.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $browserTask:Lcom/facebook/aura/model/BrowserTaskPresentation;

.field public final synthetic $confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $onOpenBrowserClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

.field public final synthetic $screenshotUri:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Lcom/facebook/aura/model/BrowserTaskPresentation;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;",
            "Lcom/facebook/aura/model/BrowserTaskPresentation;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$screenshotUri:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$browserTask:Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/33K;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->invoke(LX/33K;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 12

    .line 268435456
    move v3, p3

    .line 268435457
    const/4 v1, 0x0

    .line 268435458
    move-object v2, p1

    .line 268435459
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435460
    .line 268435461
    .line 268435462
    and-int/lit8 v0, p3, 0x6

    .line 268435463
    .line 268435464
    move-object p1, p2

    .line 268435465
    if-nez v0, :cond_0

    .line 268435466
    .line 268435467
    invoke-static {p2, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    or-int v3, p3, v0

    .line 268435472
    .line 268435473
    :cond_0
    invoke-static {v3}, LX/005;->A1G(I)Z

    .line 268435474
    .line 268435475
    .line 268435476
    move-result v0

    .line 268435477
    invoke-static {v0, p2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435478
    .line 268435479
    .line 268435480
    move-result v0

    .line 268435481
    if-eqz v0, :cond_6

    .line 268435482
    .line 268435483
    move-object v5, p0

    .line 268435484
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$screenshotUri:Ljava/lang/String;

    .line 268435485
    .line 268435486
    if-nez v0, :cond_5

    .line 268435487
    .line 268435488
    const v0, -0x17eb9a71

    .line 268435489
    .line 268435490
    .line 268435491
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435492
    .line 268435493
    .line 268435494
    const v0, 0x7f0801ae

    .line 268435495
    .line 268435496
    .line 268435497
    invoke-static {p2, v0, v1}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 268435498
    .line 268435499
    .line 268435500
    move-result-object v7

    .line 268435501
    invoke-static {p2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 268435502
    .line 268435503
    .line 268435504
    move-result-object v0

    .line 268435505
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 268435506
    .line 268435507
    iget-wide v10, v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 268435508
    .line 268435509
    sget-object v8, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->LARGE:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 268435510
    .line 268435511
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 268435512
    .line 268435513
    sget-object v0, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 268435514
    .line 268435515
    invoke-interface {v2, v0, v3}, LX/33K;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 268435516
    .line 268435517
    .line 268435518
    move-result-object v6

    .line 268435519
    invoke-static {}, LX/2l9;->A04()I

    .line 268435520
    .line 268435521
    .line 268435522
    move-result p2

    .line 268435523
    const/16 p3, 0x20

    .line 268435524
    .line 268435525
    const/4 v9, 0x0

    .line 268435526
    move-object p0, v9

    .line 268435527
    invoke-static/range {v6 .. v15}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 268435528
    .line 268435529
    .line 268435530
    :goto_0
    invoke-static {p1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 268435531
    .line 268435532
    .line 268435533
    move-result-object v4

    .line 268435534
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 268435535
    .line 268435536
    iget-object v9, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserActionLabel:Ljava/lang/String;

    .line 268435537
    .line 268435538
    const/4 v8, 0x0

    .line 268435539
    if-eqz v9, :cond_4

    .line 268435540
    .line 268435541
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 268435542
    .line 268435543
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 268435544
    .line 268435545
    invoke-interface {v3, v0}, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;->canOpen(Ljava/lang/String;)Z

    .line 268435546
    .line 268435547
    .line 268435548
    move-result v0

    .line 268435549
    if-eqz v0, :cond_4

    .line 268435550
    .line 268435551
    const v0, -0x17e5810f

    .line 268435552
    .line 268435553
    .line 268435554
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 268435555
    .line 268435556
    .line 268435557
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$browserTask:Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 268435558
    .line 268435559
    iget-object v7, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 268435560
    .line 268435561
    iget-object v6, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 268435562
    .line 268435563
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 268435564
    .line 268435565
    iget-object v5, v5, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 268435566
    .line 268435567
    if-eqz v0, :cond_3

    .line 268435568
    .line 268435569
    iget-object v0, v0, Lcom/facebook/aura/model/BrowserTaskPresentation;->siteDomain:Ljava/lang/String;

    .line 268435570
    .line 268435571
    :goto_1
    invoke-static {v0, v8}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutFaviconUri(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 268435572
    .line 268435573
    .line 268435574
    move-result-object v10

    .line 268435575
    invoke-interface {p1, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435576
    .line 268435577
    .line 268435578
    move-result v0

    .line 268435579
    invoke-static {p1, v6, v3, v0}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 268435580
    .line 268435581
    .line 268435582
    move-result v0

    .line 268435583
    invoke-static {p1, v5, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435584
    .line 268435585
    .line 268435586
    move-result v0

    .line 268435587
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435588
    .line 268435589
    .line 268435590
    move-result-object v11

    .line 268435591
    if-nez v0, :cond_1

    .line 268435592
    .line 268435593
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435594
    .line 268435595
    if-ne v11, v0, :cond_2

    .line 268435596
    .line 268435597
    :cond_1
    new-instance v11, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;

    .line 268435598
    .line 268435599
    invoke-direct {v11, v7, v6, v3, v5}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 268435600
    .line 268435601
    .line 268435602
    invoke-interface {p1, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435603
    .line 268435604
    .line 268435605
    :cond_2
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 268435606
    .line 268435607
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 268435608
    .line 268435609
    sget-object v0, LX/2Id;->A07:Landroidx/compose/ui/Alignment;

    .line 268435610
    .line 268435611
    invoke-interface {v2, v0, v3}, LX/33K;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 268435612
    .line 268435613
    .line 268435614
    move-result-object v3

    .line 268435615
    const/high16 v2, 0x41000000    # 8.0f

    .line 268435616
    .line 268435617
    const/4 v0, 0x0

    .line 268435618
    invoke-static {v3, v0, v0, v2, v2}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 268435619
    .line 268435620
    .line 268435621
    move-result-object p0

    .line 268435622
    move p3, v1

    .line 268435623
    move p2, v1

    .line 268435624
    invoke-static/range {v9 .. v15}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->BrowserTaskActionPill(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435625
    .line 268435626
    .line 268435627
    :goto_2
    invoke-static {v4, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435628
    .line 268435629
    .line 268435630
    return-void

    .line 268435631
    :cond_3
    move-object v0, v8

    .line 268435632
    goto :goto_1

    .line 268435633
    :cond_4
    const v0, -0x17e58110

    .line 268435634
    .line 268435635
    .line 268435636
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 268435637
    .line 268435638
    .line 268435639
    goto :goto_2

    .line 268435640
    :cond_5
    const v0, -0x17e76458

    .line 268435641
    .line 268435642
    .line 268435643
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435644
    .line 268435645
    .line 268435646
    goto :goto_0

    .line 268435647
    :cond_6
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435648
    .line 268435649
    .line 268435650
    return-void
.end method
