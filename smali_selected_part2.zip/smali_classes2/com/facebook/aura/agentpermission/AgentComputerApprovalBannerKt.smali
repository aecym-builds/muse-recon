.class public abstract Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final BannerIconCornerRadius:F = 10.0f

.field public static final BannerIconGlyphSize:F = 20.0f

.field public static final BannerIconSize:F = 36.0f


# direct methods
.method public static final AgentComputerApprovalBanner(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V
    .locals 31

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    const v0, 0xc131e98

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v0, :cond_8

    .line 17
    .line 18
    invoke-static {v3, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    or-int v9, v9, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v6, p4

    .line 29
    .line 30
    and-int/lit8 v8, p4, 0x2

    .line 31
    .line 32
    if-eqz v8, :cond_7

    .line 33
    .line 34
    or-int/lit8 v9, v9, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v7, v9, 0x13

    .line 37
    .line 38
    const/16 v5, 0x12

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    invoke-static {v7, v5}, LX/003;->A1H(II)Z

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    invoke-static {v5, v2, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    if-eqz v5, :cond_6

    .line 50
    .line 51
    if-eqz v8, :cond_1

    .line 52
    .line 53
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 54
    .line 55
    :cond_1
    invoke-static {v2}, LX/3Rp;->A06(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 56
    .line 57
    .line 58
    move-result-object v9

    .line 59
    invoke-static {v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionAgentName(LX/2d4;I)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v10

    .line 63
    const/4 v5, 0x0

    .line 64
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 65
    .line 66
    .line 67
    invoke-static {v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionAgentName(LX/2d4;I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    invoke-static {v3, v7, v5, v5}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->headline(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v15

    .line 75
    iget-object v7, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 76
    .line 77
    invoke-static {v7, v2, v0}, Lcom/facebook/aura/microphone/view/SilencedByMicrophoneKt;->rememberSilencedByMicrophone(Ljava/lang/Object;LX/2d4;I)Z

    .line 78
    .line 79
    .line 80
    move-result v8

    .line 81
    if-nez v15, :cond_5

    .line 82
    .line 83
    const v7, 0x24fb843c

    .line 84
    .line 85
    .line 86
    invoke-interface {v2, v7}, LX/2d4;->Agj(I)V

    .line 87
    .line 88
    .line 89
    const v7, 0x7f1200a7

    .line 90
    .line 91
    .line 92
    :goto_2
    invoke-static {v2, v10, v7}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v12

    .line 96
    invoke-static {v2}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    const v7, 0x53c6e669

    .line 101
    .line 102
    .line 103
    invoke-interface {v2, v7}, LX/2d4;->Agj(I)V

    .line 104
    .line 105
    .line 106
    sget-object v7, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 107
    .line 108
    invoke-static {v4, v3, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionApprovalImpression(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)LX/3C1;

    .line 109
    .line 110
    .line 111
    move-result-object v14

    .line 112
    if-nez v8, :cond_3

    .line 113
    .line 114
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 115
    .line 116
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v8

    .line 120
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 121
    .line 122
    if-ne v8, v7, :cond_2

    .line 123
    .line 124
    sget-object v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$1$1$1;

    .line 125
    .line 126
    invoke-interface {v2, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    :cond_2
    invoke-static {v10, v8, v0}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 130
    .line 131
    .line 132
    move-result-object v7

    .line 133
    invoke-interface {v14, v7}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 134
    .line 135
    .line 136
    move-result-object v14

    .line 137
    :cond_3
    invoke-static {v11, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 138
    .line 139
    .line 140
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;

    .line 141
    .line 142
    invoke-direct {v8, v3}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 143
    .line 144
    .line 145
    const v7, 0x4f1fead1

    .line 146
    .line 147
    .line 148
    invoke-static {v2, v8, v7}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 149
    .line 150
    .line 151
    move-result-object v13

    .line 152
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;

    .line 153
    .line 154
    invoke-direct {v8, v3, v9}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 155
    .line 156
    .line 157
    const v7, 0x1172ed6e

    .line 158
    .line 159
    .line 160
    invoke-static {v2, v8, v7}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 161
    .line 162
    .line 163
    move-result-object v16

    .line 164
    const/16 p3, 0xc00

    .line 165
    .line 166
    const p4, 0x1dfe0

    .line 167
    .line 168
    .line 169
    const-wide/16 v18, 0x0

    .line 170
    .line 171
    const/16 v20, 0x0

    .line 172
    .line 173
    const/16 v27, 0x2

    .line 174
    .line 175
    const/16 p2, 0x6030

    .line 176
    .line 177
    move-object/from16 v21, v5

    .line 178
    .line 179
    move/from16 v22, v20

    .line 180
    .line 181
    move/from16 v23, v20

    .line 182
    .line 183
    move-object/from16 v24, v5

    .line 184
    .line 185
    move-wide/from16 v25, v18

    .line 186
    .line 187
    move-object/from16 v28, v5

    .line 188
    .line 189
    move-wide/from16 v29, v18

    .line 190
    .line 191
    move/from16 p0, v0

    .line 192
    .line 193
    move-object/from16 p1, v2

    .line 194
    .line 195
    move-object/from16 v17, v5

    .line 196
    .line 197
    invoke-static/range {v12 .. v35}, Lcom/facebook/aura/ui/HatchInlineBannerKt;->HatchInlineBanner-KBbEK2Q(Ljava/lang/String;LX/JDN;LX/3C1;Ljava/lang/String;LX/JDN;LX/2bW;JFLX/2or;FFLX/2hg;JILX/2hg;JILX/2d4;III)V

    .line 198
    .line 199
    .line 200
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    if-eqz v2, :cond_4

    .line 205
    .line 206
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$4;

    .line 207
    .line 208
    invoke-direct {v0, v3, v4, v1, v6}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$4;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;II)V

    .line 209
    .line 210
    .line 211
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 212
    .line 213
    :cond_4
    return-void

    .line 214
    :cond_5
    const v7, 0x24fd44c4

    .line 215
    .line 216
    .line 217
    invoke-interface {v2, v7}, LX/2d4;->Agj(I)V

    .line 218
    .line 219
    .line 220
    const v7, 0x7f1200a6

    .line 221
    .line 222
    .line 223
    goto/16 :goto_2

    .line 224
    .line 225
    :cond_6
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 226
    .line 227
    .line 228
    goto :goto_3

    .line 229
    :cond_7
    and-int/lit8 v0, p3, 0x30

    .line 230
    .line 231
    if-nez v0, :cond_0

    .line 232
    .line 233
    invoke-static {v2, v4}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    or-int/2addr v9, v0

    .line 238
    goto/16 :goto_1

    .line 239
    .line 240
    :cond_8
    move v9, v1

    .line 241
    goto/16 :goto_0
.end method

.method public static final synthetic access$AgentComputerApprovalBanner(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->AgentComputerApprovalBanner(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getBannerIconCornerRadius$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconCornerRadius:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getBannerIconGlyphSize$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconGlyphSize:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getBannerIconSize$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconSize:F

    .line 1
    .line 2
    return v0
.end method

.method public static final rememberAgentComputerApprovalBanner(LX/2d4;I)LX/JDQ;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/JDQ<",
            "LX/3C1;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, -0x14aa89cb

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$Factory;

    .line 11
    .line 12
    invoke-direct {v5, v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$Factory;-><init>(LX/AHE;)V

    .line 13
    .line 14
    .line 15
    invoke-static {p0}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    if-eqz v4, :cond_3

    .line 20
    .line 21
    invoke-static {v4}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    const-class v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;

    .line 26
    .line 27
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const/4 v2, 0x0

    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-static {v5, v4, v3, v1, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;

    .line 38
    .line 39
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;->approval:LX/2J3;

    .line 40
    .line 41
    invoke-static {p0, v0, v2}, LX/3Rr;->A0Z(LX/2d4;LX/2J3;I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 46
    .line 47
    if-nez v2, :cond_0

    .line 48
    .line 49
    invoke-static {p0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    return-object v1

    .line 53
    :cond_0
    invoke-interface {p0, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-nez v1, :cond_1

    .line 62
    .line 63
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v0, v1, :cond_2

    .line 66
    .line 67
    :cond_1
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;

    .line 68
    .line 69
    invoke-direct {v1, v2}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 70
    .line 71
    .line 72
    const v0, 0x4ec8aa9a

    .line 73
    .line 74
    .line 75
    invoke-static {v1, v0}, LX/002;->A0W(Ljava/lang/Object;I)LX/Ddo;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_2
    check-cast v0, LX/JDQ;

    .line 83
    .line 84
    invoke-static {p0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    return-object v0

    .line 88
    :cond_3
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    throw v0
.end method

.method public static final rememberAgentComputerApprovalBanner$lambda$0(LX/16A;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;)",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/3Rq;->A09(LX/16A;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
