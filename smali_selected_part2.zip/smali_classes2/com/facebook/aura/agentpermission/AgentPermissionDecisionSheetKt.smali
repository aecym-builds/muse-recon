.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionDecisionLoading(LX/3C1;LX/2d4;II)V
    .locals 19

    .line 0
    move-object/from16 v7, p0

    .line 1
    .line 2
    const v0, -0x7fe73bb6

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p1

    .line 6
    .line 7
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v6, p3, 0x1

    .line 13
    .line 14
    const/4 v1, 0x2

    .line 15
    move/from16 v3, p2

    .line 16
    .line 17
    if-eqz v6, :cond_3

    .line 18
    .line 19
    or-int/lit8 v5, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, v5, 0x3

    .line 22
    .line 23
    const/4 v13, 0x0

    .line 24
    invoke-static {v0, v1}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0, v4, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    if-eqz v6, :cond_0

    .line 35
    .line 36
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 37
    .line 38
    :cond_0
    const v0, 0x7f1202bb

    .line 39
    .line 40
    .line 41
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;

    .line 46
    .line 47
    invoke-direct {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const v0, -0x7f299438

    .line 51
    .line 52
    .line 53
    invoke-static {v4, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 54
    .line 55
    .line 56
    move-result-object v18

    .line 57
    shl-int/lit8 v0, v5, 0x3

    .line 58
    .line 59
    and-int/lit8 p1, v0, 0x70

    .line 60
    .line 61
    const/16 p2, 0x180

    .line 62
    .line 63
    const/16 p3, 0xffd

    .line 64
    .line 65
    const/4 v6, 0x0

    .line 66
    move-object v8, v6

    .line 67
    move-object v9, v6

    .line 68
    move-object v10, v6

    .line 69
    move-object v11, v6

    .line 70
    move-object v12, v6

    .line 71
    move v14, v13

    .line 72
    move v15, v13

    .line 73
    move-object/from16 v16, v6

    .line 74
    .line 75
    move-object/from16 v17, v6

    .line 76
    .line 77
    move-object/from16 p0, v4

    .line 78
    .line 79
    invoke-static/range {v6 .. v22}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 80
    .line 81
    .line 82
    :goto_1
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    if-eqz v1, :cond_1

    .line 87
    .line 88
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$2;

    .line 89
    .line 90
    invoke-direct {v0, v7, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$2;-><init>(LX/3C1;II)V

    .line 91
    .line 92
    .line 93
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 94
    .line 95
    :cond_1
    return-void

    .line 96
    :cond_2
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 101
    .line 102
    if-nez v0, :cond_4

    .line 103
    .line 104
    invoke-static {v4, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 105
    .line 106
    .line 107
    move-result v5

    .line 108
    or-int v5, v5, p2

    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_4
    move v5, v3

    .line 112
    goto :goto_0
.end method

.method public static final AgentPermissionDecisionSheet(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v14, p1

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v6, p0

    .line 4
    .line 5
    invoke-static {v6, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x75b51454

    .line 9
    .line 10
    .line 11
    move-object/from16 v5, p2

    .line 12
    .line 13
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v4, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_10

    .line 21
    .line 22
    invoke-static {v5, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v8

    .line 26
    or-int v8, v8, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v3, p4

    .line 29
    .line 30
    and-int/lit8 v1, p4, 0x2

    .line 31
    .line 32
    if-eqz v1, :cond_f

    .line 33
    .line 34
    or-int/lit8 v8, v8, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    invoke-static {v8}, LX/005;->A1G(I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-static {v0, v5, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_e

    .line 45
    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 49
    .line 50
    :cond_1
    invoke-static {v5}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-static {v5}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    new-instance v10, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$Factory;

    .line 59
    .line 60
    invoke-direct {v10, v0, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$Factory;-><init>(LX/AHE;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-static {v5}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    if-eqz v9, :cond_11

    .line 68
    .line 69
    invoke-static {v9}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 74
    .line 75
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    const/4 v13, 0x0

    .line 80
    invoke-static {v10, v9, v7, v13, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 81
    .line 82
    .line 83
    move-result-object v11

    .line 84
    check-cast v11, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 85
    .line 86
    iget-object v0, v11, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->uiState:LX/2J3;

    .line 87
    .line 88
    invoke-static {v5, v0, v2}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 89
    .line 90
    .line 91
    move-result-object v10

    .line 92
    invoke-static {v8}, LX/008;->A1X(I)Z

    .line 93
    .line 94
    .line 95
    move-result v7

    .line 96
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-nez v7, :cond_2

    .line 101
    .line 102
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 103
    .line 104
    if-ne v0, v7, :cond_3

    .line 105
    .line 106
    :cond_2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$1$1;

    .line 107
    .line 108
    invoke-direct {v0, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$1$1;-><init>(Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    :cond_3
    invoke-static {v5, v10, v0, v6}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 119
    .line 120
    iget-object v12, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 121
    .line 122
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 127
    .line 128
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 129
    .line 130
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 131
    .line 132
    .line 133
    move-result-object v9

    .line 134
    invoke-static {v5, v10, v1}, LX/003;->A1M(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v7

    .line 138
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    if-nez v7, :cond_4

    .line 143
    .line 144
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 145
    .line 146
    if-ne v0, v7, :cond_5

    .line 147
    .line 148
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$2$1;

    .line 149
    .line 150
    invoke-direct {v0, v1, v10, v13}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$2$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;LX/16A;LX/2M4;)V

    .line 151
    .line 152
    .line 153
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    :cond_5
    check-cast v0, LX/JDN;

    .line 157
    .line 158
    sget v17, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 159
    .line 160
    invoke-static {v5, v12, v9, v0}, LX/CdB;->A04(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;LX/JDN;)V

    .line 161
    .line 162
    .line 163
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 168
    .line 169
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 170
    .line 171
    if-nez v9, :cond_8

    .line 172
    .line 173
    const v0, 0x44a335c2

    .line 174
    .line 175
    .line 176
    invoke-static {v5, v10, v0}, LX/3Rr;->A0X(LX/2d4;LX/16A;I)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 181
    .line 182
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 183
    .line 184
    if-eqz v0, :cond_7

    .line 185
    .line 186
    const v0, 0x44a3bb15

    .line 187
    .line 188
    .line 189
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 190
    .line 191
    .line 192
    shr-int/lit8 v0, v8, 0x3

    .line 193
    .line 194
    and-int/lit8 v0, v0, 0xe

    .line 195
    .line 196
    invoke-static {v14, v5, v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt;->AgentPermissionDecisionLoading(LX/3C1;LX/2d4;II)V

    .line 197
    .line 198
    .line 199
    :goto_2
    invoke-static {v5}, LX/007;->A1M(Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    if-eqz v1, :cond_6

    .line 207
    .line 208
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$3;

    .line 209
    .line 210
    invoke-direct {v0, v6, v14, v4, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$3;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 211
    .line 212
    .line 213
    :goto_3
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_6
    return-void

    .line 217
    :cond_7
    const v0, 0x44a4af16

    .line 218
    .line 219
    .line 220
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 221
    .line 222
    .line 223
    goto :goto_2

    .line 224
    :cond_8
    const v0, 0x44a4e936

    .line 225
    .line 226
    .line 227
    invoke-static {v5, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 228
    .line 229
    .line 230
    move-result-object v7

    .line 231
    invoke-static {v9}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->rendersCheckoutCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    if-eqz v0, :cond_b

    .line 236
    .line 237
    const v0, 0x44a5d6cc

    .line 238
    .line 239
    .line 240
    invoke-static {v5, v10, v0}, LX/3Rr;->A0X(LX/2d4;LX/16A;I)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 245
    .line 246
    iget-boolean v12, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 247
    .line 248
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 253
    .line 254
    iget-boolean v10, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 255
    .line 256
    invoke-static {v5, v9, v11}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v1

    .line 264
    if-nez v0, :cond_9

    .line 265
    .line 266
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 267
    .line 268
    if-ne v1, v0, :cond_a

    .line 269
    .line 270
    :cond_9
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;

    .line 271
    .line 272
    invoke-direct {v1, v9, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V

    .line 273
    .line 274
    .line 275
    invoke-interface {v5, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 276
    .line 277
    .line 278
    :cond_a
    check-cast v1, LX/JDM;

    .line 279
    .line 280
    shl-int/lit8 v0, v8, 0x6

    .line 281
    .line 282
    and-int/lit16 v0, v0, 0x1c00

    .line 283
    .line 284
    or-int v17, v17, v0

    .line 285
    .line 286
    move/from16 v18, v2

    .line 287
    .line 288
    move-object v11, v9

    .line 289
    move-object v13, v1

    .line 290
    move v15, v10

    .line 291
    move-object/from16 v16, v5

    .line 292
    .line 293
    invoke-static/range {v11 .. v18}, Lcom/facebook/aura/agentpermission/CheckoutApprovalDecisionSheetKt;->CheckoutApprovalDecisionSheet(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLX/JDM;LX/3C1;ZLX/2d4;II)V

    .line 294
    .line 295
    .line 296
    invoke-static {v5, v7}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 297
    .line 298
    .line 299
    move-result-object v1

    .line 300
    if-eqz v1, :cond_6

    .line 301
    .line 302
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$5;

    .line 303
    .line 304
    invoke-direct {v0, v6, v14, v4, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$5;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 305
    .line 306
    .line 307
    goto :goto_3

    .line 308
    :cond_b
    const v0, 0x44ac8e16

    .line 309
    .line 310
    .line 311
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 312
    .line 313
    .line 314
    invoke-static {v7, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 315
    .line 316
    .line 317
    invoke-static {v5, v9, v1}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 318
    .line 319
    .line 320
    move-result v0

    .line 321
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v7

    .line 325
    if-nez v0, :cond_c

    .line 326
    .line 327
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 328
    .line 329
    if-ne v7, v0, :cond_d

    .line 330
    .line 331
    :cond_c
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$6$1;

    .line 332
    .line 333
    invoke-direct {v7, v9, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$6$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 334
    .line 335
    .line 336
    invoke-interface {v5, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 337
    .line 338
    .line 339
    :cond_d
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 340
    .line 341
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;

    .line 342
    .line 343
    invoke-direct {v1, v9, v11, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;LX/16A;)V

    .line 344
    .line 345
    .line 346
    const v0, 0x480042ee

    .line 347
    .line 348
    .line 349
    invoke-static {v5, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 350
    .line 351
    .line 352
    move-result-object p0

    .line 353
    and-int/lit8 p2, v8, 0x70

    .line 354
    .line 355
    const/16 p3, 0x180

    .line 356
    .line 357
    const/16 p4, 0xfbd

    .line 358
    .line 359
    move-object v15, v13

    .line 360
    move-object/from16 v16, v13

    .line 361
    .line 362
    move-object/from16 v17, v13

    .line 363
    .line 364
    move-object/from16 v18, v13

    .line 365
    .line 366
    move/from16 v21, v2

    .line 367
    .line 368
    move/from16 v22, v2

    .line 369
    .line 370
    move-object/from16 v23, v13

    .line 371
    .line 372
    move-object/from16 v24, v13

    .line 373
    .line 374
    move-object/from16 p1, v5

    .line 375
    .line 376
    move-object/from16 v19, v7

    .line 377
    .line 378
    move/from16 v20, v2

    .line 379
    .line 380
    invoke-static/range {v13 .. v29}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 381
    .line 382
    .line 383
    goto :goto_4

    .line 384
    :cond_e
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 385
    .line 386
    .line 387
    :goto_4
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 388
    .line 389
    .line 390
    move-result-object v1

    .line 391
    if-eqz v1, :cond_6

    .line 392
    .line 393
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$8;

    .line 394
    .line 395
    invoke-direct {v0, v6, v14, v4, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$8;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 396
    .line 397
    .line 398
    goto/16 :goto_3

    .line 399
    .line 400
    :cond_f
    and-int/lit8 v0, p3, 0x30

    .line 401
    .line 402
    if-nez v0, :cond_0

    .line 403
    .line 404
    invoke-static {v5, v14}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 405
    .line 406
    .line 407
    move-result v0

    .line 408
    or-int/2addr v8, v0

    .line 409
    goto/16 :goto_1

    .line 410
    .line 411
    :cond_10
    move v8, v4

    .line 412
    goto/16 :goto_0

    .line 413
    .line 414
    :cond_11
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    throw v0
.end method

.method public static final AgentPermissionDecisionSheet$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$AgentPermissionDecisionSheet$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 5
    .line 6
    return-object p0
.end method
