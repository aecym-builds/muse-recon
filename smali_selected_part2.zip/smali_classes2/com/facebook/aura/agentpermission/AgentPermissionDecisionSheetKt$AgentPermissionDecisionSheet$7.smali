.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$uiState$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 15

    .line 268435456
    const/4 v14, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    move/from16 v1, p3

    .line 268435460
    .line 268435461
    invoke-static {v0, v14, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object/from16 v12, p2

    .line 268435466
    .line 268435467
    invoke-static {v0, v12, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    if-eqz v0, :cond_2

    .line 268435472
    .line 268435473
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435474
    .line 268435475
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 268435476
    .line 268435477
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 268435478
    .line 268435479
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$uiState$delegate:LX/16A;

    .line 268435480
    .line 268435481
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435482
    .line 268435483
    .line 268435484
    move-result-object v0

    .line 268435485
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 268435486
    .line 268435487
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 268435488
    .line 268435489
    xor-int/lit8 v6, v0, 0x1

    .line 268435490
    .line 268435491
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435492
    .line 268435493
    invoke-interface {v12, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435494
    .line 268435495
    .line 268435496
    move-result v1

    .line 268435497
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 268435498
    .line 268435499
    invoke-static {v12, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435500
    .line 268435501
    .line 268435502
    move-result v0

    .line 268435503
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435504
    .line 268435505
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 268435506
    .line 268435507
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435508
    .line 268435509
    .line 268435510
    move-result-object v7

    .line 268435511
    if-nez v0, :cond_0

    .line 268435512
    .line 268435513
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435514
    .line 268435515
    if-ne v7, v0, :cond_1

    .line 268435516
    .line 268435517
    :cond_0
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7$1$1;

    .line 268435518
    .line 268435519
    invoke-direct {v7, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V

    .line 268435520
    .line 268435521
    .line 268435522
    invoke-interface {v12, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435523
    .line 268435524
    .line 268435525
    :cond_1
    check-cast v7, LX/JDN;

    .line 268435526
    .line 268435527
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 268435528
    .line 268435529
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435530
    .line 268435531
    invoke-static {v1, v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionApprovalImpression(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)LX/3C1;

    .line 268435532
    .line 268435533
    .line 268435534
    move-result-object v0

    .line 268435535
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 268435536
    .line 268435537
    invoke-static {v0, v1}, LX/3Rr;->A08(LX/3C1;F)LX/3C1;

    .line 268435538
    .line 268435539
    .line 268435540
    move-result-object v8

    .line 268435541
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmallPlusNano:F

    .line 268435542
    .line 268435543
    const/high16 v0, 0x41300000    # 11.0f

    .line 268435544
    .line 268435545
    new-instance v10, LX/1XE;

    .line 268435546
    .line 268435547
    invoke-direct {v10, v1, v0, v1, v0}, LX/1XE;-><init>(FFFF)V

    .line 268435548
    .line 268435549
    .line 268435550
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$7;->$uiState$delegate:LX/16A;

    .line 268435551
    .line 268435552
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435553
    .line 268435554
    .line 268435555
    move-result-object v0

    .line 268435556
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 268435557
    .line 268435558
    iget-boolean v11, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 268435559
    .line 268435560
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 268435561
    .line 268435562
    or-int/lit8 v13, v0, 0x30

    .line 268435563
    .line 268435564
    invoke-static/range {v3 .. v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalContent-7UH0Qls(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZLX/2d4;II)V

    .line 268435565
    .line 268435566
    .line 268435567
    return-void

    .line 268435568
    :cond_2
    invoke-interface {v12}, LX/2d4;->AgJ()V

    .line 268435569
    .line 268435570
    .line 268435571
    return-void
.end method
