.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final historyRepository:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

.field public final historyState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryState;",
            ">;"
        }
    .end annotation
.end field

.field public final submittingApprovalIds:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 15

    .line 0
    const/4 v9, 0x0

    .line 1
    move-object/from16 v2, p1

    .line 2
    .line 3
    invoke-static {v2, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object v3, p0

    .line 7
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-static {v2}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->Companion:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$Companion;

    .line 17
    .line 18
    invoke-virtual {v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyRepository:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    sget-object v11, LX/0wV;->A00:LX/0wV;

    .line 26
    .line 27
    sget-object v12, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 28
    .line 29
    const/4 v14, 0x1

    .line 30
    new-instance v10, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 31
    .line 32
    move p0, v9

    .line 33
    move-object v13, v6

    .line 34
    invoke-direct/range {v10 .. v15}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)V

    .line 35
    .line 36
    .line 37
    invoke-static {v10}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    iput-object v5, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 42
    .line 43
    sget-object v0, LX/0wX;->A00:LX/0wX;

    .line 44
    .line 45
    invoke-static {v0}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    iput-object v4, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->submittingApprovalIds:LX/2J2;

    .line 50
    .line 51
    iget-object v2, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 52
    .line 53
    iget-object v1, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->confirmingApprovalIds:LX/2J3;

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;

    .line 56
    .line 57
    invoke-direct {v0, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;-><init>(LX/2M4;)V

    .line 58
    .line 59
    .line 60
    invoke-static {v0, v2, v5, v4, v1}, LX/EXj;->A01(LX/JDR;LX/2Lw;LX/2Lw;LX/2Lw;LX/2Lw;)LX/5zp;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    invoke-static {v3}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    sget-object v0, LX/5Lz;->A00:LX/5Ly;

    .line 69
    .line 70
    const/16 p0, 0x1ff

    .line 71
    .line 72
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 73
    .line 74
    move-object v7, v6

    .line 75
    move-object v8, v6

    .line 76
    move v10, v9

    .line 77
    move-object v11, v6

    .line 78
    move-object v12, v6

    .line 79
    move-object v14, v6

    .line 80
    move-object/from16 p1, v6

    .line 81
    .line 82
    invoke-direct/range {v5 .. v16}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;ILX/04f;)V

    .line 83
    .line 84
    .line 85
    invoke-static {v5, v1, v2, v0}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    iput-object v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->uiState:LX/2J3;

    .line 90
    .line 91
    invoke-static {v3}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;

    .line 96
    .line 97
    invoke-direct {v0, v3, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/2M4;)V

    .line 98
    .line 99
    .line 100
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 101
    .line 102
    .line 103
    return-void
.end method

.method public static final synthetic access$getApprovalsRepository$p(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getHistoryRepository$p(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyRepository:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getHistoryState$p(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSubmittingApprovalIds$p(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->submittingApprovalIds:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static synthetic loadHistory$default(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p2, p1}, LX/002;->A1U(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->loadHistory(Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final loadHistory(Z)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 7
    .line 8
    iget-object v1, v2, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 11
    .line 12
    if-eq v1, v0, :cond_0

    .line 13
    .line 14
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    if-nez p1, :cond_1

    .line 19
    .line 20
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 21
    .line 22
    if-eq v1, v0, :cond_1

    .line 23
    .line 24
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 25
    .line 26
    if-nez v0, :cond_1

    .line 27
    .line 28
    :cond_0
    return-void

    .line 29
    :cond_1
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    const/4 v1, 0x0

    .line 34
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;

    .line 35
    .line 36
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;ZLX/2M4;)V

    .line 37
    .line 38
    .line 39
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final submit(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v6, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v4, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 8
    .line 9
    invoke-static {p2, v0}, LX/B89;->A0N(ILjava/util/List;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v5

    .line 13
    check-cast v5, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 14
    .line 15
    if-eqz v5, :cond_7

    .line 16
    .line 17
    invoke-static {p1, v5}, Lcom/facebook/aura/gateway/ApprovalCardOnlyKt;->isQuickDecisionAllowed(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_7

    .line 22
    .line 23
    move-object v3, p0

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->submittingApprovalIds:LX/2J2;

    .line 25
    .line 26
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Ljava/util/Set;

    .line 31
    .line 32
    invoke-interface {v0, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    sget-object v2, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->ALREADY_SUBMITTING:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 39
    .line 40
    :goto_0
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 43
    .line 44
    invoke-virtual {v1, v4, v2, v0}, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->logSkipped(Ljava/lang/String;Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;Lcom/facebook/aura/gateway/ApprovalOrigin;)V

    .line 45
    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->AWAITING_SNAPSHOT:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 48
    .line 49
    if-ne v2, v0, :cond_0

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 52
    .line 53
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->requestDecisionConfirmation()V

    .line 54
    .line 55
    .line 56
    :cond_0
    return-void

    .line 57
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 58
    .line 59
    invoke-virtual {v0, v4}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->isConfirmingDecision(Ljava/lang/String;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    sget-object v2, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->AWAITING_SNAPSHOT:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 69
    .line 70
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 71
    .line 72
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Ljava/lang/Iterable;

    .line 77
    .line 78
    instance-of v0, v1, Ljava/util/Collection;

    .line 79
    .line 80
    if-eqz v0, :cond_4

    .line 81
    .line 82
    move-object v0, v1

    .line 83
    check-cast v0, Ljava/util/Collection;

    .line 84
    .line 85
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_4

    .line 90
    .line 91
    :cond_3
    sget-object v2, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->NOT_PENDING:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_4
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    :cond_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_3

    .line 103
    .line 104
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 109
    .line 110
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 111
    .line 112
    invoke-static {v0, v4}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_5

    .line 117
    .line 118
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->submittingApprovalIds:LX/2J2;

    .line 119
    .line 120
    :cond_6
    invoke-static {v4, v1}, LX/3Rs;->A1T(Ljava/lang/Object;LX/2J2;)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_6

    .line 125
    .line 126
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    const/4 p0, 0x0

    .line 131
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;

    .line 132
    .line 133
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;Ljava/lang/String;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2M4;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v2, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 137
    .line 138
    .line 139
    return-void

    .line 140
    :cond_7
    sget-object v2, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 141
    .line 142
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->OPTION_UNAVAILABLE:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 143
    .line 144
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 145
    .line 146
    invoke-virtual {v2, v4, v1, v0}, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->logSkipped(Ljava/lang/String;Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;Lcom/facebook/aura/gateway/ApprovalOrigin;)V

    .line 147
    .line 148
    .line 149
    return-void
.end method
