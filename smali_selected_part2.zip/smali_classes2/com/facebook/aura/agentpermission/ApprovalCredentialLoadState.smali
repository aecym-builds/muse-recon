.class public final enum Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

.field public static final enum FAILED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

.field public static final enum LOADED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

.field public static final enum LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const-string v1, "LOADING"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 4
    .line 5
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 9
    .line 10
    const-string v1, "FAILED"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->FAILED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 19
    .line 20
    const-string v2, "LOADED"

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 24
    .line 25
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 29
    .line 30
    filled-new-array {v4, v3, v0}, [Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sput-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->$VALUES:[Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 35
    .line 36
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sput-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->$ENTRIES:LX/0vk;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->$VALUES:[Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 7
    .line 8
    return-object v0
.end method
