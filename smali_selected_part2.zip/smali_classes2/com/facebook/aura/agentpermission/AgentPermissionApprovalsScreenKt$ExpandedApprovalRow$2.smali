.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $confirming:Z

.field public final synthetic $decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onDecision:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onReview:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $submitting:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            "ZZ",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$submitting:Z

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$confirming:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$onDecision:LX/JDM;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$onReview:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$modifier:LX/3C1;

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$$changed:I

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$$default:I

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 3
    .line 4
    iget-boolean v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$submitting:Z

    .line 5
    .line 6
    iget-boolean v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$confirming:Z

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$onDecision:LX/JDM;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$onReview:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$modifier:LX/3C1;

    .line 13
    .line 14
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$$changed:I

    .line 15
    .line 16
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 17
    .line 18
    .line 19
    move-result v9

    .line 20
    iget p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;->$$default:I

    .line 21
    .line 22
    move-object v8, p1

    .line 23
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ExpandedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
