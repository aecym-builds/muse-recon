.class public final Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public final synthetic $this_Column:LX/3dS;

.field public final synthetic $uriHandler:LX/18m;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3dS;LX/18m;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$this_Column:LX/3dS;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$uriHandler:LX/18m;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComponent;->EXTERNAL_LINK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 5
    .line 6
    invoke-static {v2, v1, v0}, LX/3Rs;->A10(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$uriHandler:LX/18m;

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;->$item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;

    .line 12
    .line 13
    :try_start_0
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;->url:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/18m;->openUri(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    :goto_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    if-eqz v2, :cond_0

    .line 31
    .line 32
    const-string v1, "ApprovalPreviewLinks"

    .line 33
    .line 34
    const-string v0, "Failed to open approval preview link"

    .line 35
    .line 36
    invoke-static {v1, v0, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    return-void
.end method
