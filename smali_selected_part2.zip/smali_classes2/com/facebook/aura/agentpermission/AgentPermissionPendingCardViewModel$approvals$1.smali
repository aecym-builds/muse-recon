.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDQ<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;",
        "Ljava/lang/String;",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionPendingCardViewModel$approvals$1"
    f = "AgentPermissionPendingCardViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic L$1:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/util/List;

    .line 1
    .line 2
    check-cast p2, Ljava/lang/String;

    .line 3
    .line 4
    check-cast p3, LX/2M4;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->invoke(Ljava/util/List;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final invoke(Ljava/util/List;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 268435457
    .line 268435458
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;

    .line 268435459
    .line 268435460
    invoke-direct {p0, v0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->L$0:Ljava/lang/Object;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->L$1:Ljava/lang/Object;

    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435470
    .line 268435471
    .line 268435472
    move-result-object v0

    .line 268435473
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v3, Ljava/util/List;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->L$1:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v2, Ljava/lang/String;

    .line 7
    .line 8
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->label:I

    .line 9
    .line 10
    if-nez v0, :cond_2

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$approvals$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->screenSessionId:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v0, v2}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->resolveThreadId(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    move-object v0, v2

    .line 44
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 45
    .line 46
    invoke-static {v0, p1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepositoryKt;->classifyApprovalPresentation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalPresentation;->BLOCKING:Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 51
    .line 52
    if-ne v1, v0, :cond_0

    .line 53
    .line 54
    invoke-virtual {p0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    return-object p0

    .line 59
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    throw v0
.end method
