.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$Companion;


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->Companion:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->userSession:LX/AHE;

    .line 4
    .line 5
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;-><init>(LX/AHE;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static synthetic getApprovalHistory-0E7RQCE$default(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;Ljava/lang/String;ILX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/16 p2, 0x32

    .line 5
    .line 6
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->getApprovalHistory-0E7RQCE(Ljava/lang/String;ILX/2M4;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method


# virtual methods
.method public clearUserData()V
    .locals 0

    .line 0
    return-void
.end method

.method public final getApprovalHistory-0E7RQCE(Ljava/lang/String;ILX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v1, LX/2PJ;

    .line 33
    .line 34
    iget-object v0, v1, LX/2PJ;->value:Ljava/lang/Object;

    .line 35
    .line 36
    return-object v0

    .line 37
    :cond_1
    invoke-static {v1}, LX/2PI;->A03(Ljava/lang/Object;)LX/BqD;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    const/4 v1, 0x0

    .line 42
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;

    .line 43
    .line 44
    invoke-direct {v0, p0, p2, p1, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;ILjava/lang/String;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    iput-object v1, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->L$0:Ljava/lang/Object;

    .line 48
    .line 49
    iput p2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->I$0:I

    .line 50
    .line 51
    iput v3, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;->label:I

    .line 52
    .line 53
    invoke-static {v5, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    if-ne v1, v4, :cond_0

    .line 58
    .line 59
    return-object v4

    .line 60
    :cond_2
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;

    .line 61
    .line 62
    invoke-direct {v5, p0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;LX/2M4;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    throw v0
.end method
