.class public final synthetic Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberPendingApprovalBatchKeySnapshot$1$1;
.super LX/DVE;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 6

    .line 0
    const-class v3, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    const-string v5, "currentBatchKey()Ljava/lang/String;"

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    const-string v4, "currentBatchKey"

    .line 6
    .line 7
    move-object v0, p0

    .line 8
    move-object v2, p1

    .line 9
    move p0, v1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberPendingApprovalBatchKeySnapshot$1$1;->invoke()Ljava/lang/String;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final invoke()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, LX/DqR;->receiver:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->currentBatchKey()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method
