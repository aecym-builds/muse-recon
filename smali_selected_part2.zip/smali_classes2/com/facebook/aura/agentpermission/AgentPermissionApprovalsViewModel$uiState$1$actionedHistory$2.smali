.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/Boolean;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 5
    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    iget-object p1, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 9
    .line 10
    :goto_0
    sget-object p0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->PENDING:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 11
    .line 12
    invoke-static {p1, p0}, LX/003;->A1S(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :cond_0
    const/4 p1, 0x0

    .line 22
    goto :goto_0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;->invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/Boolean;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
