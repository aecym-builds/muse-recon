.class public final Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $onOpen:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resolvedResource:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/AHE;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;",
            "LX/AHE;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$onOpen:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$resolvedResource:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 6

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$onOpen:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$resolvedResource:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;

    .line 6
    .line 7
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->url:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$item:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;

    .line 10
    .line 11
    iget-object v2, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->fileName:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$userSession:LX/AHE;

    .line 14
    .line 15
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 16
    .line 17
    const/4 v5, 0x0

    .line 18
    const/4 p0, 0x0

    .line 19
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/file/view/api/ContentViewerDataHolderKt;->navigateToFileViewerFromUrl(Ljava/lang/String;Ljava/lang/String;LX/AHE;Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;Z)Z

    .line 20
    .line 21
    .line 22
    return-void
.end method
