.class public abstract Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final MAX_LEGAL_LINKS:I = 0x4


# direct methods
.method public static final CarRentalReservationApprovalCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;LX/2d4;II)V
    .locals 13

    .line 0
    move-object/from16 v9, p3

    .line 1
    .line 2
    const/4 v12, 0x0

    .line 3
    move-object v3, p0

    .line 4
    move-object v2, p1

    .line 5
    move-object v7, p2

    .line 6
    invoke-static {p0, p1, p2}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    const v0, -0x3be4ae91    # -621.2724f

    .line 10
    .line 11
    .line 12
    move-object/from16 p2, p4

    .line 13
    .line 14
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 15
    .line 16
    .line 17
    move/from16 v1, p5

    .line 18
    .line 19
    and-int/lit8 v0, p5, 0x6

    .line 20
    .line 21
    if-nez v0, :cond_7

    .line 22
    .line 23
    invoke-static {p0, p2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {v0}, LX/003;->A06(I)I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    or-int v4, v4, p5

    .line 32
    .line 33
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 34
    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    invoke-static {p1, p2, v1}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0}, LX/003;->A07(I)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v4, v0

    .line 46
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 47
    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    invoke-static {v7, p2, v1}, LX/005;->A1Y(Ljava/lang/Object;LX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0}, LX/003;->A08(I)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    or-int/2addr v4, v0

    .line 59
    :cond_1
    move/from16 p5, p6

    .line 60
    .line 61
    and-int/lit8 v5, p6, 0x8

    .line 62
    .line 63
    if-eqz v5, :cond_6

    .line 64
    .line 65
    or-int/lit16 v4, v4, 0xc00

    .line 66
    .line 67
    :cond_2
    :goto_1
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-static {v0, p2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_5

    .line 76
    .line 77
    if-eqz v5, :cond_3

    .line 78
    .line 79
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 80
    .line 81
    :cond_3
    iget-object v6, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 82
    .line 83
    new-instance v5, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$1;

    .line 84
    .line 85
    invoke-direct {v5, p0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 86
    .line 87
    .line 88
    const v0, 0xc424cc7

    .line 89
    .line 90
    .line 91
    invoke-static {p2, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 92
    .line 93
    .line 94
    move-result-object v8

    .line 95
    new-instance v5, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$2;

    .line 96
    .line 97
    invoke-direct {v5, p1, v7}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;)V

    .line 98
    .line 99
    .line 100
    const v0, -0x529e155c

    .line 101
    .line 102
    .line 103
    invoke-static {p2, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 104
    .line 105
    .line 106
    move-result-object v11

    .line 107
    new-instance v5, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;

    .line 108
    .line 109
    invoke-direct {v5, p1}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;)V

    .line 110
    .line 111
    .line 112
    const v0, 0x4e818881

    .line 113
    .line 114
    .line 115
    invoke-static {p2, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    sget v0, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->$stable:I

    .line 120
    .line 121
    shl-int/lit8 v5, v0, 0x3

    .line 122
    .line 123
    const v0, 0x6030180

    .line 124
    .line 125
    .line 126
    or-int/2addr v5, v0

    .line 127
    shr-int/lit8 v0, v4, 0x3

    .line 128
    .line 129
    and-int/lit8 v0, v0, 0x70

    .line 130
    .line 131
    invoke-static {v5, v0, v4}, LX/001;->A07(III)I

    .line 132
    .line 133
    .line 134
    move-result p3

    .line 135
    const/16 p4, 0xd0

    .line 136
    .line 137
    const/4 v10, 0x0

    .line 138
    move-object p0, v10

    .line 139
    invoke-static/range {v6 .. v17}, Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt;->ApprovalCardScaffold(Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/JDQ;LX/3C1;Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;LX/JDQ;ZLX/JDN;LX/JDQ;LX/2d4;II)V

    .line 140
    .line 141
    .line 142
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 143
    .line 144
    .line 145
    move-result-object v4

    .line 146
    if-eqz v4, :cond_4

    .line 147
    .line 148
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$4;

    .line 149
    .line 150
    move-object p1, v2

    .line 151
    move-object p2, v7

    .line 152
    move-object/from16 p3, v9

    .line 153
    .line 154
    move/from16 p4, v1

    .line 155
    .line 156
    move-object v12, v0

    .line 157
    move-object p0, v3

    .line 158
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$4;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;II)V

    .line 159
    .line 160
    .line 161
    iput-object v0, v4, LX/J7V;->A06:LX/JDN;

    .line 162
    .line 163
    :cond_4
    return-void

    .line 164
    :cond_5
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 165
    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_6
    and-int/lit16 v0, v1, 0xc00

    .line 169
    .line 170
    if-nez v0, :cond_2

    .line 171
    .line 172
    invoke-static {p2, v9}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    or-int/2addr v4, v0

    .line 177
    goto :goto_1

    .line 178
    :cond_7
    move v4, v1

    .line 179
    goto/16 :goto_0
.end method

.method public static final CarRentalReservationDetailRows(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;LX/2d4;I)V
    .locals 17

    .line 0
    const v0, 0x73a7be80

    .line 1
    .line 2
    .line 3
    move-object/from16 v3, p1

    .line 4
    .line 5
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p2

    .line 9
    .line 10
    and-int/lit8 v0, p2, 0x6

    .line 11
    .line 12
    const/4 v6, 0x2

    .line 13
    move-object/from16 v4, p0

    .line 14
    .line 15
    if-nez v0, :cond_8

    .line 16
    .line 17
    invoke-static {v4, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0}, LX/003;->A06(I)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    or-int v1, v1, p2

    .line 26
    .line 27
    :goto_0
    and-int/lit8 v0, v1, 0x3

    .line 28
    .line 29
    const/4 v5, 0x1

    .line 30
    const/4 v14, 0x0

    .line 31
    invoke-static {v0, v6}, LX/003;->A1H(II)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_7

    .line 40
    .line 41
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->pickup:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;

    .line 42
    .line 43
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;->locationName:Ljava/lang/String;

    .line 44
    .line 45
    if-nez v7, :cond_0

    .line 46
    .line 47
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;->address:Ljava/lang/String;

    .line 48
    .line 49
    :cond_0
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->dropoff:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;

    .line 50
    .line 51
    iget-object v6, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;->locationName:Ljava/lang/String;

    .line 52
    .line 53
    if-nez v6, :cond_1

    .line 54
    .line 55
    iget-object v6, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;->address:Ljava/lang/String;

    .line 56
    .line 57
    :cond_1
    iget-object v11, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->vehicleName:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v10, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->supplierName:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->category:Ljava/lang/String;

    .line 62
    .line 63
    invoke-static {v0, v3, v14}, Lcom/facebook/aura/agentpermission/CarRentalReservationFormattingKt;->carRentalClass(Ljava/lang/String;LX/2d4;I)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->transmission:Ljava/lang/String;

    .line 68
    .line 69
    invoke-static {v0, v3, v14}, Lcom/facebook/aura/agentpermission/CarRentalReservationFormattingKt;->carRentalTransmission(Ljava/lang/String;LX/2d4;I)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v8

    .line 73
    iget-object v1, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->seats:Ljava/lang/Integer;

    .line 74
    .line 75
    const/4 v13, 0x0

    .line 76
    if-nez v1, :cond_6

    .line 77
    .line 78
    const v0, -0x12669d26

    .line 79
    .line 80
    .line 81
    invoke-static {v3, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    move-object v1, v13

    .line 86
    :goto_1
    filled-new-array {v10, v9, v8, v1}, [Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-static {v1}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 91
    .line 92
    .line 93
    move-result-object v8

    .line 94
    const v1, 0x7f120663

    .line 95
    .line 96
    .line 97
    invoke-static {v3, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    invoke-static {v1, v8, v13}, LX/3Rq;->A1A(Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v12

    .line 105
    const/16 p2, 0x3c

    .line 106
    .line 107
    move-object v15, v13

    .line 108
    move-object/from16 v16, v13

    .line 109
    .line 110
    move/from16 p1, v14

    .line 111
    .line 112
    move-object/from16 p0, v3

    .line 113
    .line 114
    invoke-static/range {v11 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutTextRow(Ljava/lang/String;Ljava/lang/String;LX/3C1;ILkotlin/jvm/functions/Function0;Ljava/lang/String;LX/2d4;II)V

    .line 115
    .line 116
    .line 117
    invoke-static {v13, v3, v14, v5}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDivider(LX/3C1;LX/2d4;II)V

    .line 118
    .line 119
    .line 120
    if-nez v7, :cond_5

    .line 121
    .line 122
    iget-object v11, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->supplierName:Ljava/lang/String;

    .line 123
    .line 124
    :goto_2
    iget-object v8, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->pickup:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;

    .line 125
    .line 126
    iget-object v1, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->dropoff:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;

    .line 127
    .line 128
    invoke-static {v8, v1}, Lcom/facebook/aura/agentpermission/CarRentalReservationFormattingKt;->formatCarRentalPeriod(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationStop;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v12

    .line 132
    invoke-static/range {v11 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutTextRow(Ljava/lang/String;Ljava/lang/String;LX/3C1;ILkotlin/jvm/functions/Function0;Ljava/lang/String;LX/2d4;II)V

    .line 133
    .line 134
    .line 135
    if-eqz v6, :cond_4

    .line 136
    .line 137
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-nez v1, :cond_4

    .line 142
    .line 143
    const v1, -0x126049a3

    .line 144
    .line 145
    .line 146
    invoke-interface {v3, v1}, LX/2d4;->Agj(I)V

    .line 147
    .line 148
    .line 149
    invoke-static {v13, v3, v14, v5}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDivider(LX/3C1;LX/2d4;II)V

    .line 150
    .line 151
    .line 152
    const v1, 0x7f120650

    .line 153
    .line 154
    .line 155
    invoke-static {v3, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v12

    .line 159
    move-object v11, v6

    .line 160
    invoke-static/range {v11 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutTextRow(Ljava/lang/String;Ljava/lang/String;LX/3C1;ILkotlin/jvm/functions/Function0;Ljava/lang/String;LX/2d4;II)V

    .line 161
    .line 162
    .line 163
    invoke-static {v0, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 164
    .line 165
    .line 166
    :goto_3
    iget-object v12, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->driverName:Ljava/lang/String;

    .line 167
    .line 168
    if-nez v12, :cond_3

    .line 169
    .line 170
    const v1, -0x125c782c

    .line 171
    .line 172
    .line 173
    invoke-interface {v3, v1}, LX/2d4;->Agj(I)V

    .line 174
    .line 175
    .line 176
    :goto_4
    invoke-static {v0, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 177
    .line 178
    .line 179
    :goto_5
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    if-eqz v1, :cond_2

    .line 184
    .line 185
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationDetailRows$5;

    .line 186
    .line 187
    invoke-direct {v0, v4, v2}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationDetailRows$5;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;I)V

    .line 188
    .line 189
    .line 190
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 191
    .line 192
    :cond_2
    return-void

    .line 193
    :cond_3
    const v1, -0x125c782b

    .line 194
    .line 195
    .line 196
    invoke-interface {v3, v1}, LX/2d4;->Agj(I)V

    .line 197
    .line 198
    .line 199
    invoke-static {v13, v3, v14, v5}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDivider(LX/3C1;LX/2d4;II)V

    .line 200
    .line 201
    .line 202
    const v1, 0x7f120635

    .line 203
    .line 204
    .line 205
    invoke-static {v3, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v11

    .line 209
    invoke-static/range {v11 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutTextRow(Ljava/lang/String;Ljava/lang/String;LX/3C1;ILkotlin/jvm/functions/Function0;Ljava/lang/String;LX/2d4;II)V

    .line 210
    .line 211
    .line 212
    goto :goto_4

    .line 213
    :cond_4
    const v1, -0x126049a4

    .line 214
    .line 215
    .line 216
    invoke-interface {v3, v1}, LX/2d4;->Agj(I)V

    .line 217
    .line 218
    .line 219
    invoke-static {v0, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 220
    .line 221
    .line 222
    goto :goto_3

    .line 223
    :cond_5
    move-object v11, v7

    .line 224
    goto :goto_2

    .line 225
    :cond_6
    const v0, -0x12669d25

    .line 226
    .line 227
    .line 228
    invoke-static {v3, v1, v0}, LX/3Rr;->A04(LX/2d4;Ljava/lang/Number;I)I

    .line 229
    .line 230
    .line 231
    move-result v1

    .line 232
    const v0, 0x7f10001c

    .line 233
    .line 234
    .line 235
    invoke-static {v1, v3, v0}, LX/18b;->A02(ILX/2d4;I)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    invoke-static {v3}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    goto/16 :goto_1

    .line 244
    .line 245
    :cond_7
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 246
    .line 247
    .line 248
    goto :goto_5

    .line 249
    :cond_8
    move v1, v2

    .line 250
    goto/16 :goto_0
.end method

.method public static final CarRentalReservationDivider(LX/3C1;LX/2d4;II)V
    .locals 5

    .line 0
    const v0, -0x42c0e28b

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v4, p3, 0x1

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    if-eqz v4, :cond_3

    .line 10
    .line 11
    or-int/lit8 v0, p2, 0x6

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v1, v0, 0x3

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-static {v1, v3}, LX/003;->A1H(II)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-static {v1, p1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    if-eqz v4, :cond_0

    .line 27
    .line 28
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 29
    .line 30
    :cond_0
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 31
    .line 32
    invoke-static {p0, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0, p1, v2, v2}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 37
    .line 38
    .line 39
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    if-eqz v1, :cond_1

    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationDivider$1;

    .line 46
    .line 47
    invoke-direct {v0, p0, p2, p3}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationDivider$1;-><init>(LX/3C1;II)V

    .line 48
    .line 49
    .line 50
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 51
    .line 52
    :cond_1
    return-void

    .line 53
    :cond_2
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 58
    .line 59
    if-nez v0, :cond_4

    .line 60
    .line 61
    invoke-static {p1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    or-int/2addr v0, p2

    .line 66
    goto :goto_0

    .line 67
    :cond_4
    move v0, p2

    .line 68
    goto :goto_0
.end method

.method public static final CarRentalReservationHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    const v0, 0x32258512

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p2

    .line 6
    .line 7
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v6, p0

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    invoke-static {v6, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v12

    .line 26
    or-int v12, v12, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v9, p4

    .line 29
    .line 30
    and-int/lit8 v8, p4, 0x2

    .line 31
    .line 32
    if-eqz v8, :cond_2

    .line 33
    .line 34
    or-int/lit8 v12, v12, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v7, v12, 0x13

    .line 37
    .line 38
    const/16 v0, 0x12

    .line 39
    .line 40
    const/4 v2, 0x1

    .line 41
    const/4 v1, 0x0

    .line 42
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-static {v0, v4, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_4

    .line 51
    .line 52
    if-eqz v8, :cond_1

    .line 53
    .line 54
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    :cond_1
    const/16 v16, 0x0

    .line 57
    .line 58
    invoke-static {v5}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 59
    .line 60
    .line 61
    move-result-object v7

    .line 62
    invoke-static {v4}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 63
    .line 64
    .line 65
    move-result-object v14

    .line 66
    move-object v0, v4

    .line 67
    check-cast v0, LX/J7I;

    .line 68
    .line 69
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 70
    .line 71
    .line 72
    move-result v13

    .line 73
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 74
    .line 75
    .line 76
    move-result-object v11

    .line 77
    invoke-static {v4, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 78
    .line 79
    .line 80
    move-result-object v10

    .line 81
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 82
    .line 83
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 84
    .line 85
    if-nez v7, :cond_5

    .line 86
    .line 87
    invoke-static {}, LX/1VY;->A00()V

    .line 88
    .line 89
    .line 90
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    throw v0

    .line 95
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 96
    .line 97
    if-nez v0, :cond_0

    .line 98
    .line 99
    invoke-static {v4, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    or-int/2addr v12, v0

    .line 104
    goto :goto_1

    .line 105
    :cond_3
    move v12, v3

    .line 106
    goto :goto_0

    .line 107
    :cond_4
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 108
    .line 109
    .line 110
    goto :goto_2

    .line 111
    :cond_5
    invoke-static {v4, v0, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v4, v14, v11, v10, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 115
    .line 116
    .line 117
    sget-object v8, LX/CgK;->A00:LX/CgK;

    .line 118
    .line 119
    iget-object v7, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 120
    .line 121
    invoke-static {v7}, LX/3Rr;->A0k(Ljava/lang/String;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v13

    .line 125
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 126
    .line 127
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 128
    .line 129
    invoke-static {v7, v10}, LX/3Rr;->A09(LX/3C1;F)LX/3C1;

    .line 130
    .line 131
    .line 132
    move-result-object v11

    .line 133
    const/high16 v10, 0x41c00000    # 24.0f

    .line 134
    .line 135
    invoke-static {v11, v10}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 136
    .line 137
    .line 138
    move-result-object v10

    .line 139
    invoke-static {v13, v10, v4, v1, v1}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->CheckoutMerchantFavicon(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 140
    .line 141
    .line 142
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 143
    .line 144
    invoke-static {v4, v7, v10}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 145
    .line 146
    .line 147
    const v11, 0x7f12063a

    .line 148
    .line 149
    .line 150
    invoke-static {v4, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionAgentName(LX/2d4;I)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v10

    .line 154
    invoke-static {v4, v10, v11}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v17

    .line 158
    sget v19, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 159
    .line 160
    and-int/lit8 v10, v12, 0xe

    .line 161
    .line 162
    or-int v19, v19, v10

    .line 163
    .line 164
    const/16 v20, 0x2

    .line 165
    .line 166
    move-object/from16 v18, v4

    .line 167
    .line 168
    move-object v15, v6

    .line 169
    invoke-static/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionHeadline(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;Ljava/lang/String;LX/2d4;II)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v11

    .line 173
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 174
    .line 175
    invoke-static {v4, v10}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 176
    .line 177
    .line 178
    move-result-object v15

    .line 179
    invoke-static {v4, v10}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 180
    .line 181
    .line 182
    move-result-wide v13

    .line 183
    invoke-static {v8, v7, v2}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 184
    .line 185
    .line 186
    move-result-object v10

    .line 187
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v8

    .line 191
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 192
    .line 193
    if-ne v8, v7, :cond_6

    .line 194
    .line 195
    sget-object v8, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationHeader$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationHeader$1$1$1;

    .line 196
    .line 197
    invoke-interface {v4, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    :cond_6
    invoke-static {v10, v8, v1}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 201
    .line 202
    .line 203
    move-result-object v12

    .line 204
    const/16 p4, 0x3ff0

    .line 205
    .line 206
    move-object/from16 v17, v16

    .line 207
    .line 208
    move-object/from16 v18, v16

    .line 209
    .line 210
    move/from16 v20, v1

    .line 211
    .line 212
    move/from16 v21, v1

    .line 213
    .line 214
    move/from16 v22, v1

    .line 215
    .line 216
    move-object/from16 v23, v16

    .line 217
    .line 218
    move-object/from16 v24, v16

    .line 219
    .line 220
    move-object/from16 p0, v16

    .line 221
    .line 222
    move-object/from16 p1, v4

    .line 223
    .line 224
    move/from16 p2, v1

    .line 225
    .line 226
    move/from16 p3, v1

    .line 227
    .line 228
    move/from16 v19, v1

    .line 229
    .line 230
    invoke-static/range {v11 .. v29}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 231
    .line 232
    .line 233
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 234
    .line 235
    .line 236
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    if-eqz v1, :cond_7

    .line 241
    .line 242
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationHeader$2;

    .line 243
    .line 244
    invoke-direct {v0, v6, v5, v3, v9}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationHeader$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;II)V

    .line 245
    .line 246
    .line 247
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 248
    .line 249
    :cond_7
    return-void
.end method

.method public static final CarRentalReservationLegalFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;LX/2d4;II)V
    .locals 21

    .line 0
    move-object/from16 v15, p2

    .line 1
    .line 2
    const v0, -0x1649ab9f

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p3

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    const/4 v6, 0x4

    .line 15
    move-object/from16 v4, p0

    .line 16
    .line 17
    if-nez v0, :cond_4

    .line 18
    .line 19
    invoke-static {v4, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0}, LX/003;->A06(I)I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    or-int v5, v5, p4

    .line 28
    .line 29
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 30
    .line 31
    move-object/from16 v14, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static {v14, v3, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0}, LX/003;->A07(I)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v5, v0

    .line 44
    :cond_0
    move/from16 v20, p5

    .line 45
    .line 46
    and-int/lit8 v7, p5, 0x4

    .line 47
    .line 48
    if-eqz v7, :cond_3

    .line 49
    .line 50
    or-int/lit16 v5, v5, 0x180

    .line 51
    .line 52
    :cond_1
    :goto_1
    and-int/lit16 v1, v5, 0x93

    .line 53
    .line 54
    const/16 v0, 0x92

    .line 55
    .line 56
    const/16 v16, 0x0

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0, v3, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_8

    .line 67
    .line 68
    if-eqz v7, :cond_2

    .line 69
    .line 70
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 71
    .line 72
    :cond_2
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->legalLinks:Ljava/util/List;

    .line 73
    .line 74
    invoke-static {v0, v6}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 83
    .line 84
    .line 85
    move-result-object v8

    .line 86
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_5

    .line 91
    .line 92
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationLegalLink;

    .line 97
    .line 98
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationLegalLink;->title:Ljava/lang/String;

    .line 99
    .line 100
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationLegalLink;->url:Ljava/lang/String;

    .line 101
    .line 102
    new-instance v0, Lcom/facebook/aura/agentpermission/LegalLink;

    .line 103
    .line 104
    invoke-direct {v0, v7, v1}, Lcom/facebook/aura/agentpermission/LegalLink;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    goto :goto_2

    .line 111
    :cond_3
    and-int/lit16 v0, v2, 0x180

    .line 112
    .line 113
    if-nez v0, :cond_1

    .line 114
    .line 115
    invoke-static {v3, v15}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    or-int/2addr v5, v0

    .line 120
    goto :goto_1

    .line 121
    :cond_4
    move v5, v2

    .line 122
    goto :goto_0

    .line 123
    :cond_5
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    const/4 v12, 0x3

    .line 128
    const-string v9, "Muse"

    .line 129
    .line 130
    if-eqz v0, :cond_6

    .line 131
    .line 132
    const v0, 0x58ea80e0

    .line 133
    .line 134
    .line 135
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 136
    .line 137
    .line 138
    const v8, 0x7f120637

    .line 139
    .line 140
    .line 141
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->supplierName:Ljava/lang/String;

    .line 142
    .line 143
    filled-new-array {v9, v0}, [Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    :goto_3
    invoke-static {v3, v0, v8}, LX/18b;->A0A(LX/2d4;[Ljava/lang/Object;I)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    invoke-static {v3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    invoke-static {v3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->accent:J

    .line 159
    .line 160
    move-wide/from16 p2, v0

    .line 161
    .line 162
    move-object/from16 p4, v3

    .line 163
    .line 164
    move/from16 p5, v16

    .line 165
    .line 166
    move-object/from16 p1, v6

    .line 167
    .line 168
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->rememberCheckoutLegalText-XO-JAsU(Ljava/lang/String;Ljava/util/List;JLX/2d4;I)LX/2iK;

    .line 169
    .line 170
    .line 171
    move-result-object v13

    .line 172
    sget v0, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->$stable:I

    .line 173
    .line 174
    shl-int/2addr v0, v12

    .line 175
    invoke-static {v5, v0}, LX/002;->A0B(II)I

    .line 176
    .line 177
    .line 178
    move-result v18

    .line 179
    const/16 v19, 0x8

    .line 180
    .line 181
    move-object/from16 v17, v3

    .line 182
    .line 183
    invoke-static/range {v13 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutLegalFooter-xkNWiIY(LX/2iK;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;ILX/2d4;II)V

    .line 184
    .line 185
    .line 186
    goto :goto_5

    .line 187
    :cond_6
    const v0, 0x58ed1324

    .line 188
    .line 189
    .line 190
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 191
    .line 192
    .line 193
    const v8, 0x7f120636

    .line 194
    .line 195
    .line 196
    iget-object v7, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->supplierName:Ljava/lang/String;

    .line 197
    .line 198
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    invoke-static {v0}, Landroid/icu/text/ListFormatter;->getInstance(Ljava/util/Locale;)Landroid/icu/text/ListFormatter;

    .line 203
    .line 204
    .line 205
    move-result-object v10

    .line 206
    invoke-static {v6}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 211
    .line 212
    .line 213
    move-result-object v11

    .line 214
    :goto_4
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 215
    .line 216
    .line 217
    move-result v0

    .line 218
    if-eqz v0, :cond_7

    .line 219
    .line 220
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    check-cast v0, Lcom/facebook/aura/agentpermission/LegalLink;

    .line 225
    .line 226
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/LegalLink;->label:Ljava/lang/String;

    .line 227
    .line 228
    invoke-virtual {v1, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    goto :goto_4

    .line 232
    :cond_7
    invoke-virtual {v10, v1}, Landroid/icu/text/ListFormatter;->format(Ljava/util/Collection;)Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    filled-new-array {v9, v7, v0}, [Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    goto :goto_3

    .line 244
    :cond_8
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 245
    .line 246
    .line 247
    :goto_5
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 248
    .line 249
    .line 250
    move-result-object v1

    .line 251
    if-eqz v1, :cond_9

    .line 252
    .line 253
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationLegalFooter$1;

    .line 254
    .line 255
    move-object/from16 v16, v4

    .line 256
    .line 257
    move-object/from16 v17, v14

    .line 258
    .line 259
    move-object/from16 v18, v15

    .line 260
    .line 261
    move/from16 v19, v2

    .line 262
    .line 263
    move-object v15, v0

    .line 264
    invoke-direct/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationLegalFooter$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;II)V

    .line 265
    .line 266
    .line 267
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 268
    .line 269
    :cond_9
    return-void
.end method

.method public static final CarRentalReservationSection(LX/3C1;LX/JDN;LX/2d4;II)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    const v0, 0x5807fea8

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v2, p4, 0x1

    .line 7
    .line 8
    if-eqz v2, :cond_2

    .line 9
    .line 10
    or-int/lit8 v7, p3, 0x6

    .line 11
    .line 12
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {p2, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int/2addr v7, v0

    .line 21
    :cond_0
    and-int/lit8 v1, v7, 0x13

    .line 22
    .line 23
    const/16 v0, 0x12

    .line 24
    .line 25
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0, p2, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_5

    .line 34
    .line 35
    if-eqz v2, :cond_1

    .line 36
    .line 37
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 38
    .line 39
    :cond_1
    invoke-static {p0}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutSectionShape:LX/2bC;

    .line 44
    .line 45
    invoke-static {v1, v0}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-static {p2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 54
    .line 55
    invoke-static {v2, v0, v1}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-static {p2}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    move-object v5, p2

    .line 64
    check-cast v5, LX/J7I;

    .line 65
    .line 66
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    invoke-static {p2, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 79
    .line 80
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 81
    .line 82
    if-nez v0, :cond_4

    .line 83
    .line 84
    invoke-static {}, LX/1VY;->A00()V

    .line 85
    .line 86
    .line 87
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    throw v0

    .line 92
    :cond_2
    and-int/lit8 v0, p3, 0x6

    .line 93
    .line 94
    if-nez v0, :cond_3

    .line 95
    .line 96
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 97
    .line 98
    .line 99
    move-result v7

    .line 100
    or-int/2addr v7, p3

    .line 101
    goto :goto_0

    .line 102
    :cond_3
    move v7, p3

    .line 103
    goto :goto_0

    .line 104
    :cond_4
    invoke-static {p2, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 105
    .line 106
    .line 107
    invoke-static {p2, v6, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 108
    .line 109
    .line 110
    shr-int/lit8 v0, v7, 0x3

    .line 111
    .line 112
    invoke-static {v5, p2, p1, v0}, LX/005;->A0v(LX/J7I;Ljava/lang/Object;LX/JDN;I)V

    .line 113
    .line 114
    .line 115
    goto :goto_1

    .line 116
    :cond_5
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 117
    .line 118
    .line 119
    :goto_1
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    if-eqz v1, :cond_6

    .line 124
    .line 125
    new-instance v0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationSection$2;

    .line 126
    .line 127
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationSection$2;-><init>(LX/3C1;LX/JDN;II)V

    .line 128
    .line 129
    .line 130
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 131
    .line 132
    :cond_6
    return-void
.end method

.method public static final synthetic access$CarRentalReservationDetailRows(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDetailRows(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CarRentalReservationDivider(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDivider(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CarRentalReservationHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CarRentalReservationLegalFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationLegalFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CarRentalReservationSection(LX/3C1;LX/JDN;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationSection(LX/3C1;LX/JDN;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
