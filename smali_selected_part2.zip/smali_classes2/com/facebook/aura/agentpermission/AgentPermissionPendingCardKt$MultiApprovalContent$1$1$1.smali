.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approvals:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;->$approvals:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;->invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComponent;->OPEN_AGENT_PERMISSION_DECISION_SELECTOR_SHEET:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;->$approvals:Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v2, v1, p1, v0}, LX/3Rs;->A11(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V

    .line 15
    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 18
    .line 19
    iget-object v1, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;

    .line 22
    .line 23
    invoke-direct {v0, v1}, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-interface {v2, v0, v3}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
