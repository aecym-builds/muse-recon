.class public final Lcom/facebook/aura/agentpermission/ApprovalSetup;
.super LX/07H;
.source ""


# instance fields
.field public final loaded:Z

.field public final resolved:Z

.field public final setup:Lcom/facebook/aura/gateway/PaymentSetup;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/PaymentSetup;ZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/ApprovalSetup;Lcom/facebook/aura/gateway/PaymentSetup;ZZILjava/lang/Object;)Lcom/facebook/aura/agentpermission/ApprovalSetup;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 17
    .line 18
    :cond_2
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalSetup;

    .line 19
    .line 20
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/ApprovalSetup;-><init>(Lcom/facebook/aura/gateway/PaymentSetup;ZZ)V

    .line 21
    .line 22
    .line 23
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/gateway/PaymentSetup;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/gateway/PaymentSetup;ZZ)Lcom/facebook/aura/agentpermission/ApprovalSetup;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/ApprovalSetup;-><init>(Lcom/facebook/aura/gateway/PaymentSetup;ZZ)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/ApprovalSetup;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalSetup;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 27
    .line 28
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 29
    .line 30
    if-eq v1, v0, :cond_1

    .line 31
    .line 32
    :cond_0
    return v2

    .line 33
    :cond_1
    return v3
.end method

.method public final getLoaded()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getResolved()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSetup()Lcom/facebook/aura/gateway/PaymentSetup;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->setup:Lcom/facebook/aura/gateway/PaymentSetup;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->loaded:Z

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalSetup;->resolved:Z

    .line 15
    .line 16
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
