.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final approvalId:Ljava/lang/String;

.field public final gatewayPrefs:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

.field public invalidated:Z

.field public final ownerGatewayUrl:Ljava/lang/String;

.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final singleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation
.end field

.field public unavailableFromServer:Z

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Ljava/lang/String;)V
    .locals 10

    .line 0
    const/4 v6, 0x0

    .line 1
    invoke-static {p1, p2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->userSession:LX/AHE;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;->Companion:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore$Companion;

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->gatewayPrefs:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;->getGatewayUrl()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->ownerGatewayUrl:Ljava/lang/String;

    .line 30
    .line 31
    const/4 v2, 0x0

    .line 32
    sget-object v0, Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;->INSTANCE:Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;

    .line 33
    .line 34
    invoke-static {v0}, LX/3Rp;->A04(Lcom/facebook/aura/common/coroutines/OnDuplicateCall;)Lcom/facebook/aura/common/coroutines/LazyStartSingleFlightImpl;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->singleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 39
    .line 40
    const-string v3, ""

    .line 41
    .line 42
    sget-object v5, LX/0wV;->A00:LX/0wV;

    .line 43
    .line 44
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 45
    .line 46
    move-object v4, v3

    .line 47
    move v7, v6

    .line 48
    move v8, v6

    .line 49
    move v9, v6

    .line 50
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 51
    .line 52
    .line 53
    invoke-static {v1}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 58
    .line 59
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->uiState:LX/2J3;

    .line 64
    .line 65
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;

    .line 70
    .line 71
    invoke-direct {v0, p0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 72
    .line 73
    .line 74
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->reload()V

    .line 78
    .line 79
    .line 80
    return-void
.end method

.method public static final synthetic access$applyEditor(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/gateway/EditableMessageEditor;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->applyEditor(Lcom/facebook/aura/gateway/EditableMessageEditor;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$checkOwner(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Z
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->checkOwner()Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$getApprovalId$p(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getGatewayPrefs$p(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->gatewayPrefs:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSingleFlight$p(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Lcom/facebook/aura/common/coroutines/SingleFlight;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->singleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$handleLoadFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->handleLoadFailure(Ljava/lang/Throwable;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$handleSaveFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->handleSaveFailure(Ljava/lang/Throwable;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$saveDraft-gIAlu-s(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->saveDraft-gIAlu-s(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$updateAvailability(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final applyEditor(Lcom/facebook/aura/gateway/EditableMessageEditor;)V
    .locals 11

    .line 0
    move-object v3, p1

    .line 1
    iget-object v1, p1, Lcom/facebook/aura/gateway/EditableMessageEditor;->gatewayUrl:Ljava/lang/String;

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->ownerGatewayUrl:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 12
    .line 13
    invoke-interface {v1}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 18
    .line 19
    const/4 v7, 0x0

    .line 20
    iget-object v3, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 21
    .line 22
    iget-object v4, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v6, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 27
    .line 28
    iget-boolean v8, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 29
    .line 30
    iget-boolean v9, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 31
    .line 32
    iget-boolean v10, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 33
    .line 34
    invoke-virtual/range {v2 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :cond_0
    const/4 v7, 0x0

    .line 43
    iput-boolean v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->unavailableFromServer:Z

    .line 44
    .line 45
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 46
    .line 47
    invoke-virtual {p1}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    iget-object v0, p1, Lcom/facebook/aura/gateway/EditableMessageEditor;->message:Lcom/facebook/aura/gateway/EditableMessage;

    .line 54
    .line 55
    iget-object v4, v0, Lcom/facebook/aura/gateway/EditableMessage;->subject:Ljava/lang/String;

    .line 56
    .line 57
    :goto_0
    iget-object v0, p1, Lcom/facebook/aura/gateway/EditableMessageEditor;->message:Lcom/facebook/aura/gateway/EditableMessage;

    .line 58
    .line 59
    iget-object v5, v0, Lcom/facebook/aura/gateway/EditableMessage;->body:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v6, v0, Lcom/facebook/aura/gateway/EditableMessage;->attachments:Ljava/util/List;

    .line 62
    .line 63
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 64
    .line 65
    move v8, v7

    .line 66
    move v9, v7

    .line 67
    move v10, v7

    .line 68
    invoke-direct/range {v2 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 69
    .line 70
    .line 71
    invoke-interface {v1, v2}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_1
    const-string v4, ""

    .line 79
    .line 80
    goto :goto_0
.end method

.method private final checkOwner()Z
    .locals 10

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->invalidated:Z

    .line 1
    .line 2
    const/4 v6, 0x0

    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->userSession:LX/AHE;

    .line 8
    .line 9
    invoke-virtual {v1, v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v9, 0x1

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->ownerGatewayUrl:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->gatewayPrefs:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;->getGatewayUrl()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    return v9

    .line 31
    :cond_0
    iput-boolean v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->invalidated:Z

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    const-string v3, ""

    .line 37
    .line 38
    sget-object v5, LX/0wV;->A00:LX/0wV;

    .line 39
    .line 40
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 41
    .line 42
    move-object v4, v3

    .line 43
    move v7, v6

    .line 44
    move v8, v6

    .line 45
    invoke-direct/range {v1 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 46
    .line 47
    .line 48
    invoke-interface {v0, v1}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v2, v0}, LX/EPV;->A02(Ljava/util/concurrent/CancellationException;LX/1EL;)V

    .line 56
    .line 57
    .line 58
    :cond_1
    return v6
.end method

.method private final currentApproval()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    invoke-static {v0}, LX/3Rs;->A0g(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;)Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    move-object v0, v2

    .line 17
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 18
    .line 19
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    :goto_0
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 30
    .line 31
    return-object v2

    .line 32
    :cond_1
    const/4 v2, 0x0

    .line 33
    goto :goto_0
.end method

.method private final handleLoadFailure(Ljava/lang/Throwable;)V
    .locals 14

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/json/NetworkException;

    .line 1
    .line 2
    const/4 v4, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p1, Lcom/facebook/aura/json/NetworkException;

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    iget v0, p1, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    :cond_0
    const/16 v2, 0x199

    .line 16
    .line 17
    const/16 v1, 0x194

    .line 18
    .line 19
    if-eqz v4, :cond_2

    .line 20
    .line 21
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eq v0, v1, :cond_1

    .line 26
    .line 27
    if-ne v0, v2, :cond_2

    .line 28
    .line 29
    :cond_1
    const/4 v0, 0x1

    .line 30
    iput-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->unavailableFromServer:Z

    .line 31
    .line 32
    :cond_2
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 33
    .line 34
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    check-cast v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 39
    .line 40
    const/4 v10, 0x0

    .line 41
    iget-object v6, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 42
    .line 43
    iget-object v7, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v8, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v9, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 48
    .line 49
    iget-boolean v11, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 50
    .line 51
    iget-boolean v12, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 52
    .line 53
    iget-boolean v13, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 54
    .line 55
    invoke-virtual/range {v5 .. v13}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-interface {v3, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 63
    .line 64
    .line 65
    if-eqz v4, :cond_4

    .line 66
    .line 67
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eq v0, v1, :cond_3

    .line 72
    .line 73
    if-ne v0, v2, :cond_4

    .line 74
    .line 75
    :cond_3
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->refreshApprovals()V

    .line 76
    .line 77
    .line 78
    :cond_4
    return-void
.end method

.method private final handleSaveFailure(Ljava/lang/Throwable;)V
    .locals 13

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/json/NetworkException;

    .line 1
    .line 2
    const/4 v3, 0x0

    .line 3
    if-eqz v0, :cond_6

    .line 4
    .line 5
    check-cast p1, Lcom/facebook/aura/json/NetworkException;

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    iget v0, p1, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    :cond_0
    :goto_0
    const/16 v1, 0x194

    .line 16
    .line 17
    if-eqz v3, :cond_1

    .line 18
    .line 19
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ne v0, v1, :cond_1

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    iput-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->unavailableFromServer:Z

    .line 27
    .line 28
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 29
    .line 30
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 35
    .line 36
    const/4 v10, 0x0

    .line 37
    iget-object v5, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 38
    .line 39
    iget-object v6, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 40
    .line 41
    iget-object v7, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 42
    .line 43
    iget-object v8, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 44
    .line 45
    iget-boolean v9, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 46
    .line 47
    iget-boolean v11, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 48
    .line 49
    iget-boolean v12, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 50
    .line 51
    invoke-virtual/range {v4 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-interface {v2, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 59
    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 62
    .line 63
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 68
    .line 69
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 70
    .line 71
    if-nez v0, :cond_2

    .line 72
    .line 73
    if-eqz v3, :cond_5

    .line 74
    .line 75
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    const/16 v0, 0x190

    .line 80
    .line 81
    if-ne v2, v0, :cond_5

    .line 82
    .line 83
    iget-object v2, p1, Lcom/facebook/aura/json/NetworkException;->errorCode:Ljava/lang/String;

    .line 84
    .line 85
    const/4 v0, 0x2

    .line 86
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_5

    .line 95
    .line 96
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->INVALID_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 97
    .line 98
    :goto_1
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->showErrorToast(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;)V

    .line 99
    .line 100
    .line 101
    :cond_2
    if-eqz v3, :cond_4

    .line 102
    .line 103
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 104
    .line 105
    .line 106
    move-result v2

    .line 107
    if-eq v2, v1, :cond_3

    .line 108
    .line 109
    const/16 v0, 0x199

    .line 110
    .line 111
    if-ne v2, v0, :cond_4

    .line 112
    .line 113
    :cond_3
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->refreshApprovals()V

    .line 114
    .line 115
    .line 116
    :cond_4
    return-void

    .line 117
    :cond_5
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->SAVE_FAILED:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_6
    move-object p1, v3

    .line 121
    goto :goto_0
.end method

.method private final refreshApprovals()V
    .locals 3

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const/4 v1, 0x0

    .line 5
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$refreshApprovals$1;

    .line 6
    .line 7
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$refreshApprovals$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private final saveDraft-gIAlu-s(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)Ljava/lang/Object;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    move-object/from16 v8, p1

    .line 3
    .line 4
    instance-of v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;

    .line 5
    .line 6
    move-object/from16 v9, p0

    .line 7
    .line 8
    if-eqz v0, :cond_a

    .line 9
    .line 10
    move-object v5, v3

    .line 11
    check-cast v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;

    .line 12
    .line 13
    iget v2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v2, v1

    .line 18
    .line 19
    if-eqz v0, :cond_a

    .line 20
    .line 21
    sub-int/2addr v2, v1

    .line 22
    iput v2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->label:I

    .line 29
    .line 30
    const/4 v3, 0x2

    .line 31
    const/4 v2, 0x1

    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    if-eq v0, v2, :cond_2

    .line 35
    .line 36
    if-ne v0, v3, :cond_b

    .line 37
    .line 38
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    :cond_0
    return-object v0

    .line 43
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iget-object v1, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 47
    .line 48
    iget-object v0, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 49
    .line 50
    iput-object v8, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->L$0:Ljava/lang/Object;

    .line 51
    .line 52
    iput v2, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->label:I

    .line 53
    .line 54
    invoke-virtual {v1, v0, v5}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->fetchEditableMessage-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    if-ne v6, v4, :cond_3

    .line 59
    .line 60
    return-object v4

    .line 61
    :cond_2
    iget-object v8, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->L$0:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v8, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 64
    .line 65
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    :cond_3
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    check-cast v6, Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 73
    .line 74
    invoke-static {v5}, LX/3Rp;->A1O(LX/Btl;)V

    .line 75
    .line 76
    .line 77
    invoke-direct {v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->checkOwner()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_4

    .line 82
    .line 83
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 84
    .line 85
    invoke-direct {v0}, Ljava/util/concurrent/CancellationException;-><init>()V

    .line 86
    .line 87
    .line 88
    invoke-static {v0}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    return-object v0

    .line 93
    :cond_4
    iget-object v1, v6, Lcom/facebook/aura/gateway/EditableMessageEditor;->gatewayUrl:Ljava/lang/String;

    .line 94
    .line 95
    iget-object v0, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->ownerGatewayUrl:Ljava/lang/String;

    .line 96
    .line 97
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_c

    .line 102
    .line 103
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 104
    .line 105
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_5

    .line 118
    .line 119
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    check-cast v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;

    .line 124
    .line 125
    iget-object v0, v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;->id:Ljava/lang/String;

    .line 126
    .line 127
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_5
    invoke-static {v2}, LX/B89;->A0t(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 132
    .line 133
    .line 134
    move-result-object v7

    .line 135
    iget-object v10, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 136
    .line 137
    iget-object v11, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 138
    .line 139
    invoke-virtual {v6}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-eqz v0, :cond_6

    .line 144
    .line 145
    iget-object v12, v8, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 146
    .line 147
    :goto_2
    iget-object v13, v8, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 148
    .line 149
    iget-object v0, v6, Lcom/facebook/aura/gateway/EditableMessageEditor;->message:Lcom/facebook/aura/gateway/EditableMessage;

    .line 150
    .line 151
    iget-object v0, v0, Lcom/facebook/aura/gateway/EditableMessage;->attachments:Ljava/util/List;

    .line 152
    .line 153
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    if-eqz v0, :cond_7

    .line 166
    .line 167
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    check-cast v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;

    .line 172
    .line 173
    iget-object v0, v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;->id:Ljava/lang/String;

    .line 174
    .line 175
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    goto :goto_3

    .line 179
    :cond_6
    const-string v12, ""

    .line 180
    .line 181
    goto :goto_2

    .line 182
    :cond_7
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 183
    .line 184
    .line 185
    move-result-object v14

    .line 186
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 187
    .line 188
    .line 189
    move-result-object v2

    .line 190
    :cond_8
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 191
    .line 192
    .line 193
    move-result v0

    .line 194
    if-eqz v0, :cond_9

    .line 195
    .line 196
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-interface {v7, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result v0

    .line 204
    if-eqz v0, :cond_8

    .line 205
    .line 206
    invoke-virtual {v14, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    goto :goto_4

    .line 210
    :cond_9
    iget-wide v15, v6, Lcom/facebook/aura/gateway/EditableMessageEditor;->messageRevision:J

    .line 211
    .line 212
    iget-object v1, v6, Lcom/facebook/aura/gateway/EditableMessageEditor;->gatewayUrl:Ljava/lang/String;

    .line 213
    .line 214
    const/4 v0, 0x0

    .line 215
    iput-object v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->L$0:Ljava/lang/Object;

    .line 216
    .line 217
    iput-object v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->L$1:Ljava/lang/Object;

    .line 218
    .line 219
    iput-object v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->L$2:Ljava/lang/Object;

    .line 220
    .line 221
    iput v3, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;->label:I

    .line 222
    .line 223
    move-object/from16 p1, v1

    .line 224
    .line 225
    move-object/from16 p2, v5

    .line 226
    .line 227
    invoke-virtual/range {v10 .. v18}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->saveEditableMessage-bMdYcbs(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    if-ne v0, v4, :cond_0

    .line 232
    .line 233
    return-object v4

    .line 234
    :cond_a
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;

    .line 235
    .line 236
    invoke-direct {v5, v9, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$saveDraft$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 237
    .line 238
    .line 239
    goto/16 :goto_0

    .line 240
    .line 241
    :cond_b
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    throw v0

    .line 246
    :cond_c
    const-string v0, "Approval editor gateway mismatch"

    .line 247
    .line 248
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    throw v0
.end method

.method private final showErrorToast(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;)V
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eq p1, p0, :cond_3

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    if-eq p1, p0, :cond_2

    .line 9
    .line 10
    const/4 p0, 0x2

    .line 11
    if-eq p1, p0, :cond_1

    .line 12
    .line 13
    const/4 p0, 0x3

    .line 14
    if-eq p1, p0, :cond_0

    .line 15
    .line 16
    const/4 p0, 0x4

    .line 17
    if-ne p1, p0, :cond_4

    .line 18
    .line 19
    const p1, 0x7f120112

    .line 20
    .line 21
    .line 22
    :goto_0
    sget-object p0, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 23
    .line 24
    invoke-virtual {p0, p1}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    const p1, 0x7f120110

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    const p1, 0x7f120119

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_2
    const p1, 0x7f120114

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_3
    const p1, 0x7f120116

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_4
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    throw p0
.end method

.method private final updateAvailability()V
    .locals 12

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->checkOwner()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->currentApproval()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 11
    .line 12
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    check-cast v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 19
    .line 20
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->unavailableFromServer:Z

    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    iget-boolean v0, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->editableMessageAvailable:Z

    .line 28
    .line 29
    if-ne v0, v1, :cond_0

    .line 30
    .line 31
    iget-object v0, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 32
    .line 33
    if-eqz v0, :cond_3

    .line 34
    .line 35
    iget-object v1, v0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 36
    .line 37
    :goto_0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->PENDING:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    if-eq v1, v0, :cond_1

    .line 41
    .line 42
    :cond_0
    const/4 p0, 0x1

    .line 43
    :cond_1
    iget-object v5, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 44
    .line 45
    iget-object v6, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v7, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 48
    .line 49
    iget-object v8, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 50
    .line 51
    iget-boolean v9, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 52
    .line 53
    iget-boolean v10, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 54
    .line 55
    iget-boolean v11, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 56
    .line 57
    invoke-virtual/range {v4 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-interface {v2, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    :cond_2
    return-void

    .line 65
    :cond_3
    const/4 v1, 0x0

    .line 66
    goto :goto_0
.end method

.method private final updateDraft(LX/JDM;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 4
    .line 5
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    check-cast v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 10
    .line 11
    invoke-virtual {v2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->getCanSave()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 18
    .line 19
    invoke-interface {p1, v2}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onCancelTapped()V
    .locals 6

    .line 0
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CANCEL_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 5
    .line 6
    invoke-static {v0}, LX/3Rs;->A0g(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;)Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    move-object v0, v2

    .line 21
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 22
    .line 23
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    :goto_0
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 34
    .line 35
    invoke-static {v5, v4, v2}, LX/3Rs;->A10(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    const/4 v2, 0x0

    .line 40
    goto :goto_0
.end method

.method public final reload()V
    .locals 12

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->checkOwner()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 7
    .line 8
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    check-cast v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 13
    .line 14
    iget-boolean v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-boolean v9, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 19
    .line 20
    if-nez v9, :cond_0

    .line 21
    .line 22
    iget-boolean v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 23
    .line 24
    if-nez v10, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 27
    .line 28
    const/4 v2, 0x0

    .line 29
    const/4 v8, 0x1

    .line 30
    iget-object v4, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 31
    .line 32
    iget-object v5, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 33
    .line 34
    iget-object v6, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v7, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 37
    .line 38
    iget-boolean v11, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 39
    .line 40
    invoke-virtual/range {v3 .. v11}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;

    .line 52
    .line 53
    invoke-direct {v0, p0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 54
    .line 55
    .line 56
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 57
    .line 58
    .line 59
    :cond_0
    return-void
.end method

.method public final removeAttachment(Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComponent;->ATTACHMENT_DISMISS_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    invoke-direct {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->currentApproval()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v2, v1, v0}, LX/3Rs;->A10(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;

    .line 16
    .line 17
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateDraft(LX/JDM;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final save()V
    .locals 16

    .line 0
    sget-object v10, Lcom/facebook/aura/analytics/hatch/HatchComponent;->EMAIL_SAVE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v11, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    move-object/from16 v1, p0

    .line 5
    .line 6
    invoke-direct {v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->currentApproval()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    .line 9
    move-result-object v12

    .line 10
    const/4 v13, 0x0

    .line 11
    const/4 v9, 0x1

    .line 12
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    move-object v14, v13

    .line 17
    move v15, v9

    .line 18
    invoke-static/range {v10 .. v16}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateAvailability()V

    .line 22
    .line 23
    .line 24
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 25
    .line 26
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    check-cast v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 31
    .line 32
    invoke-virtual {v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->getCanSave()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->validationError$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission()Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    invoke-direct {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->showErrorToast(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    return-void

    .line 48
    :cond_1
    iget-object v2, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 49
    .line 50
    iget-object v4, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 51
    .line 52
    iget-object v5, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v6, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 55
    .line 56
    iget-object v7, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 57
    .line 58
    iget-boolean v8, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 59
    .line 60
    iget-boolean v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 61
    .line 62
    iget-boolean v11, v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 63
    .line 64
    invoke-virtual/range {v3 .. v11}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-interface {v2, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    invoke-static {v1}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;

    .line 76
    .line 77
    invoke-direct {v0, v1, v3, v13}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V

    .line 78
    .line 79
    .line 80
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public final updateBody(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateBody$1;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateBody$1;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateDraft(LX/JDM;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final updateSubject(Ljava/lang/String;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, 0x1

    .line 21
    if-ne v1, v0, :cond_0

    .line 22
    .line 23
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;

    .line 24
    .line 25
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->updateDraft(LX/JDM;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void
.end method
