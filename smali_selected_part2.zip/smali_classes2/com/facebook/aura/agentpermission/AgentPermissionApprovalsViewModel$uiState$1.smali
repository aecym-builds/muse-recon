.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDR;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDR<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;",
        "Lcom/facebook/aura/agentpermission/ApprovalHistoryState;",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalsViewModel$uiState$1"
    f = "AgentPermissionApprovalsViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic L$1:Ljava/lang/Object;

.field public synthetic L$2:Ljava/lang/Object;

.field public synthetic L$3:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x5

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/util/List;

    .line 268435457
    .line 268435458
    check-cast p2, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 268435459
    .line 268435460
    check-cast p3, Ljava/util/Set;

    .line 268435461
    .line 268435462
    check-cast p4, Ljava/util/Set;

    .line 268435463
    .line 268435464
    check-cast p5, LX/2M4;

    .line 268435465
    .line 268435466
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->invoke(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryState;Ljava/util/Set;Ljava/util/Set;LX/2M4;)Ljava/lang/Object;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object p0

    .line 268435470
    return-object p0
.end method

.method public final invoke(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryState;Ljava/util/Set;Ljava/util/Set;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryState;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;

    .line 1
    .line 2
    invoke-direct {p0, p5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$1:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$2:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$3:Ljava/lang/Object;

    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Ljava/lang/Iterable;

    .line 5
    .line 6
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$1:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 9
    .line 10
    iget-object v4, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$2:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v4, Ljava/util/Set;

    .line 13
    .line 14
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->L$3:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v3, Ljava/util/Set;

    .line 17
    .line 18
    iget v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1;->label:I

    .line 19
    .line 20
    if-nez v0, :cond_2

    .line 21
    .line 22
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$invokeSuspend$$inlined$sortedByDescending$1;

    .line 26
    .line 27
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$invokeSuspend$$inlined$sortedByDescending$1;-><init>()V

    .line 28
    .line 29
    .line 30
    invoke-static {v1, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object v8

    .line 34
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 35
    .line 36
    .line 37
    move-result-object v7

    .line 38
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_0

    .line 47
    .line 48
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 53
    .line 54
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 61
    .line 62
    invoke-static {v0}, LX/B89;->A0J(Ljava/lang/Iterable;)LX/BhL;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$1;

    .line 67
    .line 68
    invoke-direct {v2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$1;-><init>(Ljava/util/Set;)V

    .line 69
    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    new-instance v1, LX/0Xg;

    .line 73
    .line 74
    invoke-direct {v1, v2, v6, v0}, LX/0Xg;-><init>(LX/JDM;LX/0Xf;Z)V

    .line 75
    .line 76
    .line 77
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$2;

    .line 78
    .line 79
    invoke-static {v0, v1}, LX/B84;->A05(LX/JDM;LX/0Xf;)LX/0Xg;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    sget-object v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$3;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$uiState$1$actionedHistory$3;

    .line 84
    .line 85
    const/4 v0, 0x1

    .line 86
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 87
    .line 88
    .line 89
    new-instance v0, LX/9zG;

    .line 90
    .line 91
    invoke-direct {v0, v1, v2}, LX/9zG;-><init>(LX/JDM;LX/0Xf;)V

    .line 92
    .line 93
    .line 94
    invoke-static {v0}, LX/B84;->A04(LX/0Xf;)Ljava/util/List;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    invoke-static {v8}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 103
    .line 104
    .line 105
    move-result-object v10

    .line 106
    iget-object v11, v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 107
    .line 108
    iget-boolean v12, v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 109
    .line 110
    iget-boolean v13, v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 111
    .line 112
    iget-object v14, v5, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v3, v4}, LX/163;->A00(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 115
    .line 116
    .line 117
    move-result-object v15

    .line 118
    invoke-static {v4, v3}, LX/163;->A02(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/Set;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    invoke-static {v8}, LX/0BR;->A00(Ljava/lang/Iterable;)I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 127
    .line 128
    invoke-direct {v4, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 129
    .line 130
    .line 131
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    if-eqz v0, :cond_1

    .line 140
    .line 141
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 146
    .line 147
    iget-object v3, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 148
    .line 149
    invoke-static {v0}, Lcom/facebook/aura/gateway/ApprovalCardOnlyKt;->approvesOnCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModelKt;->rowDecisionOptions(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/util/List;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 162
    .line 163
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;-><init>(ZLX/Ddn;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v4, v3, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    goto :goto_1

    .line 170
    :cond_1
    invoke-static {v4}, LX/Dwp;->A06(Ljava/util/Map;)LX/IZf;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 175
    .line 176
    invoke-direct/range {v8 .. v17}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)V

    .line 177
    .line 178
    .line 179
    return-object v8

    .line 180
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    throw v0
.end method
