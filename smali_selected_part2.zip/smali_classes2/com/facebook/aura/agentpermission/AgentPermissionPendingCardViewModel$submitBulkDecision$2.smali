.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionPendingCardViewModel$submitBulkDecision$2"
    f = "AgentPermissionPendingCardViewModel.kt"
    l = {
        0x96
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $approvalIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $decisions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApprovalDecision;",
            ">;"
        }
    .end annotation
.end field

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;Ljava/util/List;Ljava/util/Set;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApprovalDecision;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$decisions:Ljava/util/List;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$approvalIds:Ljava/util/Set;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$decisions:Ljava/util/List;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$approvalIds:Ljava/util/Set;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;Ljava/util/List;Ljava/util/Set;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_5

    .line 6
    .line 7
    if-ne v0, v2, :cond_7

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult;

    .line 13
    .line 14
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$Success;

    .line 15
    .line 16
    if-nez v0, :cond_2

    .line 17
    .line 18
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$Failed;

    .line 19
    .line 20
    if-nez v0, :cond_3

    .line 21
    .line 22
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$Confirming;

    .line 23
    .line 24
    if-nez v0, :cond_3

    .line 25
    .line 26
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$PartiallyApplied;

    .line 27
    .line 28
    if-eqz v0, :cond_6

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 31
    .line 32
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->_submittingApprovalIds:LX/2J2;

    .line 33
    .line 34
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    move-object v1, v2

    .line 39
    check-cast v1, Ljava/util/Set;

    .line 40
    .line 41
    move-object v0, p1

    .line 42
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$PartiallyApplied;

    .line 43
    .line 44
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$PartiallyApplied;->unappliedApprovalIds:Ljava/util/Set;

    .line 45
    .line 46
    invoke-static {v0, v1}, LX/163;->A02(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/Set;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_1

    .line 55
    .line 56
    :cond_2
    :goto_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 57
    .line 58
    return-object v3

    .line 59
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 60
    .line 61
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->_submittingApprovalIds:LX/2J2;

    .line 62
    .line 63
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$approvalIds:Ljava/util/Set;

    .line 64
    .line 65
    :cond_4
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    move-object v0, v1

    .line 70
    check-cast v0, Ljava/util/Set;

    .line 71
    .line 72
    invoke-static {v2, v0}, LX/163;->A02(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/Set;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-interface {v3, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-eqz v0, :cond_4

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 87
    .line 88
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 89
    .line 90
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->$decisions:Ljava/util/List;

    .line 91
    .line 92
    iput v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitBulkDecision$2;->label:I

    .line 93
    .line 94
    invoke-virtual {v1, v0, v2, p0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->decideApprovals(Ljava/util/List;ZLX/2M4;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    if-ne p1, v3, :cond_0

    .line 99
    .line 100
    return-object v3

    .line 101
    :cond_6
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    throw v0

    .line 106
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0
.end method
