.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$Companion;


# instance fields
.field public volatile job:LX/Cbu;

.field public knownApprovalIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final scope:LX/1EL;

.field public serverSnapshotLoaded:Z

.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->Companion:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->default()LX/BqD;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, LX/3Rq;->A1I(LX/BqD;)LX/EQC;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->scope:LX/1EL;

    .line 16
    .line 17
    sget-object v0, LX/0wX;->A00:LX/0wX;

    .line 18
    .line 19
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->knownApprovalIds:Ljava/util/Set;

    .line 20
    .line 21
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;-><init>(LX/AHE;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public static final synthetic access$browserTaskSiteDomain(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->browserTaskSiteDomain(Ljava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$reconcileSystemNotifications(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;JLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->reconcileSystemNotifications(Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;JLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final browserTaskSiteDomain(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 0
    sget-object v1, Lcom/facebook/aura/browsertask/api/BrowserTasks;->INSTANCE:Lcom/facebook/aura/browsertask/api/BrowserTasks;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/browsertask/api/BrowserTasks;->source(LX/AHE;)Lcom/facebook/aura/browsertask/api/BrowserTaskSource;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-interface {p0}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getActiveTasks()LX/2J3;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/lang/Iterable;

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    const/4 v2, 0x0

    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    move-object v0, v1

    .line 34
    check-cast v0, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 35
    .line 36
    iget-object v0, v0, Lcom/facebook/aura/model/BrowserTaskPresentation;->browserTaskId:Ljava/lang/String;

    .line 37
    .line 38
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    :goto_0
    check-cast v1, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 45
    .line 46
    if-nez v1, :cond_1

    .line 47
    .line 48
    invoke-interface {p0}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getPresentedTask()LX/2J3;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    check-cast v1, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 57
    .line 58
    if-eqz v1, :cond_2

    .line 59
    .line 60
    iget-object v0, v1, Lcom/facebook/aura/model/BrowserTaskPresentation;->browserTaskId:Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_2

    .line 67
    .line 68
    :cond_1
    iget-object v2, v1, Lcom/facebook/aura/model/BrowserTaskPresentation;->siteDomain:Ljava/lang/String;

    .line 69
    .line 70
    :cond_2
    return-object v2

    .line 71
    :cond_3
    move-object v1, v2

    .line 72
    goto :goto_0
.end method

.method private final reconcileSystemNotifications(Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;JLX/2M4;)Ljava/lang/Object;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;Z",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/model/AiIdentity;",
            "J",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move v7, p2

    .line 1
    move-wide/from16 v0, p6

    .line 2
    .line 3
    move-object/from16 v9, p8

    .line 4
    .line 5
    move-object/from16 v4, p4

    .line 6
    .line 7
    instance-of v2, v9, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;

    .line 8
    .line 9
    move-object v8, p0

    .line 10
    if-eqz v2, :cond_8

    .line 11
    .line 12
    move-object v6, v9

    .line 13
    check-cast v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;

    .line 14
    .line 15
    iget v5, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 16
    .line 17
    const/high16 v3, -0x80000000

    .line 18
    .line 19
    and-int v2, v5, v3

    .line 20
    .line 21
    if-eqz v2, :cond_8

    .line 22
    .line 23
    sub-int/2addr v5, v3

    .line 24
    iput v5, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v10, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v3, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 31
    .line 32
    const/4 v2, 0x1

    .line 33
    if-eqz v3, :cond_1

    .line 34
    .line 35
    if-ne v3, v2, :cond_9

    .line 36
    .line 37
    iget-wide v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->J$0:J

    .line 38
    .line 39
    iget-boolean v7, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->Z$0:Z

    .line 40
    .line 41
    iget-object v9, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$9:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v9, Ljava/util/Iterator;

    .line 44
    .line 45
    iget-object v3, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$7:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v3, Ljava/lang/String;

    .line 48
    .line 49
    iget-object p2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$4:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p2, Landroid/content/Context;

    .line 52
    .line 53
    iget-object v4, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$2:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v4, Ljava/lang/String;

    .line 56
    .line 57
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_0
    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_a

    .line 65
    .line 66
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p3

    .line 70
    check-cast p3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 71
    .line 72
    sget-object p1, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;

    .line 73
    .line 74
    invoke-direct {v8, p3, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->sideChatId(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p5

    .line 78
    new-instance v10, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$2$1;

    .line 79
    .line 80
    invoke-direct {v10, v8}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$2$1;-><init>(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    const/4 v2, 0x0

    .line 84
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$0:Ljava/lang/Object;

    .line 85
    .line 86
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$1:Ljava/lang/Object;

    .line 87
    .line 88
    iput-object v4, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$2:Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$3:Ljava/lang/Object;

    .line 91
    .line 92
    iput-object p2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$4:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$5:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$6:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object v3, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$7:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$8:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v9, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$9:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$10:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->L$11:Ljava/lang/Object;

    .line 107
    .line 108
    iput-boolean v7, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->Z$0:Z

    .line 109
    .line 110
    iput-wide v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->J$0:J

    .line 111
    .line 112
    const/4 v2, 0x1

    .line 113
    iput v2, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 114
    .line 115
    move-object/from16 p6, v10

    .line 116
    .line 117
    move-object/from16 p7, v6

    .line 118
    .line 119
    move-object/from16 p4, v3

    .line 120
    .line 121
    invoke-virtual/range {p1 .. p7}, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->post(Landroid/content/Context;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;Ljava/lang/String;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    if-ne v2, v5, :cond_0

    .line 126
    .line 127
    return-object v5

    .line 128
    :cond_1
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    sget-object v2, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 132
    .line 133
    invoke-virtual {v2}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 134
    .line 135
    .line 136
    move-result-object p2

    .line 137
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 138
    .line 139
    .line 140
    move-result-object v11

    .line 141
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    if-eqz v2, :cond_2

    .line 150
    .line 151
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 156
    .line 157
    iget-object v2, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 158
    .line 159
    invoke-virtual {v11, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    goto :goto_2

    .line 163
    :cond_2
    if-eqz v7, :cond_3

    .line 164
    .line 165
    iget-boolean v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->serverSnapshotLoaded:Z

    .line 166
    .line 167
    if-nez v2, :cond_3

    .line 168
    .line 169
    sget-object v2, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;

    .line 170
    .line 171
    invoke-virtual {v2, p2, v11, v0, v1}, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->cancelStale(Landroid/content/Context;Ljava/util/Set;J)V

    .line 172
    .line 173
    .line 174
    :cond_3
    sget-object v3, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;

    .line 175
    .line 176
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->knownApprovalIds:Ljava/util/Set;

    .line 177
    .line 178
    invoke-static {v11, v2}, LX/163;->A02(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/Set;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    invoke-virtual {v3, p2, v2}, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->cancel(Landroid/content/Context;Ljava/util/Collection;)V

    .line 183
    .line 184
    .line 185
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 186
    .line 187
    .line 188
    move-result-object v9

    .line 189
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    :cond_4
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 194
    .line 195
    .line 196
    move-result v2

    .line 197
    if-eqz v2, :cond_6

    .line 198
    .line 199
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v10

    .line 203
    move-object p0, v10

    .line 204
    check-cast p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 205
    .line 206
    iget-object v3, v8, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->knownApprovalIds:Ljava/util/Set;

    .line 207
    .line 208
    iget-object v2, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 209
    .line 210
    invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    if-nez v2, :cond_4

    .line 215
    .line 216
    iget-boolean v2, v8, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->serverSnapshotLoaded:Z

    .line 217
    .line 218
    if-nez v2, :cond_5

    .line 219
    .line 220
    iget-object v3, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 221
    .line 222
    sget-object v2, Lcom/facebook/aura/gateway/ApprovalOrigin;->LOCAL_HITL:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 223
    .line 224
    if-ne v3, v2, :cond_4

    .line 225
    .line 226
    :cond_5
    invoke-virtual {v9, v10}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    goto :goto_3

    .line 230
    :cond_6
    iput-object v11, v8, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->knownApprovalIds:Ljava/util/Set;

    .line 231
    .line 232
    iput-boolean v7, v8, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->serverSnapshotLoaded:Z

    .line 233
    .line 234
    sget-object v2, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->NOTIFICATION:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 235
    .line 236
    if-ne p3, v2, :cond_a

    .line 237
    .line 238
    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    .line 239
    .line 240
    .line 241
    move-result v2

    .line 242
    if-nez v2, :cond_a

    .line 243
    .line 244
    invoke-static/range {p5 .. p5}, Lcom/facebook/aura/model/HatchGatewayEventKt;->getTrimmedName(Lcom/facebook/aura/model/AiIdentity;)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v3

    .line 248
    if-nez v3, :cond_7

    .line 249
    .line 250
    const v2, 0x7f1200a9

    .line 251
    .line 252
    .line 253
    invoke-virtual {p2, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object v3

    .line 257
    :cond_7
    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 258
    .line 259
    .line 260
    move-result-object v9

    .line 261
    goto/16 :goto_1

    .line 262
    .line 263
    :cond_8
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;

    .line 264
    .line 265
    invoke-direct {v6, p0, v9}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;LX/2M4;)V

    .line 266
    .line 267
    .line 268
    goto/16 :goto_0

    .line 269
    .line 270
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    throw v0

    .line 275
    :cond_a
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 276
    .line 277
    return-object v5
.end method

.method private final sideChatId(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 1
    .line 2
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->threadId:Ljava/lang/String;

    .line 3
    .line 4
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->resolveThreadId(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 p0, 0x0

    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    return-object p1

    .line 18
    :cond_0
    return-object p0
.end method


# virtual methods
.method public clearUserData()V
    .locals 6

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->job:LX/Cbu;

    .line 1
    .line 2
    const/4 v5, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    iput-object v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->job:LX/Cbu;

    .line 9
    .line 10
    sget-object v4, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    sget-object v2, LX/0wX;->A00:LX/0wX;

    .line 19
    .line 20
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-virtual {v4, v3, v2, v0, v1}, Lcom/facebook/aura/agentpermission/AgentApprovalNotifier;->cancelStale(Landroid/content/Context;Ljava/util/Set;J)V

    .line 26
    .line 27
    .line 28
    sget-object v0, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->INSTANCE:Lcom/facebook/aura/notifications/attention/AttentionNotifications;

    .line 29
    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->forgetApprovalAlerts()V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->scope:LX/1EL;

    .line 34
    .line 35
    invoke-static {v5, v0}, LX/EPV;->A02(Ljava/util/concurrent/CancellationException;LX/1EL;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final start()V
    .locals 9

    .line 0
    move-object v6, p0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->job:LX/Cbu;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v0, 0x1

    .line 10
    if-ne v1, v0, :cond_0

    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 14
    .line 15
    .line 16
    move-result-wide v7

    .line 17
    sget-object v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->Companion:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$Companion;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    sget-object v3, Lcom/facebook/aura/gateway/api/GatewayCommandServiceState;->isForegroundFlow:LX/2J3;

    .line 26
    .line 27
    sget-object v2, Lcom/facebook/aura/gateway/api/GatewayForegroundServiceState;->isForeground:LX/2J3;

    .line 28
    .line 29
    sget-object v1, Lcom/facebook/aura/gateway/HatchBackgroundSession;->isActiveFlow:LX/2J3;

    .line 30
    .line 31
    const/4 p0, 0x0

    .line 32
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$keptAlive$1;

    .line 33
    .line 34
    invoke-direct {v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$keptAlive$1;-><init>(LX/2M4;)V

    .line 35
    .line 36
    .line 37
    invoke-static {v0, v3, v2, v1}, LX/EXj;->A00(LX/JDO;LX/2Lw;LX/2Lw;LX/2Lw;)LX/5zp;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    sget-object v1, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->isAppInForegroundImmediateFlow:LX/2Lw;

    .line 42
    .line 43
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;

    .line 44
    .line 45
    invoke-direct {v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;-><init>(LX/2M4;)V

    .line 46
    .line 47
    .line 48
    invoke-static {v0, v1, v2}, LX/EXj;->A03(LX/JDQ;LX/2Lw;LX/2Lw;)LX/EUU;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->scope:LX/1EL;

    .line 53
    .line 54
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;

    .line 55
    .line 56
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;LX/2Lw;Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;JLX/2M4;)V

    .line 57
    .line 58
    .line 59
    invoke-static {v3, v0}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iput-object v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->job:LX/Cbu;

    .line 64
    .line 65
    return-void
.end method
