.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$changed1:I

.field public final synthetic $enabled:Z

.field public final synthetic $menuExpanded:Z

.field public final synthetic $mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

.field public final synthetic $modeLabel:Ljava/lang/String;

.field public final synthetic $modeOptions:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDismissMenu:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onModeSelected:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRevoke:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $permissionTitle:Ljava/lang/String;

.field public final synthetic $revocable:Z

.field public final synthetic $showSpinner:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;ZZZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$permissionTitle:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$modeLabel:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$modeOptions:LX/Ddn;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$revocable:Z

    .line 9
    .line 10
    iput-boolean p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$enabled:Z

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$showSpinner:Z

    .line 13
    .line 14
    iput-boolean p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$menuExpanded:Z

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onClick:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    iput-object p11, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onModeSelected:LX/JDM;

    .line 21
    .line 22
    iput-object p12, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onRevoke:Lkotlin/jvm/functions/Function0;

    .line 23
    .line 24
    iput p13, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$$changed:I

    .line 25
    .line 26
    iput p14, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$$changed1:I

    .line 27
    .line 28
    const/4 v0, 0x2

    .line 29
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 15

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$permissionTitle:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$modeLabel:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$modeOptions:LX/Ddn;

    .line 7
    .line 8
    iget-boolean v5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$revocable:Z

    .line 9
    .line 10
    iget-boolean v6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$enabled:Z

    .line 11
    .line 12
    iget-boolean v7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$showSpinner:Z

    .line 13
    .line 14
    iget-boolean v8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$menuExpanded:Z

    .line 15
    .line 16
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onClick:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iget-object v10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    iget-object v11, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onModeSelected:LX/JDM;

    .line 21
    .line 22
    iget-object v12, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$onRevoke:Lkotlin/jvm/functions/Function0;

    .line 23
    .line 24
    iget v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$$changed:I

    .line 25
    .line 26
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 27
    .line 28
    .line 29
    move-result v14

    .line 30
    iget v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;->$$changed1:I

    .line 31
    .line 32
    invoke-static {v0}, LX/0z0;->A01(I)I

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    move-object/from16 v13, p1

    .line 37
    .line 38
    invoke-static/range {v1 .. v15}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionAction(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 39
    .line 40
    .line 41
    return-void
.end method
