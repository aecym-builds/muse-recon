.class public final Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson$Companion;


# instance fields
.field public final actor:Ljava/lang/String;

.field public final kind:Ljava/lang/String;

.field public final mode:Ljava/lang/String;

.field public final permission_id:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p1, 0x7

    .line 536870913
    .line 536870914
    const/4 v1, 0x7

    .line 536870915
    if-eq v1, v0, :cond_0

    .line 536870916
    .line 536870917
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson$$serializer;->descriptor:LX/Da5;

    .line 536870918
    .line 536870919
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 536870920
    .line 536870921
    .line 536870922
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 536870923
    .line 536870924
    .line 536870925
    move-result-object v0

    .line 536870926
    throw v0

    .line 536870927
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870928
    .line 536870929
    .line 536870930
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 536870931
    .line 536870932
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 536870933
    .line 536870934
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 536870935
    .line 536870936
    and-int/lit8 v0, p1, 0x8

    .line 536870937
    .line 536870938
    if-nez v0, :cond_1

    .line 536870939
    .line 536870940
    const-string p5, "ui"

    .line 536870941
    .line 536870942
    :cond_1
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 536870943
    .line 536870944
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p5, 0x8

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    const-string p4, "ui"

    .line 268435461
    .line 268435462
    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435463
    .line 268435464
    .line 268435465
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;LX/Da8;LX/Da5;)V
    .locals 3

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    const/4 v2, 0x3

    .line 19
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 26
    .line 27
    const-string v0, "ui"

    .line 28
    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 36
    .line 37
    invoke-interface {p1, v0, p2, v2}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    :cond_0
    return v2

    .line 51
    :cond_1
    return v3
.end method

.method public final getActor()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getKind()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermission_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->permission_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->kind:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->mode:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;->actor:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/006;->A0L(Ljava/lang/String;I)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
