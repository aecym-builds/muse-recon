.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsViewModel$loadPermissions$1"
    f = "ActivePermissionsViewModel.kt"
    l = {
        0x6d,
        0x6f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $reset:Z

.field public I$0:I

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;ZLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->$reset:Z

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->$reset:Z

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;ZLX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 0
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v8, p0

    .line 3
    .line 4
    iget v0, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->label:I

    .line 5
    .line 6
    const/4 v6, 0x2

    .line 7
    const/4 v5, 0x1

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    if-eq v0, v5, :cond_6

    .line 11
    .line 12
    if-eq v0, v6, :cond_6

    .line 13
    .line 14
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    throw v0

    .line 19
    :cond_0
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 23
    .line 24
    invoke-static {v0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    iget-boolean v0, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->$reset:Z

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    if-ne v1, v0, :cond_2

    .line 38
    .line 39
    :cond_1
    const/4 v3, 0x1

    .line 40
    :cond_2
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 41
    .line 42
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 43
    .line 44
    :cond_3
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    move-object v13, v1

    .line 49
    check-cast v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 50
    .line 51
    if-eqz v3, :cond_5

    .line 52
    .line 53
    sget-object v16, LX/Dwg;->A01:LX/Dwg;

    .line 54
    .line 55
    sget-object v19, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->LOADING:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 56
    .line 57
    const/4 v14, 0x0

    .line 58
    iget-boolean v12, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 59
    .line 60
    iget-object v11, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v10, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 63
    .line 64
    iget-boolean v9, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 65
    .line 66
    iget-object v0, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 67
    .line 68
    const/16 v23, 0x0

    .line 69
    .line 70
    move-object v15, v13

    .line 71
    move-object/from16 v17, v16

    .line 72
    .line 73
    move/from16 v18, v12

    .line 74
    .line 75
    move-object/from16 v20, v14

    .line 76
    .line 77
    move-object/from16 v21, v14

    .line 78
    .line 79
    move/from16 v22, v5

    .line 80
    .line 81
    move-object/from16 v24, v11

    .line 82
    .line 83
    move-object/from16 v25, v10

    .line 84
    .line 85
    move/from16 p0, v9

    .line 86
    .line 87
    move-object/from16 p1, v0

    .line 88
    .line 89
    invoke-virtual/range {v15 .. v27}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    :goto_0
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_3

    .line 98
    .line 99
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 100
    .line 101
    iput-object v14, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->L$0:Ljava/lang/Object;

    .line 102
    .line 103
    iput v3, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->I$0:I

    .line 104
    .line 105
    if-eqz v3, :cond_4

    .line 106
    .line 107
    iput v5, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->label:I

    .line 108
    .line 109
    invoke-static {v0, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->access$loadFirstPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    :goto_1
    if-ne v0, v7, :cond_7

    .line 114
    .line 115
    return-object v7

    .line 116
    :cond_4
    iput v6, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;->label:I

    .line 117
    .line 118
    invoke-static {v0, v4, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->access$loadNextPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/2M4;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    goto :goto_1

    .line 123
    :cond_5
    const/16 p0, 0xf7f

    .line 124
    .line 125
    const/4 v14, 0x0

    .line 126
    const/16 v16, 0x0

    .line 127
    .line 128
    move-object v15, v14

    .line 129
    move-object/from16 v17, v14

    .line 130
    .line 131
    move-object/from16 v18, v14

    .line 132
    .line 133
    move-object/from16 v19, v14

    .line 134
    .line 135
    move/from16 v20, v16

    .line 136
    .line 137
    move-object/from16 v22, v14

    .line 138
    .line 139
    move-object/from16 v23, v14

    .line 140
    .line 141
    move/from16 v24, v16

    .line 142
    .line 143
    move-object/from16 v25, v14

    .line 144
    .line 145
    move-object/from16 p1, v14

    .line 146
    .line 147
    move/from16 v21, v5

    .line 148
    .line 149
    invoke-static/range {v13 .. v27}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    goto :goto_0

    .line 154
    :cond_6
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_7
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 158
    .line 159
    return-object v7
.end method
