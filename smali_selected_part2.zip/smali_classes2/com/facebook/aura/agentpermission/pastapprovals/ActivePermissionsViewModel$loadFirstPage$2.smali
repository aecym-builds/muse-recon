.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/IBK<",
        "+",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;",
        "+",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsViewModel$loadFirstPage$2"
    f = "ActivePermissionsViewModel.kt"
    l = {
        0x79,
        0x79
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;

    .line 3
    .line 4
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$0:Ljava/lang/Object;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/IBK<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v9, LX/1EL;

    .line 3
    .line 4
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->label:I

    .line 7
    .line 8
    const/4 v7, 0x2

    .line 9
    const/4 v6, 0x1

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    if-eq v0, v6, :cond_2

    .line 13
    .line 14
    if-ne v0, v7, :cond_4

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$3:Ljava/lang/Object;

    .line 17
    .line 18
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-static {v1, p1}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0

    .line 26
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 30
    .line 31
    const/4 v5, 0x0

    .line 32
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2$grouped$1;

    .line 33
    .line 34
    invoke-direct {v0, v1, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2$grouped$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 35
    .line 36
    .line 37
    sget-object v4, LX/39s;->A00:LX/39s;

    .line 38
    .line 39
    sget-object v3, LX/FkO;->A00:Ljava/lang/Integer;

    .line 40
    .line 41
    invoke-static {v3, v4, v0, v9}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 46
    .line 47
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2$flat$1;

    .line 48
    .line 49
    invoke-direct {v0, v1, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2$flat$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 50
    .line 51
    .line 52
    invoke-static {v3, v4, v0, v9}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    iput-object v5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$2:Ljava/lang/Object;

    .line 61
    .line 62
    iput v6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->label:I

    .line 63
    .line 64
    invoke-virtual {v2, p0}, LX/DRW;->A0E(LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    if-ne p1, v8, :cond_3

    .line 69
    .line 70
    :cond_1
    return-object v8

    .line 71
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$2:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v1, LX/EQR;

    .line 74
    .line 75
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    :cond_3
    const/4 v0, 0x0

    .line 79
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$0:Ljava/lang/Object;

    .line 80
    .line 81
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$1:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$2:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->L$3:Ljava/lang/Object;

    .line 86
    .line 87
    iput v7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;->label:I

    .line 88
    .line 89
    invoke-static {v1, p0}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    if-eq v0, v8, :cond_1

    .line 94
    .line 95
    move-object v1, p1

    .line 96
    move-object p1, v0

    .line 97
    goto :goto_0

    .line 98
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    throw v0
.end method
