.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDO<",
        "LX/1Xg;",
        "Ljava/lang/Integer;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $items:Ljava/util/List;

.field public final synthetic $menuPermissionId$inlined:Ljava/lang/String;

.field public final synthetic $onDismissMenu$inlined:Lkotlin/jvm/functions/Function0;

.field public final synthetic $onMenuRequested$inlined:LX/JDM;

.field public final synthetic $onModeSelected$inlined:LX/JDN;

.field public final synthetic $onRevoke$inlined:LX/JDM;

.field public final synthetic $permissions$inlined:Ljava/util/List;

.field public final synthetic $uiState$inlined:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Ljava/lang/String;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$permissions$inlined:Ljava/util/List;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$menuPermissionId$inlined:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onRevoke$inlined:LX/JDM;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onMenuRequested$inlined:LX/JDM;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onDismissMenu$inlined:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onModeSelected$inlined:LX/JDN;

    .line 15
    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    check-cast p1, LX/1Xg;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v1

    .line 268435462
    check-cast p3, LX/2d4;

    .line 268435463
    .line 268435464
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    invoke-virtual {p0, p1, v1, p3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->invoke(LX/1Xg;ILX/2d4;I)V

    .line 268435469
    .line 268435470
    .line 268435471
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435472
    .line 268435473
    return-object v0
.end method

.method public final invoke(LX/1Xg;ILX/2d4;I)V
    .locals 11

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    if-nez v0, :cond_1

    .line 3
    .line 4
    invoke-static {p3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    or-int/2addr v1, p4

    .line 9
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    invoke-static {p3, p2}, LX/004;->A0F(LX/2d4;I)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    or-int/2addr v1, v0

    .line 18
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0, p3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 29
    .line 30
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    and-int/lit8 v3, v1, 0x7e

    .line 35
    .line 36
    check-cast v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 37
    .line 38
    const v0, -0x3b2fef58

    .line 39
    .line 40
    .line 41
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$permissions$inlined:Ljava/util/List;

    .line 45
    .line 46
    invoke-static {v0}, LX/007;->A0T(Ljava/util/List;)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 51
    .line 52
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$menuPermissionId$inlined:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onRevoke$inlined:LX/JDM;

    .line 55
    .line 56
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onMenuRequested$inlined:LX/JDM;

    .line 57
    .line 58
    iget-object v10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onDismissMenu$inlined:Lkotlin/jvm/functions/Function0;

    .line 59
    .line 60
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;->$onModeSelected$inlined:LX/JDN;

    .line 61
    .line 62
    new-instance v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;

    .line 63
    .line 64
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;)V

    .line 65
    .line 66
    .line 67
    const v0, -0x3be251f6

    .line 68
    .line 69
    .line 70
    invoke-static {p3, v4, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    shr-int/lit8 v0, v3, 0x3

    .line 75
    .line 76
    and-int/lit8 v0, v0, 0xe

    .line 77
    .line 78
    or-int/lit16 v0, v0, 0x180

    .line 79
    .line 80
    invoke-static {p2, v2, v1, p3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionRowContainer(IILX/JDN;LX/2d4;I)V

    .line 81
    .line 82
    .line 83
    invoke-static {p3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_1
    move v1, p4

    .line 88
    goto :goto_0

    .line 89
    :cond_2
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 90
    .line 91
    .line 92
    return-void
.end method
