.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final connectorKey:Ljava/lang/String;

.field public final display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

.field public final kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

.field public final lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

.field public final mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

.field public final modeOptions:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation
.end field

.field public final permissionId:Ljava/lang/String;

.field public final revocable:Z

.field public final scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;",
            "Z",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 12
    .line 13
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 14
    .line 15
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 16
    .line 17
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 18
    .line 19
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 20
    .line 21
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 22
    .line 23
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 24
    .line 25
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 26
    .line 27
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p10, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 53
    .line 54
    :cond_8
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->copy(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;",
            "Z",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;",
            ")",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 7
    .line 8
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;)V

    .line 9
    .line 10
    .line 11
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 29
    .line 30
    if-ne v1, v0, :cond_0

    .line 31
    .line 32
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 33
    .line 34
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 35
    .line 36
    if-ne v1, v0, :cond_0

    .line 37
    .line 38
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 39
    .line 40
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 41
    .line 42
    if-ne v1, v0, :cond_0

    .line 43
    .line 44
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 45
    .line 46
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 47
    .line 48
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_0

    .line 53
    .line 54
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 55
    .line 56
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 67
    .line 68
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 75
    .line 76
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 77
    .line 78
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_1

    .line 83
    .line 84
    :cond_0
    return v2

    .line 85
    :cond_1
    return v3
.end method

.method public final getConnectorKey()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisplay()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getKind()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLifetime()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode()Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getModeOptions()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermissionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRevocable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getScope()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 22
    .line 23
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 43
    .line 44
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    add-int/2addr v1, v0

    .line 55
    mul-int/lit8 v1, v1, 0x1f

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 58
    .line 59
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    add-int/2addr v1, v0

    .line 64
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
