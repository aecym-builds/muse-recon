.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/1O1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $destructiveTextColor:J

.field public final synthetic $menuPermissionId$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onDismissMenu:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onLoadMore:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onMenuRequested:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onModeSelected:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onReset:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRevoke:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resetLabel:Ljava/lang/String;

.field public final synthetic $scopeTypeLabels:LX/0Xl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/0Xl<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $supportedGroups:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

.field public final synthetic $ungroupedPermissions:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $websiteSectionTitle:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Dwf;Ljava/lang/String;LX/Dwf;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/0Xl;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;J)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "LX/Dwf<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;",
            "Ljava/lang/String;",
            "LX/Dwf<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "LX/0Xl<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;J)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$supportedGroups:LX/Dwf;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$websiteSectionTitle:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$ungroupedPermissions:LX/Dwf;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onRevoke:LX/JDM;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onMenuRequested:LX/JDM;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onModeSelected:LX/JDN;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$scopeTypeLabels:LX/0Xl;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$menuPermissionId$delegate:Landroidx/compose/runtime/MutableState;

    .line 19
    .line 20
    iput-object p11, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 21
    .line 22
    iput-object p12, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$resetLabel:Ljava/lang/String;

    .line 23
    .line 24
    iput-object p13, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onReset:Lkotlin/jvm/functions/Function0;

    .line 25
    .line 26
    iput-wide p14, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$destructiveTextColor:J

    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1O1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->invoke(LX/1O1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/1O1;)V
    .locals 29

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v1, p1

    .line 2
    .line 3
    invoke-static {v1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v0, p0

    .line 7
    .line 8
    iget-object v10, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 9
    .line 10
    iget-object v3, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 11
    .line 12
    sget-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 13
    .line 14
    if-ne v3, v2, :cond_5

    .line 15
    .line 16
    iget-boolean v2, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 17
    .line 18
    if-eqz v2, :cond_3

    .line 19
    .line 20
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$supportedGroups:LX/Dwf;

    .line 21
    .line 22
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$scopeTypeLabels:LX/0Xl;

    .line 23
    .line 24
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onRevoke:LX/JDM;

    .line 25
    .line 26
    move-object/from16 v24, v2

    .line 27
    .line 28
    iget-object v11, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onMenuRequested:LX/JDM;

    .line 29
    .line 30
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 31
    .line 32
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onModeSelected:LX/JDN;

    .line 33
    .line 34
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$menuPermissionId$delegate:Landroidx/compose/runtime/MutableState;

    .line 35
    .line 36
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v18

    .line 40
    const/16 v17, 0x0

    .line 41
    .line 42
    :goto_0
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_2

    .line 47
    .line 48
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v12

    .line 52
    add-int/lit8 v16, v17, 0x1

    .line 53
    .line 54
    if-gez v17, :cond_0

    .line 55
    .line 56
    invoke-static {}, LX/B8B;->A1A()V

    .line 57
    .line 58
    .line 59
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    throw v0

    .line 64
    :cond_0
    check-cast v12, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 65
    .line 66
    iget-object v14, v12, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 67
    .line 68
    iget-object v13, v14, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 69
    .line 70
    invoke-virtual {v13}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->getWireValue()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v15

    .line 74
    iget-object v4, v14, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->sessionScopeId:Ljava/lang/String;

    .line 75
    .line 76
    const-string v3, "scope_"

    .line 77
    .line 78
    const-string v2, "_"

    .line 79
    .line 80
    invoke-static {v3, v15, v2, v4}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v20

    .line 84
    iget-object v4, v14, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->displayName:Ljava/lang/String;

    .line 85
    .line 86
    if-nez v4, :cond_1

    .line 87
    .line 88
    invoke-static {v9, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 89
    .line 90
    .line 91
    invoke-static {v13, v9}, LX/1H9;->A01(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    check-cast v4, Ljava/lang/String;

    .line 96
    .line 97
    :cond_1
    iget-object v3, v12, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->items:Ljava/util/List;

    .line 98
    .line 99
    invoke-static {v6}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v25

    .line 103
    iget-object v2, v12, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 104
    .line 105
    iget-object v2, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 106
    .line 107
    invoke-static {v9, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 108
    .line 109
    .line 110
    invoke-static {v2, v9}, LX/1H9;->A01(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p0

    .line 114
    check-cast p0, Ljava/lang/String;

    .line 115
    .line 116
    invoke-static/range {v17 .. v17}, LX/003;->A1F(I)Z

    .line 117
    .line 118
    .line 119
    move-result p1

    .line 120
    move-object/from16 v23, v10

    .line 121
    .line 122
    move-object/from16 v26, v11

    .line 123
    .line 124
    move-object/from16 v27, v8

    .line 125
    .line 126
    move-object/from16 v28, v7

    .line 127
    .line 128
    move-object/from16 v19, v1

    .line 129
    .line 130
    move-object/from16 v21, v4

    .line 131
    .line 132
    move-object/from16 v22, v3

    .line 133
    .line 134
    invoke-static/range {v19 .. v30}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V

    .line 135
    .line 136
    .line 137
    move/from16 v17, v16

    .line 138
    .line 139
    goto :goto_0

    .line 140
    :cond_2
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$websiteSectionTitle:Ljava/lang/String;

    .line 141
    .line 142
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$ungroupedPermissions:LX/Dwf;

    .line 143
    .line 144
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 145
    .line 146
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onRevoke:LX/JDM;

    .line 147
    .line 148
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$menuPermissionId$delegate:Landroidx/compose/runtime/MutableState;

    .line 149
    .line 150
    invoke-static {v2}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v16

    .line 154
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onMenuRequested:LX/JDM;

    .line 155
    .line 156
    iget-object v4, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 157
    .line 158
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onModeSelected:LX/JDN;

    .line 159
    .line 160
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$supportedGroups:LX/Dwf;

    .line 161
    .line 162
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 163
    .line 164
    .line 165
    move-result v2

    .line 166
    xor-int/lit8 v21, v2, 0x1

    .line 167
    .line 168
    const/16 v20, 0x0

    .line 169
    .line 170
    const-string v11, "scope_other"

    .line 171
    .line 172
    move-object v14, v7

    .line 173
    move-object v15, v6

    .line 174
    move-object/from16 v17, v5

    .line 175
    .line 176
    move-object/from16 v18, v4

    .line 177
    .line 178
    move-object/from16 v19, v3

    .line 179
    .line 180
    move-object v10, v1

    .line 181
    move-object v12, v9

    .line 182
    move-object v13, v8

    .line 183
    invoke-static/range {v10 .. v21}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V

    .line 184
    .line 185
    .line 186
    goto :goto_2

    .line 187
    :cond_3
    iget-object v2, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 188
    .line 189
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 194
    .line 195
    .line 196
    move-result-object v4

    .line 197
    :cond_4
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 198
    .line 199
    .line 200
    move-result v2

    .line 201
    if-eqz v2, :cond_6

    .line 202
    .line 203
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v3

    .line 207
    move-object v2, v3

    .line 208
    check-cast v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 209
    .line 210
    invoke-static {v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->isVisibleFlatPermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    if-eqz v2, :cond_4

    .line 215
    .line 216
    invoke-virtual {v6, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    goto :goto_1

    .line 220
    :cond_5
    sget-object v3, Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt;->lambda$54296397:LX/JDQ;

    .line 221
    .line 222
    const-string v2, "active_permissions_loading"

    .line 223
    .line 224
    const-string v0, "loading"

    .line 225
    .line 226
    goto :goto_3

    .line 227
    :cond_6
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$invoke$$inlined$sortedBy$1;

    .line 228
    .line 229
    invoke-direct {v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$invoke$$inlined$sortedBy$1;-><init>()V

    .line 230
    .line 231
    .line 232
    invoke-static {v6, v2}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 233
    .line 234
    .line 235
    move-result-object v12

    .line 236
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$websiteSectionTitle:Ljava/lang/String;

    .line 237
    .line 238
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 239
    .line 240
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onRevoke:LX/JDM;

    .line 241
    .line 242
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$menuPermissionId$delegate:Landroidx/compose/runtime/MutableState;

    .line 243
    .line 244
    invoke-static {v2}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v15

    .line 248
    iget-object v4, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onMenuRequested:LX/JDM;

    .line 249
    .line 250
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 251
    .line 252
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onModeSelected:LX/JDN;

    .line 253
    .line 254
    const/16 v19, 0x0

    .line 255
    .line 256
    const-string v10, "kind_website"

    .line 257
    .line 258
    move-object v9, v1

    .line 259
    move-object v11, v8

    .line 260
    move-object v13, v7

    .line 261
    move-object v14, v6

    .line 262
    move-object/from16 v16, v4

    .line 263
    .line 264
    move-object/from16 v17, v3

    .line 265
    .line 266
    move-object/from16 v18, v2

    .line 267
    .line 268
    move/from16 v20, v5

    .line 269
    .line 270
    invoke-static/range {v9 .. v20}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V

    .line 271
    .line 272
    .line 273
    :goto_2
    iget-object v4, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 274
    .line 275
    iget-boolean v2, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 276
    .line 277
    if-nez v2, :cond_7

    .line 278
    .line 279
    iget-boolean v2, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 280
    .line 281
    if-eqz v2, :cond_8

    .line 282
    .line 283
    :cond_7
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 284
    .line 285
    new-instance v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;

    .line 286
    .line 287
    invoke-direct {v3, v4, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Lkotlin/jvm/functions/Function0;)V

    .line 288
    .line 289
    .line 290
    const v2, 0x66307ad6

    .line 291
    .line 292
    .line 293
    invoke-static {v3, v2}, LX/002;->A0W(Ljava/lang/Object;I)LX/Ddo;

    .line 294
    .line 295
    .line 296
    move-result-object v4

    .line 297
    const-string v3, "active_permissions_load_more"

    .line 298
    .line 299
    const-string v2, "load_more"

    .line 300
    .line 301
    invoke-interface {v1, v3, v2, v4}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 302
    .line 303
    .line 304
    :cond_8
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 305
    .line 306
    iget-object v4, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$resetLabel:Ljava/lang/String;

    .line 307
    .line 308
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$onReset:Lkotlin/jvm/functions/Function0;

    .line 309
    .line 310
    iget-wide v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;->$destructiveTextColor:J

    .line 311
    .line 312
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3;

    .line 313
    .line 314
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Ljava/lang/String;Lkotlin/jvm/functions/Function0;J)V

    .line 315
    .line 316
    .line 317
    const v0, -0x6967077c

    .line 318
    .line 319
    .line 320
    invoke-static {v2, v0}, LX/002;->A0W(Ljava/lang/Object;I)LX/Ddo;

    .line 321
    .line 322
    .line 323
    move-result-object v3

    .line 324
    const-string v2, "active_permissions_reset"

    .line 325
    .line 326
    const-string v0, "reset"

    .line 327
    .line 328
    :goto_3
    invoke-interface {v1, v2, v0, v3}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 329
    .line 330
    .line 331
    return-void
.end method
