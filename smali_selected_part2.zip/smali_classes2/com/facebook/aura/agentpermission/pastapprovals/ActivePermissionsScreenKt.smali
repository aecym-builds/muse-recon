.class public abstract Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ActivePermissionSectionHeader(Ljava/lang/String;Ljava/lang/String;ZLX/3C1;LX/2d4;II)V
    .locals 45

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    const v1, -0x485dd8d4

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p5

    .line 11
    .line 12
    and-int/lit8 v1, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v13, p0

    .line 15
    .line 16
    if-nez v1, :cond_6

    .line 17
    .line 18
    invoke-static {v0, v13}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    or-int v6, v6, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v1, p5, 0x30

    .line 25
    .line 26
    move-object/from16 v10, p1

    .line 27
    .line 28
    if-nez v1, :cond_0

    .line 29
    .line 30
    invoke-static {v0, v10}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    or-int/2addr v6, v1

    .line 35
    :cond_0
    and-int/lit16 v1, v2, 0x180

    .line 36
    .line 37
    move/from16 v9, p2

    .line 38
    .line 39
    if-nez v1, :cond_1

    .line 40
    .line 41
    invoke-static {v0, v9}, LX/004;->A0k(LX/2d4;Z)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    or-int/2addr v6, v1

    .line 46
    :cond_1
    and-int/lit8 v3, p6, 0x8

    .line 47
    .line 48
    if-eqz v3, :cond_5

    .line 49
    .line 50
    or-int/lit16 v6, v6, 0xc00

    .line 51
    .line 52
    :cond_2
    :goto_1
    invoke-static {v6}, LX/005;->A1K(I)Z

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    invoke-static {v1, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-eqz v1, :cond_7

    .line 61
    .line 62
    if-eqz v3, :cond_3

    .line 63
    .line 64
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 65
    .line 66
    :cond_3
    invoke-static {v4}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    const/4 v5, 0x0

    .line 71
    if-eqz p2, :cond_4

    .line 72
    .line 73
    const/high16 v5, 0x42000000    # 32.0f

    .line 74
    .line 75
    :cond_4
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 76
    .line 77
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 78
    .line 79
    invoke-static {v7, v3, v5, v3, v1}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    invoke-static {v0}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 84
    .line 85
    .line 86
    move-result-object v12

    .line 87
    move-object v3, v0

    .line 88
    check-cast v3, LX/J7I;

    .line 89
    .line 90
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 91
    .line 92
    .line 93
    move-result v11

    .line 94
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 95
    .line 96
    .line 97
    move-result-object v8

    .line 98
    invoke-static {v0, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 99
    .line 100
    .line 101
    move-result-object v7

    .line 102
    sget-object v5, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 103
    .line 104
    iget-object v1, v3, LX/J7I;->A0V:LX/3DJ;

    .line 105
    .line 106
    if-nez v1, :cond_8

    .line 107
    .line 108
    invoke-static {}, LX/1VY;->A00()V

    .line 109
    .line 110
    .line 111
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    throw v0

    .line 116
    :cond_5
    and-int/lit16 v1, v2, 0xc00

    .line 117
    .line 118
    if-nez v1, :cond_2

    .line 119
    .line 120
    invoke-static {v0, v4}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    or-int/2addr v6, v1

    .line 125
    goto :goto_1

    .line 126
    :cond_6
    move v6, v2

    .line 127
    goto :goto_0

    .line 128
    :cond_7
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 129
    .line 130
    .line 131
    goto :goto_3

    .line 132
    :cond_8
    invoke-static {v0, v3, v5}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 133
    .line 134
    .line 135
    invoke-static {v0, v12, v8, v7, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 136
    .line 137
    .line 138
    sget-object v7, LX/CgK;->A00:LX/CgK;

    .line 139
    .line 140
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 141
    .line 142
    const/16 v18, 0x0

    .line 143
    .line 144
    const/high16 v1, 0x3f800000    # 1.0f

    .line 145
    .line 146
    const/4 v8, 0x1

    .line 147
    invoke-virtual {v7, v5, v1, v8}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 148
    .line 149
    .line 150
    move-result-object v12

    .line 151
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v11

    .line 155
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 156
    .line 157
    if-ne v11, v1, :cond_9

    .line 158
    .line 159
    sget-object v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionSectionHeader$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionSectionHeader$1$1$1;

    .line 160
    .line 161
    invoke-interface {v0, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    :cond_9
    check-cast v11, LX/JDM;

    .line 165
    .line 166
    const/4 v7, 0x0

    .line 167
    invoke-static {v12, v11, v7}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 168
    .line 169
    .line 170
    move-result-object v14

    .line 171
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 172
    .line 173
    const/16 v30, 0x6

    .line 174
    .line 175
    invoke-static {v0, v1}, LX/3Rq;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 176
    .line 177
    .line 178
    move-result-object v17

    .line 179
    invoke-static {v0, v1}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 180
    .line 181
    .line 182
    move-result-wide v15

    .line 183
    const/16 v24, 0x2

    .line 184
    .line 185
    and-int/lit8 v29, v6, 0xe

    .line 186
    .line 187
    const/high16 p3, 0x30000000

    .line 188
    .line 189
    or-int v29, v29, p3

    .line 190
    .line 191
    const/16 v31, 0x39f0

    .line 192
    .line 193
    move-object/from16 v19, v18

    .line 194
    .line 195
    move-object/from16 v20, v18

    .line 196
    .line 197
    move/from16 v21, v7

    .line 198
    .line 199
    move/from16 v22, v7

    .line 200
    .line 201
    move/from16 v23, v8

    .line 202
    .line 203
    move-object/from16 v25, v18

    .line 204
    .line 205
    move-object/from16 v26, v18

    .line 206
    .line 207
    move-object/from16 v27, v18

    .line 208
    .line 209
    move-object/from16 v28, v0

    .line 210
    .line 211
    invoke-static/range {v13 .. v31}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 212
    .line 213
    .line 214
    if-nez p1, :cond_b

    .line 215
    .line 216
    const v1, 0x430952e

    .line 217
    .line 218
    .line 219
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 220
    .line 221
    .line 222
    :goto_2
    invoke-static {v3, v4, v7, v8}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 223
    .line 224
    .line 225
    move-result-object v4

    .line 226
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    if-eqz v1, :cond_a

    .line 231
    .line 232
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionSectionHeader$2;

    .line 233
    .line 234
    move-object/from16 p0, v0

    .line 235
    .line 236
    move-object/from16 p1, v13

    .line 237
    .line 238
    move-object/from16 p2, v10

    .line 239
    .line 240
    move/from16 p3, v9

    .line 241
    .line 242
    move-object/from16 p4, v4

    .line 243
    .line 244
    move/from16 p5, v2

    .line 245
    .line 246
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionSectionHeader$2;-><init>(Ljava/lang/String;Ljava/lang/String;ZLX/3C1;II)V

    .line 247
    .line 248
    .line 249
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 250
    .line 251
    :cond_a
    return-void

    .line 252
    :cond_b
    const v6, 0x430952f

    .line 253
    .line 254
    .line 255
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 256
    .line 257
    .line 258
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 259
    .line 260
    invoke-static {v5, v6}, LX/3Rr;->A09(LX/3C1;F)LX/3C1;

    .line 261
    .line 262
    .line 263
    move-result-object v33

    .line 264
    invoke-static {v0, v1}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 265
    .line 266
    .line 267
    move-result-object v36

    .line 268
    invoke-static {v0, v1}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 269
    .line 270
    .line 271
    move-result-wide v34

    .line 272
    move-object/from16 v32, v10

    .line 273
    .line 274
    move-object/from16 v37, v18

    .line 275
    .line 276
    move-object/from16 v38, v18

    .line 277
    .line 278
    move-object/from16 v39, v18

    .line 279
    .line 280
    move/from16 v40, v7

    .line 281
    .line 282
    move/from16 v41, v7

    .line 283
    .line 284
    move/from16 v42, v8

    .line 285
    .line 286
    move/from16 v43, v24

    .line 287
    .line 288
    move-object/from16 v44, v18

    .line 289
    .line 290
    move-object/from16 p0, v18

    .line 291
    .line 292
    move-object/from16 p1, v18

    .line 293
    .line 294
    move-object/from16 p2, v0

    .line 295
    .line 296
    move/from16 p4, v30

    .line 297
    .line 298
    move/from16 p5, v31

    .line 299
    .line 300
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 301
    .line 302
    .line 303
    goto :goto_2
.end method

.method public static final ActivePermissionsContent-KhTvWYU(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "FF",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, -0x40c4dfd

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p8

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v0, p9

    .line 9
    .line 10
    and-int/lit8 v3, p9, 0x6

    .line 11
    .line 12
    move-object v2, p0

    .line 13
    if-nez v3, :cond_b

    .line 14
    .line 15
    invoke-static {p0, v1, v0}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-static {v3}, LX/003;->A06(I)I

    .line 20
    .line 21
    .line 22
    move-result v8

    .line 23
    or-int v8, v8, p9

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v3, p9, 0x30

    .line 26
    .line 27
    move v4, p1

    .line 28
    if-nez v3, :cond_0

    .line 29
    .line 30
    invoke-static {v1, p1}, LX/004;->A0A(LX/2d4;F)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    or-int/2addr v8, v3

    .line 35
    :cond_0
    and-int/lit16 v5, v0, 0x180

    .line 36
    .line 37
    move v3, p2

    .line 38
    if-nez v5, :cond_1

    .line 39
    .line 40
    invoke-static {v1, p2}, LX/004;->A0B(LX/2d4;F)I

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    or-int/2addr v8, v5

    .line 45
    :cond_1
    and-int/lit16 v5, v0, 0xc00

    .line 46
    .line 47
    move-object/from16 p0, p3

    .line 48
    .line 49
    if-nez v5, :cond_2

    .line 50
    .line 51
    invoke-static {v1, p0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v5

    .line 55
    or-int/2addr v8, v5

    .line 56
    :cond_2
    and-int/lit16 v5, v0, 0x6000

    .line 57
    .line 58
    move-object/from16 v9, p4

    .line 59
    .line 60
    if-nez v5, :cond_3

    .line 61
    .line 62
    invoke-static {v1, v9}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    or-int/2addr v8, v5

    .line 67
    :cond_3
    const/high16 v5, 0x30000

    .line 68
    .line 69
    and-int v5, v5, p9

    .line 70
    .line 71
    move-object/from16 v7, p5

    .line 72
    .line 73
    if-nez v5, :cond_4

    .line 74
    .line 75
    invoke-static {v1, v7}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 76
    .line 77
    .line 78
    move-result v5

    .line 79
    or-int/2addr v8, v5

    .line 80
    :cond_4
    const/high16 v5, 0x180000

    .line 81
    .line 82
    and-int v5, v5, p9

    .line 83
    .line 84
    move-object/from16 v6, p6

    .line 85
    .line 86
    if-nez v5, :cond_5

    .line 87
    .line 88
    invoke-static {v1, v6}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 89
    .line 90
    .line 91
    move-result v5

    .line 92
    or-int/2addr v8, v5

    .line 93
    :cond_5
    const/high16 v10, 0xc00000

    .line 94
    .line 95
    and-int v10, v10, p9

    .line 96
    .line 97
    move-object/from16 v5, p7

    .line 98
    .line 99
    if-nez v10, :cond_6

    .line 100
    .line 101
    invoke-static {v1, v5}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v10

    .line 105
    or-int/2addr v8, v10

    .line 106
    :cond_6
    const v12, 0x492493

    .line 107
    .line 108
    .line 109
    and-int/2addr v12, v8

    .line 110
    const v11, 0x492492

    .line 111
    .line 112
    .line 113
    const/4 v10, 0x0

    .line 114
    invoke-static {v12, v11}, LX/003;->A1H(II)Z

    .line 115
    .line 116
    .line 117
    move-result v11

    .line 118
    invoke-static {v11, v1, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 119
    .line 120
    .line 121
    move-result v11

    .line 122
    if-eqz v11, :cond_a

    .line 123
    .line 124
    const/16 p5, 0x0

    .line 125
    .line 126
    sget-object v11, LX/2sI;->A01:LX/2wD;

    .line 127
    .line 128
    invoke-static {v11, p1, p2}, LX/2pj;->A08(LX/3C1;FF)LX/3C1;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    iget-object v12, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 133
    .line 134
    sget-object v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->ERROR:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 135
    .line 136
    if-ne v12, v11, :cond_8

    .line 137
    .line 138
    const v10, -0x323083c9

    .line 139
    .line 140
    .line 141
    invoke-interface {v1, v10}, LX/2d4;->Agj(I)V

    .line 142
    .line 143
    .line 144
    const v10, 0x7f120182

    .line 145
    .line 146
    .line 147
    invoke-static {v1, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v12

    .line 151
    sget-object p2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 152
    .line 153
    sget-object p3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 154
    .line 155
    sget-object p4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MANAGE_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 156
    .line 157
    shr-int/lit8 v8, v8, 0x6

    .line 158
    .line 159
    and-int/lit8 p8, v8, 0x70

    .line 160
    .line 161
    const v8, 0x36c00

    .line 162
    .line 163
    .line 164
    or-int p8, p8, v8

    .line 165
    .line 166
    const/16 p9, 0xc0

    .line 167
    .line 168
    move-object/from16 p6, p5

    .line 169
    .line 170
    move-object/from16 p7, v1

    .line 171
    .line 172
    invoke-static/range {v12 .. v22}, Lcom/facebook/aura/ui/HatchScreenErrorStateKt;->HatchScreenErrorState(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Ljava/lang/String;Ljava/util/Map;LX/2d4;II)V

    .line 173
    .line 174
    .line 175
    :goto_1
    invoke-static {v1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 179
    .line 180
    .line 181
    move-result-object v8

    .line 182
    if-eqz v8, :cond_7

    .line 183
    .line 184
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsContent$1;

    .line 185
    .line 186
    move v12, v3

    .line 187
    move-object p1, v9

    .line 188
    move-object p2, v7

    .line 189
    move-object/from16 p3, v6

    .line 190
    .line 191
    move-object/from16 p4, v5

    .line 192
    .line 193
    move/from16 p5, v0

    .line 194
    .line 195
    move-object v9, v1

    .line 196
    move-object v10, v2

    .line 197
    move v11, v4

    .line 198
    invoke-direct/range {v9 .. v18}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsContent$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;I)V

    .line 199
    .line 200
    .line 201
    iput-object v1, v8, LX/J7V;->A06:LX/JDN;

    .line 202
    .line 203
    :cond_7
    return-void

    .line 204
    :cond_8
    sget-object v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 205
    .line 206
    if-ne v12, v11, :cond_9

    .line 207
    .line 208
    invoke-static {v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->hasVisiblePermissions(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;)Z

    .line 209
    .line 210
    .line 211
    move-result v11

    .line 212
    if-nez v11, :cond_9

    .line 213
    .line 214
    iget-boolean v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 215
    .line 216
    if-nez v11, :cond_9

    .line 217
    .line 218
    const v8, -0x13d88522

    .line 219
    .line 220
    .line 221
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 222
    .line 223
    .line 224
    const v8, 0x7f080102

    .line 225
    .line 226
    .line 227
    invoke-static {v1, v8, v10}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 228
    .line 229
    .line 230
    move-result-object p4

    .line 231
    const v8, 0x7f12017e

    .line 232
    .line 233
    .line 234
    invoke-static {v1, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object p2

    .line 238
    sget v8, LX/2l9;->$stable:I

    .line 239
    .line 240
    shl-int/lit8 p7, v8, 0x6

    .line 241
    .line 242
    const/16 p8, 0x8

    .line 243
    .line 244
    move-object/from16 p3, p1

    .line 245
    .line 246
    move-object/from16 p6, v1

    .line 247
    .line 248
    invoke-static/range {p2 .. p8}, Lcom/facebook/aura/ui/HatchScreenEmptyStateKt;->HatchScreenEmptyState(Ljava/lang/String;LX/3C1;LX/2l9;Ljava/lang/String;LX/2d4;II)V

    .line 249
    .line 250
    .line 251
    goto :goto_1

    .line 252
    :cond_9
    const v10, -0x3230237c

    .line 253
    .line 254
    .line 255
    invoke-interface {v1, v10}, LX/2d4;->Agj(I)V

    .line 256
    .line 257
    .line 258
    sget v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->$stable:I

    .line 259
    .line 260
    and-int/lit8 v10, v8, 0xe

    .line 261
    .line 262
    or-int/2addr v11, v10

    .line 263
    invoke-static {v8, v11}, LX/002;->A0B(II)I

    .line 264
    .line 265
    .line 266
    move-result v11

    .line 267
    shr-int/lit8 v10, v8, 0x3

    .line 268
    .line 269
    and-int/lit16 v8, v10, 0x1c00

    .line 270
    .line 271
    or-int/2addr v11, v8

    .line 272
    invoke-static {v10, v11}, LX/005;->A06(II)I

    .line 273
    .line 274
    .line 275
    move-result v8

    .line 276
    invoke-static {v10, v8}, LX/001;->A06(II)I

    .line 277
    .line 278
    .line 279
    move-result p9

    .line 280
    move/from16 p3, p2

    .line 281
    .line 282
    move-object/from16 p5, v7

    .line 283
    .line 284
    move-object p1, v2

    .line 285
    move p2, v4

    .line 286
    invoke-static/range {p1 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionsList-ZUYZQmM(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V

    .line 287
    .line 288
    .line 289
    goto :goto_1

    .line 290
    :cond_a
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 291
    .line 292
    .line 293
    goto :goto_2

    .line 294
    :cond_b
    move v8, v0

    .line 295
    goto/16 :goto_0
.end method

.method public static final ActivePermissionsList-ZUYZQmM(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "FF",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, 0x8f2ef54

    .line 1
    .line 2
    .line 3
    move-object/from16 v12, p7

    .line 4
    .line 5
    invoke-interface {v12, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v11, p8

    .line 9
    .line 10
    and-int/lit8 v0, p8, 0x6

    .line 11
    .line 12
    move-object/from16 v13, p0

    .line 13
    .line 14
    if-nez v0, :cond_b

    .line 15
    .line 16
    invoke-static {v13, v12, v11}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v14

    .line 24
    or-int v14, v14, p8

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 27
    .line 28
    move/from16 v22, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    move/from16 v0, v22

    .line 33
    .line 34
    invoke-static {v12, v0}, LX/004;->A0A(LX/2d4;F)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v14, v0

    .line 39
    :cond_0
    and-int/lit16 v0, v11, 0x180

    .line 40
    .line 41
    move/from16 v21, p2

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    move/from16 v0, v21

    .line 46
    .line 47
    invoke-static {v12, v0}, LX/004;->A0B(LX/2d4;F)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v14, v0

    .line 52
    :cond_1
    and-int/lit16 v0, v11, 0xc00

    .line 53
    .line 54
    move-object/from16 p8, p3

    .line 55
    .line 56
    if-nez v0, :cond_2

    .line 57
    .line 58
    move-object/from16 v0, p8

    .line 59
    .line 60
    invoke-static {v12, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    or-int/2addr v14, v0

    .line 65
    :cond_2
    and-int/lit16 v0, v11, 0x6000

    .line 66
    .line 67
    move-object/from16 v28, p4

    .line 68
    .line 69
    if-nez v0, :cond_3

    .line 70
    .line 71
    move-object/from16 v0, v28

    .line 72
    .line 73
    invoke-static {v12, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    or-int/2addr v14, v0

    .line 78
    :cond_3
    const/high16 v0, 0x30000

    .line 79
    .line 80
    and-int/2addr v0, v11

    .line 81
    move-object/from16 p7, p5

    .line 82
    .line 83
    if-nez v0, :cond_4

    .line 84
    .line 85
    move-object/from16 v0, p7

    .line 86
    .line 87
    invoke-static {v12, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    or-int/2addr v14, v0

    .line 92
    :cond_4
    const/high16 v0, 0x180000

    .line 93
    .line 94
    and-int/2addr v0, v11

    .line 95
    move-object/from16 v31, p6

    .line 96
    .line 97
    if-nez v0, :cond_5

    .line 98
    .line 99
    move-object/from16 v0, v31

    .line 100
    .line 101
    invoke-static {v12, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    or-int/2addr v14, v0

    .line 106
    :cond_5
    const v0, 0x92493

    .line 107
    .line 108
    .line 109
    invoke-static {v14, v0}, LX/005;->A1O(II)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    invoke-static {v0, v12, v14}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_10

    .line 118
    .line 119
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v10

    .line 123
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 124
    .line 125
    const/16 v20, 0x0

    .line 126
    .line 127
    if-ne v10, v9, :cond_6

    .line 128
    .line 129
    move-object/from16 v0, v20

    .line 130
    .line 131
    invoke-static {v12, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 132
    .line 133
    .line 134
    move-result-object v10

    .line 135
    :cond_6
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 136
    .line 137
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    if-ne v8, v9, :cond_7

    .line 142
    .line 143
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$onMenuRequested$1$1;

    .line 144
    .line 145
    invoke-direct {v8, v10}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$onMenuRequested$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 146
    .line 147
    .line 148
    invoke-interface {v12, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :cond_7
    check-cast v8, LX/JDM;

    .line 152
    .line 153
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v7

    .line 157
    if-ne v7, v9, :cond_8

    .line 158
    .line 159
    new-instance v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$onDismissMenu$1$1;

    .line 160
    .line 161
    invoke-direct {v7, v10}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$onDismissMenu$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v12, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    :cond_8
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 168
    .line 169
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 170
    .line 171
    const/4 v2, 0x6

    .line 172
    invoke-static {v12, v3}, LX/07H;->A00(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)F

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    const v1, 0x7f12017f

    .line 177
    .line 178
    .line 179
    const/16 v19, 0x0

    .line 180
    .line 181
    invoke-static {v12, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v18

    .line 185
    move/from16 v1, v19

    .line 186
    .line 187
    invoke-static {v12, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionScopeTypeLabels(LX/2d4;I)LX/0Xl;

    .line 188
    .line 189
    .line 190
    move-result-object v17

    .line 191
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 192
    .line 193
    invoke-interface {v12, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v6

    .line 201
    if-nez v1, :cond_9

    .line 202
    .line 203
    if-ne v6, v9, :cond_d

    .line 204
    .line 205
    :cond_9
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 206
    .line 207
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 208
    .line 209
    .line 210
    move-result-object v5

    .line 211
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 212
    .line 213
    .line 214
    move-result-object v6

    .line 215
    :cond_a
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    if-eqz v1, :cond_c

    .line 220
    .line 221
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    move-object v1, v4

    .line 226
    check-cast v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 227
    .line 228
    iget-object v1, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 229
    .line 230
    iget-object v1, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 231
    .line 232
    invoke-static {v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->isSupportedPermissionsScope(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;)Z

    .line 233
    .line 234
    .line 235
    move-result v1

    .line 236
    if-eqz v1, :cond_a

    .line 237
    .line 238
    invoke-virtual {v5, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    goto :goto_1

    .line 242
    :cond_b
    move v14, v11

    .line 243
    goto/16 :goto_0

    .line 244
    .line 245
    :cond_c
    invoke-static {v5}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    invoke-interface {v12, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    :cond_d
    check-cast v6, LX/Dwf;

    .line 253
    .line 254
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 255
    .line 256
    invoke-interface {v12, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result v1

    .line 260
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v5

    .line 264
    if-nez v1, :cond_e

    .line 265
    .line 266
    if-ne v5, v9, :cond_12

    .line 267
    .line 268
    :cond_e
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 269
    .line 270
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 271
    .line 272
    .line 273
    move-result-object v5

    .line 274
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 275
    .line 276
    .line 277
    move-result-object v16

    .line 278
    :cond_f
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 279
    .line 280
    .line 281
    move-result v1

    .line 282
    if-eqz v1, :cond_11

    .line 283
    .line 284
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object v4

    .line 288
    move-object v15, v4

    .line 289
    check-cast v15, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 290
    .line 291
    iget-object v1, v15, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 292
    .line 293
    if-nez v1, :cond_f

    .line 294
    .line 295
    invoke-static {v15}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 296
    .line 297
    .line 298
    move-result v1

    .line 299
    if-eqz v1, :cond_f

    .line 300
    .line 301
    invoke-virtual {v5, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    goto :goto_2

    .line 305
    :cond_10
    invoke-interface {v12}, LX/2d4;->AgJ()V

    .line 306
    .line 307
    .line 308
    goto/16 :goto_4

    .line 309
    .line 310
    :cond_11
    invoke-static {v5}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 311
    .line 312
    .line 313
    move-result-object v5

    .line 314
    invoke-interface {v12, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    :cond_12
    check-cast v5, LX/Dwf;

    .line 318
    .line 319
    const v1, 0x7f12018a

    .line 320
    .line 321
    .line 322
    invoke-static {v12, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v16

    .line 326
    invoke-virtual {v3, v12, v2}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 327
    .line 328
    .line 329
    move-result-object v1

    .line 330
    iget-wide v3, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->destructiveText:J

    .line 331
    .line 332
    sget-object v1, LX/2sI;->A01:LX/2wD;

    .line 333
    .line 334
    const/4 v2, 0x0

    .line 335
    invoke-static {v1, v0, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 340
    .line 341
    add-float v1, v22, v1

    .line 342
    .line 343
    add-float v0, p2, v0

    .line 344
    .line 345
    new-instance v15, LX/1XE;

    .line 346
    .line 347
    invoke-direct {v15, v2, v1, v2, v0}, LX/1XE;-><init>(FFFF)V

    .line 348
    .line 349
    .line 350
    and-int/lit8 v1, v14, 0xe

    .line 351
    .line 352
    const/4 v0, 0x4

    .line 353
    if-eq v1, v0, :cond_13

    .line 354
    .line 355
    and-int/lit8 v0, v14, 0x8

    .line 356
    .line 357
    if-eqz v0, :cond_17

    .line 358
    .line 359
    invoke-interface {v12, v13}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 360
    .line 361
    .line 362
    move-result v0

    .line 363
    if-eqz v0, :cond_17

    .line 364
    .line 365
    :cond_13
    const/4 v1, 0x1

    .line 366
    :goto_3
    move-object/from16 v0, v17

    .line 367
    .line 368
    invoke-static {v12, v6, v0, v1}, LX/004;->A1V(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 369
    .line 370
    .line 371
    move-result v1

    .line 372
    invoke-static {v14}, LX/005;->A1N(I)Z

    .line 373
    .line 374
    .line 375
    move-result v0

    .line 376
    or-int/2addr v1, v0

    .line 377
    const/high16 v0, 0x380000

    .line 378
    .line 379
    invoke-static {v0, v14}, LX/005;->A1P(II)Z

    .line 380
    .line 381
    .line 382
    move-result v0

    .line 383
    or-int/2addr v1, v0

    .line 384
    move-object/from16 v0, v18

    .line 385
    .line 386
    invoke-static {v12, v0, v5, v1}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 387
    .line 388
    .line 389
    move-result v2

    .line 390
    invoke-static {v14}, LX/005;->A1L(I)Z

    .line 391
    .line 392
    .line 393
    move-result v1

    .line 394
    move-object/from16 v0, v16

    .line 395
    .line 396
    invoke-static {v12, v0, v2, v1}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 397
    .line 398
    .line 399
    move-result v1

    .line 400
    const/high16 v0, 0x70000

    .line 401
    .line 402
    and-int/2addr v14, v0

    .line 403
    const/high16 v0, 0x20000

    .line 404
    .line 405
    invoke-static {v14, v0}, LX/003;->A1I(II)Z

    .line 406
    .line 407
    .line 408
    move-result v0

    .line 409
    or-int/2addr v1, v0

    .line 410
    invoke-static {v12, v3, v4, v1}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 411
    .line 412
    .line 413
    move-result v1

    .line 414
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    if-nez v1, :cond_14

    .line 419
    .line 420
    if-ne v0, v9, :cond_15

    .line 421
    .line 422
    :cond_14
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;

    .line 423
    .line 424
    move-object/from16 v30, v7

    .line 425
    .line 426
    move-object/from16 v32, v17

    .line 427
    .line 428
    move-object/from16 v33, v10

    .line 429
    .line 430
    move-object/from16 v34, p8

    .line 431
    .line 432
    move-object/from16 v35, v16

    .line 433
    .line 434
    move-object/from16 v36, p7

    .line 435
    .line 436
    move-wide/from16 v37, v3

    .line 437
    .line 438
    move-object/from16 v23, v0

    .line 439
    .line 440
    move-object/from16 v24, v13

    .line 441
    .line 442
    move-object/from16 v25, v6

    .line 443
    .line 444
    move-object/from16 v26, v18

    .line 445
    .line 446
    move-object/from16 v27, v5

    .line 447
    .line 448
    move-object/from16 v29, v8

    .line 449
    .line 450
    invoke-direct/range {v23 .. v38}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Dwf;Ljava/lang/String;LX/Dwf;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/0Xl;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;J)V

    .line 451
    .line 452
    .line 453
    invoke-interface {v12, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 454
    .line 455
    .line 456
    :cond_15
    check-cast v0, LX/JDM;

    .line 457
    .line 458
    const/16 p4, 0x1fa

    .line 459
    .line 460
    move-object/from16 v32, v20

    .line 461
    .line 462
    move-object/from16 v33, v20

    .line 463
    .line 464
    move-object/from16 v34, v20

    .line 465
    .line 466
    move-object/from16 v35, v15

    .line 467
    .line 468
    move-object/from16 v36, v20

    .line 469
    .line 470
    move-object/from16 v37, v12

    .line 471
    .line 472
    move-object/from16 p0, v20

    .line 473
    .line 474
    move-object/from16 p2, v0

    .line 475
    .line 476
    move/from16 p3, v19

    .line 477
    .line 478
    move/from16 p5, v19

    .line 479
    .line 480
    move/from16 p6, v19

    .line 481
    .line 482
    invoke-static/range {v32 .. v44}, LX/EIg;->A01(LX/3IY;LX/32u;LX/Dps;LX/2or;Landroidx/compose/foundation/lazy/LazyListState;LX/2d4;LX/2sS;LX/3C1;LX/JDM;IIZZ)V

    .line 483
    .line 484
    .line 485
    :goto_4
    invoke-interface {v12}, LX/2d4;->AAg()LX/J7V;

    .line 486
    .line 487
    .line 488
    move-result-object v1

    .line 489
    if-eqz v1, :cond_16

    .line 490
    .line 491
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$2;

    .line 492
    .line 493
    move-object v2, v0

    .line 494
    move-object v3, v13

    .line 495
    move/from16 v4, v22

    .line 496
    .line 497
    move/from16 v5, v21

    .line 498
    .line 499
    move-object/from16 v6, p8

    .line 500
    .line 501
    move-object/from16 v7, v28

    .line 502
    .line 503
    move-object/from16 v8, p7

    .line 504
    .line 505
    move-object/from16 v9, v31

    .line 506
    .line 507
    move v10, v11

    .line 508
    invoke-direct/range {v2 .. v10}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;I)V

    .line 509
    .line 510
    .line 511
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 512
    .line 513
    :cond_16
    return-void

    .line 514
    :cond_17
    const/4 v1, 0x0

    .line 515
    goto/16 :goto_3
.end method

.method public static final ActivePermissionsList_ZUYZQmM$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final ActivePermissionsList_ZUYZQmM$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final ActivePermissionsScreen(Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2d4;II)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v12, p1

    .line 1
    .line 2
    move-object/from16 v0, p2

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    move-object/from16 v4, p0

    .line 6
    .line 7
    invoke-static {v4, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const v2, -0xda3e17b

    .line 11
    .line 12
    .line 13
    move-object/from16 v3, p3

    .line 14
    .line 15
    invoke-interface {v3, v2}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v2, p4

    .line 19
    .line 20
    and-int/lit8 v5, p4, 0x6

    .line 21
    .line 22
    if-nez v5, :cond_f

    .line 23
    .line 24
    invoke-static {v3, v4}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    or-int v6, v6, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v8, p5, 0x2

    .line 31
    .line 32
    if-eqz v8, :cond_e

    .line 33
    .line 34
    or-int/lit8 v6, v6, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit16 v5, v2, 0x180

    .line 37
    .line 38
    const/16 v10, 0x100

    .line 39
    .line 40
    if-nez v5, :cond_3

    .line 41
    .line 42
    and-int/lit8 v5, p5, 0x4

    .line 43
    .line 44
    if-nez v5, :cond_1

    .line 45
    .line 46
    invoke-static {v0, v3, v2}, LX/005;->A1Y(Ljava/lang/Object;LX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v7

    .line 50
    const/16 v5, 0x100

    .line 51
    .line 52
    if-nez v7, :cond_2

    .line 53
    .line 54
    :cond_1
    const/16 v5, 0x80

    .line 55
    .line 56
    :cond_2
    or-int/2addr v6, v5

    .line 57
    :cond_3
    invoke-static {v6}, LX/005;->A1I(I)Z

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    invoke-static {v5, v3, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    if-eqz v5, :cond_d

    .line 66
    .line 67
    invoke-interface {v3}, LX/2d4;->AgT()V

    .line 68
    .line 69
    .line 70
    and-int/lit8 v5, p4, 0x1

    .line 71
    .line 72
    if-eqz v5, :cond_b

    .line 73
    .line 74
    invoke-interface {v3}, LX/2d4;->AEs()Z

    .line 75
    .line 76
    .line 77
    move-result v5

    .line 78
    if-nez v5, :cond_b

    .line 79
    .line 80
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 81
    .line 82
    .line 83
    and-int/lit8 v5, p5, 0x4

    .line 84
    .line 85
    if-eqz v5, :cond_4

    .line 86
    .line 87
    :goto_2
    and-int/lit16 v6, v6, -0x381

    .line 88
    .line 89
    :cond_4
    invoke-interface {v3}, LX/2d4;->AAf()V

    .line 90
    .line 91
    .line 92
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->uiState:LX/2J3;

    .line 93
    .line 94
    const/4 v13, 0x0

    .line 95
    invoke-static {v3, v5, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 96
    .line 97
    .line 98
    move-result-object v8

    .line 99
    invoke-interface {v8}, LX/16A;->getValue()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v5

    .line 103
    check-cast v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 104
    .line 105
    iget-object v9, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 106
    .line 107
    invoke-interface {v3, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v11

    .line 111
    and-int/lit16 v5, v6, 0x380

    .line 112
    .line 113
    xor-int/lit16 v5, v5, 0x180

    .line 114
    .line 115
    if-le v5, v10, :cond_5

    .line 116
    .line 117
    invoke-interface {v3, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v5

    .line 121
    if-nez v5, :cond_6

    .line 122
    .line 123
    :cond_5
    and-int/lit16 v7, v6, 0x180

    .line 124
    .line 125
    const/4 v5, 0x0

    .line 126
    if-ne v7, v10, :cond_7

    .line 127
    .line 128
    :cond_6
    const/4 v5, 0x1

    .line 129
    :cond_7
    or-int/2addr v11, v5

    .line 130
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v5

    .line 134
    if-nez v11, :cond_8

    .line 135
    .line 136
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 137
    .line 138
    if-ne v5, v7, :cond_9

    .line 139
    .line 140
    :cond_8
    new-instance v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$1$1;

    .line 141
    .line 142
    invoke-direct {v5, v0, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$1$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/16A;)V

    .line 143
    .line 144
    .line 145
    invoke-interface {v3, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_9
    invoke-static {v3, v5, v9, v0}, LX/001;->A1I(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/AuraContainer$SecondaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$SecondaryScreen;

    .line 152
    .line 153
    const v5, 0x7f120183

    .line 154
    .line 155
    .line 156
    invoke-static {v3, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v16

    .line 160
    const/16 v34, 0x0

    .line 161
    .line 162
    new-instance v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;

    .line 163
    .line 164
    invoke-direct {v7, v0, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/16A;)V

    .line 165
    .line 166
    .line 167
    const v5, -0x7dd512b6

    .line 168
    .line 169
    .line 170
    invoke-static {v3, v7, v5}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 171
    .line 172
    .line 173
    move-result-object v43

    .line 174
    and-int/lit8 v5, v6, 0x70

    .line 175
    .line 176
    or-int/lit8 v7, v5, 0x6

    .line 177
    .line 178
    shl-int/lit8 v5, v6, 0x12

    .line 179
    .line 180
    invoke-static {v5, v7}, LX/001;->A06(II)I

    .line 181
    .line 182
    .line 183
    move-result p1

    .line 184
    const p3, 0x30000006

    .line 185
    .line 186
    .line 187
    const p4, 0x1fefffac

    .line 188
    .line 189
    .line 190
    const-wide/16 v14, 0x0

    .line 191
    .line 192
    move-object/from16 v17, v13

    .line 193
    .line 194
    move-object/from16 v19, v13

    .line 195
    .line 196
    move/from16 v21, v1

    .line 197
    .line 198
    move/from16 v22, v1

    .line 199
    .line 200
    move-object/from16 v23, v13

    .line 201
    .line 202
    move-object/from16 v24, v13

    .line 203
    .line 204
    move-object/from16 v25, v13

    .line 205
    .line 206
    move-object/from16 v26, v13

    .line 207
    .line 208
    move-object/from16 v27, v13

    .line 209
    .line 210
    move-object/from16 v28, v13

    .line 211
    .line 212
    move-wide/from16 v29, v14

    .line 213
    .line 214
    move-wide/from16 v31, v14

    .line 215
    .line 216
    move-object/from16 v33, v13

    .line 217
    .line 218
    move-object/from16 v35, v13

    .line 219
    .line 220
    move-object/from16 v36, v13

    .line 221
    .line 222
    move-object/from16 v37, v13

    .line 223
    .line 224
    move/from16 v38, v1

    .line 225
    .line 226
    move-object/from16 v39, v13

    .line 227
    .line 228
    move-object/from16 v40, v13

    .line 229
    .line 230
    move-object/from16 v41, v13

    .line 231
    .line 232
    move/from16 v42, v1

    .line 233
    .line 234
    move-object/from16 p0, v3

    .line 235
    .line 236
    move/from16 p2, v1

    .line 237
    .line 238
    move-object/from16 v18, v4

    .line 239
    .line 240
    move/from16 v20, v1

    .line 241
    .line 242
    invoke-static/range {v11 .. v48}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 243
    .line 244
    .line 245
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 246
    .line 247
    .line 248
    move-result-object v3

    .line 249
    if-eqz v3, :cond_a

    .line 250
    .line 251
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$3;

    .line 252
    .line 253
    move-object/from16 p1, v4

    .line 254
    .line 255
    move-object/from16 p2, v12

    .line 256
    .line 257
    move-object/from16 p3, v0

    .line 258
    .line 259
    move/from16 p4, v2

    .line 260
    .line 261
    move-object/from16 p0, v1

    .line 262
    .line 263
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$3;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;II)V

    .line 264
    .line 265
    .line 266
    iput-object v1, v3, LX/J7V;->A06:LX/JDN;

    .line 267
    .line 268
    :cond_a
    return-void

    .line 269
    :cond_b
    if-eqz v8, :cond_c

    .line 270
    .line 271
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 272
    .line 273
    :cond_c
    and-int/lit8 v5, p5, 0x4

    .line 274
    .line 275
    if-eqz v5, :cond_4

    .line 276
    .line 277
    invoke-static {v3}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;

    .line 282
    .line 283
    invoke-direct {v8, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;-><init>(LX/AHE;)V

    .line 284
    .line 285
    .line 286
    invoke-static {v3}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 287
    .line 288
    .line 289
    move-result-object v7

    .line 290
    if-eqz v7, :cond_10

    .line 291
    .line 292
    invoke-static {v7}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 293
    .line 294
    .line 295
    move-result-object v5

    .line 296
    const-class v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 297
    .line 298
    invoke-static {v8, v7, v5, v0}, LX/3Rq;->A05(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;)LX/1EJ;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 303
    .line 304
    goto/16 :goto_2

    .line 305
    .line 306
    :cond_d
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 307
    .line 308
    .line 309
    goto :goto_3

    .line 310
    :cond_e
    and-int/lit8 v5, p4, 0x30

    .line 311
    .line 312
    if-nez v5, :cond_0

    .line 313
    .line 314
    invoke-static {v3, v12}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 315
    .line 316
    .line 317
    move-result v5

    .line 318
    or-int/2addr v6, v5

    .line 319
    goto/16 :goto_1

    .line 320
    .line 321
    :cond_f
    move v6, v2

    .line 322
    goto/16 :goto_0

    .line 323
    .line 324
    :cond_10
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    throw v0
.end method

.method public static final ActivePermissionsScreen$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$ActivePermissionSectionHeader(Ljava/lang/String;Ljava/lang/String;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionSectionHeader(Ljava/lang/String;Ljava/lang/String;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionsContent-KhTvWYU(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionsContent-KhTvWYU(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionsList-ZUYZQmM(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionsList-ZUYZQmM(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionsList_ZUYZQmM$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$ActivePermissionsList_ZUYZQmM$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionsScreen$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p11}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$isVisibleFlatPermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->isVisibleFlatPermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final activePermissionScopeTypeLabels(LX/2d4;I)LX/0Xl;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/0Xl<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, 0x7f12017c

    .line 1
    .line 2
    .line 3
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v3

    .line 7
    const v0, 0x7f12017b

    .line 8
    .line 9
    .line 10
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const v0, 0x7f12017a

    .line 15
    .line 16
    .line 17
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    const v0, 0x7f120179

    .line 22
    .line 23
    .line 24
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    invoke-interface {p0, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {p0, v2, v5, v4, v0}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 43
    .line 44
    if-ne v1, v0, :cond_1

    .line 45
    .line 46
    :cond_0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SPACE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 47
    .line 48
    invoke-static {v0, v3}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SCHEDULE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 53
    .line 54
    invoke-static {v0, v2}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->IDEA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 59
    .line 60
    invoke-static {v0, v5}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->FEED:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 65
    .line 66
    invoke-static {v0, v4}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    filled-new-array {v3, v2, v1, v0}, [LX/IBK;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-static {v0}, LX/Dwp;->A07([LX/IBK;)LX/IZf;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    invoke-interface {p0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    :cond_1
    check-cast v1, LX/0Xl;

    .line 82
    .line 83
    return-object v1
.end method

.method public static final activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1O1;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    .line 0
    move-object/from16 v6, p3

    .line 1
    .line 2
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const-string v0, "active_permission_section_"

    .line 9
    .line 10
    invoke-static {v0, p1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;

    .line 15
    .line 16
    move-object/from16 v4, p2

    .line 17
    .line 18
    move-object/from16 v3, p10

    .line 19
    .line 20
    move/from16 v0, p11

    .line 21
    .line 22
    invoke-direct {v1, v4, v3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;-><init>(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 23
    .line 24
    .line 25
    const v0, -0x2a1cb7de

    .line 26
    .line 27
    .line 28
    const/4 v4, 0x1

    .line 29
    invoke-static {v1, v0, v4}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const-string v0, "section_header"

    .line 34
    .line 35
    invoke-interface {p0, v2, v0, v1}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 36
    .line 37
    .line 38
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$2;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$2;

    .line 39
    .line 40
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$1;

    .line 47
    .line 48
    invoke-direct {v2, v0, v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$1;-><init>(LX/JDN;Ljava/util/List;)V

    .line 49
    .line 50
    .line 51
    :goto_0
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;

    .line 52
    .line 53
    invoke-direct {v1, v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;-><init>(Ljava/util/List;)V

    .line 54
    .line 55
    .line 56
    new-instance v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;

    .line 57
    .line 58
    move-object/from16 v8, p4

    .line 59
    .line 60
    move-object/from16 v10, p5

    .line 61
    .line 62
    move-object/from16 v9, p6

    .line 63
    .line 64
    move-object/from16 v11, p7

    .line 65
    .line 66
    move-object/from16 v12, p8

    .line 67
    .line 68
    move-object/from16 v13, p9

    .line 69
    .line 70
    move-object v7, v6

    .line 71
    invoke-direct/range {v5 .. v13}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$3;-><init>(Ljava/util/List;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Ljava/lang/String;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;)V

    .line 72
    .line 73
    .line 74
    const v0, 0x799532c4

    .line 75
    .line 76
    .line 77
    invoke-static {v5, v0, v4}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-interface {p0, v2, v1, v0, v3}, LX/1O1;->APU(LX/JDM;LX/JDM;LX/JDO;I)V

    .line 82
    .line 83
    .line 84
    :cond_0
    return-void

    .line 85
    :cond_1
    const/4 v2, 0x0

    .line 86
    goto :goto_0
.end method

.method public static synthetic activePermissionSection$default(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit16 v0, p12, 0x200

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p10, 0x0

    .line 5
    :cond_0
    and-int/lit16 v0, p12, 0x400

    .line 6
    .line 7
    invoke-static {v0, p11}, LX/001;->A1P(IZ)Z

    .line 8
    .line 9
    .line 10
    move-result p11

    .line 11
    invoke-static/range {p0 .. p11}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->activePermissionSection(LX/1O1;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/JDM;Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;Ljava/lang/String;Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static final hasVisiblePermissions(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;)Z
    .locals 5

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 1
    .line 2
    const/4 v4, 0x1

    .line 3
    const/4 v3, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 7
    .line 8
    instance-of v0, v1, Ljava/util/Collection;

    .line 9
    .line 10
    if-eqz v0, :cond_4

    .line 11
    .line 12
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_4

    .line 17
    .line 18
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 19
    .line 20
    instance-of v0, v1, Ljava/util/Collection;

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    :cond_1
    return v3

    .line 31
    :cond_2
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    check-cast v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 46
    .line 47
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 48
    .line 49
    if-nez v0, :cond_3

    .line 50
    .line 51
    invoke-static {v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    return v4

    .line 58
    :cond_4
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    :cond_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_0

    .line 67
    .line 68
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    check-cast v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 73
    .line 74
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 75
    .line 76
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 77
    .line 78
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->isSupportedPermissionsScope(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_5

    .line 83
    .line 84
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->items:Ljava/util/List;

    .line 85
    .line 86
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-nez v0, :cond_5

    .line 91
    .line 92
    return v4

    .line 93
    :cond_6
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 94
    .line 95
    instance-of v0, v1, Ljava/util/Collection;

    .line 96
    .line 97
    if-eqz v0, :cond_7

    .line 98
    .line 99
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_7

    .line 104
    .line 105
    return v3

    .line 106
    :cond_7
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    :cond_8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    if-eqz v0, :cond_1

    .line 115
    .line 116
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 121
    .line 122
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->isVisibleFlatPermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_8

    .line 127
    .line 128
    return v4
.end method

.method public static final isSupportedPermissionsScope(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;)Z
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SCHEDULE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 1
    .line 2
    if-eq p0, v0, :cond_0

    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SPACE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-ne p0, v1, :cond_1

    .line 8
    .line 9
    :cond_0
    const/4 v0, 0x1

    .line 10
    :cond_1
    return v0
.end method

.method public static final isVisibleFlatPermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z
    .locals 3

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz p0, :cond_3

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 12
    .line 13
    :goto_0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->IDEA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 14
    .line 15
    if-eq v1, v0, :cond_1

    .line 16
    .line 17
    if-eqz p0, :cond_0

    .line 18
    .line 19
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 20
    .line 21
    :cond_0
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->FEED:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    if-ne v2, v1, :cond_2

    .line 25
    .line 26
    :cond_1
    const/4 v0, 0x0

    .line 27
    :cond_2
    return v0

    .line 28
    :cond_3
    move-object v1, v2

    .line 29
    goto :goto_0
.end method
