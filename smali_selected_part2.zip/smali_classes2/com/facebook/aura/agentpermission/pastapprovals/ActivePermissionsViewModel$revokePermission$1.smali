.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsViewModel$revokePermission$1"
    f = "ActivePermissionsViewModel.kt"
    l = {
        0xf0,
        0xf3
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v6, p0

    .line 3
    .line 4
    iget v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->label:I

    .line 5
    .line 6
    const/4 v4, 0x2

    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    if-eq v0, v3, :cond_3

    .line 11
    .line 12
    if-ne v0, v4, :cond_7

    .line 13
    .line 14
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    :goto_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v5

    .line 20
    :cond_1
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 24
    .line 25
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    iget-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 28
    .line 29
    :cond_2
    invoke-interface {v7}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    move-object v8, v1

    .line 34
    check-cast v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 35
    .line 36
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 37
    .line 38
    const/16 p0, 0xeff

    .line 39
    .line 40
    const/4 v9, 0x0

    .line 41
    const/4 v11, 0x0

    .line 42
    move-object v10, v9

    .line 43
    move-object v12, v9

    .line 44
    move-object v13, v9

    .line 45
    move-object v14, v9

    .line 46
    move v15, v11

    .line 47
    move/from16 v16, v11

    .line 48
    .line 49
    move-object/from16 v17, v0

    .line 50
    .line 51
    move-object/from16 v18, v9

    .line 52
    .line 53
    move/from16 v19, v11

    .line 54
    .line 55
    move-object/from16 v20, v9

    .line 56
    .line 57
    move-object/from16 p1, v9

    .line 58
    .line 59
    invoke-static/range {v8 .. v22}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-interface {v7, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_2

    .line 68
    .line 69
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 70
    .line 71
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 72
    .line 73
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 74
    .line 75
    iput v3, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->label:I

    .line 76
    .line 77
    invoke-virtual {v1, v0, v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->revokePermission-gIAlu-s(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;LX/2M4;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    if-ne v3, v5, :cond_4

    .line 82
    .line 83
    return-object v5

    .line 84
    :cond_3
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    :cond_4
    iget-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 89
    .line 90
    iget-object v1, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 91
    .line 92
    invoke-static {v3}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    if-nez v0, :cond_5

    .line 97
    .line 98
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 99
    .line 100
    iget-object v1, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 101
    .line 102
    const/4 v0, 0x0

    .line 103
    iput-object v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->L$0:Ljava/lang/Object;

    .line 104
    .line 105
    iput v4, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;->label:I

    .line 106
    .line 107
    invoke-static {v2, v3, v1, v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->access$applyRefreshedPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    if-ne v0, v5, :cond_0

    .line 112
    .line 113
    return-object v5

    .line 114
    :cond_5
    iget-object v2, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 115
    .line 116
    :cond_6
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    move-object v3, v1

    .line 121
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 122
    .line 123
    const/16 v16, 0xeff

    .line 124
    .line 125
    const/4 v4, 0x0

    .line 126
    const/4 v6, 0x0

    .line 127
    move-object v5, v4

    .line 128
    move-object v7, v4

    .line 129
    move-object v8, v4

    .line 130
    move-object v9, v4

    .line 131
    move v10, v6

    .line 132
    move v11, v6

    .line 133
    move-object v12, v4

    .line 134
    move-object v13, v4

    .line 135
    move v14, v6

    .line 136
    move-object v15, v4

    .line 137
    move-object/from16 v17, v4

    .line 138
    .line 139
    invoke-static/range {v3 .. v17}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-eqz v0, :cond_6

    .line 148
    .line 149
    goto/16 :goto_0

    .line 150
    .line 151
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    throw v0
.end method
