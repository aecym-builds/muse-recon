.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$Companion;


# instance fields
.field public final display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

.field public final kind:Ljava/lang/String;

.field public final lifetime:Ljava/lang/String;

.field public final mode:Ljava/lang/String;

.field public final mode_options:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final permissionId:Ljava/lang/String;

.field public final revocable:Z

.field public final scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

.field public final target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v7

    .line 16
    move-object v3, v2

    .line 17
    move-object v4, v2

    .line 18
    move-object v5, v2

    .line 19
    move-object v6, v2

    .line 20
    move-object v8, v2

    .line 21
    move-object v9, v2

    .line 22
    move-object v10, v2

    .line 23
    filled-new-array/range {v2 .. v10}, [Lkotlin/Lazy;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 28
    .line 29
    return-void
.end method

.method public constructor <init>()V
    .locals 9

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, ""

    .line 2
    .line 3
    const/4 v4, 0x0

    .line 4
    move-object v0, p0

    .line 5
    move-object v3, v2

    .line 6
    move-object v5, v2

    .line 7
    move-object v6, v2

    .line 8
    move-object v7, v2

    .line 9
    move-object v8, v2

    .line 10
    move-object p0, v2

    .line 11
    invoke-direct/range {v0 .. v9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;LX/5Xm;)V
    .locals 2

    .line 805306368
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 805306369
    .line 805306370
    .line 805306371
    invoke-static {p1, p2}, LX/3Rr;->A0i(ILjava/lang/String;)Ljava/lang/String;

    .line 805306372
    .line 805306373
    .line 805306374
    move-result-object v0

    .line 805306375
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 805306376
    .line 805306377
    and-int/lit8 v0, p1, 0x2

    .line 805306378
    .line 805306379
    const/4 v1, 0x0

    .line 805306380
    if-nez v0, :cond_6

    .line 805306381
    .line 805306382
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 805306383
    .line 805306384
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 805306385
    .line 805306386
    if-nez v0, :cond_5

    .line 805306387
    .line 805306388
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 805306389
    .line 805306390
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 805306391
    .line 805306392
    if-nez v0, :cond_4

    .line 805306393
    .line 805306394
    const/4 v0, 0x0

    .line 805306395
    iput-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 805306396
    .line 805306397
    :goto_2
    and-int/lit8 v0, p1, 0x10

    .line 805306398
    .line 805306399
    if-nez v0, :cond_3

    .line 805306400
    .line 805306401
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 805306402
    .line 805306403
    :goto_3
    and-int/lit8 v0, p1, 0x20

    .line 805306404
    .line 805306405
    if-nez v0, :cond_2

    .line 805306406
    .line 805306407
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 805306408
    .line 805306409
    :goto_4
    and-int/lit8 v0, p1, 0x40

    .line 805306410
    .line 805306411
    if-nez v0, :cond_1

    .line 805306412
    .line 805306413
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 805306414
    .line 805306415
    :goto_5
    and-int/lit16 v0, p1, 0x80

    .line 805306416
    .line 805306417
    if-nez v0, :cond_0

    .line 805306418
    .line 805306419
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 805306420
    .line 805306421
    :goto_6
    and-int/lit16 v0, p1, 0x100

    .line 805306422
    .line 805306423
    if-nez v0, :cond_7

    .line 805306424
    .line 805306425
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 805306426
    .line 805306427
    return-void

    .line 805306428
    :cond_0
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 805306429
    .line 805306430
    goto :goto_6

    .line 805306431
    :cond_1
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 805306432
    .line 805306433
    goto :goto_5

    .line 805306434
    :cond_2
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 805306435
    .line 805306436
    goto :goto_4

    .line 805306437
    :cond_3
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 805306438
    .line 805306439
    goto :goto_3

    .line 805306440
    :cond_4
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 805306441
    .line 805306442
    goto :goto_2

    .line 805306443
    :cond_5
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 805306444
    .line 805306445
    goto :goto_1

    .line 805306446
    :cond_6
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 805306447
    .line 805306448
    goto :goto_0

    .line 805306449
    :cond_7
    iput-object p10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 805306450
    .line 805306451
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;",
            ")V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 268435466
    .line 268435467
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 268435470
    .line 268435471
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 268435472
    .line 268435473
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 268435474
    .line 268435475
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 268435476
    .line 268435477
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 268435478
    .line 268435479
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 268435480
    .line 268435481
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;ILX/04f;)V
    .locals 2

    .line 536870912
    invoke-static {p10, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object p1

    .line 536870916
    and-int/lit8 v0, p10, 0x2

    .line 536870917
    .line 536870918
    const/4 v1, 0x0

    .line 536870919
    if-eqz v0, :cond_0

    .line 536870920
    .line 536870921
    move-object p2, v1

    .line 536870922
    :cond_0
    and-int/lit8 v0, p10, 0x4

    .line 536870923
    .line 536870924
    if-eqz v0, :cond_1

    .line 536870925
    .line 536870926
    move-object p3, v1

    .line 536870927
    :cond_1
    invoke-static {p10, p4}, LX/3Rr;->A1P(IZ)Z

    .line 536870928
    .line 536870929
    .line 536870930
    move-result p4

    .line 536870931
    and-int/lit8 v0, p10, 0x10

    .line 536870932
    .line 536870933
    if-eqz v0, :cond_2

    .line 536870934
    .line 536870935
    move-object p5, v1

    .line 536870936
    :cond_2
    and-int/lit8 v0, p10, 0x20

    .line 536870937
    .line 536870938
    if-eqz v0, :cond_3

    .line 536870939
    .line 536870940
    move-object p6, v1

    .line 536870941
    :cond_3
    and-int/lit8 v0, p10, 0x40

    .line 536870942
    .line 536870943
    if-eqz v0, :cond_4

    .line 536870944
    .line 536870945
    move-object p7, v1

    .line 536870946
    :cond_4
    and-int/lit16 v0, p10, 0x80

    .line 536870947
    .line 536870948
    if-eqz v0, :cond_5

    .line 536870949
    .line 536870950
    move-object p8, v1

    .line 536870951
    :cond_5
    and-int/lit16 v0, p10, 0x100

    .line 536870952
    .line 536870953
    if-eqz v0, :cond_6

    .line 536870954
    .line 536870955
    move-object p9, v1

    .line 536870956
    :cond_6
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V

    .line 536870957
    .line 536870958
    .line 536870959
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p10, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 53
    .line 54
    :cond_8
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0
.end method

.method public static synthetic getPermissionId$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    if-nez v4, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v2, 0x1

    .line 23
    if-nez v4, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    :cond_3
    const/4 v2, 0x2

    .line 37
    if-nez v4, :cond_4

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 40
    .line 41
    if-eqz v0, :cond_5

    .line 42
    .line 43
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 46
    .line 47
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 48
    .line 49
    .line 50
    :cond_5
    const/4 v1, 0x3

    .line 51
    if-nez v4, :cond_6

    .line 52
    .line 53
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 54
    .line 55
    if-eqz v0, :cond_7

    .line 56
    .line 57
    :cond_6
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 58
    .line 59
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 60
    .line 61
    .line 62
    :cond_7
    const/4 v2, 0x4

    .line 63
    if-nez v4, :cond_8

    .line 64
    .line 65
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 66
    .line 67
    if-eqz v0, :cond_9

    .line 68
    .line 69
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 72
    .line 73
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 74
    .line 75
    .line 76
    :cond_9
    const/4 v2, 0x5

    .line 77
    if-nez v4, :cond_a

    .line 78
    .line 79
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 80
    .line 81
    if-eqz v0, :cond_b

    .line 82
    .line 83
    :cond_a
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 88
    .line 89
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 90
    .line 91
    .line 92
    :cond_b
    const/4 v2, 0x6

    .line 93
    if-nez v4, :cond_c

    .line 94
    .line 95
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 96
    .line 97
    if-eqz v0, :cond_d

    .line 98
    .line 99
    :cond_c
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

    .line 100
    .line 101
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 102
    .line 103
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 104
    .line 105
    .line 106
    :cond_d
    const/4 v2, 0x7

    .line 107
    if-nez v4, :cond_e

    .line 108
    .line 109
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 110
    .line 111
    if-eqz v0, :cond_f

    .line 112
    .line 113
    :cond_e
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;

    .line 114
    .line 115
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 116
    .line 117
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 118
    .line 119
    .line 120
    :cond_f
    const/16 v2, 0x8

    .line 121
    .line 122
    if-nez v4, :cond_10

    .line 123
    .line 124
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 125
    .line 126
    if-eqz v0, :cond_11

    .line 127
    .line 128
    :cond_10
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 129
    .line 130
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 131
    .line 132
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 133
    .line 134
    .line 135
    :cond_11
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;",
            ")",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 41
    .line 42
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 43
    .line 44
    if-ne v1, v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_0

    .line 75
    .line 76
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 77
    .line 78
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 79
    .line 80
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_0

    .line 85
    .line 86
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 87
    .line 88
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 89
    .line 90
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-nez v0, :cond_1

    .line 95
    .line 96
    :cond_0
    return v2

    .line 97
    :cond_1
    return v3
.end method

.method public final getDisplay()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getKind()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLifetime()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode_options()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermissionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRevocable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getScope()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTarget()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    mul-int/lit8 v1, v1, 0x1f

    .line 23
    .line 24
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 40
    .line 41
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    add-int/2addr v1, v0

    .line 46
    mul-int/lit8 v1, v1, 0x1f

    .line 47
    .line 48
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 49
    .line 50
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    add-int/2addr v1, v0

    .line 55
    mul-int/lit8 v1, v1, 0x1f

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 58
    .line 59
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    add-int/2addr v1, v0

    .line 64
    mul-int/lit8 v1, v1, 0x1f

    .line 65
    .line 66
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 67
    .line 68
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    add-int/2addr v1, v0

    .line 73
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;
    .locals 12

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->permissionId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/4 v11, 0x0

    .line 7
    if-nez v0, :cond_6

    .line 8
    .line 9
    if-eqz v3, :cond_6

    .line 10
    .line 11
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind$Companion;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->kind:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    if-eqz v4, :cond_6

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 22
    .line 23
    if-eqz v0, :cond_6

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 26
    .line 27
    .line 28
    move-result-object v9

    .line 29
    if-eqz v9, :cond_6

    .line 30
    .line 31
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime$Companion;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->lifetime:Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    iget-boolean v6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->revocable:Z

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode:Ljava/lang/String;

    .line 42
    .line 43
    if-eqz v0, :cond_2

    .line 44
    .line 45
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->toConnectorPermissionModeOrNull(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 46
    .line 47
    .line 48
    move-result-object v7

    .line 49
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->mode_options:Ljava/util/List;

    .line 50
    .line 51
    if-nez v0, :cond_0

    .line 52
    .line 53
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 54
    .line 55
    :cond_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    :cond_1
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_3

    .line 68
    .line 69
    invoke-static {v1}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->toConnectorPermissionModeOrNull(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-eqz v0, :cond_1

    .line 78
    .line 79
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :cond_2
    move-object v7, v11

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    invoke-static {v2}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 86
    .line 87
    .line 88
    move-result-object v8

    .line 89
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->target:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 90
    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connectorKey()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v10

    .line 97
    :goto_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 98
    .line 99
    if-eqz v0, :cond_4

    .line 100
    .line 101
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 102
    .line 103
    .line 104
    move-result-object v11

    .line 105
    :cond_4
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 106
    .line 107
    invoke-direct/range {v2 .. v11}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;ZLcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;)V

    .line 108
    .line 109
    .line 110
    return-object v2

    .line 111
    :cond_5
    move-object v10, v11

    .line 112
    goto :goto_2

    .line 113
    :cond_6
    return-object v11
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
