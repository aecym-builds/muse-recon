.class public final synthetic Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x5

    .line 8
    const-string v0, "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionDisplayJson"

    .line 9
    .line 10
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v0, "summary_title"

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    const-string v0, "permission_caption"

    .line 21
    .line 22
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 23
    .line 24
    .line 25
    const-string v0, "icon_key"

    .line 26
    .line 27
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 28
    .line 29
    .line 30
    const-string v0, "icon_url"

    .line 31
    .line 32
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 33
    .line 34
    .line 35
    const-string v0, "mode_label"

    .line 36
    .line 37
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 38
    .line 39
    .line 40
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->descriptor:LX/Da5;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {p0, v2, v1, v0}, LX/3Rs;->A1b(LX/DZ7;LX/DZ7;LX/DZ7;LX/DZ7;)[LX/DZ7;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
    .locals 14

    .line 0
    const/4 v8, 0x0

    .line 1
    invoke-static {p1, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->descriptor:LX/Da5;

    .line 5
    .line 6
    invoke-interface {p1, v7}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 7
    .line 8
    .line 9
    move-result-object v6

    .line 10
    const/4 v5, 0x3

    .line 11
    const/4 v4, 0x4

    .line 12
    const/4 v3, 0x2

    .line 13
    const/4 v2, 0x1

    .line 14
    const/4 v10, 0x0

    .line 15
    move-object v11, v10

    .line 16
    move-object v12, v10

    .line 17
    move-object v13, v10

    .line 18
    move-object p0, v10

    .line 19
    const/4 v9, 0x0

    .line 20
    :goto_0
    invoke-interface {v6, v7}, LX/Da7;->A8S(LX/Da5;)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/4 v0, -0x1

    .line 25
    if-eq v1, v0, :cond_5

    .line 26
    .line 27
    if-eqz v1, :cond_3

    .line 28
    .line 29
    if-eq v1, v2, :cond_2

    .line 30
    .line 31
    if-eq v1, v3, :cond_1

    .line 32
    .line 33
    if-eq v1, v5, :cond_0

    .line 34
    .line 35
    if-ne v1, v4, :cond_4

    .line 36
    .line 37
    invoke-static {v7, v6, v4}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    or-int/lit8 v9, v9, 0x10

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-static {v7, v6, v5}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v13

    .line 48
    or-int/lit8 v9, v9, 0x8

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    invoke-static {v7, v6, v3}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v12

    .line 55
    or-int/lit8 v9, v9, 0x4

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    invoke-static {v7, v6, v2}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v11

    .line 62
    or-int/lit8 v9, v9, 0x2

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    invoke-static {v7, v6, v8}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    or-int/lit8 v9, v9, 0x1

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_4
    invoke-static {v1}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    throw v0

    .line 77
    :cond_5
    invoke-interface {v6, v7}, LX/Da7;->AAi(LX/Da5;)V

    .line 78
    .line 79
    .line 80
    const/4 p1, 0x0

    .line 81
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 82
    .line 83
    invoke-direct/range {v8 .. v15}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 84
    .line 85
    .line 86
    return-object v8
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
