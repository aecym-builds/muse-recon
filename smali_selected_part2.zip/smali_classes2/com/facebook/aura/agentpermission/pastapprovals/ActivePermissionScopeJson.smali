.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$Companion;


# instance fields
.field public final display_name:Ljava/lang/String;

.field public final idea_scope_id:Ljava/lang/String;

.field public final schedule_id:Ljava/lang/String;

.field public final scope_type:Ljava/lang/String;

.field public final session_scope_id:Ljava/lang/String;

.field public final space_slug:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 6

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v0, p0

    .line 2
    move-object v2, v1

    .line 3
    move-object v3, v1

    .line 4
    move-object v4, v1

    .line 5
    move-object v5, v1

    .line 6
    move-object p0, v1

    .line 7
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const/4 v1, 0x0

    .line 536870918
    if-nez v0, :cond_4

    .line 536870919
    .line 536870920
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 536870921
    .line 536870922
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    if-nez v0, :cond_3

    .line 536870925
    .line 536870926
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 536870927
    .line 536870928
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_2

    .line 536870931
    .line 536870932
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 536870933
    .line 536870934
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 536870935
    .line 536870936
    if-nez v0, :cond_1

    .line 536870937
    .line 536870938
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 536870939
    .line 536870940
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 536870941
    .line 536870942
    if-nez v0, :cond_0

    .line 536870943
    .line 536870944
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 536870945
    .line 536870946
    :goto_4
    and-int/lit8 v0, p1, 0x20

    .line 536870947
    .line 536870948
    if-nez v0, :cond_5

    .line 536870949
    .line 536870950
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 536870951
    .line 536870952
    return-void

    .line 536870953
    :cond_0
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 536870954
    .line 536870955
    goto :goto_4

    .line 536870956
    :cond_1
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 536870957
    .line 536870958
    goto :goto_3

    .line 536870959
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 536870960
    .line 536870961
    goto :goto_2

    .line 536870962
    :cond_3
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 536870963
    .line 536870964
    goto :goto_1

    .line 536870965
    :cond_4
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 536870966
    .line 536870967
    goto :goto_0

    .line 536870968
    :cond_5
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 536870969
    .line 536870970
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 268435462
    .line 268435463
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 268435464
    .line 268435465
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 268435466
    .line 268435467
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 268435470
    .line 268435471
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 805306368
    and-int/lit8 v0, p7, 0x1

    .line 805306369
    .line 805306370
    const/4 v1, 0x0

    .line 805306371
    if-eqz v0, :cond_0

    .line 805306372
    .line 805306373
    move-object p1, v1

    .line 805306374
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 805306375
    .line 805306376
    if-eqz v0, :cond_1

    .line 805306377
    .line 805306378
    move-object p2, v1

    .line 805306379
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 805306380
    .line 805306381
    if-eqz v0, :cond_2

    .line 805306382
    .line 805306383
    move-object p3, v1

    .line 805306384
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 805306385
    .line 805306386
    if-eqz v0, :cond_3

    .line 805306387
    .line 805306388
    move-object p4, v1

    .line 805306389
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 805306390
    .line 805306391
    if-eqz v0, :cond_4

    .line 805306392
    .line 805306393
    move-object p5, v1

    .line 805306394
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 805306395
    .line 805306396
    if-eqz v0, :cond_5

    .line 805306397
    .line 805306398
    move-object p6, v1

    .line 805306399
    :cond_5
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 805306400
    .line 805306401
    .line 805306402
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 7

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-object v4, p4

    .line 4
    move-object v5, p5

    .line 5
    move-object v6, p6

    .line 6
    and-int/lit8 v0, p7, 0x1

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 11
    .line 12
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 17
    .line 18
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 19
    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 23
    .line 24
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 25
    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 29
    .line 30
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 31
    .line 32
    if-eqz v0, :cond_4

    .line 33
    .line 34
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 35
    .line 36
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 37
    .line 38
    if-eqz v0, :cond_5

    .line 39
    .line 40
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 41
    .line 42
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 43
    .line 44
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v3, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    const/4 v2, 0x3

    .line 47
    if-nez v3, :cond_6

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v0, :cond_7

    .line 52
    .line 53
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_7
    const/4 v2, 0x4

    .line 61
    if-nez v3, :cond_8

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_9

    .line 66
    .line 67
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 70
    .line 71
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 72
    .line 73
    .line 74
    :cond_9
    const/4 v2, 0x5

    .line 75
    if-nez v3, :cond_a

    .line 76
    .line 77
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v0, :cond_b

    .line 80
    .line 81
    :cond_a
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 84
    .line 85
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 86
    .line 87
    .line 88
    :cond_b
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_1

    .line 69
    .line 70
    :cond_0
    return v2

    .line 71
    :cond_1
    return v3
.end method

.method public final getDisplay_name()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getIdea_scope_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSchedule_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScope_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSession_scope_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSpace_slug()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    add-int/2addr v1, v0

    .line 15
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    add-int/2addr v1, v0

    .line 24
    mul-int/lit8 v1, v1, 0x1f

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v1, v0

    .line 33
    mul-int/lit8 v1, v1, 0x1f

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 36
    .line 37
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    add-int/2addr v1, v0

    .line 42
    mul-int/lit8 v1, v1, 0x1f

    .line 43
    .line 44
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    add-int/2addr v1, v0

    .line 51
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->scope_type:Ljava/lang/String;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    const/4 v3, 0x0

    .line 9
    if-eqz v4, :cond_5

    .line 10
    .line 11
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->session_scope_id:Ljava/lang/String;

    .line 12
    .line 13
    if-eqz v2, :cond_5

    .line 14
    .line 15
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_5

    .line 20
    .line 21
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v0, 0x0

    .line 26
    if-eq v1, v0, :cond_1

    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    if-eq v1, v0, :cond_2

    .line 30
    .line 31
    const/4 v0, 0x2

    .line 32
    if-eq v1, v0, :cond_0

    .line 33
    .line 34
    const/4 v0, 0x3

    .line 35
    if-eq v1, v0, :cond_3

    .line 36
    .line 37
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    throw v0

    .line 42
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->idea_scope_id:Ljava/lang/String;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->schedule_id:Ljava/lang/String;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->space_slug:Ljava/lang/String;

    .line 49
    .line 50
    :goto_0
    if-eqz v0, :cond_5

    .line 51
    .line 52
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    return-object v3

    .line 59
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->display_name:Ljava/lang/String;

    .line 60
    .line 61
    if-eqz v1, :cond_4

    .line 62
    .line 63
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-nez v0, :cond_4

    .line 68
    .line 69
    move-object v3, v1

    .line 70
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 71
    .line 72
    invoke-direct {v0, v4, v2, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    return-object v0

    .line 76
    :cond_5
    return-object v3
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
