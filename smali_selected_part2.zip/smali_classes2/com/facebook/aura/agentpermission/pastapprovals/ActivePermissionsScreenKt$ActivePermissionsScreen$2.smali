.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$uiState$delegate:LX/16A;

    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 10

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move v4, p1

    .line 3
    move-object p1, p3

    .line 4
    if-nez v0, :cond_b

    .line 5
    .line 6
    invoke-static {p3, v4}, LX/004;->A09(LX/2d4;F)I

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    or-int/2addr v2, p4

    .line 11
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 12
    .line 13
    move v5, p2

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {p3, p2}, LX/004;->A0A(LX/2d4;F)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int/2addr v2, v0

    .line 21
    :cond_0
    invoke-static {v2}, LX/005;->A1I(I)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-static {v0, p3, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_c

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$uiState$delegate:LX/16A;

    .line 32
    .line 33
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 40
    .line 41
    invoke-interface {p3, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 46
    .line 47
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 54
    .line 55
    if-ne v6, v0, :cond_2

    .line 56
    .line 57
    :cond_1
    new-instance v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$1$1;

    .line 58
    .line 59
    invoke-direct {v6, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$1$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)V

    .line 60
    .line 61
    .line 62
    invoke-interface {p3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_2
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 66
    .line 67
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 68
    .line 69
    invoke-interface {p3, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v7

    .line 77
    if-nez v0, :cond_3

    .line 78
    .line 79
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 80
    .line 81
    if-ne v7, v0, :cond_4

    .line 82
    .line 83
    :cond_3
    new-instance v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$2$1;

    .line 84
    .line 85
    invoke-direct {v7, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$2$1;-><init>(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    invoke-interface {p3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_4
    check-cast v7, LX/DqV;

    .line 92
    .line 93
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 96
    .line 97
    invoke-interface {p3, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    if-nez v0, :cond_5

    .line 106
    .line 107
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 108
    .line 109
    if-ne v8, v0, :cond_6

    .line 110
    .line 111
    :cond_5
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$3$1;

    .line 112
    .line 113
    invoke-direct {v8, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$3$1;-><init>(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    invoke-interface {p3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_6
    check-cast v8, LX/DqV;

    .line 120
    .line 121
    check-cast v8, LX/JDM;

    .line 122
    .line 123
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 124
    .line 125
    invoke-interface {p3, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v9

    .line 133
    if-nez v0, :cond_7

    .line 134
    .line 135
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 136
    .line 137
    if-ne v9, v0, :cond_8

    .line 138
    .line 139
    :cond_7
    new-instance v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$4$1;

    .line 140
    .line 141
    invoke-direct {v9, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$4$1;-><init>(Ljava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    invoke-interface {p3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :cond_8
    check-cast v9, LX/DqV;

    .line 148
    .line 149
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 150
    .line 151
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2;->$viewModel:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 152
    .line 153
    invoke-interface {p3, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    if-nez v0, :cond_9

    .line 162
    .line 163
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 164
    .line 165
    if-ne p0, v0, :cond_a

    .line 166
    .line 167
    :cond_9
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$5$1;

    .line 168
    .line 169
    invoke-direct {p0, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsScreen$2$5$1;-><init>(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    invoke-interface {p3, p0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 173
    .line 174
    .line 175
    :cond_a
    check-cast p0, LX/DqV;

    .line 176
    .line 177
    check-cast p0, LX/JDN;

    .line 178
    .line 179
    sget v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->$stable:I

    .line 180
    .line 181
    shl-int/lit8 v0, v2, 0x3

    .line 182
    .line 183
    invoke-static {v0, v1}, LX/002;->A0B(II)I

    .line 184
    .line 185
    .line 186
    move-result p2

    .line 187
    invoke-static/range {v3 .. v12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionsContent-KhTvWYU(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;FFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;I)V

    .line 188
    .line 189
    .line 190
    return-void

    .line 191
    :cond_b
    move v2, p4

    .line 192
    goto/16 :goto_0

    .line 193
    .line 194
    :cond_c
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 195
    .line 196
    .line 197
    return-void
.end method
