.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $addTopSpacing:Z

.field public final synthetic $title:Ljava/lang/String;

.field public final synthetic $trailingLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$trailingLabel:Ljava/lang/String;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$addTopSpacing:Z

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->invoke(LX/1Xg;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 3

    .line 268435456
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object p1, p2

    .line 268435461
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$title:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$trailingLabel:Ljava/lang/String;

    .line 268435470
    .line 268435471
    iget-boolean v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$1;->$addTopSpacing:Z

    .line 268435472
    .line 268435473
    const/4 p0, 0x0

    .line 268435474
    const/4 p2, 0x0

    .line 268435475
    const/16 p3, 0x8

    .line 268435476
    .line 268435477
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt;->ActivePermissionSectionHeader(Ljava/lang/String;Ljava/lang/String;ZLX/3C1;LX/2d4;II)V

    .line 268435478
    .line 268435479
    .line 268435480
    return-void

    .line 268435481
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435482
    .line 268435483
    .line 268435484
    return-void
.end method
