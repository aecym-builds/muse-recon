.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson$Companion;


# instance fields
.field public final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation
.end field

.field public final nextCursor:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson$Companion;

    .line 6
    .line 7
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson$Companion$$childSerializers$1;

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/3Rr;->A1Y(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)[Lkotlin/Lazy;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->$childSerializers:[Lkotlin/Lazy;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/util/List;Ljava/lang/String;LX/5Xm;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    invoke-static {p2, p1}, LX/3Rp;->A0z(Ljava/util/List;I)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 8
    .line 9
    and-int/lit8 v0, p1, 0x2

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 268435466
    .line 268435467
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 536870912
    invoke-static {p1, p3}, LX/3Rr;->A0s(Ljava/util/List;I)Ljava/util/List;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object v1

    .line 536870916
    invoke-static {p3, p2}, LX/3Rr;->A0e(ILjava/lang/String;)Ljava/lang/String;

    .line 536870917
    .line 536870918
    .line 536870919
    move-result-object v0

    .line 536870920
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 536870921
    .line 536870922
    .line 536870923
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;Ljava/util/List;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public static synthetic getNextCursor$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    invoke-static {v1, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 24
    .line 25
    .line 26
    :cond_1
    const/4 v2, 0x1

    .line 27
    if-nez v3, :cond_2

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v0, :cond_3

    .line 32
    .line 33
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 36
    .line 37
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/util/List;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getItems()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getNextCursor()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    return v1
.end method

.method public final toApprovalsDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->items:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 21
    .line 22
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    :cond_2
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    move-object v0, v1

    .line 51
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 52
    .line 53
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->isVisibleInApprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_2

    .line 58
    .line 59
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->nextCursor:Ljava/lang/String;

    .line 64
    .line 65
    const/4 v1, 0x0

    .line 66
    if-eqz v2, :cond_4

    .line 67
    .line 68
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-nez v0, :cond_4

    .line 73
    .line 74
    :goto_2
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 75
    .line 76
    invoke-direct {v0, v3, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-object v0

    .line 80
    :cond_4
    move-object v2, v1

    .line 81
    goto :goto_2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
