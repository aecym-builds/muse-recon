.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsViewModel$resetPermissions$1"
    f = "ActivePermissionsViewModel.kt"
    l = {
        0x10c,
        0x10e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v5, p0

    .line 3
    .line 4
    iget v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->label:I

    .line 5
    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v6, 0x1

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    if-eq v0, v6, :cond_3

    .line 11
    .line 12
    if-ne v0, v3, :cond_7

    .line 13
    .line 14
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    :goto_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v4

    .line 20
    :cond_1
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 24
    .line 25
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    :cond_2
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    move-object v7, v1

    .line 32
    check-cast v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 33
    .line 34
    const/16 p0, 0xbff

    .line 35
    .line 36
    const/4 v8, 0x0

    .line 37
    const/4 v10, 0x0

    .line 38
    move-object v9, v8

    .line 39
    move-object v11, v8

    .line 40
    move-object v12, v8

    .line 41
    move-object v13, v8

    .line 42
    move v14, v10

    .line 43
    move v15, v10

    .line 44
    move-object/from16 v16, v8

    .line 45
    .line 46
    move-object/from16 v17, v8

    .line 47
    .line 48
    move/from16 v18, v6

    .line 49
    .line 50
    move-object/from16 v19, v8

    .line 51
    .line 52
    move-object/from16 p1, v8

    .line 53
    .line 54
    invoke-static/range {v7 .. v21}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_2

    .line 63
    .line 64
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 65
    .line 66
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 67
    .line 68
    iput v6, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->label:I

    .line 69
    .line 70
    invoke-virtual {v0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->resetPermissions-IoAF18A(LX/2M4;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    if-ne v2, v4, :cond_4

    .line 75
    .line 76
    return-object v4

    .line 77
    :cond_3
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    :cond_4
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 82
    .line 83
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    if-nez v0, :cond_5

    .line 88
    .line 89
    check-cast v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 90
    .line 91
    const/4 v0, 0x0

    .line 92
    iput-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->L$0:Ljava/lang/Object;

    .line 93
    .line 94
    iput v3, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;->label:I

    .line 95
    .line 96
    invoke-static {v1, v2, v0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->access$applyRefreshedPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-ne v0, v4, :cond_0

    .line 101
    .line 102
    return-object v4

    .line 103
    :cond_5
    iget-object v2, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 104
    .line 105
    :cond_6
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    move-object v3, v1

    .line 110
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 111
    .line 112
    const/16 v16, 0xbff

    .line 113
    .line 114
    const/4 v4, 0x0

    .line 115
    const/4 v6, 0x0

    .line 116
    move-object v5, v4

    .line 117
    move-object v7, v4

    .line 118
    move-object v8, v4

    .line 119
    move-object v9, v4

    .line 120
    move v10, v6

    .line 121
    move v11, v6

    .line 122
    move-object v12, v4

    .line 123
    move-object v13, v4

    .line 124
    move v14, v6

    .line 125
    move-object v15, v4

    .line 126
    move-object/from16 v17, v4

    .line 127
    .line 128
    invoke-static/range {v3 .. v17}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_6

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    throw v0
.end method
