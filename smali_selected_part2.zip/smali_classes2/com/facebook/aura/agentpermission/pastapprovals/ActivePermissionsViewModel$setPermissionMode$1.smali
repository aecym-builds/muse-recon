.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsViewModel$setPermissionMode$1"
    f = "ActivePermissionsViewModel.kt"
    l = {
        0xdb,
        0xde
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

.field public final synthetic $permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v5, p0

    .line 3
    .line 4
    iget v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->label:I

    .line 5
    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v6, 0x1

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    if-eq v0, v6, :cond_3

    .line 11
    .line 12
    if-ne v0, v3, :cond_6

    .line 13
    .line 14
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v4

    .line 20
    :cond_1
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 24
    .line 25
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    iget-object v2, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 28
    .line 29
    :cond_2
    invoke-interface {v7}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    move-object v8, v1

    .line 34
    check-cast v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 35
    .line 36
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 37
    .line 38
    const/16 p0, 0xdff

    .line 39
    .line 40
    const/4 v9, 0x0

    .line 41
    const/4 v11, 0x0

    .line 42
    move-object v10, v9

    .line 43
    move-object v12, v9

    .line 44
    move-object v13, v9

    .line 45
    move-object v14, v9

    .line 46
    move v15, v11

    .line 47
    move/from16 v16, v11

    .line 48
    .line 49
    move-object/from16 v17, v9

    .line 50
    .line 51
    move-object/from16 v18, v0

    .line 52
    .line 53
    move/from16 v19, v11

    .line 54
    .line 55
    move-object/from16 v20, v9

    .line 56
    .line 57
    move-object/from16 p1, v9

    .line 58
    .line 59
    invoke-static/range {v8 .. v22}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-interface {v7, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_2

    .line 68
    .line 69
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 70
    .line 71
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 72
    .line 73
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 74
    .line 75
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 76
    .line 77
    iput v6, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->label:I

    .line 78
    .line 79
    invoke-virtual {v2, v1, v0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->setPermissionMode-0E7RQCE(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2M4;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-ne v0, v4, :cond_4

    .line 84
    .line 85
    return-object v4

    .line 86
    :cond_3
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    :cond_4
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    if-eqz v0, :cond_5

    .line 95
    .line 96
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 97
    .line 98
    const v0, 0x7f1201a1

    .line 99
    .line 100
    .line 101
    invoke-virtual {v1, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 102
    .line 103
    .line 104
    :cond_5
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 105
    .line 106
    iput v3, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;->label:I

    .line 107
    .line 108
    invoke-static {v0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->access$loadFirstPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    if-ne v0, v4, :cond_0

    .line 113
    .line 114
    return-object v4

    .line 115
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    throw v0
.end method
