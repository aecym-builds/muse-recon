.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsRepository$getActivePermissions$2"
    f = "ActivePermissionsRepository.kt"
    l = {
        0x97
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $cursor:Ljava/lang/String;

.field public final synthetic $limit:I

.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;ILjava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;",
            "I",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$limit:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$cursor:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$limit:I

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$cursor:Ljava/lang/String;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;ILjava/lang/String;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v3, p0

    .line 3
    .line 4
    iget v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->label:I

    .line 5
    .line 6
    const/4 v14, 0x1

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-ne v0, v14, :cond_4

    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    :cond_0
    instance-of v0, v1, LX/2PH;

    .line 16
    .line 17
    xor-int/lit8 v0, v0, 0x1

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    check-cast v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 22
    .line 23
    invoke-virtual {v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->toApprovalsDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    :cond_1
    invoke-static {v1}, LX/3Rp;->A12(Ljava/lang/Object;)LX/2PJ;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    return-object v2

    .line 32
    :cond_2
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$limit:I

    .line 36
    .line 37
    iget-object v5, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->$cursor:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    const-string v1, "limit"

    .line 44
    .line 45
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 50
    .line 51
    .line 52
    const-string v1, "lifetime"

    .line 53
    .line 54
    const-string v0, "durable,today"

    .line 55
    .line 56
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 57
    .line 58
    .line 59
    const-string v1, "target_type"

    .line 60
    .line 61
    const-string v0, "network"

    .line 62
    .line 63
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 64
    .line 65
    .line 66
    const-string v1, "kind"

    .line 67
    .line 68
    const-string v0, "network_rule,transient_network_grant"

    .line 69
    .line 70
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 71
    .line 72
    .line 73
    if-eqz v5, :cond_3

    .line 74
    .line 75
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-nez v0, :cond_3

    .line 80
    .line 81
    const-string v0, "cursor"

    .line 82
    .line 83
    invoke-static {v0, v5, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 84
    .line 85
    .line 86
    :cond_3
    invoke-static {v4}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    const/4 v6, 0x0

    .line 91
    invoke-static {v0}, LX/3Rr;->A1Z(Ljava/util/AbstractCollection;)[LX/IBK;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 96
    .line 97
    sget-object v7, Lcom/facebook/aura/network/api/JarvisPath$PermissionsActive;->INSTANCE:Lcom/facebook/aura/network/api/JarvisPath$PermissionsActive;

    .line 98
    .line 99
    sget-object v8, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 100
    .line 101
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 102
    .line 103
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->userSession:LX/AHE;

    .line 104
    .line 105
    invoke-static {v1}, LX/3Rr;->A1a([LX/IBK;)[LX/IBK;

    .line 106
    .line 107
    .line 108
    move-result-object v11

    .line 109
    invoke-static {}, LX/3Rq;->A1F()Ljava/util/Set;

    .line 110
    .line 111
    .line 112
    move-result-object v13

    .line 113
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 114
    .line 115
    .line 116
    move-result-object v15

    .line 117
    sget-object v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2$invokeSuspend$$inlined$executeJarvisRequest-5dDjBWM$default$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2$invokeSuspend$$inlined$executeJarvisRequest-5dDjBWM$default$1;

    .line 118
    .line 119
    const/4 v10, 0x0

    .line 120
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$0:Ljava/lang/Object;

    .line 121
    .line 122
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$1:Ljava/lang/Object;

    .line 123
    .line 124
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$2:Ljava/lang/Object;

    .line 125
    .line 126
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$3:Ljava/lang/Object;

    .line 127
    .line 128
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$4:Ljava/lang/Object;

    .line 129
    .line 130
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$5:Ljava/lang/Object;

    .line 131
    .line 132
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$6:Ljava/lang/Object;

    .line 133
    .line 134
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->L$7:Ljava/lang/Object;

    .line 135
    .line 136
    iput v14, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->I$0:I

    .line 137
    .line 138
    iput v14, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->I$1:I

    .line 139
    .line 140
    iput v6, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->I$2:I

    .line 141
    .line 142
    iput v6, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->I$3:I

    .line 143
    .line 144
    iput v14, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$getActivePermissions$2;->label:I

    .line 145
    .line 146
    move-object v12, v10

    .line 147
    move/from16 v16, v14

    .line 148
    .line 149
    move-object/from16 v17, v10

    .line 150
    .line 151
    move/from16 v18, v6

    .line 152
    .line 153
    move/from16 p0, v6

    .line 154
    .line 155
    move-object/from16 p1, v3

    .line 156
    .line 157
    invoke-virtual/range {v4 .. v20}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessJarvisRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/JarvisPath;Lcom/facebook/aura/network/http/RequestType;LX/AHE;Ljava/lang/Long;[LX/IBK;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;Ljava/util/Set;ZLjava/util/Map;ZLjava/lang/String;ZZLX/2M4;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    if-ne v1, v2, :cond_0

    .line 162
    .line 163
    return-object v2

    .line 164
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    throw v0
.end method
