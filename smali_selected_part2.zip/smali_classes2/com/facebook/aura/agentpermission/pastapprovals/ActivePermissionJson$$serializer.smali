.class public final synthetic Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x9

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionJson"

    .line 10
    .line 11
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v0, "permission_id"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "kind"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "lifetime"

    .line 27
    .line 28
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    const-string v0, "revocable"

    .line 32
    .line 33
    invoke-static {v0, v2, v1}, LX/3Rr;->A1C(Ljava/lang/String;LX/DZp;Z)V

    .line 34
    .line 35
    .line 36
    const-string v0, "mode_options"

    .line 37
    .line 38
    invoke-static {v0, v2}, LX/3Rp;->A1H(Ljava/lang/String;LX/DZp;)V

    .line 39
    .line 40
    .line 41
    const-string v0, "target"

    .line 42
    .line 43
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 44
    .line 45
    .line 46
    const-string v0, "scope"

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 49
    .line 50
    .line 51
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->descriptor:LX/Da5;

    .line 52
    .line 53
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    sget-object v2, LX/DYp;->A01:LX/DYp;

    .line 3
    .line 4
    invoke-static {v2}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    invoke-static {v2}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    sget-object v5, LX/DYz;->A00:LX/DYz;

    .line 13
    .line 14
    invoke-static {v2}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 15
    .line 16
    .line 17
    move-result-object v6

    .line 18
    const/4 v0, 0x5

    .line 19
    invoke-static {v1, v0}, LX/3Rq;->A1P([Lkotlin/Lazy;I)LX/DZ7;

    .line 20
    .line 21
    .line 22
    move-result-object v7

    .line 23
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

    .line 24
    .line 25
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 26
    .line 27
    .line 28
    move-result-object v8

    .line 29
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;

    .line 30
    .line 31
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 32
    .line 33
    .line 34
    move-result-object v9

    .line 35
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 36
    .line 37
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    filled-new-array/range {v2 .. v10}, [LX/DZ7;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;
    .locals 18

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v4}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    sget-object v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->$childSerializers:[Lkotlin/Lazy;

    .line 13
    .line 14
    const/4 v7, 0x7

    .line 15
    const/16 v2, 0x8

    .line 16
    .line 17
    const/16 v16, 0x0

    .line 18
    .line 19
    move-object/from16 v17, v16

    .line 20
    .line 21
    move-object/from16 v15, v16

    .line 22
    .line 23
    move-object/from16 p0, v15

    .line 24
    .line 25
    move-object v14, v15

    .line 26
    move-object v12, v15

    .line 27
    move-object v10, v15

    .line 28
    move-object v11, v15

    .line 29
    const/4 v13, 0x0

    .line 30
    const/4 v9, 0x0

    .line 31
    const/4 v1, 0x5

    .line 32
    :goto_0
    invoke-interface {v3, v4}, LX/Da7;->A8S(LX/Da5;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    packed-switch v0, :pswitch_data_0

    .line 37
    .line 38
    .line 39
    invoke-static {v0}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    throw v0

    .line 44
    :pswitch_0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 45
    .line 46
    invoke-interface {v3, v0, v4, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    check-cast p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 51
    .line 52
    or-int/lit16 v9, v9, 0x100

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :pswitch_1
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$$serializer;

    .line 56
    .line 57
    invoke-interface {v3, v0, v4, v7}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v17

    .line 61
    check-cast v17, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 62
    .line 63
    or-int/lit16 v9, v9, 0x80

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :pswitch_2
    sget-object v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$$serializer;

    .line 67
    .line 68
    const/4 v0, 0x6

    .line 69
    invoke-interface {v3, v6, v4, v0}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v16

    .line 73
    check-cast v16, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 74
    .line 75
    or-int/lit8 v9, v9, 0x40

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :pswitch_3
    invoke-static {v4, v3, v8, v1}, LX/3Rs;->A0J(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v15

    .line 82
    check-cast v15, Ljava/util/List;

    .line 83
    .line 84
    or-int/lit8 v9, v9, 0x20

    .line 85
    .line 86
    goto :goto_0

    .line 87
    :pswitch_4
    invoke-static {v4, v3}, LX/3Rs;->A0W(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v14

    .line 91
    or-int/lit8 v9, v9, 0x10

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :pswitch_5
    const/4 v0, 0x3

    .line 95
    invoke-interface {v3, v4, v0}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 96
    .line 97
    .line 98
    move-result v13

    .line 99
    or-int/lit8 v9, v9, 0x8

    .line 100
    .line 101
    goto :goto_0

    .line 102
    :pswitch_6
    invoke-static {v4, v3}, LX/3Rs;->A0U(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v12

    .line 106
    or-int/lit8 v9, v9, 0x4

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :pswitch_7
    invoke-static {v4, v3}, LX/3Rs;->A0T(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v11

    .line 113
    or-int/lit8 v9, v9, 0x2

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :pswitch_8
    invoke-interface {v3, v4, v5}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v10

    .line 120
    or-int/lit8 v9, v9, 0x1

    .line 121
    .line 122
    goto :goto_0

    .line 123
    :pswitch_9
    invoke-interface {v3, v4}, LX/Da7;->AAi(LX/Da5;)V

    .line 124
    .line 125
    .line 126
    const/16 p1, 0x0

    .line 127
    .line 128
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 129
    .line 130
    invoke-direct/range {v8 .. v19}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;LX/5Xm;)V

    .line 131
    .line 132
    .line 133
    return-object v8

    .line 134
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
