.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$Companion;


# instance fields
.field public final connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

.field public final type:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 805306368
    const/4 v0, 0x0

    .line 805306369
    invoke-direct {p0, v0, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)V

    .line 805306370
    .line 805306371
    .line 805306372
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;LX/5Xm;)V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    and-int/lit8 v0, p1, 0x1

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 9
    .line 10
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 268435460
    .line 268435461
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 268435462
    .line 268435463
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p3, 0x1

    .line 536870913
    .line 536870914
    const/4 v1, 0x0

    .line 536870915
    if-eqz v0, :cond_0

    .line 536870916
    .line 536870917
    move-object p1, v1

    .line 536870918
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    move-object p2, v1

    .line 536870923
    :cond_1
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)V

    .line 536870924
    .line 536870925
    .line 536870926
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 11
    .line 12
    :cond_1
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 13
    .line 14
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v3, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson$$serializer;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final connectorKey()Ljava/lang/String;
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    const-string v0, "connector"

    .line 3
    .line 4
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;->key:Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    return-object v1

    .line 26
    :cond_0
    return-object v2
.end method

.method public final copy(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getConnector()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getType()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionTargetJson;->connector:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionConnectorTargetJson;

    .line 9
    .line 10
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    add-int/2addr v1, v0

    .line 15
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
