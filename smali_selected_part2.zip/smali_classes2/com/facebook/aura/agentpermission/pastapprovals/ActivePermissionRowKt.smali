.class public abstract Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ActivePermissionAction(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;ZZZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    const v0, 0x4a838d60    # 4310704.0f

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p12

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v0, p13

    .line 9
    .line 10
    and-int/lit8 v2, p13, 0x6

    .line 11
    .line 12
    move-object/from16 p13, p0

    .line 13
    .line 14
    if-nez v2, :cond_12

    .line 15
    .line 16
    move-object/from16 v2, p13

    .line 17
    .line 18
    invoke-static {v1, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v14

    .line 22
    or-int/2addr v14, v0

    .line 23
    :goto_0
    and-int/lit8 v2, v0, 0x30

    .line 24
    .line 25
    const/16 v12, 0x10

    .line 26
    .line 27
    move-object/from16 v6, p1

    .line 28
    .line 29
    if-nez v2, :cond_0

    .line 30
    .line 31
    invoke-static {v1, v6}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    or-int/2addr v14, v2

    .line 36
    :cond_0
    and-int/lit16 v2, v0, 0x180

    .line 37
    .line 38
    move-object/from16 p12, p2

    .line 39
    .line 40
    if-nez v2, :cond_1

    .line 41
    .line 42
    invoke-static/range {p12 .. p12}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    invoke-static {v1, v2}, LX/004;->A0G(LX/2d4;I)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    or-int/2addr v14, v2

    .line 51
    :cond_1
    and-int/lit16 v2, v0, 0xc00

    .line 52
    .line 53
    move-object/from16 v15, p3

    .line 54
    .line 55
    if-nez v2, :cond_2

    .line 56
    .line 57
    invoke-static {v1, v15}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    or-int/2addr v14, v2

    .line 62
    :cond_2
    and-int/lit16 v2, v0, 0x6000

    .line 63
    .line 64
    move/from16 v5, p4

    .line 65
    .line 66
    if-nez v2, :cond_3

    .line 67
    .line 68
    invoke-static {v1, v5}, LX/004;->A0m(LX/2d4;Z)I

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    or-int/2addr v14, v2

    .line 73
    :cond_3
    const/high16 v2, 0x30000

    .line 74
    .line 75
    and-int/2addr v2, v0

    .line 76
    move/from16 v10, p5

    .line 77
    .line 78
    if-nez v2, :cond_4

    .line 79
    .line 80
    invoke-static {v1, v10}, LX/004;->A0n(LX/2d4;Z)I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    or-int/2addr v14, v2

    .line 85
    :cond_4
    const/high16 v2, 0x180000

    .line 86
    .line 87
    and-int/2addr v2, v0

    .line 88
    move/from16 v9, p6

    .line 89
    .line 90
    if-nez v2, :cond_5

    .line 91
    .line 92
    invoke-static {v1, v9}, LX/004;->A0o(LX/2d4;Z)I

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    or-int/2addr v14, v2

    .line 97
    :cond_5
    const/high16 v2, 0xc00000

    .line 98
    .line 99
    and-int/2addr v2, v0

    .line 100
    move/from16 v8, p7

    .line 101
    .line 102
    if-nez v2, :cond_6

    .line 103
    .line 104
    invoke-static {v1, v8}, LX/004;->A0p(LX/2d4;Z)I

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    or-int/2addr v14, v2

    .line 109
    :cond_6
    const/high16 v2, 0x6000000

    .line 110
    .line 111
    and-int/2addr v2, v0

    .line 112
    move-object/from16 v7, p8

    .line 113
    .line 114
    if-nez v2, :cond_7

    .line 115
    .line 116
    invoke-static {v1, v7}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    or-int/2addr v14, v2

    .line 121
    :cond_7
    const/high16 v2, 0x30000000

    .line 122
    .line 123
    and-int/2addr v2, v0

    .line 124
    move-object/from16 v4, p9

    .line 125
    .line 126
    if-nez v2, :cond_8

    .line 127
    .line 128
    invoke-static {v1, v4}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    .line 129
    .line 130
    .line 131
    move-result v2

    .line 132
    or-int/2addr v14, v2

    .line 133
    :cond_8
    and-int/lit8 v2, p14, 0x6

    .line 134
    .line 135
    move-object/from16 v3, p10

    .line 136
    .line 137
    if-nez v2, :cond_11

    .line 138
    .line 139
    invoke-static {v1, v3}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    or-int p2, p14, v2

    .line 144
    .line 145
    :goto_1
    and-int/lit8 v11, p14, 0x30

    .line 146
    .line 147
    move-object/from16 v2, p11

    .line 148
    .line 149
    if-nez v11, :cond_a

    .line 150
    .line 151
    invoke-interface {v1, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v11

    .line 155
    if-eqz v11, :cond_9

    .line 156
    .line 157
    const/16 v12, 0x20

    .line 158
    .line 159
    :cond_9
    or-int p2, p2, v12

    .line 160
    .line 161
    :cond_a
    const v11, 0x12492493

    .line 162
    .line 163
    .line 164
    and-int v12, v14, v11

    .line 165
    .line 166
    const v11, 0x12492492

    .line 167
    .line 168
    .line 169
    if-ne v12, v11, :cond_b

    .line 170
    .line 171
    and-int/lit8 v13, p2, 0x13

    .line 172
    .line 173
    const/16 v12, 0x12

    .line 174
    .line 175
    const/4 v11, 0x0

    .line 176
    if-eq v13, v12, :cond_c

    .line 177
    .line 178
    :cond_b
    const/4 v11, 0x1

    .line 179
    :cond_c
    invoke-static {v11, v1, v14}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 180
    .line 181
    .line 182
    move-result v11

    .line 183
    if-eqz v11, :cond_10

    .line 184
    .line 185
    invoke-interface {v15}, Ljava/util/List;->isEmpty()Z

    .line 186
    .line 187
    .line 188
    move-result v11

    .line 189
    const/high16 p1, 0x70000000

    .line 190
    .line 191
    const/high16 p0, 0xe000000

    .line 192
    .line 193
    const/high16 v13, 0x1c00000

    .line 194
    .line 195
    if-nez v11, :cond_e

    .line 196
    .line 197
    const v11, -0x482a0f4c

    .line 198
    .line 199
    .line 200
    invoke-interface {v1, v11}, LX/2d4;->Agj(I)V

    .line 201
    .line 202
    .line 203
    and-int/lit16 v11, v14, 0x1ffe

    .line 204
    .line 205
    shr-int/lit8 v12, v14, 0x3

    .line 206
    .line 207
    invoke-static {v12, v11}, LX/3Rs;->A01(II)I

    .line 208
    .line 209
    .line 210
    move-result p9

    .line 211
    and-int v11, v12, v13

    .line 212
    .line 213
    or-int p9, p9, v11

    .line 214
    .line 215
    and-int v12, v12, p0

    .line 216
    .line 217
    or-int p9, p9, v12

    .line 218
    .line 219
    shl-int/lit8 v11, p2, 0x1b

    .line 220
    .line 221
    and-int p1, p1, v11

    .line 222
    .line 223
    or-int p9, p9, p1

    .line 224
    .line 225
    const/16 p10, 0x0

    .line 226
    .line 227
    const/16 p11, 0xc00

    .line 228
    .line 229
    const/16 p6, 0x0

    .line 230
    .line 231
    move-object/from16 p7, p6

    .line 232
    .line 233
    move-object/from16 p8, v1

    .line 234
    .line 235
    move/from16 p1, v9

    .line 236
    .line 237
    move/from16 p2, v8

    .line 238
    .line 239
    move-object/from16 p3, v7

    .line 240
    .line 241
    move-object/from16 p4, v4

    .line 242
    .line 243
    move-object/from16 p5, v3

    .line 244
    .line 245
    move-object/from16 v12, p13

    .line 246
    .line 247
    move-object v13, v6

    .line 248
    move-object/from16 v14, p12

    .line 249
    .line 250
    move/from16 p0, v10

    .line 251
    .line 252
    invoke-static/range {v12 .. v27}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeControl(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 253
    .line 254
    .line 255
    :goto_2
    invoke-static {v1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 259
    .line 260
    .line 261
    move-result-object v11

    .line 262
    if-eqz v11, :cond_d

    .line 263
    .line 264
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;

    .line 265
    .line 266
    move-object/from16 p0, v1

    .line 267
    .line 268
    move-object/from16 p1, p13

    .line 269
    .line 270
    move-object/from16 p2, v6

    .line 271
    .line 272
    move-object/from16 p3, p12

    .line 273
    .line 274
    move-object/from16 p4, v15

    .line 275
    .line 276
    move/from16 p5, v5

    .line 277
    .line 278
    move/from16 p6, v10

    .line 279
    .line 280
    move/from16 p7, v9

    .line 281
    .line 282
    move/from16 p8, v8

    .line 283
    .line 284
    move-object/from16 p9, v7

    .line 285
    .line 286
    move-object/from16 p10, v4

    .line 287
    .line 288
    move-object/from16 p11, v3

    .line 289
    .line 290
    move-object/from16 p12, v2

    .line 291
    .line 292
    move/from16 p13, v0

    .line 293
    .line 294
    invoke-direct/range {p0 .. p14}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionAction$1;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;II)V

    .line 295
    .line 296
    .line 297
    iput-object v1, v11, LX/J7V;->A06:LX/JDN;

    .line 298
    .line 299
    :cond_d
    return-void

    .line 300
    :cond_e
    if-eqz p4, :cond_f

    .line 301
    .line 302
    const v11, 0x42ee8bd7

    .line 303
    .line 304
    .line 305
    invoke-interface {v1, v11}, LX/2d4;->Agj(I)V

    .line 306
    .line 307
    .line 308
    and-int/lit16 v11, v14, 0x1ffe

    .line 309
    .line 310
    shr-int/lit8 v12, v14, 0x3

    .line 311
    .line 312
    invoke-static {v12, v11}, LX/3Rs;->A01(II)I

    .line 313
    .line 314
    .line 315
    move-result p9

    .line 316
    and-int v11, v12, v13

    .line 317
    .line 318
    or-int p9, p9, v11

    .line 319
    .line 320
    and-int v12, v12, p0

    .line 321
    .line 322
    or-int p9, p9, v12

    .line 323
    .line 324
    shl-int/lit8 v11, p2, 0x1b

    .line 325
    .line 326
    and-int v11, v11, p1

    .line 327
    .line 328
    or-int p9, p9, v11

    .line 329
    .line 330
    shr-int/lit8 v11, p2, 0x3

    .line 331
    .line 332
    and-int/lit8 p10, v11, 0xe

    .line 333
    .line 334
    const/16 p11, 0x800

    .line 335
    .line 336
    const/16 p7, 0x0

    .line 337
    .line 338
    move-object/from16 v12, p13

    .line 339
    .line 340
    move-object v13, v6

    .line 341
    move-object/from16 v14, p12

    .line 342
    .line 343
    move/from16 p0, v10

    .line 344
    .line 345
    move/from16 p1, v9

    .line 346
    .line 347
    move/from16 p2, v8

    .line 348
    .line 349
    move-object/from16 p3, v7

    .line 350
    .line 351
    move-object/from16 p4, v4

    .line 352
    .line 353
    move-object/from16 p5, v3

    .line 354
    .line 355
    move-object/from16 p6, v2

    .line 356
    .line 357
    move-object/from16 p8, v1

    .line 358
    .line 359
    invoke-static/range {v12 .. v27}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeControl(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 360
    .line 361
    .line 362
    goto :goto_2

    .line 363
    :cond_f
    const v11, -0x4829a4e7

    .line 364
    .line 365
    .line 366
    invoke-interface {v1, v11}, LX/2d4;->Agj(I)V

    .line 367
    .line 368
    .line 369
    shr-int/lit8 v11, v14, 0x3

    .line 370
    .line 371
    and-int/lit8 v12, v11, 0x7e

    .line 372
    .line 373
    move-object/from16 v11, p12

    .line 374
    .line 375
    invoke-static {v6, v11, v1, v12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeLabel(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)V

    .line 376
    .line 377
    .line 378
    goto :goto_2

    .line 379
    :cond_10
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 380
    .line 381
    .line 382
    goto :goto_3

    .line 383
    :cond_11
    move/from16 p2, p14

    .line 384
    .line 385
    goto/16 :goto_1

    .line 386
    .line 387
    :cond_12
    move v14, v0

    .line 388
    goto/16 :goto_0
.end method

.method public static final ActivePermissionActionSpinner(LX/2d4;I)V
    .locals 4

    .line 0
    const v0, -0x7423c223    # -8.4834E-32f

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_3

    .line 15
    .line 16
    const v0, 0x7f120189

    .line 17
    .line 18
    .line 19
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 24
    .line 25
    const/high16 v0, 0x41a00000    # 20.0f

    .line 26
    .line 27
    invoke-static {v1, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-interface {p0, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v1, :cond_0

    .line 40
    .line 41
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 42
    .line 43
    if-ne v0, v1, :cond_1

    .line 44
    .line 45
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionActionSpinner$1$1;

    .line 46
    .line 47
    invoke-direct {v0, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionActionSpinner$1$1;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    check-cast v0, LX/JDM;

    .line 54
    .line 55
    invoke-static {p0, v2, v0}, LX/009;->A0x(LX/2d4;LX/3C1;LX/JDM;)V

    .line 56
    .line 57
    .line 58
    :goto_0
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    if-eqz v1, :cond_2

    .line 63
    .line 64
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionActionSpinner$2;

    .line 65
    .line 66
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionActionSpinner$2;-><init>(I)V

    .line 67
    .line 68
    .line 69
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 70
    .line 71
    :cond_2
    return-void

    .line 72
    :cond_3
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 73
    .line 74
    .line 75
    goto :goto_0
.end method

.method public static final ActivePermissionDetails(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 46

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    const v0, -0x3d98f3db

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v0, p4

    .line 11
    .line 12
    and-int/lit8 v2, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v13, p0

    .line 15
    .line 16
    if-nez v2, :cond_4

    .line 17
    .line 18
    invoke-static {v1, v13}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v7

    .line 22
    or-int v7, v7, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v2, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v6, p1

    .line 27
    .line 28
    if-nez v2, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v6}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    or-int/2addr v7, v2

    .line 35
    :cond_0
    and-int/lit8 v3, p5, 0x4

    .line 36
    .line 37
    if-eqz v3, :cond_3

    .line 38
    .line 39
    or-int/lit16 v7, v7, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    invoke-static {v7}, LX/005;->A1I(I)Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    invoke-static {v2, v1, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_5

    .line 50
    .line 51
    if-eqz v3, :cond_2

    .line 52
    .line 53
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 54
    .line 55
    :cond_2
    const/high16 v2, 0x40000000    # 2.0f

    .line 56
    .line 57
    invoke-static {v2}, LX/Dn6;->A00(F)LX/CP5;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    sget-object v2, LX/2Id;->A02:LX/2sS;

    .line 62
    .line 63
    const/4 v5, 0x6

    .line 64
    invoke-static {v3, v1, v2, v5}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 65
    .line 66
    .line 67
    move-result-object v12

    .line 68
    move-object v2, v1

    .line 69
    check-cast v2, LX/J7I;

    .line 70
    .line 71
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 72
    .line 73
    .line 74
    move-result v11

    .line 75
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 80
    .line 81
    .line 82
    move-result-object v9

    .line 83
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 84
    .line 85
    iget-object v3, v2, LX/J7I;->A0V:LX/3DJ;

    .line 86
    .line 87
    if-nez v3, :cond_6

    .line 88
    .line 89
    invoke-static {}, LX/1VY;->A00()V

    .line 90
    .line 91
    .line 92
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    throw v0

    .line 97
    :cond_3
    and-int/lit16 v2, v0, 0x180

    .line 98
    .line 99
    if-nez v2, :cond_1

    .line 100
    .line 101
    invoke-static {v1, v4}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v2

    .line 105
    or-int/2addr v7, v2

    .line 106
    goto :goto_1

    .line 107
    :cond_4
    move v7, v0

    .line 108
    goto :goto_0

    .line 109
    :cond_5
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 110
    .line 111
    .line 112
    goto :goto_3

    .line 113
    :cond_6
    invoke-static {v1, v2, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 114
    .line 115
    .line 116
    invoke-static {v1, v12, v10, v9, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 117
    .line 118
    .line 119
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 120
    .line 121
    invoke-static {v1, v3}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 122
    .line 123
    .line 124
    move-result-object v17

    .line 125
    invoke-static {v1, v3}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 126
    .line 127
    .line 128
    move-result-wide v15

    .line 129
    const/16 v23, 0x2

    .line 130
    .line 131
    and-int/lit8 v29, v7, 0xe

    .line 132
    .line 133
    const/high16 p2, 0x30000000

    .line 134
    .line 135
    or-int v29, v29, p2

    .line 136
    .line 137
    const/16 v31, 0x39f2

    .line 138
    .line 139
    const/4 v14, 0x0

    .line 140
    const/16 v21, 0x0

    .line 141
    .line 142
    move-object/from16 v18, v14

    .line 143
    .line 144
    move-object/from16 v19, v14

    .line 145
    .line 146
    move-object/from16 v20, v14

    .line 147
    .line 148
    move/from16 v22, v21

    .line 149
    .line 150
    move/from16 v24, v23

    .line 151
    .line 152
    move-object/from16 v25, v14

    .line 153
    .line 154
    move-object/from16 v26, v14

    .line 155
    .line 156
    move-object/from16 v27, v14

    .line 157
    .line 158
    move-object/from16 v28, v1

    .line 159
    .line 160
    move/from16 v30, v5

    .line 161
    .line 162
    invoke-static/range {v13 .. v31}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 163
    .line 164
    .line 165
    if-nez p1, :cond_8

    .line 166
    .line 167
    const v3, 0x488dd3a1

    .line 168
    .line 169
    .line 170
    invoke-interface {v1, v3}, LX/2d4;->Agj(I)V

    .line 171
    .line 172
    .line 173
    :goto_2
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 174
    .line 175
    .line 176
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    if-eqz v2, :cond_7

    .line 181
    .line 182
    new-instance v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionDetails$2;

    .line 183
    .line 184
    move-object/from16 p0, v1

    .line 185
    .line 186
    move-object/from16 p1, v13

    .line 187
    .line 188
    move-object/from16 p2, v6

    .line 189
    .line 190
    move-object/from16 p3, v4

    .line 191
    .line 192
    move/from16 p4, v0

    .line 193
    .line 194
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionDetails$2;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 195
    .line 196
    .line 197
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 198
    .line 199
    :cond_7
    return-void

    .line 200
    :cond_8
    const v7, 0x488dd3a2

    .line 201
    .line 202
    .line 203
    invoke-static {v1, v3, v7}, LX/3Rr;->A0D(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)LX/2hg;

    .line 204
    .line 205
    .line 206
    move-result-object v36

    .line 207
    invoke-static {v1, v3}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 208
    .line 209
    .line 210
    move-result-wide v34

    .line 211
    move-object/from16 v32, v6

    .line 212
    .line 213
    move-object/from16 v33, v14

    .line 214
    .line 215
    move-object/from16 v37, v14

    .line 216
    .line 217
    move-object/from16 v38, v14

    .line 218
    .line 219
    move-object/from16 v39, v14

    .line 220
    .line 221
    move/from16 v40, v21

    .line 222
    .line 223
    move/from16 v41, v21

    .line 224
    .line 225
    move/from16 v42, v23

    .line 226
    .line 227
    move/from16 v43, v23

    .line 228
    .line 229
    move-object/from16 v44, v14

    .line 230
    .line 231
    move-object/from16 v45, v14

    .line 232
    .line 233
    move-object/from16 p0, v14

    .line 234
    .line 235
    move-object/from16 p1, v1

    .line 236
    .line 237
    move/from16 p3, v5

    .line 238
    .line 239
    move/from16 p4, v31

    .line 240
    .line 241
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 242
    .line 243
    .line 244
    goto :goto_2
.end method

.method public static final ActivePermissionModeControl(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;ZZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 0
    move-object/from16 v20, p10

    .line 1
    .line 2
    move-object/from16 v15, p11

    .line 3
    .line 4
    const v0, 0x5f768d89

    .line 5
    .line 6
    .line 7
    move-object/from16 v2, p12

    .line 8
    .line 9
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v1, p13

    .line 13
    .line 14
    and-int/lit8 v0, p13, 0x6

    .line 15
    .line 16
    if-nez v0, :cond_14

    .line 17
    .line 18
    move-object/from16 v0, p0

    .line 19
    .line 20
    invoke-static {v2, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    or-int v4, v4, p13

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p13, 0x30

    .line 27
    .line 28
    move-object/from16 v42, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    move-object/from16 v0, v42

    .line 33
    .line 34
    invoke-static {v2, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v4, v0

    .line 39
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 40
    .line 41
    move-object/from16 v41, p2

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    invoke-static/range {v41 .. v41}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v2, v0}, LX/004;->A0G(LX/2d4;I)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    or-int/2addr v4, v0

    .line 54
    :cond_1
    and-int/lit16 v0, v1, 0xc00

    .line 55
    .line 56
    move-object/from16 v40, p3

    .line 57
    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    move-object/from16 v0, v40

    .line 61
    .line 62
    invoke-static {v2, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v4, v0

    .line 67
    :cond_2
    and-int/lit16 v0, v1, 0x6000

    .line 68
    .line 69
    move/from16 v39, p4

    .line 70
    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    move/from16 v0, v39

    .line 74
    .line 75
    invoke-static {v2, v0}, LX/004;->A0m(LX/2d4;Z)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    or-int/2addr v4, v0

    .line 80
    :cond_3
    const/high16 v0, 0x30000

    .line 81
    .line 82
    and-int v0, v0, p13

    .line 83
    .line 84
    move/from16 v21, p5

    .line 85
    .line 86
    if-nez v0, :cond_4

    .line 87
    .line 88
    move/from16 v0, v21

    .line 89
    .line 90
    invoke-static {v2, v0}, LX/004;->A0n(LX/2d4;Z)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    or-int/2addr v4, v0

    .line 95
    :cond_4
    const/high16 v0, 0x180000

    .line 96
    .line 97
    and-int v0, v0, p13

    .line 98
    .line 99
    move/from16 v38, p6

    .line 100
    .line 101
    if-nez v0, :cond_5

    .line 102
    .line 103
    move/from16 v0, v38

    .line 104
    .line 105
    invoke-static {v2, v0}, LX/004;->A0o(LX/2d4;Z)I

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    or-int/2addr v4, v0

    .line 110
    :cond_5
    const/high16 v0, 0xc00000

    .line 111
    .line 112
    and-int v0, p13, v0

    .line 113
    .line 114
    move-object/from16 v35, p7

    .line 115
    .line 116
    if-nez v0, :cond_6

    .line 117
    .line 118
    move-object/from16 v0, v35

    .line 119
    .line 120
    invoke-static {v2, v0}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    or-int/2addr v4, v0

    .line 125
    :cond_6
    const/high16 v0, 0x6000000

    .line 126
    .line 127
    and-int v0, p13, v0

    .line 128
    .line 129
    move-object/from16 v34, p8

    .line 130
    .line 131
    if-nez v0, :cond_7

    .line 132
    .line 133
    move-object/from16 v0, v34

    .line 134
    .line 135
    invoke-static {v2, v0}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    or-int/2addr v4, v0

    .line 140
    :cond_7
    const/high16 v0, 0x30000000

    .line 141
    .line 142
    and-int v0, p13, v0

    .line 143
    .line 144
    move-object/from16 v33, p9

    .line 145
    .line 146
    if-nez v0, :cond_8

    .line 147
    .line 148
    move-object/from16 v0, v33

    .line 149
    .line 150
    invoke-static {v2, v0}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    or-int/2addr v4, v0

    .line 155
    :cond_8
    move/from16 v37, p15

    .line 156
    .line 157
    move/from16 v0, v37

    .line 158
    .line 159
    and-int/lit16 v6, v0, 0x400

    .line 160
    .line 161
    move/from16 v36, p14

    .line 162
    .line 163
    if-eqz v6, :cond_12

    .line 164
    .line 165
    or-int/lit8 v19, p14, 0x6

    .line 166
    .line 167
    :goto_1
    move/from16 v0, v37

    .line 168
    .line 169
    and-int/lit16 v7, v0, 0x800

    .line 170
    .line 171
    if-eqz v7, :cond_11

    .line 172
    .line 173
    or-int/lit8 v19, v19, 0x30

    .line 174
    .line 175
    :cond_9
    :goto_2
    const v0, 0x12492493

    .line 176
    .line 177
    .line 178
    and-int v3, v4, v0

    .line 179
    .line 180
    const v0, 0x12492492

    .line 181
    .line 182
    .line 183
    const/16 v18, 0x1

    .line 184
    .line 185
    if-ne v3, v0, :cond_a

    .line 186
    .line 187
    and-int/lit8 v5, v19, 0x13

    .line 188
    .line 189
    const/16 v3, 0x12

    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    if-eq v5, v3, :cond_b

    .line 193
    .line 194
    :cond_a
    const/4 v0, 0x1

    .line 195
    :cond_b
    invoke-static {v0, v2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-eqz v0, :cond_17

    .line 200
    .line 201
    if-eqz v6, :cond_c

    .line 202
    .line 203
    const/16 v20, 0x0

    .line 204
    .line 205
    :cond_c
    if-eqz v7, :cond_d

    .line 206
    .line 207
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 208
    .line 209
    :cond_d
    const/4 v5, 0x0

    .line 210
    const v6, 0x7f120186

    .line 211
    .line 212
    .line 213
    move-object/from16 v3, p0

    .line 214
    .line 215
    move-object/from16 v0, v42

    .line 216
    .line 217
    invoke-static {v2, v3, v0, v6}, LX/18b;->A09(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v7

    .line 221
    if-eqz p5, :cond_e

    .line 222
    .line 223
    const v0, 0x5c099dd1

    .line 224
    .line 225
    .line 226
    invoke-static {v2, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 231
    .line 232
    move-object v3, v10

    .line 233
    :goto_3
    invoke-static {v5}, LX/001;->A0g(Z)LX/3BI;

    .line 234
    .line 235
    .line 236
    move-result-object v8

    .line 237
    iget-wide v6, v0, LX/J7I;->A06:J

    .line 238
    .line 239
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 240
    .line 241
    .line 242
    move-result v12

    .line 243
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 244
    .line 245
    .line 246
    move-result-object v7

    .line 247
    invoke-static {v2, v15}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 248
    .line 249
    .line 250
    move-result-object v6

    .line 251
    sget-object v11, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 252
    .line 253
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 254
    .line 255
    if-nez v9, :cond_15

    .line 256
    .line 257
    invoke-static {}, LX/1VY;->A00()V

    .line 258
    .line 259
    .line 260
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    throw v0

    .line 265
    :cond_e
    const v0, 0x5c09a0db

    .line 266
    .line 267
    .line 268
    invoke-static {v2, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 269
    .line 270
    .line 271
    move-result-object v3

    .line 272
    invoke-interface {v2, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-result v6

    .line 276
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    if-nez v6, :cond_f

    .line 281
    .line 282
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 283
    .line 284
    if-ne v0, v6, :cond_10

    .line 285
    .line 286
    :cond_f
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeControl$controlSemantics$1$1;

    .line 287
    .line 288
    invoke-direct {v0, v7}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeControl$controlSemantics$1$1;-><init>(Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    :cond_10
    check-cast v0, LX/JDM;

    .line 295
    .line 296
    invoke-static {v3, v0, v5}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 297
    .line 298
    .line 299
    move-result-object v10

    .line 300
    invoke-static {v2}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    goto :goto_3

    .line 305
    :cond_11
    and-int/lit8 v0, p14, 0x30

    .line 306
    .line 307
    const/4 v7, 0x0

    .line 308
    if-nez v0, :cond_9

    .line 309
    .line 310
    invoke-static {v2, v15}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 311
    .line 312
    .line 313
    move-result v0

    .line 314
    or-int v19, v19, v0

    .line 315
    .line 316
    goto/16 :goto_2

    .line 317
    .line 318
    :cond_12
    and-int/lit8 v0, p14, 0x6

    .line 319
    .line 320
    if-nez v0, :cond_13

    .line 321
    .line 322
    move-object/from16 v0, v20

    .line 323
    .line 324
    invoke-static {v2, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 325
    .line 326
    .line 327
    move-result v0

    .line 328
    or-int v19, p14, v0

    .line 329
    .line 330
    goto/16 :goto_1

    .line 331
    .line 332
    :cond_13
    move/from16 v19, v36

    .line 333
    .line 334
    goto/16 :goto_1

    .line 335
    .line 336
    :cond_14
    move v4, v1

    .line 337
    goto/16 :goto_0

    .line 338
    .line 339
    :cond_15
    invoke-static {v2, v0, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 340
    .line 341
    .line 342
    sget-object v9, LX/3Cl;->A04:LX/JDN;

    .line 343
    .line 344
    invoke-static {v2, v8, v9}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 345
    .line 346
    .line 347
    move-result-object v8

    .line 348
    invoke-static {v2, v7, v8, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 349
    .line 350
    .line 351
    move-result-object v17

    .line 352
    sget-object v7, LX/3Cl;->A02:LX/JDM;

    .line 353
    .line 354
    invoke-static {v2, v6, v7}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 355
    .line 356
    .line 357
    move-result-object v14

    .line 358
    sget-object v16, LX/3Jn;->A00:LX/3Jn;

    .line 359
    .line 360
    const/high16 v6, 0x42400000    # 48.0f

    .line 361
    .line 362
    invoke-static {v3, v6, v6}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 363
    .line 364
    .line 365
    move-result-object v24

    .line 366
    invoke-static {v5}, LX/1Y9;->A01(I)LX/1Y9;

    .line 367
    .line 368
    .line 369
    move-result-object v25

    .line 370
    const/16 v26, 0x0

    .line 371
    .line 372
    move-object/from16 v22, v26

    .line 373
    .line 374
    move-object/from16 v23, v26

    .line 375
    .line 376
    move-object/from16 v27, v35

    .line 377
    .line 378
    move/from16 v28, v39

    .line 379
    .line 380
    invoke-static/range {v22 .. v28}, LX/3GU;->A01(LX/346;LX/3Gw;LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 381
    .line 382
    .line 383
    move-result-object v6

    .line 384
    invoke-interface {v6, v10}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 385
    .line 386
    .line 387
    move-result-object v10

    .line 388
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 389
    .line 390
    invoke-static {v10, v6}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 391
    .line 392
    .line 393
    move-result-object v6

    .line 394
    sget-object v12, LX/2Id;->A04:LX/2rU;

    .line 395
    .line 396
    const/high16 v10, 0x40800000    # 4.0f

    .line 397
    .line 398
    invoke-static {v2, v12, v10}, LX/008;->A0o(LX/2d4;LX/2rU;F)LX/3BI;

    .line 399
    .line 400
    .line 401
    move-result-object v13

    .line 402
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 403
    .line 404
    .line 405
    move-result v12

    .line 406
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 407
    .line 408
    .line 409
    move-result-object v10

    .line 410
    invoke-static {v2, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 411
    .line 412
    .line 413
    move-result-object v6

    .line 414
    invoke-static {v2, v0, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 415
    .line 416
    .line 417
    invoke-static {v2, v13, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 418
    .line 419
    .line 420
    invoke-static {v2, v10, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 421
    .line 422
    .line 423
    move-object/from16 v8, v17

    .line 424
    .line 425
    invoke-static {v7, v8, v2, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 426
    .line 427
    .line 428
    invoke-static {v2, v6, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 429
    .line 430
    .line 431
    if-eqz p5, :cond_16

    .line 432
    .line 433
    const v6, 0x1d0777fe

    .line 434
    .line 435
    .line 436
    invoke-interface {v2, v6}, LX/2d4;->Agj(I)V

    .line 437
    .line 438
    .line 439
    invoke-static {v2, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionActionSpinner(LX/2d4;I)V

    .line 440
    .line 441
    .line 442
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 443
    .line 444
    .line 445
    :goto_4
    move/from16 v5, v18

    .line 446
    .line 447
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 448
    .line 449
    .line 450
    sget-object v6, LX/2Id;->A0A:Landroidx/compose/ui/Alignment;

    .line 451
    .line 452
    move-object/from16 v5, v16

    .line 453
    .line 454
    invoke-virtual {v5, v6, v3}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 455
    .line 456
    .line 457
    move-result-object v22

    .line 458
    shr-int/lit8 v3, v4, 0xf

    .line 459
    .line 460
    and-int/lit8 v5, v3, 0x70

    .line 461
    .line 462
    shr-int/lit8 v3, v4, 0x3

    .line 463
    .line 464
    and-int/lit16 v3, v3, 0x380

    .line 465
    .line 466
    or-int/2addr v5, v3

    .line 467
    shl-int/lit8 v3, v19, 0x9

    .line 468
    .line 469
    and-int/lit16 v3, v3, 0x1c00

    .line 470
    .line 471
    or-int/2addr v5, v3

    .line 472
    shr-int/lit8 v4, v4, 0x9

    .line 473
    .line 474
    const/high16 v3, 0x70000

    .line 475
    .line 476
    and-int/2addr v3, v4

    .line 477
    or-int/2addr v5, v3

    .line 478
    invoke-static {v4, v5}, LX/001;->A06(II)I

    .line 479
    .line 480
    .line 481
    move-result v30

    .line 482
    const/16 v31, 0x10

    .line 483
    .line 484
    move/from16 v23, v38

    .line 485
    .line 486
    move-object/from16 v24, v40

    .line 487
    .line 488
    move-object/from16 v25, v20

    .line 489
    .line 490
    move-object/from16 v27, v34

    .line 491
    .line 492
    move-object/from16 v28, v33

    .line 493
    .line 494
    move-object/from16 v29, v2

    .line 495
    .line 496
    invoke-static/range {v22 .. v31}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->PermissionModeContextMenu(LX/3C1;ZLX/Ddn;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/2d4;II)V

    .line 497
    .line 498
    .line 499
    move/from16 v3, v18

    .line 500
    .line 501
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 502
    .line 503
    .line 504
    goto :goto_5

    .line 505
    :cond_16
    const v6, 0x1d08701d

    .line 506
    .line 507
    .line 508
    invoke-interface {v2, v6}, LX/2d4;->Agj(I)V

    .line 509
    .line 510
    .line 511
    shr-int/lit8 v6, v4, 0x3

    .line 512
    .line 513
    and-int/lit8 v8, v6, 0x7e

    .line 514
    .line 515
    move-object/from16 v7, v42

    .line 516
    .line 517
    move-object/from16 v6, v41

    .line 518
    .line 519
    invoke-static {v7, v6, v2, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeLabel(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)V

    .line 520
    .line 521
    .line 522
    const v6, 0x7f0800e9

    .line 523
    .line 524
    .line 525
    invoke-static {v2, v6, v5}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 526
    .line 527
    .line 528
    move-result-object v24

    .line 529
    invoke-static {v2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 530
    .line 531
    .line 532
    move-result-object v6

    .line 533
    iget-wide v6, v6, Lcom/facebook/aura/vds/compose/theme/AuraColors;->tertiaryText:J

    .line 534
    .line 535
    invoke-static {v6, v7, v2, v5}, Lcom/facebook/aura/vds/compose/ext/ColorExtKt;->applyContentAlpha-ek8zF_U(JLX/2d4;I)J

    .line 536
    .line 537
    .line 538
    move-result-wide v27

    .line 539
    sget-object v25, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_TINY:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 540
    .line 541
    invoke-static {}, LX/2l9;->A04()I

    .line 542
    .line 543
    .line 544
    move-result v31

    .line 545
    const/16 v32, 0x21

    .line 546
    .line 547
    move-object/from16 v29, v26

    .line 548
    .line 549
    move-object/from16 v30, v2

    .line 550
    .line 551
    invoke-static/range {v23 .. v32}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 552
    .line 553
    .line 554
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 555
    .line 556
    .line 557
    goto :goto_4

    .line 558
    :cond_17
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 559
    .line 560
    .line 561
    :goto_5
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 562
    .line 563
    .line 564
    move-result-object v2

    .line 565
    if-eqz v2, :cond_18

    .line 566
    .line 567
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeControl$2;

    .line 568
    .line 569
    move-object/from16 v22, v0

    .line 570
    .line 571
    move-object/from16 v23, p0

    .line 572
    .line 573
    move-object/from16 v24, v42

    .line 574
    .line 575
    move-object/from16 v25, v41

    .line 576
    .line 577
    move-object/from16 v26, v40

    .line 578
    .line 579
    move/from16 v27, v39

    .line 580
    .line 581
    move/from16 v28, v21

    .line 582
    .line 583
    move/from16 v29, v38

    .line 584
    .line 585
    move-object/from16 v30, v35

    .line 586
    .line 587
    move-object/from16 v31, v34

    .line 588
    .line 589
    move-object/from16 v32, v33

    .line 590
    .line 591
    move-object/from16 v33, v20

    .line 592
    .line 593
    move-object/from16 v34, v15

    .line 594
    .line 595
    move/from16 v35, v1

    .line 596
    .line 597
    invoke-direct/range {v22 .. v37}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeControl$2;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;III)V

    .line 598
    .line 599
    .line 600
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 601
    .line 602
    :cond_18
    return-void
.end method

.method public static final ActivePermissionModeLabel(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)V
    .locals 20

    .line 0
    const v0, -0x4582c339

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p3

    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v5, p0

    .line 13
    .line 14
    if-nez v0, :cond_3

    .line 15
    .line 16
    invoke-static {v1, v5}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    or-int v4, p3, v0

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 23
    .line 24
    move-object/from16 v3, p1

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-static {v3}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {v1, v0}, LX/004;->A0F(LX/2d4;I)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v4, v0

    .line 37
    :cond_0
    invoke-static {v4}, LX/005;->A1G(I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 48
    .line 49
    const/16 p2, 0x6

    .line 50
    .line 51
    invoke-static {v1, v0}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 52
    .line 53
    .line 54
    move-result-object v9

    .line 55
    shr-int/lit8 v0, v4, 0x3

    .line 56
    .line 57
    and-int/lit8 v0, v0, 0xe

    .line 58
    .line 59
    invoke-static {v3, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->permissionModeTextColor(Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)J

    .line 60
    .line 61
    .line 62
    move-result-wide v7

    .line 63
    const/16 v16, 0x2

    .line 64
    .line 65
    const/high16 v0, 0x30000000

    .line 66
    .line 67
    and-int/lit8 p1, v4, 0xe

    .line 68
    .line 69
    or-int p1, p1, v0

    .line 70
    .line 71
    const/16 p3, 0x39f2

    .line 72
    .line 73
    const/4 v6, 0x0

    .line 74
    const/4 v13, 0x0

    .line 75
    const/4 v15, 0x1

    .line 76
    move-object v10, v6

    .line 77
    move-object v11, v6

    .line 78
    move-object v12, v6

    .line 79
    move v14, v13

    .line 80
    move-object/from16 v17, v6

    .line 81
    .line 82
    move-object/from16 v18, v6

    .line 83
    .line 84
    move-object/from16 v19, v6

    .line 85
    .line 86
    move-object/from16 p0, v1

    .line 87
    .line 88
    invoke-static/range {v5 .. v23}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 89
    .line 90
    .line 91
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    if-eqz v1, :cond_1

    .line 96
    .line 97
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeLabel$1;

    .line 98
    .line 99
    invoke-direct {v0, v5, v3, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionModeLabel$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;I)V

    .line 100
    .line 101
    .line 102
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 103
    .line 104
    :cond_1
    return-void

    .line 105
    :cond_2
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 106
    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_3
    move v4, v2

    .line 110
    goto :goto_0
.end method

.method public static final ActivePermissionRow(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;III)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Ljava/lang/String;",
            "ZZZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p10

    .line 1
    .line 2
    const/4 v6, 0x0

    .line 3
    move-object/from16 v3, p0

    .line 4
    .line 5
    invoke-static {v3, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x6

    .line 9
    move-object/from16 p10, p6

    .line 10
    .line 11
    move-object/from16 v15, p7

    .line 12
    .line 13
    move-object/from16 v9, p8

    .line 14
    .line 15
    move-object/from16 v0, p10

    .line 16
    .line 17
    invoke-static {v0, v15, v9, v1}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    const/16 v0, 0x9

    .line 21
    .line 22
    move-object/from16 v8, p9

    .line 23
    .line 24
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    const v0, 0x7a36277a

    .line 28
    .line 29
    .line 30
    move-object/from16 v2, p11

    .line 31
    .line 32
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 33
    .line 34
    .line 35
    move/from16 v1, p12

    .line 36
    .line 37
    and-int/lit8 v0, p12, 0x6

    .line 38
    .line 39
    if-nez v0, :cond_e

    .line 40
    .line 41
    invoke-static {v3, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0}, LX/003;->A06(I)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int v0, v0, p12

    .line 50
    .line 51
    :goto_0
    and-int/lit8 v4, p12, 0x30

    .line 52
    .line 53
    move-object/from16 v19, p1

    .line 54
    .line 55
    if-nez v4, :cond_0

    .line 56
    .line 57
    move-object/from16 v4, v19

    .line 58
    .line 59
    invoke-static {v2, v4}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    or-int/2addr v0, v4

    .line 64
    :cond_0
    and-int/lit16 v4, v1, 0x180

    .line 65
    .line 66
    move/from16 p12, p2

    .line 67
    .line 68
    if-nez v4, :cond_1

    .line 69
    .line 70
    move/from16 v4, p12

    .line 71
    .line 72
    invoke-static {v2, v4}, LX/004;->A0k(LX/2d4;Z)I

    .line 73
    .line 74
    .line 75
    move-result v4

    .line 76
    or-int/2addr v0, v4

    .line 77
    :cond_1
    and-int/lit16 v4, v1, 0xc00

    .line 78
    .line 79
    move/from16 v18, p3

    .line 80
    .line 81
    if-nez v4, :cond_2

    .line 82
    .line 83
    move/from16 v4, v18

    .line 84
    .line 85
    invoke-static {v2, v4}, LX/004;->A0l(LX/2d4;Z)I

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    or-int/2addr v0, v4

    .line 90
    :cond_2
    and-int/lit16 v4, v1, 0x6000

    .line 91
    .line 92
    move/from16 v17, p4

    .line 93
    .line 94
    if-nez v4, :cond_3

    .line 95
    .line 96
    move/from16 v4, v17

    .line 97
    .line 98
    invoke-static {v2, v4}, LX/004;->A0m(LX/2d4;Z)I

    .line 99
    .line 100
    .line 101
    move-result v4

    .line 102
    or-int/2addr v0, v4

    .line 103
    :cond_3
    const/high16 v4, 0x30000

    .line 104
    .line 105
    and-int/2addr v4, v1

    .line 106
    move/from16 p11, p5

    .line 107
    .line 108
    if-nez v4, :cond_4

    .line 109
    .line 110
    move/from16 v4, p11

    .line 111
    .line 112
    invoke-static {v2, v4}, LX/004;->A0n(LX/2d4;Z)I

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    or-int/2addr v0, v4

    .line 117
    :cond_4
    const/high16 v4, 0x180000

    .line 118
    .line 119
    and-int/2addr v4, v1

    .line 120
    if-nez v4, :cond_5

    .line 121
    .line 122
    move-object/from16 v4, p10

    .line 123
    .line 124
    invoke-static {v2, v4}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 125
    .line 126
    .line 127
    move-result v4

    .line 128
    or-int/2addr v0, v4

    .line 129
    :cond_5
    const/high16 v4, 0xc00000

    .line 130
    .line 131
    and-int/2addr v4, v1

    .line 132
    if-nez v4, :cond_6

    .line 133
    .line 134
    invoke-static {v2, v15}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v4

    .line 138
    or-int/2addr v0, v4

    .line 139
    :cond_6
    const/high16 v4, 0x6000000

    .line 140
    .line 141
    and-int/2addr v4, v1

    .line 142
    if-nez v4, :cond_7

    .line 143
    .line 144
    invoke-static {v2, v9}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 145
    .line 146
    .line 147
    move-result v4

    .line 148
    or-int/2addr v0, v4

    .line 149
    :cond_7
    const/high16 v4, 0x30000000

    .line 150
    .line 151
    and-int/2addr v4, v1

    .line 152
    if-nez v4, :cond_8

    .line 153
    .line 154
    invoke-static {v2, v8}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    .line 155
    .line 156
    .line 157
    move-result v4

    .line 158
    or-int/2addr v0, v4

    .line 159
    :cond_8
    move/from16 p9, p14

    .line 160
    .line 161
    move/from16 v4, p9

    .line 162
    .line 163
    and-int/lit16 v10, v4, 0x400

    .line 164
    .line 165
    move/from16 p8, p13

    .line 166
    .line 167
    if-eqz v10, :cond_c

    .line 168
    .line 169
    or-int/lit8 v11, p13, 0x6

    .line 170
    .line 171
    :goto_1
    const v4, 0x12492493

    .line 172
    .line 173
    .line 174
    and-int v7, v0, v4

    .line 175
    .line 176
    const v4, 0x12492492

    .line 177
    .line 178
    .line 179
    if-ne v7, v4, :cond_9

    .line 180
    .line 181
    and-int/lit8 v11, v11, 0x3

    .line 182
    .line 183
    const/4 v7, 0x2

    .line 184
    const/4 v4, 0x0

    .line 185
    if-eq v11, v7, :cond_a

    .line 186
    .line 187
    :cond_9
    const/4 v4, 0x1

    .line 188
    :cond_a
    invoke-static {v4, v2, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 189
    .line 190
    .line 191
    move-result v4

    .line 192
    if-eqz v4, :cond_14

    .line 193
    .line 194
    if-eqz v10, :cond_b

    .line 195
    .line 196
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 197
    .line 198
    :cond_b
    invoke-static {v5}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 199
    .line 200
    .line 201
    move-result-object v7

    .line 202
    const/high16 v4, 0x42800000    # 64.0f

    .line 203
    .line 204
    invoke-static {v7, v4}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 205
    .line 206
    .line 207
    move-result-object v7

    .line 208
    sget v4, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 209
    .line 210
    invoke-static {v7, v4}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 211
    .line 212
    .line 213
    move-result-object v7

    .line 214
    sget-object v10, LX/2Id;->A04:LX/2rU;

    .line 215
    .line 216
    const/high16 v4, 0x41400000    # 12.0f

    .line 217
    .line 218
    invoke-static {v2, v10, v4}, LX/008;->A0o(LX/2d4;LX/2rU;F)LX/3BI;

    .line 219
    .line 220
    .line 221
    move-result-object v14

    .line 222
    move-object v4, v2

    .line 223
    check-cast v4, LX/J7I;

    .line 224
    .line 225
    invoke-static {v4}, LX/003;->A0F(LX/J7I;)I

    .line 226
    .line 227
    .line 228
    move-result v13

    .line 229
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 230
    .line 231
    .line 232
    move-result-object v12

    .line 233
    invoke-static {v2, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 234
    .line 235
    .line 236
    move-result-object v11

    .line 237
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 238
    .line 239
    iget-object v7, v4, LX/J7I;->A0V:LX/3DJ;

    .line 240
    .line 241
    if-nez v7, :cond_f

    .line 242
    .line 243
    invoke-static {}, LX/1VY;->A00()V

    .line 244
    .line 245
    .line 246
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    throw v0

    .line 251
    :cond_c
    and-int/lit8 v4, p13, 0x6

    .line 252
    .line 253
    if-nez v4, :cond_d

    .line 254
    .line 255
    invoke-static {v2, v5}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 256
    .line 257
    .line 258
    move-result v4

    .line 259
    or-int v11, p13, v4

    .line 260
    .line 261
    goto :goto_1

    .line 262
    :cond_d
    move/from16 v11, p8

    .line 263
    .line 264
    goto :goto_1

    .line 265
    :cond_e
    move v0, v1

    .line 266
    goto/16 :goto_0

    .line 267
    .line 268
    :cond_f
    invoke-static {v2, v4, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 269
    .line 270
    .line 271
    invoke-static {v2, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 272
    .line 273
    .line 274
    sget-object v7, LX/CgK;->A00:LX/CgK;

    .line 275
    .line 276
    if-nez p1, :cond_13

    .line 277
    .line 278
    iget-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 279
    .line 280
    iget-object v10, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->iconUrl:Ljava/lang/String;

    .line 281
    .line 282
    :goto_2
    sget v23, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 283
    .line 284
    sget v24, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 285
    .line 286
    invoke-static {v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->fallbackIconRes(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)I

    .line 287
    .line 288
    .line 289
    move-result v25

    .line 290
    sget v26, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 291
    .line 292
    const/16 p3, 0x30

    .line 293
    .line 294
    const/16 p4, 0x184

    .line 295
    .line 296
    const/16 v21, 0x0

    .line 297
    .line 298
    move-object/from16 v20, v10

    .line 299
    .line 300
    move-object/from16 v22, v21

    .line 301
    .line 302
    move-object/from16 p0, v21

    .line 303
    .line 304
    move-object/from16 p1, v21

    .line 305
    .line 306
    move-object/from16 p2, v2

    .line 307
    .line 308
    invoke-static/range {v20 .. v31}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 309
    .line 310
    .line 311
    iget-object v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 312
    .line 313
    iget-object v13, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->summaryTitle:Ljava/lang/String;

    .line 314
    .line 315
    iget-object v12, v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->permissionCaption:Ljava/lang/String;

    .line 316
    .line 317
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 318
    .line 319
    const/high16 v11, 0x3f800000    # 1.0f

    .line 320
    .line 321
    const/4 v10, 0x1

    .line 322
    invoke-virtual {v7, v14, v11, v10}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 323
    .line 324
    .line 325
    move-result-object v22

    .line 326
    move-object/from16 v20, v13

    .line 327
    .line 328
    move-object/from16 v21, v12

    .line 329
    .line 330
    move-object/from16 v23, v2

    .line 331
    .line 332
    move/from16 v24, v6

    .line 333
    .line 334
    move/from16 v25, v6

    .line 335
    .line 336
    invoke-static/range {v20 .. v25}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionDetails(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 337
    .line 338
    .line 339
    iget-object v11, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 340
    .line 341
    iget-object v7, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->summaryTitle:Ljava/lang/String;

    .line 342
    .line 343
    move-object/from16 v20, v7

    .line 344
    .line 345
    iget-object v7, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->modeLabel:Ljava/lang/String;

    .line 346
    .line 347
    if-nez v7, :cond_12

    .line 348
    .line 349
    const v7, 0xc191087

    .line 350
    .line 351
    .line 352
    invoke-interface {v2, v7}, LX/2d4;->Agj(I)V

    .line 353
    .line 354
    .line 355
    iget-object v7, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 356
    .line 357
    invoke-static {v7, v2, v6}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->permissionModeShortLabel(Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)Ljava/lang/String;

    .line 358
    .line 359
    .line 360
    move-result-object v7

    .line 361
    :goto_3
    invoke-static {v4, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 362
    .line 363
    .line 364
    iget-object v14, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 365
    .line 366
    iget-object v11, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 367
    .line 368
    iget-boolean v6, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 369
    .line 370
    if-nez v17, :cond_10

    .line 371
    .line 372
    const/16 v26, 0x0

    .line 373
    .line 374
    if-eqz v18, :cond_11

    .line 375
    .line 376
    :cond_10
    const/16 v26, 0x1

    .line 377
    .line 378
    :cond_11
    shl-int/lit8 v13, v0, 0x9

    .line 379
    .line 380
    const/high16 v12, 0x70000

    .line 381
    .line 382
    and-int/2addr v13, v12

    .line 383
    const/high16 v16, 0x1c00000

    .line 384
    .line 385
    shl-int/lit8 v12, v0, 0x6

    .line 386
    .line 387
    and-int v16, v16, v12

    .line 388
    .line 389
    or-int v13, v13, v16

    .line 390
    .line 391
    shl-int/lit8 v12, v0, 0x3

    .line 392
    .line 393
    const/high16 v16, 0xe000000

    .line 394
    .line 395
    and-int v16, v16, v12

    .line 396
    .line 397
    or-int v13, v13, v16

    .line 398
    .line 399
    invoke-static {v12, v13}, LX/002;->A05(II)I

    .line 400
    .line 401
    .line 402
    move-result p6

    .line 403
    shr-int/lit8 v12, v0, 0x1b

    .line 404
    .line 405
    and-int/lit8 p7, v12, 0xe

    .line 406
    .line 407
    shr-int/lit8 v0, v0, 0xf

    .line 408
    .line 409
    and-int/lit8 v0, v0, 0x70

    .line 410
    .line 411
    or-int p7, p7, v0

    .line 412
    .line 413
    move-object/from16 p3, v8

    .line 414
    .line 415
    move-object/from16 p4, p10

    .line 416
    .line 417
    move-object/from16 p5, v2

    .line 418
    .line 419
    move-object/from16 v21, v7

    .line 420
    .line 421
    move-object/from16 v22, v14

    .line 422
    .line 423
    move-object/from16 v23, v11

    .line 424
    .line 425
    move/from16 v24, v6

    .line 426
    .line 427
    move/from16 v25, p12

    .line 428
    .line 429
    move/from16 p0, p11

    .line 430
    .line 431
    move-object/from16 p1, v15

    .line 432
    .line 433
    move-object/from16 p2, v9

    .line 434
    .line 435
    invoke-static/range {v20 .. v34}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionAction(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 436
    .line 437
    .line 438
    invoke-static {v4, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 439
    .line 440
    .line 441
    goto :goto_4

    .line 442
    :cond_12
    const v11, 0xc190ca7

    .line 443
    .line 444
    .line 445
    invoke-interface {v2, v11}, LX/2d4;->Agj(I)V

    .line 446
    .line 447
    .line 448
    goto :goto_3

    .line 449
    :cond_13
    move-object/from16 v10, v19

    .line 450
    .line 451
    goto/16 :goto_2

    .line 452
    .line 453
    :cond_14
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 454
    .line 455
    .line 456
    :goto_4
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 457
    .line 458
    .line 459
    move-result-object v2

    .line 460
    if-eqz v2, :cond_15

    .line 461
    .line 462
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRow$2;

    .line 463
    .line 464
    move-object/from16 v22, v0

    .line 465
    .line 466
    move-object/from16 v23, v3

    .line 467
    .line 468
    move-object/from16 v24, v19

    .line 469
    .line 470
    move/from16 v25, p12

    .line 471
    .line 472
    move/from16 v26, v18

    .line 473
    .line 474
    move/from16 p0, v17

    .line 475
    .line 476
    move/from16 p1, p11

    .line 477
    .line 478
    move-object/from16 p2, p10

    .line 479
    .line 480
    move-object/from16 p3, v15

    .line 481
    .line 482
    move-object/from16 p4, v9

    .line 483
    .line 484
    move-object/from16 p5, v8

    .line 485
    .line 486
    move-object/from16 p6, v5

    .line 487
    .line 488
    move/from16 p7, v1

    .line 489
    .line 490
    invoke-direct/range {v22 .. v36}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRow$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;III)V

    .line 491
    .line 492
    .line 493
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 494
    .line 495
    :cond_15
    return-void
.end method

.method public static final ActivePermissionRowContainer(IILX/JDN;LX/2d4;I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const v0, -0x6291208e

    .line 5
    .line 6
    .line 7
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    if-nez v0, :cond_5

    .line 13
    .line 14
    invoke-static {p3, p0}, LX/004;->A0E(LX/2d4;I)I

    .line 15
    .line 16
    .line 17
    move-result v7

    .line 18
    or-int/2addr v7, p4

    .line 19
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 20
    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-static {p3, p1}, LX/004;->A0F(LX/2d4;I)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    or-int/2addr v7, v0

    .line 28
    :cond_0
    and-int/lit16 v0, p4, 0x180

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    invoke-static {p3, p2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v7, v0

    .line 37
    :cond_1
    and-int/lit16 v1, v7, 0x93

    .line 38
    .line 39
    const/16 v0, 0x92

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-static {v0, p3, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 53
    .line 54
    sget-object v6, LX/2sI;->A02:LX/2wD;

    .line 55
    .line 56
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 57
    .line 58
    const/4 v3, 0x6

    .line 59
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevated:J

    .line 64
    .line 65
    if-nez p0, :cond_3

    .line 66
    .line 67
    if-nez p1, :cond_2

    .line 68
    .line 69
    const v2, -0x2cb03f2

    .line 70
    .line 71
    .line 72
    invoke-interface {p3, v2}, LX/2d4;->Agj(I)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    iget v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 80
    .line 81
    invoke-static {v2}, LX/2bA;->A00(F)LX/2bC;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    :goto_1
    invoke-static {p3}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    :goto_2
    invoke-static {v6, v3, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-static {p3}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 98
    .line 99
    .line 100
    move-result v8

    .line 101
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-static {p3, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 110
    .line 111
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 112
    .line 113
    if-nez v0, :cond_6

    .line 114
    .line 115
    invoke-static {}, LX/1VY;->A00()V

    .line 116
    .line 117
    .line 118
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    throw v0

    .line 123
    :cond_2
    const v2, -0x2caf375

    .line 124
    .line 125
    .line 126
    invoke-interface {p3, v2}, LX/2d4;->Agj(I)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    iget v8, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 134
    .line 135
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    iget v3, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 140
    .line 141
    const/4 v2, 0x0

    .line 142
    invoke-static {v8, v3, v2, v2}, LX/2bA;->A01(FFFF)LX/2bC;

    .line 143
    .line 144
    .line 145
    move-result-object v3

    .line 146
    goto :goto_1

    .line 147
    :cond_3
    if-ne p0, p1, :cond_4

    .line 148
    .line 149
    const v2, -0x568f0eef

    .line 150
    .line 151
    .line 152
    invoke-interface {p3, v2}, LX/2d4;->Agj(I)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    iget v8, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 160
    .line 161
    invoke-virtual {v9, p3, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    iget v3, v2, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 166
    .line 167
    const/4 v2, 0x0

    .line 168
    invoke-static {v2, v2, v3, v8}, LX/2bA;->A01(FFFF)LX/2bC;

    .line 169
    .line 170
    .line 171
    move-result-object v3

    .line 172
    goto :goto_1

    .line 173
    :cond_4
    const v2, -0x2caafc0

    .line 174
    .line 175
    .line 176
    invoke-static {p3, v2}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    sget-object v3, LX/2oZ;->A00:LX/2bW;

    .line 181
    .line 182
    goto :goto_2

    .line 183
    :cond_5
    move v7, p4

    .line 184
    goto/16 :goto_0

    .line 185
    .line 186
    :cond_6
    invoke-static {p3, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 187
    .line 188
    .line 189
    invoke-static {p3, v9, v6, v3, v8}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 190
    .line 191
    .line 192
    shr-int/lit8 v0, v7, 0x6

    .line 193
    .line 194
    invoke-static {p3, p2, v0}, LX/003;->A19(Ljava/lang/Object;LX/JDN;I)V

    .line 195
    .line 196
    .line 197
    if-ge p0, p1, :cond_7

    .line 198
    .line 199
    const v0, -0x481226fb

    .line 200
    .line 201
    .line 202
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 203
    .line 204
    .line 205
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 206
    .line 207
    invoke-static {v5, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    invoke-static {v0, p3, v4, v4}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 212
    .line 213
    .line 214
    :goto_3
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 215
    .line 216
    .line 217
    goto :goto_4

    .line 218
    :cond_7
    const v0, -0x4810e7e6

    .line 219
    .line 220
    .line 221
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 222
    .line 223
    .line 224
    goto :goto_3

    .line 225
    :cond_8
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 226
    .line 227
    .line 228
    :goto_4
    invoke-interface {p3}, LX/2d4;->AAg()LX/J7V;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    if-eqz v1, :cond_9

    .line 233
    .line 234
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;

    .line 235
    .line 236
    invoke-direct {v0, p0, p1, p2, p4}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;-><init>(IILX/JDN;I)V

    .line 237
    .line 238
    .line 239
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 240
    .line 241
    :cond_9
    return-void
.end method

.method public static final synthetic access$ActivePermissionAction(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p14}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionAction(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionActionSpinner(LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionActionSpinner(LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionDetails(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionDetails(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionModeControl(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p15}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeControl(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/Ddn;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ActivePermissionModeLabel(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionModeLabel(Ljava/lang/String;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final fallbackIconRes(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)I
    .locals 1

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_1

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->iconKey:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    throw v0

    .line 24
    :pswitch_0
    const v0, 0x7f080244

    .line 25
    .line 26
    .line 27
    return v0

    .line 28
    :pswitch_1
    const v0, 0x7f080286

    .line 29
    .line 30
    .line 31
    return v0

    .line 32
    :pswitch_2
    const v0, 0x7f0801ac

    .line 33
    .line 34
    .line 35
    return v0

    .line 36
    :cond_0
    :pswitch_3
    const v0, 0x7f080192

    .line 37
    .line 38
    .line 39
    return v0

    .line 40
    :cond_1
    :pswitch_4
    const v0, 0x7f0801ad

    .line 41
    .line 42
    .line 43
    return v0

    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_3
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_3
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public static final isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;->NETWORK_RULE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 7
    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;->TRANSIENT_NETWORK_GRANT:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 11
    .line 12
    if-ne v1, v0, :cond_1

    .line 13
    .line 14
    :cond_0
    const/4 v2, 0x1

    .line 15
    :cond_1
    return v2
.end method

.method public static final permissionModeTextColor(Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)J
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->DENY:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 1
    .line 2
    if-ne p0, v0, :cond_0

    .line 3
    .line 4
    const v0, -0x72c6da92

    .line 5
    .line 6
    .line 7
    invoke-static {p1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->destructiveText:J

    .line 12
    .line 13
    :goto_0
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    return-wide v0

    .line 17
    :cond_0
    const v0, -0x72c6d554

    .line 18
    .line 19
    .line 20
    invoke-static {p1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 25
    .line 26
    goto :goto_0
.end method
