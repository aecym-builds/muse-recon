.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $menuPermissionId:Ljava/lang/String;

.field public final synthetic $onDismissMenu:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onMenuRequested:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onModeSelected:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRevoke:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$menuPermissionId:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onRevoke:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onMenuRequested:LX/JDM;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onModeSelected:LX/JDN;

    .line 13
    .line 14
    const/4 v0, 0x2

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 16

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    invoke-static {v1}, LX/005;->A1D(I)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    move-object/from16 v15, p1

    .line 7
    .line 8
    invoke-static {v0, v15, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_9

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    iget-object v2, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 17
    .line 18
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 19
    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 27
    .line 28
    const/4 v6, 0x1

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    :cond_0
    const/4 v6, 0x0

    .line 32
    :cond_1
    iget-object v4, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 33
    .line 34
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 35
    .line 36
    if-eqz v1, :cond_8

    .line 37
    .line 38
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 39
    .line 40
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Ljava/lang/String;

    .line 45
    .line 46
    :goto_0
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 47
    .line 48
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 51
    .line 52
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 59
    .line 60
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 63
    .line 64
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v8

    .line 70
    iget-object v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$menuPermissionId:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 73
    .line 74
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 75
    .line 76
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v9

    .line 80
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onRevoke:LX/JDM;

    .line 81
    .line 82
    invoke-interface {v15, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 87
    .line 88
    invoke-static {v15, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    iget-object v2, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onRevoke:LX/JDM;

    .line 93
    .line 94
    iget-object v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 95
    .line 96
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v10

    .line 100
    if-nez v0, :cond_2

    .line 101
    .line 102
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 103
    .line 104
    if-ne v10, v0, :cond_3

    .line 105
    .line 106
    :cond_2
    new-instance v10, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$2$1;

    .line 107
    .line 108
    invoke-direct {v10, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$2$1;-><init>(LX/JDM;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)V

    .line 109
    .line 110
    .line 111
    invoke-interface {v15, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    :cond_3
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 115
    .line 116
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onMenuRequested:LX/JDM;

    .line 117
    .line 118
    invoke-interface {v15, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 123
    .line 124
    invoke-static {v15, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    iget-object v2, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onMenuRequested:LX/JDM;

    .line 129
    .line 130
    iget-object v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 131
    .line 132
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v11

    .line 136
    if-nez v0, :cond_4

    .line 137
    .line 138
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 139
    .line 140
    if-ne v11, v0, :cond_5

    .line 141
    .line 142
    :cond_4
    new-instance v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$3$1;

    .line 143
    .line 144
    invoke-direct {v11, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$3$1;-><init>(LX/JDM;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)V

    .line 145
    .line 146
    .line 147
    invoke-interface {v15, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_5
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 151
    .line 152
    iget-object v12, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onDismissMenu:Lkotlin/jvm/functions/Function0;

    .line 153
    .line 154
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onModeSelected:LX/JDN;

    .line 155
    .line 156
    invoke-interface {v15, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v1

    .line 160
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 161
    .line 162
    invoke-static {v15, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    iget-object v2, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$onModeSelected:LX/JDN;

    .line 167
    .line 168
    iget-object v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 169
    .line 170
    invoke-interface {v15}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v13

    .line 174
    if-nez v0, :cond_6

    .line 175
    .line 176
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 177
    .line 178
    if-ne v13, v0, :cond_7

    .line 179
    .line 180
    :cond_6
    new-instance v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$4$1;

    .line 181
    .line 182
    invoke-direct {v13, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$4$1$4$1;-><init>(LX/JDN;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)V

    .line 183
    .line 184
    .line 185
    invoke-interface {v15, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    :cond_7
    check-cast v13, LX/JDM;

    .line 189
    .line 190
    sget p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->$stable:I

    .line 191
    .line 192
    const/16 p1, 0x0

    .line 193
    .line 194
    const/16 p2, 0x400

    .line 195
    .line 196
    const/4 v14, 0x0

    .line 197
    invoke-static/range {v4 .. v18}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionRow(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Ljava/lang/String;ZZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;III)V

    .line 198
    .line 199
    .line 200
    return-void

    .line 201
    :cond_8
    const/4 v5, 0x0

    .line 202
    goto/16 :goto_0

    .line 203
    .line 204
    :cond_9
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 205
    .line 206
    .line 207
    return-void
.end method
