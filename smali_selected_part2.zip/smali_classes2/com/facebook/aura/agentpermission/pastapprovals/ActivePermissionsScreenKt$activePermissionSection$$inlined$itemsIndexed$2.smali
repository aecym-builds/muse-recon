.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDM<",
        "Ljava/lang/Integer;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $items:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;->$items:Ljava/util/List;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke(I)Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;->$items:Ljava/util/List;

    .line 268435457
    .line 268435458
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    const-string p0, "active_permission_row"

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p1}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$activePermissionSection$$inlined$itemsIndexed$2;->$items:Ljava/util/List;

    .line 5
    .line 6
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    const-string p0, "active_permission_row"

    .line 10
    .line 11
    return-object p0
.end method
