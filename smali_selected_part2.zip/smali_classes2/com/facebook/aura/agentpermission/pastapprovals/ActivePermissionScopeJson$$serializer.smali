.class public final synthetic Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x6

    .line 8
    const-string v0, "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionScopeJson"

    .line 9
    .line 10
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v0, "scope_type"

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    const-string v0, "session_scope_id"

    .line 21
    .line 22
    invoke-static {v0, v2, v1}, LX/3Rr;->A1K(Ljava/lang/String;LX/DZp;Z)V

    .line 23
    .line 24
    .line 25
    const-string v0, "space_slug"

    .line 26
    .line 27
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 28
    .line 29
    .line 30
    const-string v0, "schedule_id"

    .line 31
    .line 32
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 33
    .line 34
    .line 35
    const-string v0, "idea_scope_id"

    .line 36
    .line 37
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 38
    .line 39
    .line 40
    sput-object v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->descriptor:LX/Da5;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {p0, v0}, LX/3Rt;->A0H(LX/DZ7;LX/DZ7;)[LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 15

    .line 0
    const/4 v8, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v7}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v5, 0x5

    .line 13
    const/4 v4, 0x3

    .line 14
    const/4 v3, 0x4

    .line 15
    const/4 v2, 0x2

    .line 16
    const/4 v1, 0x1

    .line 17
    const/4 v10, 0x0

    .line 18
    move-object v11, v10

    .line 19
    move-object v12, v10

    .line 20
    move-object v13, v10

    .line 21
    move-object v14, v10

    .line 22
    move-object p0, v10

    .line 23
    const/4 v9, 0x0

    .line 24
    :goto_0
    invoke-interface {v6, v7}, LX/Da7;->A8S(LX/Da5;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    packed-switch v0, :pswitch_data_0

    .line 29
    .line 30
    .line 31
    invoke-static {v0}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    throw v0

    .line 36
    :pswitch_0
    invoke-static {v7, v6, v8}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v10

    .line 40
    or-int/lit8 v9, v9, 0x1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :pswitch_1
    invoke-static {v7, v6, v1}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v11

    .line 47
    or-int/lit8 v9, v9, 0x2

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :pswitch_2
    invoke-static {v7, v6, v2}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v12

    .line 54
    or-int/lit8 v9, v9, 0x4

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :pswitch_3
    invoke-static {v7, v6, v4}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v13

    .line 61
    or-int/lit8 v9, v9, 0x8

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :pswitch_4
    invoke-static {v7, v6, v3}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v14

    .line 68
    or-int/lit8 v9, v9, 0x10

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :pswitch_5
    invoke-static {v7, v6, v5}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    or-int/lit8 v9, v9, 0x20

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :pswitch_6
    invoke-interface {v6, v7}, LX/Da7;->AAi(LX/Da5;)V

    .line 79
    .line 80
    .line 81
    const/16 p1, 0x0

    .line 82
    .line 83
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 84
    .line 85
    invoke-direct/range {v8 .. v16}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 86
    .line 87
    .line 88
    return-object v8

    .line 89
    nop

    .line 90
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_6
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
