.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/JOw;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $destructiveTextColor:J


# direct methods
.method public constructor <init>(J)V
    .locals 1

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3$1$1;->$destructiveTextColor:J

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3$1$1;->$destructiveTextColor:J

    .line 1
    .line 2
    invoke-static {v0, p0}, LX/001;->A0d(J)LX/JOw;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
.end method

.method public final invoke-QN2ZGVo()LX/JOw;
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$3$1$1;->$destructiveTextColor:J

    .line 1
    .line 2
    invoke-static {v0, p0}, LX/001;->A0d(J)LX/JOw;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
.end method
