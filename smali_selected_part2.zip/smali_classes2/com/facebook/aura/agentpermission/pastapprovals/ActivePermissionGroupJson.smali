.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson$Companion;


# instance fields
.field public final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation
.end field

.field public final scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v2, v0}, LX/3Rr;->A1X(Ljava/lang/Integer;Lkotlin/Lazy;Lkotlin/jvm/functions/Function0;)[Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->$childSerializers:[Lkotlin/Lazy;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;LX/5Xm;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    and-int/lit8 v0, p1, 0x1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const/4 p2, 0x0

    .line 8
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 9
    .line 10
    and-int/lit8 v0, p1, 0x2

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 15
    .line 16
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 17
    .line 18
    return-void

    .line 19
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x1

    .line 268435457
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 268435466
    .line 268435467
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;ILX/04f;)V
    .locals 1

    .line 536870912
    and-int/lit8 v0, p3, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    const/4 p1, 0x0

    .line 536870917
    :cond_0
    invoke-static {p2, p3}, LX/3Rr;->A0t(Ljava/util/List;I)Ljava/util/List;

    .line 536870918
    .line 536870919
    .line 536870920
    move-result-object v0

    .line 536870921
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)V

    .line 536870922
    .line 536870923
    .line 536870924
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x1

    .line 13
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson$$serializer;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v2, 0x1

    .line 21
    if-nez v3, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 24
    .line 25
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    :cond_2
    invoke-static {v4, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 36
    .line 37
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getItems()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScope()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public final toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;
    .locals 6

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;

    .line 1
    .line 2
    const/4 v5, 0x0

    .line 3
    if-eqz v0, :cond_4

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeJson;->toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    if-eqz v4, :cond_4

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroupJson;->items:Ljava/util/List;

    .line 12
    .line 13
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;

    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionJson;->toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    :cond_2
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    move-object v0, v1

    .line 62
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 63
    .line 64
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->isVisibleInApprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_2

    .line 69
    .line 70
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_3
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_4

    .line 79
    .line 80
    new-instance v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 81
    .line 82
    invoke-direct {v5, v4, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;Ljava/util/List;)V

    .line 83
    .line 84
    .line 85
    :cond_4
    return-object v5
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
