.class public abstract Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ACTIVE_PERMISSIONS_GROUPED_KINDS:Ljava/lang/String; = "network_rule,transient_connector_grant,transient_network_grant"

.field public static final ACTIVE_PERMISSIONS_GROUPED_SCOPE_TYPES:Ljava/lang/String; = "schedule,space"

.field public static final ACTIVE_PERMISSIONS_GROUP_BY_SCOPE:Ljava/lang/String; = "scope"

.field public static final ACTIVE_PERMISSIONS_GROUP_PAGE_SIZE:I = 0x14

.field public static final ACTIVE_PERMISSIONS_LIFETIMES:Ljava/lang/String; = "durable,today"

.field public static final ACTIVE_PERMISSIONS_NETWORK_KINDS:Ljava/lang/String; = "network_rule,transient_network_grant"

.field public static final ACTIVE_PERMISSIONS_PAGE_SIZE:I = 0x32
