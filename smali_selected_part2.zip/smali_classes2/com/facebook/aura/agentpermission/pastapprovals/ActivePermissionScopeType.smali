.class public final enum Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType$Companion;

.field public static final enum FEED:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

.field public static final enum IDEA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

.field public static final enum SCHEDULE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

.field public static final enum SPACE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;


# instance fields
.field public final wireValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "schedule"

    .line 2
    .line 3
    const-string v0, "SCHEDULE"

    .line 4
    .line 5
    new-instance v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 6
    .line 7
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SCHEDULE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "space"

    .line 14
    .line 15
    const-string v0, "SPACE"

    .line 16
    .line 17
    new-instance v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 18
    .line 19
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->SPACE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "idea"

    .line 26
    .line 27
    const-string v0, "IDEA"

    .line 28
    .line 29
    new-instance v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 30
    .line 31
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->IDEA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 35
    .line 36
    const/4 v3, 0x3

    .line 37
    const-string v2, "feed"

    .line 38
    .line 39
    const-string v1, "FEED"

    .line 40
    .line 41
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 42
    .line 43
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->FEED:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 47
    .line 48
    filled-new-array {v6, v5, v4, v0}, [Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->$VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 53
    .line 54
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->$ENTRIES:LX/0vk;

    .line 59
    .line 60
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType$Companion;

    .line 61
    .line 62
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 63
    .line 64
    .line 65
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType$Companion;

    .line 66
    .line 67
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->wireValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->$VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getWireValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;->wireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
