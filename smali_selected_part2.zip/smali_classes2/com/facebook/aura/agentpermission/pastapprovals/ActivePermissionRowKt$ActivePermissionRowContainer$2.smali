.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $content:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $index:I

.field public final synthetic $lastIndex:I


# direct methods
.method public constructor <init>(IILX/JDN;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;I)V"
        }
    .end annotation

    .line 0
    iput p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$index:I

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$lastIndex:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$content:LX/JDN;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$$changed:I

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 0
    iget v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$index:I

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$lastIndex:I

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$content:LX/JDN;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt$ActivePermissionRowContainer$2;->$$changed:I

    .line 7
    .line 8
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-static {v3, v2, v1, p1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->ActivePermissionRowContainer(IILX/JDN;LX/2d4;I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
