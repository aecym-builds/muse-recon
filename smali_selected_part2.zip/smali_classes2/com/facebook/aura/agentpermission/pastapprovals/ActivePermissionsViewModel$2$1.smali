.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(LX/Ddn;LX/2M4;)Ljava/lang/Object;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/skills/model/Skill;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/facebook/aura/skills/model/Skill;

    .line 19
    .line 20
    iget-object v1, v0, Lcom/facebook/aura/skills/model/Skill;->iconUrl:Ljava/lang/String;

    .line 21
    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    iget-object v0, v0, Lcom/facebook/aura/skills/model/Skill;->id:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0, v1, v3}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    invoke-static {v3}, LX/1HA;->A09(Ljava/lang/Iterable;)Ljava/util/Map;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-static {v0}, LX/Dwp;->A06(Ljava/util/Map;)LX/IZf;

    .line 35
    .line 36
    .line 37
    move-result-object v15

    .line 38
    move-object/from16 v0, p0

    .line 39
    .line 40
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 41
    .line 42
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 43
    .line 44
    :cond_2
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    move-object v3, v1

    .line 49
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 50
    .line 51
    const/16 p0, 0x7ff

    .line 52
    .line 53
    const/4 v4, 0x0

    .line 54
    const/4 v6, 0x0

    .line 55
    move-object v5, v4

    .line 56
    move-object v7, v4

    .line 57
    move-object v8, v4

    .line 58
    move-object v9, v4

    .line 59
    move v10, v6

    .line 60
    move v11, v6

    .line 61
    move-object v12, v4

    .line 62
    move-object v13, v4

    .line 63
    move v14, v6

    .line 64
    move-object/from16 p1, v4

    .line 65
    .line 66
    invoke-static/range {v3 .. v17}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_2

    .line 75
    .line 76
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 77
    .line 78
    return-object v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/Ddn;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2$1;->emit(LX/Ddn;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
