.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lkotlin/Unit;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsRepository$setPermissionMode$2"
    f = "ActivePermissionsRepository.kt"
    l = {
        0xab
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

.field public final synthetic $permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public I$4:I

.field public I$5:I

.field public I$6:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v3, p0

    .line 3
    .line 4
    iget v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->label:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-ne v0, v1, :cond_3

    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    :cond_0
    instance-of v0, v1, LX/2PH;

    .line 16
    .line 17
    xor-int/lit8 v0, v0, 0x1

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 22
    .line 23
    :cond_1
    invoke-static {v1}, LX/3Rp;->A12(Ljava/lang/Object;)LX/2PJ;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    return-object v2

    .line 28
    :cond_2
    invoke-static/range {p1 .. p1}, LX/3Rp;->A08(Ljava/lang/Object;)Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 29
    .line 30
    .line 31
    move-result-object v7

    .line 32
    sget-object v11, Lcom/facebook/aura/network/api/JarvisPath$PermissionsActive;->INSTANCE:Lcom/facebook/aura/network/api/JarvisPath$PermissionsActive;

    .line 33
    .line 34
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$permission:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 35
    .line 36
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 39
    .line 40
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;->getWireValue()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->$mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 45
    .line 46
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->getWireValue()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    const/4 v15, 0x0

    .line 51
    const-string v0, "ui"

    .line 52
    .line 53
    new-instance v12, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;

    .line 54
    .line 55
    invoke-direct {v12, v6, v5, v4, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/SetActivePermissionModeRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sget-object v13, Lcom/facebook/aura/network/http/RequestType;->PATCH:Lcom/facebook/aura/network/http/RequestType;

    .line 59
    .line 60
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 61
    .line 62
    iget-object v14, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->userSession:LX/AHE;

    .line 63
    .line 64
    const/4 v10, 0x0

    .line 65
    new-array v0, v10, [LX/IBK;

    .line 66
    .line 67
    invoke-static {}, LX/3Rq;->A1F()Ljava/util/Set;

    .line 68
    .line 69
    .line 70
    move-result-object v18

    .line 71
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 72
    .line 73
    .line 74
    move-result-object v21

    .line 75
    sget-object v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$1;

    .line 76
    .line 77
    sget-object v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$2;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$2;

    .line 78
    .line 79
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$0:Ljava/lang/Object;

    .line 80
    .line 81
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$1:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$2:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$3:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$4:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$5:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$6:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v15, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->L$7:Ljava/lang/Object;

    .line 94
    .line 95
    iput v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$0:I

    .line 96
    .line 97
    iput v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$1:I

    .line 98
    .line 99
    iput v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$2:I

    .line 100
    .line 101
    iput v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$3:I

    .line 102
    .line 103
    iput v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$4:I

    .line 104
    .line 105
    iput v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$5:I

    .line 106
    .line 107
    iput v10, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->I$6:I

    .line 108
    .line 109
    iput v1, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$setPermissionMode$2;->label:I

    .line 110
    .line 111
    move-object/from16 v16, v15

    .line 112
    .line 113
    move/from16 v19, v1

    .line 114
    .line 115
    move/from16 v20, v1

    .line 116
    .line 117
    move-object/from16 v22, v15

    .line 118
    .line 119
    move/from16 v23, v10

    .line 120
    .line 121
    move/from16 v24, v1

    .line 122
    .line 123
    move/from16 v25, v10

    .line 124
    .line 125
    move/from16 v26, v10

    .line 126
    .line 127
    move-object/from16 v27, v15

    .line 128
    .line 129
    move/from16 p0, v10

    .line 130
    .line 131
    move-object/from16 p1, v3

    .line 132
    .line 133
    move-object/from16 v17, v0

    .line 134
    .line 135
    invoke-virtual/range {v7 .. v29}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeJarvisRequestWith-Fof5HsY(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/JarvisPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;LX/AHE;Ljava/lang/Long;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;[LX/IBK;Ljava/util/Set;ZZLjava/util/Map;Ljava/lang/String;ZZZZLjava/lang/String;ZLX/2M4;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    if-ne v1, v2, :cond_0

    .line 140
    .line 141
    return-object v2

    .line 142
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    throw v0
.end method
