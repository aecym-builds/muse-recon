.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$Companion;


# instance fields
.field public final iconKey:Ljava/lang/String;

.field public final iconUrl:Ljava/lang/String;

.field public final mode_label:Ljava/lang/String;

.field public final permissionCaption:Ljava/lang/String;

.field public final summaryTitle:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v0, p0

    .line 2
    move-object v2, v1

    .line 3
    move-object v3, v1

    .line 4
    move-object v4, v1

    .line 5
    move-object p0, v1

    .line 6
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const/4 v1, 0x0

    .line 536870918
    if-nez v0, :cond_3

    .line 536870919
    .line 536870920
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 536870921
    .line 536870922
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    if-nez v0, :cond_2

    .line 536870925
    .line 536870926
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 536870927
    .line 536870928
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_1

    .line 536870931
    .line 536870932
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 536870933
    .line 536870934
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 536870935
    .line 536870936
    if-nez v0, :cond_0

    .line 536870937
    .line 536870938
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 536870939
    .line 536870940
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 536870941
    .line 536870942
    if-nez v0, :cond_4

    .line 536870943
    .line 536870944
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 536870945
    .line 536870946
    return-void

    .line 536870947
    :cond_0
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 536870948
    .line 536870949
    goto :goto_3

    .line 536870950
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 536870951
    .line 536870952
    goto :goto_2

    .line 536870953
    :cond_2
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 536870954
    .line 536870955
    goto :goto_1

    .line 536870956
    :cond_3
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 536870957
    .line 536870958
    goto :goto_0

    .line 536870959
    :cond_4
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 536870960
    .line 536870961
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 805306368
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 805306369
    .line 805306370
    .line 805306371
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 805306372
    .line 805306373
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 805306374
    .line 805306375
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 805306376
    .line 805306377
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 805306378
    .line 805306379
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 805306380
    .line 805306381
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p6, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 268435478
    .line 268435479
    if-eqz v0, :cond_4

    .line 268435480
    .line 268435481
    move-object p5, v1

    .line 268435482
    :cond_4
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435483
    .line 268435484
    .line 268435485
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static synthetic getIconKey$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic getIconUrl$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic getPermissionCaption$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static synthetic getSummaryTitle$annotations()V
    .locals 0

    .line 0
    return-void
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_agentpermission_pastapprovals_pastapprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v3, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    const/4 v2, 0x3

    .line 47
    if-nez v3, :cond_6

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v0, :cond_7

    .line 52
    .line 53
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 58
    .line 59
    .line 60
    :cond_7
    const/4 v2, 0x4

    .line 61
    if-nez v3, :cond_8

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_9

    .line 66
    .line 67
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 70
    .line 71
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 72
    .line 73
    .line 74
    :cond_9
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getIconKey()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getIconUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode_label()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermissionCaption()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSummaryTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    add-int/2addr v1, v0

    .line 15
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    add-int/2addr v1, v0

    .line 24
    mul-int/lit8 v1, v1, 0x1f

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v1, v0

    .line 33
    mul-int/lit8 v1, v1, 0x1f

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 36
    .line 37
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    add-int/2addr v1, v0

    .line 42
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;
    .locals 7

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->summaryTitle:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    if-eqz v3, :cond_6

    .line 4
    .line 5
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_6

    .line 10
    .line 11
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->permissionCaption:Ljava/lang/String;

    .line 12
    .line 13
    if-eqz v4, :cond_0

    .line 14
    .line 15
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    :cond_0
    move-object v4, v2

    .line 22
    :cond_1
    sget-object v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey$Companion;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconKey:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->iconUrl:Ljava/lang/String;

    .line 31
    .line 32
    if-eqz v6, :cond_2

    .line 33
    .line 34
    invoke-static {v6}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    :cond_2
    move-object v6, v2

    .line 41
    :cond_3
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplayJson;->mode_label:Ljava/lang/String;

    .line 42
    .line 43
    if-eqz p0, :cond_4

    .line 44
    .line 45
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_5

    .line 50
    .line 51
    :cond_4
    move-object p0, v2

    .line 52
    :cond_5
    new-instance v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 53
    .line 54
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    :cond_6
    return-object v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
