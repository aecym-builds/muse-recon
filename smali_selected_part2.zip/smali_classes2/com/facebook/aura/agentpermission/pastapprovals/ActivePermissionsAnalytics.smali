.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->PERMISSIONS:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->MANAGE_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    move-object v4, p1

    .line 10
    move-object p1, p2

    .line 11
    move-object p2, p0

    .line 12
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public static synthetic logClick$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final permissionKey(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x1

    .line 5
    if-eq p1, p0, :cond_2

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    if-eq p1, p0, :cond_1

    .line 9
    .line 10
    const/4 p0, 0x2

    .line 11
    if-eq p1, p0, :cond_0

    .line 12
    .line 13
    const/4 p0, 0x3

    .line 14
    if-eq p1, p0, :cond_0

    .line 15
    .line 16
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    throw p0

    .line 21
    :cond_0
    const/4 p0, 0x0

    .line 22
    return-object p0

    .line 23
    :cond_1
    const-string p0, "scheduled_tasks"

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_2
    const-string p0, "artifacts"

    .line 27
    .line 28
    return-object p0
.end method


# virtual methods
.method public final logLoadMore()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchComponent;->LOAD_MORE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logModeSelected(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;)V
    .locals 4

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchComponent;->PERMISSION_ROW:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 4
    .line 5
    new-instance v2, LX/Imj;

    .line 6
    .line 7
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 8
    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PERMISSION_MODE:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {p2}, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->getWireValue()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    iget-object v1, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->connectorKey:Ljava/lang/String;

    .line 24
    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PROVIDER:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 28
    .line 29
    invoke-static {v0, v1, v2}, LX/3Rr;->A16(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;Ljava/lang/Object;LX/Imj;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 37
    .line 38
    if-eqz v1, :cond_1

    .line 39
    .line 40
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 41
    .line 42
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->permissionKey(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PERMISSION_KEY:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 49
    .line 50
    invoke-static {v0, v1, v2}, LX/3Rr;->A16(Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;Ljava/lang/Object;LX/Imj;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-direct {p0, v3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method

.method public final logReset()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchComponent;->RESET_DEFAULTS_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final logWebsiteRevoke()V
    .locals 4

    .line 0
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchComponent;->PERMISSION_ROW:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PERMISSION_KEY:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-string v0, "websites"

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->PERMISSION_MODE:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    const-string v0, "revoke"

    .line 21
    .line 22
    invoke-static {v1, v0, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-direct {p0, v3, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
