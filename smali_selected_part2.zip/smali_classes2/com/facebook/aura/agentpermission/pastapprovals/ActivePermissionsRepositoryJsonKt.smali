.class public abstract Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final synthetic access$isVisibleInApprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->isVisibleInApprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$toConnectorPermissionModeOrNull(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepositoryJsonKt;->toConnectorPermissionModeOrNull(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final isVisibleInApprovals(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->kind:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;->CONNECTOR_OVERRIDE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionKind;

    .line 3
    .line 4
    if-eq v1, v0, :cond_1

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->lifetime:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;->DURABLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 9
    .line 10
    if-eq v1, v0, :cond_0

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;->TODAY:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionLifetime;

    .line 13
    .line 14
    if-ne v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    const/4 v0, 0x1

    .line 17
    return v0

    .line 18
    :cond_1
    const/4 v0, 0x0

    .line 19
    return v0
.end method

.method public static final toConnectorPermissionModeOrNull(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;
    .locals 3

    .line 0
    invoke-static {}, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->getEntries()LX/0vk;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    move-object v0, v1

    .line 19
    check-cast v0, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->getWireValue()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {v0, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    :goto_0
    check-cast v1, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 32
    .line 33
    return-object v1

    .line 34
    :cond_1
    const/4 v1, 0x0

    .line 35
    goto :goto_0
.end method
