.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;->create()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;
    .locals 5

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$Factory;->userSession:LX/AHE;

    .line 1
    .line 2
    const/4 v4, 0x6

    .line 3
    const/4 v2, 0x0

    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;

    .line 5
    .line 6
    move-object v3, v2

    .line 7
    move-object p0, v2

    .line 8
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;-><init>(LX/AHE;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;ILX/04f;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
