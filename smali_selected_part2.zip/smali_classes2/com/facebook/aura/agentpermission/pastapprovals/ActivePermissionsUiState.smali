.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final canLoadMore:Z

.field public final connectorIconUrls:LX/0Xl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final groupCursor:Ljava/lang/String;

.field public final groups:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;"
        }
    .end annotation
.end field

.field public final isGrouped:Z

.field public final isLoadingMore:Z

.field public final isResetting:Z

.field public final loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

.field public final nextCursor:Ljava/lang/String;

.field public final permissions:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;"
        }
    .end annotation
.end field

.field public final revokingPermissionId:Ljava/lang/String;

.field public final updatingPermissionId:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    sget v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->$stable:I

    .line 1
    .line 2
    sget v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->$stable:I

    .line 3
    .line 4
    or-int/2addr v1, v0

    .line 5
    sput v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->$stable:I

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 13

    .line 0
    const/4 v5, 0x0

    .line 1
    sget-object v1, LX/Dwg;->A01:LX/Dwg;

    .line 2
    .line 3
    const/4 v3, 0x0

    .line 4
    sget-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 5
    .line 6
    const/4 v7, 0x1

    .line 7
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 8
    .line 9
    .line 10
    move-result-object v12

    .line 11
    move-object v0, p0

    .line 12
    move-object v2, v1

    .line 13
    move-object v6, v5

    .line 14
    move v8, v3

    .line 15
    move-object v9, v5

    .line 16
    move-object v10, v5

    .line 17
    move v11, v3

    .line 18
    invoke-direct/range {v0 .. v12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;-><init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;Z",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 536870912
    invoke-static {p1, p2, p4}, LX/3Rq;->A1S(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536870913
    .line 536870914
    .line 536870915
    const/16 v0, 0xb

    .line 536870916
    .line 536870917
    invoke-static {p12, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 536870918
    .line 536870919
    .line 536870920
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870921
    .line 536870922
    .line 536870923
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 536870924
    .line 536870925
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 536870926
    .line 536870927
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 536870928
    .line 536870929
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 536870930
    .line 536870931
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 536870932
    .line 536870933
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 536870934
    .line 536870935
    iput-boolean p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 536870936
    .line 536870937
    iput-boolean p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 536870938
    .line 536870939
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 536870940
    .line 536870941
    iput-object p10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 536870942
    .line 536870943
    iput-boolean p11, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 536870944
    .line 536870945
    iput-object p12, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 536870946
    .line 536870947
    return-void
.end method

.method public synthetic constructor <init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILX/04f;)V
    .locals 15

    .line 268435456
    move-object/from16 v6, p4

    .line 268435457
    .line 268435458
    move-object/from16 v7, p5

    .line 268435459
    .line 268435460
    move-object/from16 v8, p6

    .line 268435461
    .line 268435462
    move-object/from16 v11, p9

    .line 268435463
    .line 268435464
    move/from16 v1, p13

    .line 268435465
    .line 268435466
    move-object/from16 v3, p1

    .line 268435467
    .line 268435468
    move-object/from16 v4, p2

    .line 268435469
    .line 268435470
    move-object/from16 v14, p12

    .line 268435471
    .line 268435472
    and-int/lit8 v0, p13, 0x1

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_0

    .line 268435475
    .line 268435476
    sget-object v3, LX/Dwg;->A01:LX/Dwg;

    .line 268435477
    .line 268435478
    :cond_0
    and-int/lit8 v0, p13, 0x2

    .line 268435479
    .line 268435480
    if-eqz v0, :cond_1

    .line 268435481
    .line 268435482
    sget-object v4, LX/Dwg;->A01:LX/Dwg;

    .line 268435483
    .line 268435484
    :cond_1
    and-int/lit8 v0, p13, 0x4

    .line 268435485
    .line 268435486
    const/4 v13, 0x0

    .line 268435487
    move/from16 v2, p3

    .line 268435488
    .line 268435489
    invoke-static {v0, v2}, LX/001;->A1P(IZ)Z

    .line 268435490
    .line 268435491
    .line 268435492
    move-result v5

    .line 268435493
    and-int/lit8 v0, p13, 0x8

    .line 268435494
    .line 268435495
    if-eqz v0, :cond_2

    .line 268435496
    .line 268435497
    sget-object v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 268435498
    .line 268435499
    :cond_2
    and-int/lit8 v0, p13, 0x10

    .line 268435500
    .line 268435501
    const/4 v12, 0x0

    .line 268435502
    if-eqz v0, :cond_3

    .line 268435503
    .line 268435504
    move-object v7, v12

    .line 268435505
    :cond_3
    and-int/lit8 v0, p13, 0x20

    .line 268435506
    .line 268435507
    if-eqz v0, :cond_4

    .line 268435508
    .line 268435509
    move-object v8, v12

    .line 268435510
    :cond_4
    and-int/lit8 v0, p13, 0x40

    .line 268435511
    .line 268435512
    move/from16 v2, p7

    .line 268435513
    .line 268435514
    invoke-static {v0, v2}, LX/001;->A1Q(IZ)Z

    .line 268435515
    .line 268435516
    .line 268435517
    move-result v9

    .line 268435518
    move/from16 v0, p8

    .line 268435519
    .line 268435520
    invoke-static {v1, v0}, LX/3Rr;->A1S(IZ)Z

    .line 268435521
    .line 268435522
    .line 268435523
    move-result v10

    .line 268435524
    and-int/lit16 v0, v1, 0x100

    .line 268435525
    .line 268435526
    if-eqz v0, :cond_5

    .line 268435527
    .line 268435528
    move-object v11, v12

    .line 268435529
    :cond_5
    and-int/lit16 v0, v1, 0x200

    .line 268435530
    .line 268435531
    if-nez v0, :cond_6

    .line 268435532
    .line 268435533
    move-object/from16 v12, p10

    .line 268435534
    .line 268435535
    :cond_6
    and-int/lit16 v0, v1, 0x400

    .line 268435536
    .line 268435537
    if-nez v0, :cond_7

    .line 268435538
    .line 268435539
    move/from16 v13, p11

    .line 268435540
    .line 268435541
    :cond_7
    and-int/lit16 v0, v1, 0x800

    .line 268435542
    .line 268435543
    if-eqz v0, :cond_8

    .line 268435544
    .line 268435545
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 268435546
    .line 268435547
    .line 268435548
    move-result-object v14

    .line 268435549
    :cond_8
    move-object v2, p0

    .line 268435550
    invoke-direct/range {v2 .. v14}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;-><init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)V

    .line 268435551
    .line 268435552
    .line 268435553
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p13, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p13, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p13, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p13, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p13, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p13, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p13, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-boolean p7, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p13, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-boolean p8, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p13, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 53
    .line 54
    :cond_8
    and-int/lit16 v0, p13, 0x200

    .line 55
    .line 56
    if-eqz v0, :cond_9

    .line 57
    .line 58
    iget-object p10, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 59
    .line 60
    :cond_9
    and-int/lit16 v0, p13, 0x400

    .line 61
    .line 62
    if-eqz v0, :cond_a

    .line 63
    .line 64
    iget-boolean p11, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 65
    .line 66
    :cond_a
    and-int/lit16 v0, p13, 0x800

    .line 67
    .line 68
    if-eqz v0, :cond_b

    .line 69
    .line 70
    iget-object p12, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 71
    .line 72
    :cond_b
    invoke-virtual/range {p0 .. p12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    return-object v0
.end method


# virtual methods
.method public final component1()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component12()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component8()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;Z",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p4}, LX/3Rq;->A1S(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/16 p0, 0xb

    .line 4
    .line 5
    invoke-static {p12, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 9
    .line 10
    invoke-direct/range {p0 .. p12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;-><init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)V

    .line 11
    .line 12
    .line 13
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 31
    .line 32
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_0

    .line 61
    .line 62
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 63
    .line 64
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 65
    .line 66
    if-ne v1, v0, :cond_0

    .line 67
    .line 68
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 69
    .line 70
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 71
    .line 72
    if-ne v1, v0, :cond_0

    .line 73
    .line 74
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_0

    .line 83
    .line 84
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 85
    .line 86
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 87
    .line 88
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-eqz v0, :cond_0

    .line 93
    .line 94
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 95
    .line 96
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 97
    .line 98
    if-ne v1, v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-nez v0, :cond_1

    .line 109
    .line 110
    :cond_0
    return v2

    .line 111
    :cond_1
    return v3
.end method

.method public final getCanLoadMore()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getConnectorIconUrls()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getGroupCursor()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getGroups()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoadingState()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getNextCursor()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPermissions()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRevokingPermissionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUpdatingPermissionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v1, v0

    .line 31
    mul-int/lit8 v1, v1, 0x1f

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    add-int/2addr v1, v0

    .line 40
    mul-int/lit8 v1, v1, 0x1f

    .line 41
    .line 42
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    add-int/2addr v1, v0

    .line 61
    mul-int/lit8 v1, v1, 0x1f

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    add-int/2addr v1, v0

    .line 70
    mul-int/lit8 v1, v1, 0x1f

    .line 71
    .line 72
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 79
    .line 80
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    return v0
.end method

.method public final isGrouped()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isLoadingMore()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isResetting()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
