.class public final enum Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum BROWSER:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum CHECKOUT:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum CONNECTOR:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey$Companion;

.field public static final enum DEVICE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum MEDIA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum NETWORK:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

.field public static final enum TOOL:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;


# instance fields
.field public final wireValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "network"

    .line 2
    .line 3
    const-string v0, "NETWORK"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->NETWORK:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "connector"

    .line 14
    .line 15
    const-string v0, "CONNECTOR"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->CONNECTOR:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "browser"

    .line 26
    .line 27
    const-string v0, "BROWSER"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->BROWSER:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "tool"

    .line 38
    .line 39
    const-string v0, "TOOL"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->TOOL:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "checkout"

    .line 50
    .line 51
    const-string v0, "CHECKOUT"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->CHECKOUT:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "media"

    .line 62
    .line 63
    const-string v0, "MEDIA"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->MEDIA:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "device"

    .line 74
    .line 75
    const-string v0, "DEVICE"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->DEVICE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 83
    .line 84
    filled-new-array/range {v3 .. v9}, [Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->$VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 89
    .line 90
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->$ENTRIES:LX/0vk;

    .line 95
    .line 96
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey$Companion;

    .line 97
    .line 98
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 99
    .line 100
    .line 101
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey$Companion;

    .line 102
    .line 103
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->wireValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->$VALUES:[Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getWireValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionIconKey;->wireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
