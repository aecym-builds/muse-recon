.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final connectorRepository:Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;

.field public final repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/AHE;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;)V
    .locals 13

    .line 0
    const/4 v3, 0x0

    .line 1
    move-object/from16 v0, p3

    .line 2
    .line 3
    invoke-static {p1, p2, v0}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 10
    .line 11
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->connectorRepository:Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    sget-object v1, LX/Dwg;->A01:LX/Dwg;

    .line 15
    .line 16
    sget-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 17
    .line 18
    const/4 v7, 0x1

    .line 19
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 20
    .line 21
    .line 22
    move-result-object v12

    .line 23
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 24
    .line 25
    move-object v2, v1

    .line 26
    move-object v6, v5

    .line 27
    move v8, v3

    .line 28
    move-object v9, v5

    .line 29
    move-object v10, v5

    .line 30
    move v11, v3

    .line 31
    invoke-direct/range {v0 .. v12}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;-><init>(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)V

    .line 32
    .line 33
    .line 34
    invoke-static {v0}, LX/3Rp;->A17(Ljava/lang/Object;)LX/Ddv;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 39
    .line 40
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->uiState:LX/2J3;

    .line 45
    .line 46
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$1;

    .line 51
    .line 52
    invoke-direct {v0, p0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 53
    .line 54
    .line 55
    sget-object v3, LX/39s;->A00:LX/39s;

    .line 56
    .line 57
    sget-object v2, LX/FkO;->A00:Ljava/lang/Integer;

    .line 58
    .line 59
    invoke-static {v2, v3, v0, v1}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 60
    .line 61
    .line 62
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2;

    .line 67
    .line 68
    invoke-direct {v0, p0, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 69
    .line 70
    .line 71
    invoke-static {v2, v3, v0, v1}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;ILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p4, 0x2

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->Companion:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$Companion;

    .line 268435461
    .line 268435462
    invoke-virtual {v0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object p2

    .line 268435466
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 268435467
    .line 268435468
    if-eqz v0, :cond_1

    .line 268435469
    .line 268435470
    sget-object v0, Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;->Companion:Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository$Companion;

    .line 268435471
    .line 268435472
    invoke-virtual {v0, p1}, Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;

    .line 268435473
    .line 268435474
    .line 268435475
    move-result-object p3

    .line 268435476
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;-><init>(LX/AHE;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;)V

    .line 268435477
    .line 268435478
    .line 268435479
    return-void
.end method

.method public static final synthetic access$applyRefreshedPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->applyRefreshedPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getConnectorRepository$p(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->connectorRepository:Lcom/facebook/aura/skills/repo/HatchConnectorCatalogRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$loadFirstPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->loadFirstPage(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$loadNextPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->loadNextPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final applyRefreshedPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p3

    .line 1
    .line 2
    move-object/from16 v5, p2

    .line 3
    .line 4
    move-object/from16 v4, p1

    .line 5
    .line 6
    instance-of v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;

    .line 7
    .line 8
    move-object/from16 v8, p0

    .line 9
    .line 10
    if-eqz v0, :cond_b

    .line 11
    .line 12
    move-object v9, v3

    .line 13
    check-cast v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;

    .line 14
    .line 15
    iget v2, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->label:I

    .line 16
    .line 17
    const/high16 v1, -0x80000000

    .line 18
    .line 19
    and-int v0, v2, v1

    .line 20
    .line 21
    if-eqz v0, :cond_b

    .line 22
    .line 23
    sub-int/2addr v2, v1

    .line 24
    iput v2, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->label:I

    .line 25
    .line 26
    :goto_0
    iget-object v2, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->result:Ljava/lang/Object;

    .line 27
    .line 28
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 29
    .line 30
    iget v0, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->label:I

    .line 31
    .line 32
    const/4 v7, 0x0

    .line 33
    const/4 v1, 0x1

    .line 34
    if-eqz v0, :cond_a

    .line 35
    .line 36
    if-ne v0, v1, :cond_c

    .line 37
    .line 38
    iget-boolean v6, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->Z$0:Z

    .line 39
    .line 40
    iget-object v5, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->L$1:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v5, Ljava/lang/String;

    .line 43
    .line 44
    iget-object v4, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 47
    .line 48
    invoke-static {v2}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    :cond_0
    instance-of v0, v1, LX/2PH;

    .line 53
    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    move-object v7, v1

    .line 57
    :cond_1
    check-cast v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;

    .line 58
    .line 59
    :cond_2
    iget-object v3, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 60
    .line 61
    :cond_3
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    move-object v13, v2

    .line 66
    check-cast v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 67
    .line 68
    if-eqz v7, :cond_8

    .line 69
    .line 70
    iget-object v0, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->groups:Ljava/util/List;

    .line 71
    .line 72
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 73
    .line 74
    .line 75
    move-result-object v15

    .line 76
    iget-object v1, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->nextCursor:Ljava/lang/String;

    .line 77
    .line 78
    :goto_1
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->items:Ljava/util/List;

    .line 79
    .line 80
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 81
    .line 82
    .line 83
    move-result-object v14

    .line 84
    const/4 v9, 0x0

    .line 85
    if-nez v6, :cond_4

    .line 86
    .line 87
    const/16 v16, 0x0

    .line 88
    .line 89
    if-eqz v7, :cond_5

    .line 90
    .line 91
    :cond_4
    const/16 v16, 0x1

    .line 92
    .line 93
    :cond_5
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->nextCursor:Ljava/lang/String;

    .line 94
    .line 95
    if-nez v6, :cond_6

    .line 96
    .line 97
    if-eqz v7, :cond_7

    .line 98
    .line 99
    :cond_6
    const/4 v9, 0x1

    .line 100
    :cond_7
    invoke-direct {v8, v9, v1, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->canLoadMore(ZLjava/lang/String;Ljava/lang/String;)Z

    .line 101
    .line 102
    .line 103
    move-result v20

    .line 104
    const/16 p0, 0x0

    .line 105
    .line 106
    iget-object v12, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 107
    .line 108
    iget-boolean v11, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 109
    .line 110
    iget-object v10, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v9, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 113
    .line 114
    const/16 p2, 0x0

    .line 115
    .line 116
    move-object/from16 p3, v9

    .line 117
    .line 118
    move/from16 v21, v11

    .line 119
    .line 120
    move-object/from16 p1, v10

    .line 121
    .line 122
    move-object/from16 v19, v1

    .line 123
    .line 124
    move-object/from16 v18, v0

    .line 125
    .line 126
    move-object/from16 v17, v12

    .line 127
    .line 128
    invoke-virtual/range {v13 .. v25}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_3

    .line 137
    .line 138
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 139
    .line 140
    return-object v3

    .line 141
    :cond_8
    iget-object v15, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 142
    .line 143
    if-eqz v6, :cond_9

    .line 144
    .line 145
    invoke-direct {v8, v15, v5}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->withoutPermission(LX/Ddn;Ljava/lang/String;)LX/Ddn;

    .line 146
    .line 147
    .line 148
    move-result-object v15

    .line 149
    :cond_9
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_a
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    invoke-static {v8}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    iget-boolean v6, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 160
    .line 161
    if-eqz v6, :cond_2

    .line 162
    .line 163
    iget-object v2, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->repository:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 164
    .line 165
    iput-object v4, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->L$0:Ljava/lang/Object;

    .line 166
    .line 167
    iput-object v5, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->L$1:Ljava/lang/Object;

    .line 168
    .line 169
    iput-boolean v6, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->Z$0:Z

    .line 170
    .line 171
    iput v1, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;->label:I

    .line 172
    .line 173
    const/4 v1, 0x0

    .line 174
    const/16 v0, 0x14

    .line 175
    .line 176
    invoke-virtual {v2, v1, v0, v9}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->getGroupedActivePermissions-0E7RQCE(Ljava/lang/String;ILX/2M4;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    if-ne v1, v3, :cond_0

    .line 181
    .line 182
    return-object v3

    .line 183
    :cond_b
    new-instance v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;

    .line 184
    .line 185
    invoke-direct {v9, v8, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$applyRefreshedPage$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 186
    .line 187
    .line 188
    goto/16 :goto_0

    .line 189
    .line 190
    :cond_c
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    throw v0
.end method

.method private final canLoadMore(ZLjava/lang/String;Ljava/lang/String;)Z
    .locals 0

    .line 0
    if-eqz p3, :cond_0

    .line 1
    .line 2
    invoke-static {p3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-eqz p0, :cond_2

    .line 7
    .line 8
    :cond_0
    if-eqz p1, :cond_1

    .line 9
    .line 10
    if-eqz p2, :cond_1

    .line 11
    .line 12
    invoke-static {p2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    if-eqz p0, :cond_2

    .line 17
    .line 18
    :cond_1
    const/4 p0, 0x0

    .line 19
    return p0

    .line 20
    :cond_2
    const/4 p0, 0x1

    .line 21
    return p0
.end method

.method private final loadFirstPage(LX/2M4;)Ljava/lang/Object;
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;

    .line 3
    .line 4
    move-object/from16 v5, p0

    .line 5
    .line 6
    if-eqz v0, :cond_c

    .line 7
    .line 8
    move-object v4, v3

    .line 9
    check-cast v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;

    .line 10
    .line 11
    iget v2, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_c

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;->label:I

    .line 27
    .line 28
    const/4 v1, 0x1

    .line 29
    const/4 v8, 0x0

    .line 30
    if-eqz v0, :cond_b

    .line 31
    .line 32
    if-ne v0, v1, :cond_d

    .line 33
    .line 34
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    check-cast v3, LX/IBK;

    .line 38
    .line 39
    iget-object v4, v3, LX/IBK;->first:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;

    .line 42
    .line 43
    iget-object v3, v3, LX/IBK;->second:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 46
    .line 47
    if-nez v4, :cond_2

    .line 48
    .line 49
    if-nez v3, :cond_2

    .line 50
    .line 51
    iget-object v2, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 52
    .line 53
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    move-object v7, v1

    .line 58
    check-cast v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 59
    .line 60
    sget-object v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->ERROR:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 61
    .line 62
    const/16 p0, 0xd77

    .line 63
    .line 64
    const/4 v10, 0x0

    .line 65
    move-object v9, v8

    .line 66
    move-object v12, v8

    .line 67
    move-object v13, v8

    .line 68
    move v14, v10

    .line 69
    move v15, v10

    .line 70
    move-object/from16 v16, v8

    .line 71
    .line 72
    move-object/from16 v17, v8

    .line 73
    .line 74
    move/from16 v18, v10

    .line 75
    .line 76
    move-object/from16 v19, v8

    .line 77
    .line 78
    move-object/from16 p1, v8

    .line 79
    .line 80
    invoke-static/range {v7 .. v21}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_1

    .line 89
    .line 90
    :goto_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 91
    .line 92
    return-object v2

    .line 93
    :cond_2
    iget-object v2, v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 94
    .line 95
    :cond_3
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    move-object v9, v1

    .line 100
    check-cast v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 101
    .line 102
    if-eqz v3, :cond_4

    .line 103
    .line 104
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->items:Ljava/util/List;

    .line 105
    .line 106
    if-nez v0, :cond_5

    .line 107
    .line 108
    :cond_4
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 109
    .line 110
    :cond_5
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 111
    .line 112
    .line 113
    move-result-object v10

    .line 114
    if-eqz v4, :cond_6

    .line 115
    .line 116
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->groups:Ljava/util/List;

    .line 117
    .line 118
    if-nez v0, :cond_7

    .line 119
    .line 120
    :cond_6
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 121
    .line 122
    :cond_7
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 123
    .line 124
    .line 125
    move-result-object v11

    .line 126
    invoke-static {v4}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v12

    .line 130
    const/4 v6, 0x0

    .line 131
    sget-object v13, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 132
    .line 133
    if-eqz v3, :cond_a

    .line 134
    .line 135
    iget-object v14, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->nextCursor:Ljava/lang/String;

    .line 136
    .line 137
    :goto_2
    if-eqz v4, :cond_9

    .line 138
    .line 139
    iget-object v15, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->nextCursor:Ljava/lang/String;

    .line 140
    .line 141
    const/4 v6, 0x1

    .line 142
    :goto_3
    if-eqz v3, :cond_8

    .line 143
    .line 144
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->nextCursor:Ljava/lang/String;

    .line 145
    .line 146
    :goto_4
    invoke-direct {v5, v6, v15, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->canLoadMore(ZLjava/lang/String;Ljava/lang/String;)Z

    .line 147
    .line 148
    .line 149
    move-result v16

    .line 150
    iget-object v7, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 151
    .line 152
    iget-boolean v6, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 153
    .line 154
    iget-object v0, v9, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 155
    .line 156
    const/16 v17, 0x0

    .line 157
    .line 158
    move-object/from16 v18, v7

    .line 159
    .line 160
    move-object/from16 v19, v8

    .line 161
    .line 162
    move/from16 p0, v6

    .line 163
    .line 164
    move-object/from16 p1, v0

    .line 165
    .line 166
    invoke-virtual/range {v9 .. v21}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    move-result v0

    .line 174
    if-eqz v0, :cond_3

    .line 175
    .line 176
    goto :goto_1

    .line 177
    :cond_8
    move-object v0, v8

    .line 178
    goto :goto_4

    .line 179
    :cond_9
    move-object v15, v8

    .line 180
    goto :goto_3

    .line 181
    :cond_a
    move-object v14, v8

    .line 182
    goto :goto_2

    .line 183
    :cond_b
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;

    .line 187
    .line 188
    invoke-direct {v0, v5, v8}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 189
    .line 190
    .line 191
    iput v1, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;->label:I

    .line 192
    .line 193
    invoke-static {v0, v4}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v3

    .line 197
    if-ne v3, v2, :cond_0

    .line 198
    .line 199
    return-object v2

    .line 200
    :cond_c
    new-instance v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;

    .line 201
    .line 202
    invoke-direct {v4, v5, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadFirstPage$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 203
    .line 204
    .line 205
    goto/16 :goto_0

    .line 206
    .line 207
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    throw v0
.end method

.method private final loadNextPage(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;LX/2M4;)Ljava/lang/Object;
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;

    .line 3
    .line 4
    move-object/from16 v8, p0

    .line 5
    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    move-object v6, v3

    .line 9
    check-cast v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;

    .line 10
    .line 11
    iget v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_a

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->label:I

    .line 27
    .line 28
    const/4 v4, 0x1

    .line 29
    if-eqz v0, :cond_8

    .line 30
    .line 31
    if-ne v0, v4, :cond_b

    .line 32
    .line 33
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v1, LX/IBK;

    .line 37
    .line 38
    iget-object v7, v1, LX/IBK;->first:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;

    .line 41
    .line 42
    iget-object v6, v1, LX/IBK;->second:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 45
    .line 46
    iget-object v5, v8, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->_uiState:LX/2J2;

    .line 47
    .line 48
    :cond_1
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    move-object v11, v4

    .line 53
    check-cast v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 54
    .line 55
    iget-object v13, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groups:LX/Ddn;

    .line 56
    .line 57
    if-eqz v7, :cond_3

    .line 58
    .line 59
    iget-object v0, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->groups:Ljava/util/List;

    .line 60
    .line 61
    invoke-static {v0, v13}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 70
    .line 71
    .line 72
    move-result-object v9

    .line 73
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_2

    .line 82
    .line 83
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    move-object v0, v2

    .line 88
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 89
    .line 90
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 91
    .line 92
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->type:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScopeType;

    .line 93
    .line 94
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;->sessionScopeId:Ljava/lang/String;

    .line 95
    .line 96
    invoke-static {v1, v0}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {v0, v2, v10, v9}, LX/3Rs;->A1A(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;Ljava/util/AbstractCollection;)V

    .line 101
    .line 102
    .line 103
    goto :goto_1

    .line 104
    :cond_2
    invoke-static {v9}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 105
    .line 106
    .line 107
    move-result-object v13

    .line 108
    :cond_3
    iget-object v12, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->permissions:LX/Ddn;

    .line 109
    .line 110
    if-eqz v6, :cond_5

    .line 111
    .line 112
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->items:Ljava/util/List;

    .line 113
    .line 114
    invoke-static {v0, v12}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 119
    .line 120
    .line 121
    move-result-object v9

    .line 122
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-eqz v0, :cond_4

    .line 135
    .line 136
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    move-object v0, v1

    .line 141
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 142
    .line 143
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 144
    .line 145
    invoke-static {v0, v1, v9, v3}, LX/3Rs;->A1A(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;Ljava/util/AbstractCollection;)V

    .line 146
    .line 147
    .line 148
    goto :goto_2

    .line 149
    :cond_4
    invoke-static {v3}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 150
    .line 151
    .line 152
    move-result-object v12

    .line 153
    :cond_5
    if-nez v7, :cond_7

    .line 154
    .line 155
    iget-object v3, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 156
    .line 157
    :goto_3
    if-nez v6, :cond_6

    .line 158
    .line 159
    iget-object v2, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 160
    .line 161
    :goto_4
    sget-object v15, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 162
    .line 163
    iget-boolean v0, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 164
    .line 165
    invoke-direct {v8, v0, v3, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->canLoadMore(ZLjava/lang/String;Ljava/lang/String;)Z

    .line 166
    .line 167
    .line 168
    move-result v18

    .line 169
    iget-boolean v14, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 170
    .line 171
    iget-object v10, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 172
    .line 173
    iget-object v9, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 174
    .line 175
    iget-boolean v1, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 176
    .line 177
    iget-object v0, v11, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->connectorIconUrls:LX/0Xl;

    .line 178
    .line 179
    const/16 v19, 0x0

    .line 180
    .line 181
    move-object/from16 v17, v3

    .line 182
    .line 183
    move-object/from16 v20, v10

    .line 184
    .line 185
    move-object/from16 p0, v9

    .line 186
    .line 187
    move/from16 p1, v1

    .line 188
    .line 189
    move-object/from16 p2, v0

    .line 190
    .line 191
    move-object/from16 v16, v2

    .line 192
    .line 193
    invoke-virtual/range {v11 .. v23}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->copy(LX/Ddn;LX/Ddn;ZLcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;ZLX/0Xl;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_1

    .line 202
    .line 203
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 204
    .line 205
    return-object v5

    .line 206
    :cond_6
    iget-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;->nextCursor:Ljava/lang/String;

    .line 207
    .line 208
    goto :goto_4

    .line 209
    :cond_7
    iget-object v3, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsGroupedPage;->nextCursor:Ljava/lang/String;

    .line 210
    .line 211
    goto :goto_3

    .line 212
    :cond_8
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    move-object/from16 v1, p1

    .line 216
    .line 217
    iget-object v3, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->groupCursor:Ljava/lang/String;

    .line 218
    .line 219
    const/4 v2, 0x0

    .line 220
    if-eqz v3, :cond_9

    .line 221
    .line 222
    iget-boolean v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isGrouped:Z

    .line 223
    .line 224
    if-eqz v0, :cond_9

    .line 225
    .line 226
    :goto_5
    iget-object v1, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->nextCursor:Ljava/lang/String;

    .line 227
    .line 228
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$2;

    .line 229
    .line 230
    invoke-direct {v0, v3, v8, v1, v2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$2;-><init>(Ljava/lang/String;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Ljava/lang/String;LX/2M4;)V

    .line 231
    .line 232
    .line 233
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->L$0:Ljava/lang/Object;

    .line 234
    .line 235
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->L$1:Ljava/lang/Object;

    .line 236
    .line 237
    iput-object v2, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->L$2:Ljava/lang/Object;

    .line 238
    .line 239
    iput v4, v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;->label:I

    .line 240
    .line 241
    invoke-static {v0, v6}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    if-ne v1, v5, :cond_0

    .line 246
    .line 247
    return-object v5

    .line 248
    :cond_9
    move-object v3, v2

    .line 249
    goto :goto_5

    .line 250
    :cond_a
    new-instance v6, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;

    .line 251
    .line 252
    invoke-direct {v6, v8, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadNextPage$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 253
    .line 254
    .line 255
    goto/16 :goto_0

    .line 256
    .line 257
    :cond_b
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 258
    .line 259
    .line 260
    move-result-object v0

    .line 261
    throw v0
.end method

.method public static synthetic loadPermissions$default(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p2, p1}, LX/002;->A1U(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->loadPermissions(Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final withoutPermission(LX/Ddn;Ljava/lang/String;)LX/Ddn;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;",
            ">;"
        }
    .end annotation

    .line 0
    if-nez p2, :cond_0

    .line 1
    .line 2
    sget-object v0, LX/Dwg;->A01:LX/Dwg;

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v5

    .line 13
    :cond_1
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_3

    .line 18
    .line 19
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    check-cast v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 24
    .line 25
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->items:Ljava/util/List;

    .line 26
    .line 27
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    move-object v0, v1

    .line 46
    check-cast v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 47
    .line 48
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->permissionId:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v0, v1, p2, v3}, LX/3Rs;->A19(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/util/AbstractCollection;)V

    .line 51
    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_2
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;->scope:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;

    .line 61
    .line 62
    const/4 v0, 0x0

    .line 63
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 64
    .line 65
    .line 66
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;

    .line 67
    .line 68
    invoke-direct {v0, v1, v3}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionGroup;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionScope;Ljava/util/List;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    invoke-static {p0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    return-object v0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final loadMore()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logLoadMore()V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;->loadPermissions(Z)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final loadPermissions(Z)V
    .locals 3

    .line 0
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    iget-object v1, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->loadingState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->LOADING:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 7
    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 19
    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    if-nez p1, :cond_1

    .line 27
    .line 28
    iget-boolean v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->canLoadMore:Z

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsLoadingState;

    .line 33
    .line 34
    if-eq v1, v0, :cond_1

    .line 35
    .line 36
    :cond_0
    return-void

    .line 37
    :cond_1
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    const/4 v1, 0x0

    .line 42
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;

    .line 43
    .line 44
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$loadPermissions$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;ZLX/2M4;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public final resetPermissions()V
    .locals 3

    .line 0
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 33
    .line 34
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logReset()V

    .line 35
    .line 36
    .line 37
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    const/4 v1, 0x0

    .line 42
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;

    .line 43
    .line 44
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$resetPermissions$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 48
    .line 49
    .line 50
    :cond_0
    return-void
.end method

.method public final revokePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->revocable:Z

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 37
    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    invoke-static {p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 47
    .line 48
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logWebsiteRevoke()V

    .line 49
    .line 50
    .line 51
    :cond_0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    const/4 v1, 0x0

    .line 56
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;

    .line 57
    .line 58
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$revokePermission$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;LX/2M4;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 62
    .line 63
    .line 64
    :cond_1
    return-void
.end method

.method public final setPermissionMode(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p0}, LX/3Rr;->A0F(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;)Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->mode:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 8
    .line 9
    if-eq v0, p2, :cond_1

    .line 10
    .line 11
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->modeOptions:LX/Ddn;

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 20
    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    iget-boolean v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 28
    .line 29
    if-nez v0, :cond_1

    .line 30
    .line 31
    iget-boolean v0, v1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 32
    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    invoke-static {p1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionRowKt;->isWebsitePermission(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_0

    .line 40
    .line 41
    sget-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;

    .line 42
    .line 43
    invoke-virtual {v0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsAnalytics;->logModeSelected(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    const/4 v1, 0x0

    .line 51
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;

    .line 52
    .line 53
    invoke-direct {v0, p0, p1, p2, v1}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel$setPermissionMode$1;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsViewModel;Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2M4;)V

    .line 54
    .line 55
    .line 56
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 57
    .line 58
    .line 59
    :cond_1
    return-void
.end method
