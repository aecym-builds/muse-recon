.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsRepository$resetPermissions$2"
    f = "ActivePermissionsRepository.kt"
    l = {
        0xab
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public I$4:I

.field public I$5:I

.field public I$6:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;-><init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v2, p0

    .line 3
    .line 4
    iget v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->label:I

    .line 5
    .line 6
    const/4 v15, 0x1

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-ne v0, v15, :cond_3

    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    :cond_0
    instance-of v0, v2, LX/2PH;

    .line 16
    .line 17
    xor-int/lit8 v0, v0, 0x1

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    check-cast v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsEnvelopeJson;

    .line 22
    .line 23
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsEnvelopeJson;->activePermissions:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPageJson;->toApprovalsDomain()Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsPage;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    :cond_1
    invoke-static {v2}, LX/3Rp;->A12(Ljava/lang/Object;)LX/2PJ;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    return-object v1

    .line 34
    :cond_2
    invoke-static/range {p1 .. p1}, LX/3Rp;->A08(Ljava/lang/Object;)Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    sget-object v7, Lcom/facebook/aura/agentpermission/pastapprovals/PastApprovalsJarvisPath$PermissionsReset;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/PastApprovalsJarvisPath$PermissionsReset;

    .line 39
    .line 40
    const-string v0, "Reset permissions to defaults from Hatch settings."

    .line 41
    .line 42
    new-instance v8, Lcom/facebook/aura/agentpermission/pastapprovals/ResetActivePermissionsRequestJson;

    .line 43
    .line 44
    invoke-direct {v8, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ResetActivePermissionsRequestJson;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    sget-object v9, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 48
    .line 49
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 50
    .line 51
    iget-object v10, v0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->userSession:LX/AHE;

    .line 52
    .line 53
    const/4 v6, 0x0

    .line 54
    new-array v13, v6, [LX/IBK;

    .line 55
    .line 56
    invoke-static {}, LX/3Rq;->A1F()Ljava/util/Set;

    .line 57
    .line 58
    .line 59
    move-result-object v14

    .line 60
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 61
    .line 62
    .line 63
    move-result-object v17

    .line 64
    sget-object v4, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$1;

    .line 65
    .line 66
    sget-object v5, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$2;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2$invokeSuspend$$inlined$executeJarvisRequest-Z6QaZII$default$2;

    .line 67
    .line 68
    const/4 v11, 0x0

    .line 69
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$0:Ljava/lang/Object;

    .line 70
    .line 71
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$1:Ljava/lang/Object;

    .line 72
    .line 73
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$2:Ljava/lang/Object;

    .line 74
    .line 75
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$3:Ljava/lang/Object;

    .line 76
    .line 77
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$4:Ljava/lang/Object;

    .line 78
    .line 79
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$5:Ljava/lang/Object;

    .line 80
    .line 81
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$6:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->L$7:Ljava/lang/Object;

    .line 84
    .line 85
    iput v15, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$0:I

    .line 86
    .line 87
    iput v15, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$1:I

    .line 88
    .line 89
    iput v6, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$2:I

    .line 90
    .line 91
    iput v15, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$3:I

    .line 92
    .line 93
    iput v6, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$4:I

    .line 94
    .line 95
    iput v6, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$5:I

    .line 96
    .line 97
    iput v6, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->I$6:I

    .line 98
    .line 99
    iput v15, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$2;->label:I

    .line 100
    .line 101
    move-object v12, v11

    .line 102
    move/from16 v16, v15

    .line 103
    .line 104
    move-object/from16 v18, v11

    .line 105
    .line 106
    move/from16 v19, v6

    .line 107
    .line 108
    move/from16 v20, v15

    .line 109
    .line 110
    move/from16 v21, v6

    .line 111
    .line 112
    move/from16 v22, v6

    .line 113
    .line 114
    move-object/from16 v23, v11

    .line 115
    .line 116
    move/from16 p0, v6

    .line 117
    .line 118
    move-object/from16 p1, v2

    .line 119
    .line 120
    invoke-virtual/range {v3 .. v25}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeJarvisRequestWith-Fof5HsY(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/JarvisPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;LX/AHE;Ljava/lang/Long;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;[LX/IBK;Ljava/util/Set;ZZLjava/util/Map;Ljava/lang/String;ZZZZLjava/lang/String;ZLX/2M4;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    if-ne v2, v1, :cond_0

    .line 125
    .line 126
    return-object v1

    .line 127
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    throw v0
.end method
