.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onLoadMore:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;->invoke(LX/1Xg;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 40

    .line 268435456
    const/4 v5, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    invoke-static {v0, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435460
    .line 268435461
    .line 268435462
    move/from16 v2, p3

    .line 268435463
    .line 268435464
    and-int/lit8 v1, p3, 0x11

    .line 268435465
    .line 268435466
    const/16 v0, 0x10

    .line 268435467
    .line 268435468
    const/4 v4, 0x1

    .line 268435469
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435470
    .line 268435471
    .line 268435472
    move-result v0

    .line 268435473
    move-object/from16 v6, p2

    .line 268435474
    .line 268435475
    invoke-static {v0, v6, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    if-eqz v0, :cond_3

    .line 268435480
    .line 268435481
    const/4 v12, 0x0

    .line 268435482
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 268435483
    .line 268435484
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 268435485
    .line 268435486
    invoke-static {v1, v0}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 268435487
    .line 268435488
    .line 268435489
    move-result-object v1

    .line 268435490
    sget-object v0, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 268435491
    .line 268435492
    move-object/from16 v2, p0

    .line 268435493
    .line 268435494
    iget-object v7, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;->$uiState:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;

    .line 268435495
    .line 268435496
    iget-object v3, v2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 268435497
    .line 268435498
    invoke-static {v0, v5}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 268435499
    .line 268435500
    .line 268435501
    move-result-object v11

    .line 268435502
    move-object v2, v6

    .line 268435503
    check-cast v2, LX/J7I;

    .line 268435504
    .line 268435505
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 268435506
    .line 268435507
    .line 268435508
    move-result v10

    .line 268435509
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 268435510
    .line 268435511
    .line 268435512
    move-result-object v9

    .line 268435513
    invoke-static {v6, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 268435514
    .line 268435515
    .line 268435516
    move-result-object v8

    .line 268435517
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 268435518
    .line 268435519
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 268435520
    .line 268435521
    if-nez v0, :cond_0

    .line 268435522
    .line 268435523
    invoke-static {}, LX/1VY;->A00()V

    .line 268435524
    .line 268435525
    .line 268435526
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435527
    .line 268435528
    .line 268435529
    move-result-object v0

    .line 268435530
    throw v0

    .line 268435531
    :cond_0
    invoke-static {v6, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 268435532
    .line 268435533
    .line 268435534
    invoke-static {v6, v11, v9, v8, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435535
    .line 268435536
    .line 268435537
    const v0, 0x7f120160

    .line 268435538
    .line 268435539
    .line 268435540
    invoke-static {v6, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435541
    .line 268435542
    .line 268435543
    move-result-object v13

    .line 268435544
    invoke-static {v6}, LX/007;->A0h(LX/2d4;)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 268435545
    .line 268435546
    .line 268435547
    move-result-object v16

    .line 268435548
    sget-object v17, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 268435549
    .line 268435550
    iget-boolean v1, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isLoadingMore:Z

    .line 268435551
    .line 268435552
    if-nez v1, :cond_1

    .line 268435553
    .line 268435554
    iget-boolean v0, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->isResetting:Z

    .line 268435555
    .line 268435556
    if-nez v0, :cond_1

    .line 268435557
    .line 268435558
    iget-object v0, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->revokingPermissionId:Ljava/lang/String;

    .line 268435559
    .line 268435560
    if-nez v0, :cond_1

    .line 268435561
    .line 268435562
    iget-object v0, v7, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsUiState;->updatingPermissionId:Ljava/lang/String;

    .line 268435563
    .line 268435564
    const/16 v21, 0x1

    .line 268435565
    .line 268435566
    if-eqz v0, :cond_2

    .line 268435567
    .line 268435568
    :cond_1
    const/16 v21, 0x0

    .line 268435569
    .line 268435570
    :cond_2
    const/16 p2, 0x6000

    .line 268435571
    .line 268435572
    const p3, 0x6ffb9cd

    .line 268435573
    .line 268435574
    .line 268435575
    const/high16 p0, 0x30000

    .line 268435576
    .line 268435577
    move-object v14, v12

    .line 268435578
    move-object v15, v12

    .line 268435579
    move-object/from16 v18, v12

    .line 268435580
    .line 268435581
    move/from16 v20, v5

    .line 268435582
    .line 268435583
    move/from16 v22, v1

    .line 268435584
    .line 268435585
    move/from16 v23, v5

    .line 268435586
    .line 268435587
    move-object/from16 v24, v12

    .line 268435588
    .line 268435589
    move-object/from16 v25, v12

    .line 268435590
    .line 268435591
    move-object/from16 v26, v3

    .line 268435592
    .line 268435593
    move-object/from16 v27, v12

    .line 268435594
    .line 268435595
    move-object/from16 v28, v12

    .line 268435596
    .line 268435597
    move-object/from16 v29, v12

    .line 268435598
    .line 268435599
    move-object/from16 v30, v12

    .line 268435600
    .line 268435601
    move-object/from16 v31, v12

    .line 268435602
    .line 268435603
    move-object/from16 v32, v12

    .line 268435604
    .line 268435605
    move-object/from16 v33, v12

    .line 268435606
    .line 268435607
    move-object/from16 v34, v12

    .line 268435608
    .line 268435609
    move/from16 v35, v5

    .line 268435610
    .line 268435611
    move/from16 v36, v4

    .line 268435612
    .line 268435613
    move/from16 v37, v5

    .line 268435614
    .line 268435615
    move/from16 v38, v5

    .line 268435616
    .line 268435617
    move-object/from16 v39, v6

    .line 268435618
    .line 268435619
    move/from16 p1, v5

    .line 268435620
    .line 268435621
    move/from16 v19, v5

    .line 268435622
    .line 268435623
    invoke-static/range {v12 .. v43}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 268435624
    .line 268435625
    .line 268435626
    invoke-static {v2, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435627
    .line 268435628
    .line 268435629
    return-void

    .line 268435630
    :cond_3
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 268435631
    .line 268435632
    .line 268435633
    return-void
.end method
