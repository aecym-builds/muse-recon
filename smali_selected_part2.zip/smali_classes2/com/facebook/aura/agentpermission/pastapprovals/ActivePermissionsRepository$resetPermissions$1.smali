.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.pastapprovals.ActivePermissionsRepository"
    f = "ActivePermissionsRepository.kt"
    l = {
        0x6f
    }
    m = "resetPermissions-IoAF18A"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository$resetPermissions$1;->this$0:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;

    .line 10
    .line 11
    invoke-virtual {v0, p0}, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsRepository;->resetPermissions-IoAF18A(LX/2M4;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, LX/3Rs;->A0C(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
