.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionsScreenKt$ActivePermissionsList$1$1$invoke$$inlined$sortedBy$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 0
    check-cast p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 1
    .line 2
    iget-object p0, p1, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->summaryTitle:Ljava/lang/String;

    .line 5
    .line 6
    check-cast p2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;

    .line 7
    .line 8
    iget-object p0, p2, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermission;->display:Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;

    .line 9
    .line 10
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/pastapprovals/ActivePermissionDisplay;->summaryTitle:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {p1, p0}, LX/34d;->A00(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method
