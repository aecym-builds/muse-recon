.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final allowKinds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final allowOnce:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

.field public final approvalId:Ljava/lang/String;

.field public final enteredLoginAllows:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;",
            ">;"
        }
    .end annotation
.end field

.field public final requiresSelection:Z

.field public final selections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLjava/util/Set;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x4

    .line 4
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->approvalId:Ljava/lang/String;

    .line 11
    .line 12
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->requiresSelection:Z

    .line 13
    .line 14
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 15
    .line 16
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowOnce:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 17
    .line 18
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->selections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 19
    .line 20
    iget-object v1, p5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->choices:LX/2J3;

    .line 21
    .line 22
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$1;

    .line 23
    .line 24
    invoke-direct {v0, v1, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$1;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 25
    .line 26
    .line 27
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$map$1;

    .line 28
    .line 29
    invoke-direct {v3, v0, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$map$1;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 30
    .line 31
    .line 32
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    sget-object v1, LX/5Lz;->A00:LX/5Ly;

    .line 37
    .line 38
    iget-object v0, p5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->choices:LX/2J3;

    .line 39
    .line 40
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    check-cast v0, Ljava/util/Map;

    .line 45
    .line 46
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 51
    .line 52
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->toUiState(Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v0, v2, v3, v1}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->uiState:LX/2J3;

    .line 61
    .line 62
    iget-object v1, p5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->choices:LX/2J3;

    .line 63
    .line 64
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$2;

    .line 65
    .line 66
    invoke-direct {v0, v1, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$2;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 67
    .line 68
    .line 69
    invoke-static {v0}, LX/IJu;->A02(LX/2Lw;)LX/2Lw;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$3;

    .line 74
    .line 75
    invoke-direct {v0, v1, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$special$$inlined$mapNotNull$3;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 76
    .line 77
    .line 78
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->enteredLoginAllows:LX/2Lw;

    .line 79
    .line 80
    invoke-virtual {p5, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->loadIfNeeded$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public static final synthetic access$getAllowKinds$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)Ljava/util/Set;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getAllowOnce$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowOnce:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getApprovalId$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->approvalId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSelections$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->selections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$toUiState(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->toUiState(Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final isEnterableLoginSite(Ljava/lang/String;)Z
    .locals 2

    .line 0
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "https"

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    invoke-virtual {p1}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    return v1

    .line 38
    :cond_0
    const/4 v1, 0x0

    .line 39
    return v1
.end method

.method private final toUiState(Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 17

    .line 0
    move-object/from16 v4, p0

    .line 1
    .line 2
    move-object/from16 v5, p1

    .line 3
    .line 4
    if-eqz p1, :cond_2

    .line 5
    .line 6
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 7
    .line 8
    invoke-virtual {v5, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->selection(Ljava/util/Set;)Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;

    .line 9
    .line 10
    .line 11
    move-result-object v8

    .line 12
    :goto_0
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 13
    .line 14
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 15
    .line 16
    .line 17
    move-result-object v7

    .line 18
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    :cond_0
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    if-eqz v8, :cond_1

    .line 33
    .line 34
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;->decisionKinds:Ljava/util/List;

    .line 35
    .line 36
    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    xor-int/lit8 v0, v0, 0x1

    .line 41
    .line 42
    :goto_2
    if-eqz v0, :cond_0

    .line 43
    .line 44
    invoke-virtual {v7, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_1
    iget-boolean v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->requiresSelection:Z

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_2
    const/4 v8, 0x0

    .line 52
    goto :goto_0

    .line 53
    :cond_3
    if-eqz v8, :cond_4

    .line 54
    .line 55
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 56
    .line 57
    invoke-static {v7, v0}, LX/163;->A02(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/Set;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-static {v1}, LX/3Rq;->A01(Ljava/lang/Iterable;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    new-instance v6, Ljava/util/LinkedHashMap;

    .line 66
    .line 67
    invoke-direct {v6, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 68
    .line 69
    .line 70
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_5

    .line 79
    .line 80
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;->credentialId:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {v6, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    goto :goto_3

    .line 90
    :cond_4
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 91
    .line 92
    .line 93
    move-result-object v6

    .line 94
    :cond_5
    if-eqz p1, :cond_b

    .line 95
    .line 96
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 97
    .line 98
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 99
    .line 100
    if-eq v1, v0, :cond_b

    .line 101
    .line 102
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->FAILED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 103
    .line 104
    if-ne v1, v0, :cond_9

    .line 105
    .line 106
    sget-object v12, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->FAILED:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 107
    .line 108
    :goto_4
    if-eqz p1, :cond_8

    .line 109
    .line 110
    iget-object v13, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 113
    .line 114
    if-nez v0, :cond_6

    .line 115
    .line 116
    :goto_5
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 117
    .line 118
    :cond_6
    invoke-static {v0}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 119
    .line 120
    .line 121
    move-result-object v10

    .line 122
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 123
    .line 124
    .line 125
    move-result-object v11

    .line 126
    :goto_6
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    if-eqz v0, :cond_c

    .line 131
    .line 132
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    check-cast v1, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 137
    .line 138
    iget-object v9, v1, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 139
    .line 140
    iget-object v3, v1, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->label:Ljava/lang/String;

    .line 141
    .line 142
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowKinds:Ljava/util/Set;

    .line 143
    .line 144
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->offersAny(Ljava/util/Collection;)Z

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    iget-object v1, v1, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 149
    .line 150
    if-eqz v8, :cond_7

    .line 151
    .line 152
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;->credentialId:Ljava/lang/String;

    .line 153
    .line 154
    :goto_7
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 159
    .line 160
    invoke-direct {v0, v9, v3, v2, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v10, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    goto :goto_6

    .line 167
    :cond_7
    const/4 v0, 0x0

    .line 168
    goto :goto_7

    .line 169
    :cond_8
    const/4 v13, 0x0

    .line 170
    goto :goto_5

    .line 171
    :cond_9
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 172
    .line 173
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    if-eqz v0, :cond_a

    .line 178
    .line 179
    sget-object v12, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->EMPTY:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 180
    .line 181
    goto :goto_4

    .line 182
    :cond_a
    sget-object v12, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->LOADED:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 183
    .line 184
    goto :goto_4

    .line 185
    :cond_b
    sget-object v12, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 186
    .line 187
    goto :goto_4

    .line 188
    :cond_c
    invoke-static {v10}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 189
    .line 190
    .line 191
    move-result-object v14

    .line 192
    if-eqz p1, :cond_12

    .line 193
    .line 194
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 195
    .line 196
    if-eqz v0, :cond_12

    .line 197
    .line 198
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 199
    .line 200
    .line 201
    move-result-object v3

    .line 202
    :cond_d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    if-eqz v0, :cond_11

    .line 207
    .line 208
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v2

    .line 212
    move-object v0, v2

    .line 213
    check-cast v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 214
    .line 215
    iget-object v1, v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 216
    .line 217
    if-eqz v8, :cond_10

    .line 218
    .line 219
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;->credentialId:Ljava/lang/String;

    .line 220
    .line 221
    :goto_8
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v0

    .line 225
    if-eqz v0, :cond_d

    .line 226
    .line 227
    :goto_9
    check-cast v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 228
    .line 229
    if-eqz v2, :cond_12

    .line 230
    .line 231
    iget-object v15, v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->label:Ljava/lang/String;

    .line 232
    .line 233
    :goto_a
    invoke-static {v7}, LX/Dwp;->A08(Ljava/lang/Iterable;)LX/JlV;

    .line 234
    .line 235
    .line 236
    move-result-object v16

    .line 237
    invoke-static {v6}, LX/Dwp;->A06(Ljava/util/Map;)LX/IZf;

    .line 238
    .line 239
    .line 240
    move-result-object p0

    .line 241
    if-eqz p1, :cond_e

    .line 242
    .line 243
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 244
    .line 245
    if-eqz v1, :cond_e

    .line 246
    .line 247
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->allowOnce:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 248
    .line 249
    if-eqz v0, :cond_e

    .line 250
    .line 251
    invoke-direct {v4, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->isEnterableLoginSite(Ljava/lang/String;)Z

    .line 252
    .line 253
    .line 254
    move-result v0

    .line 255
    if-nez v0, :cond_f

    .line 256
    .line 257
    :cond_e
    const/4 v1, 0x0

    .line 258
    :cond_f
    new-instance v11, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 259
    .line 260
    move-object/from16 p1, v1

    .line 261
    .line 262
    invoke-direct/range {v11 .. v18}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    return-object v11

    .line 266
    :cond_10
    const/4 v0, 0x0

    .line 267
    goto :goto_8

    .line 268
    :cond_11
    const/4 v2, 0x0

    .line 269
    goto :goto_9

    .line 270
    :cond_12
    const/4 v15, 0x0

    .line 271
    goto :goto_a
.end method


# virtual methods
.method public final getEnteredLoginAllows()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->enteredLoginAllows:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final reload()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->selections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->approvalId:Ljava/lang/String;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->load$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final select(Ljava/lang/String;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->selections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->approvalId:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v1, v0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->select$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
