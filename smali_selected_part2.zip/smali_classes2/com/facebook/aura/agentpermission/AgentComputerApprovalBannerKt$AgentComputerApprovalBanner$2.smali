.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 12

    .line 0
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object v11, p1

    .line 5
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$2;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 12
    .line 13
    iget-object v2, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v0, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 16
    .line 17
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->getRendersAsConnectorCard()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    :cond_0
    iget-object v3, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 25
    .line 26
    sget v5, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconSize:F

    .line 27
    .line 28
    sget v6, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconCornerRadius:F

    .line 29
    .line 30
    invoke-static {v1}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    sget v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->BannerIconGlyphSize:F

    .line 35
    .line 36
    const p0, 0x186c00

    .line 37
    .line 38
    .line 39
    const/16 p1, 0x184

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    move-object v9, v4

    .line 43
    move-object v10, v4

    .line 44
    invoke-static/range {v2 .. v13}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :cond_1
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 49
    .line 50
    .line 51
    return-void
.end method
