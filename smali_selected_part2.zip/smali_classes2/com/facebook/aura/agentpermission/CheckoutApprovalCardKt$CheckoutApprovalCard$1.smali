.class public final Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

.field public final synthetic $headline:LX/2iK;

.field public final synthetic $narrative:Ljava/lang/String;

.field public final synthetic $reviewText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$headline:LX/2iK;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$narrative:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$reviewText:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 7

    .line 268435456
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object v4, p2

    .line 268435461
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 268435468
    .line 268435469
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$headline:LX/2iK;

    .line 268435470
    .line 268435471
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$narrative:Ljava/lang/String;

    .line 268435472
    .line 268435473
    sget v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->$stable:I

    .line 268435474
    .line 268435475
    const/4 v3, 0x0

    .line 268435476
    const/16 v6, 0x8

    .line 268435477
    .line 268435478
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 268435479
    .line 268435480
    .line 268435481
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;->$reviewText:Ljava/lang/String;

    .line 268435482
    .line 268435483
    const/4 v2, 0x0

    .line 268435484
    const/4 v5, 0x6

    .line 268435485
    move-object v1, v3

    .line 268435486
    move-object v3, p2

    .line 268435487
    move v4, v2

    .line 268435488
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionReviewText(Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 268435489
    .line 268435490
    .line 268435491
    return-void

    .line 268435492
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435493
    .line 268435494
    .line 268435495
    return-void
.end method
