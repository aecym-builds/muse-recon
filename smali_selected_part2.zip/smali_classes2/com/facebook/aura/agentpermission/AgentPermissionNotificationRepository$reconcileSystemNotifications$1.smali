.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionNotificationRepository"
    f = "AgentPermissionNotificationRepository.kt"
    l = {
        0x6f
    }
    m = "reconcileSystemNotifications"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$10:Ljava/lang/Object;

.field public L$11:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public L$8:Ljava/lang/Object;

.field public L$9:Ljava/lang/Object;

.field public Z$0:Z

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 10
    .line 11
    const-wide/16 v6, 0x0

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    const/4 v2, 0x0

    .line 15
    move-object v3, v1

    .line 16
    move-object v4, v1

    .line 17
    move-object v5, v1

    .line 18
    invoke-static/range {v0 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->access$reconcileSystemNotifications(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;JLX/2M4;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method
