.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onLoadMore:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/1Xg;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->invoke(LX/1Xg;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 32

    .line 268435456
    const/4 v11, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    invoke-static {v0, v11}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435460
    .line 268435461
    .line 268435462
    move/from16 v2, p3

    .line 268435463
    .line 268435464
    and-int/lit8 v1, p3, 0x11

    .line 268435465
    .line 268435466
    const/4 v6, 0x1

    .line 268435467
    const/16 v0, 0x10

    .line 268435468
    .line 268435469
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435470
    .line 268435471
    .line 268435472
    move-result v0

    .line 268435473
    move-object/from16 v3, p2

    .line 268435474
    .line 268435475
    invoke-static {v0, v3, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    if-eqz v0, :cond_4

    .line 268435480
    .line 268435481
    move-object/from16 v2, p0

    .line 268435482
    .line 268435483
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 268435484
    .line 268435485
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 268435486
    .line 268435487
    invoke-interface {v3, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435488
    .line 268435489
    .line 268435490
    move-result v1

    .line 268435491
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 268435492
    .line 268435493
    invoke-static {v3, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435494
    .line 268435495
    .line 268435496
    move-result v1

    .line 268435497
    iget-object v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 268435498
    .line 268435499
    iget-object v4, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 268435500
    .line 268435501
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435502
    .line 268435503
    .line 268435504
    move-result-object v0

    .line 268435505
    if-nez v1, :cond_0

    .line 268435506
    .line 268435507
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435508
    .line 268435509
    if-ne v0, v1, :cond_1

    .line 268435510
    .line 268435511
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2$1$1;

    .line 268435512
    .line 268435513
    invoke-direct {v0, v5, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;)V

    .line 268435514
    .line 268435515
    .line 268435516
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435517
    .line 268435518
    .line 268435519
    :cond_1
    invoke-static {v3, v0, v7}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435520
    .line 268435521
    .line 268435522
    const v0, 0x7f120160

    .line 268435523
    .line 268435524
    .line 268435525
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435526
    .line 268435527
    .line 268435528
    move-result-object v5

    .line 268435529
    sget-object v1, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 268435530
    .line 268435531
    const/4 v4, 0x0

    .line 268435532
    const/16 v0, 0x30

    .line 268435533
    .line 268435534
    invoke-virtual {v1, v4, v3, v0, v6}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 268435535
    .line 268435536
    .line 268435537
    move-result-object v8

    .line 268435538
    sget-object v9, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 268435539
    .line 268435540
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 268435541
    .line 268435542
    iget-boolean v14, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 268435543
    .line 268435544
    xor-int/lit8 v13, v14, 0x1

    .line 268435545
    .line 268435546
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 268435547
    .line 268435548
    const/high16 v0, 0x41800000    # 16.0f

    .line 268435549
    .line 268435550
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 268435551
    .line 268435552
    .line 268435553
    move-result-object v1

    .line 268435554
    const/high16 v0, 0x42400000    # 48.0f

    .line 268435555
    .line 268435556
    invoke-static {v1, v0}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 268435557
    .line 268435558
    .line 268435559
    move-result-object v7

    .line 268435560
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 268435561
    .line 268435562
    invoke-interface {v3, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 268435563
    .line 268435564
    .line 268435565
    move-result v1

    .line 268435566
    iget-object v2, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;->$onLoadMore:Lkotlin/jvm/functions/Function0;

    .line 268435567
    .line 268435568
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435569
    .line 268435570
    .line 268435571
    move-result-object v0

    .line 268435572
    if-nez v1, :cond_2

    .line 268435573
    .line 268435574
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435575
    .line 268435576
    if-ne v0, v1, :cond_3

    .line 268435577
    .line 268435578
    :cond_2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2$2$1;

    .line 268435579
    .line 268435580
    invoke-direct {v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2$2$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 268435581
    .line 268435582
    .line 268435583
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435584
    .line 268435585
    .line 268435586
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435587
    .line 268435588
    const p3, 0x7ffb9c5

    .line 268435589
    .line 268435590
    .line 268435591
    const p0, 0x30c00

    .line 268435592
    .line 268435593
    .line 268435594
    move-object v6, v4

    .line 268435595
    move-object v10, v4

    .line 268435596
    move v12, v11

    .line 268435597
    move v15, v11

    .line 268435598
    move-object/from16 v16, v4

    .line 268435599
    .line 268435600
    move-object/from16 v17, v4

    .line 268435601
    .line 268435602
    move-object/from16 v18, v0

    .line 268435603
    .line 268435604
    move-object/from16 v19, v4

    .line 268435605
    .line 268435606
    move-object/from16 v20, v4

    .line 268435607
    .line 268435608
    move-object/from16 v21, v4

    .line 268435609
    .line 268435610
    move-object/from16 v22, v4

    .line 268435611
    .line 268435612
    move-object/from16 v23, v4

    .line 268435613
    .line 268435614
    move-object/from16 v24, v4

    .line 268435615
    .line 268435616
    move-object/from16 v25, v4

    .line 268435617
    .line 268435618
    move-object/from16 v26, v4

    .line 268435619
    .line 268435620
    move/from16 v27, v11

    .line 268435621
    .line 268435622
    move/from16 v28, v11

    .line 268435623
    .line 268435624
    move/from16 v29, v11

    .line 268435625
    .line 268435626
    move/from16 v30, v11

    .line 268435627
    .line 268435628
    move-object/from16 v31, v3

    .line 268435629
    .line 268435630
    move/from16 p1, v11

    .line 268435631
    .line 268435632
    move/from16 p2, v11

    .line 268435633
    .line 268435634
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 268435635
    .line 268435636
    .line 268435637
    return-void

    .line 268435638
    :cond_4
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 268435639
    .line 268435640
    .line 268435641
    return-void
.end method
