.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final rememberPermissionCaptionText(Ljava/lang/String;LX/2d4;I)LX/2iK;
    .locals 10

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v7, p0

    .line 2
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    invoke-static {p1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-wide v8, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 10
    .line 11
    and-int/lit8 v0, p2, 0xe

    .line 12
    .line 13
    xor-int/lit8 v4, v0, 0x6

    .line 14
    .line 15
    const/4 v5, 0x0

    .line 16
    const/4 v3, 0x4

    .line 17
    if-le v4, v3, :cond_0

    .line 18
    .line 19
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    :cond_0
    and-int/lit8 v1, p2, 0x6

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    if-ne v1, v3, :cond_2

    .line 29
    .line 30
    :cond_1
    const/4 v0, 0x1

    .line 31
    :cond_2
    invoke-static {p1, v8, v9, v0}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    if-nez v0, :cond_3

    .line 40
    .line 41
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 42
    .line 43
    if-ne v6, v0, :cond_4

    .line 44
    .line 45
    :cond_3
    invoke-static {p0}, LX/002;->A0e(Ljava/lang/String;)LX/2iK;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {p1, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 50
    .line 51
    .line 52
    move-result-object v6

    .line 53
    :cond_4
    check-cast v6, Landroidx/compose/runtime/MutableState;

    .line 54
    .line 55
    invoke-static {v8, v9}, LX/001;->A0d(J)LX/JOw;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-interface {p1, v6}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-le v4, v3, :cond_5

    .line 64
    .line 65
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_6

    .line 70
    .line 71
    :cond_5
    and-int/lit8 v0, p2, 0x6

    .line 72
    .line 73
    if-ne v0, v3, :cond_7

    .line 74
    .line 75
    :cond_6
    const/4 v5, 0x1

    .line 76
    :cond_7
    or-int/2addr v1, v5

    .line 77
    invoke-static {p1, v8, v9, v1}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v5

    .line 85
    if-nez v0, :cond_8

    .line 86
    .line 87
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 88
    .line 89
    if-ne v5, v0, :cond_9

    .line 90
    .line 91
    :cond_8
    const/4 p0, 0x0

    .line 92
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;

    .line 93
    .line 94
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;-><init>(Landroidx/compose/runtime/MutableState;Ljava/lang/String;JLX/2M4;)V

    .line 95
    .line 96
    .line 97
    invoke-interface {p1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    :cond_9
    invoke-static {p1, v5, v7, v2}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    invoke-interface {v6}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    check-cast v0, LX/2iK;

    .line 108
    .line 109
    return-object v0
.end method
