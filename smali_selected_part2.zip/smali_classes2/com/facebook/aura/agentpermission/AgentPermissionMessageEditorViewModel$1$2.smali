.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$updateAvailability(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public final emit(Lkotlin/Unit;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Unit;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 268435457
    .line 268435458
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$updateAvailability(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method
