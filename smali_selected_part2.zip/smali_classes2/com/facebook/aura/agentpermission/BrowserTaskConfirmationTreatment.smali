.class public final enum Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

.field public static final enum BROWSER:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

.field public static final enum CHECKOUT:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

.field public static final Companion:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment$Companion;


# instance fields
.field public final iconRes:I


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const/4 v2, 0x0

    .line 1
    const v1, 0x7f0800ed

    .line 2
    .line 3
    .line 4
    const-string v0, "BROWSER"

    .line 5
    .line 6
    new-instance v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 7
    .line 8
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;-><init>(Ljava/lang/String;II)V

    .line 9
    .line 10
    .line 11
    sput-object v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->BROWSER:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    const v2, 0x7f0802a2

    .line 15
    .line 16
    .line 17
    const-string v1, "CHECKOUT"

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 20
    .line 21
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;-><init>(Ljava/lang/String;II)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->CHECKOUT:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 25
    .line 26
    filled-new-array {v4, v0}, [Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->$VALUES:[Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 31
    .line 32
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->$ENTRIES:LX/0vk;

    .line 37
    .line 38
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment$Companion;

    .line 39
    .line 40
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 41
    .line 42
    .line 43
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->Companion:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment$Companion;

    .line 44
    .line 45
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput p3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->iconRes:I

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->$VALUES:[Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getIconRes()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->iconRes:I

    .line 1
    .line 2
    return p0
.end method
