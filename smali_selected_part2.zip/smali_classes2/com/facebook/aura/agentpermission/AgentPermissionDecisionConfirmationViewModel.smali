.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final stalled:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 12
    .line 13
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->decisionConfirmationStalled:LX/2J3;

    .line 14
    .line 15
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->stalled:LX/2J3;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final checkAgain(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 2

    .line 0
    invoke-static {p1, p2}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->RETRY_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    invoke-static {v0, p2, p1, v1}, LX/3Rs;->A11(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->requestDecisionConfirmation()V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final getStalled()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->stalled:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method
