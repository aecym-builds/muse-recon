.class public final synthetic Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$2$1;
.super LX/DVE;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 0
    const-class v3, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 1
    .line 2
    const-string v5, "browserTaskSiteDomain(Ljava/lang/String;)Ljava/lang/String;"

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v4, "browserTaskSiteDomain"

    .line 7
    .line 8
    move-object v0, p0

    .line 9
    move-object v2, p1

    .line 10
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$reconcileSystemNotifications$2$1;->invoke(Ljava/lang/String;)Ljava/lang/String;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p1, p0}, LX/007;->A0y(Ljava/lang/Object;LX/DqR;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 5
    .line 6
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->access$browserTaskSiteDomain(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method
