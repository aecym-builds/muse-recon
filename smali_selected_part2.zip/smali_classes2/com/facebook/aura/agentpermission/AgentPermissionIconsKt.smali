.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ApprovalIconCornerRadius:F = 12.0f

.field public static final ApprovalIconGlyphSize:F = 28.0f

.field public static final ApprovalIconSize:F = 44.0f


# direct methods
.method public static final approvalCapabilityIconRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/Integer;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 5
    .line 6
    return-object v0
.end method

.method public static final approvalFallbackIconRes(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;Lcom/facebook/aura/gateway/ApprovalIconKey;)I
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    throw v0

    .line 18
    :pswitch_0
    const v0, 0x7f080192

    .line 19
    .line 20
    .line 21
    return v0

    .line 22
    :pswitch_1
    const v0, 0x7f08012c

    .line 23
    .line 24
    .line 25
    return v0

    .line 26
    :pswitch_2
    const v0, 0x7f080244

    .line 27
    .line 28
    .line 29
    return v0

    .line 30
    :pswitch_3
    const v0, 0x7f080286

    .line 31
    .line 32
    .line 33
    return v0

    .line 34
    :pswitch_4
    const v0, 0x7f0801ac

    .line 35
    .line 36
    .line 37
    return v0

    .line 38
    :pswitch_5
    const v0, 0x7f0801ad

    .line 39
    .line 40
    .line 41
    return v0

    .line 42
    :cond_0
    :pswitch_6
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->payloadFallbackIconRes(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    return v0

    .line 47
    nop

    .line 48
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_6
        :pswitch_5
        :pswitch_1
        :pswitch_0
        :pswitch_4
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method

.method public static synthetic approvalFallbackIconRes$default(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;Lcom/facebook/aura/gateway/ApprovalIconKey;ILjava/lang/Object;)I
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    :cond_0
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalFallbackIconRes(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;Lcom/facebook/aura/gateway/ApprovalIconKey;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public static final approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, v0, Lcom/facebook/aura/gateway/ApprovalRecord;->iconKey:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 11
    .line 12
    :goto_0
    invoke-static {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalFallbackIconRes(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;Lcom/facebook/aura/gateway/ApprovalIconKey;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    return v0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    goto :goto_0
.end method

.method public static final getApprovalIconCornerRadius()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 1
    .line 2
    return v0
.end method

.method public static final getApprovalIconGlyphSize()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 1
    .line 2
    return v0
.end method

.method public static final getApprovalIconSize()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 1
    .line 2
    return v0
.end method

.method public static final payloadFallbackIconRes(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;)I
    .locals 0

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    throw p0

    .line 12
    :pswitch_0
    const p0, 0x7f080192

    .line 13
    .line 14
    .line 15
    return p0

    .line 16
    :pswitch_1
    const p0, 0x7f0802a2

    .line 17
    .line 18
    .line 19
    return p0

    .line 20
    :pswitch_2
    const p0, 0x7f0802cc

    .line 21
    .line 22
    .line 23
    return p0

    .line 24
    :pswitch_3
    const p0, 0x7f080244

    .line 25
    .line 26
    .line 27
    return p0

    .line 28
    :pswitch_4
    const p0, 0x7f080286

    .line 29
    .line 30
    .line 31
    return p0

    .line 32
    :pswitch_5
    const p0, 0x7f08007e

    .line 33
    .line 34
    .line 35
    return p0

    .line 36
    :pswitch_6
    const p0, 0x7f0801ac

    .line 37
    .line 38
    .line 39
    return p0

    .line 40
    :pswitch_7
    const p0, 0x7f0801ad

    .line 41
    .line 42
    .line 43
    return p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_6
        :pswitch_6
        :pswitch_6
        :pswitch_6
        :pswitch_5
        :pswitch_6
        :pswitch_0
        :pswitch_2
        :pswitch_3
        :pswitch_6
        :pswitch_7
        :pswitch_4
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
