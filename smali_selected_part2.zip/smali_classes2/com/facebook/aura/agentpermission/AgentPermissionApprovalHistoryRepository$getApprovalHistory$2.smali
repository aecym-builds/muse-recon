.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalHistoryRepository$getApprovalHistory$2"
    f = "AgentPermissionApprovalHistoryRepository.kt"
    l = {
        0x41
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $cursor:Ljava/lang/String;

.field public final synthetic $limit:I

.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;ILjava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;",
            "I",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$limit:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$cursor:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$limit:I

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$cursor:Ljava/lang/String;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;ILjava/lang/String;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v3, p0

    .line 3
    .line 4
    iget v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->label:I

    .line 5
    .line 6
    const/4 v14, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    if-ne v0, v14, :cond_3

    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    :cond_0
    invoke-static {v0}, LX/3Rp;->A12(Ljava/lang/Object;)LX/2PJ;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    return-object v2

    .line 20
    :cond_1
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$limit:I

    .line 24
    .line 25
    iget-object v5, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->$cursor:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    const-string v1, "limit"

    .line 32
    .line 33
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 38
    .line 39
    .line 40
    const-string v1, "record_schema"

    .line 41
    .line 42
    const-string v0, "snapshot_v1"

    .line 43
    .line 44
    invoke-static {v1, v0, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 45
    .line 46
    .line 47
    if-eqz v5, :cond_2

    .line 48
    .line 49
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_2

    .line 54
    .line 55
    const-string v0, "cursor"

    .line 56
    .line 57
    invoke-static {v0, v5, v4}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 58
    .line 59
    .line 60
    :cond_2
    invoke-static {v4}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    const/4 v6, 0x0

    .line 65
    invoke-static {v0}, LX/3Rr;->A1Z(Ljava/util/AbstractCollection;)[LX/IBK;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 70
    .line 71
    sget-object v7, Lcom/facebook/aura/agentpermission/AgentPermissionJarvisPath$ApprovalsHistory;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionJarvisPath$ApprovalsHistory;

    .line 72
    .line 73
    sget-object v8, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 74
    .line 75
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 76
    .line 77
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->userSession:LX/AHE;

    .line 78
    .line 79
    invoke-static {v1}, LX/3Rr;->A1a([LX/IBK;)[LX/IBK;

    .line 80
    .line 81
    .line 82
    move-result-object v11

    .line 83
    invoke-static {}, LX/3Rq;->A1F()Ljava/util/Set;

    .line 84
    .line 85
    .line 86
    move-result-object v13

    .line 87
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 88
    .line 89
    .line 90
    move-result-object v15

    .line 91
    sget-object v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2$invokeSuspend$$inlined$executeJarvisRequest-5dDjBWM$default$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2$invokeSuspend$$inlined$executeJarvisRequest-5dDjBWM$default$1;

    .line 92
    .line 93
    const/4 v10, 0x0

    .line 94
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$0:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$1:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$2:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$3:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$4:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$5:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$6:Ljava/lang/Object;

    .line 107
    .line 108
    iput-object v10, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->L$7:Ljava/lang/Object;

    .line 109
    .line 110
    iput v14, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->I$0:I

    .line 111
    .line 112
    iput v14, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->I$1:I

    .line 113
    .line 114
    iput v6, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->I$2:I

    .line 115
    .line 116
    iput v6, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->I$3:I

    .line 117
    .line 118
    iput v14, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository$getApprovalHistory$2;->label:I

    .line 119
    .line 120
    move-object v12, v10

    .line 121
    move/from16 v16, v14

    .line 122
    .line 123
    move-object/from16 v17, v10

    .line 124
    .line 125
    move/from16 v18, v6

    .line 126
    .line 127
    move/from16 p0, v6

    .line 128
    .line 129
    move-object/from16 p1, v3

    .line 130
    .line 131
    invoke-virtual/range {v4 .. v20}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessJarvisRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/JarvisPath;Lcom/facebook/aura/network/http/RequestType;LX/AHE;Ljava/lang/Long;[LX/IBK;Lcom/facebook/aura/network/transport/HatchHttpCachePolicy;Ljava/util/Set;ZLjava/util/Map;ZLjava/lang/String;ZZLX/2M4;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-ne v0, v2, :cond_0

    .line 136
    .line 137
    return-object v2

    .line 138
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    throw v0
.end method
