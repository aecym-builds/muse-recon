.class public final Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $backgroundColor:J

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $scrollState:LX/3Lr;


# direct methods
.method public constructor <init>(LX/3Lr;JLX/3C1;II)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$scrollState:LX/3Lr;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$backgroundColor:J

    .line 3
    .line 4
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$modifier:LX/3C1;

    .line 5
    .line 6
    iput p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$$changed:I

    .line 7
    .line 8
    iput p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$$default:I

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 7

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$scrollState:LX/3Lr;

    .line 1
    .line 2
    iget-wide v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$backgroundColor:J

    .line 3
    .line 4
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$modifier:LX/3C1;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$$changed:I

    .line 7
    .line 8
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 9
    .line 10
    .line 11
    move-result v6

    .line 12
    iget p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;->$$default:I

    .line 13
    .line 14
    move-object v5, p1

    .line 15
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineRequestPreviewBottomFade-3IgeMak(LX/3Lr;JLX/3C1;LX/2d4;II)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
