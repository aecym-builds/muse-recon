.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# instance fields
.field public final synthetic $isVisible$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;->$isVisible$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/8j5;)LX/60k;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;->$isVisible$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;->$isVisible$delegate:Landroidx/compose/runtime/MutableState;

    .line 11
    .line 12
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1$1;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, LX/60k;

    .line 18
    .line 19
    invoke-direct {v0, v1}, LX/60k;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/8j5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;->invoke(LX/8j5;)LX/60k;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
