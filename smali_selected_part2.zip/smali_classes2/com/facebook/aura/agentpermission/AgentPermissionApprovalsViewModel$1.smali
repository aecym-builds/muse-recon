.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalsViewModel$1"
    f = "AgentPermissionApprovalsViewModel.kt"
    l = {
        0x7a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v4, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v5

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 19
    .line 20
    iget-object v0, v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 21
    .line 22
    iget-object v2, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->historyRefreshVersion:LX/2J3;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    new-instance v1, LX/EWQ;

    .line 26
    .line 27
    invoke-direct {v1, v2, v0}, LX/EWQ;-><init>(Ljava/lang/Object;I)V

    .line 28
    .line 29
    .line 30
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1$1;

    .line 31
    .line 32
    invoke-direct {v0, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)V

    .line 33
    .line 34
    .line 35
    iput v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$1;->label:I

    .line 36
    .line 37
    invoke-virtual {v1, v0, p0}, LX/EWQ;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-ne v0, v5, :cond_0

    .line 42
    .line 43
    return-object v5

    .line 44
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0
.end method
