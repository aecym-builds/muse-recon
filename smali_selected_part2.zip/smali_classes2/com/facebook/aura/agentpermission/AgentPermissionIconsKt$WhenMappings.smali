.class public abstract synthetic Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    invoke-static {}, Lcom/facebook/aura/gateway/ApprovalIconKey;->values()[Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v2, v0, [I

    .line 6
    .line 7
    const/4 v9, 0x1

    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->NETWORK:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 9
    .line 10
    invoke-static {v0, v2, v9}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    :catch_0
    const/4 v8, 0x2

    .line 14
    :try_start_1
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->BROWSER:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 15
    .line 16
    invoke-static {v0, v2, v8}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 17
    .line 18
    .line 19
    :catch_1
    const/4 v7, 0x3

    .line 20
    :try_start_2
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->DEVICE:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 21
    .line 22
    invoke-static {v0, v2, v7}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 23
    .line 24
    .line 25
    :catch_2
    const/4 v6, 0x4

    .line 26
    :try_start_3
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->MEDIA:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 27
    .line 28
    invoke-static {v0, v2, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 29
    .line 30
    .line 31
    :catch_3
    const/4 v5, 0x5

    .line 32
    :try_start_4
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->WARNING:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 33
    .line 34
    invoke-static {v0, v2, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 35
    .line 36
    .line 37
    :catch_4
    const/4 v4, 0x6

    .line 38
    :try_start_5
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->CONNECTOR:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 39
    .line 40
    invoke-static {v0, v2, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 41
    .line 42
    .line 43
    :catch_5
    const/4 v3, 0x7

    .line 44
    :try_start_6
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->TOOL:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 45
    .line 46
    invoke-static {v0, v2, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 47
    .line 48
    .line 49
    :catch_6
    const/16 v1, 0x8

    .line 50
    .line 51
    :try_start_7
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalIconKey;->CHECKOUT:Lcom/facebook/aura/gateway/ApprovalIconKey;

    .line 52
    .line 53
    invoke-static {v0, v2, v1}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 54
    .line 55
    .line 56
    :catch_7
    sput-object v2, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 57
    .line 58
    invoke-static {}, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->values()[Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    array-length v0, v0

    .line 63
    new-array v2, v0, [I

    .line 64
    .line 65
    :try_start_8
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->NETWORK:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 66
    .line 67
    invoke-static {v0, v2, v9}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 68
    .line 69
    .line 70
    :catch_8
    :try_start_9
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->BROWSER_ACTION:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 71
    .line 72
    invoke-static {v0, v2, v8}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 73
    .line 74
    .line 75
    :catch_9
    :try_start_a
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->BROWSER_TASK_CONFIRMATION:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 76
    .line 77
    invoke-static {v0, v2, v7}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    .line 78
    .line 79
    .line 80
    :catch_a
    :try_start_b
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->BROWSER_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 81
    .line 82
    invoke-static {v0, v2, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    .line 83
    .line 84
    .line 85
    :catch_b
    :try_start_c
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->STRIPE_LINK_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 86
    .line 87
    invoke-static {v0, v2, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_c} :catch_c

    .line 88
    .line 89
    .line 90
    :catch_c
    :try_start_d
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->RESERVATION_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 91
    .line 92
    invoke-static {v0, v2, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_d .. :try_end_d} :catch_d

    .line 93
    .line 94
    .line 95
    :catch_d
    :try_start_e
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->SHOPIFY_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 96
    .line 97
    invoke-static {v0, v2, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_e .. :try_end_e} :catch_e

    .line 98
    .line 99
    .line 100
    :catch_e
    :try_start_f
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->FLIGHT_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 101
    .line 102
    invoke-static {v0, v2, v1}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_f .. :try_end_f} :catch_f

    .line 103
    .line 104
    .line 105
    :catch_f
    :try_start_10
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->DEVICE:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 106
    .line 107
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    const/16 v0, 0x9

    .line 112
    .line 113
    aput v0, v2, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_10 .. :try_end_10} :catch_10

    .line 114
    .line 115
    :catch_10
    :try_start_11
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->OUTGOING_MEDIA:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 116
    .line 117
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    const/16 v0, 0xa

    .line 122
    .line 123
    aput v0, v2, v1
    :try_end_11
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_11} :catch_11

    .line 124
    .line 125
    :catch_11
    :try_start_12
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->DELIVERY_CHECKOUT:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 126
    .line 127
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    const/16 v0, 0xb

    .line 132
    .line 133
    aput v0, v2, v1
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_12} :catch_12

    .line 134
    .line 135
    :catch_12
    :try_start_13
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->PURCHASE_PREAPPROVAL:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    const/16 v0, 0xc

    .line 142
    .line 143
    aput v0, v2, v1
    :try_end_13
    .catch Ljava/lang/NoSuchFieldError; {:try_start_13 .. :try_end_13} :catch_13

    .line 144
    .line 145
    :catch_13
    :try_start_14
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->CAR_RENTAL_RESERVATION:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 146
    .line 147
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 148
    .line 149
    .line 150
    move-result v1

    .line 151
    const/16 v0, 0xd

    .line 152
    .line 153
    aput v0, v2, v1
    :try_end_14
    .catch Ljava/lang/NoSuchFieldError; {:try_start_14 .. :try_end_14} :catch_14

    .line 154
    .line 155
    :catch_14
    :try_start_15
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->CONNECTOR:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 156
    .line 157
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    const/16 v0, 0xe

    .line 162
    .line 163
    aput v0, v2, v1
    :try_end_15
    .catch Ljava/lang/NoSuchFieldError; {:try_start_15 .. :try_end_15} :catch_15

    .line 164
    .line 165
    :catch_15
    :try_start_16
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->UNKNOWN:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 166
    .line 167
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    const/16 v0, 0xf

    .line 172
    .line 173
    aput v0, v2, v1
    :try_end_16
    .catch Ljava/lang/NoSuchFieldError; {:try_start_16 .. :try_end_16} :catch_16

    .line 174
    .line 175
    :catch_16
    sput-object v2, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt$WhenMappings;->$EnumSwitchMapping$1:[I

    .line 176
    .line 177
    return-void
.end method
