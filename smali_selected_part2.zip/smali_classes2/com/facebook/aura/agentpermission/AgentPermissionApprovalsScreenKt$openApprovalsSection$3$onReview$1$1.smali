.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $onOpen:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$onOpen:LX/JDM;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 4

    .line 0
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchComponent;->OPEN_AGENT_PERMISSION_DECISION_SELECTOR_SHEET:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$uiState:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v3, v2, v1, v0}, LX/3Rs;->A11(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V

    .line 15
    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$onOpen:LX/JDM;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 20
    .line 21
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    return-void
.end method
