.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionHistoryDetailsSheet(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v14, p2

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    move-object/from16 v5, p0

    .line 4
    .line 5
    invoke-static {v5, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x69b9a875

    .line 9
    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_13

    .line 21
    .line 22
    invoke-static {v3, v5}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v7

    .line 26
    or-int v7, v7, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v4, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v3, v4}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v7, v0

    .line 39
    :cond_0
    and-int/lit8 v6, p5, 0x4

    .line 40
    .line 41
    if-eqz v6, :cond_12

    .line 42
    .line 43
    or-int/lit16 v7, v7, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    invoke-static {v7}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v3, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_a

    .line 54
    .line 55
    if-eqz v6, :cond_2

    .line 56
    .line 57
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    invoke-static {v3}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 60
    .line 61
    .line 62
    move-result-object v9

    .line 63
    shr-int/lit8 v12, v7, 0x3

    .line 64
    .line 65
    and-int/lit8 v0, v12, 0xe

    .line 66
    .line 67
    invoke-static {v4, v3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->rememberAgentPermissionApprovalsViewModel(Ljava/lang/String;LX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    iget-object v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->uiState:LX/2J3;

    .line 72
    .line 73
    const/4 v13, 0x0

    .line 74
    invoke-static {v3, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 75
    .line 76
    .line 77
    move-result-object v10

    .line 78
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 83
    .line 84
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 85
    .line 86
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    :cond_3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    const/16 v20, 0x0

    .line 95
    .line 96
    if-eqz v0, :cond_9

    .line 97
    .line 98
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v8

    .line 102
    move-object v0, v8

    .line 103
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 104
    .line 105
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 106
    .line 107
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_3

    .line 112
    .line 113
    :goto_2
    check-cast v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 114
    .line 115
    invoke-interface {v3, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v6

    .line 119
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    if-nez v6, :cond_4

    .line 124
    .line 125
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 126
    .line 127
    if-ne v0, v6, :cond_5

    .line 128
    .line 129
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$1$1;

    .line 130
    .line 131
    invoke-direct {v0, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)V

    .line 132
    .line 133
    .line 134
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :cond_5
    invoke-static {v3, v10, v0, v7}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 142
    .line 143
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 144
    .line 145
    invoke-interface {v3, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    invoke-static {v3, v10, v9, v0}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    if-nez v6, :cond_6

    .line 158
    .line 159
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 160
    .line 161
    if-ne v0, v6, :cond_7

    .line 162
    .line 163
    :cond_6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;

    .line 164
    .line 165
    invoke-direct {v0, v8, v9, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;LX/16A;)V

    .line 166
    .line 167
    .line 168
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    :cond_7
    check-cast v0, LX/JDM;

    .line 172
    .line 173
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 174
    .line 175
    invoke-static {v3, v8, v7, v0}, LX/CdB;->A03(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;LX/JDM;)V

    .line 176
    .line 177
    .line 178
    if-nez v8, :cond_b

    .line 179
    .line 180
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    if-eqz v1, :cond_8

    .line 185
    .line 186
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$currentApproval$1;

    .line 187
    .line 188
    move-object/from16 p0, v0

    .line 189
    .line 190
    move-object/from16 p1, v5

    .line 191
    .line 192
    move-object/from16 p2, v4

    .line 193
    .line 194
    move-object/from16 p3, v14

    .line 195
    .line 196
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$currentApproval$1;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 197
    .line 198
    .line 199
    :goto_3
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    :cond_8
    return-void

    .line 203
    :cond_9
    move-object/from16 v8, v20

    .line 204
    .line 205
    goto :goto_2

    .line 206
    :cond_a
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 207
    .line 208
    .line 209
    goto/16 :goto_8

    .line 210
    .line 211
    :cond_b
    invoke-static {v8}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalHistoryTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v7

    .line 215
    invoke-static {v8, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalHistorySummary(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v19

    .line 219
    iget-object v0, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 220
    .line 221
    if-eqz v0, :cond_11

    .line 222
    .line 223
    iget-object v6, v0, Lcom/facebook/aura/gateway/ApprovalRecord;->outcomeLabel:Ljava/lang/String;

    .line 224
    .line 225
    if-eqz v6, :cond_11

    .line 226
    .line 227
    const v0, 0x1e0f0b8f

    .line 228
    .line 229
    .line 230
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 231
    .line 232
    .line 233
    :goto_4
    invoke-static {v3}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    if-nez v6, :cond_10

    .line 238
    .line 239
    const v6, 0x1e0f1b7a

    .line 240
    .line 241
    .line 242
    invoke-interface {v3, v6}, LX/2d4;->Agj(I)V

    .line 243
    .line 244
    .line 245
    invoke-static {v8, v3, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->decisionLabel(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    :goto_5
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 250
    .line 251
    .line 252
    iget-object v10, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 253
    .line 254
    if-nez v10, :cond_f

    .line 255
    .line 256
    const v10, -0x5c29819c

    .line 257
    .line 258
    .line 259
    invoke-interface {v3, v10}, LX/2d4;->Agj(I)V

    .line 260
    .line 261
    .line 262
    iget-object v10, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->purchaseHistoryFacts:Lcom/facebook/aura/gateway/PurchaseHistoryFacts;

    .line 263
    .line 264
    if-nez v10, :cond_e

    .line 265
    .line 266
    const v10, -0x5c29819d

    .line 267
    .line 268
    .line 269
    invoke-interface {v3, v10}, LX/2d4;->Agj(I)V

    .line 270
    .line 271
    .line 272
    :goto_6
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 273
    .line 274
    .line 275
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 276
    .line 277
    .line 278
    :goto_7
    invoke-static {v3, v8, v9}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 279
    .line 280
    .line 281
    move-result v10

    .line 282
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v0

    .line 286
    if-nez v10, :cond_c

    .line 287
    .line 288
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 289
    .line 290
    if-ne v0, v10, :cond_d

    .line 291
    .line 292
    :cond_c
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$3$1;

    .line 293
    .line 294
    invoke-direct {v0, v8, v9}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$3$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 295
    .line 296
    .line 297
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    :cond_d
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 301
    .line 302
    new-instance v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;

    .line 303
    .line 304
    move-object/from16 v17, v6

    .line 305
    .line 306
    move-object/from16 v18, v7

    .line 307
    .line 308
    move-object v15, v9

    .line 309
    move-object/from16 v16, v8

    .line 310
    .line 311
    invoke-direct/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;)V

    .line 312
    .line 313
    .line 314
    const v6, 0x204e509

    .line 315
    .line 316
    .line 317
    invoke-static {v3, v9, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 318
    .line 319
    .line 320
    move-result-object p0

    .line 321
    and-int/lit8 p2, v12, 0x70

    .line 322
    .line 323
    const/16 p3, 0x180

    .line 324
    .line 325
    const/16 p4, 0xfbd

    .line 326
    .line 327
    move-object v15, v13

    .line 328
    move-object/from16 v16, v13

    .line 329
    .line 330
    move-object/from16 v17, v13

    .line 331
    .line 332
    move-object/from16 v18, v13

    .line 333
    .line 334
    move/from16 v21, v1

    .line 335
    .line 336
    move/from16 v22, v1

    .line 337
    .line 338
    move-object/from16 v23, v13

    .line 339
    .line 340
    move-object/from16 v24, v13

    .line 341
    .line 342
    move-object/from16 p1, v3

    .line 343
    .line 344
    move-object/from16 v19, v0

    .line 345
    .line 346
    move/from16 v20, v1

    .line 347
    .line 348
    invoke-static/range {v13 .. v29}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 349
    .line 350
    .line 351
    :goto_8
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    if-eqz v1, :cond_8

    .line 356
    .line 357
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$5;

    .line 358
    .line 359
    move-object/from16 p0, v0

    .line 360
    .line 361
    move-object/from16 p1, v5

    .line 362
    .line 363
    move-object/from16 p2, v4

    .line 364
    .line 365
    move-object/from16 p3, v14

    .line 366
    .line 367
    move/from16 p4, v2

    .line 368
    .line 369
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$5;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 370
    .line 371
    .line 372
    goto/16 :goto_3

    .line 373
    .line 374
    :cond_e
    const v11, 0x1e0f2d5e

    .line 375
    .line 376
    .line 377
    invoke-interface {v3, v11}, LX/2d4;->Agj(I)V

    .line 378
    .line 379
    .line 380
    sget v11, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->$stable:I

    .line 381
    .line 382
    invoke-static {v10, v3, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->toPreviewDocument(Lcom/facebook/aura/gateway/PurchaseHistoryFacts;LX/2d4;I)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 383
    .line 384
    .line 385
    move-result-object v20

    .line 386
    goto :goto_6

    .line 387
    :cond_f
    const v11, 0x1e0f2278

    .line 388
    .line 389
    .line 390
    invoke-interface {v3, v11}, LX/2d4;->Agj(I)V

    .line 391
    .line 392
    .line 393
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 394
    .line 395
    .line 396
    move-object/from16 v20, v10

    .line 397
    .line 398
    goto :goto_7

    .line 399
    :cond_10
    const v10, 0x1e0f0bbc

    .line 400
    .line 401
    .line 402
    invoke-interface {v3, v10}, LX/2d4;->Agj(I)V

    .line 403
    .line 404
    .line 405
    goto/16 :goto_5

    .line 406
    .line 407
    :cond_11
    const v0, 0x1e0f1485

    .line 408
    .line 409
    .line 410
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 411
    .line 412
    .line 413
    invoke-static {v8, v3, v10}, Lcom/facebook/aura/agentpermission/CheckoutPaymentSetupRowKt;->paymentSetupOutcomeLabel(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 414
    .line 415
    .line 416
    move-result-object v6

    .line 417
    goto/16 :goto_4

    .line 418
    .line 419
    :cond_12
    and-int/lit16 v0, v2, 0x180

    .line 420
    .line 421
    if-nez v0, :cond_1

    .line 422
    .line 423
    invoke-static {v3, v14}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 424
    .line 425
    .line 426
    move-result v0

    .line 427
    or-int/2addr v7, v0

    .line 428
    goto/16 :goto_1

    .line 429
    .line 430
    :cond_13
    move v7, v2

    .line 431
    goto/16 :goto_0
.end method

.method public static final AgentPermissionHistoryDetailsSheet$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final HistoryMetadataRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 23

    .line 0
    move-object/from16 v7, p2

    .line 1
    .line 2
    const v0, -0x16fc172f

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v0, p4

    .line 11
    .line 12
    and-int/lit8 v2, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v2, :cond_4

    .line 17
    .line 18
    invoke-static {v4, v1, v0}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    invoke-static {v2}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    or-int v9, v9, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v2, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v8, p1

    .line 31
    .line 32
    if-nez v2, :cond_0

    .line 33
    .line 34
    invoke-static {v1, v8}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    or-int/2addr v9, v2

    .line 39
    :cond_0
    and-int/lit8 v5, p5, 0x4

    .line 40
    .line 41
    if-eqz v5, :cond_3

    .line 42
    .line 43
    or-int/lit16 v9, v9, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    and-int/lit16 v3, v9, 0x93

    .line 46
    .line 47
    const/16 v2, 0x92

    .line 48
    .line 49
    const/4 v6, 0x0

    .line 50
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    invoke-static {v2, v1, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-eqz v2, :cond_7

    .line 59
    .line 60
    if-eqz v5, :cond_2

    .line 61
    .line 62
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 65
    .line 66
    .line 67
    move-result-object v10

    .line 68
    sget-object v5, LX/Dn6;->A03:LX/1Yw;

    .line 69
    .line 70
    sget-object v3, LX/2Id;->A04:LX/2rU;

    .line 71
    .line 72
    const/16 v2, 0x36

    .line 73
    .line 74
    invoke-static {v5, v1, v3, v2}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 75
    .line 76
    .line 77
    move-result-object v13

    .line 78
    move-object v5, v1

    .line 79
    check-cast v5, LX/J7I;

    .line 80
    .line 81
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 82
    .line 83
    .line 84
    move-result v12

    .line 85
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 86
    .line 87
    .line 88
    move-result-object v11

    .line 89
    invoke-static {v1, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v10

    .line 93
    sget-object v3, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    iget-object v2, v5, LX/J7I;->A0V:LX/3DJ;

    .line 96
    .line 97
    if-nez v2, :cond_5

    .line 98
    .line 99
    invoke-static {}, LX/1VY;->A00()V

    .line 100
    .line 101
    .line 102
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    throw v0

    .line 107
    :cond_3
    and-int/lit16 v2, v0, 0x180

    .line 108
    .line 109
    if-nez v2, :cond_1

    .line 110
    .line 111
    invoke-static {v1, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 112
    .line 113
    .line 114
    move-result v2

    .line 115
    or-int/2addr v9, v2

    .line 116
    goto :goto_1

    .line 117
    :cond_4
    move v9, v0

    .line 118
    goto :goto_0

    .line 119
    :cond_5
    invoke-static {v1, v5, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v1, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 123
    .line 124
    .line 125
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 126
    .line 127
    and-int/lit8 v2, v9, 0xe

    .line 128
    .line 129
    or-int/2addr v3, v2

    .line 130
    invoke-static {v4, v1, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->historyOutcomeColor(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)J

    .line 131
    .line 132
    .line 133
    move-result-wide v12

    .line 134
    shr-int/lit8 v2, v9, 0x3

    .line 135
    .line 136
    and-int/lit8 v18, v2, 0xe

    .line 137
    .line 138
    const/16 v19, 0xc

    .line 139
    .line 140
    const/4 v10, 0x0

    .line 141
    const-wide/16 v15, 0x0

    .line 142
    .line 143
    move-object v14, v10

    .line 144
    move-object/from16 v17, v1

    .line 145
    .line 146
    move-object v11, v8

    .line 147
    invoke-static/range {v11 .. v19}, Lcom/facebook/aura/vds/compose/tag/AuraStatusTagKt;->AuraStatusTag--RWsq2U(Ljava/lang/String;JLX/3C1;JLX/2d4;II)V

    .line 148
    .line 149
    .line 150
    iget-wide v2, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestedAtMs:J

    .line 151
    .line 152
    cmp-long v9, v2, v15

    .line 153
    .line 154
    if-lez v9, :cond_6

    .line 155
    .line 156
    const v2, -0x640029ad

    .line 157
    .line 158
    .line 159
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 160
    .line 161
    .line 162
    iget-wide v2, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestedAtMs:J

    .line 163
    .line 164
    invoke-static {v2, v3, v1, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->approvalHistorySheetTimestamp(JLX/2d4;I)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 169
    .line 170
    invoke-static {v1, v2}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 171
    .line 172
    .line 173
    move-result-object v13

    .line 174
    invoke-static {v1, v2}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 175
    .line 176
    .line 177
    move-result-wide v11

    .line 178
    const/16 p4, 0x3ff2

    .line 179
    .line 180
    move-object v15, v10

    .line 181
    move-object/from16 v16, v10

    .line 182
    .line 183
    move/from16 v18, v6

    .line 184
    .line 185
    move/from16 v19, v6

    .line 186
    .line 187
    move/from16 v20, v6

    .line 188
    .line 189
    move-object/from16 v21, v10

    .line 190
    .line 191
    move-object/from16 v22, v10

    .line 192
    .line 193
    move-object/from16 p0, v10

    .line 194
    .line 195
    move-object/from16 p1, v1

    .line 196
    .line 197
    move/from16 p2, v6

    .line 198
    .line 199
    move/from16 p3, v6

    .line 200
    .line 201
    move/from16 v17, v6

    .line 202
    .line 203
    invoke-static/range {v9 .. v27}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 204
    .line 205
    .line 206
    :goto_2
    invoke-static {v5}, LX/003;->A0u(LX/J7I;)V

    .line 207
    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_6
    const v2, -0x63fd3a2b

    .line 211
    .line 212
    .line 213
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 214
    .line 215
    .line 216
    goto :goto_2

    .line 217
    :cond_7
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 218
    .line 219
    .line 220
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 221
    .line 222
    .line 223
    move-result-object v2

    .line 224
    if-eqz v2, :cond_8

    .line 225
    .line 226
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$HistoryMetadataRow$2;

    .line 227
    .line 228
    move-object/from16 p0, v1

    .line 229
    .line 230
    move-object/from16 p1, v4

    .line 231
    .line 232
    move-object/from16 p2, v8

    .line 233
    .line 234
    move-object/from16 p3, v7

    .line 235
    .line 236
    move/from16 p4, v0

    .line 237
    .line 238
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$HistoryMetadataRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/3C1;II)V

    .line 239
    .line 240
    .line 241
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 242
    .line 243
    :cond_8
    return-void
.end method

.method public static final synthetic access$AgentPermissionHistoryDetailsSheet$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$HistoryMetadataRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->HistoryMetadataRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final approvalHistorySheetTimestamp(JLX/2d4;I)Ljava/lang/String;
    .locals 5

    .line 0
    invoke-static {p2}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    new-instance v1, Ljava/util/Date;

    .line 5
    .line 6
    invoke-direct {v1, p0, p1}, Ljava/util/Date;-><init>(J)V

    .line 7
    .line 8
    .line 9
    invoke-static {v4}, Landroid/text/format/DateFormat;->getTimeFormat(Landroid/content/Context;)Ljava/text/DateFormat;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v2, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-static {p0, p1}, Landroid/text/format/DateUtils;->isToday(J)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    const v0, -0x7d7fc506

    .line 35
    .line 36
    .line 37
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 38
    .line 39
    .line 40
    const v1, 0x7f120148

    .line 41
    .line 42
    .line 43
    :goto_0
    invoke-static {v3}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    :goto_1
    invoke-static {p2, v0, v1}, LX/18b;->A0A(LX/2d4;[Ljava/lang/Object;I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_0
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->isYesterday(Ljava/util/Calendar;Ljava/util/Calendar;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_1

    .line 66
    .line 67
    const v0, -0x7d7fb5a2

    .line 68
    .line 69
    .line 70
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 71
    .line 72
    .line 73
    const v1, 0x7f120149

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_1
    const v0, -0x32758ce9

    .line 78
    .line 79
    .line 80
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 81
    .line 82
    .line 83
    const v0, 0x10018

    .line 84
    .line 85
    .line 86
    invoke-static {v4, p0, p1, v0}, Landroid/text/format/DateUtils;->formatDateTime(Landroid/content/Context;JI)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    const v1, 0x7f120147

    .line 91
    .line 92
    .line 93
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    invoke-static {v3}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    filled-new-array {v0, v3}, [Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    goto :goto_1
.end method

.method public static final historyOutcomeColor(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)J
    .locals 3

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz p0, :cond_6

    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 6
    .line 7
    :goto_0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->TIMED_OUT:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 8
    .line 9
    if-eq v2, v0, :cond_5

    .line 10
    .line 11
    if-eqz p0, :cond_4

    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 14
    .line 15
    :goto_1
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->TIMED_OUT:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 16
    .line 17
    if-eq v2, v0, :cond_5

    .line 18
    .line 19
    if-eqz p0, :cond_3

    .line 20
    .line 21
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 22
    .line 23
    :goto_2
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->DENIED:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 24
    .line 25
    if-eq v2, v0, :cond_2

    .line 26
    .line 27
    if-eqz p0, :cond_1

    .line 28
    .line 29
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 30
    .line 31
    :goto_3
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->DENY:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 32
    .line 33
    if-eq v2, v0, :cond_2

    .line 34
    .line 35
    if-eqz p0, :cond_0

    .line 36
    .line 37
    iget-object v1, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 38
    .line 39
    :cond_0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->DENY_ALWAYS:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 40
    .line 41
    if-eq v1, v0, :cond_2

    .line 42
    .line 43
    const v0, -0x34945a17    # -1.5443433E7f

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->success:J

    .line 51
    .line 52
    :goto_4
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    return-wide v0

    .line 56
    :cond_1
    move-object v2, v1

    .line 57
    goto :goto_3

    .line 58
    :cond_2
    const v0, -0x34945eb9    # -1.5442247E7f

    .line 59
    .line 60
    .line 61
    invoke-static {p1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->error:J

    .line 66
    .line 67
    goto :goto_4

    .line 68
    :cond_3
    move-object v2, v1

    .line 69
    goto :goto_2

    .line 70
    :cond_4
    move-object v2, v1

    .line 71
    goto :goto_1

    .line 72
    :cond_5
    const v0, -0x34947c91    # -1.5434607E7f

    .line 73
    .line 74
    .line 75
    invoke-static {p1, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 80
    .line 81
    goto :goto_4

    .line 82
    :cond_6
    move-object v2, v1

    .line 83
    goto :goto_0
.end method

.method public static final isYesterday(Ljava/util/Calendar;Ljava/util/Calendar;)Z
    .locals 5

    .line 0
    invoke-virtual {p1}, Ljava/util/Calendar;->clone()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    const/16 v0, 0x38

    .line 5
    .line 6
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v4, v0}, LX/I1c;->A0g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    check-cast v4, Ljava/util/Calendar;

    .line 14
    .line 15
    const/4 v0, -0x1

    .line 16
    const/4 v3, 0x6

    .line 17
    invoke-virtual {v4, v3, v0}, Ljava/util/Calendar;->add(II)V

    .line 18
    .line 19
    .line 20
    const/4 v2, 0x1

    .line 21
    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    invoke-virtual {v4, v2}, Ljava/util/Calendar;->get(I)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-ne v1, v0, :cond_0

    .line 30
    .line 31
    invoke-virtual {p0, v3}, Ljava/util/Calendar;->get(I)I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-virtual {v4, v3}, Ljava/util/Calendar;->get(I)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-ne v1, v0, :cond_0

    .line 40
    .line 41
    return v2

    .line 42
    :cond_0
    const/4 v2, 0x0

    .line 43
    return v2
.end method

.method public static final previewField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;
    .locals 2

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    new-instance v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, v1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object v0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    return-object v0
.end method

.method public static final toPreviewDocument(Lcom/facebook/aura/gateway/PurchaseHistoryFacts;LX/2d4;I)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;
    .locals 8

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->totalAmount:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v7, 0x0

    .line 3
    if-eqz v3, :cond_3

    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->totalKind:Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;->STAY:Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->totalCurrency:Ljava/lang/String;

    .line 10
    .line 11
    if-ne v2, v1, :cond_2

    .line 12
    .line 13
    invoke-static {v3, v0}, LX/3Rs;->A0Q(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    :goto_0
    const v0, 0x7f120145

    .line 18
    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->merchant:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->previewField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    iget-object v2, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->totalKind:Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;

    .line 32
    .line 33
    sget-object v1, Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;->ESTIMATED:Lcom/facebook/aura/gateway/PurchaseHistoryTotalKind;

    .line 34
    .line 35
    const v0, 0x7f120199

    .line 36
    .line 37
    .line 38
    if-ne v2, v1, :cond_0

    .line 39
    .line 40
    const v0, 0x7f1200b7

    .line 41
    .line 42
    .line 43
    :cond_0
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-static {v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->previewField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    iget-object v6, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->dueNow:Lcom/facebook/aura/gateway/PurchaseHistoryDueNow;

    .line 52
    .line 53
    if-nez v6, :cond_1

    .line 54
    .line 55
    const v0, -0x4f97eba7

    .line 56
    .line 57
    .line 58
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 59
    .line 60
    .line 61
    :goto_1
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    const v0, 0x7f1200ba

    .line 65
    .line 66
    .line 67
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    iget-object v1, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->paymentMethodLabel:Ljava/lang/String;

    .line 72
    .line 73
    iget-object v0, p0, Lcom/facebook/aura/gateway/PurchaseHistoryFacts;->cardLast4:Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {v1, v0, p1, v3}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutPaymentMethodLabel(Ljava/lang/String;Ljava/lang/String;LX/2d4;I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->previewField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    filled-new-array {v5, v4, v7, v0}, [Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    new-instance v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;

    .line 92
    .line 93
    invoke-direct {v0, v1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;-><init>(Ljava/util/List;)V

    .line 94
    .line 95
    .line 96
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    const/4 v1, 0x0

    .line 101
    new-instance v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 102
    .line 103
    invoke-direct {v0, v3, v2, v3, v1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;-><init>(ZLjava/util/List;ZLjava/util/List;)V

    .line 104
    .line 105
    .line 106
    return-object v0

    .line 107
    :cond_1
    const v0, -0x4f97eba6

    .line 108
    .line 109
    .line 110
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 111
    .line 112
    .line 113
    const v0, 0x7f120157

    .line 114
    .line 115
    .line 116
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    iget-object v1, v6, Lcom/facebook/aura/gateway/PurchaseHistoryDueNow;->amount:Ljava/lang/String;

    .line 121
    .line 122
    iget-object v0, v6, Lcom/facebook/aura/gateway/PurchaseHistoryDueNow;->currency:Ljava/lang/String;

    .line 123
    .line 124
    invoke-static {v1, v0}, LX/3Rs;->A0Q(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-static {v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->previewField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    goto :goto_1

    .line 133
    :cond_2
    invoke-static {v3, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutFormattedAmount(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v4

    .line 137
    goto :goto_0

    .line 138
    :cond_3
    move-object v4, v7

    .line 139
    goto :goto_0
.end method
