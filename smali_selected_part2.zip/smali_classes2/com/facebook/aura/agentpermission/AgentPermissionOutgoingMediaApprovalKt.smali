.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final OutgoingMediaShape:LX/2bC;

.field public static final OutgoingMediaThumbnailSize:F = 150.0f


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    const/high16 v0, 0x41400000    # 12.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaShape:LX/2bC;

    .line 7
    .line 8
    return-void
.end method

.method public static final AgentPermissionOutgoingMediaApproval(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaApproval;LX/3C1;LX/2d4;II)V
    .locals 34

    .line 0
    move-object/from16 v7, p1

    .line 1
    .line 2
    const v0, 0x25d42788

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v0, :cond_b

    .line 17
    .line 18
    invoke-static {v8, v6, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    or-int v3, v3, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v19, p4

    .line 29
    .line 30
    and-int/lit8 v2, p4, 0x2

    .line 31
    .line 32
    if-eqz v2, :cond_a

    .line 33
    .line 34
    or-int/lit8 v3, v3, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v1, v3, 0x13

    .line 37
    .line 38
    const/16 v0, 0x12

    .line 39
    .line 40
    const/4 v15, 0x1

    .line 41
    const/4 v4, 0x0

    .line 42
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-static {v0, v6, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    if-eqz v2, :cond_1

    .line 53
    .line 54
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    :cond_1
    const/16 v25, 0x0

    .line 57
    .line 58
    if-eqz p0, :cond_2

    .line 59
    .line 60
    iget-object v3, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaApproval;->items:Ljava/util/List;

    .line 61
    .line 62
    if-nez v3, :cond_3

    .line 63
    .line 64
    :cond_2
    sget-object v3, LX/0wV;->A00:LX/0wV;

    .line 65
    .line 66
    :cond_3
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_5

    .line 71
    .line 72
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    if-eqz v2, :cond_4

    .line 77
    .line 78
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$1;

    .line 79
    .line 80
    move/from16 v0, v19

    .line 81
    .line 82
    invoke-direct {v1, v8, v7, v5, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaApproval;LX/3C1;II)V

    .line 83
    .line 84
    .line 85
    :goto_2
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 86
    .line 87
    :cond_4
    return-void

    .line 88
    :cond_5
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 89
    .line 90
    invoke-interface {v7, v14}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 91
    .line 92
    .line 93
    move-result-object v10

    .line 94
    sget v13, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 95
    .line 96
    invoke-static {v6, v13, v4}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    move-object v2, v6

    .line 101
    check-cast v2, LX/J7I;

    .line 102
    .line 103
    iget-wide v11, v2, LX/J7I;->A06:J

    .line 104
    .line 105
    invoke-static {v11, v12}, LX/001;->A0A(J)I

    .line 106
    .line 107
    .line 108
    move-result v9

    .line 109
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-static {v6, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v16

    .line 117
    sget-object v12, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 118
    .line 119
    iget-object v10, v2, LX/J7I;->A0V:LX/3DJ;

    .line 120
    .line 121
    if-nez v10, :cond_6

    .line 122
    .line 123
    invoke-static {}, LX/1VY;->A00()V

    .line 124
    .line 125
    .line 126
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    throw v0

    .line 131
    :cond_6
    invoke-static {v6, v2, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 132
    .line 133
    .line 134
    sget-object v11, LX/3Cl;->A04:LX/JDN;

    .line 135
    .line 136
    invoke-static {v6, v1, v11}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    invoke-static {v6, v0, v1, v9}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 141
    .line 142
    .line 143
    move-result-object v18

    .line 144
    sget-object v0, LX/3Cl;->A02:LX/JDM;

    .line 145
    .line 146
    move-object/from16 v9, v16

    .line 147
    .line 148
    invoke-static {v6, v9, v0}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 149
    .line 150
    .line 151
    move-result-object v17

    .line 152
    const v9, 0x7f120163

    .line 153
    .line 154
    .line 155
    invoke-static {v6, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v20

    .line 159
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 160
    .line 161
    invoke-static {v6, v9}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 162
    .line 163
    .line 164
    move-result-object v24

    .line 165
    invoke-static {v6, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 166
    .line 167
    .line 168
    move-result-wide v22

    .line 169
    sget-object v16, LX/3C1;->A00:LX/3Cb;

    .line 170
    .line 171
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v10

    .line 175
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 176
    .line 177
    if-ne v10, v9, :cond_7

    .line 178
    .line 179
    sget-object v10, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$2$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$2$1$1;

    .line 180
    .line 181
    invoke-interface {v6, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    :cond_7
    move-object/from16 v9, v16

    .line 185
    .line 186
    invoke-static {v9, v10, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 187
    .line 188
    .line 189
    move-result-object v21

    .line 190
    const/16 p4, 0x3ff0

    .line 191
    .line 192
    move-object/from16 v26, v25

    .line 193
    .line 194
    move-object/from16 v27, v25

    .line 195
    .line 196
    move/from16 v28, v4

    .line 197
    .line 198
    move/from16 v29, v4

    .line 199
    .line 200
    move/from16 v30, v4

    .line 201
    .line 202
    move/from16 v31, v4

    .line 203
    .line 204
    move-object/from16 v32, v25

    .line 205
    .line 206
    move-object/from16 v33, v25

    .line 207
    .line 208
    move-object/from16 p0, v25

    .line 209
    .line 210
    move-object/from16 p1, v6

    .line 211
    .line 212
    move/from16 p2, v4

    .line 213
    .line 214
    move/from16 p3, v4

    .line 215
    .line 216
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 217
    .line 218
    .line 219
    invoke-static {v4, v6, v4, v15}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 220
    .line 221
    .line 222
    move-result-object v9

    .line 223
    invoke-static {v9, v14}, LX/3J3;->A01(LX/3Lr;LX/3C1;)LX/3C1;

    .line 224
    .line 225
    .line 226
    move-result-object v14

    .line 227
    invoke-static {v6, v13, v4}, LX/007;->A0g(LX/2d4;FI)LX/3BI;

    .line 228
    .line 229
    .line 230
    move-result-object v13

    .line 231
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 232
    .line 233
    .line 234
    move-result v10

    .line 235
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 236
    .line 237
    .line 238
    move-result-object v9

    .line 239
    invoke-static {v6, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 240
    .line 241
    .line 242
    move-result-object v14

    .line 243
    invoke-static {v6, v2, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 244
    .line 245
    .line 246
    invoke-static {v6, v13, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 247
    .line 248
    .line 249
    invoke-static {v6, v9, v1}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 250
    .line 251
    .line 252
    move-object/from16 v1, v18

    .line 253
    .line 254
    invoke-static {v0, v1, v6, v10}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 255
    .line 256
    .line 257
    move-object/from16 v0, v17

    .line 258
    .line 259
    invoke-static {v6, v14, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 260
    .line 261
    .line 262
    const v0, 0x2cbd055e

    .line 263
    .line 264
    .line 265
    invoke-static {v6, v3, v0}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 266
    .line 267
    .line 268
    move-result-object v3

    .line 269
    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 270
    .line 271
    .line 272
    move-result v0

    .line 273
    if-eqz v0, :cond_9

    .line 274
    .line 275
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v1

    .line 279
    check-cast v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;

    .line 280
    .line 281
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 282
    .line 283
    invoke-static {v1, v6, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaAttachmentTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 284
    .line 285
    .line 286
    goto :goto_3

    .line 287
    :cond_8
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 288
    .line 289
    .line 290
    goto :goto_4

    .line 291
    :cond_9
    invoke-static {v2, v4, v15}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 292
    .line 293
    .line 294
    :goto_4
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 295
    .line 296
    .line 297
    move-result-object v2

    .line 298
    if-eqz v2, :cond_4

    .line 299
    .line 300
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$3;

    .line 301
    .line 302
    move/from16 v0, v19

    .line 303
    .line 304
    invoke-direct {v1, v8, v7, v5, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$AgentPermissionOutgoingMediaApproval$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaApproval;LX/3C1;II)V

    .line 305
    .line 306
    .line 307
    goto/16 :goto_2

    .line 308
    .line 309
    :cond_a
    and-int/lit8 v0, p3, 0x30

    .line 310
    .line 311
    if-nez v0, :cond_0

    .line 312
    .line 313
    invoke-static {v6, v7}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 314
    .line 315
    .line 316
    move-result v0

    .line 317
    or-int/2addr v3, v0

    .line 318
    goto/16 :goto_1

    .line 319
    .line 320
    :cond_b
    move v3, v5

    .line 321
    goto/16 :goto_0
.end method

.method public static final OutgoingMediaAttachmentTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 22

    .line 0
    const v0, -0x126954d5

    .line 1
    .line 2
    .line 3
    move-object/from16 v4, p1

    .line 4
    .line 5
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p2

    .line 9
    .line 10
    and-int/lit8 v0, p2, 0x6

    .line 11
    .line 12
    const/16 v16, 0x2

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {v3, v4, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v11

    .line 26
    or-int v11, v11, p2

    .line 27
    .line 28
    :goto_0
    invoke-static {v11}, LX/004;->A1R(I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {v0, v4, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 39
    .line 40
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaThumbnailSize:F

    .line 41
    .line 42
    invoke-static {v1, v0}, LX/2sI;->A08(LX/3C1;F)LX/3C1;

    .line 43
    .line 44
    .line 45
    move-result-object v6

    .line 46
    const/high16 v0, 0x40800000    # 4.0f

    .line 47
    .line 48
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sget-object v0, LX/2Id;->A02:LX/2sS;

    .line 53
    .line 54
    const/4 v5, 0x6

    .line 55
    invoke-static {v1, v4, v0, v5}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 56
    .line 57
    .line 58
    move-result-object v10

    .line 59
    move-object v1, v4

    .line 60
    check-cast v1, LX/J7I;

    .line 61
    .line 62
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 63
    .line 64
    .line 65
    move-result v9

    .line 66
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    invoke-static {v4, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 75
    .line 76
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 77
    .line 78
    if-nez v0, :cond_2

    .line 79
    .line 80
    invoke-static {}, LX/1VY;->A00()V

    .line 81
    .line 82
    .line 83
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    throw v0

    .line 88
    :cond_0
    move v11, v2

    .line 89
    goto :goto_0

    .line 90
    :cond_1
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 91
    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_2
    invoke-static {v4, v1, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 95
    .line 96
    .line 97
    invoke-static {v4, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 98
    .line 99
    .line 100
    sget v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 101
    .line 102
    and-int/lit8 v0, v11, 0xe

    .line 103
    .line 104
    or-int/2addr v6, v0

    .line 105
    invoke-static {v3, v4, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 106
    .line 107
    .line 108
    iget-object v0, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->caption:Ljava/lang/String;

    .line 109
    .line 110
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    if-eqz v6, :cond_4

    .line 115
    .line 116
    const v0, 0x60e1f2c8

    .line 117
    .line 118
    .line 119
    invoke-static {v4, v0}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-static {v4, v0}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 124
    .line 125
    .line 126
    move-result-object v10

    .line 127
    invoke-static {v4, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 128
    .line 129
    .line 130
    move-result-wide v8

    .line 131
    const/16 p2, 0x39f2

    .line 132
    .line 133
    const/4 v7, 0x0

    .line 134
    const/4 v14, 0x0

    .line 135
    const/high16 p0, 0x30000000

    .line 136
    .line 137
    move-object v11, v7

    .line 138
    move-object v12, v7

    .line 139
    move-object v13, v7

    .line 140
    move v15, v14

    .line 141
    move/from16 v17, v16

    .line 142
    .line 143
    move-object/from16 v18, v7

    .line 144
    .line 145
    move-object/from16 v19, v7

    .line 146
    .line 147
    move-object/from16 v20, v7

    .line 148
    .line 149
    move-object/from16 v21, v4

    .line 150
    .line 151
    move/from16 p1, v5

    .line 152
    .line 153
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 154
    .line 155
    .line 156
    :goto_1
    invoke-static {v1}, LX/003;->A0u(LX/J7I;)V

    .line 157
    .line 158
    .line 159
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    if-eqz v1, :cond_3

    .line 164
    .line 165
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaAttachmentTile$2;

    .line 166
    .line 167
    invoke-direct {v0, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaAttachmentTile$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;I)V

    .line 168
    .line 169
    .line 170
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 171
    .line 172
    :cond_3
    return-void

    .line 173
    :cond_4
    const v0, 0x60e538a1

    .line 174
    .line 175
    .line 176
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 177
    .line 178
    .line 179
    goto :goto_1
.end method

.method public static final OutgoingMediaLoadedPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;Ljava/lang/String;LX/2d4;I)V
    .locals 37

    .line 0
    const v0, -0x5fb849b2

    .line 1
    .line 2
    .line 3
    move-object/from16 v2, p2

    .line 4
    .line 5
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v5, p3

    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v9, p0

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-static {v9, v2, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int v10, p3, v0

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 27
    .line 28
    move-object/from16 p3, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    move-object/from16 v0, p3

    .line 33
    .line 34
    invoke-static {v2, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v10, v0

    .line 39
    :cond_0
    and-int/lit8 v3, v10, 0x13

    .line 40
    .line 41
    const/16 v0, 0x12

    .line 42
    .line 43
    const/4 v1, 0x0

    .line 44
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {v0, v2, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_2

    .line 53
    .line 54
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    sget v13, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaThumbnailSize:F

    .line 57
    .line 58
    invoke-static {v12, v13}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaShape:LX/2bC;

    .line 63
    .line 64
    invoke-static {v3, v0}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    invoke-static {v2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iget-wide v3, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 73
    .line 74
    const/16 v24, 0x0

    .line 75
    .line 76
    sget-object v19, LX/2oZ;->A00:LX/2bW;

    .line 77
    .line 78
    move-object/from16 v0, v19

    .line 79
    .line 80
    invoke-static {v6, v0, v3, v4}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    sget-object v11, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 85
    .line 86
    invoke-static {v11, v1}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    move-object v0, v2

    .line 91
    check-cast v0, LX/J7I;

    .line 92
    .line 93
    iget-wide v3, v0, LX/J7I;->A06:J

    .line 94
    .line 95
    invoke-static {v3, v4}, LX/001;->A0A(J)I

    .line 96
    .line 97
    .line 98
    move-result v14

    .line 99
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 100
    .line 101
    .line 102
    move-result-object v4

    .line 103
    invoke-static {v2, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    sget-object v18, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 108
    .line 109
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 110
    .line 111
    if-nez v7, :cond_3

    .line 112
    .line 113
    invoke-static {}, LX/1VY;->A00()V

    .line 114
    .line 115
    .line 116
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    throw v0

    .line 121
    :cond_1
    move v10, v5

    .line 122
    goto :goto_0

    .line 123
    :cond_2
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 124
    .line 125
    .line 126
    goto/16 :goto_2

    .line 127
    .line 128
    :cond_3
    move-object/from16 v7, v18

    .line 129
    .line 130
    invoke-static {v2, v0, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 131
    .line 132
    .line 133
    sget-object v8, LX/3Cl;->A04:LX/JDN;

    .line 134
    .line 135
    invoke-static {v2, v6, v8}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    invoke-static {v2, v4, v7, v14}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 140
    .line 141
    .line 142
    move-result-object v17

    .line 143
    sget-object v6, LX/3Cl;->A02:LX/JDM;

    .line 144
    .line 145
    invoke-static {v2, v3, v6}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 146
    .line 147
    .line 148
    move-result-object v16

    .line 149
    sget-object v21, LX/2sI;->A01:LX/2wD;

    .line 150
    .line 151
    sget-object v22, LX/32Y;->A00:LX/2vq;

    .line 152
    .line 153
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 154
    .line 155
    and-int/lit8 v4, v10, 0xe

    .line 156
    .line 157
    or-int/2addr v3, v4

    .line 158
    invoke-static {v9, v2, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->mediaContentDescription(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v23

    .line 162
    invoke-static {v13}, LX/1Ot;->A02(F)LX/1Ot;

    .line 163
    .line 164
    .line 165
    move-result-object v26

    .line 166
    shr-int/lit8 v3, v10, 0x3

    .line 167
    .line 168
    and-int/lit8 p0, v3, 0xe

    .line 169
    .line 170
    const v3, 0x61801b0

    .line 171
    .line 172
    .line 173
    or-int p0, p0, v3

    .line 174
    .line 175
    const/16 p2, 0x7eb0

    .line 176
    .line 177
    const-wide/16 v27, 0x0

    .line 178
    .line 179
    const/4 v15, 0x1

    .line 180
    const/4 v10, 0x6

    .line 181
    move/from16 v25, v1

    .line 182
    .line 183
    move/from16 v29, v15

    .line 184
    .line 185
    move/from16 v30, v1

    .line 186
    .line 187
    move/from16 v31, v1

    .line 188
    .line 189
    move-object/from16 v32, v24

    .line 190
    .line 191
    move-object/from16 v33, v24

    .line 192
    .line 193
    move-object/from16 v34, v24

    .line 194
    .line 195
    move-object/from16 v35, v24

    .line 196
    .line 197
    move-object/from16 v36, v2

    .line 198
    .line 199
    move/from16 p1, v1

    .line 200
    .line 201
    move-object/from16 v20, p3

    .line 202
    .line 203
    invoke-static/range {v20 .. v39}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage-XRP3Ue8(Ljava/lang/String;LX/3C1;LX/2vq;Ljava/lang/String;Lcom/facebook/common/callercontext/ContextChain;ZLX/1Ot;JZZZLX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;III)V

    .line 204
    .line 205
    .line 206
    iget-object v4, v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 207
    .line 208
    sget-object v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;->VIDEO:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 209
    .line 210
    if-ne v4, v3, :cond_5

    .line 211
    .line 212
    const v3, -0x98866db

    .line 213
    .line 214
    .line 215
    invoke-interface {v2, v3}, LX/2d4;->Agj(I)V

    .line 216
    .line 217
    .line 218
    const/high16 v3, 0x42300000    # 44.0f

    .line 219
    .line 220
    invoke-static {v12, v3}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 221
    .line 222
    .line 223
    move-result-object v4

    .line 224
    const/high16 v3, 0x41b00000    # 22.0f

    .line 225
    .line 226
    invoke-static {v4, v3}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 227
    .line 228
    .line 229
    move-result-object v14

    .line 230
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 231
    .line 232
    invoke-virtual {v12, v2, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 233
    .line 234
    .line 235
    move-result-object v3

    .line 236
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->surfaceOnMedia:J

    .line 237
    .line 238
    move-object/from16 v13, v19

    .line 239
    .line 240
    invoke-static {v14, v13, v3, v4}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 241
    .line 242
    .line 243
    move-result-object v3

    .line 244
    invoke-static {v11, v1}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 245
    .line 246
    .line 247
    move-result-object v14

    .line 248
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 249
    .line 250
    .line 251
    move-result v13

    .line 252
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 253
    .line 254
    .line 255
    move-result-object v11

    .line 256
    invoke-static {v2, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 257
    .line 258
    .line 259
    move-result-object v4

    .line 260
    move-object/from16 v3, v18

    .line 261
    .line 262
    invoke-static {v2, v0, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 263
    .line 264
    .line 265
    invoke-static {v2, v14, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 266
    .line 267
    .line 268
    invoke-static {v2, v11, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 269
    .line 270
    .line 271
    move-object/from16 v3, v17

    .line 272
    .line 273
    invoke-static {v6, v3, v2, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 274
    .line 275
    .line 276
    move-object/from16 v3, v16

    .line 277
    .line 278
    invoke-static {v2, v4, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 279
    .line 280
    .line 281
    const v3, 0x7f080244

    .line 282
    .line 283
    .line 284
    invoke-static {v2, v3, v1}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 285
    .line 286
    .line 287
    move-result-object v18

    .line 288
    invoke-virtual {v12, v2, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 289
    .line 290
    .line 291
    move-result-object v3

    .line 292
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->onMedia:J

    .line 293
    .line 294
    sget-object v19, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 295
    .line 296
    invoke-static {}, LX/2l9;->A04()I

    .line 297
    .line 298
    .line 299
    move-result v25

    .line 300
    const/16 v26, 0x21

    .line 301
    .line 302
    move-object/from16 v17, v24

    .line 303
    .line 304
    move-object/from16 v20, v24

    .line 305
    .line 306
    move-wide/from16 v21, v3

    .line 307
    .line 308
    move-object/from16 v23, v24

    .line 309
    .line 310
    move-object/from16 v24, v2

    .line 311
    .line 312
    invoke-static/range {v17 .. v26}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 313
    .line 314
    .line 315
    invoke-static {v0, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 316
    .line 317
    .line 318
    :goto_1
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 319
    .line 320
    .line 321
    invoke-static {v0, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 322
    .line 323
    .line 324
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    if-eqz v2, :cond_4

    .line 329
    .line 330
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaLoadedPreview$2;

    .line 331
    .line 332
    move-object/from16 v0, p3

    .line 333
    .line 334
    invoke-direct {v1, v9, v0, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaLoadedPreview$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;Ljava/lang/String;I)V

    .line 335
    .line 336
    .line 337
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 338
    .line 339
    :cond_4
    return-void

    .line 340
    :cond_5
    const v3, -0x9813b32

    .line 341
    .line 342
    .line 343
    invoke-interface {v2, v3}, LX/2d4;->Agj(I)V

    .line 344
    .line 345
    .line 346
    goto :goto_1
.end method

.method public static final OutgoingMediaPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 11

    .line 0
    const v0, 0x5e9d36ee

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v0, p2, 0x6

    .line 7
    .line 8
    const/4 v10, 0x3

    .line 9
    const/4 v9, 0x2

    .line 10
    const/4 v8, 0x1

    .line 11
    if-nez v0, :cond_2

    .line 12
    .line 13
    invoke-static {p0, p1, p2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v0}, LX/003;->A06(I)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    or-int/2addr v3, p2

    .line 22
    :goto_0
    and-int/lit8 v0, v3, 0x3

    .line 23
    .line 24
    const/4 v7, 0x0

    .line 25
    invoke-static {v0, v9}, LX/003;->A1H(II)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0, p1, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    invoke-static {p1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->media:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaDescriptor;

    .line 40
    .line 41
    const/4 v5, 0x0

    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaDescriptor;->url:Ljava/lang/String;

    .line 45
    .line 46
    :goto_1
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 51
    .line 52
    invoke-static {p1, v0}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    invoke-static {p1, v4, v6, v0}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    if-nez v0, :cond_0

    .line 65
    .line 66
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 67
    .line 68
    if-ne v2, v0, :cond_7

    .line 69
    .line 70
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eq v1, v7, :cond_5

    .line 77
    .line 78
    if-eq v1, v8, :cond_3

    .line 79
    .line 80
    if-eq v1, v9, :cond_6

    .line 81
    .line 82
    if-eq v1, v10, :cond_6

    .line 83
    .line 84
    const/4 v0, 0x4

    .line 85
    if-eq v1, v0, :cond_6

    .line 86
    .line 87
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    throw v0

    .line 92
    :cond_1
    move-object v0, v5

    .line 93
    goto :goto_1

    .line 94
    :cond_2
    move v3, p2

    .line 95
    goto :goto_0

    .line 96
    :cond_3
    sget-object v1, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 97
    .line 98
    sget-object v0, Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;->LARGE:Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;

    .line 99
    .line 100
    invoke-virtual {v1, v4, v6, v0}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveThumbnailUrl(Ljava/lang/String;LX/AHE;Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    goto :goto_2

    .line 105
    :cond_4
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 106
    .line 107
    .line 108
    goto :goto_4

    .line 109
    :cond_5
    sget-object v0, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 110
    .line 111
    invoke-virtual {v0, v4, v6}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveRawAssetUrl(Ljava/lang/String;LX/AHE;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v5

    .line 115
    :cond_6
    :goto_2
    invoke-interface {p1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    move-object v2, v5

    .line 119
    :cond_7
    check-cast v2, Ljava/lang/String;

    .line 120
    .line 121
    if-eqz v2, :cond_9

    .line 122
    .line 123
    const v0, 0x594636da

    .line 124
    .line 125
    .line 126
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 127
    .line 128
    .line 129
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 130
    .line 131
    and-int/lit8 v0, v3, 0xe

    .line 132
    .line 133
    or-int/2addr v1, v0

    .line 134
    invoke-static {p0, v2, p1, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaLoadedPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;Ljava/lang/String;LX/2d4;I)V

    .line 135
    .line 136
    .line 137
    :goto_3
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    :goto_4
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    if-eqz v1, :cond_8

    .line 145
    .line 146
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaPreview$1;

    .line 147
    .line 148
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaPreview$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;I)V

    .line 149
    .line 150
    .line 151
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 152
    .line 153
    :cond_8
    return-void

    .line 154
    :cond_9
    const v0, 0x5947a602

    .line 155
    .line 156
    .line 157
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 158
    .line 159
    .line 160
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 161
    .line 162
    and-int/lit8 v0, v3, 0xe

    .line 163
    .line 164
    or-int/2addr v1, v0

    .line 165
    invoke-static {p0, p1, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaSquareIconTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 166
    .line 167
    .line 168
    goto :goto_3
.end method

.method public static final OutgoingMediaSquareIconTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 35

    .line 0
    const v1, -0x781a3c02

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v15, p2

    .line 9
    .line 10
    and-int/lit8 v1, p2, 0x6

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    move-object/from16 p2, p0

    .line 14
    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    move-object/from16 v1, p2

    .line 18
    .line 19
    invoke-static {v1, v0, v15}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-static {v1}, LX/003;->A06(I)I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    or-int/2addr v5, v15

    .line 28
    :goto_0
    and-int/lit8 v1, v5, 0x3

    .line 29
    .line 30
    const/16 v17, 0x0

    .line 31
    .line 32
    invoke-static {v1, v2}, LX/003;->A1H(II)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-static {v1, v0, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 43
    .line 44
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaThumbnailSize:F

    .line 45
    .line 46
    invoke-static {v4, v1}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    sget-object v8, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaShape:LX/2bC;

    .line 51
    .line 52
    invoke-static {v1, v8}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 57
    .line 58
    const/16 v16, 0x6

    .line 59
    .line 60
    invoke-static {v0, v3}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 61
    .line 62
    .line 63
    move-result-wide v1

    .line 64
    const/16 v19, 0x0

    .line 65
    .line 66
    invoke-static {v6, v1, v2}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    const/high16 v6, 0x3f800000    # 1.0f

    .line 71
    .line 72
    move/from16 v1, v16

    .line 73
    .line 74
    invoke-virtual {v3, v0, v1}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->border:J

    .line 79
    .line 80
    invoke-static {v7, v8, v6, v1, v2}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    const/high16 v1, 0x41400000    # 12.0f

    .line 85
    .line 86
    invoke-static {v2, v1}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 91
    .line 92
    .line 93
    move-result-object v9

    .line 94
    move-object v1, v0

    .line 95
    check-cast v1, LX/J7I;

    .line 96
    .line 97
    iget-wide v6, v1, LX/J7I;->A06:J

    .line 98
    .line 99
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 100
    .line 101
    .line 102
    move-result v8

    .line 103
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 104
    .line 105
    .line 106
    move-result-object v7

    .line 107
    invoke-static {v0, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 108
    .line 109
    .line 110
    move-result-object v6

    .line 111
    sget-object v14, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 112
    .line 113
    iget-object v2, v1, LX/J7I;->A0V:LX/3DJ;

    .line 114
    .line 115
    if-nez v2, :cond_2

    .line 116
    .line 117
    invoke-static {}, LX/1VY;->A00()V

    .line 118
    .line 119
    .line 120
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    throw v0

    .line 125
    :cond_0
    move v5, v15

    .line 126
    goto :goto_0

    .line 127
    :cond_1
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 128
    .line 129
    .line 130
    goto/16 :goto_1

    .line 131
    .line 132
    :cond_2
    invoke-static {v0, v1, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 133
    .line 134
    .line 135
    sget-object v13, LX/3Cl;->A04:LX/JDN;

    .line 136
    .line 137
    invoke-static {v0, v9, v13}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 138
    .line 139
    .line 140
    move-result-object v12

    .line 141
    invoke-static {v0, v7, v12, v8}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 142
    .line 143
    .line 144
    move-result-object v11

    .line 145
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 146
    .line 147
    invoke-static {v0, v6, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 148
    .line 149
    .line 150
    move-result-object v9

    .line 151
    sget-object v2, LX/2Id;->A00:LX/2sS;

    .line 152
    .line 153
    invoke-static {v0, v2}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 154
    .line 155
    .line 156
    move-result-object v8

    .line 157
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 158
    .line 159
    .line 160
    move-result v7

    .line 161
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 162
    .line 163
    .line 164
    move-result-object v6

    .line 165
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    invoke-static {v0, v1, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 170
    .line 171
    .line 172
    invoke-static {v0, v8, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v0, v6, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 176
    .line 177
    .line 178
    invoke-static {v10, v11, v0, v7}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 179
    .line 180
    .line 181
    invoke-static {v0, v2, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 182
    .line 183
    .line 184
    move-object/from16 v2, p2

    .line 185
    .line 186
    iget-object v2, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 187
    .line 188
    invoke-static {v2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->iconResFor(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;)I

    .line 189
    .line 190
    .line 191
    move-result v6

    .line 192
    move/from16 v2, v17

    .line 193
    .line 194
    invoke-static {v0, v6, v2}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 195
    .line 196
    .line 197
    move-result-object v20

    .line 198
    invoke-static {v0, v3}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 199
    .line 200
    .line 201
    move-result-wide v23

    .line 202
    sget-object v21, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 203
    .line 204
    invoke-static {}, LX/2l9;->A04()I

    .line 205
    .line 206
    .line 207
    move-result v27

    .line 208
    const/16 v28, 0x21

    .line 209
    .line 210
    move-object/from16 v22, v19

    .line 211
    .line 212
    move-object/from16 v25, v19

    .line 213
    .line 214
    move-object/from16 v26, v0

    .line 215
    .line 216
    invoke-static/range {v19 .. v28}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 217
    .line 218
    .line 219
    invoke-static {v0, v4}, LX/1Vt;->A02(LX/2d4;LX/3C1;)V

    .line 220
    .line 221
    .line 222
    sget v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 223
    .line 224
    and-int/lit8 v2, v5, 0xe

    .line 225
    .line 226
    or-int/2addr v4, v2

    .line 227
    move-object/from16 v2, p2

    .line 228
    .line 229
    invoke-static {v2, v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->attachmentTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v18

    .line 233
    invoke-static {v0, v3}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 234
    .line 235
    .line 236
    move-result-object v22

    .line 237
    invoke-static {v0, v3}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 238
    .line 239
    .line 240
    move-result-wide v20

    .line 241
    const/4 v2, 0x3

    .line 242
    const/16 v29, 0x5

    .line 243
    .line 244
    invoke-static {v2}, LX/2wS;->A01(I)LX/2wS;

    .line 245
    .line 246
    .line 247
    move-result-object v25

    .line 248
    const/16 p1, 0x39b2

    .line 249
    .line 250
    const/4 v2, 0x1

    .line 251
    const/high16 v34, 0x30000000

    .line 252
    .line 253
    move-object/from16 v23, v19

    .line 254
    .line 255
    move-object/from16 v24, v19

    .line 256
    .line 257
    move/from16 v26, v17

    .line 258
    .line 259
    move/from16 v27, v17

    .line 260
    .line 261
    move/from16 v28, v2

    .line 262
    .line 263
    move-object/from16 v30, v19

    .line 264
    .line 265
    move-object/from16 v31, v19

    .line 266
    .line 267
    move-object/from16 v32, v19

    .line 268
    .line 269
    move-object/from16 v33, v0

    .line 270
    .line 271
    move/from16 p0, v16

    .line 272
    .line 273
    invoke-static/range {v18 .. v36}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 274
    .line 275
    .line 276
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 277
    .line 278
    .line 279
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 280
    .line 281
    .line 282
    :goto_1
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 283
    .line 284
    .line 285
    move-result-object v2

    .line 286
    if-eqz v2, :cond_3

    .line 287
    .line 288
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaSquareIconTile$2;

    .line 289
    .line 290
    move-object/from16 v0, p2

    .line 291
    .line 292
    invoke-direct {v1, v0, v15}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt$OutgoingMediaSquareIconTile$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;I)V

    .line 293
    .line 294
    .line 295
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 296
    .line 297
    :cond_3
    return-void
.end method

.method public static final synthetic access$OutgoingMediaAttachmentTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaAttachmentTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$OutgoingMediaLoadedPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;Ljava/lang/String;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaLoadedPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;Ljava/lang/String;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$OutgoingMediaPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$OutgoingMediaSquareIconTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->OutgoingMediaSquareIconTile(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final attachmentTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)Ljava/lang/String;
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->fileName:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    if-nez v1, :cond_4

    .line 7
    .line 8
    const v0, 0x4c41e943    # 5.0832652E7f

    .line 9
    .line 10
    .line 11
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, 0x0

    .line 21
    if-eq v1, v0, :cond_3

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    if-eq v1, v0, :cond_2

    .line 25
    .line 26
    const/4 v0, 0x2

    .line 27
    if-eq v1, v0, :cond_1

    .line 28
    .line 29
    const/4 v0, 0x3

    .line 30
    if-eq v1, v0, :cond_0

    .line 31
    .line 32
    const/4 v0, 0x4

    .line 33
    if-ne v1, v0, :cond_5

    .line 34
    .line 35
    const v0, -0x26d452d1

    .line 36
    .line 37
    .line 38
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 39
    .line 40
    .line 41
    const v0, 0x7f120165

    .line 42
    .line 43
    .line 44
    :goto_0
    invoke-static {p1, v0}, LX/3Rs;->A0K(LX/2d4;I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    :goto_1
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    return-object v1

    .line 52
    :cond_0
    const v0, -0x26d4628f

    .line 53
    .line 54
    .line 55
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 56
    .line 57
    .line 58
    const v0, 0x7f120168

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_1
    const v0, -0x26d47154

    .line 63
    .line 64
    .line 65
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 66
    .line 67
    .line 68
    const v0, 0x7f120164

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_2
    const v0, -0x26d48014

    .line 73
    .line 74
    .line 75
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 76
    .line 77
    .line 78
    const v0, 0x7f120167

    .line 79
    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_3
    const v0, -0x26d48ed4

    .line 83
    .line 84
    .line 85
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 86
    .line 87
    .line 88
    const v0, 0x7f120166

    .line 89
    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_4
    const v0, -0x26d49a96

    .line 93
    .line 94
    .line 95
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_5
    const v0, -0x26d49561

    .line 100
    .line 101
    .line 102
    invoke-static {p1, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    throw v0
.end method

.method public static final iconResFor(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaKind;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_4

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_3

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_2

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-eq p0, v0, :cond_1

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-ne p0, v0, :cond_0

    .line 18
    .line 19
    const v0, 0x7f080282

    .line 20
    .line 21
    .line 22
    return v0

    .line 23
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    throw v0

    .line 28
    :cond_1
    const v0, 0x7f08026d

    .line 29
    .line 30
    .line 31
    return v0

    .line 32
    :cond_2
    const v0, 0x7f08027a

    .line 33
    .line 34
    .line 35
    return v0

    .line 36
    :cond_3
    const v0, 0x7f0800d9

    .line 37
    .line 38
    .line 39
    return v0

    .line 40
    :cond_4
    const v0, 0x7f08021a

    .line 41
    .line 42
    .line 43
    return v0
.end method

.method public static final mediaContentDescription(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)Ljava/lang/String;
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->caption:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    if-nez v1, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->fileName:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    if-nez v1, :cond_0

    .line 15
    .line 16
    const v0, 0x61d030d1

    .line 17
    .line 18
    .line 19
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 20
    .line 21
    .line 22
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;->$stable:I

    .line 23
    .line 24
    and-int/lit8 v0, p2, 0xe

    .line 25
    .line 26
    or-int/2addr v0, v1

    .line 27
    invoke-static {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionOutgoingMediaApprovalKt;->attachmentTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$OutgoingMediaItem;LX/2d4;I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    :goto_0
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :cond_0
    const v0, 0x61d02876

    .line 36
    .line 37
    .line 38
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 39
    .line 40
    .line 41
    goto :goto_0
.end method

.method public static final trimmedNonEmpty(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    invoke-static {p0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-lez v0, :cond_0

    .line 14
    .line 15
    return-object v1

    .line 16
    :cond_0
    return-object v2
.end method
