.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approvals:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->$approvals:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->invoke(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v4, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    invoke-static {p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->bulkActionComponent(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 10
    .line 11
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->$approvals:Ljava/util/List;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v5, 0x1

    .line 15
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 16
    .line 17
    .line 18
    move-result-object v6

    .line 19
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;->$approvals:Ljava/util/List;

    .line 25
    .line 26
    invoke-virtual {v1, v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->submitBulkDecision(Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
