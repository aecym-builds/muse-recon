.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final AgentPermissionCardShape:LX/2bC;

.field public static final CardHorizontalPadding:F = 18.0f

.field public static final SEE_DETAILS_URL_ANNOTATION:Ljava/lang/String; = "aura://agent-permission/see-details"

.field public static final SingleApprovalContentSpacing:F = 16.0f


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    const/high16 v0, 0x41e00000    # 28.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionCardShape:LX/2bC;

    .line 7
    .line 8
    return-void
.end method

.method public static final AgentPermissionApprovalCard-FJfuzF0(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            "Z",
            "LX/3C1;",
            "F",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v16, p3

    .line 1
    .line 2
    move/from16 v6, p4

    .line 3
    .line 4
    const v0, -0x598d27c    # -3.0008594E35f

    .line 5
    .line 6
    .line 7
    move-object/from16 v10, p5

    .line 8
    .line 9
    invoke-interface {v10, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v5, p6

    .line 13
    .line 14
    and-int/lit8 v0, p6, 0x6

    .line 15
    .line 16
    move-object/from16 v9, p0

    .line 17
    .line 18
    if-nez v0, :cond_b

    .line 19
    .line 20
    invoke-static {v9, v10, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    or-int v3, v3, p6

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 31
    .line 32
    move-object/from16 v8, p1

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {v8, v10, v5}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-static {v0}, LX/003;->A07(I)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    or-int/2addr v3, v0

    .line 45
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 46
    .line 47
    move/from16 v7, p2

    .line 48
    .line 49
    if-nez v0, :cond_1

    .line 50
    .line 51
    invoke-static {v10, v7}, LX/004;->A0k(LX/2d4;Z)I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    or-int/2addr v3, v0

    .line 56
    :cond_1
    move/from16 v4, p7

    .line 57
    .line 58
    and-int/lit8 v2, p7, 0x8

    .line 59
    .line 60
    if-eqz v2, :cond_a

    .line 61
    .line 62
    or-int/lit16 v3, v3, 0xc00

    .line 63
    .line 64
    :cond_2
    :goto_1
    and-int/lit16 v0, v5, 0x6000

    .line 65
    .line 66
    if-nez v0, :cond_5

    .line 67
    .line 68
    and-int/lit8 v0, p7, 0x10

    .line 69
    .line 70
    if-nez v0, :cond_3

    .line 71
    .line 72
    invoke-interface {v10, v6}, LX/2d4;->A66(F)Z

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    const/16 v0, 0x4000

    .line 77
    .line 78
    if-nez v1, :cond_4

    .line 79
    .line 80
    :cond_3
    const/16 v0, 0x2000

    .line 81
    .line 82
    :cond_4
    or-int/2addr v3, v0

    .line 83
    :cond_5
    and-int/lit16 v1, v3, 0x2493

    .line 84
    .line 85
    const/16 v0, 0x2492

    .line 86
    .line 87
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    invoke-static {v0, v10, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_e

    .line 96
    .line 97
    invoke-interface {v10}, LX/2d4;->AgT()V

    .line 98
    .line 99
    .line 100
    and-int/lit8 v0, p6, 0x1

    .line 101
    .line 102
    const v1, -0xe001

    .line 103
    .line 104
    .line 105
    if-eqz v0, :cond_8

    .line 106
    .line 107
    invoke-interface {v10}, LX/2d4;->AEs()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-nez v0, :cond_8

    .line 112
    .line 113
    invoke-static {v4, v10, v3}, LX/004;->A06(ILX/2d4;I)I

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    :cond_6
    :goto_2
    invoke-interface {v10}, LX/2d4;->AAf()V

    .line 118
    .line 119
    .line 120
    invoke-static {v9}, LX/B89;->A0Y(Ljava/util/List;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 125
    .line 126
    if-eqz v2, :cond_7

    .line 127
    .line 128
    sget-object v11, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 129
    .line 130
    :goto_3
    invoke-static/range {v16 .. v16}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    shl-int/lit8 v0, v3, 0x3

    .line 135
    .line 136
    and-int/lit8 v0, v0, 0x70

    .line 137
    .line 138
    invoke-static {v1, v9, v11, v10, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;

    .line 139
    .line 140
    .line 141
    move-result-object v11

    .line 142
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 143
    .line 144
    const/4 v0, 0x0

    .line 145
    invoke-static {v11, v1, v0, v1, v6}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    const/high16 p2, 0x41000000    # 8.0f

    .line 150
    .line 151
    sget-object v11, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionCardShape:LX/2bC;

    .line 152
    .line 153
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 154
    .line 155
    const/4 v0, 0x6

    .line 156
    invoke-virtual {v1, v10, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 157
    .line 158
    .line 159
    move-result-object v12

    .line 160
    iget-wide v12, v12, Lcom/facebook/aura/vds/compose/theme/AuraColors;->shadow:J

    .line 161
    .line 162
    const/16 p3, 0xc

    .line 163
    .line 164
    const-wide/16 p4, 0x0

    .line 165
    .line 166
    move-object/from16 p1, v11

    .line 167
    .line 168
    move-wide/from16 p6, v12

    .line 169
    .line 170
    invoke-static/range {p0 .. p7}, LX/1ps;->A00(LX/3C1;LX/2bW;FIJJ)LX/3C1;

    .line 171
    .line 172
    .line 173
    move-result-object v12

    .line 174
    invoke-virtual {v1, v10, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->card:J

    .line 179
    .line 180
    invoke-static {v12, v11, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    invoke-static {v10}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 185
    .line 186
    .line 187
    move-result-object v15

    .line 188
    move-object v11, v10

    .line 189
    check-cast v11, LX/J7I;

    .line 190
    .line 191
    invoke-static {v11}, LX/003;->A0F(LX/J7I;)I

    .line 192
    .line 193
    .line 194
    move-result v14

    .line 195
    invoke-static {v11}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 196
    .line 197
    .line 198
    move-result-object v13

    .line 199
    invoke-static {v10, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 200
    .line 201
    .line 202
    move-result-object v12

    .line 203
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 204
    .line 205
    iget-object v0, v11, LX/J7I;->A0V:LX/3DJ;

    .line 206
    .line 207
    if-nez v0, :cond_c

    .line 208
    .line 209
    invoke-static {}, LX/1VY;->A00()V

    .line 210
    .line 211
    .line 212
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    throw v0

    .line 217
    :cond_7
    sget-object v11, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 218
    .line 219
    goto :goto_3

    .line 220
    :cond_8
    if-eqz v2, :cond_9

    .line 221
    .line 222
    sget-object v16, LX/3C1;->A00:LX/3Cb;

    .line 223
    .line 224
    :cond_9
    and-int/lit8 v0, p7, 0x10

    .line 225
    .line 226
    if-eqz v0, :cond_6

    .line 227
    .line 228
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 229
    .line 230
    and-int/2addr v3, v1

    .line 231
    goto :goto_2

    .line 232
    :cond_a
    and-int/lit16 v0, v5, 0xc00

    .line 233
    .line 234
    if-nez v0, :cond_2

    .line 235
    .line 236
    move-object/from16 v0, v16

    .line 237
    .line 238
    invoke-static {v10, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 239
    .line 240
    .line 241
    move-result v0

    .line 242
    or-int/2addr v3, v0

    .line 243
    goto/16 :goto_1

    .line 244
    .line 245
    :cond_b
    move v3, v5

    .line 246
    goto/16 :goto_0

    .line 247
    .line 248
    :cond_c
    invoke-static {v10, v11, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 249
    .line 250
    .line 251
    invoke-static {v10, v15, v13, v12, v14}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 252
    .line 253
    .line 254
    if-eqz v2, :cond_d

    .line 255
    .line 256
    const v0, -0x5f1432c9

    .line 257
    .line 258
    .line 259
    invoke-interface {v10, v0}, LX/2d4;->Agj(I)V

    .line 260
    .line 261
    .line 262
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 263
    .line 264
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->$stable:I

    .line 265
    .line 266
    shl-int/lit8 v0, v0, 0x3

    .line 267
    .line 268
    invoke-static {v1, v0, v3}, LX/3Rq;->A00(III)I

    .line 269
    .line 270
    .line 271
    move-result v1

    .line 272
    and-int/lit16 v0, v3, 0x380

    .line 273
    .line 274
    or-int/2addr v0, v1

    .line 275
    invoke-static {v2, v8, v7, v10, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContent(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V

    .line 276
    .line 277
    .line 278
    :goto_4
    invoke-static {v11}, LX/003;->A0u(LX/J7I;)V

    .line 279
    .line 280
    .line 281
    goto :goto_5

    .line 282
    :cond_d
    const v0, -0x5f11bbc4

    .line 283
    .line 284
    .line 285
    invoke-interface {v10, v0}, LX/2d4;->Agj(I)V

    .line 286
    .line 287
    .line 288
    and-int/lit8 v1, v3, 0xe

    .line 289
    .line 290
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->$stable:I

    .line 291
    .line 292
    shl-int/lit8 v0, v0, 0x3

    .line 293
    .line 294
    or-int/2addr v1, v0

    .line 295
    invoke-static {v3, v1}, LX/002;->A0B(II)I

    .line 296
    .line 297
    .line 298
    move-result v0

    .line 299
    invoke-static {v9, v8, v7, v10, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->MultiApprovalContent(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V

    .line 300
    .line 301
    .line 302
    goto :goto_4

    .line 303
    :cond_e
    invoke-interface {v10}, LX/2d4;->AgJ()V

    .line 304
    .line 305
    .line 306
    :goto_5
    invoke-interface {v10}, LX/2d4;->AAg()LX/J7V;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    if-eqz v0, :cond_f

    .line 311
    .line 312
    new-instance v12, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalCard$2;

    .line 313
    .line 314
    move/from16 p2, v4

    .line 315
    .line 316
    move/from16 p1, v5

    .line 317
    .line 318
    move/from16 p0, v6

    .line 319
    .line 320
    move v15, v7

    .line 321
    move-object v13, v9

    .line 322
    move-object v14, v8

    .line 323
    invoke-direct/range {v12 .. v19}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalCard$2;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FII)V

    .line 324
    .line 325
    .line 326
    iput-object v12, v0, LX/J7V;->A06:LX/JDN;

    .line 327
    .line 328
    :cond_f
    return-void
.end method

.method public static final AgentPermissionApprovalContent-7UH0Qls(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZLX/2d4;II)V
    .locals 35
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "FZ",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "F",
            "LX/2or;",
            "Z",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v28, p5

    .line 1
    .line 2
    move/from16 v27, p6

    .line 3
    .line 4
    move-object/from16 v26, p7

    .line 5
    .line 6
    move/from16 v22, p8

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    move-object/from16 v5, p0

    .line 10
    .line 11
    move-object/from16 p8, p1

    .line 12
    .line 13
    move-object/from16 v0, p8

    .line 14
    .line 15
    invoke-static {v5, v0}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v24

    .line 19
    const/16 v23, 0x4

    .line 20
    .line 21
    move-object/from16 p5, p4

    .line 22
    .line 23
    move-object/from16 v1, p5

    .line 24
    .line 25
    move/from16 v0, v23

    .line 26
    .line 27
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 28
    .line 29
    .line 30
    const v0, 0x7e96b65c

    .line 31
    .line 32
    .line 33
    move-object/from16 v4, p9

    .line 34
    .line 35
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 36
    .line 37
    .line 38
    move/from16 v3, p10

    .line 39
    .line 40
    and-int/lit8 v0, p10, 0x6

    .line 41
    .line 42
    if-nez v0, :cond_f

    .line 43
    .line 44
    invoke-static {v5, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {v0}, LX/003;->A06(I)I

    .line 49
    .line 50
    .line 51
    move-result v12

    .line 52
    or-int v12, v12, p10

    .line 53
    .line 54
    :goto_0
    and-int/lit8 v0, p10, 0x30

    .line 55
    .line 56
    if-nez v0, :cond_0

    .line 57
    .line 58
    move-object/from16 v0, p8

    .line 59
    .line 60
    invoke-static {v4, v0}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    or-int/2addr v12, v0

    .line 65
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 66
    .line 67
    move/from16 p7, p2

    .line 68
    .line 69
    if-nez v0, :cond_1

    .line 70
    .line 71
    move/from16 v0, p7

    .line 72
    .line 73
    invoke-static {v4, v0}, LX/004;->A0B(LX/2d4;F)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    or-int/2addr v12, v0

    .line 78
    :cond_1
    and-int/lit16 v0, v3, 0xc00

    .line 79
    .line 80
    move/from16 p6, p3

    .line 81
    .line 82
    if-nez v0, :cond_2

    .line 83
    .line 84
    move/from16 v0, p6

    .line 85
    .line 86
    invoke-static {v4, v0}, LX/004;->A0l(LX/2d4;Z)I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    or-int/2addr v12, v0

    .line 91
    :cond_2
    and-int/lit16 v0, v3, 0x6000

    .line 92
    .line 93
    if-nez v0, :cond_3

    .line 94
    .line 95
    invoke-static {v4, v1}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    or-int/2addr v12, v0

    .line 100
    :cond_3
    move/from16 v25, p11

    .line 101
    .line 102
    and-int/lit8 v8, p11, 0x20

    .line 103
    .line 104
    const/high16 v0, 0x30000

    .line 105
    .line 106
    if-nez v8, :cond_4

    .line 107
    .line 108
    and-int v0, v0, p10

    .line 109
    .line 110
    if-nez v0, :cond_5

    .line 111
    .line 112
    move-object/from16 v0, v28

    .line 113
    .line 114
    invoke-static {v4, v0}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    :cond_4
    or-int/2addr v12, v0

    .line 119
    :cond_5
    and-int/lit8 v6, p11, 0x40

    .line 120
    .line 121
    const/high16 v0, 0x180000

    .line 122
    .line 123
    if-nez v6, :cond_6

    .line 124
    .line 125
    and-int v0, v0, p10

    .line 126
    .line 127
    if-nez v0, :cond_7

    .line 128
    .line 129
    move/from16 v0, v27

    .line 130
    .line 131
    invoke-interface {v4, v0}, LX/2d4;->A66(F)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    invoke-static {v0}, LX/003;->A03(I)I

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    :cond_6
    or-int/2addr v12, v0

    .line 140
    :cond_7
    move/from16 v0, v25

    .line 141
    .line 142
    and-int/lit16 v1, v0, 0x80

    .line 143
    .line 144
    const/high16 v0, 0xc00000

    .line 145
    .line 146
    if-nez v1, :cond_8

    .line 147
    .line 148
    and-int v0, p10, v0

    .line 149
    .line 150
    if-nez v0, :cond_9

    .line 151
    .line 152
    move-object/from16 v0, v26

    .line 153
    .line 154
    invoke-static {v4, v0}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    :cond_8
    or-int/2addr v12, v0

    .line 159
    :cond_9
    move/from16 v0, v25

    .line 160
    .line 161
    and-int/lit16 v7, v0, 0x100

    .line 162
    .line 163
    const/high16 v0, 0x6000000

    .line 164
    .line 165
    if-nez v7, :cond_a

    .line 166
    .line 167
    and-int v0, p10, v0

    .line 168
    .line 169
    if-nez v0, :cond_b

    .line 170
    .line 171
    move/from16 v0, v22

    .line 172
    .line 173
    invoke-static {v4, v0}, LX/004;->A0q(LX/2d4;Z)I

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    :cond_a
    or-int/2addr v12, v0

    .line 178
    :cond_b
    invoke-static {v12}, LX/009;->A1K(I)Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    invoke-static {v0, v4, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    if-eqz v0, :cond_10

    .line 187
    .line 188
    if-eqz v8, :cond_c

    .line 189
    .line 190
    sget-object v28, LX/3C1;->A00:LX/3Cb;

    .line 191
    .line 192
    :cond_c
    if-eqz v6, :cond_d

    .line 193
    .line 194
    const/high16 v27, 0x41000000    # 8.0f

    .line 195
    .line 196
    :cond_d
    if-eqz v1, :cond_e

    .line 197
    .line 198
    const/high16 v6, 0x41000000    # 8.0f

    .line 199
    .line 200
    const/high16 v1, 0x41200000    # 10.0f

    .line 201
    .line 202
    new-instance v26, LX/1XE;

    .line 203
    .line 204
    move-object/from16 v0, v26

    .line 205
    .line 206
    invoke-direct {v0, v6, v1, v6, v1}, LX/1XE;-><init>(FFFF)V

    .line 207
    .line 208
    .line 209
    :cond_e
    move/from16 v0, v22

    .line 210
    .line 211
    invoke-static {v7, v0}, LX/001;->A1P(IZ)Z

    .line 212
    .line 213
    .line 214
    move-result v22

    .line 215
    invoke-static/range {v28 .. v28}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 216
    .line 217
    .line 218
    move-result-object v10

    .line 219
    sget v21, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContentSpacing:F

    .line 220
    .line 221
    invoke-static/range {v21 .. v21}, LX/Dn6;->A00(F)LX/CP5;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    sget-object v14, LX/2Id;->A02:LX/2sS;

    .line 226
    .line 227
    const/4 v13, 0x6

    .line 228
    invoke-static {v0, v4, v14, v13}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 229
    .line 230
    .line 231
    move-result-object v8

    .line 232
    move-object v1, v4

    .line 233
    check-cast v1, LX/J7I;

    .line 234
    .line 235
    iget-wide v6, v1, LX/J7I;->A06:J

    .line 236
    .line 237
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 238
    .line 239
    .line 240
    move-result v9

    .line 241
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 242
    .line 243
    .line 244
    move-result-object v7

    .line 245
    invoke-static {v4, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    sget-object v20, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 250
    .line 251
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 252
    .line 253
    if-nez v0, :cond_11

    .line 254
    .line 255
    invoke-static {}, LX/1VY;->A00()V

    .line 256
    .line 257
    .line 258
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    throw v0

    .line 263
    :cond_f
    move v12, v3

    .line 264
    goto/16 :goto_0

    .line 265
    .line 266
    :cond_10
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 267
    .line 268
    .line 269
    goto/16 :goto_4

    .line 270
    .line 271
    :cond_11
    move-object/from16 v0, v20

    .line 272
    .line 273
    invoke-static {v4, v1, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 274
    .line 275
    .line 276
    sget-object v11, LX/3Cl;->A04:LX/JDN;

    .line 277
    .line 278
    invoke-static {v4, v8, v11}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 279
    .line 280
    .line 281
    move-result-object v10

    .line 282
    invoke-static {v4, v7, v10, v9}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 283
    .line 284
    .line 285
    move-result-object v19

    .line 286
    sget-object v9, LX/3Cl;->A02:LX/JDM;

    .line 287
    .line 288
    invoke-static {v4, v6, v9}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 289
    .line 290
    .line 291
    move-result-object v18

    .line 292
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 293
    .line 294
    const/4 v7, 0x0

    .line 295
    move/from16 v0, p7

    .line 296
    .line 297
    invoke-static {v8, v0, v7}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 298
    .line 299
    .line 300
    move-result-object v32

    .line 301
    sget v34, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 302
    .line 303
    and-int/lit8 v17, v12, 0xe

    .line 304
    .line 305
    or-int v34, v34, v17

    .line 306
    .line 307
    and-int/lit8 v15, v12, 0x70

    .line 308
    .line 309
    or-int v34, v34, v15

    .line 310
    .line 311
    shr-int/lit8 v6, v12, 0x3

    .line 312
    .line 313
    and-int/lit16 v0, v6, 0x380

    .line 314
    .line 315
    or-int v34, v34, v0

    .line 316
    .line 317
    move-object/from16 v29, v5

    .line 318
    .line 319
    move-object/from16 v30, p8

    .line 320
    .line 321
    move/from16 v31, p6

    .line 322
    .line 323
    move-object/from16 v33, v4

    .line 324
    .line 325
    move/from16 p0, v2

    .line 326
    .line 327
    invoke-static/range {v29 .. v35}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V

    .line 328
    .line 329
    .line 330
    invoke-static {v4, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PermissionCardDivider(LX/2d4;I)V

    .line 331
    .line 332
    .line 333
    const/16 v16, 0x0

    .line 334
    .line 335
    move/from16 v0, p7

    .line 336
    .line 337
    invoke-static {v8, v0, v7}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 338
    .line 339
    .line 340
    move-result-object v7

    .line 341
    invoke-static/range {v21 .. v21}, LX/Dn6;->A00(F)LX/CP5;

    .line 342
    .line 343
    .line 344
    move-result-object v0

    .line 345
    invoke-static {v0, v4, v14, v13}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 346
    .line 347
    .line 348
    move-result-object v14

    .line 349
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 350
    .line 351
    .line 352
    move-result v13

    .line 353
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 354
    .line 355
    .line 356
    move-result-object v8

    .line 357
    invoke-static {v4, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 358
    .line 359
    .line 360
    move-result-object v7

    .line 361
    move-object/from16 v0, v20

    .line 362
    .line 363
    invoke-static {v4, v1, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 364
    .line 365
    .line 366
    invoke-static {v4, v14, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 367
    .line 368
    .line 369
    invoke-static {v4, v8, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 370
    .line 371
    .line 372
    move-object/from16 v0, v19

    .line 373
    .line 374
    invoke-static {v9, v0, v4, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 375
    .line 376
    .line 377
    move-object/from16 v0, v18

    .line 378
    .line 379
    invoke-static {v4, v7, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 380
    .line 381
    .line 382
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 383
    .line 384
    invoke-static {v4, v0}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 385
    .line 386
    .line 387
    move-result-object v8

    .line 388
    sget v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 389
    .line 390
    or-int v0, v7, v17

    .line 391
    .line 392
    invoke-static {v5, v8, v4, v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PermissionCaption(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2hg;LX/2d4;II)V

    .line 393
    .line 394
    .line 395
    invoke-static {v5}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModelKt;->credentialChooserMarker(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

    .line 396
    .line 397
    .line 398
    move-result-object v31

    .line 399
    const v8, 0xe000

    .line 400
    .line 401
    .line 402
    if-nez v31, :cond_19

    .line 403
    .line 404
    const v0, -0x524a0717

    .line 405
    .line 406
    .line 407
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 408
    .line 409
    .line 410
    iget-boolean v0, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->hasPreviewTemplate:Z

    .line 411
    .line 412
    if-eqz v0, :cond_16

    .line 413
    .line 414
    iget-object v0, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 415
    .line 416
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 417
    .line 418
    .line 419
    move-result v6

    .line 420
    const/4 v0, 0x2

    .line 421
    if-ne v6, v0, :cond_16

    .line 422
    .line 423
    const v0, -0x5248fedd

    .line 424
    .line 425
    .line 426
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 427
    .line 428
    .line 429
    iget-object v7, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 430
    .line 431
    and-int/2addr v8, v12

    .line 432
    const/16 v0, 0x4000

    .line 433
    .line 434
    invoke-static {v8, v0}, LX/003;->A1I(II)Z

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 439
    .line 440
    .line 441
    move-result-object v6

    .line 442
    if-nez v0, :cond_12

    .line 443
    .line 444
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 445
    .line 446
    if-ne v6, v0, :cond_13

    .line 447
    .line 448
    :cond_12
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$1$1$1$1;

    .line 449
    .line 450
    move-object/from16 v0, p5

    .line 451
    .line 452
    invoke-direct {v6, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$1$1$1$1;-><init>(LX/JDN;)V

    .line 453
    .line 454
    .line 455
    invoke-interface {v4, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 456
    .line 457
    .line 458
    :cond_13
    check-cast v6, LX/JDM;

    .line 459
    .line 460
    shr-int/lit8 v0, v12, 0x6

    .line 461
    .line 462
    and-int/lit8 v13, v0, 0x70

    .line 463
    .line 464
    const/16 v14, 0x18

    .line 465
    .line 466
    move/from16 v8, p6

    .line 467
    .line 468
    move-object v9, v6

    .line 469
    move-object/from16 v10, v16

    .line 470
    .line 471
    move v11, v2

    .line 472
    move-object v12, v4

    .line 473
    invoke-static/range {v7 .. v14}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->SideBySideDecisionButtons(Ljava/util/List;ZLX/JDM;LX/3C1;ZLX/2d4;II)V

    .line 474
    .line 475
    .line 476
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 477
    .line 478
    .line 479
    :goto_1
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 480
    .line 481
    .line 482
    const/4 v6, 0x2

    .line 483
    :goto_2
    if-eqz v22, :cond_15

    .line 484
    .line 485
    const v0, -0x553bba6b

    .line 486
    .line 487
    .line 488
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 489
    .line 490
    .line 491
    sget v11, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 492
    .line 493
    or-int v11, v11, v17

    .line 494
    .line 495
    or-int/2addr v11, v15

    .line 496
    move-object v7, v5

    .line 497
    move-object/from16 v8, p8

    .line 498
    .line 499
    move-object/from16 v9, v16

    .line 500
    .line 501
    move-object v10, v4

    .line 502
    move/from16 v12, v23

    .line 503
    .line 504
    invoke-static/range {v7 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionConfirmingStatus(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 505
    .line 506
    .line 507
    :goto_3
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 508
    .line 509
    .line 510
    sget v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 511
    .line 512
    or-int v2, v2, v17

    .line 513
    .line 514
    move-object/from16 v0, v16

    .line 515
    .line 516
    invoke-static {v5, v0, v4, v2, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V

    .line 517
    .line 518
    .line 519
    move/from16 v0, v24

    .line 520
    .line 521
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 522
    .line 523
    .line 524
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 525
    .line 526
    .line 527
    :goto_4
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 528
    .line 529
    .line 530
    move-result-object v1

    .line 531
    if-eqz v1, :cond_14

    .line 532
    .line 533
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;

    .line 534
    .line 535
    move-object v4, v0

    .line 536
    move-object/from16 v6, p8

    .line 537
    .line 538
    move/from16 v7, p7

    .line 539
    .line 540
    move/from16 v8, p6

    .line 541
    .line 542
    move-object/from16 v9, p5

    .line 543
    .line 544
    move-object/from16 v10, v28

    .line 545
    .line 546
    move/from16 v11, v27

    .line 547
    .line 548
    move-object/from16 v12, v26

    .line 549
    .line 550
    move/from16 v13, v22

    .line 551
    .line 552
    move v14, v3

    .line 553
    move/from16 v15, v25

    .line 554
    .line 555
    invoke-direct/range {v4 .. v15}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZII)V

    .line 556
    .line 557
    .line 558
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 559
    .line 560
    :cond_14
    return-void

    .line 561
    :cond_15
    const v0, -0x523a71e6

    .line 562
    .line 563
    .line 564
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 565
    .line 566
    .line 567
    goto :goto_3

    .line 568
    :cond_16
    const v0, -0x52459a61

    .line 569
    .line 570
    .line 571
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 572
    .line 573
    .line 574
    iget-object v7, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 575
    .line 576
    and-int/2addr v8, v12

    .line 577
    const/16 v0, 0x4000

    .line 578
    .line 579
    invoke-static {v8, v0}, LX/003;->A1I(II)Z

    .line 580
    .line 581
    .line 582
    move-result v0

    .line 583
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 584
    .line 585
    .line 586
    move-result-object v6

    .line 587
    if-nez v0, :cond_17

    .line 588
    .line 589
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 590
    .line 591
    if-ne v6, v0, :cond_18

    .line 592
    .line 593
    :cond_17
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$1$1$2$1;

    .line 594
    .line 595
    move-object/from16 v0, p5

    .line 596
    .line 597
    invoke-direct {v6, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$1$1$2$1;-><init>(LX/JDN;)V

    .line 598
    .line 599
    .line 600
    invoke-interface {v4, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 601
    .line 602
    .line 603
    :cond_18
    check-cast v6, LX/JDM;

    .line 604
    .line 605
    shr-int/lit8 p2, v12, 0x6

    .line 606
    .line 607
    const v0, 0x7e070

    .line 608
    .line 609
    .line 610
    and-int p2, p2, v0

    .line 611
    .line 612
    const/16 p3, 0x48

    .line 613
    .line 614
    move-object/from16 v29, v7

    .line 615
    .line 616
    move/from16 v30, p6

    .line 617
    .line 618
    move-object/from16 v31, v6

    .line 619
    .line 620
    move-object/from16 v32, v16

    .line 621
    .line 622
    move/from16 v33, v27

    .line 623
    .line 624
    move-object/from16 v34, v26

    .line 625
    .line 626
    move-object/from16 p0, v16

    .line 627
    .line 628
    move-object/from16 p1, v4

    .line 629
    .line 630
    invoke-static/range {v29 .. v38}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionButtons-iHT-50w(Ljava/util/List;ZLX/JDM;LX/3C1;FLX/2or;LX/JDM;LX/2d4;II)V

    .line 631
    .line 632
    .line 633
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 634
    .line 635
    .line 636
    goto/16 :goto_1

    .line 637
    .line 638
    :cond_19
    const v0, -0x52409f24

    .line 639
    .line 640
    .line 641
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 642
    .line 643
    .line 644
    or-int v7, v7, v17

    .line 645
    .line 646
    invoke-static {v7, v15, v12}, LX/001;->A07(III)I

    .line 647
    .line 648
    .line 649
    move-result v0

    .line 650
    and-int/2addr v8, v12

    .line 651
    or-int/2addr v8, v0

    .line 652
    invoke-static {v6, v8}, LX/002;->A06(II)I

    .line 653
    .line 654
    .line 655
    move-result v0

    .line 656
    invoke-static {v6, v0}, LX/001;->A06(II)I

    .line 657
    .line 658
    .line 659
    move-result p3

    .line 660
    const/16 p4, 0x80

    .line 661
    .line 662
    const/4 v6, 0x2

    .line 663
    move/from16 v32, p6

    .line 664
    .line 665
    move-object/from16 v33, p5

    .line 666
    .line 667
    move/from16 v34, v27

    .line 668
    .line 669
    move-object/from16 p0, v26

    .line 670
    .line 671
    move-object/from16 p1, v16

    .line 672
    .line 673
    move-object/from16 p2, v4

    .line 674
    .line 675
    invoke-static/range {v29 .. v39}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialDecisions-eHTjO5g(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;ZLX/JDN;FLX/2or;LX/3C1;LX/2d4;II)V

    .line 676
    .line 677
    .line 678
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 679
    .line 680
    .line 681
    goto/16 :goto_2
.end method

.method public static final AgentPermissionApprovalHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V
    .locals 19

    .line 0
    move-object/from16 v3, p3

    .line 1
    .line 2
    const v0, -0x6f47329d

    .line 3
    .line 4
    .line 5
    move-object/from16 v14, p4

    .line 6
    .line 7
    invoke-interface {v14, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v10, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v10, v14, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    or-int v6, v6, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 29
    .line 30
    move-object/from16 v11, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v14, v11}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v6, v0

    .line 39
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 40
    .line 41
    move/from16 v12, p2

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    invoke-static {v14, v12}, LX/004;->A0k(LX/2d4;Z)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v6, v0

    .line 50
    :cond_1
    move/from16 p0, p6

    .line 51
    .line 52
    and-int/lit8 v1, p6, 0x8

    .line 53
    .line 54
    if-eqz v1, :cond_4

    .line 55
    .line 56
    or-int/lit16 v6, v6, 0xc00

    .line 57
    .line 58
    :cond_2
    :goto_1
    invoke-static {v6}, LX/005;->A1K(I)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0, v14, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_7

    .line 67
    .line 68
    if-eqz v1, :cond_3

    .line 69
    .line 70
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 71
    .line 72
    :cond_3
    invoke-static {v3}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContentSpacing:F

    .line 77
    .line 78
    invoke-static {v14, v0}, LX/3Rs;->A09(LX/2d4;F)LX/3BI;

    .line 79
    .line 80
    .line 81
    move-result-object v9

    .line 82
    move-object v5, v14

    .line 83
    check-cast v5, LX/J7I;

    .line 84
    .line 85
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 86
    .line 87
    .line 88
    move-result v8

    .line 89
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 90
    .line 91
    .line 92
    move-result-object v7

    .line 93
    invoke-static {v14, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 94
    .line 95
    .line 96
    move-result-object v4

    .line 97
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 98
    .line 99
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 100
    .line 101
    if-nez v0, :cond_6

    .line 102
    .line 103
    invoke-static {}, LX/1VY;->A00()V

    .line 104
    .line 105
    .line 106
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0

    .line 111
    :cond_4
    and-int/lit16 v0, v2, 0xc00

    .line 112
    .line 113
    if-nez v0, :cond_2

    .line 114
    .line 115
    invoke-static {v14, v3}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    or-int/2addr v6, v0

    .line 120
    goto :goto_1

    .line 121
    :cond_5
    move v6, v2

    .line 122
    goto :goto_0

    .line 123
    :cond_6
    invoke-static {v14, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 124
    .line 125
    .line 126
    invoke-static {v14, v9, v7, v4, v8}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 127
    .line 128
    .line 129
    sget v15, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 130
    .line 131
    and-int/lit8 v4, v6, 0xe

    .line 132
    .line 133
    or-int/2addr v15, v4

    .line 134
    and-int/lit8 v1, v6, 0x70

    .line 135
    .line 136
    or-int/2addr v15, v1

    .line 137
    and-int/lit16 v0, v6, 0x380

    .line 138
    .line 139
    or-int/2addr v15, v0

    .line 140
    const/16 v16, 0x8

    .line 141
    .line 142
    const/4 v13, 0x0

    .line 143
    invoke-static/range {v10 .. v16}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalTitleRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V

    .line 144
    .line 145
    .line 146
    sget p5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 147
    .line 148
    or-int p5, p5, v4

    .line 149
    .line 150
    or-int p5, p5, v1

    .line 151
    .line 152
    const/16 p6, 0x4

    .line 153
    .line 154
    move-object/from16 p1, v10

    .line 155
    .line 156
    move-object/from16 p2, v11

    .line 157
    .line 158
    move-object/from16 p3, v13

    .line 159
    .line 160
    invoke-static/range {p1 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionPurposeCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 161
    .line 162
    .line 163
    invoke-static {v5, v3}, LX/002;->A0Y(LX/J7I;LX/3C1;)LX/3C1;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    goto :goto_2

    .line 168
    :cond_7
    invoke-interface {v14}, LX/2d4;->AgJ()V

    .line 169
    .line 170
    .line 171
    :goto_2
    invoke-interface {v14}, LX/2d4;->AAg()LX/J7V;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    if-eqz v0, :cond_8

    .line 176
    .line 177
    new-instance v13, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalHeader$2;

    .line 178
    .line 179
    move-object v14, v10

    .line 180
    move-object v15, v11

    .line 181
    move/from16 v16, v12

    .line 182
    .line 183
    move-object/from16 v17, v3

    .line 184
    .line 185
    move/from16 v18, v2

    .line 186
    .line 187
    invoke-direct/range {v13 .. v19}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalHeader$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;II)V

    .line 188
    .line 189
    .line 190
    iput-object v13, v0, LX/J7V;->A06:LX/JDN;

    .line 191
    .line 192
    :cond_8
    return-void
.end method

.method public static final AgentPermissionAttentionBanner(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 30

    .line 0
    move-object/from16 v10, p2

    .line 1
    .line 2
    const v1, -0x143f6de4

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p3

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p4

    .line 11
    .line 12
    and-int/lit8 v1, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v13, p0

    .line 15
    .line 16
    if-nez v1, :cond_b

    .line 17
    .line 18
    invoke-static {v0, v13}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    or-int v4, v4, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v12, p1

    .line 27
    .line 28
    if-nez v1, :cond_0

    .line 29
    .line 30
    invoke-static {v0, v12}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    or-int/2addr v4, v1

    .line 35
    :cond_0
    and-int/lit8 v3, p5, 0x4

    .line 36
    .line 37
    if-eqz v3, :cond_a

    .line 38
    .line 39
    or-int/lit16 v4, v4, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v2, v4, 0x93

    .line 42
    .line 43
    const/16 v1, 0x92

    .line 44
    .line 45
    const/4 v11, 0x0

    .line 46
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    invoke-static {v1, v0, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_9

    .line 55
    .line 56
    if-eqz v3, :cond_2

    .line 57
    .line 58
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    if-eqz p0, :cond_8

    .line 61
    .line 62
    invoke-static {v13}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    if-eqz v6, :cond_8

    .line 67
    .line 68
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    const/16 v19, 0x0

    .line 73
    .line 74
    if-lez v1, :cond_8

    .line 75
    .line 76
    if-eqz p1, :cond_7

    .line 77
    .line 78
    invoke-static {v12}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-eqz v2, :cond_7

    .line 83
    .line 84
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    if-lez v1, :cond_7

    .line 89
    .line 90
    const v1, -0x4150c623

    .line 91
    .line 92
    .line 93
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 94
    .line 95
    .line 96
    invoke-static {v2, v0, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt;->rememberPermissionCaptionText(Ljava/lang/String;LX/2d4;I)LX/2iK;

    .line 97
    .line 98
    .line 99
    move-result-object v7

    .line 100
    invoke-static {v0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :goto_2
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 104
    .line 105
    const/4 v3, 0x6

    .line 106
    invoke-virtual {v4, v0, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->destructiveText:J

    .line 111
    .line 112
    invoke-static {v0, v6, v7}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v8

    .line 116
    invoke-static {v0, v1, v2, v8}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 117
    .line 118
    .line 119
    move-result v8

    .line 120
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v14

    .line 124
    if-nez v8, :cond_3

    .line 125
    .line 126
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 127
    .line 128
    if-ne v14, v8, :cond_5

    .line 129
    .line 130
    :cond_3
    invoke-static {}, LX/2b4;->A00()LX/2b4;

    .line 131
    .line 132
    .line 133
    move-result-object v8

    .line 134
    iget-object v14, v8, LX/2b4;->A00:Ljava/lang/StringBuilder;

    .line 135
    .line 136
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->length()I

    .line 137
    .line 138
    .line 139
    move-result v9

    .line 140
    invoke-virtual {v8, v6}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    sget-object v21, LX/2W8;->A01:LX/2W8;

    .line 144
    .line 145
    sget-wide v29, LX/2hw;->A01:J

    .line 146
    .line 147
    sget-wide p3, LX/JOw;->A07:J

    .line 148
    .line 149
    new-instance v6, LX/2hh;

    .line 150
    .line 151
    move-object v15, v6

    .line 152
    move-object/from16 v16, v19

    .line 153
    .line 154
    move-object/from16 v17, v19

    .line 155
    .line 156
    move-object/from16 v18, v19

    .line 157
    .line 158
    move-object/from16 v20, v19

    .line 159
    .line 160
    move-object/from16 v22, v19

    .line 161
    .line 162
    move-object/from16 v23, v19

    .line 163
    .line 164
    move-object/from16 v24, v19

    .line 165
    .line 166
    move-object/from16 v25, v19

    .line 167
    .line 168
    move-object/from16 v26, v19

    .line 169
    .line 170
    move-wide/from16 v27, v1

    .line 171
    .line 172
    move-wide/from16 p1, v29

    .line 173
    .line 174
    invoke-direct/range {v15 .. v34}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->length()I

    .line 178
    .line 179
    .line 180
    move-result v1

    .line 181
    invoke-virtual {v8, v6, v9, v1}, LX/2b4;->A0A(LX/2hh;II)V

    .line 182
    .line 183
    .line 184
    if-eqz v7, :cond_4

    .line 185
    .line 186
    const-string v1, " "

    .line 187
    .line 188
    invoke-virtual {v8, v1}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v8, v7}, LX/2b4;->A07(LX/2iK;)V

    .line 192
    .line 193
    .line 194
    :cond_4
    invoke-static {v0, v8}, LX/3Rr;->A0C(LX/2d4;LX/2b4;)LX/2iK;

    .line 195
    .line 196
    .line 197
    move-result-object v14

    .line 198
    :cond_5
    check-cast v14, LX/2iK;

    .line 199
    .line 200
    invoke-static {v0, v4}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 201
    .line 202
    .line 203
    move-result-object v18

    .line 204
    invoke-static {v0, v4}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 205
    .line 206
    .line 207
    move-result-wide v16

    .line 208
    invoke-static {v10}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 209
    .line 210
    .line 211
    move-result-object v6

    .line 212
    invoke-virtual {v4, v0, v3}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->error:J

    .line 217
    .line 218
    const v3, 0x3dcccccd    # 0.1f

    .line 219
    .line 220
    .line 221
    invoke-static {v1, v2, v3}, LX/JOw;->A04(JF)J

    .line 222
    .line 223
    .line 224
    move-result-wide v1

    .line 225
    const/high16 v4, 0x41400000    # 12.0f

    .line 226
    .line 227
    invoke-static {v4}, LX/2bA;->A00(F)LX/2bC;

    .line 228
    .line 229
    .line 230
    move-result-object v3

    .line 231
    invoke-static {v6, v3, v1, v2}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 232
    .line 233
    .line 234
    move-result-object v2

    .line 235
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 236
    .line 237
    invoke-static {v2, v1, v4}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 238
    .line 239
    .line 240
    move-result-object v15

    .line 241
    const/16 p4, 0x7ff0

    .line 242
    .line 243
    const-wide/16 v22, 0x0

    .line 244
    .line 245
    move-object/from16 v20, v19

    .line 246
    .line 247
    move-object/from16 v21, v19

    .line 248
    .line 249
    move/from16 v25, v11

    .line 250
    .line 251
    move/from16 v26, v11

    .line 252
    .line 253
    move/from16 v27, v11

    .line 254
    .line 255
    move-object/from16 v28, v19

    .line 256
    .line 257
    move-object/from16 v29, v19

    .line 258
    .line 259
    move-object/from16 p0, v19

    .line 260
    .line 261
    move-object/from16 p1, v0

    .line 262
    .line 263
    move/from16 p2, v11

    .line 264
    .line 265
    move/from16 p3, v11

    .line 266
    .line 267
    move/from16 v24, v11

    .line 268
    .line 269
    invoke-static/range {v14 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 270
    .line 271
    .line 272
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    if-eqz v1, :cond_6

    .line 277
    .line 278
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionAttentionBanner$1;

    .line 279
    .line 280
    move-object/from16 p1, v13

    .line 281
    .line 282
    move-object/from16 p2, v12

    .line 283
    .line 284
    move-object/from16 p3, v10

    .line 285
    .line 286
    move/from16 p4, v5

    .line 287
    .line 288
    move-object/from16 p0, v0

    .line 289
    .line 290
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionAttentionBanner$1;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 291
    .line 292
    .line 293
    :goto_4
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    :cond_6
    return-void

    .line 297
    :cond_7
    const v1, -0x4150c624

    .line 298
    .line 299
    .line 300
    invoke-static {v0, v1}, LX/003;->A0q(LX/2d4;I)V

    .line 301
    .line 302
    .line 303
    move-object/from16 v7, v19

    .line 304
    .line 305
    goto/16 :goto_2

    .line 306
    .line 307
    :cond_8
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 308
    .line 309
    .line 310
    move-result-object v1

    .line 311
    if-eqz v1, :cond_6

    .line 312
    .line 313
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionAttentionBanner$label$2;

    .line 314
    .line 315
    move-object/from16 p1, v13

    .line 316
    .line 317
    move-object/from16 p2, v12

    .line 318
    .line 319
    move-object/from16 p3, v10

    .line 320
    .line 321
    move-object/from16 p0, v0

    .line 322
    .line 323
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionAttentionBanner$label$2;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 324
    .line 325
    .line 326
    goto :goto_4

    .line 327
    :cond_9
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 328
    .line 329
    .line 330
    goto :goto_3

    .line 331
    :cond_a
    and-int/lit16 v1, v5, 0x180

    .line 332
    .line 333
    if-nez v1, :cond_1

    .line 334
    .line 335
    invoke-static {v0, v10}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 336
    .line 337
    .line 338
    move-result v1

    .line 339
    or-int/2addr v4, v1

    .line 340
    goto/16 :goto_1

    .line 341
    .line 342
    :cond_b
    move v4, v5

    .line 343
    goto/16 :goto_0
.end method

.method public static final AgentPermissionDecisionButtons-iHT-50w(Ljava/util/List;ZLX/JDM;LX/3C1;FLX/2or;LX/JDM;LX/2d4;II)V
    .locals 47
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;Z",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "F",
            "LX/2or;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v14, p3

    .line 1
    .line 2
    move/from16 v9, p4

    .line 3
    .line 4
    move-object/from16 v7, p5

    .line 5
    .line 6
    move-object/from16 v3, p6

    .line 7
    .line 8
    const/4 v8, 0x0

    .line 9
    move-object/from16 p6, p0

    .line 10
    .line 11
    move-object/from16 v15, p2

    .line 12
    .line 13
    move-object/from16 v0, p6

    .line 14
    .line 15
    invoke-static {v0, v15, v8}, LX/003;->A0J(Ljava/lang/Object;Ljava/lang/Object;I)I

    .line 16
    .line 17
    .line 18
    move-result v44

    .line 19
    const v0, -0x255e3fe6

    .line 20
    .line 21
    .line 22
    move-object/from16 v6, p7

    .line 23
    .line 24
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 25
    .line 26
    .line 27
    move/from16 v5, p8

    .line 28
    .line 29
    and-int/lit8 v0, p8, 0x6

    .line 30
    .line 31
    if-nez v0, :cond_f

    .line 32
    .line 33
    move-object/from16 v0, p6

    .line 34
    .line 35
    invoke-static {v0, v6, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0}, LX/003;->A06(I)I

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    or-int v4, v4, p8

    .line 44
    .line 45
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 46
    .line 47
    move/from16 v19, p1

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    move/from16 v0, v19

    .line 52
    .line 53
    invoke-static {v6, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    or-int/2addr v4, v0

    .line 58
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 59
    .line 60
    if-nez v0, :cond_1

    .line 61
    .line 62
    invoke-static {v6, v15}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v4, v0

    .line 67
    :cond_1
    move/from16 p5, p9

    .line 68
    .line 69
    and-int/lit8 v11, p9, 0x8

    .line 70
    .line 71
    if-eqz v11, :cond_e

    .line 72
    .line 73
    or-int/lit16 v4, v4, 0xc00

    .line 74
    .line 75
    :cond_2
    :goto_1
    and-int/lit8 v10, p9, 0x10

    .line 76
    .line 77
    if-eqz v10, :cond_d

    .line 78
    .line 79
    or-int/lit16 v4, v4, 0x6000

    .line 80
    .line 81
    :cond_3
    :goto_2
    and-int/lit8 v1, p9, 0x20

    .line 82
    .line 83
    const/high16 v0, 0x30000

    .line 84
    .line 85
    if-nez v1, :cond_4

    .line 86
    .line 87
    and-int v0, v0, p8

    .line 88
    .line 89
    if-nez v0, :cond_5

    .line 90
    .line 91
    invoke-static {v6, v7}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    :cond_4
    or-int/2addr v4, v0

    .line 96
    :cond_5
    and-int/lit8 v2, p9, 0x40

    .line 97
    .line 98
    const/high16 v0, 0x180000

    .line 99
    .line 100
    if-nez v2, :cond_6

    .line 101
    .line 102
    and-int v0, p8, v0

    .line 103
    .line 104
    if-nez v0, :cond_7

    .line 105
    .line 106
    invoke-static {v6, v3}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    :cond_6
    or-int/2addr v4, v0

    .line 111
    :cond_7
    const v0, 0x92493

    .line 112
    .line 113
    .line 114
    invoke-static {v4, v0}, LX/005;->A1O(II)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    invoke-static {v0, v6, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_18

    .line 123
    .line 124
    if-eqz v11, :cond_8

    .line 125
    .line 126
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 127
    .line 128
    :cond_8
    if-eqz v10, :cond_9

    .line 129
    .line 130
    const/high16 v9, 0x41000000    # 8.0f

    .line 131
    .line 132
    :cond_9
    if-eqz v1, :cond_a

    .line 133
    .line 134
    const/high16 v1, 0x41000000    # 8.0f

    .line 135
    .line 136
    const/high16 v0, 0x41200000    # 10.0f

    .line 137
    .line 138
    new-instance v7, LX/1XE;

    .line 139
    .line 140
    invoke-direct {v7, v1, v0, v1, v0}, LX/1XE;-><init>(FFFF)V

    .line 141
    .line 142
    .line 143
    :cond_a
    if-eqz v2, :cond_c

    .line 144
    .line 145
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 150
    .line 151
    if-ne v3, v0, :cond_b

    .line 152
    .line 153
    sget-object v3, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$1$1;

    .line 154
    .line 155
    invoke-interface {v6, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    :cond_b
    check-cast v3, LX/JDM;

    .line 159
    .line 160
    :cond_c
    invoke-static/range {p6 .. p6}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v18

    .line 164
    sget-object v17, LX/2sI;->A02:LX/2wD;

    .line 165
    .line 166
    move-object/from16 v0, v17

    .line 167
    .line 168
    invoke-interface {v14, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-static {v6, v9, v8}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 173
    .line 174
    .line 175
    move-result-object v13

    .line 176
    move-object v2, v6

    .line 177
    check-cast v2, LX/J7I;

    .line 178
    .line 179
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 180
    .line 181
    .line 182
    move-result v12

    .line 183
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 184
    .line 185
    .line 186
    move-result-object v11

    .line 187
    invoke-static {v6, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 188
    .line 189
    .line 190
    move-result-object v10

    .line 191
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 192
    .line 193
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 194
    .line 195
    if-nez v0, :cond_10

    .line 196
    .line 197
    invoke-static {}, LX/1VY;->A00()V

    .line 198
    .line 199
    .line 200
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    throw v0

    .line 205
    :cond_d
    and-int/lit16 v0, v5, 0x6000

    .line 206
    .line 207
    if-nez v0, :cond_3

    .line 208
    .line 209
    invoke-static {v6, v9}, LX/008;->A0I(LX/2d4;F)I

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    or-int/2addr v4, v0

    .line 214
    goto/16 :goto_2

    .line 215
    .line 216
    :cond_e
    and-int/lit16 v0, v5, 0xc00

    .line 217
    .line 218
    if-nez v0, :cond_2

    .line 219
    .line 220
    invoke-static {v6, v14}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 221
    .line 222
    .line 223
    move-result v0

    .line 224
    or-int/2addr v4, v0

    .line 225
    goto/16 :goto_1

    .line 226
    .line 227
    :cond_f
    move v4, v5

    .line 228
    goto/16 :goto_0

    .line 229
    .line 230
    :cond_10
    invoke-static {v6, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 231
    .line 232
    .line 233
    invoke-static {v6, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 234
    .line 235
    .line 236
    const v1, -0x52cc5845

    .line 237
    .line 238
    .line 239
    move-object/from16 v0, p6

    .line 240
    .line 241
    invoke-static {v6, v0, v1}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 242
    .line 243
    .line 244
    move-result-object v16

    .line 245
    :goto_3
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 246
    .line 247
    .line 248
    move-result v0

    .line 249
    if-eqz v0, :cond_19

    .line 250
    .line 251
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    check-cast v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 256
    .line 257
    iget-object v13, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->labelText:Ljava/lang/String;

    .line 258
    .line 259
    move-object/from16 v1, v18

    .line 260
    .line 261
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v1

    .line 265
    const/16 v12, 0x30

    .line 266
    .line 267
    if-eqz v1, :cond_17

    .line 268
    .line 269
    const v1, 0x7f0864a7

    .line 270
    .line 271
    .line 272
    invoke-interface {v6, v1}, LX/2d4;->Agj(I)V

    .line 273
    .line 274
    .line 275
    sget-object v11, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 276
    .line 277
    const/4 v10, 0x1

    .line 278
    const/4 v1, 0x0

    .line 279
    invoke-virtual {v11, v1, v6, v12, v10}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 280
    .line 281
    .line 282
    move-result-object v24

    .line 283
    :goto_4
    invoke-static {v2, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 284
    .line 285
    .line 286
    sget-object v25, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->MEDIUM:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 287
    .line 288
    if-eqz v19, :cond_11

    .line 289
    .line 290
    invoke-static {v0, v3}, LX/003;->A1Y(Ljava/lang/Object;LX/JDM;)Z

    .line 291
    .line 292
    .line 293
    move-result v1

    .line 294
    const/16 v29, 0x1

    .line 295
    .line 296
    if-nez v1, :cond_12

    .line 297
    .line 298
    :cond_11
    const/16 v29, 0x0

    .line 299
    .line 300
    :cond_12
    const/16 v20, 0x0

    .line 301
    .line 302
    invoke-static {v4}, LX/005;->A1J(I)Z

    .line 303
    .line 304
    .line 305
    move-result v1

    .line 306
    invoke-static {v6, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 307
    .line 308
    .line 309
    move-result v10

    .line 310
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    if-nez v10, :cond_13

    .line 315
    .line 316
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 317
    .line 318
    if-ne v1, v10, :cond_14

    .line 319
    .line 320
    :cond_13
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$1$1;

    .line 321
    .line 322
    invoke-direct {v1, v15, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$1$1;-><init>(LX/JDM;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 323
    .line 324
    .line 325
    invoke-interface {v6, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    :cond_14
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 329
    .line 330
    invoke-static {v4}, LX/009;->A1L(I)Z

    .line 331
    .line 332
    .line 333
    move-result v10

    .line 334
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v0

    .line 338
    if-nez v10, :cond_15

    .line 339
    .line 340
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 341
    .line 342
    if-ne v0, v10, :cond_16

    .line 343
    .line 344
    :cond_15
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;

    .line 345
    .line 346
    invoke-direct {v0, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;-><init>(LX/2or;)V

    .line 347
    .line 348
    .line 349
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    :cond_16
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 353
    .line 354
    const/16 p3, 0x6000

    .line 355
    .line 356
    const p4, 0x6dfbdc5

    .line 357
    .line 358
    .line 359
    const p1, 0x30c00

    .line 360
    .line 361
    .line 362
    move-object/from16 v22, v20

    .line 363
    .line 364
    move-object/from16 v26, v20

    .line 365
    .line 366
    move/from16 v27, v8

    .line 367
    .line 368
    move/from16 v28, v8

    .line 369
    .line 370
    move/from16 v30, v8

    .line 371
    .line 372
    move/from16 v31, v8

    .line 373
    .line 374
    move-object/from16 v32, v20

    .line 375
    .line 376
    move-object/from16 v33, v20

    .line 377
    .line 378
    move-object/from16 v34, v1

    .line 379
    .line 380
    move-object/from16 v35, v20

    .line 381
    .line 382
    move-object/from16 v36, v20

    .line 383
    .line 384
    move-object/from16 v37, v20

    .line 385
    .line 386
    move-object/from16 v38, v20

    .line 387
    .line 388
    move-object/from16 v39, v20

    .line 389
    .line 390
    move-object/from16 v40, v20

    .line 391
    .line 392
    move-object/from16 v41, v0

    .line 393
    .line 394
    move-object/from16 v42, v20

    .line 395
    .line 396
    move/from16 v43, v8

    .line 397
    .line 398
    move/from16 v45, v8

    .line 399
    .line 400
    move/from16 v46, v8

    .line 401
    .line 402
    move-object/from16 p0, v6

    .line 403
    .line 404
    move/from16 p2, v8

    .line 405
    .line 406
    move-object/from16 v21, v13

    .line 407
    .line 408
    move-object/from16 v23, v17

    .line 409
    .line 410
    invoke-static/range {v20 .. v51}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 411
    .line 412
    .line 413
    goto/16 :goto_3

    .line 414
    .line 415
    :cond_17
    const/4 v11, 0x1

    .line 416
    const/4 v10, 0x0

    .line 417
    const v1, 0x7f086a69

    .line 418
    .line 419
    .line 420
    invoke-interface {v6, v1}, LX/2d4;->Agj(I)V

    .line 421
    .line 422
    .line 423
    sget-object v1, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 424
    .line 425
    invoke-virtual {v1, v10, v6, v12, v11}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 426
    .line 427
    .line 428
    move-result-object v24

    .line 429
    goto/16 :goto_4

    .line 430
    .line 431
    :cond_18
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 432
    .line 433
    .line 434
    goto :goto_5

    .line 435
    :cond_19
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 436
    .line 437
    .line 438
    :goto_5
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 439
    .line 440
    .line 441
    move-result-object v1

    .line 442
    if-eqz v1, :cond_1a

    .line 443
    .line 444
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$3;

    .line 445
    .line 446
    move-object/from16 v43, v0

    .line 447
    .line 448
    move-object/from16 v44, p6

    .line 449
    .line 450
    move/from16 v45, v19

    .line 451
    .line 452
    move-object/from16 v46, v15

    .line 453
    .line 454
    move-object/from16 p0, v14

    .line 455
    .line 456
    move/from16 p1, v9

    .line 457
    .line 458
    move-object/from16 p2, v7

    .line 459
    .line 460
    move-object/from16 p3, v3

    .line 461
    .line 462
    move/from16 p4, v5

    .line 463
    .line 464
    invoke-direct/range {v43 .. v52}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$3;-><init>(Ljava/util/List;ZLX/JDM;LX/3C1;FLX/2or;LX/JDM;II)V

    .line 465
    .line 466
    .line 467
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 468
    .line 469
    :cond_1a
    return-void
.end method

.method public static final AgentPermissionDecisionConfirmingStatus(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V
    .locals 13

    .line 0
    move-object v3, p0

    .line 1
    move-object v2, p1

    .line 2
    move-object v12, p2

    .line 3
    invoke-static {p0, p1}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    const v0, -0x1584a741

    .line 8
    .line 9
    .line 10
    move-object/from16 p2, p3

    .line 11
    .line 12
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 13
    .line 14
    .line 15
    move/from16 v1, p4

    .line 16
    .line 17
    and-int/lit8 v0, p4, 0x6

    .line 18
    .line 19
    const/4 v7, 0x4

    .line 20
    if-nez v0, :cond_b

    .line 21
    .line 22
    invoke-static {p0, p2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-static {v0}, LX/003;->A06(I)I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    or-int v6, v6, p4

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {p2, p1}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v6, v0

    .line 41
    :cond_0
    and-int/lit8 v5, p5, 0x4

    .line 42
    .line 43
    if-eqz v5, :cond_a

    .line 44
    .line 45
    or-int/lit16 v6, v6, 0x180

    .line 46
    .line 47
    :cond_1
    :goto_1
    invoke-static {v6}, LX/005;->A1I(I)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0, p2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_9

    .line 56
    .line 57
    if-eqz v5, :cond_2

    .line 58
    .line 59
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 60
    .line 61
    :cond_2
    invoke-static {p2}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    new-instance v9, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;

    .line 66
    .line 67
    invoke-direct {v9, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;-><init>(LX/AHE;)V

    .line 68
    .line 69
    .line 70
    invoke-static {p2}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 71
    .line 72
    .line 73
    move-result-object v8

    .line 74
    if-eqz v8, :cond_c

    .line 75
    .line 76
    invoke-static {v8}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 81
    .line 82
    invoke-static {v9, v8, v5, v0}, LX/3Rq;->A05(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;)LX/1EJ;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    check-cast v5, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 87
    .line 88
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->stalled:LX/2J3;

    .line 89
    .line 90
    invoke-static {p2, v0, v4}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-static {v0}, LX/16A;->A0C(LX/16A;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_8

    .line 99
    .line 100
    const v0, -0x17fd4080

    .line 101
    .line 102
    .line 103
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 104
    .line 105
    .line 106
    const v0, 0x7f1200f1

    .line 107
    .line 108
    .line 109
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v9

    .line 113
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 114
    .line 115
    invoke-static {p2, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 116
    .line 117
    .line 118
    move-result-wide v10

    .line 119
    const v0, 0x7f1200ec

    .line 120
    .line 121
    .line 122
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    invoke-interface {p2, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v8

    .line 130
    and-int/lit8 v0, v6, 0xe

    .line 131
    .line 132
    if-eq v0, v7, :cond_3

    .line 133
    .line 134
    and-int/lit8 v0, v6, 0x8

    .line 135
    .line 136
    if-eqz v0, :cond_7

    .line 137
    .line 138
    invoke-interface {p2, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-eqz v0, :cond_7

    .line 143
    .line 144
    :cond_3
    const/4 v0, 0x1

    .line 145
    :goto_2
    or-int/2addr v8, v0

    .line 146
    invoke-static {v6}, LX/004;->A1S(I)Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    or-int/2addr v8, v0

    .line 151
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    if-nez v8, :cond_4

    .line 156
    .line 157
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 158
    .line 159
    if-ne p1, v0, :cond_5

    .line 160
    .line 161
    :cond_4
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;

    .line 162
    .line 163
    invoke-direct {p1, v5, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 164
    .line 165
    .line 166
    invoke-interface {p2, p1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    :cond_5
    check-cast p1, Lkotlin/jvm/functions/Function0;

    .line 170
    .line 171
    and-int/lit16 v0, v6, 0x380

    .line 172
    .line 173
    move/from16 p4, v4

    .line 174
    .line 175
    move/from16 p3, v0

    .line 176
    .line 177
    invoke-static/range {v9 .. v17}, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt;->ApprovalCardStatusMessage-8V94_ZQ(Ljava/lang/String;JLX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 178
    .line 179
    .line 180
    :goto_3
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    :goto_4
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    if-eqz v0, :cond_6

    .line 188
    .line 189
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$2;

    .line 190
    .line 191
    move-object/from16 p3, v12

    .line 192
    .line 193
    move/from16 p4, v1

    .line 194
    .line 195
    move-object p2, v2

    .line 196
    move-object p1, v3

    .line 197
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 198
    .line 199
    .line 200
    iput-object p0, v0, LX/J7V;->A06:LX/JDN;

    .line 201
    .line 202
    :cond_6
    return-void

    .line 203
    :cond_7
    const/4 v0, 0x0

    .line 204
    goto :goto_2

    .line 205
    :cond_8
    const v0, -0x17f7e1d8

    .line 206
    .line 207
    .line 208
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 209
    .line 210
    .line 211
    const v0, 0x7f1200ed

    .line 212
    .line 213
    .line 214
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v5

    .line 218
    shr-int/lit8 v0, v6, 0x3

    .line 219
    .line 220
    and-int/lit8 v0, v0, 0x70

    .line 221
    .line 222
    invoke-static {v5, v12, p2, v0, v4}, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt;->ApprovalCardProgressMessage(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 223
    .line 224
    .line 225
    goto :goto_3

    .line 226
    :cond_9
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 227
    .line 228
    .line 229
    goto :goto_4

    .line 230
    :cond_a
    and-int/lit16 v0, v1, 0x180

    .line 231
    .line 232
    if-nez v0, :cond_1

    .line 233
    .line 234
    invoke-static {p2, v12}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    or-int/2addr v6, v0

    .line 239
    goto/16 :goto_1

    .line 240
    .line 241
    :cond_b
    move v6, v1

    .line 242
    goto/16 :goto_0

    .line 243
    .line 244
    :cond_c
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    throw v0
.end method

.method public static final AgentPermissionDecisionConfirmingStatus$lambda$0(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final AgentPermissionFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V
    .locals 11

    .line 0
    move-object v6, p1

    .line 1
    const/4 v7, 0x0

    .line 2
    invoke-static {p0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    const v0, 0x37841b74

    .line 6
    .line 7
    .line 8
    move-object v8, p2

    .line 9
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    if-nez v0, :cond_6

    .line 15
    .line 16
    invoke-static {p0, p2, p3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    or-int/2addr v3, p3

    .line 25
    :goto_0
    and-int/lit8 v1, p4, 0x2

    .line 26
    .line 27
    if-eqz v1, :cond_5

    .line 28
    .line 29
    or-int/lit8 v3, v3, 0x30

    .line 30
    .line 31
    :cond_0
    :goto_1
    invoke-static {v3}, LX/005;->A1G(I)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, p2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 44
    .line 45
    :cond_1
    iget-object v2, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->footer:Ljava/lang/String;

    .line 46
    .line 47
    if-nez v2, :cond_4

    .line 48
    .line 49
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    if-eqz v1, :cond_2

    .line 54
    .line 55
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionFooter$footer$1;

    .line 56
    .line 57
    invoke-direct {v0, p0, v6, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionFooter$footer$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;II)V

    .line 58
    .line 59
    .line 60
    :goto_2
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void

    .line 64
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 65
    .line 66
    .line 67
    goto :goto_3

    .line 68
    :cond_4
    invoke-static {p2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionAgentName(LX/2d4;I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    const/4 v5, 0x0

    .line 73
    const-string v0, "{assistant}"

    .line 74
    .line 75
    invoke-static {v2, v0, v1}, LX/A75;->A07(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {v0, p2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt;->rememberPermissionCaptionText(Ljava/lang/String;LX/2d4;I)LX/2iK;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    shl-int/lit8 v0, v3, 0x3

    .line 84
    .line 85
    and-int/lit16 v0, v0, 0x380

    .line 86
    .line 87
    or-int/lit8 v9, v0, 0x30

    .line 88
    .line 89
    const/16 v10, 0x8

    .line 90
    .line 91
    invoke-static/range {v4 .. v10}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutLegalFooter-xkNWiIY(LX/2iK;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;ILX/2d4;II)V

    .line 92
    .line 93
    .line 94
    :goto_3
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    if-eqz v1, :cond_2

    .line 99
    .line 100
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionFooter$1;

    .line 101
    .line 102
    invoke-direct {v0, p0, v6, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionFooter$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;II)V

    .line 103
    .line 104
    .line 105
    goto :goto_2

    .line 106
    :cond_5
    and-int/lit8 v0, p3, 0x30

    .line 107
    .line 108
    if-nez v0, :cond_0

    .line 109
    .line 110
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    or-int/2addr v3, v0

    .line 115
    goto :goto_1

    .line 116
    :cond_6
    move v3, p3

    .line 117
    goto :goto_0
.end method

.method public static final AgentPermissionPendingCard-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V
    .locals 12

    .line 0
    move v10, p2

    .line 1
    move v11, p3

    .line 2
    move-object v8, p0

    .line 3
    move-object v9, p1

    .line 4
    const v0, 0x6d7bd59a

    .line 5
    .line 6
    .line 7
    move-object/from16 v1, p5

    .line 8
    .line 9
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 p2, p7

    .line 13
    .line 14
    and-int/lit8 v7, p7, 0x1

    .line 15
    .line 16
    move/from16 p1, p6

    .line 17
    .line 18
    if-eqz v7, :cond_10

    .line 19
    .line 20
    or-int/lit8 v4, p6, 0x6

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v2, p7, 0x2

    .line 23
    .line 24
    if-eqz v2, :cond_f

    .line 25
    .line 26
    or-int/lit8 v4, v4, 0x30

    .line 27
    .line 28
    :cond_0
    :goto_1
    and-int/lit8 v6, p7, 0x4

    .line 29
    .line 30
    if-eqz v6, :cond_e

    .line 31
    .line 32
    or-int/lit16 v4, v4, 0x180

    .line 33
    .line 34
    :cond_1
    :goto_2
    and-int/lit16 v0, p1, 0xc00

    .line 35
    .line 36
    if-nez v0, :cond_4

    .line 37
    .line 38
    and-int/lit8 v0, p7, 0x8

    .line 39
    .line 40
    if-nez v0, :cond_2

    .line 41
    .line 42
    invoke-interface {v1, p3}, LX/2d4;->A66(F)Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    const/16 v0, 0x800

    .line 47
    .line 48
    if-nez v3, :cond_3

    .line 49
    .line 50
    :cond_2
    const/16 v0, 0x400

    .line 51
    .line 52
    :cond_3
    or-int/2addr v4, v0

    .line 53
    :cond_4
    and-int/lit8 v5, p7, 0x10

    .line 54
    .line 55
    move/from16 v3, p4

    .line 56
    .line 57
    if-eqz v5, :cond_d

    .line 58
    .line 59
    or-int/lit16 v4, v4, 0x6000

    .line 60
    .line 61
    :cond_5
    :goto_3
    invoke-static {v4}, LX/009;->A1I(I)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_c

    .line 70
    .line 71
    invoke-interface {v1}, LX/2d4;->AgT()V

    .line 72
    .line 73
    .line 74
    and-int/lit8 v0, p6, 0x1

    .line 75
    .line 76
    if-eqz v0, :cond_8

    .line 77
    .line 78
    invoke-interface {v1}, LX/2d4;->AEs()Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_8

    .line 83
    .line 84
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 85
    .line 86
    .line 87
    :goto_4
    move p0, v3

    .line 88
    :cond_6
    invoke-interface {v1}, LX/2d4;->AAf()V

    .line 89
    .line 90
    .line 91
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraContainer$Card;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$Card;

    .line 92
    .line 93
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;

    .line 94
    .line 95
    invoke-direct/range {v7 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;-><init>(LX/3C1;Ljava/lang/String;ZFZ)V

    .line 96
    .line 97
    .line 98
    const v0, -0x5179f0db

    .line 99
    .line 100
    .line 101
    const/16 v2, 0x36

    .line 102
    .line 103
    invoke-static {v1, v7, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-static {v3, v0, v1, v2}, Lcom/facebook/aura/vds/compose/theme/AuraContainerKt;->ProvideAuraContainer(Lcom/facebook/aura/vds/compose/theme/AuraContainer;LX/JDN;LX/2d4;I)V

    .line 108
    .line 109
    .line 110
    :goto_5
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    if-eqz v0, :cond_7

    .line 115
    .line 116
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$2;

    .line 117
    .line 118
    invoke-direct/range {v7 .. v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$2;-><init>(LX/3C1;Ljava/lang/String;ZFZII)V

    .line 119
    .line 120
    .line 121
    iput-object v7, v0, LX/J7V;->A06:LX/JDN;

    .line 122
    .line 123
    :cond_7
    return-void

    .line 124
    :cond_8
    if-eqz v7, :cond_9

    .line 125
    .line 126
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 127
    .line 128
    :cond_9
    invoke-static {v9, v2}, LX/002;->A10(Ljava/lang/String;I)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v9

    .line 132
    if-eqz v6, :cond_a

    .line 133
    .line 134
    const/4 v10, 0x1

    .line 135
    :cond_a
    and-int/lit8 v0, p7, 0x8

    .line 136
    .line 137
    if-eqz v0, :cond_b

    .line 138
    .line 139
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 140
    .line 141
    :cond_b
    const/4 p0, 0x0

    .line 142
    if-nez v5, :cond_6

    .line 143
    .line 144
    goto :goto_4

    .line 145
    :cond_c
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 146
    .line 147
    .line 148
    move p0, v3

    .line 149
    goto :goto_5

    .line 150
    :cond_d
    and-int/lit16 v0, p1, 0x6000

    .line 151
    .line 152
    if-nez v0, :cond_5

    .line 153
    .line 154
    invoke-static {v1, v3}, LX/004;->A0m(LX/2d4;Z)I

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    or-int/2addr v4, v0

    .line 159
    goto :goto_3

    .line 160
    :cond_e
    and-int/lit16 v0, p1, 0x180

    .line 161
    .line 162
    if-nez v0, :cond_1

    .line 163
    .line 164
    invoke-static {v1, v10}, LX/004;->A0k(LX/2d4;Z)I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    or-int/2addr v4, v0

    .line 169
    goto/16 :goto_2

    .line 170
    .line 171
    :cond_f
    and-int/lit8 v0, p6, 0x30

    .line 172
    .line 173
    if-nez v0, :cond_0

    .line 174
    .line 175
    invoke-static {v1, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    or-int/2addr v4, v0

    .line 180
    goto/16 :goto_1

    .line 181
    .line 182
    :cond_10
    and-int/lit8 v0, p6, 0x6

    .line 183
    .line 184
    if-nez v0, :cond_11

    .line 185
    .line 186
    invoke-static {v1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 187
    .line 188
    .line 189
    move-result v4

    .line 190
    or-int v4, v4, p6

    .line 191
    .line 192
    goto/16 :goto_0

    .line 193
    .line 194
    :cond_11
    move v4, p1

    .line 195
    goto/16 :goto_0
.end method

.method public static final AgentPermissionPendingCardContainer-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V
    .locals 17

    .line 0
    move-object/from16 v13, p1

    .line 1
    .line 2
    move/from16 v14, p2

    .line 3
    .line 4
    move/from16 v15, p3

    .line 5
    .line 6
    move/from16 v7, p4

    .line 7
    .line 8
    move-object/from16 v12, p0

    .line 9
    .line 10
    const v0, 0x53bf043b

    .line 11
    .line 12
    .line 13
    move-object/from16 v6, p5

    .line 14
    .line 15
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v4, p7

    .line 19
    .line 20
    and-int/lit8 v11, p7, 0x1

    .line 21
    .line 22
    move/from16 v5, p6

    .line 23
    .line 24
    if-eqz v11, :cond_1d

    .line 25
    .line 26
    or-int/lit8 v0, p6, 0x6

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v10, p7, 0x2

    .line 29
    .line 30
    if-eqz v10, :cond_1c

    .line 31
    .line 32
    or-int/lit8 v0, v0, 0x30

    .line 33
    .line 34
    :cond_0
    :goto_1
    and-int/lit8 v9, p7, 0x4

    .line 35
    .line 36
    if-eqz v9, :cond_1b

    .line 37
    .line 38
    or-int/lit16 v0, v0, 0x180

    .line 39
    .line 40
    :cond_1
    :goto_2
    and-int/lit16 v1, v5, 0xc00

    .line 41
    .line 42
    if-nez v1, :cond_4

    .line 43
    .line 44
    and-int/lit8 v1, p7, 0x8

    .line 45
    .line 46
    if-nez v1, :cond_2

    .line 47
    .line 48
    invoke-interface {v6, v15}, LX/2d4;->A66(F)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    const/16 v1, 0x800

    .line 53
    .line 54
    if-nez v2, :cond_3

    .line 55
    .line 56
    :cond_2
    const/16 v1, 0x400

    .line 57
    .line 58
    :cond_3
    or-int/2addr v0, v1

    .line 59
    :cond_4
    and-int/lit8 v8, p7, 0x10

    .line 60
    .line 61
    if-eqz v8, :cond_1a

    .line 62
    .line 63
    or-int/lit16 v0, v0, 0x6000

    .line 64
    .line 65
    :cond_5
    :goto_3
    and-int/lit16 v2, v0, 0x2493

    .line 66
    .line 67
    const/16 v1, 0x2492

    .line 68
    .line 69
    const/4 v3, 0x0

    .line 70
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    invoke-static {v1, v6, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-eqz v1, :cond_15

    .line 79
    .line 80
    invoke-interface {v6}, LX/2d4;->AgT()V

    .line 81
    .line 82
    .line 83
    and-int/lit8 v1, p6, 0x1

    .line 84
    .line 85
    const/16 p0, 0x0

    .line 86
    .line 87
    if-eqz v1, :cond_10

    .line 88
    .line 89
    invoke-interface {v6}, LX/2d4;->AEs()Z

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    if-nez v1, :cond_10

    .line 94
    .line 95
    invoke-static {v4, v6, v0}, LX/003;->A0A(ILX/2d4;I)I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    :goto_4
    move/from16 v16, v7

    .line 100
    .line 101
    :cond_6
    invoke-interface {v6}, LX/2d4;->AAf()V

    .line 102
    .line 103
    .line 104
    invoke-static {v6}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-static {v13, v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->pendingApprovalsViewModelKey(Ljava/lang/String;Z)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v7

    .line 112
    new-instance v9, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$Factory;

    .line 113
    .line 114
    invoke-direct {v9, v1, v13, v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$Factory;-><init>(LX/AHE;Ljava/lang/String;Z)V

    .line 115
    .line 116
    .line 117
    invoke-static {v6}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    if-eqz v8, :cond_1f

    .line 122
    .line 123
    invoke-static {v8}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    const-class v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 128
    .line 129
    invoke-static {v9, v8, v2, v1, v7}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    check-cast v2, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 134
    .line 135
    iget-object v1, v2, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->approvals:LX/2J3;

    .line 136
    .line 137
    invoke-static {v6, v1, v3}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    invoke-static {v8}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    invoke-static {v1, v7, v6, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->rememberApprovalActionsEnabled(Ljava/util/List;Ljava/lang/String;LX/2d4;I)Z

    .line 146
    .line 147
    .line 148
    move-result p2

    .line 149
    invoke-interface {v6, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v7

    .line 157
    if-nez v1, :cond_7

    .line 158
    .line 159
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 160
    .line 161
    if-ne v7, v1, :cond_8

    .line 162
    .line 163
    :cond_7
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 164
    .line 165
    invoke-static {v6, v1}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 166
    .line 167
    .line 168
    move-result-object v7

    .line 169
    :cond_8
    check-cast v7, Landroidx/compose/runtime/MutableState;

    .line 170
    .line 171
    invoke-static {v6, v8, v7}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v9

    .line 175
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    if-nez v9, :cond_9

    .line 180
    .line 181
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 182
    .line 183
    if-ne v1, v9, :cond_a

    .line 184
    .line 185
    :cond_9
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$1$1;

    .line 186
    .line 187
    invoke-direct {v1, v7, v8}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$1$1;-><init>(Landroidx/compose/runtime/MutableState;LX/16A;)V

    .line 188
    .line 189
    .line 190
    invoke-interface {v6, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_a
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 194
    .line 195
    invoke-interface {v6, v1}, LX/2d4;->AaD(Lkotlin/jvm/functions/Function0;)V

    .line 196
    .line 197
    .line 198
    invoke-static {v8}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    if-eqz v16, :cond_b

    .line 203
    .line 204
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 205
    .line 206
    .line 207
    move-result v8

    .line 208
    if-eqz v8, :cond_b

    .line 209
    .line 210
    invoke-interface {v7}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    check-cast v1, Ljava/util/List;

    .line 215
    .line 216
    :cond_b
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 217
    .line 218
    .line 219
    move-result v7

    .line 220
    if-eqz v7, :cond_d

    .line 221
    .line 222
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    if-eqz v0, :cond_c

    .line 227
    .line 228
    new-instance v11, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$2;

    .line 229
    .line 230
    move/from16 p1, v4

    .line 231
    .line 232
    move/from16 p0, v5

    .line 233
    .line 234
    invoke-direct/range {v11 .. v18}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$2;-><init>(LX/3C1;Ljava/lang/String;ZFZII)V

    .line 235
    .line 236
    .line 237
    :goto_5
    invoke-static {v0, v11}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 238
    .line 239
    .line 240
    :cond_c
    return-void

    .line 241
    :cond_d
    move/from16 v7, v16

    .line 242
    .line 243
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 244
    .line 245
    .line 246
    move-result-object v10

    .line 247
    :cond_e
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 248
    .line 249
    .line 250
    move-result v8

    .line 251
    if-eqz v8, :cond_f

    .line 252
    .line 253
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v9

    .line 257
    move-object v8, v9

    .line 258
    check-cast v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 259
    .line 260
    invoke-static {v8}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->rendersCheckoutCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 261
    .line 262
    .line 263
    move-result v8

    .line 264
    if-eqz v8, :cond_e

    .line 265
    .line 266
    move-object/from16 p0, v9

    .line 267
    .line 268
    :cond_f
    check-cast p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 269
    .line 270
    const v10, 0xe000

    .line 271
    .line 272
    .line 273
    if-eqz p0, :cond_16

    .line 274
    .line 275
    const v1, -0x5e1c54c9

    .line 276
    .line 277
    .line 278
    invoke-interface {v6, v1}, LX/2d4;->Agj(I)V

    .line 279
    .line 280
    .line 281
    sget p6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 282
    .line 283
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->$stable:I

    .line 284
    .line 285
    shl-int/lit8 v1, v1, 0x3

    .line 286
    .line 287
    or-int p6, p6, v1

    .line 288
    .line 289
    shl-int/lit8 v1, v0, 0x9

    .line 290
    .line 291
    and-int/lit16 v1, v1, 0x1c00

    .line 292
    .line 293
    or-int p6, p6, v1

    .line 294
    .line 295
    shl-int/lit8 v0, v0, 0x3

    .line 296
    .line 297
    and-int/2addr v0, v10

    .line 298
    or-int p6, p6, v0

    .line 299
    .line 300
    move-object/from16 p3, v12

    .line 301
    .line 302
    move/from16 p4, v15

    .line 303
    .line 304
    move/from16 p7, v3

    .line 305
    .line 306
    move-object/from16 p1, v2

    .line 307
    .line 308
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->RichApprovalPendingCard-FJfuzF0(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V

    .line 309
    .line 310
    .line 311
    invoke-static {v6, v6}, LX/003;->A0W(LX/2d4;Ljava/lang/Object;)LX/J7V;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    if-eqz v0, :cond_c

    .line 316
    .line 317
    new-instance v11, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$3;

    .line 318
    .line 319
    move/from16 p0, v5

    .line 320
    .line 321
    move/from16 p1, v4

    .line 322
    .line 323
    invoke-direct/range {v11 .. v18}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$3;-><init>(LX/3C1;Ljava/lang/String;ZFZII)V

    .line 324
    .line 325
    .line 326
    goto :goto_5

    .line 327
    :cond_10
    if-eqz v11, :cond_11

    .line 328
    .line 329
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 330
    .line 331
    :cond_11
    if-eqz v10, :cond_12

    .line 332
    .line 333
    move-object/from16 v13, p0

    .line 334
    .line 335
    :cond_12
    if-eqz v9, :cond_13

    .line 336
    .line 337
    const/4 v14, 0x1

    .line 338
    :cond_13
    and-int/lit8 v1, p7, 0x8

    .line 339
    .line 340
    if-eqz v1, :cond_14

    .line 341
    .line 342
    sget v15, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 343
    .line 344
    and-int/lit16 v0, v0, -0x1c01

    .line 345
    .line 346
    :cond_14
    const/16 v16, 0x0

    .line 347
    .line 348
    if-nez v8, :cond_6

    .line 349
    .line 350
    goto/16 :goto_4

    .line 351
    .line 352
    :cond_15
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 353
    .line 354
    .line 355
    goto :goto_6

    .line 356
    :cond_16
    const v8, -0x5e18cfd9

    .line 357
    .line 358
    .line 359
    invoke-static {v6, v8}, LX/003;->A0q(LX/2d4;I)V

    .line 360
    .line 361
    .line 362
    invoke-interface {v6, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 363
    .line 364
    .line 365
    move-result v8

    .line 366
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    move-result-object v9

    .line 370
    if-nez v8, :cond_17

    .line 371
    .line 372
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 373
    .line 374
    if-ne v9, v8, :cond_18

    .line 375
    .line 376
    :cond_17
    invoke-static {v1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->partitionExclusiveApprovals(Ljava/util/List;)Ljava/util/List;

    .line 377
    .line 378
    .line 379
    move-result-object v9

    .line 380
    invoke-interface {v6, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 381
    .line 382
    .line 383
    :cond_18
    check-cast v9, Ljava/util/List;

    .line 384
    .line 385
    invoke-static {v9}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 386
    .line 387
    .line 388
    move-result-object v8

    .line 389
    check-cast v8, Ljava/util/List;

    .line 390
    .line 391
    if-eqz v8, :cond_19

    .line 392
    .line 393
    move-object v1, v8

    .line 394
    :cond_19
    sget v8, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->$stable:I

    .line 395
    .line 396
    shl-int/lit8 v9, v8, 0x3

    .line 397
    .line 398
    shl-int/lit8 v8, v0, 0x9

    .line 399
    .line 400
    and-int/lit16 v8, v8, 0x1c00

    .line 401
    .line 402
    or-int/2addr v9, v8

    .line 403
    shl-int/lit8 p5, v0, 0x3

    .line 404
    .line 405
    and-int p5, p5, v10

    .line 406
    .line 407
    or-int p5, p5, v9

    .line 408
    .line 409
    move-object/from16 v16, v1

    .line 410
    .line 411
    move-object/from16 p0, v2

    .line 412
    .line 413
    move/from16 p1, p2

    .line 414
    .line 415
    move-object/from16 p2, v12

    .line 416
    .line 417
    move/from16 p3, v15

    .line 418
    .line 419
    move-object/from16 p4, v6

    .line 420
    .line 421
    move/from16 p6, v3

    .line 422
    .line 423
    invoke-static/range {v16 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalCard-FJfuzF0(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V

    .line 424
    .line 425
    .line 426
    :goto_6
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 427
    .line 428
    .line 429
    move-result-object v0

    .line 430
    if-eqz v0, :cond_c

    .line 431
    .line 432
    new-instance v11, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$4;

    .line 433
    .line 434
    move/from16 v16, v7

    .line 435
    .line 436
    move/from16 p0, v5

    .line 437
    .line 438
    move/from16 p1, v4

    .line 439
    .line 440
    invoke-direct/range {v11 .. v18}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCardContainer$4;-><init>(LX/3C1;Ljava/lang/String;ZFZII)V

    .line 441
    .line 442
    .line 443
    goto/16 :goto_5

    .line 444
    .line 445
    :cond_1a
    and-int/lit16 v1, v5, 0x6000

    .line 446
    .line 447
    if-nez v1, :cond_5

    .line 448
    .line 449
    invoke-static {v6, v7}, LX/004;->A0m(LX/2d4;Z)I

    .line 450
    .line 451
    .line 452
    move-result v1

    .line 453
    or-int/2addr v0, v1

    .line 454
    goto/16 :goto_3

    .line 455
    .line 456
    :cond_1b
    and-int/lit16 v1, v5, 0x180

    .line 457
    .line 458
    if-nez v1, :cond_1

    .line 459
    .line 460
    invoke-static {v6, v14}, LX/004;->A0k(LX/2d4;Z)I

    .line 461
    .line 462
    .line 463
    move-result v1

    .line 464
    or-int/2addr v0, v1

    .line 465
    goto/16 :goto_2

    .line 466
    .line 467
    :cond_1c
    and-int/lit8 v1, p6, 0x30

    .line 468
    .line 469
    if-nez v1, :cond_0

    .line 470
    .line 471
    invoke-static {v6, v13}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 472
    .line 473
    .line 474
    move-result v1

    .line 475
    or-int/2addr v0, v1

    .line 476
    goto/16 :goto_1

    .line 477
    .line 478
    :cond_1d
    and-int/lit8 v0, p6, 0x6

    .line 479
    .line 480
    if-nez v0, :cond_1e

    .line 481
    .line 482
    invoke-static {v6, v12}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 483
    .line 484
    .line 485
    move-result v0

    .line 486
    or-int v0, v0, p6

    .line 487
    .line 488
    goto/16 :goto_0

    .line 489
    .line 490
    :cond_1e
    move v0, v5

    .line 491
    goto/16 :goto_0

    .line 492
    .line 493
    :cond_1f
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 494
    .line 495
    .line 496
    move-result-object v0

    .line 497
    throw v0
.end method

.method public static final AgentPermissionPendingCardContainer_hGBTI10$lambda$0(LX/16A;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;>;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final AgentPermissionPurposeCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V
    .locals 26

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    const/4 v7, 0x0

    .line 3
    move-object/from16 v5, p0

    .line 4
    .line 5
    move-object/from16 v8, p1

    .line 6
    .line 7
    invoke-static {v5, v8}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v14

    .line 11
    const v0, -0x6c716193

    .line 12
    .line 13
    .line 14
    move-object/from16 v3, p3

    .line 15
    .line 16
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 17
    .line 18
    .line 19
    move/from16 v2, p4

    .line 20
    .line 21
    and-int/lit8 v0, p4, 0x6

    .line 22
    .line 23
    if-nez v0, :cond_4

    .line 24
    .line 25
    invoke-static {v5, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0}, LX/003;->A06(I)I

    .line 30
    .line 31
    .line 32
    move-result v6

    .line 33
    or-int v6, v6, p4

    .line 34
    .line 35
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 36
    .line 37
    if-nez v0, :cond_0

    .line 38
    .line 39
    invoke-static {v3, v8}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v6, v0

    .line 44
    :cond_0
    and-int/lit8 v1, p5, 0x4

    .line 45
    .line 46
    if-eqz v1, :cond_3

    .line 47
    .line 48
    or-int/lit16 v6, v6, 0x180

    .line 49
    .line 50
    :cond_1
    :goto_1
    invoke-static {v6}, LX/005;->A1I(I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0, v3, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_7

    .line 59
    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    invoke-static {v4}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 69
    .line 70
    invoke-static {v3, v1, v7}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 71
    .line 72
    .line 73
    move-result-object v11

    .line 74
    move-object v1, v3

    .line 75
    check-cast v1, LX/J7I;

    .line 76
    .line 77
    iget-wide v9, v1, LX/J7I;->A06:J

    .line 78
    .line 79
    const/16 v24, 0x20

    .line 80
    .line 81
    invoke-static {v9, v10}, LX/001;->A0A(J)I

    .line 82
    .line 83
    .line 84
    move-result v13

    .line 85
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 86
    .line 87
    .line 88
    move-result-object v12

    .line 89
    invoke-static {v3, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v10

    .line 93
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 96
    .line 97
    if-nez v0, :cond_5

    .line 98
    .line 99
    invoke-static {}, LX/1VY;->A00()V

    .line 100
    .line 101
    .line 102
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    throw v0

    .line 107
    :cond_3
    and-int/lit16 v0, v2, 0x180

    .line 108
    .line 109
    if-nez v0, :cond_1

    .line 110
    .line 111
    invoke-static {v3, v4}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    or-int/2addr v6, v0

    .line 116
    goto :goto_1

    .line 117
    :cond_4
    move v6, v2

    .line 118
    goto :goto_0

    .line 119
    :cond_5
    invoke-static {v3, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v3, v11, v12, v10, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 123
    .line 124
    .line 125
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 126
    .line 127
    and-int/lit8 v9, v6, 0xe

    .line 128
    .line 129
    invoke-static {v0, v9, v6}, LX/3Rq;->A00(III)I

    .line 130
    .line 131
    .line 132
    move-result v9

    .line 133
    invoke-static {v5, v8, v3, v9}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionSubtitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V

    .line 134
    .line 135
    .line 136
    iget-object v9, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->attentionLabel:Ljava/lang/String;

    .line 137
    .line 138
    invoke-static {v5}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->attentionExplanation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v19

    .line 142
    const/16 v23, 0x4

    .line 143
    .line 144
    const/16 v20, 0x0

    .line 145
    .line 146
    move-object/from16 v18, v9

    .line 147
    .line 148
    move-object/from16 v21, v3

    .line 149
    .line 150
    move/from16 v22, v7

    .line 151
    .line 152
    invoke-static/range {v18 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionAttentionBanner(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 153
    .line 154
    .line 155
    iget-object v9, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->reviewText:Ljava/lang/String;

    .line 156
    .line 157
    const/16 p4, 0x6

    .line 158
    .line 159
    move-object/from16 v25, v9

    .line 160
    .line 161
    move-object/from16 p0, v20

    .line 162
    .line 163
    move/from16 p1, v7

    .line 164
    .line 165
    move-object/from16 p2, v3

    .line 166
    .line 167
    move/from16 p3, v7

    .line 168
    .line 169
    invoke-static/range {v25 .. v30}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionReviewText(Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 170
    .line 171
    .line 172
    invoke-static {v5}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->hasInlineRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 173
    .line 174
    .line 175
    move-result v9

    .line 176
    if-eqz v9, :cond_6

    .line 177
    .line 178
    const v9, -0x9911823

    .line 179
    .line 180
    .line 181
    invoke-interface {v3, v9}, LX/2d4;->Agj(I)V

    .line 182
    .line 183
    .line 184
    iget-object v15, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 185
    .line 186
    iget-object v10, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPreview:Ljava/lang/String;

    .line 187
    .line 188
    invoke-static {v5}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->hasRequestPreviewAttachments(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 189
    .line 190
    .line 191
    move-result v17

    .line 192
    invoke-static {v5}, Lcom/facebook/aura/gateway/ApprovalCardOnlyKt;->isConnectorOrderApproval(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 193
    .line 194
    .line 195
    move-result v21

    .line 196
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->$stable:I

    .line 197
    .line 198
    shl-int/lit8 v0, v0, 0x9

    .line 199
    .line 200
    or-int/2addr v9, v0

    .line 201
    shl-int/lit8 v6, v6, 0x9

    .line 202
    .line 203
    and-int/lit16 v0, v6, 0x1c00

    .line 204
    .line 205
    or-int/2addr v9, v0

    .line 206
    invoke-static {v6, v9}, LX/002;->A09(II)I

    .line 207
    .line 208
    .line 209
    move-result v23

    .line 210
    move-object/from16 v22, v3

    .line 211
    .line 212
    move-object/from16 v18, v5

    .line 213
    .line 214
    move-object/from16 v19, v8

    .line 215
    .line 216
    move-object/from16 v16, v10

    .line 217
    .line 218
    invoke-static/range {v15 .. v24}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->AgentPermissionInlineRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;ZLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;ZLX/2d4;II)V

    .line 219
    .line 220
    .line 221
    :goto_2
    invoke-static {v1, v4, v7, v14}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    goto :goto_3

    .line 226
    :cond_6
    const v0, -0x98be741

    .line 227
    .line 228
    .line 229
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 230
    .line 231
    .line 232
    goto :goto_2

    .line 233
    :cond_7
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 234
    .line 235
    .line 236
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    if-eqz v1, :cond_8

    .line 241
    .line 242
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPurposeCard$2;

    .line 243
    .line 244
    move-object/from16 p0, v0

    .line 245
    .line 246
    move-object/from16 p1, v5

    .line 247
    .line 248
    move-object/from16 p2, v8

    .line 249
    .line 250
    move-object/from16 p3, v4

    .line 251
    .line 252
    move/from16 p4, v2

    .line 253
    .line 254
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPurposeCard$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 255
    .line 256
    .line 257
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 258
    .line 259
    :cond_8
    return-void
.end method

.method public static final AgentPermissionReviewText(Ljava/lang/String;LX/3C1;ZLX/2d4;II)V
    .locals 26

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    move/from16 v2, p2

    .line 3
    .line 4
    const v0, -0x197b620e

    .line 5
    .line 6
    .line 7
    move-object/from16 v5, p3

    .line 8
    .line 9
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v4, p4

    .line 13
    .line 14
    and-int/lit8 v0, p4, 0x6

    .line 15
    .line 16
    move-object/from16 v6, p0

    .line 17
    .line 18
    if-nez v0, :cond_9

    .line 19
    .line 20
    invoke-static {v5, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v8

    .line 24
    or-int v8, v8, p4

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v7, p5, 0x2

    .line 27
    .line 28
    if-eqz v7, :cond_8

    .line 29
    .line 30
    or-int/lit8 v8, v8, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v1, p5, 0x4

    .line 33
    .line 34
    if-eqz v1, :cond_7

    .line 35
    .line 36
    or-int/lit16 v8, v8, 0x180

    .line 37
    .line 38
    :cond_1
    :goto_2
    invoke-static {v8}, LX/005;->A1I(I)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    invoke-static {v0, v5, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_6

    .line 47
    .line 48
    if-eqz v7, :cond_2

    .line 49
    .line 50
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 51
    .line 52
    :cond_2
    invoke-static {v1, v2}, LX/001;->A1Q(IZ)Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-eqz p0, :cond_5

    .line 57
    .line 58
    invoke-static {v6}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v12

    .line 62
    if-eqz v12, :cond_5

    .line 63
    .line 64
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-lez v0, :cond_5

    .line 69
    .line 70
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 71
    .line 72
    const/4 v1, 0x6

    .line 73
    invoke-static {v5, v8}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 74
    .line 75
    .line 76
    move-result-object v16

    .line 77
    invoke-static {v5, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 78
    .line 79
    .line 80
    move-result-wide v14

    .line 81
    const/4 v11, 0x5

    .line 82
    invoke-static {v3}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v7

    .line 86
    if-eqz v2, :cond_4

    .line 87
    .line 88
    const v0, 0x57d54547

    .line 89
    .line 90
    .line 91
    invoke-static {v5, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 92
    .line 93
    .line 94
    move-result-object v10

    .line 95
    invoke-virtual {v8, v5, v1}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 100
    .line 101
    const/high16 v8, 0x41400000    # 12.0f

    .line 102
    .line 103
    invoke-static {v8}, LX/2bA;->A00(F)LX/2bC;

    .line 104
    .line 105
    .line 106
    move-result-object v9

    .line 107
    invoke-static {v10, v9, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 112
    .line 113
    invoke-static {v1, v0, v8}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-static {v5}, LX/002;->A1Y(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v20

    .line 121
    :goto_3
    invoke-interface {v7, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 122
    .line 123
    .line 124
    move-result-object v13

    .line 125
    invoke-static {v11}, LX/2wS;->A01(I)LX/2wS;

    .line 126
    .line 127
    .line 128
    move-result-object v19

    .line 129
    const/16 p4, 0x3fb0

    .line 130
    .line 131
    const/16 v17, 0x0

    .line 132
    .line 133
    move-object/from16 v18, v17

    .line 134
    .line 135
    move/from16 v21, v20

    .line 136
    .line 137
    move/from16 v22, v20

    .line 138
    .line 139
    move/from16 v23, v20

    .line 140
    .line 141
    move-object/from16 v24, v17

    .line 142
    .line 143
    move-object/from16 v25, v17

    .line 144
    .line 145
    move-object/from16 p0, v17

    .line 146
    .line 147
    move-object/from16 p1, v5

    .line 148
    .line 149
    move/from16 p2, v20

    .line 150
    .line 151
    move/from16 p3, v20

    .line 152
    .line 153
    invoke-static/range {v12 .. v30}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 154
    .line 155
    .line 156
    :goto_4
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    if-eqz v1, :cond_3

    .line 161
    .line 162
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionReviewText$1;

    .line 163
    .line 164
    move-object/from16 p1, v6

    .line 165
    .line 166
    move-object/from16 p2, v3

    .line 167
    .line 168
    move/from16 p3, v2

    .line 169
    .line 170
    move/from16 p4, v4

    .line 171
    .line 172
    move-object/from16 p0, v0

    .line 173
    .line 174
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionReviewText$1;-><init>(Ljava/lang/String;LX/3C1;ZII)V

    .line 175
    .line 176
    .line 177
    :goto_5
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    :cond_3
    return-void

    .line 181
    :cond_4
    const v0, 0x57d54eba

    .line 182
    .line 183
    .line 184
    invoke-static {v5, v0}, LX/004;->A1T(LX/2d4;I)Z

    .line 185
    .line 186
    .line 187
    move-result v20

    .line 188
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 189
    .line 190
    goto :goto_3

    .line 191
    :cond_5
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    if-eqz v1, :cond_3

    .line 196
    .line 197
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionReviewText$text$2;

    .line 198
    .line 199
    move-object/from16 p1, v6

    .line 200
    .line 201
    move-object/from16 p2, v3

    .line 202
    .line 203
    move/from16 p3, v2

    .line 204
    .line 205
    move-object/from16 p0, v0

    .line 206
    .line 207
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionReviewText$text$2;-><init>(Ljava/lang/String;LX/3C1;ZII)V

    .line 208
    .line 209
    .line 210
    goto :goto_5

    .line 211
    :cond_6
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 212
    .line 213
    .line 214
    goto :goto_4

    .line 215
    :cond_7
    and-int/lit16 v0, v4, 0x180

    .line 216
    .line 217
    if-nez v0, :cond_1

    .line 218
    .line 219
    invoke-static {v5, v2}, LX/004;->A0k(LX/2d4;Z)I

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    or-int/2addr v8, v0

    .line 224
    goto/16 :goto_2

    .line 225
    .line 226
    :cond_8
    and-int/lit8 v0, p4, 0x30

    .line 227
    .line 228
    if-nez v0, :cond_0

    .line 229
    .line 230
    invoke-static {v5, v3}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 231
    .line 232
    .line 233
    move-result v0

    .line 234
    or-int/2addr v8, v0

    .line 235
    goto/16 :goto_1

    .line 236
    .line 237
    :cond_9
    move v8, v4

    .line 238
    goto/16 :goto_0
.end method

.method public static final AgentPermissionSubtitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V
    .locals 36

    .line 0
    const v1, -0x33efef12    # -3.776607E7f

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v3, p3

    .line 9
    .line 10
    and-int/lit8 v1, p3, 0x6

    .line 11
    .line 12
    move-object/from16 v4, p0

    .line 13
    .line 14
    if-nez v1, :cond_10

    .line 15
    .line 16
    invoke-static {v4, v0, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-static {v1}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v7

    .line 24
    or-int v7, v7, p3

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v1, p3, 0x30

    .line 27
    .line 28
    move-object/from16 v12, p1

    .line 29
    .line 30
    if-nez v1, :cond_0

    .line 31
    .line 32
    invoke-static {v0, v12}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    or-int/2addr v7, v1

    .line 37
    :cond_0
    and-int/lit8 v2, v7, 0x13

    .line 38
    .line 39
    const/16 v1, 0x12

    .line 40
    .line 41
    const/4 v10, 0x0

    .line 42
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    invoke-static {v1, v0, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_f

    .line 51
    .line 52
    invoke-static {v0}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    const v1, 0x7f12017d

    .line 57
    .line 58
    .line 59
    invoke-static {v0, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v11

    .line 63
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 64
    .line 65
    invoke-static {v0, v5}, LX/07H;->A07(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 66
    .line 67
    .line 68
    move-result-wide v1

    .line 69
    invoke-static {v4}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->purposeSummaryText(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v13

    .line 73
    invoke-static {v4}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->hasInlineRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 74
    .line 75
    .line 76
    move-result v8

    .line 77
    const/16 v17, 0x0

    .line 78
    .line 79
    if-nez v8, :cond_d

    .line 80
    .line 81
    invoke-static {v4}, Lcom/facebook/aura/agentpermission/AgentPermissionTaskDetailsSheetKt;->hasTaskDetailsBeyondSummary(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 82
    .line 83
    .line 84
    move-result v8

    .line 85
    if-eqz v8, :cond_d

    .line 86
    .line 87
    const v8, 0x1ac95f4

    .line 88
    .line 89
    .line 90
    invoke-static {v0, v8}, LX/003;->A0q(LX/2d4;I)V

    .line 91
    .line 92
    .line 93
    if-eqz v13, :cond_c

    .line 94
    .line 95
    invoke-static {v13}, LX/AdT;->A0L(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 96
    .line 97
    .line 98
    move-result-object v8

    .line 99
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v13

    .line 103
    if-eqz v13, :cond_c

    .line 104
    .line 105
    invoke-static {v13}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v8

    .line 109
    if-nez v8, :cond_c

    .line 110
    .line 111
    :goto_1
    invoke-static {v0, v13, v11}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v8

    .line 115
    invoke-static {v0, v1, v2, v8}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 116
    .line 117
    .line 118
    move-result v8

    .line 119
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v14

    .line 123
    if-nez v8, :cond_1

    .line 124
    .line 125
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 126
    .line 127
    if-ne v14, v8, :cond_3

    .line 128
    .line 129
    :cond_1
    invoke-static {}, LX/2b4;->A00()LX/2b4;

    .line 130
    .line 131
    .line 132
    move-result-object v9

    .line 133
    if-eqz v13, :cond_2

    .line 134
    .line 135
    invoke-virtual {v9, v13}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-static {v13}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->endsWithSentencePunctuation(Ljava/lang/String;)Z

    .line 139
    .line 140
    .line 141
    move-result v8

    .line 142
    if-eqz v8, :cond_b

    .line 143
    .line 144
    const-string v8, " "

    .line 145
    .line 146
    :goto_2
    invoke-virtual {v9, v8}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    :cond_2
    iget-object v13, v9, LX/2b4;->A00:Ljava/lang/StringBuilder;

    .line 150
    .line 151
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->length()I

    .line 152
    .line 153
    .line 154
    move-result v8

    .line 155
    invoke-virtual {v9, v11}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    sget-object v20, LX/2W8;->A03:LX/2W8;

    .line 159
    .line 160
    sget-wide v28, LX/2hw;->A01:J

    .line 161
    .line 162
    sget-wide v32, LX/JOw;->A07:J

    .line 163
    .line 164
    new-instance v11, LX/2hh;

    .line 165
    .line 166
    move-object v14, v11

    .line 167
    move-object/from16 v15, v17

    .line 168
    .line 169
    move-object/from16 v16, v15

    .line 170
    .line 171
    move-object/from16 v18, v15

    .line 172
    .line 173
    move-object/from16 v19, v15

    .line 174
    .line 175
    move-object/from16 v21, v15

    .line 176
    .line 177
    move-object/from16 v22, v15

    .line 178
    .line 179
    move-object/from16 v23, v15

    .line 180
    .line 181
    move-object/from16 v24, v15

    .line 182
    .line 183
    move-object/from16 v25, v15

    .line 184
    .line 185
    move-wide/from16 v26, v1

    .line 186
    .line 187
    move-wide/from16 v30, v28

    .line 188
    .line 189
    invoke-direct/range {v14 .. v33}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->length()I

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    invoke-virtual {v9, v11, v8, v1}, LX/2b4;->A0A(LX/2hh;II)V

    .line 197
    .line 198
    .line 199
    const-string v1, "aura://agent-permission/see-details"

    .line 200
    .line 201
    new-instance v2, LX/2D6;

    .line 202
    .line 203
    invoke-direct {v2, v1}, LX/2D6;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->length()I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    invoke-virtual {v9, v2, v8, v1}, LX/2b4;->A0B(LX/2D6;II)V

    .line 211
    .line 212
    .line 213
    invoke-static {v0, v9}, LX/3Rr;->A0C(LX/2d4;LX/2b4;)LX/2iK;

    .line 214
    .line 215
    .line 216
    move-result-object v14

    .line 217
    :cond_3
    check-cast v14, LX/2iK;

    .line 218
    .line 219
    invoke-static {v7}, LX/005;->A1H(I)Z

    .line 220
    .line 221
    .line 222
    move-result v8

    .line 223
    and-int/lit8 v2, v7, 0xe

    .line 224
    .line 225
    const/4 v1, 0x4

    .line 226
    if-eq v2, v1, :cond_4

    .line 227
    .line 228
    and-int/lit8 v1, v7, 0x8

    .line 229
    .line 230
    if-eqz v1, :cond_5

    .line 231
    .line 232
    invoke-interface {v0, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result v1

    .line 236
    if-eqz v1, :cond_5

    .line 237
    .line 238
    :cond_4
    const/4 v10, 0x1

    .line 239
    :cond_5
    invoke-static {v0, v6, v8, v10}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 240
    .line 241
    .line 242
    move-result v1

    .line 243
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v7

    .line 247
    if-nez v1, :cond_6

    .line 248
    .line 249
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 250
    .line 251
    if-ne v7, v1, :cond_7

    .line 252
    .line 253
    :cond_6
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$onSeeDetailsClick$1$1;

    .line 254
    .line 255
    invoke-direct {v7, v12, v4, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$onSeeDetailsClick$1$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 256
    .line 257
    .line 258
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    :cond_7
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 262
    .line 263
    invoke-static {v0, v5}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 264
    .line 265
    .line 266
    move-result-object v23

    .line 267
    invoke-static {v0, v5}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 268
    .line 269
    .line 270
    move-result-wide v21

    .line 271
    const/4 v5, 0x5

    .line 272
    sget-object v15, LX/2sI;->A02:LX/2wD;

    .line 273
    .line 274
    invoke-static {v0, v14, v7}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 275
    .line 276
    .line 277
    move-result v2

    .line 278
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object v1

    .line 282
    if-nez v2, :cond_8

    .line 283
    .line 284
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 285
    .line 286
    if-ne v1, v2, :cond_9

    .line 287
    .line 288
    :cond_8
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$2$1;

    .line 289
    .line 290
    invoke-direct {v1, v14, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$2$1;-><init>(LX/2iK;Lkotlin/jvm/functions/Function0;)V

    .line 291
    .line 292
    .line 293
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    :cond_9
    check-cast v1, LX/JDM;

    .line 297
    .line 298
    invoke-static {v5}, LX/2wS;->A01(I)LX/2wS;

    .line 299
    .line 300
    .line 301
    move-result-object v26

    .line 302
    const/16 v20, 0x0

    .line 303
    .line 304
    const p3, 0xff678

    .line 305
    .line 306
    .line 307
    const-wide/16 v27, 0x0

    .line 308
    .line 309
    const/16 p1, 0x30

    .line 310
    .line 311
    move-object/from16 v18, v17

    .line 312
    .line 313
    move-object/from16 v19, v17

    .line 314
    .line 315
    move-object/from16 v24, v17

    .line 316
    .line 317
    move-object/from16 v25, v17

    .line 318
    .line 319
    move/from16 v29, v20

    .line 320
    .line 321
    move/from16 v30, v20

    .line 322
    .line 323
    move/from16 v31, v20

    .line 324
    .line 325
    move/from16 v32, v20

    .line 326
    .line 327
    move-object/from16 v33, v17

    .line 328
    .line 329
    move-object/from16 v34, v17

    .line 330
    .line 331
    move-object/from16 v35, v17

    .line 332
    .line 333
    move-object/from16 p0, v0

    .line 334
    .line 335
    move/from16 p2, v20

    .line 336
    .line 337
    move-object/from16 v16, v1

    .line 338
    .line 339
    invoke-static/range {v14 .. v39}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraClickableText-ZsD2BWI(LX/2iK;LX/3C1;LX/JDM;LX/3C1;LX/JDM;LX/JDM;ZJLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 340
    .line 341
    .line 342
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    if-eqz v1, :cond_a

    .line 347
    .line 348
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$3;

    .line 349
    .line 350
    invoke-direct {v0, v4, v12, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;I)V

    .line 351
    .line 352
    .line 353
    :goto_4
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 354
    .line 355
    .line 356
    :cond_a
    return-void

    .line 357
    :cond_b
    const-string v8, ". "

    .line 358
    .line 359
    goto/16 :goto_2

    .line 360
    .line 361
    :cond_c
    move-object/from16 v13, v17

    .line 362
    .line 363
    goto/16 :goto_1

    .line 364
    .line 365
    :cond_d
    const v1, 0x1a84a0f

    .line 366
    .line 367
    .line 368
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 369
    .line 370
    .line 371
    if-eqz v13, :cond_e

    .line 372
    .line 373
    const v1, 0x1a8cea8    # 6.200999E-38f

    .line 374
    .line 375
    .line 376
    invoke-static {v0, v5, v1}, LX/002;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 377
    .line 378
    .line 379
    move-result-object v1

    .line 380
    iget-object v2, v1, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineRegular:LX/2hg;

    .line 381
    .line 382
    invoke-static {v0, v5}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 383
    .line 384
    .line 385
    move-result-wide v15

    .line 386
    const/4 v1, 0x5

    .line 387
    sget-object v14, LX/2sI;->A02:LX/2wD;

    .line 388
    .line 389
    invoke-static {v1}, LX/2wS;->A01(I)LX/2wS;

    .line 390
    .line 391
    .line 392
    move-result-object v20

    .line 393
    const/16 v31, 0x3fb0

    .line 394
    .line 395
    const/16 v29, 0x30

    .line 396
    .line 397
    move-object/from16 v18, v17

    .line 398
    .line 399
    move-object/from16 v19, v17

    .line 400
    .line 401
    move/from16 v21, v10

    .line 402
    .line 403
    move/from16 v22, v10

    .line 404
    .line 405
    move/from16 v23, v10

    .line 406
    .line 407
    move/from16 v24, v10

    .line 408
    .line 409
    move-object/from16 v25, v17

    .line 410
    .line 411
    move-object/from16 v26, v17

    .line 412
    .line 413
    move-object/from16 v27, v17

    .line 414
    .line 415
    move-object/from16 v28, v0

    .line 416
    .line 417
    move/from16 v30, v10

    .line 418
    .line 419
    move-object/from16 v17, v2

    .line 420
    .line 421
    invoke-static/range {v13 .. v31}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 422
    .line 423
    .line 424
    :goto_5
    invoke-static {v0}, LX/007;->A1M(Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 428
    .line 429
    .line 430
    move-result-object v1

    .line 431
    if-eqz v1, :cond_a

    .line 432
    .line 433
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$1;

    .line 434
    .line 435
    invoke-direct {v0, v4, v12, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionSubtitle$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;I)V

    .line 436
    .line 437
    .line 438
    goto :goto_4

    .line 439
    :cond_e
    const v1, 0x1ac5bd4

    .line 440
    .line 441
    .line 442
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 443
    .line 444
    .line 445
    goto :goto_5

    .line 446
    :cond_f
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 447
    .line 448
    .line 449
    goto :goto_3

    .line 450
    :cond_10
    move v7, v3

    .line 451
    goto/16 :goto_0
.end method

.method public static final ApprovalListRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 41
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v22, p2

    .line 1
    .line 2
    const/16 v21, 0x0

    .line 3
    .line 4
    move-object/from16 v6, p0

    .line 5
    .line 6
    move-object/from16 p2, p1

    .line 7
    .line 8
    move-object/from16 v0, p2

    .line 9
    .line 10
    invoke-static {v6, v0}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    const v1, 0x534237fe

    .line 15
    .line 16
    .line 17
    move-object/from16 v0, p3

    .line 18
    .line 19
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 20
    .line 21
    .line 22
    move/from16 v3, p4

    .line 23
    .line 24
    and-int/lit8 v1, p4, 0x6

    .line 25
    .line 26
    if-nez v1, :cond_4

    .line 27
    .line 28
    invoke-static {v6, v0, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-static {v1}, LX/003;->A06(I)I

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    or-int v5, v5, p4

    .line 37
    .line 38
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 39
    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    move-object/from16 v1, p2

    .line 43
    .line 44
    invoke-static {v0, v1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    or-int/2addr v5, v1

    .line 49
    :cond_0
    move/from16 p1, p5

    .line 50
    .line 51
    and-int/lit8 v4, p5, 0x4

    .line 52
    .line 53
    if-eqz v4, :cond_3

    .line 54
    .line 55
    or-int/lit16 v5, v5, 0x180

    .line 56
    .line 57
    :cond_1
    :goto_1
    invoke-static {v5}, LX/005;->A1I(I)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-static {v1, v0, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-eqz v1, :cond_7

    .line 66
    .line 67
    if-eqz v4, :cond_2

    .line 68
    .line 69
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 70
    .line 71
    :cond_2
    sget v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 72
    .line 73
    and-int/lit8 v1, v5, 0xe

    .line 74
    .line 75
    or-int/2addr v4, v1

    .line 76
    invoke-static {v6, v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionQuestion(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v20

    .line 80
    invoke-static {v6}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->purposeSummaryText(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v15

    .line 84
    const/16 v19, 0x0

    .line 85
    .line 86
    invoke-static/range {v22 .. v22}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    move-object/from16 v4, v19

    .line 91
    .line 92
    move-object/from16 v1, p2

    .line 93
    .line 94
    invoke-static {v5, v4, v1, v2}, LX/1Y9;->A00(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 95
    .line 96
    .line 97
    move-result-object v4

    .line 98
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 99
    .line 100
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 101
    .line 102
    invoke-static {v4, v1, v10}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 103
    .line 104
    .line 105
    move-result-object v8

    .line 106
    invoke-static {v0}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 107
    .line 108
    .line 109
    move-result-object v7

    .line 110
    move-object v1, v0

    .line 111
    check-cast v1, LX/J7I;

    .line 112
    .line 113
    iget-wide v4, v1, LX/J7I;->A06:J

    .line 114
    .line 115
    invoke-static {v4, v5}, LX/001;->A0A(J)I

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 120
    .line 121
    .line 122
    move-result-object v11

    .line 123
    invoke-static {v0, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 124
    .line 125
    .line 126
    move-result-object v5

    .line 127
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 128
    .line 129
    iget-object v4, v1, LX/J7I;->A0V:LX/3DJ;

    .line 130
    .line 131
    if-nez v4, :cond_5

    .line 132
    .line 133
    invoke-static {}, LX/1VY;->A00()V

    .line 134
    .line 135
    .line 136
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    throw v0

    .line 141
    :cond_3
    and-int/lit16 v1, v3, 0x180

    .line 142
    .line 143
    if-nez v1, :cond_1

    .line 144
    .line 145
    move-object/from16 v1, v22

    .line 146
    .line 147
    invoke-static {v0, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 148
    .line 149
    .line 150
    move-result v1

    .line 151
    or-int/2addr v5, v1

    .line 152
    goto :goto_1

    .line 153
    :cond_4
    move v5, v3

    .line 154
    goto :goto_0

    .line 155
    :cond_5
    invoke-static {v0, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 156
    .line 157
    .line 158
    sget-object v8, LX/3Cl;->A04:LX/JDN;

    .line 159
    .line 160
    invoke-static {v0, v7, v8}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 161
    .line 162
    .line 163
    move-result-object v7

    .line 164
    invoke-static {v0, v11, v7, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 165
    .line 166
    .line 167
    move-result-object v18

    .line 168
    sget-object v4, LX/3Cl;->A02:LX/JDM;

    .line 169
    .line 170
    invoke-static {v0, v5, v4}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 171
    .line 172
    .line 173
    move-result-object v17

    .line 174
    sget-object v11, LX/CgK;->A00:LX/CgK;

    .line 175
    .line 176
    iget-object v12, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 177
    .line 178
    iget-object v5, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 179
    .line 180
    sget v26, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 181
    .line 182
    sget v27, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 183
    .line 184
    invoke-static {v6}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 185
    .line 186
    .line 187
    move-result v28

    .line 188
    sget v29, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 189
    .line 190
    const/16 v34, 0x184

    .line 191
    .line 192
    move-object/from16 v23, v12

    .line 193
    .line 194
    move-object/from16 v24, v5

    .line 195
    .line 196
    move-object/from16 v25, v19

    .line 197
    .line 198
    move-object/from16 v30, v19

    .line 199
    .line 200
    move-object/from16 v31, v19

    .line 201
    .line 202
    move-object/from16 v32, v0

    .line 203
    .line 204
    move/from16 v33, v21

    .line 205
    .line 206
    invoke-static/range {v23 .. v34}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 207
    .line 208
    .line 209
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 210
    .line 211
    invoke-static {v0, v5, v10}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 212
    .line 213
    .line 214
    invoke-static {v11, v5, v2}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 215
    .line 216
    .line 217
    move-result-object v13

    .line 218
    const/high16 v11, 0x40000000    # 2.0f

    .line 219
    .line 220
    invoke-static {v11}, LX/Dn6;->A00(F)LX/CP5;

    .line 221
    .line 222
    .line 223
    move-result-object v14

    .line 224
    sget-object v12, LX/2Id;->A02:LX/2sS;

    .line 225
    .line 226
    const/16 v16, 0x6

    .line 227
    .line 228
    move/from16 v11, v16

    .line 229
    .line 230
    invoke-static {v14, v0, v12, v11}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 231
    .line 232
    .line 233
    move-result-object v14

    .line 234
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 235
    .line 236
    .line 237
    move-result v12

    .line 238
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 239
    .line 240
    .line 241
    move-result-object v11

    .line 242
    invoke-static {v0, v13}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 243
    .line 244
    .line 245
    move-result-object v13

    .line 246
    invoke-static {v0, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 247
    .line 248
    .line 249
    invoke-static {v0, v14, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 250
    .line 251
    .line 252
    invoke-static {v0, v11, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 253
    .line 254
    .line 255
    move-object/from16 v7, v18

    .line 256
    .line 257
    invoke-static {v4, v7, v0, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 258
    .line 259
    .line 260
    move-object/from16 v4, v17

    .line 261
    .line 262
    invoke-static {v0, v13, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 263
    .line 264
    .line 265
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 266
    .line 267
    invoke-static {v0, v4}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 268
    .line 269
    .line 270
    move-result-object v27

    .line 271
    invoke-static {v0, v4}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 272
    .line 273
    .line 274
    move-result-wide v25

    .line 275
    const/16 v33, 0x2

    .line 276
    .line 277
    const/16 p0, 0x39f2

    .line 278
    .line 279
    const/high16 v39, 0x30000000

    .line 280
    .line 281
    move-object/from16 v24, v19

    .line 282
    .line 283
    move-object/from16 v28, v19

    .line 284
    .line 285
    move-object/from16 v29, v19

    .line 286
    .line 287
    move/from16 v31, v21

    .line 288
    .line 289
    move/from16 v32, v21

    .line 290
    .line 291
    move/from16 v34, v33

    .line 292
    .line 293
    move-object/from16 v35, v19

    .line 294
    .line 295
    move-object/from16 v36, v19

    .line 296
    .line 297
    move-object/from16 v37, v19

    .line 298
    .line 299
    move-object/from16 v38, v0

    .line 300
    .line 301
    move/from16 v40, v16

    .line 302
    .line 303
    move-object/from16 v23, v20

    .line 304
    .line 305
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 306
    .line 307
    .line 308
    if-eqz v15, :cond_6

    .line 309
    .line 310
    move-object/from16 v7, v20

    .line 311
    .line 312
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 313
    .line 314
    .line 315
    move-result v7

    .line 316
    if-nez v7, :cond_6

    .line 317
    .line 318
    const v7, 0x29757378

    .line 319
    .line 320
    .line 321
    invoke-static {v0, v4, v7}, LX/3Rr;->A0D(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)LX/2hg;

    .line 322
    .line 323
    .line 324
    move-result-object v27

    .line 325
    invoke-static {v0, v4}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 326
    .line 327
    .line 328
    move-result-wide v25

    .line 329
    move-object/from16 v23, v15

    .line 330
    .line 331
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 332
    .line 333
    .line 334
    :goto_2
    move/from16 v7, v21

    .line 335
    .line 336
    invoke-static {v1, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 337
    .line 338
    .line 339
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 340
    .line 341
    .line 342
    invoke-static {v0, v5, v10}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 343
    .line 344
    .line 345
    const v7, 0x7f0800e8

    .line 346
    .line 347
    .line 348
    move/from16 v5, v21

    .line 349
    .line 350
    invoke-static {v0, v7, v5}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 351
    .line 352
    .line 353
    move-result-object v8

    .line 354
    invoke-static {v0, v4}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 355
    .line 356
    .line 357
    move-result-wide v11

    .line 358
    sget-object v9, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 359
    .line 360
    invoke-static {}, LX/2l9;->A04()I

    .line 361
    .line 362
    .line 363
    move-result v15

    .line 364
    const/16 v16, 0x21

    .line 365
    .line 366
    move-object/from16 v7, v19

    .line 367
    .line 368
    move-object v10, v7

    .line 369
    move-object v13, v7

    .line 370
    move-object v14, v0

    .line 371
    invoke-static/range {v7 .. v16}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 372
    .line 373
    .line 374
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 375
    .line 376
    .line 377
    goto :goto_3

    .line 378
    :cond_6
    const v7, 0x2978f1de

    .line 379
    .line 380
    .line 381
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 382
    .line 383
    .line 384
    goto :goto_2

    .line 385
    :cond_7
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 386
    .line 387
    .line 388
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 389
    .line 390
    .line 391
    move-result-object v1

    .line 392
    if-eqz v1, :cond_8

    .line 393
    .line 394
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListRow$2;

    .line 395
    .line 396
    move-object/from16 v37, v0

    .line 397
    .line 398
    move-object/from16 v38, v6

    .line 399
    .line 400
    move-object/from16 v39, p2

    .line 401
    .line 402
    move-object/from16 v40, v22

    .line 403
    .line 404
    move/from16 p0, v3

    .line 405
    .line 406
    invoke-direct/range {v37 .. v42}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 407
    .line 408
    .line 409
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 410
    .line 411
    :cond_8
    return-void
.end method

.method public static final ApprovalListSection(Ljava/util/List;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p2

    .line 1
    .line 2
    const v0, 0x7a61a2a7

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p3

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v14, p0

    .line 15
    .line 16
    if-nez v0, :cond_9

    .line 17
    .line 18
    invoke-static {v14, v6, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    or-int v4, v4, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v8, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v6, v8}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v4, v0

    .line 39
    :cond_0
    and-int/lit8 v9, p5, 0x4

    .line 40
    .line 41
    if-eqz v9, :cond_8

    .line 42
    .line 43
    or-int/lit16 v4, v4, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    and-int/lit16 v1, v4, 0x93

    .line 46
    .line 47
    const/16 v0, 0x92

    .line 48
    .line 49
    const/4 v3, 0x1

    .line 50
    const/4 v2, 0x0

    .line 51
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v6, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_a

    .line 60
    .line 61
    if-eqz v9, :cond_2

    .line 62
    .line 63
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 66
    .line 67
    const/4 v0, 0x6

    .line 68
    invoke-virtual {v11, v6, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iget v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 73
    .line 74
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 75
    .line 76
    .line 77
    move-result-object v10

    .line 78
    const/16 p1, 0x0

    .line 79
    .line 80
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    const/high16 v1, 0x431b0000    # 155.0f

    .line 85
    .line 86
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 87
    .line 88
    invoke-static {v9, v0, v1}, LX/2sI;->A0A(LX/3C1;FF)LX/3C1;

    .line 89
    .line 90
    .line 91
    move-result-object v9

    .line 92
    invoke-static {v6, v11}, LX/3Rs;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 93
    .line 94
    .line 95
    move-result-wide v0

    .line 96
    invoke-static {v9, v10, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {v0, v10}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    invoke-static {v6, v0}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-static {v6}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 109
    .line 110
    .line 111
    move-result-object v13

    .line 112
    move-object v10, v6

    .line 113
    check-cast v10, LX/J7I;

    .line 114
    .line 115
    invoke-static {v10}, LX/002;->A0J(LX/J7I;)I

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    invoke-static {v10}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 120
    .line 121
    .line 122
    move-result-object v11

    .line 123
    invoke-static {v6, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 124
    .line 125
    .line 126
    move-result-object v9

    .line 127
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 128
    .line 129
    iget-object v0, v10, LX/J7I;->A0V:LX/3DJ;

    .line 130
    .line 131
    if-nez v0, :cond_3

    .line 132
    .line 133
    invoke-static {}, LX/1VY;->A00()V

    .line 134
    .line 135
    .line 136
    :goto_2
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    throw v0

    .line 141
    :cond_3
    invoke-static {v6, v10, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v6, v13, v11, v9, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 145
    .line 146
    .line 147
    const v0, 0x407458f7

    .line 148
    .line 149
    .line 150
    invoke-static {v6, v14, v0}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 151
    .line 152
    .line 153
    move-result-object v12

    .line 154
    const/4 v1, 0x0

    .line 155
    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    if-eqz v0, :cond_b

    .line 160
    .line 161
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v15

    .line 165
    add-int/lit8 v11, v1, 0x1

    .line 166
    .line 167
    if-gez v1, :cond_4

    .line 168
    .line 169
    invoke-static {}, LX/B8B;->A1A()V

    .line 170
    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_4
    check-cast v15, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 174
    .line 175
    invoke-static {v4}, LX/004;->A1S(I)Z

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    invoke-static {v6, v15, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 180
    .line 181
    .line 182
    move-result v9

    .line 183
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    if-nez v9, :cond_5

    .line 188
    .line 189
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 190
    .line 191
    if-ne v0, v9, :cond_6

    .line 192
    .line 193
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListSection$1$1$1$1;

    .line 194
    .line 195
    invoke-direct {v0, v8, v15}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListSection$1$1$1$1;-><init>(LX/JDM;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 196
    .line 197
    .line 198
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    :cond_6
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 202
    .line 203
    sget p3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 204
    .line 205
    const/16 p4, 0x4

    .line 206
    .line 207
    move-object/from16 p2, v6

    .line 208
    .line 209
    move-object/from16 p0, v0

    .line 210
    .line 211
    invoke-static/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->ApprovalListRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 212
    .line 213
    .line 214
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 215
    .line 216
    .line 217
    move-result v0

    .line 218
    add-int/lit8 v0, v0, -0x1

    .line 219
    .line 220
    if-ge v1, v0, :cond_7

    .line 221
    .line 222
    const v0, 0x7314c3fc

    .line 223
    .line 224
    .line 225
    invoke-static {v6, v0}, LX/3Rs;->A0v(LX/2d4;I)V

    .line 226
    .line 227
    .line 228
    invoke-static {v10, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 229
    .line 230
    .line 231
    :goto_4
    move v1, v11

    .line 232
    goto :goto_3

    .line 233
    :cond_7
    const v0, 0x73161215

    .line 234
    .line 235
    .line 236
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 237
    .line 238
    .line 239
    invoke-static {v10, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 240
    .line 241
    .line 242
    goto :goto_4

    .line 243
    :cond_8
    and-int/lit16 v0, v5, 0x180

    .line 244
    .line 245
    if-nez v0, :cond_1

    .line 246
    .line 247
    invoke-static {v6, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 248
    .line 249
    .line 250
    move-result v0

    .line 251
    or-int/2addr v4, v0

    .line 252
    goto/16 :goto_1

    .line 253
    .line 254
    :cond_9
    move v4, v5

    .line 255
    goto/16 :goto_0

    .line 256
    .line 257
    :cond_a
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 258
    .line 259
    .line 260
    goto :goto_5

    .line 261
    :cond_b
    invoke-static {v10, v7, v2, v3}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 262
    .line 263
    .line 264
    move-result-object v7

    .line 265
    :goto_5
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 266
    .line 267
    .line 268
    move-result-object v1

    .line 269
    if-eqz v1, :cond_c

    .line 270
    .line 271
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListSection$2;

    .line 272
    .line 273
    move-object/from16 p1, v14

    .line 274
    .line 275
    move-object/from16 p2, v8

    .line 276
    .line 277
    move-object/from16 p3, v7

    .line 278
    .line 279
    move/from16 p4, v5

    .line 280
    .line 281
    move-object/from16 p0, v0

    .line 282
    .line 283
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$ApprovalListSection$2;-><init>(Ljava/util/List;LX/JDM;LX/3C1;II)V

    .line 284
    .line 285
    .line 286
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 287
    .line 288
    :cond_c
    return-void
.end method

.method public static final MultiApprovalContent(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            "Z",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, 0x6d19ac9d

    .line 1
    .line 2
    .line 3
    move-object/from16 v9, p3

    .line 4
    .line 5
    invoke-interface {v9, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v8, p4

    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    move-object/from16 v11, p0

    .line 13
    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    invoke-static {v11, v9, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v12

    .line 24
    or-int v12, v12, p4

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 27
    .line 28
    move-object/from16 v10, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-static {v10, v9, v8}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, LX/003;->A07(I)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v12, v0

    .line 41
    :cond_0
    and-int/lit16 v0, v8, 0x180

    .line 42
    .line 43
    move/from16 p4, p2

    .line 44
    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    move/from16 v0, p4

    .line 48
    .line 49
    invoke-static {v9, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    or-int/2addr v12, v0

    .line 54
    :cond_1
    and-int/lit16 v1, v12, 0x93

    .line 55
    .line 56
    const/16 v0, 0x92

    .line 57
    .line 58
    const/4 v7, 0x0

    .line 59
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-static {v0, v9, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_e

    .line 68
    .line 69
    invoke-static {v9}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 70
    .line 71
    .line 72
    move-result-object v13

    .line 73
    invoke-static {v11}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModelKt;->commonPermissionDecisionOptions(Ljava/util/List;)Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object v17

    .line 77
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 78
    .line 79
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 80
    .line 81
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->CardHorizontalPadding:F

    .line 82
    .line 83
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 84
    .line 85
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 86
    .line 87
    invoke-static {v2, v1, v0, v1, v5}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-static {v9}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 92
    .line 93
    .line 94
    move-result-object v15

    .line 95
    move-object v4, v9

    .line 96
    check-cast v4, LX/J7I;

    .line 97
    .line 98
    iget-wide v1, v4, LX/J7I;->A06:J

    .line 99
    .line 100
    const/16 v16, 0x20

    .line 101
    .line 102
    invoke-static {v1, v2}, LX/001;->A0A(J)I

    .line 103
    .line 104
    .line 105
    move-result v14

    .line 106
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    invoke-static {v9, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 115
    .line 116
    iget-object v0, v4, LX/J7I;->A0V:LX/3DJ;

    .line 117
    .line 118
    if-nez v0, :cond_3

    .line 119
    .line 120
    invoke-static {}, LX/1VY;->A00()V

    .line 121
    .line 122
    .line 123
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    throw v0

    .line 128
    :cond_2
    move v12, v8

    .line 129
    goto :goto_0

    .line 130
    :cond_3
    invoke-static {v9, v4, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v9, v15, v3, v2, v14}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 134
    .line 135
    .line 136
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    const/16 p0, 0x0

    .line 141
    .line 142
    const/4 v3, 0x0

    .line 143
    invoke-static {v6, v3, v3, v3, v5}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-static {v1, v0, v9, v7, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PendingHeader(ILX/3C1;LX/2d4;II)V

    .line 148
    .line 149
    .line 150
    and-int/lit8 v2, v12, 0xe

    .line 151
    .line 152
    const/4 v1, 0x4

    .line 153
    if-eq v2, v1, :cond_4

    .line 154
    .line 155
    and-int/lit8 v0, v12, 0x8

    .line 156
    .line 157
    if-eqz v0, :cond_d

    .line 158
    .line 159
    invoke-interface {v9, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_d

    .line 164
    .line 165
    :cond_4
    const/4 v0, 0x1

    .line 166
    :goto_1
    invoke-static {v9, v13, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 167
    .line 168
    .line 169
    move-result v5

    .line 170
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    if-nez v5, :cond_5

    .line 175
    .line 176
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 177
    .line 178
    if-ne v0, v5, :cond_6

    .line 179
    .line 180
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;

    .line 181
    .line 182
    invoke-direct {v0, v11, v13}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$1$1;-><init>(Ljava/util/List;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 183
    .line 184
    .line 185
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    :cond_6
    check-cast v0, LX/JDM;

    .line 189
    .line 190
    move-object/from16 v18, v11

    .line 191
    .line 192
    move-object/from16 v19, v0

    .line 193
    .line 194
    move-object/from16 p1, v9

    .line 195
    .line 196
    move/from16 p2, v2

    .line 197
    .line 198
    move/from16 p3, v1

    .line 199
    .line 200
    invoke-static/range {v18 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->ApprovalListSection(Ljava/util/List;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 201
    .line 202
    .line 203
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 204
    .line 205
    invoke-static {v6, v3, v0, v3, v3}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    if-eq v2, v1, :cond_7

    .line 210
    .line 211
    and-int/lit8 v0, v12, 0x8

    .line 212
    .line 213
    if-eqz v0, :cond_c

    .line 214
    .line 215
    invoke-interface {v9, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    if-eqz v0, :cond_c

    .line 220
    .line 221
    :cond_7
    const/4 v2, 0x1

    .line 222
    :goto_2
    and-int/lit8 v1, v12, 0x70

    .line 223
    .line 224
    move/from16 v0, v16

    .line 225
    .line 226
    if-eq v1, v0, :cond_8

    .line 227
    .line 228
    and-int/lit8 v0, v12, 0x40

    .line 229
    .line 230
    if-eqz v0, :cond_b

    .line 231
    .line 232
    invoke-interface {v9, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result v0

    .line 236
    if-eqz v0, :cond_b

    .line 237
    .line 238
    :cond_8
    const/4 v0, 0x1

    .line 239
    :goto_3
    or-int/2addr v2, v0

    .line 240
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v1

    .line 244
    if-nez v2, :cond_9

    .line 245
    .line 246
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 247
    .line 248
    if-ne v1, v0, :cond_a

    .line 249
    .line 250
    :cond_9
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;

    .line 251
    .line 252
    invoke-direct {v1, v11, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$1$2$1;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;)V

    .line 253
    .line 254
    .line 255
    invoke-interface {v9, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    :cond_a
    check-cast v1, LX/JDM;

    .line 259
    .line 260
    shr-int/lit8 v0, v12, 0x3

    .line 261
    .line 262
    and-int/lit8 p2, v0, 0x70

    .line 263
    .line 264
    move/from16 p3, v7

    .line 265
    .line 266
    move/from16 v18, p4

    .line 267
    .line 268
    move-object/from16 v19, v1

    .line 269
    .line 270
    invoke-static/range {v17 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PendingActionRow(Ljava/util/List;ZLX/JDM;LX/3C1;LX/2d4;II)V

    .line 271
    .line 272
    .line 273
    const/4 v0, 0x1

    .line 274
    invoke-static {v4, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 275
    .line 276
    .line 277
    goto :goto_4

    .line 278
    :cond_b
    const/4 v0, 0x0

    .line 279
    goto :goto_3

    .line 280
    :cond_c
    const/4 v2, 0x0

    .line 281
    goto :goto_2

    .line 282
    :cond_d
    const/4 v0, 0x0

    .line 283
    goto :goto_1

    .line 284
    :cond_e
    invoke-interface {v9}, LX/2d4;->AgJ()V

    .line 285
    .line 286
    .line 287
    :goto_4
    invoke-interface {v9}, LX/2d4;->AAg()LX/J7V;

    .line 288
    .line 289
    .line 290
    move-result-object v2

    .line 291
    if-eqz v2, :cond_f

    .line 292
    .line 293
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$2;

    .line 294
    .line 295
    move/from16 v0, p4

    .line 296
    .line 297
    invoke-direct {v1, v11, v10, v0, v8}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$MultiApprovalContent$2;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZI)V

    .line 298
    .line 299
    .line 300
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 301
    .line 302
    :cond_f
    return-void
.end method

.method public static final PendingActionRow(Ljava/util/List;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;Z",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p3

    .line 1
    .line 2
    const v0, 0xb0f9cf0

    .line 3
    .line 4
    .line 5
    move-object/from16 v8, p4

    .line 6
    .line 7
    invoke-interface {v8, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v7, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v15, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v15, v8, v7}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    or-int v6, v6, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 29
    .line 30
    move/from16 v26, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    move/from16 v0, v26

    .line 35
    .line 36
    invoke-static {v8, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v6, v0

    .line 41
    :cond_0
    and-int/lit16 v0, v7, 0x180

    .line 42
    .line 43
    move-object/from16 v13, p2

    .line 44
    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    invoke-static {v8, v13}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v6, v0

    .line 52
    :cond_1
    and-int/lit8 v2, p6, 0x8

    .line 53
    .line 54
    if-eqz v2, :cond_4

    .line 55
    .line 56
    or-int/lit16 v6, v6, 0xc00

    .line 57
    .line 58
    :cond_2
    :goto_1
    and-int/lit16 v1, v6, 0x493

    .line 59
    .line 60
    const/16 v0, 0x492

    .line 61
    .line 62
    const/4 v5, 0x1

    .line 63
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    invoke-static {v0, v8, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_b

    .line 72
    .line 73
    if-eqz v2, :cond_3

    .line 74
    .line 75
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 76
    .line 77
    :cond_3
    invoke-static {v15}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v11

    .line 81
    sget-object v10, LX/2sI;->A02:LX/2wD;

    .line 82
    .line 83
    invoke-interface {v9, v10}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    const/high16 v0, 0x41000000    # 8.0f

    .line 88
    .line 89
    invoke-static {v8, v0}, LX/3Rs;->A09(LX/2d4;F)LX/3BI;

    .line 90
    .line 91
    .line 92
    move-result-object v14

    .line 93
    move-object v4, v8

    .line 94
    check-cast v4, LX/J7I;

    .line 95
    .line 96
    invoke-static {v4}, LX/003;->A0F(LX/J7I;)I

    .line 97
    .line 98
    .line 99
    move-result v12

    .line 100
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    invoke-static {v8, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 109
    .line 110
    iget-object v0, v4, LX/J7I;->A0V:LX/3DJ;

    .line 111
    .line 112
    if-nez v0, :cond_6

    .line 113
    .line 114
    invoke-static {}, LX/1VY;->A00()V

    .line 115
    .line 116
    .line 117
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    throw v0

    .line 122
    :cond_4
    and-int/lit16 v0, v7, 0xc00

    .line 123
    .line 124
    if-nez v0, :cond_2

    .line 125
    .line 126
    invoke-static {v8, v9}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    or-int/2addr v6, v0

    .line 131
    goto :goto_1

    .line 132
    :cond_5
    move v6, v7

    .line 133
    goto :goto_0

    .line 134
    :cond_6
    invoke-static {v8, v4, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 135
    .line 136
    .line 137
    invoke-static {v8, v14, v3, v2, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 138
    .line 139
    .line 140
    const v0, 0x69eb8d6f

    .line 141
    .line 142
    .line 143
    invoke-static {v8, v15, v0}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 144
    .line 145
    .line 146
    move-result-object v16

    .line 147
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-eqz v0, :cond_c

    .line 152
    .line 153
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v12

    .line 157
    check-cast v12, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 158
    .line 159
    iget-object v14, v12, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->labelText:Ljava/lang/String;

    .line 160
    .line 161
    invoke-virtual {v12, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    const/16 v1, 0x30

    .line 166
    .line 167
    if-eqz v0, :cond_a

    .line 168
    .line 169
    const v0, -0x750826cb

    .line 170
    .line 171
    .line 172
    invoke-interface {v8, v0}, LX/2d4;->Agj(I)V

    .line 173
    .line 174
    .line 175
    sget-object v0, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 176
    .line 177
    const/4 v3, 0x0

    .line 178
    invoke-virtual {v0, v3, v8, v1, v5}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 179
    .line 180
    .line 181
    move-result-object v21

    .line 182
    const/4 v0, 0x0

    .line 183
    invoke-static {v4, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 184
    .line 185
    .line 186
    :goto_3
    sget-object v22, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->MEDIUM:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 187
    .line 188
    invoke-static {v6}, LX/005;->A1J(I)Z

    .line 189
    .line 190
    .line 191
    move-result v1

    .line 192
    invoke-static {v8, v12, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    invoke-interface {v8}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v2

    .line 200
    if-nez v1, :cond_7

    .line 201
    .line 202
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 203
    .line 204
    if-ne v2, v1, :cond_8

    .line 205
    .line 206
    :cond_7
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;

    .line 207
    .line 208
    invoke-direct {v2, v13, v12}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;-><init>(LX/JDM;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 209
    .line 210
    .line 211
    invoke-interface {v8, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_8
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 215
    .line 216
    invoke-interface {v8}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v1

    .line 220
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 221
    .line 222
    if-ne v1, v12, :cond_9

    .line 223
    .line 224
    sget-object v1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$2$1;

    .line 225
    .line 226
    invoke-interface {v8, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :cond_9
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 230
    .line 231
    shl-int/lit8 p2, v6, 0x18

    .line 232
    .line 233
    const/high16 v12, 0x70000000

    .line 234
    .line 235
    and-int p2, p2, v12

    .line 236
    .line 237
    const v12, 0x30c00

    .line 238
    .line 239
    .line 240
    or-int p2, p2, v12

    .line 241
    .line 242
    const/16 p4, 0x6030

    .line 243
    .line 244
    const p5, 0x6dfbdc5

    .line 245
    .line 246
    .line 247
    move-object/from16 v19, v3

    .line 248
    .line 249
    move-object/from16 v23, v3

    .line 250
    .line 251
    move/from16 v24, v0

    .line 252
    .line 253
    move/from16 v25, v0

    .line 254
    .line 255
    move/from16 v27, v0

    .line 256
    .line 257
    move/from16 v28, v0

    .line 258
    .line 259
    move-object/from16 v29, v3

    .line 260
    .line 261
    move-object/from16 v30, v3

    .line 262
    .line 263
    move-object/from16 v31, v2

    .line 264
    .line 265
    move-object/from16 v32, v3

    .line 266
    .line 267
    move-object/from16 v33, v3

    .line 268
    .line 269
    move-object/from16 v34, v3

    .line 270
    .line 271
    move-object/from16 v35, v3

    .line 272
    .line 273
    move-object/from16 v36, v3

    .line 274
    .line 275
    move-object/from16 v37, v3

    .line 276
    .line 277
    move-object/from16 v38, v1

    .line 278
    .line 279
    move-object/from16 v39, v3

    .line 280
    .line 281
    move/from16 v40, v0

    .line 282
    .line 283
    move/from16 v41, v5

    .line 284
    .line 285
    move/from16 v42, v0

    .line 286
    .line 287
    move/from16 p0, v0

    .line 288
    .line 289
    move-object/from16 p1, v8

    .line 290
    .line 291
    move/from16 p3, v0

    .line 292
    .line 293
    move-object/from16 v18, v14

    .line 294
    .line 295
    move-object/from16 v20, v10

    .line 296
    .line 297
    move-object/from16 v17, v3

    .line 298
    .line 299
    invoke-static/range {v17 .. v48}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 300
    .line 301
    .line 302
    goto/16 :goto_2

    .line 303
    .line 304
    :cond_a
    const/4 v3, 0x0

    .line 305
    const v0, -0x75082109

    .line 306
    .line 307
    .line 308
    invoke-interface {v8, v0}, LX/2d4;->Agj(I)V

    .line 309
    .line 310
    .line 311
    sget-object v0, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 312
    .line 313
    invoke-virtual {v0, v3, v8, v1, v5}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 314
    .line 315
    .line 316
    move-result-object v21

    .line 317
    const/4 v0, 0x0

    .line 318
    invoke-static {v4, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 319
    .line 320
    .line 321
    goto/16 :goto_3

    .line 322
    .line 323
    :cond_b
    invoke-interface {v8}, LX/2d4;->AgJ()V

    .line 324
    .line 325
    .line 326
    goto :goto_4

    .line 327
    :cond_c
    const/4 v0, 0x0

    .line 328
    invoke-static {v4, v9, v0, v5}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 329
    .line 330
    .line 331
    move-result-object v9

    .line 332
    :goto_4
    invoke-interface {v8}, LX/2d4;->AAg()LX/J7V;

    .line 333
    .line 334
    .line 335
    move-result-object v1

    .line 336
    if-eqz v1, :cond_d

    .line 337
    .line 338
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$2;

    .line 339
    .line 340
    move/from16 p2, v26

    .line 341
    .line 342
    move-object/from16 p3, v13

    .line 343
    .line 344
    move-object/from16 p4, v9

    .line 345
    .line 346
    move/from16 p5, v7

    .line 347
    .line 348
    move-object/from16 p0, v0

    .line 349
    .line 350
    move-object/from16 p1, v15

    .line 351
    .line 352
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$2;-><init>(Ljava/util/List;ZLX/JDM;LX/3C1;II)V

    .line 353
    .line 354
    .line 355
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 356
    .line 357
    :cond_d
    return-void
.end method

.method public static final PendingHeader(ILX/3C1;LX/2d4;II)V
    .locals 20

    .line 0
    move-object/from16 v2, p1

    .line 1
    .line 2
    const v0, 0x174be667

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v1, v5}, LX/004;->A0E(LX/2d4;I)I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    or-int v8, v8, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v3, p4

    .line 25
    .line 26
    and-int/lit8 v7, p4, 0x2

    .line 27
    .line 28
    if-eqz v7, :cond_4

    .line 29
    .line 30
    or-int/lit8 v8, v8, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v6, v8, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v14, 0x0

    .line 37
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v1, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_3

    .line 46
    .line 47
    if-eqz v7, :cond_1

    .line 48
    .line 49
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 50
    .line 51
    :cond_1
    const v0, 0x7f10000a

    .line 52
    .line 53
    .line 54
    invoke-static {v5, v1, v0}, LX/18b;->A02(ILX/2d4;I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    invoke-static {v1, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v8

    .line 68
    const/4 v11, 0x0

    .line 69
    invoke-static {v2}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    const/16 p4, 0x3ff0

    .line 74
    .line 75
    move-object v12, v11

    .line 76
    move-object v13, v11

    .line 77
    move v15, v14

    .line 78
    move/from16 v16, v14

    .line 79
    .line 80
    move/from16 v17, v14

    .line 81
    .line 82
    move-object/from16 v18, v11

    .line 83
    .line 84
    move-object/from16 v19, v11

    .line 85
    .line 86
    move-object/from16 p0, v11

    .line 87
    .line 88
    move-object/from16 p1, v1

    .line 89
    .line 90
    move/from16 p2, v14

    .line 91
    .line 92
    move/from16 p3, v14

    .line 93
    .line 94
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 95
    .line 96
    .line 97
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    if-eqz v1, :cond_2

    .line 102
    .line 103
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingHeader$1;

    .line 104
    .line 105
    invoke-direct {v0, v5, v2, v4, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingHeader$1;-><init>(ILX/3C1;II)V

    .line 106
    .line 107
    .line 108
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 109
    .line 110
    :cond_2
    return-void

    .line 111
    :cond_3
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 112
    .line 113
    .line 114
    goto :goto_2

    .line 115
    :cond_4
    and-int/lit8 v0, p3, 0x30

    .line 116
    .line 117
    if-nez v0, :cond_0

    .line 118
    .line 119
    invoke-static {v1, v2}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    or-int/2addr v8, v0

    .line 124
    goto :goto_1

    .line 125
    :cond_5
    move v8, v4

    .line 126
    goto :goto_0
.end method

.method public static final PermissionCaption(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2hg;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v13, p1

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    move-object/from16 v4, p0

    .line 4
    .line 5
    invoke-static {v4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v1, 0x4456d891

    .line 9
    .line 10
    .line 11
    move-object/from16 v3, p2

    .line 12
    .line 13
    invoke-interface {v3, v1}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p3

    .line 17
    .line 18
    and-int/lit8 v1, p3, 0x6

    .line 19
    .line 20
    if-nez v1, :cond_8

    .line 21
    .line 22
    invoke-static {v4, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-static {v1}, LX/003;->A06(I)I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    or-int v6, v6, p3

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v5, p3, 0x30

    .line 33
    .line 34
    move/from16 v1, p4

    .line 35
    .line 36
    if-nez v5, :cond_2

    .line 37
    .line 38
    and-int/lit8 v5, p4, 0x2

    .line 39
    .line 40
    if-nez v5, :cond_0

    .line 41
    .line 42
    invoke-interface {v3, v13}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    const/16 v5, 0x20

    .line 47
    .line 48
    if-nez v7, :cond_1

    .line 49
    .line 50
    :cond_0
    const/16 v5, 0x10

    .line 51
    .line 52
    :cond_1
    or-int/2addr v6, v5

    .line 53
    :cond_2
    invoke-static {v6}, LX/005;->A1G(I)Z

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    invoke-static {v5, v3, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    if-eqz v5, :cond_7

    .line 62
    .line 63
    invoke-interface {v3}, LX/2d4;->AgT()V

    .line 64
    .line 65
    .line 66
    and-int/lit8 v5, p3, 0x1

    .line 67
    .line 68
    const/4 v8, 0x6

    .line 69
    if-eqz v5, :cond_6

    .line 70
    .line 71
    invoke-interface {v3}, LX/2d4;->AEs()Z

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    if-nez v5, :cond_6

    .line 76
    .line 77
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 78
    .line 79
    .line 80
    and-int/lit8 v5, p4, 0x2

    .line 81
    .line 82
    if-eqz v5, :cond_3

    .line 83
    .line 84
    :goto_1
    and-int/lit8 v6, v6, -0x71

    .line 85
    .line 86
    :cond_3
    invoke-interface {v3}, LX/2d4;->AAf()V

    .line 87
    .line 88
    .line 89
    invoke-static {v4}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->permissionCaptionText(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v7

    .line 93
    if-nez v7, :cond_5

    .line 94
    .line 95
    const v0, -0x49a14c8b

    .line 96
    .line 97
    .line 98
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 99
    .line 100
    .line 101
    :goto_2
    invoke-static {v3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    if-eqz v3, :cond_4

    .line 109
    .line 110
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PermissionCaption$2;

    .line 111
    .line 112
    invoke-direct {v0, v4, v13, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PermissionCaption$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2hg;II)V

    .line 113
    .line 114
    .line 115
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 116
    .line 117
    :cond_4
    return-void

    .line 118
    :cond_5
    const v5, -0x49a14c8a

    .line 119
    .line 120
    .line 121
    invoke-interface {v3, v5}, LX/2d4;->Agj(I)V

    .line 122
    .line 123
    .line 124
    invoke-static {v7, v3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt;->rememberPermissionCaptionText(Ljava/lang/String;LX/2d4;I)LX/2iK;

    .line 125
    .line 126
    .line 127
    move-result-object v9

    .line 128
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 129
    .line 130
    invoke-static {v3, v5}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 131
    .line 132
    .line 133
    move-result-wide v11

    .line 134
    const/4 v5, 0x5

    .line 135
    const/4 v14, 0x0

    .line 136
    sget-object v10, LX/2sI;->A02:LX/2wD;

    .line 137
    .line 138
    invoke-static {v5}, LX/2wS;->A01(I)LX/2wS;

    .line 139
    .line 140
    .line 141
    move-result-object v16

    .line 142
    shl-int/2addr v6, v8

    .line 143
    and-int/lit16 v5, v6, 0x1c00

    .line 144
    .line 145
    or-int/lit8 p2, v5, 0x30

    .line 146
    .line 147
    const/16 p4, 0x7fb0

    .line 148
    .line 149
    const-wide/16 v17, 0x0

    .line 150
    .line 151
    move-object v15, v14

    .line 152
    move/from16 v20, v0

    .line 153
    .line 154
    move/from16 v21, v0

    .line 155
    .line 156
    move/from16 v22, v0

    .line 157
    .line 158
    move-object/from16 v23, v14

    .line 159
    .line 160
    move-object/from16 v24, v14

    .line 161
    .line 162
    move-object/from16 p0, v14

    .line 163
    .line 164
    move-object/from16 p1, v3

    .line 165
    .line 166
    move/from16 p3, v0

    .line 167
    .line 168
    move/from16 v19, v0

    .line 169
    .line 170
    invoke-static/range {v9 .. v29}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 171
    .line 172
    .line 173
    goto :goto_2

    .line 174
    :cond_6
    and-int/lit8 v5, p4, 0x2

    .line 175
    .line 176
    if-eqz v5, :cond_3

    .line 177
    .line 178
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 179
    .line 180
    invoke-static {v3, v5}, LX/3Rq;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 181
    .line 182
    .line 183
    move-result-object v13

    .line 184
    goto :goto_1

    .line 185
    :cond_7
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 186
    .line 187
    .line 188
    goto :goto_3

    .line 189
    :cond_8
    move v6, v2

    .line 190
    goto/16 :goto_0
.end method

.method public static final PermissionCardDivider(LX/2d4;I)V
    .locals 5

    .line 0
    const v0, -0x41cde223

    .line 1
    .line 2
    .line 3
    move-object v3, p0

    .line 4
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle$Elevated;->INSTANCE:Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle$Elevated;

    .line 18
    .line 19
    const/16 v4, 0x30

    .line 20
    .line 21
    const/4 p0, 0x5

    .line 22
    const/4 v0, 0x0

    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraDivider(LX/3C1;Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle;ZLX/2d4;II)V

    .line 25
    .line 26
    .line 27
    :goto_0
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PermissionCardDivider$1;

    .line 34
    .line 35
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PermissionCardDivider$1;-><init>(I)V

    .line 36
    .line 37
    .line 38
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 39
    .line 40
    :cond_0
    return-void

    .line 41
    :cond_1
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 42
    .line 43
    .line 44
    goto :goto_0
.end method

.method public static final RichApprovalPendingCard-FJfuzF0(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V
    .locals 15

    .line 0
    move-object/from16 v5, p3

    .line 1
    .line 2
    move/from16 v4, p4

    .line 3
    .line 4
    const v0, -0x5343cac0

    .line 5
    .line 6
    .line 7
    move-object/from16 v7, p5

    .line 8
    .line 9
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v3, p6

    .line 13
    .line 14
    and-int/lit8 v0, p6, 0x6

    .line 15
    .line 16
    const/4 v12, 0x4

    .line 17
    if-nez v0, :cond_12

    .line 18
    .line 19
    invoke-static {p0, v7, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0}, LX/003;->A06(I)I

    .line 24
    .line 25
    .line 26
    move-result v9

    .line 27
    or-int v9, v9, p6

    .line 28
    .line 29
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 30
    .line 31
    const/16 v11, 0x20

    .line 32
    .line 33
    move-object/from16 v6, p1

    .line 34
    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    invoke-static {v6, v7, v3}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0}, LX/003;->A07(I)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v9, v0

    .line 46
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 47
    .line 48
    move/from16 v10, p2

    .line 49
    .line 50
    if-nez v0, :cond_1

    .line 51
    .line 52
    invoke-static {v7, v10}, LX/004;->A0k(LX/2d4;Z)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    or-int/2addr v9, v0

    .line 57
    :cond_1
    move/from16 v2, p7

    .line 58
    .line 59
    and-int/lit8 v8, p7, 0x8

    .line 60
    .line 61
    if-eqz v8, :cond_11

    .line 62
    .line 63
    or-int/lit16 v9, v9, 0xc00

    .line 64
    .line 65
    :cond_2
    :goto_1
    and-int/lit16 v0, v3, 0x6000

    .line 66
    .line 67
    if-nez v0, :cond_5

    .line 68
    .line 69
    and-int/lit8 v0, p7, 0x10

    .line 70
    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    invoke-interface {v7, v4}, LX/2d4;->A66(F)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    const/16 v0, 0x4000

    .line 78
    .line 79
    if-nez v1, :cond_4

    .line 80
    .line 81
    :cond_3
    const/16 v0, 0x2000

    .line 82
    .line 83
    :cond_4
    or-int/2addr v9, v0

    .line 84
    :cond_5
    and-int/lit16 v1, v9, 0x2493

    .line 85
    .line 86
    const/16 v0, 0x2492

    .line 87
    .line 88
    const/4 v14, 0x1

    .line 89
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-static {v0, v7, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_10

    .line 98
    .line 99
    invoke-interface {v7}, LX/2d4;->AgT()V

    .line 100
    .line 101
    .line 102
    and-int/lit8 v0, p6, 0x1

    .line 103
    .line 104
    const v1, -0xe001

    .line 105
    .line 106
    .line 107
    if-eqz v0, :cond_e

    .line 108
    .line 109
    invoke-interface {v7}, LX/2d4;->AEs()Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-nez v0, :cond_e

    .line 114
    .line 115
    invoke-static {v2, v7, v9}, LX/004;->A06(ILX/2d4;I)I

    .line 116
    .line 117
    .line 118
    move-result v9

    .line 119
    :cond_6
    :goto_2
    invoke-interface {v7}, LX/2d4;->AAf()V

    .line 120
    .line 121
    .line 122
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->submittingApprovalIds:LX/2J3;

    .line 123
    .line 124
    const/4 v1, 0x0

    .line 125
    invoke-static {v7, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 126
    .line 127
    .line 128
    move-result-object v8

    .line 129
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->confirmingApprovalIds:LX/2J3;

    .line 130
    .line 131
    invoke-static {v7, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 132
    .line 133
    .line 134
    move-result-object v13

    .line 135
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 136
    .line 137
    invoke-interface {v8}, LX/16A;->getValue()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    check-cast v8, Ljava/util/Set;

    .line 142
    .line 143
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 144
    .line 145
    invoke-interface {v8, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result p2

    .line 149
    and-int/lit8 v8, v9, 0xe

    .line 150
    .line 151
    if-eq v8, v12, :cond_7

    .line 152
    .line 153
    and-int/lit8 v0, v9, 0x8

    .line 154
    .line 155
    if-eqz v0, :cond_d

    .line 156
    .line 157
    invoke-interface {v7, p0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    if-eqz v0, :cond_d

    .line 162
    .line 163
    :cond_7
    const/4 v12, 0x1

    .line 164
    :goto_3
    and-int/lit8 v0, v9, 0x70

    .line 165
    .line 166
    if-eq v0, v11, :cond_8

    .line 167
    .line 168
    and-int/lit8 v0, v9, 0x40

    .line 169
    .line 170
    if-eqz v0, :cond_c

    .line 171
    .line 172
    invoke-interface {v7, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    if-eqz v0, :cond_c

    .line 177
    .line 178
    :cond_8
    :goto_4
    or-int/2addr v12, v14

    .line 179
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    if-nez v12, :cond_9

    .line 184
    .line 185
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 186
    .line 187
    if-ne v0, v11, :cond_a

    .line 188
    .line 189
    :cond_9
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$RichApprovalPendingCard$1$1;

    .line 190
    .line 191
    invoke-direct {v0, p0, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$RichApprovalPendingCard$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;)V

    .line 192
    .line 193
    .line 194
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    :cond_a
    check-cast v0, LX/JDM;

    .line 198
    .line 199
    invoke-interface {v13}, LX/16A;->getValue()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v12

    .line 203
    check-cast v12, Ljava/util/Set;

    .line 204
    .line 205
    iget-object v11, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 206
    .line 207
    invoke-interface {v12, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result p7

    .line 211
    const/16 p4, 0x1

    .line 212
    .line 213
    new-instance v14, Lcom/facebook/aura/agentpermission/RichApprovalSurface;

    .line 214
    .line 215
    move/from16 p3, v10

    .line 216
    .line 217
    move/from16 p5, v1

    .line 218
    .line 219
    move-object/from16 p6, v0

    .line 220
    .line 221
    invoke-direct/range {v14 .. v22}, Lcom/facebook/aura/agentpermission/RichApprovalSurface;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZZZZLX/JDM;Z)V

    .line 222
    .line 223
    .line 224
    shr-int/lit8 v0, v9, 0x9

    .line 225
    .line 226
    and-int/lit8 v11, v0, 0xe

    .line 227
    .line 228
    sget v12, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 229
    .line 230
    shl-int/lit8 v0, v12, 0x3

    .line 231
    .line 232
    or-int/2addr v11, v0

    .line 233
    shl-int/lit8 v0, v9, 0x3

    .line 234
    .line 235
    and-int/lit8 v0, v0, 0x70

    .line 236
    .line 237
    or-int/2addr v11, v0

    .line 238
    shr-int/lit8 v0, v9, 0x6

    .line 239
    .line 240
    and-int/lit16 v0, v0, 0x380

    .line 241
    .line 242
    or-int/2addr v11, v0

    .line 243
    invoke-static {v5, p0, v4, v7, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->pendingRichApprovalCard-TDGSqEk(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;FLX/2d4;I)LX/3C1;

    .line 244
    .line 245
    .line 246
    move-result-object p2

    .line 247
    or-int/2addr v12, v8

    .line 248
    sget v0, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->$stable:I

    .line 249
    .line 250
    shl-int/lit8 p4, v0, 0x3

    .line 251
    .line 252
    or-int p4, p4, v12

    .line 253
    .line 254
    move-object/from16 p1, v14

    .line 255
    .line 256
    move-object/from16 p3, v7

    .line 257
    .line 258
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/RichApprovalCardKt;->RichApprovalCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/3C1;LX/2d4;II)V

    .line 259
    .line 260
    .line 261
    :goto_5
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    if-eqz v0, :cond_b

    .line 266
    .line 267
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$RichApprovalPendingCard$2;

    .line 268
    .line 269
    move-object v8, p0

    .line 270
    move-object v9, v6

    .line 271
    move-object v11, v5

    .line 272
    move v12, v4

    .line 273
    move v13, v3

    .line 274
    move v14, v2

    .line 275
    invoke-direct/range {v7 .. v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$RichApprovalPendingCard$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FII)V

    .line 276
    .line 277
    .line 278
    iput-object v7, v0, LX/J7V;->A06:LX/JDN;

    .line 279
    .line 280
    :cond_b
    return-void

    .line 281
    :cond_c
    const/4 v14, 0x0

    .line 282
    goto :goto_4

    .line 283
    :cond_d
    const/4 v12, 0x0

    .line 284
    goto :goto_3

    .line 285
    :cond_e
    if-eqz v8, :cond_f

    .line 286
    .line 287
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 288
    .line 289
    :cond_f
    and-int/lit8 v0, p7, 0x10

    .line 290
    .line 291
    if-eqz v0, :cond_6

    .line 292
    .line 293
    sget v4, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 294
    .line 295
    and-int/2addr v9, v1

    .line 296
    goto/16 :goto_2

    .line 297
    .line 298
    :cond_10
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 299
    .line 300
    .line 301
    goto :goto_5

    .line 302
    :cond_11
    and-int/lit16 v0, v3, 0xc00

    .line 303
    .line 304
    if-nez v0, :cond_2

    .line 305
    .line 306
    invoke-static {v7, v5}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    or-int/2addr v9, v0

    .line 311
    goto/16 :goto_1

    .line 312
    .line 313
    :cond_12
    move v9, v3

    .line 314
    goto/16 :goto_0
.end method

.method public static final RichApprovalPendingCard_FJfuzF0$lambda$0(LX/16A;)Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/util/Set;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final RichApprovalPendingCard_FJfuzF0$lambda$1(LX/16A;)Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/util/Set;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SingleApprovalContent(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V
    .locals 19

    .line 0
    const v0, 0x2625b6f1

    .line 1
    .line 2
    .line 3
    move-object/from16 v6, p3

    .line 4
    .line 5
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p4

    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    const/4 v11, 0x4

    .line 13
    move-object/from16 v12, p0

    .line 14
    .line 15
    if-nez v0, :cond_c

    .line 16
    .line 17
    invoke-static {v12, v6, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0}, LX/003;->A06(I)I

    .line 22
    .line 23
    .line 24
    move-result v9

    .line 25
    or-int v9, v9, p4

    .line 26
    .line 27
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 28
    .line 29
    const/16 v5, 0x20

    .line 30
    .line 31
    move-object/from16 v4, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static {v4, v6, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0}, LX/003;->A07(I)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v9, v0

    .line 44
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 45
    .line 46
    move/from16 v3, p2

    .line 47
    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    invoke-static {v6, v3}, LX/004;->A0k(LX/2d4;Z)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v9, v0

    .line 55
    :cond_1
    invoke-static {v9}, LX/005;->A1I(I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    invoke-static {v0, v6, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_b

    .line 64
    .line 65
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->submittingApprovalIds:LX/2J3;

    .line 66
    .line 67
    const/4 v7, 0x0

    .line 68
    const/16 p0, 0x0

    .line 69
    .line 70
    invoke-static {v6, v0, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->confirmingApprovalIds:LX/2J3;

    .line 75
    .line 76
    invoke-static {v6, v0, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 77
    .line 78
    .line 79
    move-result-object v10

    .line 80
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    check-cast v1, Ljava/util/Set;

    .line 85
    .line 86
    iget-object v0, v12, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 87
    .line 88
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v8

    .line 92
    and-int/lit8 v7, v9, 0xe

    .line 93
    .line 94
    if-eq v7, v11, :cond_2

    .line 95
    .line 96
    and-int/lit8 v0, v9, 0x8

    .line 97
    .line 98
    if-eqz v0, :cond_a

    .line 99
    .line 100
    invoke-interface {v6, v12}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_a

    .line 105
    .line 106
    :cond_2
    const/4 v1, 0x1

    .line 107
    :goto_1
    and-int/lit8 v0, v9, 0x70

    .line 108
    .line 109
    if-eq v0, v5, :cond_3

    .line 110
    .line 111
    and-int/lit8 v0, v9, 0x40

    .line 112
    .line 113
    if-eqz v0, :cond_9

    .line 114
    .line 115
    invoke-interface {v6, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_9

    .line 120
    .line 121
    :cond_3
    const/4 v0, 0x1

    .line 122
    :goto_2
    or-int/2addr v1, v0

    .line 123
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v5

    .line 127
    if-nez v1, :cond_4

    .line 128
    .line 129
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 130
    .line 131
    if-ne v5, v0, :cond_5

    .line 132
    .line 133
    :cond_4
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalContent$onDecision$1$1;

    .line 134
    .line 135
    invoke-direct {v5, v12, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalContent$onDecision$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;)V

    .line 136
    .line 137
    .line 138
    invoke-interface {v6, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    :cond_5
    check-cast v5, LX/JDN;

    .line 142
    .line 143
    sget-object v13, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 144
    .line 145
    sget v14, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->CardHorizontalPadding:F

    .line 146
    .line 147
    if-eqz p2, :cond_6

    .line 148
    .line 149
    const/4 v15, 0x1

    .line 150
    if-eqz v8, :cond_7

    .line 151
    .line 152
    :cond_6
    const/4 v15, 0x0

    .line 153
    :cond_7
    sget-object v9, LX/2sI;->A02:LX/2wD;

    .line 154
    .line 155
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 156
    .line 157
    const/4 v1, 0x0

    .line 158
    const/high16 v0, 0x41c00000    # 24.0f

    .line 159
    .line 160
    invoke-static {v9, v1, v0, v1, v8}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 161
    .line 162
    .line 163
    move-result-object v17

    .line 164
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v8

    .line 168
    check-cast v8, Ljava/util/Set;

    .line 169
    .line 170
    iget-object v0, v12, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 171
    .line 172
    invoke-interface {v8, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    move-result p1

    .line 176
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 177
    .line 178
    or-int/lit16 v0, v0, 0x1b0

    .line 179
    .line 180
    or-int/2addr v0, v7

    .line 181
    const/16 p4, 0xc0

    .line 182
    .line 183
    move-object/from16 p2, v6

    .line 184
    .line 185
    move/from16 p3, v0

    .line 186
    .line 187
    move/from16 v18, v1

    .line 188
    .line 189
    move-object/from16 v16, v5

    .line 190
    .line 191
    invoke-static/range {v12 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalContent-7UH0Qls(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZLX/2d4;II)V

    .line 192
    .line 193
    .line 194
    :goto_3
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    if-eqz v1, :cond_8

    .line 199
    .line 200
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalContent$1;

    .line 201
    .line 202
    invoke-direct {v0, v12, v4, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalContent$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZI)V

    .line 203
    .line 204
    .line 205
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 206
    .line 207
    :cond_8
    return-void

    .line 208
    :cond_9
    const/4 v0, 0x0

    .line 209
    goto :goto_2

    .line 210
    :cond_a
    const/4 v1, 0x0

    .line 211
    goto :goto_1

    .line 212
    :cond_b
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 213
    .line 214
    .line 215
    goto :goto_3

    .line 216
    :cond_c
    move v9, v2

    .line 217
    goto/16 :goto_0
.end method

.method public static final SingleApprovalContent$lambda$0(LX/16A;)Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/util/Set;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SingleApprovalContent$lambda$1(LX/16A;)Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/util/Set;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SingleApprovalTitleRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V
    .locals 35

    .line 0
    move-object/from16 v11, p3

    .line 1
    .line 2
    const v1, 0x2523e57e

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p5

    .line 11
    .line 12
    and-int/lit8 v1, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    if-nez v1, :cond_5

    .line 17
    .line 18
    invoke-static {v2, v0, v4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    or-int v1, v1, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v3, p5, 0x30

    .line 29
    .line 30
    move-object/from16 v15, p1

    .line 31
    .line 32
    if-nez v3, :cond_0

    .line 33
    .line 34
    invoke-static {v0, v15}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    or-int/2addr v1, v3

    .line 39
    :cond_0
    and-int/lit16 v3, v4, 0x180

    .line 40
    .line 41
    move/from16 p5, p2

    .line 42
    .line 43
    if-nez v3, :cond_1

    .line 44
    .line 45
    move/from16 v3, p5

    .line 46
    .line 47
    invoke-static {v0, v3}, LX/004;->A0k(LX/2d4;Z)I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    or-int/2addr v1, v3

    .line 52
    :cond_1
    move/from16 p4, p6

    .line 53
    .line 54
    and-int/lit8 v5, p6, 0x8

    .line 55
    .line 56
    if-eqz v5, :cond_4

    .line 57
    .line 58
    or-int/lit16 v1, v1, 0xc00

    .line 59
    .line 60
    :cond_2
    :goto_1
    invoke-static {v1}, LX/005;->A1K(I)Z

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    invoke-static {v3, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_e

    .line 69
    .line 70
    if-eqz v5, :cond_3

    .line 71
    .line 72
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 73
    .line 74
    :cond_3
    invoke-static {v11}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    invoke-static {v0}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 79
    .line 80
    .line 81
    move-result-object v10

    .line 82
    move-object v5, v0

    .line 83
    check-cast v5, LX/J7I;

    .line 84
    .line 85
    iget-wide v6, v5, LX/J7I;->A06:J

    .line 86
    .line 87
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 88
    .line 89
    .line 90
    move-result v9

    .line 91
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 92
    .line 93
    .line 94
    move-result-object v8

    .line 95
    invoke-static {v0, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 96
    .line 97
    .line 98
    move-result-object v7

    .line 99
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 100
    .line 101
    iget-object v3, v5, LX/J7I;->A0V:LX/3DJ;

    .line 102
    .line 103
    if-nez v3, :cond_6

    .line 104
    .line 105
    invoke-static {}, LX/1VY;->A00()V

    .line 106
    .line 107
    .line 108
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0

    .line 113
    :cond_4
    and-int/lit16 v3, v4, 0xc00

    .line 114
    .line 115
    if-nez v3, :cond_2

    .line 116
    .line 117
    invoke-static {v0, v11}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 118
    .line 119
    .line 120
    move-result v3

    .line 121
    or-int/2addr v1, v3

    .line 122
    goto :goto_1

    .line 123
    :cond_5
    move v1, v4

    .line 124
    goto :goto_0

    .line 125
    :cond_6
    invoke-static {v0, v5, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v0, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 129
    .line 130
    .line 131
    sget-object v6, LX/CgK;->A00:LX/CgK;

    .line 132
    .line 133
    iget-object v7, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 134
    .line 135
    iget-object v3, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 136
    .line 137
    invoke-virtual {v3}, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->getRendersAsConnectorCard()Z

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    const/16 v19, 0x0

    .line 142
    .line 143
    if-eqz v3, :cond_7

    .line 144
    .line 145
    move-object/from16 v19, v7

    .line 146
    .line 147
    :cond_7
    iget-object v3, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 148
    .line 149
    sget v22, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 150
    .line 151
    sget v23, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 152
    .line 153
    invoke-static {v2}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 154
    .line 155
    .line 156
    move-result v24

    .line 157
    sget v25, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 158
    .line 159
    const/4 v9, 0x0

    .line 160
    const/16 v30, 0x184

    .line 161
    .line 162
    const/16 v21, 0x0

    .line 163
    .line 164
    move-object/from16 v20, v3

    .line 165
    .line 166
    move-object/from16 v26, v21

    .line 167
    .line 168
    move-object/from16 v27, v21

    .line 169
    .line 170
    move-object/from16 v28, v0

    .line 171
    .line 172
    move/from16 v29, v9

    .line 173
    .line 174
    invoke-static/range {v19 .. v30}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 175
    .line 176
    .line 177
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 178
    .line 179
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 180
    .line 181
    invoke-static {v0, v3, v7}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 182
    .line 183
    .line 184
    sget v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 185
    .line 186
    and-int/lit8 v12, v1, 0xe

    .line 187
    .line 188
    or-int/2addr v7, v12

    .line 189
    invoke-static {v2, v0, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionQuestion(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v16

    .line 193
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 194
    .line 195
    const/4 v14, 0x6

    .line 196
    invoke-static {v0, v7}, LX/07H;->A0M(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 197
    .line 198
    .line 199
    move-result-object v20

    .line 200
    invoke-static {v0, v7}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 201
    .line 202
    .line 203
    move-result-wide v18

    .line 204
    const/4 v8, 0x5

    .line 205
    const/high16 v7, 0x3f800000    # 1.0f

    .line 206
    .line 207
    const/4 v13, 0x1

    .line 208
    invoke-virtual {v6, v3, v7, v13}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 209
    .line 210
    .line 211
    move-result-object v7

    .line 212
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v6

    .line 216
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 217
    .line 218
    if-ne v6, v10, :cond_8

    .line 219
    .line 220
    sget-object v6, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$1$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$1$2$1;

    .line 221
    .line 222
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    :cond_8
    invoke-static {v7, v6, v9}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 226
    .line 227
    .line 228
    move-result-object v17

    .line 229
    invoke-static {v8}, LX/2wS;->A01(I)LX/2wS;

    .line 230
    .line 231
    .line 232
    move-result-object v23

    .line 233
    const/16 v34, 0x3fb0

    .line 234
    .line 235
    const/4 v6, 0x1

    .line 236
    move-object/from16 v22, v21

    .line 237
    .line 238
    move/from16 v24, v9

    .line 239
    .line 240
    move/from16 v25, v9

    .line 241
    .line 242
    move/from16 v26, v9

    .line 243
    .line 244
    move/from16 v27, v9

    .line 245
    .line 246
    move-object/from16 v28, v21

    .line 247
    .line 248
    move-object/from16 v29, v21

    .line 249
    .line 250
    move-object/from16 v30, v21

    .line 251
    .line 252
    move-object/from16 v31, v0

    .line 253
    .line 254
    move/from16 v32, v9

    .line 255
    .line 256
    move/from16 v33, v9

    .line 257
    .line 258
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 259
    .line 260
    .line 261
    iget-boolean v7, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->editableMessageAvailable:Z

    .line 262
    .line 263
    if-eqz v7, :cond_d

    .line 264
    .line 265
    const v7, 0x7e95ee5a

    .line 266
    .line 267
    .line 268
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 269
    .line 270
    .line 271
    invoke-static {v0}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 272
    .line 273
    .line 274
    move-result-object v7

    .line 275
    const v8, 0x7f080284

    .line 276
    .line 277
    .line 278
    invoke-static {v0, v8, v9}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 279
    .line 280
    .line 281
    move-result-object v23

    .line 282
    sget-object v24, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;->XM_LARGE:Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;

    .line 283
    .line 284
    sget-object v8, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;

    .line 285
    .line 286
    invoke-virtual {v8, v0, v14}, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;->flat(LX/2d4;I)Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;

    .line 287
    .line 288
    .line 289
    move-result-object v25

    .line 290
    const v8, 0x7f12010b

    .line 291
    .line 292
    .line 293
    invoke-static {v0, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object v26

    .line 297
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 298
    .line 299
    invoke-static {v3, v8}, LX/3Rr;->A09(LX/3C1;F)LX/3C1;

    .line 300
    .line 301
    .line 302
    move-result-object v22

    .line 303
    invoke-static {v1}, LX/004;->A1S(I)Z

    .line 304
    .line 305
    .line 306
    move-result v8

    .line 307
    const/4 v3, 0x4

    .line 308
    if-eq v12, v3, :cond_9

    .line 309
    .line 310
    and-int/lit8 v3, v1, 0x8

    .line 311
    .line 312
    if-eqz v3, :cond_c

    .line 313
    .line 314
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 315
    .line 316
    .line 317
    move-result v3

    .line 318
    if-eqz v3, :cond_c

    .line 319
    .line 320
    :cond_9
    :goto_2
    invoke-static {v0, v7, v8, v6}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 321
    .line 322
    .line 323
    move-result v6

    .line 324
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v3

    .line 328
    if-nez v6, :cond_a

    .line 329
    .line 330
    if-ne v3, v10, :cond_b

    .line 331
    .line 332
    :cond_a
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$1$3$1;

    .line 333
    .line 334
    invoke-direct {v3, v15, v2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$1$3$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 335
    .line 336
    .line 337
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    :cond_b
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 341
    .line 342
    invoke-static {}, LX/2l9;->A03()I

    .line 343
    .line 344
    .line 345
    move-result v6

    .line 346
    shl-int/lit8 v1, v1, 0xf

    .line 347
    .line 348
    invoke-static {v1, v6}, LX/002;->A0A(II)I

    .line 349
    .line 350
    .line 351
    move-result p1

    .line 352
    const/16 p3, 0x1f40

    .line 353
    .line 354
    move-object/from16 v27, v3

    .line 355
    .line 356
    move/from16 v29, p5

    .line 357
    .line 358
    move-object/from16 v31, v21

    .line 359
    .line 360
    move-object/from16 v32, v21

    .line 361
    .line 362
    move-object/from16 v33, v21

    .line 363
    .line 364
    move-object/from16 v34, v21

    .line 365
    .line 366
    move-object/from16 p0, v0

    .line 367
    .line 368
    move/from16 p2, v9

    .line 369
    .line 370
    invoke-static/range {v22 .. v38}, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonKt;->AuraIconButtonV2-X32rcYo(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLX/JOw;LX/1Ot;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonBackground;LX/3Gw;Ljava/lang/String;LX/2d4;III)V

    .line 371
    .line 372
    .line 373
    :goto_3
    invoke-static {v5, v11, v9, v13}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 374
    .line 375
    .line 376
    move-result-object v11

    .line 377
    goto :goto_4

    .line 378
    :cond_c
    const/4 v6, 0x0

    .line 379
    goto :goto_2

    .line 380
    :cond_d
    const v1, 0x7e9f6760

    .line 381
    .line 382
    .line 383
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 384
    .line 385
    .line 386
    goto :goto_3

    .line 387
    :cond_e
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 388
    .line 389
    .line 390
    :goto_4
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 391
    .line 392
    .line 393
    move-result-object v1

    .line 394
    if-eqz v1, :cond_f

    .line 395
    .line 396
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$2;

    .line 397
    .line 398
    move-object/from16 v33, v0

    .line 399
    .line 400
    move-object/from16 v34, v2

    .line 401
    .line 402
    move-object/from16 p0, v15

    .line 403
    .line 404
    move/from16 p1, p5

    .line 405
    .line 406
    move-object/from16 p2, v11

    .line 407
    .line 408
    move/from16 p3, v4

    .line 409
    .line 410
    invoke-direct/range {v33 .. v39}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$SingleApprovalTitleRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;II)V

    .line 411
    .line 412
    .line 413
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 414
    .line 415
    :cond_f
    return-void
.end method

.method public static final synthetic access$AgentPermissionApprovalCard-FJfuzF0(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalCard-FJfuzF0(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgentPermissionApprovalHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgentPermissionPendingCardContainer-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionPendingCardContainer-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgentPermissionPendingCardContainer_hGBTI10$lambda$0(LX/16A;)Ljava/util/List;
    .locals 0

    .line 0
    invoke-static {p0}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$AgentPermissionSubtitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionSubtitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalListSection(Ljava/util/List;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->ApprovalListSection(Ljava/util/List;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MultiApprovalContent(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->MultiApprovalContent(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PendingActionRow(Ljava/util/List;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PendingActionRow(Ljava/util/List;ZLX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PendingHeader(ILX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PendingHeader(ILX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$RichApprovalPendingCard-FJfuzF0(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->RichApprovalPendingCard-FJfuzF0(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/3C1;FLX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$SingleApprovalContent(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContent(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;ZLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$SingleApprovalTitleRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalTitleRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$agentPermissionApprovalImpressions$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$agentPermissionApprovalImpressions$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$bulkActionComponent(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Lcom/facebook/aura/analytics/hatch/HatchComponent;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->bulkActionComponent(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rememberApprovalActionsEnabled$lambda$3(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "LX/2d4;",
            "I)",
            "LX/3C1;"
        }
    .end annotation

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v14, p0

    .line 2
    move-object/from16 v9, p1

    .line 3
    .line 4
    move-object/from16 v12, p2

    .line 5
    .line 6
    invoke-static {p0, v9, v12}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    move-object/from16 v4, p3

    .line 10
    .line 11
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-static {v4, v0, v3, v1}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v10

    .line 21
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 22
    .line 23
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v11

    .line 27
    if-ne v11, v3, :cond_0

    .line 28
    .line 29
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 30
    .line 31
    .line 32
    move-result-object v11

    .line 33
    invoke-interface {v4, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v11, Ljava/util/Set;

    .line 37
    .line 38
    invoke-static {v9}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 57
    .line 58
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 59
    .line 60
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    invoke-static {v10}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    move/from16 v7, p4

    .line 73
    .line 74
    and-int/lit8 v0, p4, 0x70

    .line 75
    .line 76
    xor-int/lit8 v0, v0, 0x30

    .line 77
    .line 78
    const/4 v8, 0x1

    .line 79
    const/16 v6, 0x20

    .line 80
    .line 81
    if-le v0, v6, :cond_2

    .line 82
    .line 83
    invoke-interface {v4, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-nez v0, :cond_3

    .line 88
    .line 89
    :cond_2
    and-int/lit8 v1, p4, 0x30

    .line 90
    .line 91
    const/4 v0, 0x0

    .line 92
    if-ne v1, v6, :cond_4

    .line 93
    .line 94
    :cond_3
    const/4 v0, 0x1

    .line 95
    :cond_4
    invoke-static {v4, v11, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 96
    .line 97
    .line 98
    move-result v6

    .line 99
    and-int/lit16 v0, v7, 0x380

    .line 100
    .line 101
    xor-int/lit16 v0, v0, 0x180

    .line 102
    .line 103
    const/16 v1, 0x100

    .line 104
    .line 105
    if-le v0, v1, :cond_5

    .line 106
    .line 107
    invoke-static {v4, v12}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-nez v0, :cond_6

    .line 112
    .line 113
    :cond_5
    and-int/lit16 v0, v7, 0x180

    .line 114
    .line 115
    if-eq v0, v1, :cond_6

    .line 116
    .line 117
    const/4 v8, 0x0

    .line 118
    :cond_6
    or-int/2addr v6, v8

    .line 119
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    if-nez v6, :cond_7

    .line 124
    .line 125
    if-ne v8, v3, :cond_8

    .line 126
    .line 127
    :cond_7
    const/4 v13, 0x0

    .line 128
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$1$1;

    .line 129
    .line 130
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$1$1;-><init>(Ljava/util/List;Landroidx/compose/runtime/MutableState;Ljava/util/Set;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2M4;)V

    .line 131
    .line 132
    .line 133
    invoke-interface {v4, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    :cond_8
    invoke-static {v4, v8, v5, v2}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    if-ne v0, v3, :cond_9

    .line 144
    .line 145
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;

    .line 146
    .line 147
    invoke-direct {v0, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$agentPermissionApprovalImpressions$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 148
    .line 149
    .line 150
    invoke-interface {v4, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    :cond_9
    check-cast v0, LX/JDM;

    .line 154
    .line 155
    const-wide/16 p3, 0x0

    .line 156
    .line 157
    const/16 p2, 0x0

    .line 158
    .line 159
    sget-object p0, LX/15h;->A06:LX/15h;

    .line 160
    .line 161
    move-object/from16 p1, v0

    .line 162
    .line 163
    invoke-static/range {v14 .. v19}, LX/7Kl;->A00(LX/3C1;LX/15h;LX/JDM;FJ)LX/3C1;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    return-object v0
.end method

.method public static final agentPermissionApprovalImpressions$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final agentPermissionApprovalImpressions$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final bulkActionComponent(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Lcom/facebook/aura/analytics/hatch/HatchComponent;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionDecision;->DENY:Lcom/facebook/aura/gateway/AgentPermissionDecision;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/AgentPermissionDecision;->getWireValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_DENY_ALL_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_0
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionDecision;->ALLOW_ALWAYS:Lcom/facebook/aura/gateway/AgentPermissionDecision;

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/AgentPermissionDecision;->getWireValue()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_ALLOW_ALWAYS_ALL_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_CONFIRM_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 33
    .line 34
    return-object v0
.end method

.method public static final checkoutPaymentRowKey(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutApprovalPayload;)Lcom/facebook/aura/navigation/AuraBottomSheetNavKey;
    .locals 1

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-interface {p1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutApprovalPayload;->getPaymentSelection()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutPaymentSelection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    invoke-interface {p1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutApprovalPayload;->getPaymentOptions()Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/navigation/key/CheckoutPayWithLinkSheetKey;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Lcom/facebook/aura/navigation/key/CheckoutPayWithLinkSheetKey;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    check-cast v0, Lcom/facebook/aura/navigation/AuraBottomSheetNavKey;

    .line 25
    .line 26
    return-object v0

    .line 27
    :cond_0
    new-instance v0, Lcom/facebook/aura/navigation/key/CheckoutWalletSheetKey;

    .line 28
    .line 29
    invoke-direct {v0, p0}, Lcom/facebook/aura/navigation/key/CheckoutWalletSheetKey;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0
.end method

.method public static final endsWithSentencePunctuation(Ljava/lang/String;)Z
    .locals 3

    .line 0
    const/16 v0, 0x2e

    .line 1
    .line 2
    invoke-static {v0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    const/16 v0, 0x21

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/16 v0, 0x3f

    .line 13
    .line 14
    invoke-static {v0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    filled-new-array {v2, v1, v0}, [Ljava/lang/Character;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-static {p0}, LX/Bf6;->A0y(Ljava/lang/CharSequence;)Ljava/lang/Character;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v1, v0}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    return v0
.end method

.method public static final getSingleApprovalContentSpacing()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContentSpacing:F

    .line 1
    .line 2
    return v0
.end method

.method public static final partitionExclusiveApprovals(Ljava/util/List;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;>;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$partitionExclusiveApprovals$$inlined$sortedBy$1;

    .line 5
    .line 6
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$partitionExclusiveApprovals$$inlined$sortedBy$1;-><init>()V

    .line 7
    .line 8
    .line 9
    invoke-static {p0, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    check-cast v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 36
    .line 37
    iget-boolean v0, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->isExclusive:Z

    .line 38
    .line 39
    if-nez v0, :cond_0

    .line 40
    .line 41
    invoke-static {v1}, Lcom/facebook/aura/gateway/ApprovalCardOnlyKt;->allowsOnlyOnCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_0

    .line 46
    .line 47
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_1
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_2

    .line 64
    .line 65
    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-static {v0, p0}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    :cond_2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$partitionExclusiveApprovals$$inlined$sortedBy$2;

    .line 74
    .line 75
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$partitionExclusiveApprovals$$inlined$sortedBy$2;-><init>()V

    .line 76
    .line 77
    .line 78
    invoke-static {p0, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    return-object v0
.end method

.method public static final pendingApprovalsViewModel(Ljava/lang/String;ZLX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;
    .locals 5

    .line 0
    invoke-static {p2}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->pendingApprovalsViewModelKey(Ljava/lang/String;Z)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$Factory;

    .line 9
    .line 10
    invoke-direct {v3, v0, p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$Factory;-><init>(LX/AHE;Ljava/lang/String;Z)V

    .line 11
    .line 12
    .line 13
    invoke-static {p2}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    invoke-static {v2}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 24
    .line 25
    invoke-static {v3, v2, v1, v0, v4}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    throw v0
.end method

.method public static final pendingApprovalsViewModelKey(Ljava/lang/String;Z)Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 1
    .line 2
    invoke-virtual {v0, p0}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->normalize(Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    const-string v1, "agent_permission_pending_"

    .line 7
    .line 8
    const-string v0, "_"

    .line 9
    .line 10
    invoke-static {v1, p0, v0, p1}, LX/Gi8;->A16(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public static final pendingRichApprovalCard-TDGSqEk(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;FLX/2d4;I)LX/3C1;
    .locals 4

    .line 0
    invoke-static {p0}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_PILL:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 9
    .line 10
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 11
    .line 12
    shl-int/lit8 v0, v0, 0x3

    .line 13
    .line 14
    or-int/lit16 v0, v0, 0x180

    .line 15
    .line 16
    invoke-static {v3, v2, v1, p3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-static {v2, v1, v0, v1, p2}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const/high16 v3, 0x41000000    # 8.0f

    .line 28
    .line 29
    sget-object v2, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionCardShape:LX/2bC;

    .line 30
    .line 31
    invoke-static {p3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-wide p3, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->shadow:J

    .line 36
    .line 37
    const/16 p0, 0xc

    .line 38
    .line 39
    const-wide/16 p1, 0x0

    .line 40
    .line 41
    invoke-static/range {v1 .. v8}, LX/1ps;->A00(LX/3C1;LX/2bW;FIJJ)LX/3C1;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public static final rememberApprovalActionsEnabled(Ljava/util/List;Ljava/lang/String;LX/2d4;I)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            "LX/2d4;",
            "I)Z"
        }
    .end annotation

    .line 0
    and-int/lit8 v0, p3, 0xe

    .line 1
    .line 2
    xor-int/lit8 v0, v0, 0x6

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    const/4 v2, 0x4

    .line 6
    const/4 v6, 0x0

    .line 7
    if-le v0, v2, :cond_0

    .line 8
    .line 9
    invoke-interface {p2, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    :cond_0
    and-int/lit8 v1, p3, 0x6

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    if-ne v1, v2, :cond_2

    .line 19
    .line 20
    :cond_1
    const/4 v0, 0x1

    .line 21
    :cond_2
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    if-nez v0, :cond_3

    .line 26
    .line 27
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 28
    .line 29
    if-ne v4, v0, :cond_5

    .line 30
    .line 31
    :cond_3
    invoke-static {p0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_4

    .line 44
    .line 45
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 50
    .line 51
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_4
    invoke-interface {p2, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_5
    check-cast v4, Ljava/util/List;

    .line 61
    .line 62
    invoke-interface {p2, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    and-int/lit8 v0, p3, 0x70

    .line 67
    .line 68
    xor-int/lit8 v0, v0, 0x30

    .line 69
    .line 70
    const/16 v1, 0x20

    .line 71
    .line 72
    if-le v0, v1, :cond_6

    .line 73
    .line 74
    invoke-interface {p2, p1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_7

    .line 79
    .line 80
    :cond_6
    and-int/lit8 v0, p3, 0x30

    .line 81
    .line 82
    if-eq v0, v1, :cond_7

    .line 83
    .line 84
    const/4 v3, 0x0

    .line 85
    :cond_7
    or-int/2addr v5, v3

    .line 86
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    const/4 v2, 0x0

    .line 91
    if-nez v5, :cond_8

    .line 92
    .line 93
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 94
    .line 95
    if-ne v3, v0, :cond_9

    .line 96
    .line 97
    :cond_8
    invoke-static {p2, v6}, LX/005;->A0Y(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    :cond_9
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 102
    .line 103
    invoke-static {p2, v4, v3}, LX/004;->A1U(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    if-nez v1, :cond_a

    .line 112
    .line 113
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 114
    .line 115
    if-ne v0, v1, :cond_b

    .line 116
    .line 117
    :cond_a
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberApprovalActionsEnabled$1$1;

    .line 118
    .line 119
    invoke-direct {v0, v4, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberApprovalActionsEnabled$1$1;-><init>(Ljava/util/List;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 120
    .line 121
    .line 122
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    :cond_b
    invoke-static {p2, v0, v4, p1}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    return v0
.end method

.method public static final rememberApprovalActionsEnabled$lambda$2(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final rememberApprovalActionsEnabled$lambda$3(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberPendingAgentPermissionCount(Ljava/lang/String;ZLX/2d4;II)I
    .locals 1

    .line 0
    invoke-static {p4, p0}, LX/3Rp;->A0w(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    and-int/lit8 v0, p4, 0x2

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    :cond_0
    and-int/lit8 v0, p3, 0x7e

    .line 10
    .line 11
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->rememberPendingApprovals(Ljava/lang/String;ZLX/2d4;I)Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    return v0
.end method

.method public static final rememberPendingApprovalBatchKey(Ljava/lang/String;ZLX/2d4;II)Ljava/lang/String;
    .locals 2

    .line 0
    and-int/lit8 v1, p4, 0x1

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    if-eqz v1, :cond_0

    .line 4
    .line 5
    move-object p0, v0

    .line 6
    :cond_0
    and-int/lit8 v1, p4, 0x2

    .line 7
    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    :cond_1
    and-int/lit8 v1, p3, 0x7e

    .line 12
    .line 13
    invoke-static {p0, p1, p2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->rememberPendingApprovals(Ljava/lang/String;ZLX/2d4;I)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {v1}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 22
    .line 23
    if-eqz v1, :cond_2

    .line 24
    .line 25
    iget-object v0, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 26
    .line 27
    :cond_2
    return-object v0
.end method

.method public static final rememberPendingApprovalBatchKeySnapshot(Ljava/lang/String;ZLX/2d4;II)Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "LX/2d4;",
            "II)",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p4, p0}, LX/3Rp;->A0w(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    and-int/lit8 v0, p4, 0x2

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    :cond_0
    and-int/lit8 v0, p3, 0x7e

    .line 10
    .line 11
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->pendingApprovalsViewModel(Ljava/lang/String;ZLX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-interface {p2, p1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-nez p0, :cond_1

    .line 24
    .line 25
    sget-object p0, LX/2d6;->A00:Ljava/lang/Object;

    .line 26
    .line 27
    if-ne v0, p0, :cond_2

    .line 28
    .line 29
    :cond_1
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberPendingApprovalBatchKeySnapshot$1$1;

    .line 30
    .line 31
    invoke-direct {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$rememberPendingApprovalBatchKeySnapshot$1$1;-><init>(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_2
    check-cast v0, LX/DqV;

    .line 38
    .line 39
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 40
    .line 41
    return-object v0
.end method

.method public static final rememberPendingApprovals(Ljava/lang/String;ZLX/2d4;I)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "LX/2d4;",
            "I)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    and-int/lit8 v0, p3, 0x7e

    .line 1
    .line 2
    invoke-static {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->pendingApprovalsViewModel(Ljava/lang/String;ZLX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    iget-object p0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->approvals:LX/2J3;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-static {p2, p0, v0}, LX/3Rr;->A0Z(LX/2d4;LX/2J3;I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Ljava/util/List;

    .line 14
    .line 15
    return-object v0
.end method

.method public static final rememberPendingApprovals$lambda$0(LX/16A;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;>;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
