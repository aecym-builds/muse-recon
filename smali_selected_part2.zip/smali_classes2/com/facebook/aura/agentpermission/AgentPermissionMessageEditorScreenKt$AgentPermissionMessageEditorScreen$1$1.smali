.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $state$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;->$state$delegate:LX/16A;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;->$state$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 7
    .line 8
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 13
    .line 14
    invoke-interface {v0}, Lcom/facebook/aura/navigation/AuraNavigator;->back()Z

    .line 15
    .line 16
    .line 17
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1$invoke$$inlined$onDispose$1;

    .line 18
    .line 19
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
