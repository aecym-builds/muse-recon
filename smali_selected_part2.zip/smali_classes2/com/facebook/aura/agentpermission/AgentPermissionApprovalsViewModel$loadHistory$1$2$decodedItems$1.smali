.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1"
    f = "AgentPermissionApprovalsViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $page:Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->$page:Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->$page:Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;-><init>(Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->$page:Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;-><init>(Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_2

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;->$page:Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 8
    .line 9
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;->items:Ljava/util/List;

    .line 10
    .line 11
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lkotlinx/serialization/json/JsonElement;

    .line 30
    .line 31
    invoke-static {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepositoryJsonKt;->decodeApprovalSnapshotRecord(Lkotlinx/serialization/json/JsonElement;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    invoke-virtual {p1, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    return-object p1

    .line 42
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    throw v0
.end method
