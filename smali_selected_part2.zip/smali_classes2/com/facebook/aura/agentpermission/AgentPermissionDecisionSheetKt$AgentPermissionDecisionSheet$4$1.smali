.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->invoke(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 5
    .line 6
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionDecisionSheetConfirmClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V

    .line 7
    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionSheet$4$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 12
    .line 13
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->messageRevision:Ljava/lang/Long;

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-virtual {v2, p1, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->submit(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Ljava/lang/Long;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method
