.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final attachments:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;"
        }
    .end annotation
.end field

.field public final body:Ljava/lang/String;

.field public final editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

.field public final loading:Z

.field public final saved:Z

.field public final saving:Z

.field public final subject:Ljava/lang/String;

.field public final unavailable:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/gateway/EditableMessageEditor;->$stable:I

    .line 1
    .line 2
    sput v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->$stable:I

    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>()V
    .locals 8

    .line 0
    const/4 v1, 0x0

    .line 1
    const-string v2, ""

    .line 2
    .line 3
    sget-object v4, LX/0wV;->A00:LX/0wV;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    move-object v0, p0

    .line 7
    move-object v3, v2

    .line 8
    move v6, v5

    .line 9
    move v7, v5

    .line 10
    move p0, v5

    .line 11
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/EditableMessageEditor;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;ZZZZ)V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x1

    .line 268435457
    invoke-static {p2, p3, p4, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 268435466
    .line 268435467
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 268435470
    .line 268435471
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 268435472
    .line 268435473
    iput-boolean p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 268435474
    .line 268435475
    iput-boolean p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 268435476
    .line 268435477
    iput-boolean p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 268435478
    .line 268435479
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p9, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    const/4 p1, 0x0

    .line 536870917
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 536870918
    .line 536870919
    const-string v1, ""

    .line 536870920
    .line 536870921
    if-eqz v0, :cond_1

    .line 536870922
    .line 536870923
    move-object p2, v1

    .line 536870924
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    move-object p3, v1

    .line 536870929
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 536870930
    .line 536870931
    if-eqz v0, :cond_3

    .line 536870932
    .line 536870933
    sget-object p4, LX/0wV;->A00:LX/0wV;

    .line 536870934
    .line 536870935
    :cond_3
    invoke-static {p9, p5}, LX/3Rr;->A1Q(IZ)Z

    .line 536870936
    .line 536870937
    .line 536870938
    move-result p5

    .line 536870939
    and-int/lit8 v0, p9, 0x20

    .line 536870940
    .line 536870941
    if-eqz v0, :cond_4

    .line 536870942
    .line 536870943
    const/4 p6, 0x0

    .line 536870944
    :cond_4
    and-int/lit8 v0, p9, 0x40

    .line 536870945
    .line 536870946
    if-eqz v0, :cond_5

    .line 536870947
    .line 536870948
    const/4 p7, 0x0

    .line 536870949
    :cond_5
    invoke-static {p9, p8}, LX/3Rr;->A1S(IZ)Z

    .line 536870950
    .line 536870951
    .line 536870952
    move-result p8

    .line 536870953
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 536870954
    .line 536870955
    .line 536870956
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZILjava/lang/Object;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p9, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-boolean p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-boolean p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p9, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-boolean p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 47
    .line 48
    :cond_7
    invoke-virtual/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/gateway/EditableMessageEditor;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component6()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component7()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component8()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/EditableMessageEditor;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;ZZZZ)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p3, p4, p0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;-><init>(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 51
    .line 52
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 53
    .line 54
    if-ne v1, v0, :cond_0

    .line 55
    .line 56
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 57
    .line 58
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 59
    .line 60
    if-ne v1, v0, :cond_0

    .line 61
    .line 62
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 63
    .line 64
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 65
    .line 66
    if-ne v1, v0, :cond_0

    .line 67
    .line 68
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 69
    .line 70
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 71
    .line 72
    if-eq v1, v0, :cond_1

    .line 73
    .line 74
    :cond_0
    return v2

    .line 75
    :cond_1
    return v3
.end method

.method public final getAttachments()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBody()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCanSave()Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    if-eqz p0, :cond_1

    .line 20
    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    :cond_1
    return v0
.end method

.method public final getEditor()Lcom/facebook/aura/gateway/EditableMessageEditor;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoading()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSaved()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSaving()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSubject()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUnavailable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 27
    .line 28
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 45
    .line 46
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public final validationError$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission()Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 1
    .line 2
    sget-object v2, LX/Fbu;->A05:Ljava/nio/charset/Charset;

    .line 3
    .line 4
    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    array-length v1, v0

    .line 9
    const/16 v0, 0x800

    .line 10
    .line 11
    if-le v1, v0, :cond_0

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->SUBJECT_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    array-length v1, v0

    .line 23
    const/high16 v0, 0x10000

    .line 24
    .line 25
    if-le v1, v0, :cond_1

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->BODY_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 28
    .line 29
    return-object v0

    .line 30
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_2

    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 49
    .line 50
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_2

    .line 55
    .line 56
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->EMPTY_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 57
    .line 58
    return-object v0

    .line 59
    :cond_2
    const/4 v0, 0x0

    .line 60
    return-object v0
.end method
