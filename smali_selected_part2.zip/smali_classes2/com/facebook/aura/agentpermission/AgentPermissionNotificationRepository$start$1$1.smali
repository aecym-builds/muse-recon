.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDP;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDP<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;",
        "Ljava/lang/Boolean;",
        "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
        "Ljava/lang/String;",
        "Lcom/facebook/aura/model/AiIdentity;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionNotificationRepository$start$1$1"
    f = "AgentPermissionNotificationRepository.kt"
    l = {
        0x4a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final synthetic $startedAtMs:J

.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic L$1:Ljava/lang/Object;

.field public synthetic L$2:Ljava/lang/Object;

.field public synthetic Z$0:Z

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$startedAtMs:J

    .line 5
    .line 6
    const/4 v0, 0x6

    .line 7
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/util/List;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p2

    .line 6
    check-cast p3, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 7
    .line 8
    check-cast p4, Ljava/lang/String;

    .line 9
    .line 10
    check-cast p5, Lcom/facebook/aura/model/AiIdentity;

    .line 11
    .line 12
    check-cast p6, LX/2M4;

    .line 13
    .line 14
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->invoke(Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;LX/2M4;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method

.method public final invoke(Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;Z",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/model/AiIdentity;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 268435457
    .line 268435458
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 268435459
    .line 268435460
    iget-wide v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$startedAtMs:J

    .line 268435461
    .line 268435462
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;

    .line 268435463
    .line 268435464
    move-object p1, p6

    .line 268435465
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;JLX/2M4;)V

    .line 268435466
    .line 268435467
    .line 268435468
    iput-boolean p2, v1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->Z$0:Z

    .line 268435469
    .line 268435470
    iput-object p3, v1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$0:Ljava/lang/Object;

    .line 268435471
    .line 268435472
    iput-object p4, v1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$1:Ljava/lang/Object;

    .line 268435473
    .line 268435474
    iput-object p5, v1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$2:Ljava/lang/Object;

    .line 268435475
    .line 268435476
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435477
    .line 268435478
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435479
    .line 268435480
    .line 268435481
    move-result-object v0

    .line 268435482
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 0
    iget-boolean v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->Z$0:Z

    .line 1
    .line 2
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$0:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v6, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 5
    .line 6
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$1:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v7, Ljava/lang/String;

    .line 9
    .line 10
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$2:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v8, Lcom/facebook/aura/model/AiIdentity;

    .line 13
    .line 14
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 15
    .line 16
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->label:I

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    if-ne v0, v1, :cond_2

    .line 22
    .line 23
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object v2

    .line 29
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 33
    .line 34
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->currentPendingApprovals()Ljava/util/List;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    iget-wide v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->$startedAtMs:J

    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$0:Ljava/lang/Object;

    .line 44
    .line 45
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$1:Ljava/lang/Object;

    .line 46
    .line 47
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->L$2:Ljava/lang/Object;

    .line 48
    .line 49
    iput-boolean v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->Z$0:Z

    .line 50
    .line 51
    iput v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;->label:I

    .line 52
    .line 53
    invoke-static/range {v3 .. v11}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->access$reconcileSystemNotifications(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Ljava/util/List;ZLcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;Ljava/lang/String;Lcom/facebook/aura/model/AiIdentity;JLX/2M4;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-ne v0, v2, :cond_0

    .line 58
    .line 59
    return-object v2

    .line 60
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    throw v0
.end method
