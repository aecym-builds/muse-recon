.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionPendingCardViewModel$submitSingleDecision$3"
    f = "AgentPermissionPendingCardViewModel.kt"
    l = {
        0x71
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $approvalId:Ljava/lang/String;

.field public final synthetic $credentialId:Ljava/lang/String;

.field public final synthetic $option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;Ljava/lang/String;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$credentialId:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$credentialId:Ljava/lang/String;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;Ljava/lang/String;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->label:I

    .line 3
    .line 4
    const/4 v7, 0x1

    .line 5
    if-eqz v0, :cond_3

    .line 6
    .line 7
    if-ne v0, v7, :cond_4

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    instance-of v3, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$Success;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 15
    .line 16
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->credentialSelections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approvalId:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$credentialId:Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {v2, v1, v3, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->onDecided$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;ZLjava/lang/String;)V

    .line 23
    .line 24
    .line 25
    if-nez v3, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 28
    .line 29
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->_submittingApprovalIds:LX/2J2;

    .line 30
    .line 31
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approvalId:Ljava/lang/String;

    .line 32
    .line 33
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    move-object v0, v1

    .line 38
    check-cast v0, Ljava/util/Set;

    .line 39
    .line 40
    invoke-static {v2, v0}, LX/163;->A03(Ljava/lang/Object;Ljava/util/Set;)Ljava/util/Set;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-interface {v3, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    :cond_2
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 51
    .line 52
    return-object v1

    .line 53
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;

    .line 57
    .line 58
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 59
    .line 60
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approvalId:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 63
    .line 64
    iget-object v4, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v5, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->alwaysScope:Ljava/lang/String;

    .line 67
    .line 68
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 69
    .line 70
    iget-object v8, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->messageRevision:Ljava/lang/Long;

    .line 71
    .line 72
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->$credentialId:Ljava/lang/String;

    .line 73
    .line 74
    iput v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submitSingleDecision$3;->label:I

    .line 75
    .line 76
    const/4 v6, 0x0

    .line 77
    move-object v10, v6

    .line 78
    move-object v11, v6

    .line 79
    invoke-virtual/range {v2 .. v12}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->decideApproval(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    if-ne p1, v1, :cond_0

    .line 84
    .line 85
    return-object v1

    .line 86
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    throw v0
.end method
