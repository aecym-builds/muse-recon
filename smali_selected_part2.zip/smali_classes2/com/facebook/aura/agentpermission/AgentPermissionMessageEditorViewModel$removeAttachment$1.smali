.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
        "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $id:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;->$id:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 11

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v4, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 6
    .line 7
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;->$id:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 10
    .line 11
    .line 12
    move-result-object v8

    .line 13
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    move-object v0, v1

    .line 28
    check-cast v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;

    .line 29
    .line 30
    iget-object v0, v0, Lcom/facebook/aura/gateway/EditableMessageAttachment;->id:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0, v3, v1, v8}, LX/3Rs;->A17(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    iget-object v5, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 37
    .line 38
    iget-object v6, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v7, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 41
    .line 42
    iget-boolean v9, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 43
    .line 44
    iget-boolean v10, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 45
    .line 46
    iget-boolean p0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 47
    .line 48
    iget-boolean p1, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 49
    .line 50
    invoke-virtual/range {v4 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$removeAttachment$1;->invoke(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
