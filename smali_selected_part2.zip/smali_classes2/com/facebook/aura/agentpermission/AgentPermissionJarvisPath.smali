.class public interface abstract Lcom/facebook/aura/agentpermission/AgentPermissionJarvisPath;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/api/JarvisPath$Extension;
