.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onDecisionClick:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;


# direct methods
.method public constructor <init>(LX/JDM;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;->$onDecisionClick:LX/JDM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;->$onDecisionClick:LX/JDM;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$PendingActionRow$1$1$1$1;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
