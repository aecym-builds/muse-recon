.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.ApprovalCredentialSelections$load$2"
    f = "ApprovalCredentialSelections.kt"
    l = {
        0x55
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $approvalId:Ljava/lang/String;

.field public final synthetic $loadId:I

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;Ljava/lang/String;ILX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;",
            "Ljava/lang/String;",
            "I",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->this$0:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$loadId:I

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->this$0:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iget v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$loadId:I

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;Ljava/lang/String;ILX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    if-ne v0, v2, :cond_5

    .line 8
    .line 9
    invoke-static {p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->this$0:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 14
    .line 15
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$approvalId:Ljava/lang/String;

    .line 18
    .line 19
    iget v5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$loadId:I

    .line 20
    .line 21
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    move-object v1, v6

    .line 26
    check-cast v1, Ljava/util/Map;

    .line 27
    .line 28
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v7

    .line 32
    check-cast v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 33
    .line 34
    if-eqz v7, :cond_2

    .line 35
    .line 36
    iget v0, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 37
    .line 38
    if-ne v0, v5, :cond_2

    .line 39
    .line 40
    invoke-static {v4}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-nez v0, :cond_3

    .line 45
    .line 46
    move-object v0, v4

    .line 47
    check-cast v0, Lcom/facebook/aura/gateway/ApprovalCredentialSelection;

    .line 48
    .line 49
    sget-object v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 50
    .line 51
    iget-object v9, v0, Lcom/facebook/aura/gateway/ApprovalCredentialSelection;->origin:Ljava/lang/String;

    .line 52
    .line 53
    iget-object v10, v0, Lcom/facebook/aura/gateway/ApprovalCredentialSelection;->candidates:Ljava/util/List;

    .line 54
    .line 55
    :goto_0
    iget-object v11, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 56
    .line 57
    iget-object v12, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 58
    .line 59
    iget-boolean p0, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 60
    .line 61
    iget p1, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 62
    .line 63
    invoke-static {v8, v10}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    new-instance v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 67
    .line 68
    invoke-direct/range {v7 .. v14}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 69
    .line 70
    .line 71
    invoke-static {v2, v7, v1}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    :cond_2
    invoke-interface {v3, v6, v1}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_1

    .line 80
    .line 81
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 82
    .line 83
    return-object v3

    .line 84
    :cond_3
    sget-object v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->FAILED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 85
    .line 86
    iget-object v9, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 87
    .line 88
    iget-object v10, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->this$0:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 95
    .line 96
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 97
    .line 98
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->$approvalId:Ljava/lang/String;

    .line 99
    .line 100
    iput v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;->label:I

    .line 101
    .line 102
    invoke-virtual {v1, v0, p0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->fetchCredentialSelection-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    if-ne v4, v3, :cond_0

    .line 107
    .line 108
    return-object v3

    .line 109
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    throw v0
.end method
