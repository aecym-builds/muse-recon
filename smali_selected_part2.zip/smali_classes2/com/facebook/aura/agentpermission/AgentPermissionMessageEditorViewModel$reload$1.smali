.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$reload$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {
        0x82
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v5, :cond_0

    .line 8
    .line 9
    :try_start_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    goto :goto_0
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    throw v0

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :try_start_1
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 22
    .line 23
    iget-object v3, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->singleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 24
    .line 25
    sget-object v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Operation;->LOAD:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Operation;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;

    .line 29
    .line 30
    invoke-direct {v0, v4, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 31
    .line 32
    .line 33
    iput v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->label:I

    .line 34
    .line 35
    invoke-interface {v3, v2, v0, p0}, Lcom/facebook/aura/common/coroutines/SingleFlight;->invoke(Ljava/lang/Object;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-ne v0, v6, :cond_2

    .line 40
    .line 41
    return-object v6
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 42
    :catch_0
    move-exception v1

    .line 43
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 44
    .line 45
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$checkOwner(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_2

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 52
    .line 53
    invoke-static {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$handleLoadFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V

    .line 54
    .line 55
    .line 56
    :cond_2
    :goto_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 57
    .line 58
    return-object v6

    .line 59
    :catch_1
    move-exception v0

    .line 60
    throw v0
.end method
