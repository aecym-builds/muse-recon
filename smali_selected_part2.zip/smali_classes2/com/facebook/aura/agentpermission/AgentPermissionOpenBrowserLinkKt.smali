.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final OpenBrowserLink(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p2

    .line 1
    .line 2
    const/4 v14, 0x0

    .line 3
    move-object/from16 v6, p0

    .line 4
    .line 5
    move-object/from16 v5, p1

    .line 6
    .line 7
    invoke-static {v6, v5}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const v0, -0x361b3ec8    # -1873959.0f

    .line 12
    .line 13
    .line 14
    move-object/from16 v4, p3

    .line 15
    .line 16
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 17
    .line 18
    .line 19
    move/from16 v3, p4

    .line 20
    .line 21
    and-int/lit8 v0, p4, 0x6

    .line 22
    .line 23
    if-nez v0, :cond_8

    .line 24
    .line 25
    invoke-static {v4, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 26
    .line 27
    .line 28
    move-result v9

    .line 29
    or-int v9, v9, p4

    .line 30
    .line 31
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static {v4, v5}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    or-int/2addr v9, v0

    .line 40
    :cond_0
    and-int/lit8 v8, p5, 0x4

    .line 41
    .line 42
    if-eqz v8, :cond_7

    .line 43
    .line 44
    or-int/lit16 v9, v9, 0x180

    .line 45
    .line 46
    :cond_1
    :goto_1
    and-int/lit16 v7, v9, 0x93

    .line 47
    .line 48
    const/16 v0, 0x92

    .line 49
    .line 50
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0, v4, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_9

    .line 59
    .line 60
    if-eqz v8, :cond_2

    .line 61
    .line 62
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    invoke-static {v4}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    invoke-static {v4}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 69
    .line 70
    .line 71
    move-result-object v10

    .line 72
    invoke-interface {v4, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    if-nez v0, :cond_3

    .line 81
    .line 82
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 83
    .line 84
    if-ne v8, v0, :cond_4

    .line 85
    .line 86
    :cond_3
    sget-object v0, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->INSTANCE:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;

    .line 87
    .line 88
    invoke-virtual {v0, v7}, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->opener(LX/AHE;)Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 89
    .line 90
    .line 91
    move-result-object v8

    .line 92
    invoke-interface {v4, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :cond_4
    check-cast v8, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 96
    .line 97
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 98
    .line 99
    invoke-static {v4, v11}, LX/07H;->A07(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 100
    .line 101
    .line 102
    move-result-wide v18

    .line 103
    invoke-static {v14}, LX/1Y9;->A01(I)LX/1Y9;

    .line 104
    .line 105
    .line 106
    move-result-object v7

    .line 107
    invoke-static {v9}, LX/004;->A1S(I)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-static {v4, v8, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    invoke-static {v9}, LX/002;->A1S(I)Z

    .line 116
    .line 117
    .line 118
    move-result v9

    .line 119
    invoke-static {v4, v10, v0, v9}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 120
    .line 121
    .line 122
    move-result v9

    .line 123
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    if-nez v9, :cond_5

    .line 128
    .line 129
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 130
    .line 131
    if-ne v0, v9, :cond_6

    .line 132
    .line 133
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt$OpenBrowserLink$1$1;

    .line 134
    .line 135
    invoke-direct {v0, v5, v8, v6, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt$OpenBrowserLink$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Ljava/lang/String;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 136
    .line 137
    .line 138
    invoke-interface {v4, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    :cond_6
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 142
    .line 143
    const/4 v15, 0x0

    .line 144
    invoke-static {v1, v7, v15, v0, v2}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 145
    .line 146
    .line 147
    move-result-object v7

    .line 148
    invoke-static {v4}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 149
    .line 150
    .line 151
    move-result-object v13

    .line 152
    move-object v0, v4

    .line 153
    check-cast v0, LX/J7I;

    .line 154
    .line 155
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 156
    .line 157
    .line 158
    move-result v12

    .line 159
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 160
    .line 161
    .line 162
    move-result-object v10

    .line 163
    invoke-static {v4, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 164
    .line 165
    .line 166
    move-result-object v9

    .line 167
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 168
    .line 169
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 170
    .line 171
    if-nez v7, :cond_a

    .line 172
    .line 173
    invoke-static {}, LX/1VY;->A00()V

    .line 174
    .line 175
    .line 176
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    throw v0

    .line 181
    :cond_7
    and-int/lit16 v0, v3, 0x180

    .line 182
    .line 183
    if-nez v0, :cond_1

    .line 184
    .line 185
    invoke-static {v4, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    or-int/2addr v9, v0

    .line 190
    goto/16 :goto_1

    .line 191
    .line 192
    :cond_8
    move v9, v3

    .line 193
    goto/16 :goto_0

    .line 194
    .line 195
    :cond_9
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 196
    .line 197
    .line 198
    goto :goto_2

    .line 199
    :cond_a
    invoke-static {v4, v0, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 200
    .line 201
    .line 202
    invoke-static {v4, v13, v10, v9, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 203
    .line 204
    .line 205
    const v7, 0x7f120161

    .line 206
    .line 207
    .line 208
    invoke-static {v4, v7}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v16

    .line 212
    invoke-static {v4, v11}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 213
    .line 214
    .line 215
    move-result-object v20

    .line 216
    const/16 p4, 0x3ff2

    .line 217
    .line 218
    move-object/from16 v21, v15

    .line 219
    .line 220
    move-object/from16 v22, v15

    .line 221
    .line 222
    move-object/from16 v23, v15

    .line 223
    .line 224
    move/from16 v24, v14

    .line 225
    .line 226
    move/from16 v25, v14

    .line 227
    .line 228
    move/from16 v26, v14

    .line 229
    .line 230
    move/from16 v27, v14

    .line 231
    .line 232
    move-object/from16 v28, v15

    .line 233
    .line 234
    move-object/from16 v29, v15

    .line 235
    .line 236
    move-object/from16 p0, v15

    .line 237
    .line 238
    move-object/from16 p1, v4

    .line 239
    .line 240
    move/from16 p2, v14

    .line 241
    .line 242
    move/from16 p3, v14

    .line 243
    .line 244
    move-object/from16 v17, v15

    .line 245
    .line 246
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 247
    .line 248
    .line 249
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 250
    .line 251
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 252
    .line 253
    invoke-static {v4, v8, v7}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 254
    .line 255
    .line 256
    const v7, 0x7f080089

    .line 257
    .line 258
    .line 259
    invoke-static {v4, v7, v14}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 260
    .line 261
    .line 262
    move-result-object v9

    .line 263
    sget-object v10, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->TINY:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 264
    .line 265
    invoke-static {}, LX/2l9;->A04()I

    .line 266
    .line 267
    .line 268
    move-result v16

    .line 269
    const/16 v17, 0x21

    .line 270
    .line 271
    move-object v8, v15

    .line 272
    move-object v11, v15

    .line 273
    move-wide/from16 v12, v18

    .line 274
    .line 275
    move-object v14, v15

    .line 276
    move-object v15, v4

    .line 277
    invoke-static/range {v8 .. v17}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 278
    .line 279
    .line 280
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 281
    .line 282
    .line 283
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 284
    .line 285
    .line 286
    move-result-object v2

    .line 287
    if-eqz v2, :cond_b

    .line 288
    .line 289
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt$OpenBrowserLink$3;

    .line 290
    .line 291
    move-object/from16 p1, v6

    .line 292
    .line 293
    move-object/from16 p2, v5

    .line 294
    .line 295
    move-object/from16 p3, v1

    .line 296
    .line 297
    move/from16 p4, v3

    .line 298
    .line 299
    move-object/from16 p0, v0

    .line 300
    .line 301
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt$OpenBrowserLink$3;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 302
    .line 303
    .line 304
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 305
    .line 306
    :cond_b
    return-void
.end method

.method public static final isLiveBrowserPreviewBehindSheet(LX/2d4;I)Z
    .locals 7

    .line 0
    const v0, 0xd9db517

    .line 1
    .line 2
    .line 3
    move-object v3, p0

    .line 4
    invoke-interface {p0, v0}, LX/2d4;->Agj(I)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetStateKt;->LocalAuraSheetState:LX/Ip3;

    .line 8
    .line 9
    invoke-interface {p0, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-static {p0}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    return v0

    .line 20
    :cond_0
    invoke-static {p0}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {p0, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 35
    .line 36
    if-ne v1, v0, :cond_2

    .line 37
    .line 38
    :cond_1
    sget-object v0, Lcom/facebook/aura/browsertask/api/BrowserTasks;->INSTANCE:Lcom/facebook/aura/browsertask/api/BrowserTasks;

    .line 39
    .line 40
    invoke-virtual {v0, v2}, Lcom/facebook/aura/browsertask/api/BrowserTasks;->source(LX/AHE;)Lcom/facebook/aura/browsertask/api/BrowserTaskSource;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-interface {p0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_2
    check-cast v1, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;

    .line 48
    .line 49
    invoke-interface {v1}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getPreviewVisibility()LX/2Lw;

    .line 50
    .line 51
    .line 52
    move-result-object v6

    .line 53
    invoke-interface {v1}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->isPreviewVisible()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    const/4 p0, 0x0

    .line 62
    const/16 p1, 0xe

    .line 63
    .line 64
    const/4 v4, 0x0

    .line 65
    invoke-static/range {v3 .. v8}, LX/1x0;->A01(LX/2d4;LX/15h;Ljava/lang/Object;LX/2Lw;II)LX/16A;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-static {v0}, LX/16A;->A0C(LX/16A;)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-static {v3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    return v0
.end method

.method public static final isLiveBrowserPreviewBehindSheet$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method
