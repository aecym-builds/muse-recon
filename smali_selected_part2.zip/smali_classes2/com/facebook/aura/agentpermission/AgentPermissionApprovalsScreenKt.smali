.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ActionedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 56
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v20, p2

    .line 1
    .line 2
    const v1, 0x6fc7b940

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p3

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v10, p4

    .line 11
    .line 12
    and-int/lit8 v1, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v1, :cond_6

    .line 17
    .line 18
    invoke-static {v5, v0, v10}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    or-int v2, v2, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 29
    .line 30
    move-object/from16 p4, p1

    .line 31
    .line 32
    if-nez v1, :cond_0

    .line 33
    .line 34
    move-object/from16 v1, p4

    .line 35
    .line 36
    invoke-static {v0, v1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    or-int/2addr v2, v1

    .line 41
    :cond_0
    move/from16 p3, p5

    .line 42
    .line 43
    and-int/lit8 v6, p5, 0x4

    .line 44
    .line 45
    if-eqz v6, :cond_5

    .line 46
    .line 47
    or-int/lit16 v2, v2, 0x180

    .line 48
    .line 49
    :cond_1
    :goto_1
    and-int/lit16 v3, v2, 0x93

    .line 50
    .line 51
    const/16 v1, 0x92

    .line 52
    .line 53
    const/4 v4, 0x0

    .line 54
    invoke-static {v3, v1}, LX/003;->A1H(II)Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    invoke-static {v1, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_b

    .line 63
    .line 64
    if-eqz v6, :cond_2

    .line 65
    .line 66
    sget-object v20, LX/3C1;->A00:LX/3Cb;

    .line 67
    .line 68
    :cond_2
    invoke-static {v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalHistoryTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v19

    .line 72
    move-object/from16 v1, v19

    .line 73
    .line 74
    invoke-static {v5, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalHistorySummary(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v40

    .line 78
    iget-object v1, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 79
    .line 80
    const/16 v18, 0x0

    .line 81
    .line 82
    if-eqz v1, :cond_4

    .line 83
    .line 84
    iget-object v6, v1, Lcom/facebook/aura/gateway/ApprovalRecord;->outcomeLabel:Ljava/lang/String;

    .line 85
    .line 86
    if-eqz v6, :cond_4

    .line 87
    .line 88
    const v1, -0x6341770a

    .line 89
    .line 90
    .line 91
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 92
    .line 93
    .line 94
    :goto_2
    invoke-static {v0}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    if-nez v6, :cond_3

    .line 99
    .line 100
    const v3, -0x634169b1    # -1.2611999E-21f

    .line 101
    .line 102
    .line 103
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 104
    .line 105
    .line 106
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 107
    .line 108
    and-int/lit8 v2, v2, 0xe

    .line 109
    .line 110
    or-int/2addr v2, v3

    .line 111
    invoke-static {v5, v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->decisionLabel(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    :goto_3
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 116
    .line 117
    .line 118
    iget-wide v2, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestedAtMs:J

    .line 119
    .line 120
    invoke-static {v2, v3, v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalHistoryTimestamp(JLX/2d4;I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v17

    .line 124
    invoke-static/range {v20 .. v20}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 125
    .line 126
    .line 127
    move-result-object v8

    .line 128
    invoke-static {v4}, LX/1Y9;->A01(I)LX/1Y9;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    const/4 v9, 0x1

    .line 133
    move-object/from16 v3, p4

    .line 134
    .line 135
    move-object/from16 v2, v18

    .line 136
    .line 137
    invoke-static {v8, v7, v2, v3, v9}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 138
    .line 139
    .line 140
    move-result-object v7

    .line 141
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 142
    .line 143
    sget v2, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmallPlusNano:F

    .line 144
    .line 145
    invoke-static {v7, v3, v2}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 146
    .line 147
    .line 148
    move-result-object v7

    .line 149
    sget-object v3, LX/2Id;->A05:LX/2rU;

    .line 150
    .line 151
    invoke-static {v2}, LX/Dn6;->A00(F)LX/CP5;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    invoke-static {v2, v0, v3}, LX/3Rr;->A0B(LX/Cl0;LX/2d4;LX/2rU;)LX/3BI;

    .line 156
    .line 157
    .line 158
    move-result-object v12

    .line 159
    iget-wide v2, v1, LX/J7I;->A06:J

    .line 160
    .line 161
    invoke-static {v2, v3}, LX/001;->A0A(J)I

    .line 162
    .line 163
    .line 164
    move-result v13

    .line 165
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    invoke-static {v0, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 170
    .line 171
    .line 172
    move-result-object v11

    .line 173
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 174
    .line 175
    iget-object v3, v1, LX/J7I;->A0V:LX/3DJ;

    .line 176
    .line 177
    if-nez v3, :cond_7

    .line 178
    .line 179
    invoke-static {}, LX/1VY;->A00()V

    .line 180
    .line 181
    .line 182
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    throw v0

    .line 187
    :cond_3
    const v2, -0x634176e4

    .line 188
    .line 189
    .line 190
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 191
    .line 192
    .line 193
    goto :goto_3

    .line 194
    :cond_4
    const v1, -0x63416fc6

    .line 195
    .line 196
    .line 197
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 198
    .line 199
    .line 200
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 201
    .line 202
    and-int/lit8 v1, v2, 0xe

    .line 203
    .line 204
    or-int/2addr v3, v1

    .line 205
    invoke-static {v5, v0, v3}, Lcom/facebook/aura/agentpermission/CheckoutPaymentSetupRowKt;->paymentSetupOutcomeLabel(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v6

    .line 209
    goto :goto_2

    .line 210
    :cond_5
    and-int/lit16 v1, v10, 0x180

    .line 211
    .line 212
    if-nez v1, :cond_1

    .line 213
    .line 214
    move-object/from16 v1, v20

    .line 215
    .line 216
    invoke-static {v0, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    or-int/2addr v2, v1

    .line 221
    goto/16 :goto_1

    .line 222
    .line 223
    :cond_6
    move v2, v10

    .line 224
    goto/16 :goto_0

    .line 225
    .line 226
    :cond_7
    invoke-static {v0, v1, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 227
    .line 228
    .line 229
    sget-object v7, LX/3Cl;->A04:LX/JDN;

    .line 230
    .line 231
    invoke-static {v0, v12, v7}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 232
    .line 233
    .line 234
    move-result-object v3

    .line 235
    invoke-static {v0, v2, v3, v13}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 236
    .line 237
    .line 238
    move-result-object v16

    .line 239
    sget-object v2, LX/3Cl;->A02:LX/JDM;

    .line 240
    .line 241
    invoke-static {v0, v11, v2}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 242
    .line 243
    .line 244
    move-result-object v15

    .line 245
    sget-object v11, LX/CgK;->A00:LX/CgK;

    .line 246
    .line 247
    iget-object v13, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 248
    .line 249
    iget-object v12, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 250
    .line 251
    sget v24, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 252
    .line 253
    sget v25, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 254
    .line 255
    invoke-static {v5}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 256
    .line 257
    .line 258
    move-result v26

    .line 259
    sget v27, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 260
    .line 261
    const/16 v32, 0x184

    .line 262
    .line 263
    move-object/from16 v21, v13

    .line 264
    .line 265
    move-object/from16 v22, v12

    .line 266
    .line 267
    move-object/from16 v23, v18

    .line 268
    .line 269
    move-object/from16 v28, v18

    .line 270
    .line 271
    move-object/from16 v29, v18

    .line 272
    .line 273
    move-object/from16 v30, v0

    .line 274
    .line 275
    move/from16 v31, v4

    .line 276
    .line 277
    invoke-static/range {v21 .. v32}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 278
    .line 279
    .line 280
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 281
    .line 282
    invoke-static {v11, v12, v9}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 283
    .line 284
    .line 285
    move-result-object v11

    .line 286
    sget v12, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 287
    .line 288
    invoke-static {v0, v12, v4}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 289
    .line 290
    .line 291
    move-result-object v14

    .line 292
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 293
    .line 294
    .line 295
    move-result v13

    .line 296
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 297
    .line 298
    .line 299
    move-result-object v12

    .line 300
    invoke-static {v0, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 301
    .line 302
    .line 303
    move-result-object v11

    .line 304
    invoke-static {v0, v1, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 305
    .line 306
    .line 307
    invoke-static {v0, v14, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 308
    .line 309
    .line 310
    invoke-static {v0, v12, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 311
    .line 312
    .line 313
    move-object/from16 v3, v16

    .line 314
    .line 315
    invoke-static {v2, v3, v0, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 316
    .line 317
    .line 318
    invoke-static {v0, v11, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 319
    .line 320
    .line 321
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 322
    .line 323
    const/16 v38, 0x6

    .line 324
    .line 325
    invoke-static {v0, v2}, LX/07H;->A0N(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 326
    .line 327
    .line 328
    move-result-object v25

    .line 329
    invoke-static {v0, v2}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 330
    .line 331
    .line 332
    move-result-wide v23

    .line 333
    const/16 v31, 0x2

    .line 334
    .line 335
    const/16 v39, 0x39f2

    .line 336
    .line 337
    const/high16 v37, 0x30000000

    .line 338
    .line 339
    move-object/from16 v26, v18

    .line 340
    .line 341
    move-object/from16 v27, v18

    .line 342
    .line 343
    move/from16 v29, v4

    .line 344
    .line 345
    move/from16 v30, v4

    .line 346
    .line 347
    move/from16 v32, v31

    .line 348
    .line 349
    move-object/from16 v33, v18

    .line 350
    .line 351
    move-object/from16 v34, v18

    .line 352
    .line 353
    move-object/from16 v35, v18

    .line 354
    .line 355
    move-object/from16 v36, v0

    .line 356
    .line 357
    move-object/from16 v21, v19

    .line 358
    .line 359
    move-object/from16 v22, v18

    .line 360
    .line 361
    invoke-static/range {v21 .. v39}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 362
    .line 363
    .line 364
    if-nez v40, :cond_a

    .line 365
    .line 366
    const v3, 0xf7d2142

    .line 367
    .line 368
    .line 369
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 370
    .line 371
    .line 372
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 373
    .line 374
    .line 375
    :goto_4
    if-nez v17, :cond_9

    .line 376
    .line 377
    const v3, 0xf81bac6

    .line 378
    .line 379
    .line 380
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 381
    .line 382
    .line 383
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 384
    .line 385
    .line 386
    :goto_5
    move-object/from16 v40, v6

    .line 387
    .line 388
    :cond_8
    invoke-static {v0, v2}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 389
    .line 390
    .line 391
    move-result-object v44

    .line 392
    invoke-static {v0, v2}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 393
    .line 394
    .line 395
    move-result-wide v42

    .line 396
    move-object/from16 v41, v18

    .line 397
    .line 398
    move-object/from16 v45, v18

    .line 399
    .line 400
    move-object/from16 v46, v18

    .line 401
    .line 402
    move-object/from16 v47, v18

    .line 403
    .line 404
    move/from16 v48, v4

    .line 405
    .line 406
    move/from16 v49, v4

    .line 407
    .line 408
    move/from16 v50, v9

    .line 409
    .line 410
    move/from16 v51, v31

    .line 411
    .line 412
    move-object/from16 v52, v18

    .line 413
    .line 414
    move-object/from16 v53, v18

    .line 415
    .line 416
    move-object/from16 v54, v18

    .line 417
    .line 418
    move-object/from16 v55, v0

    .line 419
    .line 420
    move/from16 p0, v37

    .line 421
    .line 422
    move/from16 p1, v38

    .line 423
    .line 424
    move/from16 p2, v39

    .line 425
    .line 426
    invoke-static/range {v40 .. v58}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 427
    .line 428
    .line 429
    invoke-static {v1, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 430
    .line 431
    .line 432
    invoke-static {v1, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 433
    .line 434
    .line 435
    goto :goto_6

    .line 436
    :cond_9
    const v3, 0xf81bac7

    .line 437
    .line 438
    .line 439
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 440
    .line 441
    .line 442
    const v7, 0x7f120146

    .line 443
    .line 444
    .line 445
    move-object/from16 v3, v17

    .line 446
    .line 447
    invoke-static {v0, v6, v3, v7}, LX/18b;->A09(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v40

    .line 451
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 452
    .line 453
    .line 454
    if-nez v40, :cond_8

    .line 455
    .line 456
    goto :goto_5

    .line 457
    :cond_a
    const v3, 0xf7d2143

    .line 458
    .line 459
    .line 460
    invoke-static {v0, v2, v3}, LX/002;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 461
    .line 462
    .line 463
    move-result-object v3

    .line 464
    iget-object v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineRegular:LX/2hg;

    .line 465
    .line 466
    invoke-static {v0, v2}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 467
    .line 468
    .line 469
    move-result-wide v42

    .line 470
    move-object/from16 v41, v18

    .line 471
    .line 472
    move-object/from16 v44, v3

    .line 473
    .line 474
    move-object/from16 v45, v18

    .line 475
    .line 476
    move-object/from16 v46, v18

    .line 477
    .line 478
    move-object/from16 v47, v18

    .line 479
    .line 480
    move/from16 v48, v4

    .line 481
    .line 482
    move/from16 v49, v4

    .line 483
    .line 484
    move/from16 v50, v9

    .line 485
    .line 486
    move/from16 v51, v31

    .line 487
    .line 488
    move-object/from16 v52, v18

    .line 489
    .line 490
    move-object/from16 v53, v18

    .line 491
    .line 492
    move-object/from16 v54, v18

    .line 493
    .line 494
    move-object/from16 v55, v0

    .line 495
    .line 496
    move/from16 p0, v37

    .line 497
    .line 498
    move/from16 p1, v38

    .line 499
    .line 500
    move/from16 p2, v39

    .line 501
    .line 502
    invoke-static/range {v40 .. v58}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 503
    .line 504
    .line 505
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 506
    .line 507
    .line 508
    goto/16 :goto_4

    .line 509
    .line 510
    :cond_b
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 511
    .line 512
    .line 513
    :goto_6
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 514
    .line 515
    .line 516
    move-result-object v1

    .line 517
    if-eqz v1, :cond_c

    .line 518
    .line 519
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ActionedApprovalRow$2;

    .line 520
    .line 521
    move-object/from16 v54, v0

    .line 522
    .line 523
    move-object/from16 v55, v5

    .line 524
    .line 525
    move-object/from16 p0, p4

    .line 526
    .line 527
    move-object/from16 p1, v20

    .line 528
    .line 529
    move/from16 p2, v10

    .line 530
    .line 531
    invoke-direct/range {v54 .. v59}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ActionedApprovalRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 532
    .line 533
    .line 534
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 535
    .line 536
    :cond_c
    return-void
.end method

.method public static final AgentPermissionApprovalsScreen-djqs-MU(Ljava/lang/String;FFLX/3C1;LX/2d4;II)V
    .locals 22

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    const v0, -0x59034874

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p4

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_e

    .line 17
    .line 18
    invoke-static {v3, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    or-int v8, v8, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move/from16 v6, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v3, v6}, LX/004;->A0A(LX/2d4;F)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v8, v0

    .line 35
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 36
    .line 37
    move/from16 v5, p2

    .line 38
    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    invoke-static {v3, v5}, LX/004;->A0B(LX/2d4;F)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v8, v0

    .line 46
    :cond_1
    and-int/lit8 v1, p6, 0x8

    .line 47
    .line 48
    if-eqz v1, :cond_d

    .line 49
    .line 50
    or-int/lit16 v8, v8, 0xc00

    .line 51
    .line 52
    :cond_2
    :goto_1
    invoke-static {v8}, LX/005;->A1K(I)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    invoke-static {v0, v3, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_c

    .line 61
    .line 62
    if-eqz v1, :cond_3

    .line 63
    .line 64
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 65
    .line 66
    :cond_3
    and-int/lit8 v12, v8, 0xe

    .line 67
    .line 68
    invoke-static {v7, v3, v12}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->rememberAgentPermissionApprovalsViewModel(Ljava/lang/String;LX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 69
    .line 70
    .line 71
    move-result-object v11

    .line 72
    iget-object v0, v11, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->uiState:LX/2J3;

    .line 73
    .line 74
    const/4 v1, 0x0

    .line 75
    const/4 v15, 0x0

    .line 76
    invoke-static {v3, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 77
    .line 78
    .line 79
    move-result-object v10

    .line 80
    invoke-interface {v3, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v8

    .line 84
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    if-nez v8, :cond_4

    .line 89
    .line 90
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 91
    .line 92
    if-ne v0, v8, :cond_5

    .line 93
    .line 94
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$1$1;

    .line 95
    .line 96
    invoke-direct {v0, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)V

    .line 97
    .line 98
    .line 99
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_5
    invoke-static {v3, v10, v0, v11}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 107
    .line 108
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 109
    .line 110
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 111
    .line 112
    if-ne v8, v0, :cond_7

    .line 113
    .line 114
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 119
    .line 120
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 121
    .line 122
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_7

    .line 127
    .line 128
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 133
    .line 134
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 135
    .line 136
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-eqz v0, :cond_7

    .line 141
    .line 142
    const v0, 0x7afbb5d4

    .line 143
    .line 144
    .line 145
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 146
    .line 147
    .line 148
    const v0, 0x7f1211e1

    .line 149
    .line 150
    .line 151
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v8

    .line 155
    const v0, 0x7f1200ab

    .line 156
    .line 157
    .line 158
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v11

    .line 162
    invoke-static {v4, v5, v6}, LX/3Rs;->A07(LX/3C1;FF)LX/3C1;

    .line 163
    .line 164
    .line 165
    move-result-object v9

    .line 166
    const/4 v14, 0x4

    .line 167
    move-object v10, v15

    .line 168
    move-object v12, v3

    .line 169
    move v13, v1

    .line 170
    invoke-static/range {v8 .. v14}, Lcom/facebook/aura/ui/HatchScreenEmptyStateKt;->HatchScreenEmptyState(Ljava/lang/String;LX/3C1;LX/2l9;Ljava/lang/String;LX/2d4;II)V

    .line 171
    .line 172
    .line 173
    invoke-static {v3, v3}, LX/003;->A0W(LX/2d4;Ljava/lang/Object;)LX/J7V;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    if-eqz v1, :cond_6

    .line 178
    .line 179
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$2;

    .line 180
    .line 181
    move-object/from16 p0, v0

    .line 182
    .line 183
    move-object/from16 p1, v7

    .line 184
    .line 185
    move/from16 p2, v6

    .line 186
    .line 187
    move/from16 p3, v5

    .line 188
    .line 189
    move-object/from16 p4, v4

    .line 190
    .line 191
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$2;-><init>(Ljava/lang/String;FFLX/3C1;II)V

    .line 192
    .line 193
    .line 194
    :goto_2
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    :cond_6
    return-void

    .line 198
    :cond_7
    const v0, 0x7b006e96

    .line 199
    .line 200
    .line 201
    invoke-static {v3, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 202
    .line 203
    .line 204
    move-result-object v8

    .line 205
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 210
    .line 211
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 212
    .line 213
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 214
    .line 215
    if-ne v9, v0, :cond_8

    .line 216
    .line 217
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 222
    .line 223
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 224
    .line 225
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 226
    .line 227
    .line 228
    move-result v0

    .line 229
    if-eqz v0, :cond_8

    .line 230
    .line 231
    invoke-interface {v10}, LX/16A;->getValue()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 236
    .line 237
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 238
    .line 239
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    if-eqz v0, :cond_8

    .line 244
    .line 245
    const v0, 0x7b0315cd

    .line 246
    .line 247
    .line 248
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 249
    .line 250
    .line 251
    invoke-static {v4, v5, v6}, LX/3Rs;->A07(LX/3C1;FF)LX/3C1;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-static {v0, v3, v1, v1}, Lcom/facebook/aura/ui/HatchScreenLoadingStateKt;->HatchScreenLoadingState(LX/3C1;LX/2d4;II)V

    .line 256
    .line 257
    .line 258
    invoke-static {v3, v8}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    if-eqz v1, :cond_6

    .line 263
    .line 264
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$3;

    .line 265
    .line 266
    move-object/from16 p0, v0

    .line 267
    .line 268
    move-object/from16 p1, v7

    .line 269
    .line 270
    move/from16 p2, v6

    .line 271
    .line 272
    move/from16 p3, v5

    .line 273
    .line 274
    move-object/from16 p4, v4

    .line 275
    .line 276
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$3;-><init>(Ljava/lang/String;FFLX/3C1;II)V

    .line 277
    .line 278
    .line 279
    goto :goto_2

    .line 280
    :cond_8
    const/4 v14, 0x0

    .line 281
    const v0, 0x7b059036

    .line 282
    .line 283
    .line 284
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 285
    .line 286
    .line 287
    invoke-static {v8, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 288
    .line 289
    .line 290
    invoke-static {v3}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 291
    .line 292
    .line 293
    move-result-object v9

    .line 294
    invoke-static {v4}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 295
    .line 296
    .line 297
    move-result-object p0

    .line 298
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 299
    .line 300
    add-float v8, p2, v0

    .line 301
    .line 302
    const/4 v0, 0x0

    .line 303
    new-instance v13, LX/1XE;

    .line 304
    .line 305
    invoke-direct {v13, v0, v6, v0, v8}, LX/1XE;-><init>(FFFF)V

    .line 306
    .line 307
    .line 308
    invoke-interface {v3, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v0

    .line 312
    invoke-static {v3, v11, v9, v0}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 313
    .line 314
    .line 315
    move-result v8

    .line 316
    const/4 v0, 0x4

    .line 317
    if-ne v12, v0, :cond_9

    .line 318
    .line 319
    const/4 v14, 0x1

    .line 320
    :cond_9
    or-int/2addr v8, v14

    .line 321
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    if-nez v8, :cond_a

    .line 326
    .line 327
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 328
    .line 329
    if-ne v0, v8, :cond_b

    .line 330
    .line 331
    :cond_a
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;

    .line 332
    .line 333
    invoke-direct {v0, v11, v10, v9, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/16A;Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 337
    .line 338
    .line 339
    :cond_b
    check-cast v0, LX/JDM;

    .line 340
    .line 341
    const/16 p3, 0x1fa

    .line 342
    .line 343
    move-object/from16 v16, v15

    .line 344
    .line 345
    move-object/from16 v17, v15

    .line 346
    .line 347
    move-object/from16 v19, v15

    .line 348
    .line 349
    move-object/from16 v21, v15

    .line 350
    .line 351
    move/from16 p2, v1

    .line 352
    .line 353
    move/from16 p4, v1

    .line 354
    .line 355
    move/from16 p5, v1

    .line 356
    .line 357
    move-object/from16 v18, v13

    .line 358
    .line 359
    move-object/from16 v20, v3

    .line 360
    .line 361
    move-object/from16 p1, v0

    .line 362
    .line 363
    invoke-static/range {v15 .. v27}, LX/EIg;->A01(LX/3IY;LX/32u;LX/Dps;LX/2or;Landroidx/compose/foundation/lazy/LazyListState;LX/2d4;LX/2sS;LX/3C1;LX/JDM;IIZZ)V

    .line 364
    .line 365
    .line 366
    goto :goto_3

    .line 367
    :cond_c
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 368
    .line 369
    .line 370
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 371
    .line 372
    .line 373
    move-result-object v1

    .line 374
    if-eqz v1, :cond_6

    .line 375
    .line 376
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$5;

    .line 377
    .line 378
    move-object/from16 p0, v0

    .line 379
    .line 380
    move-object/from16 p1, v7

    .line 381
    .line 382
    move/from16 p2, v6

    .line 383
    .line 384
    move/from16 p3, v5

    .line 385
    .line 386
    move-object/from16 p4, v4

    .line 387
    .line 388
    move/from16 p5, v2

    .line 389
    .line 390
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$5;-><init>(Ljava/lang/String;FFLX/3C1;II)V

    .line 391
    .line 392
    .line 393
    goto/16 :goto_2

    .line 394
    .line 395
    :cond_d
    and-int/lit16 v0, v2, 0xc00

    .line 396
    .line 397
    if-nez v0, :cond_2

    .line 398
    .line 399
    invoke-static {v3, v4}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 400
    .line 401
    .line 402
    move-result v0

    .line 403
    or-int/2addr v8, v0

    .line 404
    goto/16 :goto_1

    .line 405
    .line 406
    :cond_e
    move v8, v2

    .line 407
    goto/16 :goto_0
.end method

.method public static final AgentPermissionApprovalsScreen_djqs_MU$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final ApprovalDecisionButtons(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 46
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v13, p5

    .line 1
    .line 2
    const v1, 0x7c8efa91

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p6

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p7

    .line 11
    .line 12
    and-int/lit8 v1, p7, 0x6

    .line 13
    .line 14
    move-object/from16 v15, p0

    .line 15
    .line 16
    if-nez v1, :cond_7

    .line 17
    .line 18
    invoke-static {v15, v0, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    or-int v1, v1, p7

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v3, p7, 0x30

    .line 29
    .line 30
    move-object/from16 v14, p1

    .line 31
    .line 32
    if-nez v3, :cond_0

    .line 33
    .line 34
    invoke-static {v14, v0, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    invoke-static {v3}, LX/003;->A07(I)I

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    or-int/2addr v1, v3

    .line 43
    :cond_0
    and-int/lit16 v3, v2, 0x180

    .line 44
    .line 45
    move/from16 v28, p2

    .line 46
    .line 47
    if-nez v3, :cond_1

    .line 48
    .line 49
    move/from16 v3, v28

    .line 50
    .line 51
    invoke-static {v0, v3}, LX/004;->A0k(LX/2d4;Z)I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    or-int/2addr v1, v3

    .line 56
    :cond_1
    and-int/lit16 v3, v2, 0xc00

    .line 57
    .line 58
    move-object/from16 p7, p3

    .line 59
    .line 60
    if-nez v3, :cond_2

    .line 61
    .line 62
    move-object/from16 v3, p7

    .line 63
    .line 64
    invoke-static {v0, v3}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    or-int/2addr v1, v3

    .line 69
    :cond_2
    and-int/lit16 v3, v2, 0x6000

    .line 70
    .line 71
    move-object/from16 p6, p4

    .line 72
    .line 73
    if-nez v3, :cond_3

    .line 74
    .line 75
    move-object/from16 v3, p6

    .line 76
    .line 77
    invoke-static {v0, v3}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 78
    .line 79
    .line 80
    move-result v3

    .line 81
    or-int/2addr v1, v3

    .line 82
    :cond_3
    move/from16 p5, p8

    .line 83
    .line 84
    and-int/lit8 v6, p8, 0x20

    .line 85
    .line 86
    const/high16 v3, 0x30000

    .line 87
    .line 88
    if-nez v6, :cond_4

    .line 89
    .line 90
    and-int/2addr v3, v2

    .line 91
    if-nez v3, :cond_5

    .line 92
    .line 93
    invoke-static {v0, v13}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    :cond_4
    or-int/2addr v1, v3

    .line 98
    :cond_5
    const v4, 0x12493

    .line 99
    .line 100
    .line 101
    and-int/2addr v4, v1

    .line 102
    const v3, 0x12492

    .line 103
    .line 104
    .line 105
    const/4 v5, 0x0

    .line 106
    invoke-static {v4, v3}, LX/003;->A1H(II)Z

    .line 107
    .line 108
    .line 109
    move-result v3

    .line 110
    invoke-static {v3, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 111
    .line 112
    .line 113
    move-result v3

    .line 114
    if-eqz v3, :cond_11

    .line 115
    .line 116
    if-eqz v6, :cond_6

    .line 117
    .line 118
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 119
    .line 120
    :cond_6
    iget-boolean v12, v14, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;->reviewsOnCard:Z

    .line 121
    .line 122
    sget-object v9, LX/2sI;->A02:LX/2wD;

    .line 123
    .line 124
    invoke-interface {v13, v9}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    const/high16 v3, 0x41200000    # 10.0f

    .line 129
    .line 130
    invoke-static {v0, v3}, LX/3Rs;->A09(LX/2d4;F)LX/3BI;

    .line 131
    .line 132
    .line 133
    move-result-object v11

    .line 134
    move-object v3, v0

    .line 135
    check-cast v3, LX/J7I;

    .line 136
    .line 137
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 138
    .line 139
    .line 140
    move-result v10

    .line 141
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 142
    .line 143
    .line 144
    move-result-object v8

    .line 145
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 146
    .line 147
    .line 148
    move-result-object v7

    .line 149
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 150
    .line 151
    iget-object v4, v3, LX/J7I;->A0V:LX/3DJ;

    .line 152
    .line 153
    if-nez v4, :cond_8

    .line 154
    .line 155
    invoke-static {}, LX/1VY;->A00()V

    .line 156
    .line 157
    .line 158
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    throw v0

    .line 163
    :cond_7
    move v1, v2

    .line 164
    goto/16 :goto_0

    .line 165
    .line 166
    :cond_8
    invoke-static {v0, v3, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 167
    .line 168
    .line 169
    invoke-static {v0, v11, v8, v7, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 170
    .line 171
    .line 172
    const/16 v7, 0x30

    .line 173
    .line 174
    if-eqz v12, :cond_10

    .line 175
    .line 176
    const v4, 0x33a13801

    .line 177
    .line 178
    .line 179
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 180
    .line 181
    .line 182
    const v4, 0x7f1200ac

    .line 183
    .line 184
    .line 185
    invoke-static {v0, v4}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v20

    .line 189
    const/high16 v18, 0x70000000

    .line 190
    .line 191
    sget-object v8, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 192
    .line 193
    const/4 v4, 0x0

    .line 194
    const/4 v6, 0x1

    .line 195
    const v17, 0x30c00

    .line 196
    .line 197
    .line 198
    invoke-virtual {v8, v4, v0, v7, v6}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 199
    .line 200
    .line 201
    move-result-object v23

    .line 202
    sget-object v24, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 203
    .line 204
    const/high16 v6, 0x42100000    # 36.0f

    .line 205
    .line 206
    invoke-static {v9, v6}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 207
    .line 208
    .line 209
    move-result-object v22

    .line 210
    sget-object v38, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$1;

    .line 211
    .line 212
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v6

    .line 216
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 217
    .line 218
    if-ne v6, v8, :cond_9

    .line 219
    .line 220
    sget-object v6, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;

    .line 221
    .line 222
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    :cond_9
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 226
    .line 227
    shl-int/lit8 p1, v1, 0x15

    .line 228
    .line 229
    and-int p1, p1, v18

    .line 230
    .line 231
    or-int p1, p1, v17

    .line 232
    .line 233
    const v8, 0xe000

    .line 234
    .line 235
    .line 236
    and-int p2, v1, v8

    .line 237
    .line 238
    const p4, 0x7d7bdc5

    .line 239
    .line 240
    .line 241
    move-object/from16 v21, v4

    .line 242
    .line 243
    move-object/from16 v25, v4

    .line 244
    .line 245
    move/from16 v26, v5

    .line 246
    .line 247
    move/from16 v27, v5

    .line 248
    .line 249
    move/from16 v29, v5

    .line 250
    .line 251
    move/from16 v30, v5

    .line 252
    .line 253
    move-object/from16 v31, v4

    .line 254
    .line 255
    move-object/from16 v32, v4

    .line 256
    .line 257
    move-object/from16 v33, p6

    .line 258
    .line 259
    move-object/from16 v34, v4

    .line 260
    .line 261
    move-object/from16 v35, v4

    .line 262
    .line 263
    move-object/from16 v36, v4

    .line 264
    .line 265
    move-object/from16 v37, v4

    .line 266
    .line 267
    move-object/from16 v39, v4

    .line 268
    .line 269
    move-object/from16 v40, v6

    .line 270
    .line 271
    move-object/from16 v41, v4

    .line 272
    .line 273
    move/from16 v42, v5

    .line 274
    .line 275
    move/from16 v43, v5

    .line 276
    .line 277
    move/from16 v44, v5

    .line 278
    .line 279
    move/from16 v45, v5

    .line 280
    .line 281
    move-object/from16 p0, v0

    .line 282
    .line 283
    move/from16 p3, v7

    .line 284
    .line 285
    move-object/from16 v19, v4

    .line 286
    .line 287
    invoke-static/range {v19 .. v50}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 288
    .line 289
    .line 290
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 291
    .line 292
    .line 293
    :goto_1
    const v6, -0x6976775

    .line 294
    .line 295
    .line 296
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 297
    .line 298
    .line 299
    iget-object v6, v14, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;->options:LX/Ddn;

    .line 300
    .line 301
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 302
    .line 303
    .line 304
    move-result-object v16

    .line 305
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 306
    .line 307
    .line 308
    move-result v6

    .line 309
    if-eqz v6, :cond_12

    .line 310
    .line 311
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object v6

    .line 315
    check-cast v6, LX/0RM;

    .line 316
    .line 317
    iget v11, v6, LX/0RM;->A00:I

    .line 318
    .line 319
    iget-object v10, v6, LX/0RM;->A01:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast v10, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 322
    .line 323
    iget-object v6, v10, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->labelText:Ljava/lang/String;

    .line 324
    .line 325
    move-object/from16 v20, v6

    .line 326
    .line 327
    if-nez v11, :cond_f

    .line 328
    .line 329
    if-nez v12, :cond_f

    .line 330
    .line 331
    const v6, 0x5de563af

    .line 332
    .line 333
    .line 334
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 335
    .line 336
    .line 337
    sget-object v8, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 338
    .line 339
    const/4 v6, 0x1

    .line 340
    invoke-virtual {v8, v4, v0, v7, v6}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 341
    .line 342
    .line 343
    move-result-object v23

    .line 344
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 345
    .line 346
    .line 347
    :goto_3
    sget-object v24, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 348
    .line 349
    const/high16 v6, 0x42100000    # 36.0f

    .line 350
    .line 351
    invoke-static {v9, v6}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 352
    .line 353
    .line 354
    move-result-object v22

    .line 355
    and-int/lit8 v8, v1, 0xe

    .line 356
    .line 357
    const/4 v6, 0x4

    .line 358
    if-eq v8, v6, :cond_a

    .line 359
    .line 360
    and-int/lit8 v6, v1, 0x8

    .line 361
    .line 362
    if-eqz v6, :cond_e

    .line 363
    .line 364
    invoke-interface {v0, v15}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 365
    .line 366
    .line 367
    move-result v6

    .line 368
    if-eqz v6, :cond_e

    .line 369
    .line 370
    :cond_a
    const/4 v6, 0x1

    .line 371
    :goto_4
    invoke-static {v0, v10, v6}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 372
    .line 373
    .line 374
    move-result v8

    .line 375
    invoke-static {v1}, LX/005;->A1L(I)Z

    .line 376
    .line 377
    .line 378
    move-result v6

    .line 379
    or-int/2addr v6, v8

    .line 380
    invoke-static {v6, v0, v11}, LX/001;->A1Z(ZLX/2d4;I)Z

    .line 381
    .line 382
    .line 383
    move-result v6

    .line 384
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    move-result-object v8

    .line 388
    if-nez v6, :cond_b

    .line 389
    .line 390
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 391
    .line 392
    if-ne v8, v6, :cond_c

    .line 393
    .line 394
    :cond_b
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$1$1;

    .line 395
    .line 396
    move-object/from16 v6, p7

    .line 397
    .line 398
    invoke-direct {v8, v15, v10, v6, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;LX/JDM;I)V

    .line 399
    .line 400
    .line 401
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 402
    .line 403
    .line 404
    :cond_c
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 405
    .line 406
    sget-object v38, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;

    .line 407
    .line 408
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 409
    .line 410
    .line 411
    move-result-object v6

    .line 412
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 413
    .line 414
    if-ne v6, v10, :cond_d

    .line 415
    .line 416
    sget-object v6, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$3$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$3$1;

    .line 417
    .line 418
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 419
    .line 420
    .line 421
    :cond_d
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 422
    .line 423
    shl-int/lit8 p1, v1, 0x15

    .line 424
    .line 425
    and-int p1, p1, v18

    .line 426
    .line 427
    or-int p1, p1, v17

    .line 428
    .line 429
    const p4, 0x7d7bdc5

    .line 430
    .line 431
    .line 432
    move-object/from16 v19, v4

    .line 433
    .line 434
    move-object/from16 v21, v4

    .line 435
    .line 436
    move-object/from16 v25, v4

    .line 437
    .line 438
    move/from16 v26, v5

    .line 439
    .line 440
    move/from16 v27, v5

    .line 441
    .line 442
    move/from16 v29, v5

    .line 443
    .line 444
    move/from16 v30, v5

    .line 445
    .line 446
    move-object/from16 v31, v4

    .line 447
    .line 448
    move-object/from16 v32, v4

    .line 449
    .line 450
    move-object/from16 v33, v8

    .line 451
    .line 452
    move-object/from16 v34, v4

    .line 453
    .line 454
    move-object/from16 v35, v4

    .line 455
    .line 456
    move-object/from16 v36, v4

    .line 457
    .line 458
    move-object/from16 v37, v4

    .line 459
    .line 460
    move-object/from16 v39, v4

    .line 461
    .line 462
    move-object/from16 v40, v6

    .line 463
    .line 464
    move-object/from16 v41, v4

    .line 465
    .line 466
    move/from16 v42, v5

    .line 467
    .line 468
    move/from16 v43, v5

    .line 469
    .line 470
    move/from16 v44, v5

    .line 471
    .line 472
    move/from16 v45, v5

    .line 473
    .line 474
    move-object/from16 p0, v0

    .line 475
    .line 476
    move/from16 p2, v5

    .line 477
    .line 478
    move/from16 p3, v7

    .line 479
    .line 480
    invoke-static/range {v19 .. v50}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 481
    .line 482
    .line 483
    goto/16 :goto_2

    .line 484
    .line 485
    :cond_e
    const/4 v6, 0x0

    .line 486
    goto :goto_4

    .line 487
    :cond_f
    const/4 v8, 0x1

    .line 488
    const v6, 0x5de56971

    .line 489
    .line 490
    .line 491
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 492
    .line 493
    .line 494
    sget-object v6, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 495
    .line 496
    invoke-virtual {v6, v4, v0, v7, v8}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 497
    .line 498
    .line 499
    move-result-object v23

    .line 500
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 501
    .line 502
    .line 503
    goto/16 :goto_3

    .line 504
    .line 505
    :cond_10
    const/4 v4, 0x0

    .line 506
    const/high16 v18, 0x70000000

    .line 507
    .line 508
    const v17, 0x30c00

    .line 509
    .line 510
    .line 511
    const v6, 0x33a9aafb

    .line 512
    .line 513
    .line 514
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 515
    .line 516
    .line 517
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 518
    .line 519
    .line 520
    goto/16 :goto_1

    .line 521
    .line 522
    :cond_11
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 523
    .line 524
    .line 525
    goto :goto_5

    .line 526
    :cond_12
    invoke-static {v3}, LX/003;->A0u(LX/J7I;)V

    .line 527
    .line 528
    .line 529
    :goto_5
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 530
    .line 531
    .line 532
    move-result-object v1

    .line 533
    if-eqz v1, :cond_13

    .line 534
    .line 535
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$2;

    .line 536
    .line 537
    move-object/from16 v43, v0

    .line 538
    .line 539
    move-object/from16 v44, v15

    .line 540
    .line 541
    move-object/from16 v45, v14

    .line 542
    .line 543
    move/from16 p0, v28

    .line 544
    .line 545
    move-object/from16 p1, p7

    .line 546
    .line 547
    move-object/from16 p2, p6

    .line 548
    .line 549
    move-object/from16 p3, v13

    .line 550
    .line 551
    move/from16 p4, v2

    .line 552
    .line 553
    invoke-direct/range {v43 .. v51}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 554
    .line 555
    .line 556
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 557
    .line 558
    :cond_13
    return-void
.end method

.method public static final ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V
    .locals 36
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v23, p1

    .line 1
    .line 2
    move-object/from16 v22, p2

    .line 3
    .line 4
    const v0, 0x5a97d7df

    .line 5
    .line 6
    .line 7
    move-object/from16 v2, p4

    .line 8
    .line 9
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 v1, p5

    .line 13
    .line 14
    and-int/lit8 v0, p5, 0x6

    .line 15
    .line 16
    move-object/from16 v13, p0

    .line 17
    .line 18
    if-nez v0, :cond_b

    .line 19
    .line 20
    invoke-static {v13, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    or-int v4, v4, p5

    .line 29
    .line 30
    :goto_0
    move/from16 v5, p6

    .line 31
    .line 32
    and-int/lit8 v8, p6, 0x2

    .line 33
    .line 34
    if-eqz v8, :cond_a

    .line 35
    .line 36
    or-int/lit8 v4, v4, 0x30

    .line 37
    .line 38
    :cond_0
    :goto_1
    and-int/lit16 v0, v1, 0x180

    .line 39
    .line 40
    if-nez v0, :cond_3

    .line 41
    .line 42
    and-int/lit8 v0, p6, 0x4

    .line 43
    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    move-object/from16 v0, v22

    .line 47
    .line 48
    invoke-interface {v2, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    const/16 v0, 0x100

    .line 53
    .line 54
    if-nez v3, :cond_2

    .line 55
    .line 56
    :cond_1
    const/16 v0, 0x80

    .line 57
    .line 58
    :cond_2
    or-int/2addr v4, v0

    .line 59
    :cond_3
    and-int/lit8 v7, p6, 0x8

    .line 60
    .line 61
    move-object/from16 v6, p3

    .line 62
    .line 63
    if-eqz v7, :cond_9

    .line 64
    .line 65
    or-int/lit16 v4, v4, 0xc00

    .line 66
    .line 67
    :cond_4
    :goto_2
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-static {v0, v2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_c

    .line 76
    .line 77
    invoke-interface {v2}, LX/2d4;->AgT()V

    .line 78
    .line 79
    .line 80
    and-int/lit8 v0, p5, 0x1

    .line 81
    .line 82
    const/16 v21, 0x0

    .line 83
    .line 84
    if-eqz v0, :cond_6

    .line 85
    .line 86
    invoke-interface {v2}, LX/2d4;->AEs()Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-nez v0, :cond_6

    .line 91
    .line 92
    invoke-static {v5, v2, v4}, LX/003;->A0B(ILX/2d4;I)I

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    :cond_5
    move-object/from16 v21, v6

    .line 97
    .line 98
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAf()V

    .line 99
    .line 100
    .line 101
    sget-object v20, LX/2sI;->A02:LX/2wD;

    .line 102
    .line 103
    move-object/from16 v3, v23

    .line 104
    .line 105
    move-object/from16 v0, v20

    .line 106
    .line 107
    invoke-interface {v3, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    const/high16 v0, 0x42300000    # 44.0f

    .line 112
    .line 113
    invoke-static {v3, v0}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v9

    .line 117
    sget-object v3, LX/2Id;->A05:LX/2rU;

    .line 118
    .line 119
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmallPlusNano:F

    .line 120
    .line 121
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-static {v0, v2, v3}, LX/3Rr;->A0B(LX/Cl0;LX/2d4;LX/2rU;)LX/3BI;

    .line 126
    .line 127
    .line 128
    move-result-object v8

    .line 129
    move-object v0, v2

    .line 130
    check-cast v0, LX/J7I;

    .line 131
    .line 132
    iget-wide v6, v0, LX/J7I;->A06:J

    .line 133
    .line 134
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 135
    .line 136
    .line 137
    move-result v11

    .line 138
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    invoke-static {v2, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 143
    .line 144
    .line 145
    move-result-object v7

    .line 146
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 147
    .line 148
    iget-object v3, v0, LX/J7I;->A0V:LX/3DJ;

    .line 149
    .line 150
    if-nez v3, :cond_d

    .line 151
    .line 152
    invoke-static {}, LX/1VY;->A00()V

    .line 153
    .line 154
    .line 155
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    throw v0

    .line 160
    :cond_6
    if-eqz v8, :cond_7

    .line 161
    .line 162
    sget-object v23, LX/3C1;->A00:LX/3Cb;

    .line 163
    .line 164
    :cond_7
    and-int/lit8 v0, p6, 0x4

    .line 165
    .line 166
    if-eqz v0, :cond_8

    .line 167
    .line 168
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 169
    .line 170
    and-int/lit8 v0, v4, 0xe

    .line 171
    .line 172
    or-int/2addr v3, v0

    .line 173
    invoke-static {v13, v2, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionQuestion(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v22

    .line 177
    and-int/lit16 v4, v4, -0x381

    .line 178
    .line 179
    :cond_8
    if-eqz v7, :cond_5

    .line 180
    .line 181
    goto :goto_3

    .line 182
    :cond_9
    and-int/lit16 v0, v1, 0xc00

    .line 183
    .line 184
    if-nez v0, :cond_4

    .line 185
    .line 186
    invoke-static {v2, v6}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    or-int/2addr v4, v0

    .line 191
    goto :goto_2

    .line 192
    :cond_a
    and-int/lit8 v0, p5, 0x30

    .line 193
    .line 194
    if-nez v0, :cond_0

    .line 195
    .line 196
    move-object/from16 v0, v23

    .line 197
    .line 198
    invoke-static {v2, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 199
    .line 200
    .line 201
    move-result v0

    .line 202
    or-int/2addr v4, v0

    .line 203
    goto/16 :goto_1

    .line 204
    .line 205
    :cond_b
    move v4, v1

    .line 206
    goto/16 :goto_0

    .line 207
    .line 208
    :cond_c
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 209
    .line 210
    .line 211
    move-object/from16 v21, v6

    .line 212
    .line 213
    goto/16 :goto_5

    .line 214
    .line 215
    :cond_d
    invoke-static {v2, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 216
    .line 217
    .line 218
    sget-object v9, LX/3Cl;->A04:LX/JDN;

    .line 219
    .line 220
    invoke-static {v2, v8, v9}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 221
    .line 222
    .line 223
    move-result-object v8

    .line 224
    invoke-static {v2, v6, v8, v11}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 225
    .line 226
    .line 227
    move-result-object v19

    .line 228
    sget-object v6, LX/3Cl;->A02:LX/JDM;

    .line 229
    .line 230
    invoke-static {v2, v7, v6}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 231
    .line 232
    .line 233
    move-result-object v18

    .line 234
    sget-object v11, LX/CgK;->A00:LX/CgK;

    .line 235
    .line 236
    iget-object v12, v13, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 237
    .line 238
    iget-object v7, v13, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 239
    .line 240
    sget v29, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconSize:F

    .line 241
    .line 242
    sget v30, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconCornerRadius:F

    .line 243
    .line 244
    invoke-static {v13}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 245
    .line 246
    .line 247
    move-result v31

    .line 248
    sget v32, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->ApprovalIconGlyphSize:F

    .line 249
    .line 250
    const/4 v3, 0x0

    .line 251
    const/16 p1, 0x184

    .line 252
    .line 253
    const/16 v25, 0x0

    .line 254
    .line 255
    move-object/from16 v26, v12

    .line 256
    .line 257
    move-object/from16 v27, v7

    .line 258
    .line 259
    move-object/from16 v28, v25

    .line 260
    .line 261
    move-object/from16 v33, v25

    .line 262
    .line 263
    move-object/from16 v34, v25

    .line 264
    .line 265
    move-object/from16 v35, v2

    .line 266
    .line 267
    move/from16 p0, v3

    .line 268
    .line 269
    invoke-static/range {v26 .. v37}, Lcom/facebook/aura/skills/view/common/HatchConnectorIconKt;->ConnectorIcon-VRRgpyE(Ljava/lang/String;Ljava/lang/Integer;LX/3C1;FFIFLX/JOw;LX/JDN;LX/2d4;II)V

    .line 270
    .line 271
    .line 272
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 273
    .line 274
    const/high16 v12, 0x3f800000    # 1.0f

    .line 275
    .line 276
    const/4 v7, 0x1

    .line 277
    invoke-virtual {v11, v14, v12, v7}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 278
    .line 279
    .line 280
    move-result-object v12

    .line 281
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 282
    .line 283
    invoke-static {v11}, LX/Dn6;->A00(F)LX/CP5;

    .line 284
    .line 285
    .line 286
    move-result-object v14

    .line 287
    sget-object v11, LX/2Id;->A02:LX/2sS;

    .line 288
    .line 289
    invoke-static {v14, v2, v11, v3}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 290
    .line 291
    .line 292
    move-result-object v17

    .line 293
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 294
    .line 295
    .line 296
    move-result v16

    .line 297
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 298
    .line 299
    .line 300
    move-result-object v14

    .line 301
    invoke-static {v2, v12}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 302
    .line 303
    .line 304
    move-result-object v15

    .line 305
    invoke-static {v2, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 306
    .line 307
    .line 308
    move-object/from16 v12, v17

    .line 309
    .line 310
    invoke-static {v2, v12, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 311
    .line 312
    .line 313
    invoke-static {v2, v14, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 314
    .line 315
    .line 316
    move-object/from16 v14, v19

    .line 317
    .line 318
    move/from16 v12, v16

    .line 319
    .line 320
    invoke-static {v6, v14, v2, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 321
    .line 322
    .line 323
    move-object/from16 v12, v18

    .line 324
    .line 325
    invoke-static {v2, v15, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 326
    .line 327
    .line 328
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 329
    .line 330
    const/16 p5, 0x6

    .line 331
    .line 332
    invoke-static {v2, v12}, LX/07H;->A0N(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 333
    .line 334
    .line 335
    move-result-object v28

    .line 336
    invoke-static {v2, v12}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 337
    .line 338
    .line 339
    move-result-wide v26

    .line 340
    const/16 v34, 0x2

    .line 341
    .line 342
    shr-int/lit8 v4, v4, 0x6

    .line 343
    .line 344
    invoke-static {v4}, LX/006;->A06(I)I

    .line 345
    .line 346
    .line 347
    move-result p4

    .line 348
    const/16 p6, 0x39f2

    .line 349
    .line 350
    move-object/from16 v24, v22

    .line 351
    .line 352
    move-object/from16 v29, v25

    .line 353
    .line 354
    move-object/from16 v30, v25

    .line 355
    .line 356
    move-object/from16 v31, v25

    .line 357
    .line 358
    move/from16 v32, v3

    .line 359
    .line 360
    move/from16 v33, v3

    .line 361
    .line 362
    move/from16 v35, v34

    .line 363
    .line 364
    move-object/from16 p0, v25

    .line 365
    .line 366
    move-object/from16 p1, v25

    .line 367
    .line 368
    move-object/from16 p2, v25

    .line 369
    .line 370
    move-object/from16 p3, v2

    .line 371
    .line 372
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 373
    .line 374
    .line 375
    if-nez v21, :cond_f

    .line 376
    .line 377
    const v4, -0x456a1465

    .line 378
    .line 379
    .line 380
    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    .line 381
    .line 382
    .line 383
    :goto_4
    invoke-static {v0, v3, v7}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 384
    .line 385
    .line 386
    :goto_5
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 387
    .line 388
    .line 389
    move-result-object v2

    .line 390
    if-eqz v2, :cond_e

    .line 391
    .line 392
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalIdentityRow$2;

    .line 393
    .line 394
    move-object v6, v0

    .line 395
    move-object v7, v13

    .line 396
    move-object/from16 v8, v23

    .line 397
    .line 398
    move-object/from16 v9, v22

    .line 399
    .line 400
    move-object/from16 v10, v21

    .line 401
    .line 402
    move v11, v1

    .line 403
    move v12, v5

    .line 404
    invoke-direct/range {v6 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalIdentityRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;II)V

    .line 405
    .line 406
    .line 407
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 408
    .line 409
    :cond_e
    return-void

    .line 410
    :cond_f
    const v4, -0x456a1464

    .line 411
    .line 412
    .line 413
    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    .line 414
    .line 415
    .line 416
    const/high16 v12, 0x41000000    # 8.0f

    .line 417
    .line 418
    move-object/from16 v4, v20

    .line 419
    .line 420
    invoke-static {v4, v12}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 421
    .line 422
    .line 423
    move-result-object v15

    .line 424
    sget-object v4, LX/Dn6;->A06:LX/Dps;

    .line 425
    .line 426
    invoke-static {v4, v2, v11, v3}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 427
    .line 428
    .line 429
    move-result-object v14

    .line 430
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 431
    .line 432
    .line 433
    move-result v12

    .line 434
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 435
    .line 436
    .line 437
    move-result-object v4

    .line 438
    invoke-static {v2, v15}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 439
    .line 440
    .line 441
    move-result-object v11

    .line 442
    invoke-static {v2, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 443
    .line 444
    .line 445
    invoke-static {v2, v14, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 446
    .line 447
    .line 448
    invoke-static {v2, v4, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 449
    .line 450
    .line 451
    move-object/from16 v4, v19

    .line 452
    .line 453
    invoke-static {v6, v4, v2, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 454
    .line 455
    .line 456
    move-object/from16 v4, v18

    .line 457
    .line 458
    invoke-static {v2, v11, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 459
    .line 460
    .line 461
    move-object/from16 v4, v21

    .line 462
    .line 463
    invoke-static {v2, v4, v3}, LX/002;->A1N(Ljava/lang/Object;LX/JDN;I)V

    .line 464
    .line 465
    .line 466
    invoke-static {v0, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 467
    .line 468
    .line 469
    goto :goto_4
.end method

.method public static final ApprovalsSectionHeader(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 22

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    const v0, 0x72236d26

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v1, v8}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    or-int v6, p3, v0

    .line 23
    .line 24
    :goto_0
    move/from16 v2, p4

    .line 25
    .line 26
    and-int/lit8 v5, p4, 0x2

    .line 27
    .line 28
    if-eqz v5, :cond_5

    .line 29
    .line 30
    or-int/lit8 v6, v6, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    invoke-static {v6}, LX/005;->A1G(I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0, v1, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_4

    .line 41
    .line 42
    if-eqz v5, :cond_1

    .line 43
    .line 44
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 45
    .line 46
    :cond_1
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 47
    .line 48
    invoke-static {v1, v0}, LX/07H;->A0N(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 49
    .line 50
    .line 51
    move-result-object v12

    .line 52
    invoke-static {v1, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 53
    .line 54
    .line 55
    move-result-wide v10

    .line 56
    const/4 v13, 0x0

    .line 57
    invoke-static {v4}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-static {v0}, LX/3Rr;->A07(LX/3C1;)LX/3C1;

    .line 62
    .line 63
    .line 64
    move-result-object v7

    .line 65
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 70
    .line 71
    if-ne v5, v0, :cond_2

    .line 72
    .line 73
    sget-object v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalsSectionHeader$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalsSectionHeader$1$1;

    .line 74
    .line 75
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    :cond_2
    check-cast v5, LX/JDM;

    .line 79
    .line 80
    const/4 v0, 0x0

    .line 81
    invoke-static {v7, v5, v0}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 82
    .line 83
    .line 84
    move-result-object v9

    .line 85
    and-int/lit8 p2, v6, 0xe

    .line 86
    .line 87
    const/16 p4, 0x3ff0

    .line 88
    .line 89
    move-object v14, v13

    .line 90
    move-object v15, v13

    .line 91
    move/from16 v17, v0

    .line 92
    .line 93
    move/from16 v18, v0

    .line 94
    .line 95
    move/from16 v19, v0

    .line 96
    .line 97
    move-object/from16 v20, v13

    .line 98
    .line 99
    move-object/from16 v21, v13

    .line 100
    .line 101
    move-object/from16 p0, v13

    .line 102
    .line 103
    move-object/from16 p1, v1

    .line 104
    .line 105
    move/from16 p3, v0

    .line 106
    .line 107
    move/from16 v16, v0

    .line 108
    .line 109
    invoke-static/range {v8 .. v26}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 110
    .line 111
    .line 112
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    if-eqz v1, :cond_3

    .line 117
    .line 118
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalsSectionHeader$2;

    .line 119
    .line 120
    invoke-direct {v0, v8, v4, v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalsSectionHeader$2;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 121
    .line 122
    .line 123
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 124
    .line 125
    :cond_3
    return-void

    .line 126
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 127
    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_5
    and-int/lit8 v0, p3, 0x30

    .line 131
    .line 132
    if-nez v0, :cond_0

    .line 133
    .line 134
    invoke-static {v1, v4}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    or-int/2addr v6, v0

    .line 139
    goto :goto_1

    .line 140
    :cond_6
    move v6, v3

    .line 141
    goto :goto_0
.end method

.method public static final CheckoutApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    const v0, -0x7f9cfeab

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 p5, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    move-object/from16 v0, p5

    .line 19
    .line 20
    invoke-static {v0, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    or-int/2addr v6, v1

    .line 29
    :goto_0
    and-int/lit8 v0, v1, 0x30

    .line 30
    .line 31
    move/from16 v15, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static {v2, v15}, LX/004;->A0j(LX/2d4;Z)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    or-int/2addr v6, v0

    .line 40
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 41
    .line 42
    move-object/from16 v30, p2

    .line 43
    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    move-object/from16 v0, v30

    .line 47
    .line 48
    invoke-static {v2, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    or-int/2addr v6, v0

    .line 53
    :cond_1
    move/from16 p4, p6

    .line 54
    .line 55
    and-int/lit8 v5, p6, 0x8

    .line 56
    .line 57
    if-eqz v5, :cond_4

    .line 58
    .line 59
    or-int/lit16 v6, v6, 0xc00

    .line 60
    .line 61
    :cond_2
    :goto_1
    and-int/lit16 v3, v6, 0x493

    .line 62
    .line 63
    const/16 v0, 0x492

    .line 64
    .line 65
    const/4 v8, 0x0

    .line 66
    const/4 v13, 0x1

    .line 67
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-static {v0, v2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_9

    .line 76
    .line 77
    if-eqz v5, :cond_3

    .line 78
    .line 79
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 80
    .line 81
    :cond_3
    invoke-static/range {p5 .. p5}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 82
    .line 83
    .line 84
    move-result-object v7

    .line 85
    sget-object v12, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 86
    .line 87
    shr-int/lit8 v0, v6, 0x9

    .line 88
    .line 89
    and-int/lit8 v0, v0, 0xe

    .line 90
    .line 91
    or-int/lit16 v5, v0, 0x180

    .line 92
    .line 93
    sget v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 94
    .line 95
    shl-int/lit8 v0, v3, 0x3

    .line 96
    .line 97
    or-int/2addr v5, v0

    .line 98
    invoke-static {v4, v7, v12, v2, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-static {v0}, LX/3Rr;->A07(LX/3C1;)LX/3C1;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    const/high16 v0, 0x41200000    # 10.0f

    .line 107
    .line 108
    invoke-static {v2, v0}, LX/3Rs;->A09(LX/2d4;F)LX/3BI;

    .line 109
    .line 110
    .line 111
    move-result-object v14

    .line 112
    move-object v0, v2

    .line 113
    check-cast v0, LX/J7I;

    .line 114
    .line 115
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 116
    .line 117
    .line 118
    move-result v11

    .line 119
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 120
    .line 121
    .line 122
    move-result-object v10

    .line 123
    invoke-static {v2, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 124
    .line 125
    .line 126
    move-result-object v9

    .line 127
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 128
    .line 129
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 130
    .line 131
    if-nez v5, :cond_6

    .line 132
    .line 133
    invoke-static {}, LX/1VY;->A00()V

    .line 134
    .line 135
    .line 136
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    throw v0

    .line 141
    :cond_4
    and-int/lit16 v0, v1, 0xc00

    .line 142
    .line 143
    if-nez v0, :cond_2

    .line 144
    .line 145
    invoke-static {v2, v4}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    or-int/2addr v6, v0

    .line 150
    goto :goto_1

    .line 151
    :cond_5
    move v6, v1

    .line 152
    goto :goto_0

    .line 153
    :cond_6
    invoke-static {v2, v0, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 154
    .line 155
    .line 156
    invoke-static {v2, v14, v10, v9, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 157
    .line 158
    .line 159
    invoke-static/range {p5 .. p5}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->purposeSummaryText(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v19

    .line 163
    if-nez v19, :cond_8

    .line 164
    .line 165
    const v5, 0x2bfcada0

    .line 166
    .line 167
    .line 168
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 169
    .line 170
    .line 171
    and-int/lit8 v5, v6, 0xe

    .line 172
    .line 173
    or-int v7, v3, v5

    .line 174
    .line 175
    move-object/from16 v5, p5

    .line 176
    .line 177
    invoke-static {v5, v2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionTitleKt;->agentPermissionQuestion(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v19

    .line 181
    :goto_2
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 182
    .line 183
    .line 184
    and-int/lit8 v14, v6, 0xe

    .line 185
    .line 186
    or-int v22, v3, v14

    .line 187
    .line 188
    const/16 v23, 0xa

    .line 189
    .line 190
    const/16 v16, 0x0

    .line 191
    .line 192
    move-object/from16 v17, p5

    .line 193
    .line 194
    move-object/from16 v18, v16

    .line 195
    .line 196
    move-object/from16 v20, v16

    .line 197
    .line 198
    move-object/from16 v21, v2

    .line 199
    .line 200
    invoke-static/range {v17 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V

    .line 201
    .line 202
    .line 203
    const v5, 0x7f1200ac

    .line 204
    .line 205
    .line 206
    invoke-static {v2, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v17

    .line 210
    sget-object v5, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 211
    .line 212
    invoke-static {v2, v5}, LX/006;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 213
    .line 214
    .line 215
    move-result-object v20

    .line 216
    sget-object v21, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 217
    .line 218
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 219
    .line 220
    sget-object v9, LX/2sI;->A02:LX/2wD;

    .line 221
    .line 222
    const/high16 v7, 0x42580000    # 54.0f

    .line 223
    .line 224
    const/4 v5, 0x0

    .line 225
    invoke-static {v9, v7, v5, v5, v5}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 226
    .line 227
    .line 228
    move-result-object v10

    .line 229
    const/high16 v9, 0x42100000    # 36.0f

    .line 230
    .line 231
    invoke-static {v10, v9}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 232
    .line 233
    .line 234
    move-result-object v19

    .line 235
    const v9, 0xe000

    .line 236
    .line 237
    .line 238
    shl-int/lit8 p1, v6, 0x6

    .line 239
    .line 240
    and-int p1, p1, v9

    .line 241
    .line 242
    const p3, 0x7ffbfc5

    .line 243
    .line 244
    .line 245
    const p0, 0x30c00

    .line 246
    .line 247
    .line 248
    move-object/from16 v22, v16

    .line 249
    .line 250
    move/from16 v23, v8

    .line 251
    .line 252
    move/from16 v24, v8

    .line 253
    .line 254
    move/from16 v25, v8

    .line 255
    .line 256
    move/from16 v26, v8

    .line 257
    .line 258
    move/from16 v27, v8

    .line 259
    .line 260
    move-object/from16 v28, v16

    .line 261
    .line 262
    move-object/from16 v29, v16

    .line 263
    .line 264
    move-object/from16 v31, v16

    .line 265
    .line 266
    move-object/from16 v32, v16

    .line 267
    .line 268
    move-object/from16 v33, v16

    .line 269
    .line 270
    move-object/from16 v34, v16

    .line 271
    .line 272
    move-object/from16 v35, v16

    .line 273
    .line 274
    move-object/from16 v36, v16

    .line 275
    .line 276
    move-object/from16 v37, v16

    .line 277
    .line 278
    move-object/from16 v38, v16

    .line 279
    .line 280
    move/from16 v39, v8

    .line 281
    .line 282
    move/from16 v40, v8

    .line 283
    .line 284
    move/from16 v41, v8

    .line 285
    .line 286
    move/from16 v42, v8

    .line 287
    .line 288
    move-object/from16 v43, v2

    .line 289
    .line 290
    move/from16 p2, v8

    .line 291
    .line 292
    invoke-static/range {v16 .. v47}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 293
    .line 294
    .line 295
    if-eqz v15, :cond_7

    .line 296
    .line 297
    const v6, 0x539eb28a

    .line 298
    .line 299
    .line 300
    invoke-interface {v2, v6}, LX/2d4;->Agj(I)V

    .line 301
    .line 302
    .line 303
    invoke-static {v11, v7, v5, v5, v5}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 304
    .line 305
    .line 306
    move-result-object v18

    .line 307
    or-int/lit16 v3, v3, 0x1b0

    .line 308
    .line 309
    or-int/2addr v3, v14

    .line 310
    move-object/from16 v16, p5

    .line 311
    .line 312
    move-object/from16 v17, v12

    .line 313
    .line 314
    move-object/from16 v19, v2

    .line 315
    .line 316
    move/from16 v20, v3

    .line 317
    .line 318
    move/from16 v21, v8

    .line 319
    .line 320
    invoke-static/range {v16 .. v21}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionConfirmingStatus(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 321
    .line 322
    .line 323
    :goto_3
    invoke-static {v0, v4, v8, v13}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 324
    .line 325
    .line 326
    move-result-object v4

    .line 327
    goto :goto_4

    .line 328
    :cond_7
    const v3, 0x53a1e123

    .line 329
    .line 330
    .line 331
    invoke-interface {v2, v3}, LX/2d4;->Agj(I)V

    .line 332
    .line 333
    .line 334
    goto :goto_3

    .line 335
    :cond_8
    const v5, 0x2bfca9a1

    .line 336
    .line 337
    .line 338
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 339
    .line 340
    .line 341
    goto/16 :goto_2

    .line 342
    .line 343
    :cond_9
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 344
    .line 345
    .line 346
    :goto_4
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 347
    .line 348
    .line 349
    move-result-object v2

    .line 350
    if-eqz v2, :cond_a

    .line 351
    .line 352
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CheckoutApprovalRow$2;

    .line 353
    .line 354
    move-object/from16 v42, v0

    .line 355
    .line 356
    move-object/from16 v43, p5

    .line 357
    .line 358
    move/from16 p0, v15

    .line 359
    .line 360
    move-object/from16 p1, v30

    .line 361
    .line 362
    move-object/from16 p2, v4

    .line 363
    .line 364
    move/from16 p3, v1

    .line 365
    .line 366
    invoke-direct/range {v42 .. v48}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CheckoutApprovalRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 367
    .line 368
    .line 369
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 370
    .line 371
    :cond_a
    return-void
.end method

.method public static final CollapsedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    const v0, -0x3b720b5a

    .line 1
    .line 2
    .line 3
    move-object v7, p3

    .line 4
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    move p3, p4

    .line 8
    and-int/lit8 v0, p4, 0x6

    .line 9
    .line 10
    move-object v3, p0

    .line 11
    if-nez v0, :cond_6

    .line 12
    .line 13
    invoke-static {p0, v7, p4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v0}, LX/003;->A06(I)I

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    or-int/2addr v2, p4

    .line 22
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    invoke-static {v7, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    or-int/2addr v2, v0

    .line 31
    :cond_0
    move p4, p5

    .line 32
    and-int/lit8 v1, p5, 0x4

    .line 33
    .line 34
    if-eqz v1, :cond_5

    .line 35
    .line 36
    or-int/lit16 v2, v2, 0x180

    .line 37
    .line 38
    :cond_1
    :goto_1
    invoke-static {v2}, LX/005;->A1I(I)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    invoke-static {v0, v7, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_4

    .line 47
    .line 48
    if-eqz v1, :cond_2

    .line 49
    .line 50
    sget-object p2, LX/3C1;->A00:LX/3Cb;

    .line 51
    .line 52
    :cond_2
    const/4 v5, 0x0

    .line 53
    invoke-static {p2}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    const/high16 v0, 0x42800000    # 64.0f

    .line 58
    .line 59
    invoke-static {v1, v0}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-static {v0, v5, p1}, LX/3Rs;->A08(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-static {v0}, LX/3Rr;->A07(LX/3C1;)LX/3C1;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CollapsedApprovalRow$1;

    .line 72
    .line 73
    invoke-direct {v1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CollapsedApprovalRow$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 74
    .line 75
    .line 76
    const v0, -0x5c34636f

    .line 77
    .line 78
    .line 79
    invoke-static {v7, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 84
    .line 85
    or-int/lit16 v0, v0, 0xc00

    .line 86
    .line 87
    and-int/lit8 v8, v2, 0xe

    .line 88
    .line 89
    or-int/2addr v8, v0

    .line 90
    const/4 p0, 0x4

    .line 91
    invoke-static/range {v3 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V

    .line 92
    .line 93
    .line 94
    :goto_2
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    if-eqz v0, :cond_3

    .line 99
    .line 100
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CollapsedApprovalRow$2;

    .line 101
    .line 102
    move-object p0, v3

    .line 103
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$CollapsedApprovalRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 104
    .line 105
    .line 106
    iput-object v8, v0, LX/J7V;->A06:LX/JDN;

    .line 107
    .line 108
    :cond_3
    return-void

    .line 109
    :cond_4
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 110
    .line 111
    .line 112
    goto :goto_2

    .line 113
    :cond_5
    and-int/lit16 v0, p3, 0x180

    .line 114
    .line 115
    if-nez v0, :cond_1

    .line 116
    .line 117
    invoke-static {v7, p2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    or-int/2addr v2, v0

    .line 122
    goto :goto_1

    .line 123
    :cond_6
    move v2, p4

    .line 124
    goto :goto_0
.end method

.method public static final ExpandedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            "ZZ",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v13, p6

    .line 1
    .line 2
    const v0, 0x24693391

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p7

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v14, p8

    .line 11
    .line 12
    and-int/lit8 v0, p8, 0x6

    .line 13
    .line 14
    move-object/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_a

    .line 17
    .line 18
    invoke-static {v7, v1, v14}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    or-int v3, v3, p8

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 29
    .line 30
    move-object/from16 v8, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v8, v1, v14}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v0}, LX/003;->A07(I)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v3, v0

    .line 43
    :cond_0
    and-int/lit16 v0, v14, 0x180

    .line 44
    .line 45
    move/from16 v9, p2

    .line 46
    .line 47
    if-nez v0, :cond_1

    .line 48
    .line 49
    invoke-static {v1, v9}, LX/004;->A0k(LX/2d4;Z)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    or-int/2addr v3, v0

    .line 54
    :cond_1
    and-int/lit16 v0, v14, 0xc00

    .line 55
    .line 56
    move/from16 v10, p3

    .line 57
    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    invoke-static {v1, v10}, LX/004;->A0l(LX/2d4;Z)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    or-int/2addr v3, v0

    .line 65
    :cond_2
    and-int/lit16 v0, v14, 0x6000

    .line 66
    .line 67
    move-object/from16 v11, p4

    .line 68
    .line 69
    if-nez v0, :cond_3

    .line 70
    .line 71
    invoke-static {v1, v11}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    or-int/2addr v3, v0

    .line 76
    :cond_3
    const/high16 v0, 0x30000

    .line 77
    .line 78
    and-int v0, v0, p8

    .line 79
    .line 80
    move-object/from16 v12, p5

    .line 81
    .line 82
    if-nez v0, :cond_4

    .line 83
    .line 84
    invoke-static {v1, v12}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    or-int/2addr v3, v0

    .line 89
    :cond_4
    move/from16 v15, p9

    .line 90
    .line 91
    and-int/lit8 v2, p9, 0x40

    .line 92
    .line 93
    const/high16 v0, 0x180000

    .line 94
    .line 95
    if-nez v2, :cond_5

    .line 96
    .line 97
    and-int v0, v0, p8

    .line 98
    .line 99
    if-nez v0, :cond_6

    .line 100
    .line 101
    invoke-static {v1, v13}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    :cond_5
    or-int/2addr v3, v0

    .line 106
    :cond_6
    const v0, 0x92493

    .line 107
    .line 108
    .line 109
    invoke-static {v0, v3}, LX/005;->A1O(II)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    invoke-static {v0, v1, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_9

    .line 118
    .line 119
    if-eqz v2, :cond_7

    .line 120
    .line 121
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 122
    .line 123
    :cond_7
    invoke-static {v7}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 124
    .line 125
    .line 126
    move-result-object v6

    .line 127
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 128
    .line 129
    shr-int/lit8 v0, v3, 0x12

    .line 130
    .line 131
    and-int/lit8 v0, v0, 0xe

    .line 132
    .line 133
    or-int/lit16 v2, v0, 0x180

    .line 134
    .line 135
    sget v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 136
    .line 137
    shl-int/lit8 v0, v4, 0x3

    .line 138
    .line 139
    or-int/2addr v2, v0

    .line 140
    invoke-static {v13, v6, v5, v1, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    invoke-static {v0}, LX/3Rr;->A07(LX/3C1;)LX/3C1;

    .line 145
    .line 146
    .line 147
    move-result-object p4

    .line 148
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;

    .line 149
    .line 150
    move-object/from16 v17, v7

    .line 151
    .line 152
    move-object/from16 v18, v8

    .line 153
    .line 154
    move/from16 p0, v9

    .line 155
    .line 156
    move-object/from16 p1, v11

    .line 157
    .line 158
    move-object/from16 p2, v12

    .line 159
    .line 160
    move-object/from16 v16, v2

    .line 161
    .line 162
    invoke-direct/range {v16 .. v22}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;Z)V

    .line 163
    .line 164
    .line 165
    const v0, 0x66fbb83c

    .line 166
    .line 167
    .line 168
    invoke-static {v1, v2, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 169
    .line 170
    .line 171
    move-result-object p6

    .line 172
    or-int/lit16 v2, v4, 0xc00

    .line 173
    .line 174
    and-int/lit8 v0, v3, 0xe

    .line 175
    .line 176
    or-int/2addr v2, v0

    .line 177
    const/16 p9, 0x4

    .line 178
    .line 179
    const/16 p5, 0x0

    .line 180
    .line 181
    move-object/from16 p3, v7

    .line 182
    .line 183
    move/from16 p8, v2

    .line 184
    .line 185
    invoke-static/range {p3 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V

    .line 186
    .line 187
    .line 188
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    if-eqz v0, :cond_8

    .line 193
    .line 194
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;

    .line 195
    .line 196
    invoke-direct/range {v6 .. v15}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 197
    .line 198
    .line 199
    iput-object v6, v0, LX/J7V;->A06:LX/JDN;

    .line 200
    .line 201
    :cond_8
    return-void

    .line 202
    :cond_9
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 203
    .line 204
    .line 205
    goto :goto_1

    .line 206
    :cond_a
    move v3, v14

    .line 207
    goto/16 :goto_0
.end method

.method public static final synthetic access$ActionedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ActionedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgentPermissionApprovalsScreen_djqs_MU$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$ApprovalDecisionButtons(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalDecisionButtons(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalIdentityRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;Ljava/lang/String;LX/JDN;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalsSectionHeader(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalsSectionHeader(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->CheckoutApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CollapsedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->CollapsedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ExpandedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ExpandedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$actionedApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->actionedApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$approvalsStatusItem(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalsStatusItem(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$openApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDN;LX/JDM;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->openApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDN;LX/JDM;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final actionedApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1O1;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    sget-object v2, Lcom/facebook/aura/agentpermission/ComposableSingletons$AgentPermissionApprovalsScreenKt;->lambda$-80254027:LX/JDQ;

    .line 9
    .line 10
    const-string v1, "actioned_approvals_header"

    .line 11
    .line 12
    const-string v0, "section_header"

    .line 13
    .line 14
    invoke-interface {p0, v1, v0, v2}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 15
    .line 16
    .line 17
    iget-object v5, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$1;

    .line 20
    .line 21
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$1;

    .line 28
    .line 29
    invoke-direct {v3, v0, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$1;-><init>(LX/JDN;Ljava/util/List;)V

    .line 30
    .line 31
    .line 32
    :goto_0
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$2;

    .line 33
    .line 34
    invoke-direct {v2, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$2;-><init>(Ljava/util/List;)V

    .line 35
    .line 36
    .line 37
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;

    .line 38
    .line 39
    invoke-direct {v1, v5, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;-><init>(Ljava/util/List;LX/JDM;)V

    .line 40
    .line 41
    .line 42
    const v0, 0x799532c4

    .line 43
    .line 44
    .line 45
    invoke-static {v1, v0}, LX/002;->A0W(Ljava/lang/Object;I)LX/Ddo;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-interface {p0, v3, v2, v0, v4}, LX/1O1;->APU(LX/JDM;LX/JDM;LX/JDO;I)V

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void

    .line 53
    :cond_1
    const/4 v3, 0x0

    .line 54
    goto :goto_0
.end method

.method public static final approvalHistorySummary(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->scopeSummary:Ljava/lang/String;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    :goto_0
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-nez v1, :cond_1

    .line 25
    .line 26
    return-object v0

    .line 27
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->purposeSummary:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/3Rs;->A0P(Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    return-object v2
.end method

.method public static final approvalHistoryTimestamp(JLX/2d4;I)Ljava/lang/String;
    .locals 7

    .line 0
    const v0, 0x1366c690

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    const-wide/16 v3, 0x0

    .line 7
    .line 8
    cmp-long v0, p0, v3

    .line 9
    .line 10
    if-gtz v0, :cond_0

    .line 11
    .line 12
    invoke-static {p2}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    return-object v0

    .line 17
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v1

    .line 21
    sub-long/2addr v1, p0

    .line 22
    cmp-long v0, v1, v3

    .line 23
    .line 24
    if-ltz v0, :cond_1

    .line 25
    .line 26
    move-wide v3, v1

    .line 27
    :cond_1
    const-wide/32 v0, 0xea60

    .line 28
    .line 29
    .line 30
    div-long/2addr v3, v0

    .line 31
    long-to-int v2, v3

    .line 32
    const/4 v6, 0x1

    .line 33
    const/4 v4, 0x0

    .line 34
    if-ge v2, v6, :cond_2

    .line 35
    .line 36
    const v0, -0x3aded93f

    .line 37
    .line 38
    .line 39
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 40
    .line 41
    .line 42
    const v0, 0x7f120175

    .line 43
    .line 44
    .line 45
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    :goto_0
    invoke-static {p2}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    :goto_1
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 54
    .line 55
    .line 56
    return-object v0

    .line 57
    :cond_2
    const v0, -0x3adda92e

    .line 58
    .line 59
    .line 60
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 61
    .line 62
    .line 63
    move-object v5, p2

    .line 64
    check-cast v5, LX/J7I;

    .line 65
    .line 66
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 67
    .line 68
    .line 69
    const/16 v1, 0x3c

    .line 70
    .line 71
    if-ge v2, v1, :cond_3

    .line 72
    .line 73
    const v0, -0x3add29e9

    .line 74
    .line 75
    .line 76
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 77
    .line 78
    .line 79
    const v0, 0x7f10000d

    .line 80
    .line 81
    .line 82
    :goto_2
    invoke-static {v2, p2, v0}, LX/18b;->A02(ILX/2d4;I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    goto :goto_0

    .line 87
    :cond_3
    const v0, -0x3adae40e

    .line 88
    .line 89
    .line 90
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 91
    .line 92
    .line 93
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 94
    .line 95
    .line 96
    div-int/2addr v2, v1

    .line 97
    const/16 v1, 0x18

    .line 98
    .line 99
    if-ge v2, v1, :cond_4

    .line 100
    .line 101
    const v0, -0x3ad9ce63

    .line 102
    .line 103
    .line 104
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 105
    .line 106
    .line 107
    const v0, 0x7f10000c

    .line 108
    .line 109
    .line 110
    goto :goto_2

    .line 111
    :cond_4
    const v0, -0x3ad79f0e

    .line 112
    .line 113
    .line 114
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 115
    .line 116
    .line 117
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 118
    .line 119
    .line 120
    div-int/2addr v2, v1

    .line 121
    const/4 v0, 0x7

    .line 122
    if-ge v2, v0, :cond_5

    .line 123
    .line 124
    const v0, -0x3ad69d20

    .line 125
    .line 126
    .line 127
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 128
    .line 129
    .line 130
    const v0, 0x7f10000b

    .line 131
    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_5
    const v0, -0x3ad4790e

    .line 135
    .line 136
    .line 137
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 138
    .line 139
    .line 140
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 141
    .line 142
    .line 143
    invoke-static {p2}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v0, v6}, Ljava/util/Calendar;->get(I)I

    .line 155
    .line 156
    .line 157
    move-result v2

    .line 158
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    invoke-virtual {v0, v6}, Ljava/util/Calendar;->get(I)I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    const/4 v1, 0x4

    .line 167
    if-ne v2, v0, :cond_6

    .line 168
    .line 169
    const/16 v1, 0x8

    .line 170
    .line 171
    :cond_6
    const v0, 0x10010

    .line 172
    .line 173
    .line 174
    or-int/2addr v1, v0

    .line 175
    invoke-static {v3, p0, p1, v1}, Landroid/text/format/DateUtils;->formatDateTime(Landroid/content/Context;JI)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    goto :goto_1
.end method

.method public static final approvalHistoryTitle(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/lang/String;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    iget-object v0, v1, Lcom/facebook/aura/gateway/ApprovalRecord;->summaryTitle:Ljava/lang/String;

    .line 10
    .line 11
    :cond_0
    const-string v1, ""

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/gateway/ApprovalRecord;->summaryTitle:Ljava/lang/String;

    .line 26
    .line 27
    :goto_0
    if-nez v0, :cond_6

    .line 28
    .line 29
    :cond_1
    return-object v1

    .line 30
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->purposeSummary:Ljava/lang/String;

    .line 31
    .line 32
    if-eqz v0, :cond_3

    .line 33
    .line 34
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_3

    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->purposeSummary:Ljava/lang/String;

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->displayName:Ljava/lang/String;

    .line 44
    .line 45
    if-eqz v0, :cond_4

    .line 46
    .line 47
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_4

    .line 52
    .line 53
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->displayName:Ljava/lang/String;

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->permissionQuestion:Ljava/lang/String;

    .line 57
    .line 58
    if-eqz v0, :cond_5

    .line 59
    .line 60
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-nez v0, :cond_5

    .line 65
    .line 66
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->permissionQuestion:Ljava/lang/String;

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 70
    .line 71
    :cond_6
    return-object v0
.end method

.method public static final approvalsStatusItem(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1O1;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->ERROR:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-ne v1, v0, :cond_1

    .line 6
    .line 7
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;

    .line 8
    .line 9
    invoke-direct {v1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 10
    .line 11
    .line 12
    const v0, 0x2ecee11

    .line 13
    .line 14
    .line 15
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const-string v1, "approvals_error"

    .line 20
    .line 21
    const-string v0, "status"

    .line 22
    .line 23
    :goto_0
    invoke-interface {p0, v1, v0, v2}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void

    .line 27
    :cond_1
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 28
    .line 29
    if-ne v1, v0, :cond_0

    .line 30
    .line 31
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 32
    .line 33
    if-nez v0, :cond_2

    .line 34
    .line 35
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 36
    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    :cond_2
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;

    .line 40
    .line 41
    invoke-direct {v1, p1, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;)V

    .line 42
    .line 43
    .line 44
    const v0, -0x6a76ac06

    .line 45
    .line 46
    .line 47
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    const-string v1, "approvals_load_more"

    .line 52
    .line 53
    const-string v0, "load_more"

    .line 54
    .line 55
    goto :goto_0
.end method

.method public static final decisionLabel(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2d4;I)Ljava/lang/String;
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalRecord:Lcom/facebook/aura/gateway/ApprovalRecord;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz p0, :cond_10

    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 10
    .line 11
    :goto_0
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->TIMED_OUT:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 12
    .line 13
    if-eq v2, v0, :cond_f

    .line 14
    .line 15
    if-eqz p0, :cond_e

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 18
    .line 19
    :goto_1
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->TIMED_OUT:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 20
    .line 21
    if-eq v2, v0, :cond_f

    .line 22
    .line 23
    if-eqz p0, :cond_d

    .line 24
    .line 25
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 26
    .line 27
    :goto_2
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->ALLOW_ALWAYS:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 28
    .line 29
    if-ne v2, v0, :cond_0

    .line 30
    .line 31
    const v0, 0x5348e2f7

    .line 32
    .line 33
    .line 34
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 35
    .line 36
    .line 37
    const v0, 0x7f1200e9

    .line 38
    .line 39
    .line 40
    :goto_3
    invoke-static {p1, v0}, LX/3Rs;->A0K(LX/2d4;I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    return-object v0

    .line 45
    :cond_0
    if-eqz p0, :cond_1

    .line 46
    .line 47
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 48
    .line 49
    :goto_4
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->AUTO_ALLOW:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 50
    .line 51
    if-ne v2, v0, :cond_2

    .line 52
    .line 53
    const v0, 0x5348f595

    .line 54
    .line 55
    .line 56
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 57
    .line 58
    .line 59
    const v0, 0x7f1200eb

    .line 60
    .line 61
    .line 62
    goto :goto_3

    .line 63
    :cond_1
    move-object v2, v1

    .line 64
    goto :goto_4

    .line 65
    :cond_2
    if-eqz p0, :cond_c

    .line 66
    .line 67
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 68
    .line 69
    :goto_5
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->ALLOW_ONCE:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 70
    .line 71
    if-ne v2, v0, :cond_3

    .line 72
    .line 73
    const v0, 0x534907f2

    .line 74
    .line 75
    .line 76
    :goto_6
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 77
    .line 78
    .line 79
    const v0, 0x7f1200e8

    .line 80
    .line 81
    .line 82
    goto :goto_3

    .line 83
    :cond_3
    if-eqz p0, :cond_4

    .line 84
    .line 85
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 86
    .line 87
    :goto_7
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->DENY_ALWAYS:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 88
    .line 89
    if-ne v2, v0, :cond_5

    .line 90
    .line 91
    const v0, 0x53491a16

    .line 92
    .line 93
    .line 94
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 95
    .line 96
    .line 97
    const v0, 0x7f1200ea

    .line 98
    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_4
    move-object v2, v1

    .line 102
    goto :goto_7

    .line 103
    :cond_5
    if-eqz p0, :cond_b

    .line 104
    .line 105
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->decision:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 106
    .line 107
    :goto_8
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->DENY:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 108
    .line 109
    if-ne v2, v0, :cond_7

    .line 110
    .line 111
    const v2, 0x53492bd1

    .line 112
    .line 113
    .line 114
    :cond_6
    invoke-interface {p1, v2}, LX/2d4;->Agj(I)V

    .line 115
    .line 116
    .line 117
    const v0, 0x7f1200ee

    .line 118
    .line 119
    .line 120
    goto :goto_3

    .line 121
    :cond_7
    if-eqz p0, :cond_8

    .line 122
    .line 123
    iget-object v2, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 124
    .line 125
    :goto_9
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->APPROVED:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 126
    .line 127
    if-ne v2, v0, :cond_9

    .line 128
    .line 129
    const v0, 0x53493cf2

    .line 130
    .line 131
    .line 132
    goto :goto_6

    .line 133
    :cond_8
    move-object v2, v1

    .line 134
    goto :goto_9

    .line 135
    :cond_9
    if-eqz p0, :cond_a

    .line 136
    .line 137
    iget-object v1, p0, Lcom/facebook/aura/gateway/ApprovalRecord;->status:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 138
    .line 139
    :cond_a
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordStatus;->DENIED:Lcom/facebook/aura/gateway/ApprovalRecordStatus;

    .line 140
    .line 141
    const v2, 0x53494df1

    .line 142
    .line 143
    .line 144
    if-eq v1, v0, :cond_6

    .line 145
    .line 146
    const v0, 0x53495772

    .line 147
    .line 148
    .line 149
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 150
    .line 151
    .line 152
    const v0, 0x7f1200ef

    .line 153
    .line 154
    .line 155
    goto :goto_3

    .line 156
    :cond_b
    move-object v2, v1

    .line 157
    goto :goto_8

    .line 158
    :cond_c
    move-object v2, v1

    .line 159
    goto :goto_5

    .line 160
    :cond_d
    move-object v2, v1

    .line 161
    goto/16 :goto_2

    .line 162
    .line 163
    :cond_e
    move-object v2, v1

    .line 164
    goto/16 :goto_1

    .line 165
    .line 166
    :cond_f
    const v0, 0x5348d074

    .line 167
    .line 168
    .line 169
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 170
    .line 171
    .line 172
    const v0, 0x7f1200f0

    .line 173
    .line 174
    .line 175
    goto/16 :goto_3

    .line 176
    .line 177
    :cond_10
    move-object v2, v1

    .line 178
    goto/16 :goto_0
.end method

.method public static final openApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDN;LX/JDM;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1O1;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    sget-object v2, Lcom/facebook/aura/agentpermission/ComposableSingletons$AgentPermissionApprovalsScreenKt;->lambda$213780472:LX/JDQ;

    .line 9
    .line 10
    const-string v1, "open_approvals_header"

    .line 11
    .line 12
    const-string v0, "section_header"

    .line 13
    .line 14
    invoke-interface {p0, v1, v0, v2}, LX/1O1;->APS(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;)V

    .line 15
    .line 16
    .line 17
    iget-object v5, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$1;

    .line 20
    .line 21
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;

    .line 28
    .line 29
    invoke-direct {v3, v0, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;-><init>(LX/JDN;Ljava/util/List;)V

    .line 30
    .line 31
    .line 32
    :goto_0
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$2;

    .line 33
    .line 34
    invoke-direct {v2, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$2;-><init>(Ljava/util/List;)V

    .line 35
    .line 36
    .line 37
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;

    .line 38
    .line 39
    invoke-direct {v1, v5, p1, p3, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;LX/JDN;)V

    .line 40
    .line 41
    .line 42
    const v0, 0x799532c4

    .line 43
    .line 44
    .line 45
    invoke-static {v1, v0}, LX/002;->A0W(Ljava/lang/Object;I)LX/Ddo;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-interface {p0, v3, v2, v0, v4}, LX/1O1;->APU(LX/JDM;LX/JDM;LX/JDO;I)V

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void

    .line 53
    :cond_1
    const/4 v3, 0x0

    .line 54
    goto :goto_0
.end method

.method public static final rememberAgentPermissionApprovalsViewModel(Ljava/lang/String;LX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;
    .locals 4

    .line 0
    invoke-static {p1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 5
    .line 6
    invoke-virtual {v0, p0}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->normalize(Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "agent_permission_approvals_"

    .line 11
    .line 12
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$Factory;

    .line 17
    .line 18
    invoke-direct {v3, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$Factory;-><init>(LX/AHE;)V

    .line 19
    .line 20
    .line 21
    invoke-static {p1}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    if-eqz v2, :cond_0

    .line 26
    .line 27
    invoke-static {v2}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 32
    .line 33
    invoke-static {v3, v2, v1, v0, p0}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_0
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    throw v0
.end method

.method public static final rememberOpenAgentPermissionTaskCount(Ljava/lang/String;LX/2d4;II)I
    .locals 1

    .line 0
    invoke-static {p3, p0}, LX/3Rp;->A0w(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    and-int/lit8 v0, p2, 0xe

    .line 5
    .line 6
    invoke-static {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->rememberAgentPermissionApprovalsViewModel(Ljava/lang/String;LX/2d4;I)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object p0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->uiState:LX/2J3;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, p0, v0}, LX/3Rr;->A0Z(LX/2d4;LX/2J3;I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 20
    .line 21
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0
.end method

.method public static final rememberOpenAgentPermissionTaskCount$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 5
    .line 6
    return-object p0
.end method
