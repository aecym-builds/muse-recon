.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$save$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {
        0xa2
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->label:I

    .line 3
    .line 4
    const/4 v6, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v6, :cond_0

    .line 8
    .line 9
    :try_start_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    goto :goto_0
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    throw v0

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :try_start_1
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 22
    .line 23
    iget-object v4, v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->singleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 24
    .line 25
    sget-object v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Operation;->SAVE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Operation;

    .line 26
    .line 27
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;

    .line 31
    .line 32
    invoke-direct {v0, v5, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V

    .line 33
    .line 34
    .line 35
    iput v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->label:I

    .line 36
    .line 37
    invoke-interface {v4, v3, v0, p0}, Lcom/facebook/aura/common/coroutines/SingleFlight;->invoke(Ljava/lang/Object;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-ne v0, v7, :cond_2

    .line 42
    .line 43
    return-object v7
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 44
    :catch_0
    move-exception v1

    .line 45
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 46
    .line 47
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$checkOwner(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 54
    .line 55
    invoke-static {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$handleSaveFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    :goto_0
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 59
    .line 60
    return-object v7

    .line 61
    :catch_1
    move-exception v0

    .line 62
    throw v0
.end method
