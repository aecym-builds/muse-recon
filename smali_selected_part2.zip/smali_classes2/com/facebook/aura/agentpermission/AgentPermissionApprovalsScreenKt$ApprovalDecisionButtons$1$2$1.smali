.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/2or;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$2$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/2or;
    .locals 2

    .line 0
    sget p0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 1
    .line 2
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 3
    .line 4
    new-instance v0, LX/1XE;

    .line 5
    .line 6
    invoke-direct {v0, p0, v1, p0, v1}, LX/1XE;-><init>(FFFF)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 2

    .line 268435456
    sget p0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 268435457
    .line 268435458
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 268435459
    .line 268435460
    new-instance v0, LX/1XE;

    .line 268435461
    .line 268435462
    invoke-direct {v0, p0, v1, p0, v1}, LX/1XE;-><init>(FFFF)V

    .line 268435463
    .line 268435464
    .line 268435465
    return-object v0
.end method
