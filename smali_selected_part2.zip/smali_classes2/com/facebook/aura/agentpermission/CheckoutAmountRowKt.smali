.class public abstract Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final CheckoutAmountChevron(ZLX/3C1;LX/2d4;II)V
    .locals 13

    .line 0
    move-object v8, p1

    .line 1
    const v0, -0x58f526d6

    .line 2
    .line 3
    .line 4
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    move/from16 v2, p3

    .line 8
    .line 9
    and-int/lit8 v0, p3, 0x6

    .line 10
    .line 11
    move v3, p0

    .line 12
    if-nez v0, :cond_6

    .line 13
    .line 14
    invoke-static {p2, p0}, LX/004;->A0i(LX/2d4;Z)I

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    or-int v4, v4, p3

    .line 19
    .line 20
    :goto_0
    move/from16 v1, p4

    .line 21
    .line 22
    and-int/lit8 v7, p4, 0x2

    .line 23
    .line 24
    if-eqz v7, :cond_5

    .line 25
    .line 26
    or-int/lit8 v4, v4, 0x30

    .line 27
    .line 28
    :cond_0
    :goto_1
    and-int/lit8 v6, v4, 0x13

    .line 29
    .line 30
    const/16 v0, 0x12

    .line 31
    .line 32
    const/4 v5, 0x0

    .line 33
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    invoke-static {v0, p2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    if-eqz v7, :cond_1

    .line 44
    .line 45
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 46
    .line 47
    :cond_1
    const v0, 0x7f0800e8

    .line 48
    .line 49
    .line 50
    invoke-static {p2, v0, v5}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 51
    .line 52
    .line 53
    move-result-object v9

    .line 54
    const/4 v5, 0x6

    .line 55
    if-eqz p0, :cond_3

    .line 56
    .line 57
    const v0, 0xfb955d2

    .line 58
    .line 59
    .line 60
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 61
    .line 62
    .line 63
    sget-object v0, Lcom/facebook/aura/vds/compose/icons/AuraIconDefaults;->INSTANCE:Lcom/facebook/aura/vds/compose/icons/AuraIconDefaults;

    .line 64
    .line 65
    invoke-virtual {v0, p2, v5}, Lcom/facebook/aura/vds/compose/icons/AuraIconDefaults;->colors-WaAFU9c(LX/2d4;I)J

    .line 66
    .line 67
    .line 68
    move-result-wide v12

    .line 69
    :goto_2
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    sget-object v10, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 73
    .line 74
    shr-int/lit8 v0, v4, 0x3

    .line 75
    .line 76
    and-int/lit8 v0, v0, 0xe

    .line 77
    .line 78
    or-int/lit16 v4, v0, 0xd80

    .line 79
    .line 80
    sget v0, LX/2l9;->$stable:I

    .line 81
    .line 82
    shl-int/lit8 v0, v0, 0x3

    .line 83
    .line 84
    or-int/2addr v4, v0

    .line 85
    const/16 p4, 0x20

    .line 86
    .line 87
    const/4 v11, 0x0

    .line 88
    move-object p1, v11

    .line 89
    move/from16 p3, v4

    .line 90
    .line 91
    invoke-static/range {v8 .. v17}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 92
    .line 93
    .line 94
    :goto_3
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 95
    .line 96
    .line 97
    move-result-object v4

    .line 98
    if-eqz v4, :cond_2

    .line 99
    .line 100
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountChevron$1;

    .line 101
    .line 102
    invoke-direct {v0, v3, v8, v2, v1}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountChevron$1;-><init>(ZLX/3C1;II)V

    .line 103
    .line 104
    .line 105
    iput-object v0, v4, LX/J7V;->A06:LX/JDN;

    .line 106
    .line 107
    :cond_2
    return-void

    .line 108
    :cond_3
    const v0, 0xfb959b6

    .line 109
    .line 110
    .line 111
    invoke-static {p2, v0}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    iget-wide v12, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->tertiaryText:J

    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_4
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 119
    .line 120
    .line 121
    goto :goto_3

    .line 122
    :cond_5
    and-int/lit8 v0, p3, 0x30

    .line 123
    .line 124
    if-nez v0, :cond_0

    .line 125
    .line 126
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    or-int/2addr v4, v0

    .line 131
    goto :goto_1

    .line 132
    :cond_6
    move v4, v2

    .line 133
    goto :goto_0
.end method

.method public static final CheckoutAmountChildRow(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZLX/3C1;LX/2d4;II)V
    .locals 33

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    const v0, 0x26e540d

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v0, :cond_8

    .line 17
    .line 18
    invoke-static {v4, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    or-int v6, v6, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move/from16 v12, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v2, v12}, LX/004;->A0j(LX/2d4;Z)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v6, v0

    .line 39
    :cond_0
    and-int/lit8 v7, p5, 0x4

    .line 40
    .line 41
    if-eqz v7, :cond_7

    .line 42
    .line 43
    or-int/lit16 v6, v6, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    and-int/lit16 v5, v6, 0x93

    .line 46
    .line 47
    const/16 v0, 0x92

    .line 48
    .line 49
    const/4 v11, 0x0

    .line 50
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0, v2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_6

    .line 59
    .line 60
    if-eqz v7, :cond_2

    .line 61
    .line 62
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 65
    .line 66
    const/4 v13, 0x6

    .line 67
    invoke-static {v2, v0}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 68
    .line 69
    .line 70
    move-result-object v18

    .line 71
    invoke-static {v2, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 72
    .line 73
    .line 74
    move-result-wide v16

    .line 75
    sget v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->$stable:I

    .line 76
    .line 77
    and-int/lit8 v0, v6, 0xe

    .line 78
    .line 79
    or-int/2addr v5, v0

    .line 80
    invoke-static {v4, v2, v5}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->checkoutAmountLabel(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;LX/2d4;I)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v14

    .line 84
    const/4 v15, 0x0

    .line 85
    if-eqz p1, :cond_4

    .line 86
    .line 87
    const v0, -0x1af49a8d

    .line 88
    .line 89
    .line 90
    invoke-static {v3, v2, v0}, LX/3Rr;->A0A(LX/3C1;LX/2d4;I)LX/3C1;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 95
    .line 96
    invoke-static {v5, v0}, LX/3Rr;->A09(LX/3C1;F)LX/3C1;

    .line 97
    .line 98
    .line 99
    move-result-object v5

    .line 100
    invoke-static {v2}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 101
    .line 102
    .line 103
    move-result-object v10

    .line 104
    move-object v0, v2

    .line 105
    check-cast v0, LX/J7I;

    .line 106
    .line 107
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 108
    .line 109
    .line 110
    move-result v9

    .line 111
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 112
    .line 113
    .line 114
    move-result-object v8

    .line 115
    invoke-static {v2, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 116
    .line 117
    .line 118
    move-result-object v7

    .line 119
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 120
    .line 121
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 122
    .line 123
    if-eqz v5, :cond_9

    .line 124
    .line 125
    invoke-static {v2, v0, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v2, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 129
    .line 130
    .line 131
    const/16 v32, 0x3ff2

    .line 132
    .line 133
    move-object/from16 v19, v15

    .line 134
    .line 135
    move-object/from16 v20, v15

    .line 136
    .line 137
    move-object/from16 v21, v15

    .line 138
    .line 139
    move/from16 v22, v11

    .line 140
    .line 141
    move/from16 v23, v11

    .line 142
    .line 143
    move/from16 v24, v11

    .line 144
    .line 145
    move/from16 v25, v11

    .line 146
    .line 147
    move-object/from16 v26, v15

    .line 148
    .line 149
    move-object/from16 v27, v15

    .line 150
    .line 151
    move-object/from16 v28, v15

    .line 152
    .line 153
    move-object/from16 v29, v2

    .line 154
    .line 155
    move/from16 v30, v11

    .line 156
    .line 157
    move/from16 v31, v11

    .line 158
    .line 159
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 160
    .line 161
    .line 162
    iget-object v14, v4, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->amount:Ljava/lang/String;

    .line 163
    .line 164
    const v5, -0x6b02a276

    .line 165
    .line 166
    .line 167
    if-eqz v14, :cond_5

    .line 168
    .line 169
    const v5, -0x6b02a275

    .line 170
    .line 171
    .line 172
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 173
    .line 174
    .line 175
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 176
    .line 177
    .line 178
    :goto_2
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 179
    .line 180
    .line 181
    invoke-static {v0, v11}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 182
    .line 183
    .line 184
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 185
    .line 186
    .line 187
    move-result-object v2

    .line 188
    if-eqz v2, :cond_3

    .line 189
    .line 190
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountChildRow$3;

    .line 191
    .line 192
    move-object/from16 p1, v4

    .line 193
    .line 194
    move/from16 p2, v12

    .line 195
    .line 196
    move-object/from16 p3, v3

    .line 197
    .line 198
    move/from16 p4, v1

    .line 199
    .line 200
    move-object/from16 p0, v0

    .line 201
    .line 202
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountChildRow$3;-><init>(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZLX/3C1;II)V

    .line 203
    .line 204
    .line 205
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 206
    .line 207
    :cond_3
    return-void

    .line 208
    :cond_4
    const v0, -0x1af10506

    .line 209
    .line 210
    .line 211
    invoke-static {v3, v2, v0}, LX/3Rr;->A0A(LX/3C1;LX/2d4;I)LX/3C1;

    .line 212
    .line 213
    .line 214
    move-result-object v5

    .line 215
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 216
    .line 217
    invoke-static {v5, v0}, LX/3Rr;->A09(LX/3C1;F)LX/3C1;

    .line 218
    .line 219
    .line 220
    move-result-object v5

    .line 221
    invoke-static {v2, v0, v11}, LX/007;->A0g(LX/2d4;FI)LX/3BI;

    .line 222
    .line 223
    .line 224
    move-result-object v10

    .line 225
    move-object v0, v2

    .line 226
    check-cast v0, LX/J7I;

    .line 227
    .line 228
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 229
    .line 230
    .line 231
    move-result v9

    .line 232
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 233
    .line 234
    .line 235
    move-result-object v8

    .line 236
    invoke-static {v2, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 237
    .line 238
    .line 239
    move-result-object v7

    .line 240
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 241
    .line 242
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 243
    .line 244
    if-eqz v5, :cond_9

    .line 245
    .line 246
    invoke-static {v2, v0, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 247
    .line 248
    .line 249
    invoke-static {v2, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 250
    .line 251
    .line 252
    sget-object v8, LX/CgK;->A00:LX/CgK;

    .line 253
    .line 254
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 255
    .line 256
    const/high16 v6, 0x3f800000    # 1.0f

    .line 257
    .line 258
    const/4 v5, 0x1

    .line 259
    invoke-virtual {v8, v7, v6, v5}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 260
    .line 261
    .line 262
    move-result-object v20

    .line 263
    const/16 p4, 0x3ff0

    .line 264
    .line 265
    move-object/from16 v19, v14

    .line 266
    .line 267
    move-wide/from16 v21, v16

    .line 268
    .line 269
    move-object/from16 v23, v18

    .line 270
    .line 271
    move-object/from16 v24, v15

    .line 272
    .line 273
    move-object/from16 v25, v15

    .line 274
    .line 275
    move-object/from16 v26, v15

    .line 276
    .line 277
    move/from16 v27, v11

    .line 278
    .line 279
    move/from16 v28, v11

    .line 280
    .line 281
    move/from16 v29, v11

    .line 282
    .line 283
    move/from16 v30, v11

    .line 284
    .line 285
    move-object/from16 v31, v15

    .line 286
    .line 287
    move-object/from16 v32, v15

    .line 288
    .line 289
    move-object/from16 p0, v15

    .line 290
    .line 291
    move-object/from16 p1, v2

    .line 292
    .line 293
    move/from16 p2, v11

    .line 294
    .line 295
    move/from16 p3, v11

    .line 296
    .line 297
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 298
    .line 299
    .line 300
    iget-object v14, v4, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->amount:Ljava/lang/String;

    .line 301
    .line 302
    const v5, 0x554730aa

    .line 303
    .line 304
    .line 305
    if-eqz v14, :cond_5

    .line 306
    .line 307
    const v5, 0x554730ab

    .line 308
    .line 309
    .line 310
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 311
    .line 312
    .line 313
    invoke-static {v13}, LX/2wS;->A01(I)LX/2wS;

    .line 314
    .line 315
    .line 316
    move-result-object v21

    .line 317
    const/16 v32, 0x3fb2

    .line 318
    .line 319
    move-object/from16 v19, v15

    .line 320
    .line 321
    move-object/from16 v20, v15

    .line 322
    .line 323
    move/from16 v22, v11

    .line 324
    .line 325
    move/from16 v23, v11

    .line 326
    .line 327
    move/from16 v24, v11

    .line 328
    .line 329
    move/from16 v25, v11

    .line 330
    .line 331
    move-object/from16 v27, v15

    .line 332
    .line 333
    move-object/from16 v28, v15

    .line 334
    .line 335
    move-object/from16 v29, v2

    .line 336
    .line 337
    move/from16 v31, v11

    .line 338
    .line 339
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 340
    .line 341
    .line 342
    goto/16 :goto_2

    .line 343
    .line 344
    :cond_5
    invoke-interface {v2, v5}, LX/2d4;->Agj(I)V

    .line 345
    .line 346
    .line 347
    goto/16 :goto_2

    .line 348
    .line 349
    :cond_6
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 350
    .line 351
    .line 352
    goto/16 :goto_3

    .line 353
    .line 354
    :cond_7
    and-int/lit16 v0, v1, 0x180

    .line 355
    .line 356
    if-nez v0, :cond_1

    .line 357
    .line 358
    invoke-static {v2, v3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 359
    .line 360
    .line 361
    move-result v0

    .line 362
    or-int/2addr v6, v0

    .line 363
    goto/16 :goto_1

    .line 364
    .line 365
    :cond_8
    move v6, v1

    .line 366
    goto/16 :goto_0

    .line 367
    .line 368
    :cond_9
    invoke-static {}, LX/1VY;->A00()V

    .line 369
    .line 370
    .line 371
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    throw v0
.end method

.method public static final CheckoutAmountDueAtPropertyNote(LX/3C1;LX/2d4;II)V
    .locals 21

    .line 0
    move-object/from16 v7, p0

    .line 1
    .line 2
    const v0, 0x38f9e0a1

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p1

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v6, p3, 0x1

    .line 13
    .line 14
    const/4 v5, 0x2

    .line 15
    move/from16 v3, p2

    .line 16
    .line 17
    if-eqz v6, :cond_3

    .line 18
    .line 19
    or-int/lit8 v4, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, v4, 0x3

    .line 22
    .line 23
    const/4 v14, 0x0

    .line 24
    invoke-static {v0, v5}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    if-eqz v6, :cond_0

    .line 35
    .line 36
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 37
    .line 38
    :cond_0
    const v0, 0x7f120152

    .line 39
    .line 40
    .line 41
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 46
    .line 47
    invoke-static {v1, v0}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 48
    .line 49
    .line 50
    move-result-object v10

    .line 51
    invoke-static {v1, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 52
    .line 53
    .line 54
    move-result-wide v8

    .line 55
    shl-int/lit8 v0, v4, 0x3

    .line 56
    .line 57
    and-int/lit8 p1, v0, 0x70

    .line 58
    .line 59
    const/16 p3, 0x3ff0

    .line 60
    .line 61
    const/4 v11, 0x0

    .line 62
    move-object v12, v11

    .line 63
    move-object v13, v11

    .line 64
    move v15, v14

    .line 65
    move/from16 v16, v14

    .line 66
    .line 67
    move/from16 v17, v14

    .line 68
    .line 69
    move-object/from16 v18, v11

    .line 70
    .line 71
    move-object/from16 v19, v11

    .line 72
    .line 73
    move-object/from16 v20, v11

    .line 74
    .line 75
    move-object/from16 p0, v1

    .line 76
    .line 77
    move/from16 p2, v14

    .line 78
    .line 79
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 80
    .line 81
    .line 82
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    if-eqz v1, :cond_1

    .line 87
    .line 88
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountDueAtPropertyNote$1;

    .line 89
    .line 90
    invoke-direct {v0, v7, v3, v2}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountDueAtPropertyNote$1;-><init>(LX/3C1;II)V

    .line 91
    .line 92
    .line 93
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 94
    .line 95
    :cond_1
    return-void

    .line 96
    :cond_2
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 101
    .line 102
    if-nez v0, :cond_4

    .line 103
    .line 104
    invoke-static {v1, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    or-int v4, v4, p2

    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_4
    move v4, v3

    .line 112
    goto :goto_0
.end method

.method public static final CheckoutAmountLine(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 40

    .line 0
    move-object/from16 v22, p4

    .line 1
    .line 2
    const v0, -0x5ecf8f00

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p5

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v7, p6

    .line 11
    .line 12
    and-int/lit8 v0, p6, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_18

    .line 17
    .line 18
    invoke-static {v5, v1, v7}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    or-int v9, v9, p6

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 29
    .line 30
    move/from16 v25, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    move/from16 v0, v25

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v9, v0

    .line 41
    :cond_0
    and-int/lit16 v0, v7, 0x180

    .line 42
    .line 43
    move/from16 v24, p2

    .line 44
    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    move/from16 v0, v24

    .line 48
    .line 49
    invoke-static {v1, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    or-int/2addr v9, v0

    .line 54
    :cond_1
    and-int/lit16 v0, v7, 0xc00

    .line 55
    .line 56
    move-object/from16 v23, p3

    .line 57
    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    move-object/from16 v0, v23

    .line 61
    .line 62
    invoke-static {v1, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v9, v0

    .line 67
    :cond_2
    move/from16 p5, p7

    .line 68
    .line 69
    and-int/lit8 v2, p7, 0x10

    .line 70
    .line 71
    if-eqz v2, :cond_17

    .line 72
    .line 73
    or-int/lit16 v9, v9, 0x6000

    .line 74
    .line 75
    :cond_3
    :goto_1
    invoke-static {v9}, LX/009;->A1I(I)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    invoke-static {v0, v1, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_16

    .line 84
    .line 85
    if-eqz v2, :cond_4

    .line 86
    .line 87
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 88
    .line 89
    :cond_4
    iget-boolean v0, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->emphasized:Z

    .line 90
    .line 91
    const/16 v16, 0x6

    .line 92
    .line 93
    if-eqz v0, :cond_15

    .line 94
    .line 95
    const v0, 0x16d84f6e

    .line 96
    .line 97
    .line 98
    invoke-static {v1, v0}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 99
    .line 100
    .line 101
    move-result-object v8

    .line 102
    invoke-static {v1, v8}, LX/07H;->A0N(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 103
    .line 104
    .line 105
    move-result-object v30

    .line 106
    :goto_2
    move-object v0, v1

    .line 107
    check-cast v0, LX/J7I;

    .line 108
    .line 109
    const/4 v2, 0x0

    .line 110
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 111
    .line 112
    .line 113
    iget-boolean v3, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->subdued:Z

    .line 114
    .line 115
    if-eqz v3, :cond_14

    .line 116
    .line 117
    const v3, 0x16d85dad

    .line 118
    .line 119
    .line 120
    invoke-static {v1, v8, v3}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 125
    .line 126
    :goto_3
    move-wide/from16 p6, v3

    .line 127
    .line 128
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 129
    .line 130
    .line 131
    iget-object v4, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->layout:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 132
    .line 133
    sget-object v3, Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;->WRAPPING:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 134
    .line 135
    invoke-static {v4, v3}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    sget v4, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->$stable:I

    .line 140
    .line 141
    and-int/lit8 v3, v9, 0xe

    .line 142
    .line 143
    or-int/2addr v3, v4

    .line 144
    invoke-static {v5, v1, v3}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->checkoutAmountLabel(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;LX/2d4;I)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v26

    .line 148
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->amount:Ljava/lang/String;

    .line 149
    .line 150
    move-object/from16 v21, v3

    .line 151
    .line 152
    if-eqz p1, :cond_9

    .line 153
    .line 154
    const v3, -0x3bc9910f

    .line 155
    .line 156
    .line 157
    invoke-interface {v1, v3}, LX/2d4;->Agj(I)V

    .line 158
    .line 159
    .line 160
    sget-object v4, LX/Dn6;->A06:LX/Dps;

    .line 161
    .line 162
    sget-object v3, LX/2Id;->A02:LX/2sS;

    .line 163
    .line 164
    invoke-static {v4, v1, v3, v2}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 165
    .line 166
    .line 167
    move-result-object v6

    .line 168
    iget-wide v3, v0, LX/J7I;->A06:J

    .line 169
    .line 170
    invoke-static {v3, v4}, LX/001;->A0A(J)I

    .line 171
    .line 172
    .line 173
    move-result v8

    .line 174
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 175
    .line 176
    .line 177
    move-result-object v4

    .line 178
    move-object/from16 v3, v22

    .line 179
    .line 180
    invoke-static {v1, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 181
    .line 182
    .line 183
    move-result-object v3

    .line 184
    sget-object v12, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 185
    .line 186
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 187
    .line 188
    if-eqz v9, :cond_19

    .line 189
    .line 190
    invoke-static {v1, v0, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 191
    .line 192
    .line 193
    sget-object v11, LX/3Cl;->A04:LX/JDN;

    .line 194
    .line 195
    invoke-static {v1, v6, v11}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 196
    .line 197
    .line 198
    move-result-object v10

    .line 199
    invoke-static {v1, v4, v10, v8}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 200
    .line 201
    .line 202
    move-result-object v15

    .line 203
    sget-object v9, LX/3Cl;->A02:LX/JDM;

    .line 204
    .line 205
    invoke-static {v1, v3, v9}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 206
    .line 207
    .line 208
    move-result-object v14

    .line 209
    sget-object v3, LX/2Id;->A04:LX/2rU;

    .line 210
    .line 211
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 212
    .line 213
    invoke-static {v1, v3}, LX/003;->A0Z(LX/2d4;LX/2rU;)LX/3BI;

    .line 214
    .line 215
    .line 216
    move-result-object v13

    .line 217
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 218
    .line 219
    .line 220
    move-result v6

    .line 221
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    invoke-static {v1, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 226
    .line 227
    .line 228
    move-result-object v3

    .line 229
    invoke-static {v1, v0, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 230
    .line 231
    .line 232
    invoke-static {v1, v13, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 233
    .line 234
    .line 235
    invoke-static {v1, v4, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 236
    .line 237
    .line 238
    invoke-static {v9, v15, v1, v6}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 239
    .line 240
    .line 241
    invoke-static {v1, v3, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 242
    .line 243
    .line 244
    sget-object v10, LX/CgK;->A00:LX/CgK;

    .line 245
    .line 246
    const/4 v6, 0x2

    .line 247
    const/4 v4, 0x0

    .line 248
    const/high16 v9, 0x3f800000    # 1.0f

    .line 249
    .line 250
    const/4 v3, 0x1

    .line 251
    invoke-virtual {v10, v8, v9, v3}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 252
    .line 253
    .line 254
    move-result-object v27

    .line 255
    const/16 p4, 0x3ff4

    .line 256
    .line 257
    const-wide/16 v28, 0x0

    .line 258
    .line 259
    move-object/from16 v31, v4

    .line 260
    .line 261
    move-object/from16 v32, v4

    .line 262
    .line 263
    move-object/from16 v33, v4

    .line 264
    .line 265
    move/from16 v34, v2

    .line 266
    .line 267
    move/from16 v35, v2

    .line 268
    .line 269
    move/from16 v36, v2

    .line 270
    .line 271
    move/from16 v37, v2

    .line 272
    .line 273
    move-object/from16 v38, v4

    .line 274
    .line 275
    move-object/from16 v39, v4

    .line 276
    .line 277
    move-object/from16 p0, v4

    .line 278
    .line 279
    move-object/from16 p1, v1

    .line 280
    .line 281
    move/from16 p2, v2

    .line 282
    .line 283
    move/from16 p3, v2

    .line 284
    .line 285
    invoke-static/range {v26 .. v44}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 286
    .line 287
    .line 288
    if-eqz v24, :cond_8

    .line 289
    .line 290
    const v8, -0x30b03a8f

    .line 291
    .line 292
    .line 293
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 294
    .line 295
    .line 296
    move/from16 v8, v16

    .line 297
    .line 298
    invoke-static {v3, v4, v1, v8, v6}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountChevron(ZLX/3C1;LX/2d4;II)V

    .line 299
    .line 300
    .line 301
    :goto_4
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 302
    .line 303
    .line 304
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 305
    .line 306
    .line 307
    iget-boolean v6, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->dueAtPropertyNote:Z

    .line 308
    .line 309
    if-eqz v6, :cond_7

    .line 310
    .line 311
    const v6, 0x512824f0

    .line 312
    .line 313
    .line 314
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 315
    .line 316
    .line 317
    invoke-static {v4, v1, v2, v3}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountDueAtPropertyNote(LX/3C1;LX/2d4;II)V

    .line 318
    .line 319
    .line 320
    :goto_5
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 321
    .line 322
    .line 323
    if-nez v21, :cond_6

    .line 324
    .line 325
    const v4, -0x2c22c94d

    .line 326
    .line 327
    .line 328
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 329
    .line 330
    .line 331
    :goto_6
    invoke-static {v0, v2, v3}, LX/3Rr;->A15(LX/J7I;ZZ)V

    .line 332
    .line 333
    .line 334
    :goto_7
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 335
    .line 336
    .line 337
    move-result-object v1

    .line 338
    if-eqz v1, :cond_5

    .line 339
    .line 340
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$3;

    .line 341
    .line 342
    move-object/from16 v38, v0

    .line 343
    .line 344
    move-object/from16 v39, v5

    .line 345
    .line 346
    move/from16 p0, v25

    .line 347
    .line 348
    move/from16 p1, v24

    .line 349
    .line 350
    move-object/from16 p2, v23

    .line 351
    .line 352
    move-object/from16 p3, v22

    .line 353
    .line 354
    move/from16 p4, v7

    .line 355
    .line 356
    invoke-direct/range {v38 .. v45}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$3;-><init>(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;II)V

    .line 357
    .line 358
    .line 359
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 360
    .line 361
    :cond_5
    return-void

    .line 362
    :cond_6
    const v6, -0x2c22c94c

    .line 363
    .line 364
    .line 365
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 366
    .line 367
    .line 368
    const/16 p4, 0x3ff2

    .line 369
    .line 370
    move-object/from16 v26, v21

    .line 371
    .line 372
    move-object/from16 v27, v4

    .line 373
    .line 374
    move-wide/from16 v28, p6

    .line 375
    .line 376
    invoke-static/range {v26 .. v44}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 377
    .line 378
    .line 379
    goto :goto_6

    .line 380
    :cond_7
    const v6, -0x2c230b0d

    .line 381
    .line 382
    .line 383
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 384
    .line 385
    .line 386
    goto :goto_5

    .line 387
    :cond_8
    const v6, 0x1aa97757

    .line 388
    .line 389
    .line 390
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 391
    .line 392
    .line 393
    goto :goto_4

    .line 394
    :cond_9
    const v3, -0x3bc2afc0

    .line 395
    .line 396
    .line 397
    invoke-interface {v1, v3}, LX/2d4;->Agj(I)V

    .line 398
    .line 399
    .line 400
    if-eqz v6, :cond_13

    .line 401
    .line 402
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 403
    .line 404
    invoke-static {v3}, LX/Dn6;->A00(F)LX/CP5;

    .line 405
    .line 406
    .line 407
    move-result-object v3

    .line 408
    sget-object v4, LX/2Id;->A05:LX/2rU;

    .line 409
    .line 410
    :goto_8
    invoke-static {v3, v1, v4, v2}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 411
    .line 412
    .line 413
    move-result-object v11

    .line 414
    iget-wide v3, v0, LX/J7I;->A06:J

    .line 415
    .line 416
    invoke-static {v3, v4}, LX/001;->A0A(J)I

    .line 417
    .line 418
    .line 419
    move-result v10

    .line 420
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 421
    .line 422
    .line 423
    move-result-object v4

    .line 424
    move-object/from16 v3, v22

    .line 425
    .line 426
    invoke-static {v1, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 427
    .line 428
    .line 429
    move-result-object v3

    .line 430
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 431
    .line 432
    iget-object v12, v0, LX/J7I;->A0V:LX/3DJ;

    .line 433
    .line 434
    if-eqz v12, :cond_19

    .line 435
    .line 436
    invoke-static {v1, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 437
    .line 438
    .line 439
    sget-object v12, LX/3Cl;->A04:LX/JDN;

    .line 440
    .line 441
    invoke-static {v1, v11, v12}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 442
    .line 443
    .line 444
    move-result-object v11

    .line 445
    invoke-static {v1, v4, v11, v10}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 446
    .line 447
    .line 448
    move-result-object v20

    .line 449
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 450
    .line 451
    invoke-static {v1, v3, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 452
    .line 453
    .line 454
    move-result-object v19

    .line 455
    sget-object v15, LX/CgK;->A00:LX/CgK;

    .line 456
    .line 457
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 458
    .line 459
    const/16 v18, 0x2

    .line 460
    .line 461
    const/4 v13, 0x0

    .line 462
    const/high16 v14, 0x3f800000    # 1.0f

    .line 463
    .line 464
    const/4 v3, 0x1

    .line 465
    invoke-virtual {v15, v4, v14, v3}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 466
    .line 467
    .line 468
    move-result-object v14

    .line 469
    invoke-static {v1}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 470
    .line 471
    .line 472
    move-result-object v17

    .line 473
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 474
    .line 475
    .line 476
    move-result v16

    .line 477
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 478
    .line 479
    .line 480
    move-result-object v15

    .line 481
    invoke-static {v1, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 482
    .line 483
    .line 484
    move-result-object v14

    .line 485
    invoke-static {v1, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 486
    .line 487
    .line 488
    move-object/from16 v9, v17

    .line 489
    .line 490
    invoke-static {v1, v9, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 491
    .line 492
    .line 493
    invoke-static {v1, v15, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 494
    .line 495
    .line 496
    move-object/from16 v11, v20

    .line 497
    .line 498
    move/from16 v9, v16

    .line 499
    .line 500
    invoke-static {v10, v11, v1, v9}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 501
    .line 502
    .line 503
    move-object/from16 v9, v19

    .line 504
    .line 505
    invoke-static {v1, v14, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 506
    .line 507
    .line 508
    if-eqz v6, :cond_12

    .line 509
    .line 510
    const v8, -0x3d915493

    .line 511
    .line 512
    .line 513
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 514
    .line 515
    .line 516
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 517
    .line 518
    .line 519
    sget-wide v8, LX/JOw;->A07:J

    .line 520
    .line 521
    :goto_9
    const/16 p4, 0x3ff2

    .line 522
    .line 523
    move-object/from16 v27, v13

    .line 524
    .line 525
    move-wide/from16 v28, v8

    .line 526
    .line 527
    move-object/from16 v31, v13

    .line 528
    .line 529
    move-object/from16 v32, v13

    .line 530
    .line 531
    move-object/from16 v33, v13

    .line 532
    .line 533
    move/from16 v34, v2

    .line 534
    .line 535
    move/from16 v35, v2

    .line 536
    .line 537
    move/from16 v36, v2

    .line 538
    .line 539
    move/from16 v37, v2

    .line 540
    .line 541
    move-object/from16 v38, v13

    .line 542
    .line 543
    move-object/from16 v39, v13

    .line 544
    .line 545
    move-object/from16 p0, v13

    .line 546
    .line 547
    move-object/from16 p1, v1

    .line 548
    .line 549
    move/from16 p2, v2

    .line 550
    .line 551
    move/from16 p3, v2

    .line 552
    .line 553
    invoke-static/range {v26 .. v44}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 554
    .line 555
    .line 556
    iget-boolean v8, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->dueAtPropertyNote:Z

    .line 557
    .line 558
    if-eqz v8, :cond_11

    .line 559
    .line 560
    const v8, -0x3d9148dd

    .line 561
    .line 562
    .line 563
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 564
    .line 565
    .line 566
    invoke-static {v13, v1, v2, v3}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountDueAtPropertyNote(LX/3C1;LX/2d4;II)V

    .line 567
    .line 568
    .line 569
    :goto_a
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 570
    .line 571
    .line 572
    if-nez v23, :cond_10

    .line 573
    .line 574
    const v8, -0x7496e5e6

    .line 575
    .line 576
    .line 577
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 578
    .line 579
    .line 580
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 581
    .line 582
    .line 583
    :goto_b
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 584
    .line 585
    .line 586
    if-eqz v21, :cond_f

    .line 587
    .line 588
    const v8, 0x5e6207f5

    .line 589
    .line 590
    .line 591
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 592
    .line 593
    .line 594
    iget-object v9, v5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->layout:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 595
    .line 596
    sget-object v8, Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;->SUMMARY:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 597
    .line 598
    if-ne v9, v8, :cond_e

    .line 599
    .line 600
    const v8, 0x2413b0bd

    .line 601
    .line 602
    .line 603
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 604
    .line 605
    .line 606
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 607
    .line 608
    invoke-static {v1, v4, v8}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 609
    .line 610
    .line 611
    :goto_c
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 612
    .line 613
    .line 614
    if-eqz v6, :cond_d

    .line 615
    .line 616
    const v8, 0x2413c182

    .line 617
    .line 618
    .line 619
    invoke-static {v1, v8}, LX/002;->A0t(LX/2d4;I)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    move-result-object v9

    .line 623
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 624
    .line 625
    if-ne v9, v8, :cond_a

    .line 626
    .line 627
    sget-object v9, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountLine$2$amountModifier$1$1;

    .line 628
    .line 629
    invoke-interface {v1, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 630
    .line 631
    .line 632
    :cond_a
    check-cast v9, LX/JDQ;

    .line 633
    .line 634
    invoke-static {v4, v9}, LX/2ub;->A00(LX/3C1;LX/JDQ;)LX/3C1;

    .line 635
    .line 636
    .line 637
    move-result-object v27

    .line 638
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 639
    .line 640
    .line 641
    const v36, 0x7fffffff

    .line 642
    .line 643
    .line 644
    const/16 v37, 0x1

    .line 645
    .line 646
    const/4 v8, 0x6

    .line 647
    :goto_d
    invoke-static {v8}, LX/2wS;->A01(I)LX/2wS;

    .line 648
    .line 649
    .line 650
    move-result-object v33

    .line 651
    const/16 p4, 0x39b0

    .line 652
    .line 653
    move-object/from16 v26, v21

    .line 654
    .line 655
    move-wide/from16 v28, p6

    .line 656
    .line 657
    invoke-static/range {v26 .. v44}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 658
    .line 659
    .line 660
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 661
    .line 662
    .line 663
    :goto_e
    if-eqz v24, :cond_c

    .line 664
    .line 665
    const v8, 0x5e732d5d

    .line 666
    .line 667
    .line 668
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 669
    .line 670
    .line 671
    if-nez v6, :cond_b

    .line 672
    .line 673
    const v8, 0x24143e1c

    .line 674
    .line 675
    .line 676
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 677
    .line 678
    .line 679
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 680
    .line 681
    invoke-static {v1, v4, v8}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 682
    .line 683
    .line 684
    :goto_f
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 685
    .line 686
    .line 687
    move/from16 v4, v18

    .line 688
    .line 689
    invoke-static {v6, v13, v1, v2, v4}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountChevron(ZLX/3C1;LX/2d4;II)V

    .line 690
    .line 691
    .line 692
    :goto_10
    invoke-static {v0, v2, v3}, LX/3Rr;->A15(LX/J7I;ZZ)V

    .line 693
    .line 694
    .line 695
    goto/16 :goto_7

    .line 696
    .line 697
    :cond_b
    const v4, 0x5e740c8a

    .line 698
    .line 699
    .line 700
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 701
    .line 702
    .line 703
    goto :goto_f

    .line 704
    :cond_c
    const v4, 0x5e74c68a

    .line 705
    .line 706
    .line 707
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 708
    .line 709
    .line 710
    goto :goto_10

    .line 711
    :cond_d
    const v8, 0x241406e0

    .line 712
    .line 713
    .line 714
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 715
    .line 716
    .line 717
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 718
    .line 719
    .line 720
    move-object/from16 v27, v4

    .line 721
    .line 722
    const/16 v36, 0x1

    .line 723
    .line 724
    const/16 v37, 0x2

    .line 725
    .line 726
    const/4 v8, 0x0

    .line 727
    goto :goto_d

    .line 728
    :cond_e
    const v8, 0x5e62f1ca

    .line 729
    .line 730
    .line 731
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 732
    .line 733
    .line 734
    goto :goto_c

    .line 735
    :cond_f
    const v8, 0x5e72c32a

    .line 736
    .line 737
    .line 738
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 739
    .line 740
    .line 741
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 742
    .line 743
    .line 744
    goto :goto_e

    .line 745
    :cond_10
    const v8, -0x7496e5e5

    .line 746
    .line 747
    .line 748
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 749
    .line 750
    .line 751
    move-object/from16 v9, v23

    .line 752
    .line 753
    move/from16 v8, v18

    .line 754
    .line 755
    invoke-static {v9, v13, v1, v2, v8}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->CheckoutTotalPromoCaption(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 756
    .line 757
    .line 758
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 759
    .line 760
    .line 761
    goto/16 :goto_b

    .line 762
    .line 763
    :cond_11
    const v8, -0x749756e0

    .line 764
    .line 765
    .line 766
    invoke-interface {v1, v8}, LX/2d4;->Agj(I)V

    .line 767
    .line 768
    .line 769
    goto/16 :goto_a

    .line 770
    .line 771
    :cond_12
    const v9, -0x3d915053

    .line 772
    .line 773
    .line 774
    invoke-static {v1, v8, v9}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 775
    .line 776
    .line 777
    move-result-object v8

    .line 778
    iget-wide v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 779
    .line 780
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 781
    .line 782
    .line 783
    goto/16 :goto_9

    .line 784
    .line 785
    :cond_13
    sget-object v3, LX/Dn6;->A01:LX/Cl0;

    .line 786
    .line 787
    sget-object v4, LX/2Id;->A04:LX/2rU;

    .line 788
    .line 789
    goto/16 :goto_8

    .line 790
    .line 791
    :cond_14
    const v3, 0x16d8622b

    .line 792
    .line 793
    .line 794
    invoke-static {v1, v8, v3}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 795
    .line 796
    .line 797
    move-result-object v3

    .line 798
    iget-wide v3, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 799
    .line 800
    goto/16 :goto_3

    .line 801
    .line 802
    :cond_15
    const v0, 0x16d8548b

    .line 803
    .line 804
    .line 805
    invoke-static {v1, v0}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 806
    .line 807
    .line 808
    move-result-object v8

    .line 809
    invoke-static {v1, v8}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 810
    .line 811
    .line 812
    move-result-object v30

    .line 813
    goto/16 :goto_2

    .line 814
    .line 815
    :cond_16
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 816
    .line 817
    .line 818
    goto/16 :goto_7

    .line 819
    .line 820
    :cond_17
    and-int/lit16 v0, v7, 0x6000

    .line 821
    .line 822
    if-nez v0, :cond_3

    .line 823
    .line 824
    move-object/from16 v0, v22

    .line 825
    .line 826
    invoke-static {v1, v0}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 827
    .line 828
    .line 829
    move-result v0

    .line 830
    or-int/2addr v9, v0

    .line 831
    goto/16 :goto_1

    .line 832
    .line 833
    :cond_18
    move v9, v7

    .line 834
    goto/16 :goto_0

    .line 835
    .line 836
    :cond_19
    invoke-static {}, LX/1VY;->A00()V

    .line 837
    .line 838
    .line 839
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 840
    .line 841
    .line 842
    move-result-object v0

    .line 843
    throw v0
.end method

.method public static final CheckoutAmountRow(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;LX/3C1;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Ljava/lang/String;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;",
            "LX/3C1;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    move-object/from16 v13, p3

    .line 3
    .line 4
    move-object/from16 v14, p4

    .line 5
    .line 6
    move-object/from16 v12, p1

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    move-object/from16 v15, p0

    .line 10
    .line 11
    invoke-static {v15, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 12
    .line 13
    .line 14
    const v0, -0x4b41355f

    .line 15
    .line 16
    .line 17
    move-object/from16 v3, p5

    .line 18
    .line 19
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 20
    .line 21
    .line 22
    move/from16 v2, p6

    .line 23
    .line 24
    and-int/lit8 v0, p6, 0x6

    .line 25
    .line 26
    if-nez v0, :cond_16

    .line 27
    .line 28
    invoke-static {v15, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {v0}, LX/003;->A06(I)I

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    or-int v9, v9, p6

    .line 37
    .line 38
    :goto_0
    and-int/lit8 v10, p7, 0x2

    .line 39
    .line 40
    if-eqz v10, :cond_15

    .line 41
    .line 42
    or-int/lit8 v9, v9, 0x30

    .line 43
    .line 44
    :cond_0
    :goto_1
    and-int/lit8 v8, p7, 0x4

    .line 45
    .line 46
    if-eqz v8, :cond_14

    .line 47
    .line 48
    or-int/lit16 v9, v9, 0x180

    .line 49
    .line 50
    :cond_1
    :goto_2
    and-int/lit8 v7, p7, 0x8

    .line 51
    .line 52
    if-eqz v7, :cond_13

    .line 53
    .line 54
    or-int/lit16 v9, v9, 0xc00

    .line 55
    .line 56
    :cond_2
    :goto_3
    and-int/lit8 v6, p7, 0x10

    .line 57
    .line 58
    if-eqz v6, :cond_12

    .line 59
    .line 60
    or-int/lit16 v9, v9, 0x6000

    .line 61
    .line 62
    :cond_3
    :goto_4
    and-int/lit16 v5, v9, 0x2493

    .line 63
    .line 64
    const/16 v0, 0x2492

    .line 65
    .line 66
    const/16 p1, 0x0

    .line 67
    .line 68
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    invoke-static {v0, v3, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_11

    .line 77
    .line 78
    if-eqz v10, :cond_4

    .line 79
    .line 80
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    :cond_4
    const/4 v0, 0x0

    .line 83
    if-eqz v8, :cond_5

    .line 84
    .line 85
    move-object v4, v0

    .line 86
    :cond_5
    if-eqz v7, :cond_6

    .line 87
    .line 88
    move-object v13, v0

    .line 89
    :cond_6
    if-eqz v6, :cond_7

    .line 90
    .line 91
    move-object v14, v0

    .line 92
    :cond_7
    iget-object v5, v15, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->layout:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 93
    .line 94
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;->WRAPPING:Lcom/facebook/aura/agentpermission/CheckoutAmountLayout;

    .line 95
    .line 96
    if-ne v5, v0, :cond_10

    .line 97
    .line 98
    const v0, -0x7fc936b9

    .line 99
    .line 100
    .line 101
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 102
    .line 103
    .line 104
    sget-object v0, LX/3Fe;->A04:LX/Ip3;

    .line 105
    .line 106
    invoke-interface {v3, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    check-cast v0, LX/1yo;

    .line 111
    .line 112
    invoke-interface {v0}, LX/1yo;->AFv()F

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    const/high16 v0, 0x3fc00000    # 1.5f

    .line 117
    .line 118
    cmpl-float v0, v5, v0

    .line 119
    .line 120
    const/16 p0, 0x0

    .line 121
    .line 122
    if-ltz v0, :cond_8

    .line 123
    .line 124
    const/16 p0, 0x1

    .line 125
    .line 126
    :cond_8
    invoke-static {v3}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    :goto_5
    invoke-static {v12}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 131
    .line 132
    .line 133
    move-result-object v6

    .line 134
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 135
    .line 136
    if-eqz v4, :cond_9

    .line 137
    .line 138
    invoke-static {v5, v13, v4}, LX/3Rs;->A08(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 139
    .line 140
    .line 141
    move-result-object v5

    .line 142
    :cond_9
    invoke-interface {v6, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    invoke-static {v5}, LX/2pj;->A03(LX/3C1;)LX/3C1;

    .line 147
    .line 148
    .line 149
    move-result-object v5

    .line 150
    iget-object v6, v15, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->children:Ljava/util/List;

    .line 151
    .line 152
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 153
    .line 154
    .line 155
    move-result v6

    .line 156
    if-eqz v6, :cond_c

    .line 157
    .line 158
    const v6, -0x7956ca1b

    .line 159
    .line 160
    .line 161
    invoke-interface {v3, v6}, LX/2d4;->Agj(I)V

    .line 162
    .line 163
    .line 164
    if-eqz v4, :cond_a

    .line 165
    .line 166
    const/16 p1, 0x1

    .line 167
    .line 168
    :cond_a
    sget p5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->$stable:I

    .line 169
    .line 170
    and-int/lit8 v6, v9, 0xe

    .line 171
    .line 172
    or-int p5, p5, v6

    .line 173
    .line 174
    shr-int/lit8 v6, v9, 0x3

    .line 175
    .line 176
    and-int/lit16 v6, v6, 0x1c00

    .line 177
    .line 178
    or-int p5, p5, v6

    .line 179
    .line 180
    move-object/from16 p3, v5

    .line 181
    .line 182
    move-object/from16 p4, v3

    .line 183
    .line 184
    move/from16 p6, v1

    .line 185
    .line 186
    move-object/from16 p2, v14

    .line 187
    .line 188
    invoke-static/range {v15 .. v22}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountLine(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 189
    .line 190
    .line 191
    :goto_6
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 192
    .line 193
    .line 194
    :goto_7
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    if-eqz v1, :cond_b

    .line 199
    .line 200
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountRow$2;

    .line 201
    .line 202
    move-object/from16 p1, v15

    .line 203
    .line 204
    move-object/from16 p2, v12

    .line 205
    .line 206
    move-object/from16 p3, v4

    .line 207
    .line 208
    move-object/from16 p4, v13

    .line 209
    .line 210
    move-object/from16 p5, v14

    .line 211
    .line 212
    move/from16 p6, v2

    .line 213
    .line 214
    move-object/from16 p0, v0

    .line 215
    .line 216
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$CheckoutAmountRow$2;-><init>(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;LX/3C1;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Ljava/lang/String;II)V

    .line 217
    .line 218
    .line 219
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 220
    .line 221
    :cond_b
    return-void

    .line 222
    :cond_c
    const v6, -0x79553b39

    .line 223
    .line 224
    .line 225
    invoke-interface {v3, v6}, LX/2d4;->Agj(I)V

    .line 226
    .line 227
    .line 228
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 229
    .line 230
    invoke-static {v3, v6, v1}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 231
    .line 232
    .line 233
    move-result-object v11

    .line 234
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 235
    .line 236
    .line 237
    move-result v10

    .line 238
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 239
    .line 240
    .line 241
    move-result-object v8

    .line 242
    invoke-static {v3, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 243
    .line 244
    .line 245
    move-result-object v7

    .line 246
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 247
    .line 248
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 249
    .line 250
    if-nez v5, :cond_d

    .line 251
    .line 252
    invoke-static {}, LX/1VY;->A00()V

    .line 253
    .line 254
    .line 255
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    throw v0

    .line 260
    :cond_d
    invoke-static {v3, v0, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 261
    .line 262
    .line 263
    invoke-static {v3, v11, v8, v7, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 264
    .line 265
    .line 266
    if-eqz v4, :cond_e

    .line 267
    .line 268
    const/16 p1, 0x1

    .line 269
    .line 270
    :cond_e
    sget p5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->$stable:I

    .line 271
    .line 272
    and-int/lit8 v5, v9, 0xe

    .line 273
    .line 274
    or-int p5, p5, v5

    .line 275
    .line 276
    shr-int/lit8 v5, v9, 0x3

    .line 277
    .line 278
    and-int/lit16 v5, v5, 0x1c00

    .line 279
    .line 280
    or-int p5, p5, v5

    .line 281
    .line 282
    const/16 p6, 0x10

    .line 283
    .line 284
    const/16 p3, 0x0

    .line 285
    .line 286
    move-object/from16 p2, v14

    .line 287
    .line 288
    move-object/from16 p4, v3

    .line 289
    .line 290
    invoke-static/range {v15 .. v22}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountLine(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 291
    .line 292
    .line 293
    const v5, -0x6f1bee8a

    .line 294
    .line 295
    .line 296
    invoke-interface {v3, v5}, LX/2d4;->Agj(I)V

    .line 297
    .line 298
    .line 299
    iget-object v5, v15, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->children:Ljava/util/List;

    .line 300
    .line 301
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 302
    .line 303
    .line 304
    move-result-object v6

    .line 305
    :goto_8
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 306
    .line 307
    .line 308
    move-result v5

    .line 309
    if-eqz v5, :cond_f

    .line 310
    .line 311
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object p1

    .line 315
    check-cast p1, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;

    .line 316
    .line 317
    sget p5, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->$stable:I

    .line 318
    .line 319
    const/16 p6, 0x4

    .line 320
    .line 321
    move/from16 p2, p0

    .line 322
    .line 323
    invoke-static/range {p1 .. p6}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountChildRow(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZLX/3C1;LX/2d4;II)V

    .line 324
    .line 325
    .line 326
    goto :goto_8

    .line 327
    :cond_f
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 328
    .line 329
    .line 330
    goto/16 :goto_6

    .line 331
    .line 332
    :cond_10
    const v0, -0x795d9b92

    .line 333
    .line 334
    .line 335
    invoke-static {v3, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    const/16 p0, 0x0

    .line 340
    .line 341
    goto/16 :goto_5

    .line 342
    .line 343
    :cond_11
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 344
    .line 345
    .line 346
    goto/16 :goto_7

    .line 347
    .line 348
    :cond_12
    and-int/lit16 v0, v2, 0x6000

    .line 349
    .line 350
    if-nez v0, :cond_3

    .line 351
    .line 352
    invoke-static {v3, v14}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    or-int/2addr v9, v0

    .line 357
    goto/16 :goto_4

    .line 358
    .line 359
    :cond_13
    and-int/lit16 v0, v2, 0xc00

    .line 360
    .line 361
    if-nez v0, :cond_2

    .line 362
    .line 363
    invoke-static {v3, v13}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 364
    .line 365
    .line 366
    move-result v0

    .line 367
    or-int/2addr v9, v0

    .line 368
    goto/16 :goto_3

    .line 369
    .line 370
    :cond_14
    and-int/lit16 v0, v2, 0x180

    .line 371
    .line 372
    if-nez v0, :cond_1

    .line 373
    .line 374
    invoke-static {v3, v4}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 375
    .line 376
    .line 377
    move-result v0

    .line 378
    or-int/2addr v9, v0

    .line 379
    goto/16 :goto_2

    .line 380
    .line 381
    :cond_15
    and-int/lit8 v0, p6, 0x30

    .line 382
    .line 383
    if-nez v0, :cond_0

    .line 384
    .line 385
    invoke-static {v3, v12}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 386
    .line 387
    .line 388
    move-result v0

    .line 389
    or-int/2addr v9, v0

    .line 390
    goto/16 :goto_1

    .line 391
    .line 392
    :cond_16
    move v9, v2

    .line 393
    goto/16 :goto_0
.end method

.method public static final synthetic access$CheckoutAmountChevron(ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountChevron(ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutAmountChildRow(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountChildRow(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutAmountDueAtPropertyNote(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountDueAtPropertyNote(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutAmountLine(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt;->CheckoutAmountLine(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;ZZLjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final checkoutAmountLabel(Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;LX/2d4;I)Ljava/lang/String;
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->label:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const-string v1, ""

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    const v0, -0x7243109e

    .line 13
    .line 14
    .line 15
    invoke-static {p1, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    throw v0

    .line 20
    :pswitch_0
    const v0, -0x72429f8a

    .line 21
    .line 22
    .line 23
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 24
    .line 25
    .line 26
    const v0, 0x7f120150

    .line 27
    .line 28
    .line 29
    goto :goto_1

    .line 30
    :pswitch_1
    const v0, -0x7242adf2

    .line 31
    .line 32
    .line 33
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 34
    .line 35
    .line 36
    const v0, 0x7f120151

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :pswitch_2
    const v0, -0x7242bacc

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 44
    .line 45
    .line 46
    const v0, 0x7f12015a

    .line 47
    .line 48
    .line 49
    goto :goto_1

    .line 50
    :pswitch_3
    const v0, -0x7242c9cb

    .line 51
    .line 52
    .line 53
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 54
    .line 55
    .line 56
    const v0, 0x7f12015e

    .line 57
    .line 58
    .line 59
    goto :goto_1

    .line 60
    :pswitch_4
    const v0, -0x7242d850

    .line 61
    .line 62
    .line 63
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 64
    .line 65
    .line 66
    const v0, 0x7f12014b

    .line 67
    .line 68
    .line 69
    goto :goto_1

    .line 70
    :pswitch_5
    const v0, 0x29e435a5

    .line 71
    .line 72
    .line 73
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 74
    .line 75
    .line 76
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->currency:Ljava/lang/String;

    .line 77
    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->trimToNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    if-eqz v1, :cond_0

    .line 85
    .line 86
    const v0, 0x29e4a9c6

    .line 87
    .line 88
    .line 89
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 90
    .line 91
    .line 92
    const v0, 0x7f12015f

    .line 93
    .line 94
    .line 95
    invoke-static {p1, v1, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {p1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    if-eqz v1, :cond_1

    .line 104
    .line 105
    const v0, -0x7242f603

    .line 106
    .line 107
    .line 108
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 109
    .line 110
    .line 111
    :goto_0
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 112
    .line 113
    .line 114
    goto :goto_2

    .line 115
    :cond_0
    const v0, 0x29e4a9c5

    .line 116
    .line 117
    .line 118
    invoke-static {p1, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 119
    .line 120
    .line 121
    move-result-object v2

    .line 122
    :cond_1
    const v0, -0x7242e4d1

    .line 123
    .line 124
    .line 125
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 126
    .line 127
    .line 128
    const v0, 0x7f1200c4

    .line 129
    .line 130
    .line 131
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    goto :goto_0

    .line 136
    :pswitch_6
    const v0, -0x72430452

    .line 137
    .line 138
    .line 139
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 140
    .line 141
    .line 142
    const v0, 0x7f120199

    .line 143
    .line 144
    .line 145
    :goto_1
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    :goto_2
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    return-object v1

    .line 153
    :pswitch_7
    const v0, -0x72430ae4

    .line 154
    .line 155
    .line 156
    invoke-static {p1, v0}, LX/003;->A0q(LX/2d4;I)V

    .line 157
    .line 158
    .line 159
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutAmountPresentation;->providedLabel:Ljava/lang/String;

    .line 160
    .line 161
    if-eqz v0, :cond_2

    .line 162
    .line 163
    return-object v0

    .line 164
    :cond_2
    return-object v1

    .line 165
    nop

    .line 166
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
