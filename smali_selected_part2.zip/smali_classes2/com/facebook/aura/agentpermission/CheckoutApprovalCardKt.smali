.class public abstract Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CheckoutCardShape:LX/2bC;

.field public static final CheckoutPaymentRowShape:LX/2bC;

.field public static final CheckoutReviewFaviconSize:F = 24.0f

.field public static final CheckoutRowShape:LX/2bC;

.field public static final CheckoutScreenshotScrimAlpha:F = 0.03f


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    const/high16 v0, 0x41e00000    # 28.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutCardShape:LX/2bC;

    .line 7
    .line 8
    const/high16 v0, 0x41c00000    # 24.0f

    .line 9
    .line 10
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutRowShape:LX/2bC;

    .line 15
    .line 16
    const/high16 v0, 0x41b00000    # 22.0f

    .line 17
    .line 18
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutPaymentRowShape:LX/2bC;

    .line 23
    .line 24
    return-void
.end method

.method public static final BrowserTaskActionPill(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v2, p3

    .line 1
    .line 2
    const/4 v15, 0x0

    .line 3
    move-object/from16 v5, p0

    .line 4
    .line 5
    move-object/from16 v13, p2

    .line 6
    .line 7
    invoke-static {v5, v15, v13}, LX/003;->A0x(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const v0, 0x725881a0

    .line 11
    .line 12
    .line 13
    move-object/from16 v4, p4

    .line 14
    .line 15
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v3, p5

    .line 19
    .line 20
    and-int/lit8 v0, p5, 0x6

    .line 21
    .line 22
    if-nez v0, :cond_8

    .line 23
    .line 24
    invoke-static {v4, v5}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v7

    .line 28
    or-int v7, v7, p5

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 31
    .line 32
    move-object/from16 v6, p1

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {v4, v6}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v7, v0

    .line 41
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    invoke-static {v4, v13}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v7, v0

    .line 50
    :cond_1
    and-int/lit8 v8, p6, 0x8

    .line 51
    .line 52
    if-eqz v8, :cond_7

    .line 53
    .line 54
    or-int/lit16 v7, v7, 0xc00

    .line 55
    .line 56
    :cond_2
    :goto_1
    and-int/lit16 v1, v7, 0x493

    .line 57
    .line 58
    const/16 v0, 0x492

    .line 59
    .line 60
    const/4 v11, 0x1

    .line 61
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0, v4, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_6

    .line 70
    .line 71
    if-eqz v8, :cond_3

    .line 72
    .line 73
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 74
    .line 75
    :cond_3
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 76
    .line 77
    const/4 v12, 0x6

    .line 78
    invoke-static {v4, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 79
    .line 80
    .line 81
    move-result-wide v0

    .line 82
    const/high16 v16, 0x40800000    # 4.0f

    .line 83
    .line 84
    const/high16 v8, 0x42400000    # 48.0f

    .line 85
    .line 86
    invoke-static {v2, v8, v8}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 87
    .line 88
    .line 89
    move-result-object v10

    .line 90
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v9

    .line 94
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 95
    .line 96
    if-ne v9, v8, :cond_4

    .line 97
    .line 98
    sget-object v9, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$1$1;

    .line 99
    .line 100
    invoke-interface {v4, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :cond_4
    invoke-static {v10, v9, v11}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 104
    .line 105
    .line 106
    move-result-object v14

    .line 107
    new-instance v8, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;

    .line 108
    .line 109
    invoke-direct {v8, v6, v0, v1, v5}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 110
    .line 111
    .line 112
    const v0, -0x7ee2e642

    .line 113
    .line 114
    .line 115
    invoke-static {v4, v8, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 116
    .line 117
    .line 118
    move-result-object p2

    .line 119
    shr-int/2addr v7, v12

    .line 120
    and-int/lit8 p4, v7, 0xe

    .line 121
    .line 122
    const v0, 0xc06d80

    .line 123
    .line 124
    .line 125
    or-int p4, p4, v0

    .line 126
    .line 127
    const/16 p5, 0x60

    .line 128
    .line 129
    const/high16 v17, 0x41000000    # 8.0f

    .line 130
    .line 131
    const/16 p0, 0x0

    .line 132
    .line 133
    move/from16 p1, v15

    .line 134
    .line 135
    move-object/from16 p3, v4

    .line 136
    .line 137
    invoke-static/range {v13 .. v23}, Lcom/facebook/aura/vds/compose/button/AuraElevatedButtonKt;->AuraPillButton-q88KkHs(Lkotlin/jvm/functions/Function0;LX/3C1;ZFFFZLX/JDN;LX/2d4;II)V

    .line 138
    .line 139
    .line 140
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    if-eqz v1, :cond_5

    .line 145
    .line 146
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$3;

    .line 147
    .line 148
    move-object/from16 p0, v0

    .line 149
    .line 150
    move-object/from16 p1, v5

    .line 151
    .line 152
    move-object/from16 p2, v6

    .line 153
    .line 154
    move-object/from16 p3, v13

    .line 155
    .line 156
    move-object/from16 p4, v2

    .line 157
    .line 158
    move/from16 p5, v3

    .line 159
    .line 160
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$3;-><init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 161
    .line 162
    .line 163
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 164
    .line 165
    :cond_5
    return-void

    .line 166
    :cond_6
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 167
    .line 168
    .line 169
    goto :goto_2

    .line 170
    :cond_7
    and-int/lit16 v0, v3, 0xc00

    .line 171
    .line 172
    if-nez v0, :cond_2

    .line 173
    .line 174
    invoke-static {v4, v2}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    or-int/2addr v7, v0

    .line 179
    goto :goto_1

    .line 180
    :cond_8
    move v7, v3

    .line 181
    goto/16 :goto_0
.end method

.method public static final CheckoutApprovalCard(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;",
            "LX/2iK;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;",
            "Lcom/facebook/aura/agentpermission/RichApprovalSurface;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 521348
    move-object/from16 v0, p12

    const/16 v22, 0x0

    .line 521349
    move-object/from16 v7, p0

    move-object/from16 v6, p1

    move-object/from16 v5, p2

    invoke-static {v7, v6, v5}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 521350
    const/4 v3, 0x6

    .line 521351
    move-object/from16 p0, p6

    move-object/from16 v32, p7

    move-object/from16 v2, p0

    move-object/from16 v1, v32

    invoke-static {v2, v3, v1}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 521352
    const/16 v2, 0x8

    .line 521353
    move-object/from16 v31, p8

    move-object/from16 v15, p9

    move-object/from16 v4, p10

    move-object/from16 v8, p11

    move-object/from16 v1, v31

    invoke-static {v1, v15, v4, v8, v2}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 521354
    const v1, 0x1d37e40b

    .line 521355
    move-object/from16 v3, p13

    invoke-interface {v3, v1}, LX/2d4;->Agl(I)V

    move/from16 v2, p14

    and-int/lit8 v1, p14, 0x6

    const/4 v11, 0x4

    if-nez v1, :cond_17

    .line 521356
    invoke-static {v3, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    move-result v10

    .line 521357
    or-int v10, v10, p14

    :goto_0
    and-int/lit8 v1, p14, 0x30

    const/16 v13, 0x20

    if-nez v1, :cond_0

    .line 521358
    invoke-static {v6, v3, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    move-result v1

    .line 521359
    invoke-static {v1}, LX/003;->A07(I)I

    move-result v1

    .line 521360
    or-int/2addr v10, v1

    :cond_0
    and-int/lit16 v1, v2, 0x180

    const/16 v12, 0x100

    if-nez v1, :cond_1

    .line 521361
    invoke-static {v3, v5}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521362
    or-int/2addr v10, v1

    :cond_1
    and-int/lit16 v1, v2, 0xc00

    if-nez v1, :cond_2

    .line 521363
    move-object/from16 v1, p3

    invoke-static {v3, v1}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521364
    or-int/2addr v10, v1

    :cond_2
    and-int/lit16 v1, v2, 0x6000

    move-object/from16 p2, p4

    if-nez v1, :cond_3

    .line 521365
    move-object/from16 v1, p2

    invoke-static {v3, v1}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521366
    or-int/2addr v10, v1

    :cond_3
    const/high16 v1, 0x30000

    and-int v1, v1, p14

    move-object/from16 p1, p5

    if-nez v1, :cond_4

    .line 521367
    move-object/from16 v1, p1

    invoke-static {v3, v1}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521368
    or-int/2addr v10, v1

    :cond_4
    const/high16 v1, 0x180000

    and-int v1, p14, v1

    if-nez v1, :cond_5

    const/high16 v9, 0x200000

    .line 521369
    move-object/from16 v1, p0

    invoke-static {v3, v1, v2, v9}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    move-result v1

    .line 521370
    invoke-static {v1}, LX/003;->A03(I)I

    move-result v1

    .line 521371
    or-int/2addr v10, v1

    :cond_5
    const/high16 v1, 0xc00000

    and-int v1, p14, v1

    if-nez v1, :cond_7

    const/high16 v9, 0x1000000

    .line 521372
    move-object/from16 v1, v32

    invoke-static {v3, v1, v2, v9}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    move-result v9

    .line 521373
    const/high16 v1, 0x400000

    if-eqz v9, :cond_6

    const/high16 v1, 0x800000

    :cond_6
    or-int/2addr v10, v1

    :cond_7
    const/high16 v1, 0x6000000

    and-int v1, p14, v1

    if-nez v1, :cond_8

    .line 521374
    move-object/from16 v1, v31

    invoke-static {v3, v1}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521375
    or-int/2addr v10, v1

    :cond_8
    const/high16 v1, 0x30000000

    and-int v1, p14, v1

    if-nez v1, :cond_9

    .line 521376
    invoke-static {v3, v15}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v1

    .line 521377
    or-int/2addr v10, v1

    :cond_9
    move/from16 v1, p15

    and-int/lit8 v9, p15, 0x6

    if-nez v9, :cond_16

    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_a

    const/4 v11, 0x2

    :cond_a
    or-int v9, p15, v11

    :goto_1
    and-int/lit8 v11, p15, 0x30

    if-nez v11, :cond_c

    invoke-interface {v3, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_b

    const/16 v13, 0x10

    :cond_b
    or-int/2addr v9, v13

    :cond_c
    move/from16 v30, p16

    move/from16 v11, v30

    and-int/lit16 v14, v11, 0x1000

    if-eqz v14, :cond_14

    or-int/lit16 v9, v9, 0x180

    :cond_d
    :goto_2
    const v11, 0x12492493

    and-int v12, v10, v11

    const v11, 0x12492492

    if-ne v12, v11, :cond_e

    and-int/lit16 v13, v9, 0x93

    const/16 v12, 0x92

    const/4 v11, 0x0

    if-eq v13, v12, :cond_f

    :cond_e
    const/4 v11, 0x1

    .line 521378
    :cond_f
    invoke-static {v11, v3, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    move-result v11

    .line 521379
    if-eqz v11, :cond_13

    if-eqz v14, :cond_10

    .line 521380
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 521381
    :cond_10
    iget-object v12, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->amount:Ljava/lang/String;

    .line 521382
    iget-object v11, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->currency:Ljava/lang/String;

    .line 521383
    invoke-static {v12, v11}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutFormattedAmount(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    if-eqz v27, :cond_12

    const v11, 0x2b1b9100

    .line 521384
    invoke-interface {v3, v11}, LX/2d4;->Agj(I)V

    and-int/lit8 v11, v10, 0xe

    .line 521385
    invoke-static {v7, v3, v11}, Lcom/facebook/aura/agentpermission/CheckoutInfoSheetKt;->CheckoutInfoPrefetch(Ljava/lang/String;LX/2d4;I)V

    .line 521386
    :goto_3
    invoke-static {v3}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 521387
    new-instance v13, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;

    move-object/from16 v12, p3

    move-object/from16 v11, p2

    invoke-direct {v13, v6, v5, v12, v11}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;)V

    const v11, 0x186e1363

    invoke-static {v3, v13, v11}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    move-result-object v18

    .line 521388
    new-instance v12, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;

    invoke-direct {v12, v6, v4}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;)V

    const v11, -0x455b3940

    invoke-static {v3, v12, v11}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    move-result-object v21

    .line 521389
    new-instance v11, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;

    move-object/from16 v23, v11

    move-object/from16 v24, v6

    move-object/from16 v25, v8

    move-object/from16 v26, v31

    move-object/from16 v28, v15

    move-object/from16 v29, p1

    invoke-direct/range {v23 .. v29}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    const v12, 0x5cdb7a1d

    invoke-static {v3, v11, v12}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    move-result-object v24

    shr-int/lit8 v12, v10, 0x12

    and-int/lit8 v11, v12, 0xe

    const v10, 0x6030180

    or-int/2addr v11, v10

    sget v10, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->$stable:I

    shl-int/lit8 v10, v10, 0x3

    or-int/2addr v11, v10

    and-int/lit8 v10, v12, 0x70

    .line 521390
    invoke-static {v10, v11, v9}, LX/3Rr;->A03(III)I

    move-result v26

    .line 521391
    const/16 v27, 0xd0

    const/16 v20, 0x0

    .line 521392
    move-object/from16 v16, p0

    move-object/from16 v17, v32

    move-object/from16 v19, v0

    move-object/from16 v23, v20

    move-object/from16 v25, v3

    invoke-static/range {v16 .. v27}, Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt;->ApprovalCardScaffold(Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/JDQ;LX/3C1;Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;LX/JDQ;ZLX/JDN;LX/JDQ;LX/2d4;II)V

    .line 521393
    :goto_4
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    move-result-object v9

    if-eqz v9, :cond_11

    .line 521394
    new-instance v3, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$4;

    move-object/from16 v24, v4

    move-object/from16 v25, v8

    move-object/from16 v26, v0

    move/from16 v27, v2

    move/from16 v28, v1

    move/from16 v29, v30

    move-object/from16 v16, v5

    move-object/from16 v17, p3

    move-object/from16 v18, p2

    move-object/from16 v19, p1

    move-object/from16 v20, p0

    move-object/from16 v21, v32

    move-object/from16 v22, v31

    move-object/from16 v23, v15

    move-object v13, v3

    move-object v14, v7

    move-object v15, v6

    invoke-direct/range {v13 .. v29}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$4;-><init>(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;III)V

    .line 521395
    iput-object v3, v9, LX/J7V;->A06:LX/JDN;

    .line 521396
    :cond_11
    return-void

    .line 521397
    :cond_12
    const v11, 0x2b1c5f77

    .line 521398
    invoke-interface {v3, v11}, LX/2d4;->Agj(I)V

    goto/16 :goto_3

    .line 521399
    :cond_13
    invoke-interface {v3}, LX/2d4;->AgJ()V

    goto :goto_4

    .line 521400
    :cond_14
    and-int/lit16 v11, v1, 0x180

    if-nez v11, :cond_d

    invoke-interface {v3, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_15

    const/16 v12, 0x80

    :cond_15
    or-int/2addr v9, v12

    goto/16 :goto_2

    :cond_16
    move v9, v1

    goto/16 :goto_1

    :cond_17
    move v10, v2

    goto/16 :goto_0
.end method

.method public static final CheckoutHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 36

    .line 0
    move-object/from16 v6, p3

    .line 1
    .line 2
    const v0, -0x307ed9d8

    .line 3
    .line 4
    .line 5
    move-object/from16 v5, p4

    .line 6
    .line 7
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 p5, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    move-object/from16 v0, p5

    .line 19
    .line 20
    invoke-static {v0, v5, v4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v7

    .line 28
    or-int/2addr v7, v4

    .line 29
    :goto_0
    and-int/lit8 v0, v4, 0x30

    .line 30
    .line 31
    move-object/from16 p4, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    move-object/from16 v0, p4

    .line 36
    .line 37
    invoke-static {v5, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    or-int/2addr v7, v0

    .line 42
    :cond_0
    and-int/lit16 v0, v4, 0x180

    .line 43
    .line 44
    move-object/from16 v19, p2

    .line 45
    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    move-object/from16 v0, v19

    .line 49
    .line 50
    invoke-static {v5, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v7, v0

    .line 55
    :cond_1
    move/from16 p3, p6

    .line 56
    .line 57
    and-int/lit8 v2, p6, 0x8

    .line 58
    .line 59
    if-eqz v2, :cond_4

    .line 60
    .line 61
    or-int/lit16 v7, v7, 0xc00

    .line 62
    .line 63
    :cond_2
    :goto_1
    and-int/lit16 v1, v7, 0x493

    .line 64
    .line 65
    const/16 v0, 0x492

    .line 66
    .line 67
    const/4 v3, 0x0

    .line 68
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    invoke-static {v0, v5, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_6

    .line 77
    .line 78
    if-eqz v2, :cond_3

    .line 79
    .line 80
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    :cond_3
    const/16 v18, 0x0

    .line 83
    .line 84
    sget-object v17, LX/2sI;->A02:LX/2wD;

    .line 85
    .line 86
    move-object/from16 v0, v17

    .line 87
    .line 88
    invoke-interface {v6, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 89
    .line 90
    .line 91
    move-result-object v10

    .line 92
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 93
    .line 94
    invoke-static {v5, v0, v3}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 95
    .line 96
    .line 97
    move-result-object v9

    .line 98
    move-object v2, v5

    .line 99
    check-cast v2, LX/J7I;

    .line 100
    .line 101
    iget-wide v0, v2, LX/J7I;->A06:J

    .line 102
    .line 103
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 104
    .line 105
    .line 106
    move-result v8

    .line 107
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 108
    .line 109
    .line 110
    move-result-object v7

    .line 111
    invoke-static {v5, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    sget-object v14, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 118
    .line 119
    if-nez v0, :cond_7

    .line 120
    .line 121
    invoke-static {}, LX/1VY;->A00()V

    .line 122
    .line 123
    .line 124
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0

    .line 129
    :cond_4
    and-int/lit16 v0, v4, 0xc00

    .line 130
    .line 131
    if-nez v0, :cond_2

    .line 132
    .line 133
    invoke-static {v5, v6}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    or-int/2addr v7, v0

    .line 138
    goto :goto_1

    .line 139
    :cond_5
    move v7, v4

    .line 140
    goto :goto_0

    .line 141
    :cond_6
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 142
    .line 143
    .line 144
    goto/16 :goto_3

    .line 145
    .line 146
    :cond_7
    invoke-static {v5, v2, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 147
    .line 148
    .line 149
    sget-object v13, LX/3Cl;->A04:LX/JDN;

    .line 150
    .line 151
    invoke-static {v5, v9, v13}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 152
    .line 153
    .line 154
    move-result-object v12

    .line 155
    invoke-static {v5, v7, v12, v8}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 156
    .line 157
    .line 158
    move-result-object v15

    .line 159
    sget-object v11, LX/3Cl;->A02:LX/JDM;

    .line 160
    .line 161
    invoke-static {v5, v1, v11}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 162
    .line 163
    .line 164
    move-result-object v10

    .line 165
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 166
    .line 167
    sget-object v7, LX/2Id;->A04:LX/2rU;

    .line 168
    .line 169
    sget-object v1, LX/Dn6;->A01:LX/Cl0;

    .line 170
    .line 171
    const/16 v16, 0x30

    .line 172
    .line 173
    move/from16 v0, v16

    .line 174
    .line 175
    invoke-static {v1, v5, v7, v0}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 176
    .line 177
    .line 178
    move-result-object v8

    .line 179
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 180
    .line 181
    .line 182
    move-result v7

    .line 183
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    move-object/from16 v0, v17

    .line 188
    .line 189
    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-static {v5, v2, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 194
    .line 195
    .line 196
    invoke-static {v5, v8, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 197
    .line 198
    .line 199
    invoke-static {v5, v1, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 200
    .line 201
    .line 202
    invoke-static {v11, v15, v5, v7}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 203
    .line 204
    .line 205
    invoke-static {v5, v0, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 206
    .line 207
    .line 208
    sget-object v1, LX/CgK;->A00:LX/CgK;

    .line 209
    .line 210
    move-object/from16 v0, p5

    .line 211
    .line 212
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->merchantUrl:Ljava/lang/String;

    .line 213
    .line 214
    move-object/from16 v0, v18

    .line 215
    .line 216
    invoke-static {v7, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutFaviconUri(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v8

    .line 220
    const/4 v7, 0x2

    .line 221
    invoke-static {v8, v0, v5, v3, v7}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->CheckoutMerchantFavicon(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 222
    .line 223
    .line 224
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 225
    .line 226
    invoke-static {v5, v9, v0}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 227
    .line 228
    .line 229
    move-object/from16 v0, p4

    .line 230
    .line 231
    iget-object v8, v0, LX/2iK;->A00:Ljava/lang/String;

    .line 232
    .line 233
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 234
    .line 235
    invoke-static {v5, v7}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 236
    .line 237
    .line 238
    move-result-object v24

    .line 239
    invoke-static {v5, v7}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 240
    .line 241
    .line 242
    move-result-wide v22

    .line 243
    const/high16 v10, 0x3f800000    # 1.0f

    .line 244
    .line 245
    const/4 v0, 0x1

    .line 246
    invoke-virtual {v1, v9, v10, v0}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 247
    .line 248
    .line 249
    move-result-object v10

    .line 250
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v9

    .line 254
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 255
    .line 256
    if-ne v9, v1, :cond_8

    .line 257
    .line 258
    sget-object v9, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutHeader$1$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutHeader$1$1$1$1;

    .line 259
    .line 260
    invoke-interface {v5, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    :cond_8
    invoke-static {v10, v9, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 264
    .line 265
    .line 266
    move-result-object v21

    .line 267
    const/16 p2, 0x3ff0

    .line 268
    .line 269
    move-object/from16 v26, v18

    .line 270
    .line 271
    move-object/from16 v27, v18

    .line 272
    .line 273
    move/from16 v28, v3

    .line 274
    .line 275
    move/from16 v29, v3

    .line 276
    .line 277
    move/from16 v30, v3

    .line 278
    .line 279
    move/from16 v31, v3

    .line 280
    .line 281
    move-object/from16 v32, v18

    .line 282
    .line 283
    move-object/from16 v33, v18

    .line 284
    .line 285
    move-object/from16 v34, v18

    .line 286
    .line 287
    move-object/from16 v35, v5

    .line 288
    .line 289
    move/from16 p0, v3

    .line 290
    .line 291
    move/from16 p1, v3

    .line 292
    .line 293
    move-object/from16 v25, v18

    .line 294
    .line 295
    move-object/from16 v20, v8

    .line 296
    .line 297
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 298
    .line 299
    .line 300
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 301
    .line 302
    .line 303
    if-nez v19, :cond_a

    .line 304
    .line 305
    const v1, 0x48c8aa7f

    .line 306
    .line 307
    .line 308
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    .line 309
    .line 310
    .line 311
    :goto_2
    invoke-static {v2, v6, v3, v0}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 312
    .line 313
    .line 314
    move-result-object v6

    .line 315
    :goto_3
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    if-eqz v1, :cond_9

    .line 320
    .line 321
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutHeader$2;

    .line 322
    .line 323
    move-object/from16 p0, v19

    .line 324
    .line 325
    move-object/from16 p1, v6

    .line 326
    .line 327
    move/from16 p2, v4

    .line 328
    .line 329
    move-object/from16 v33, v0

    .line 330
    .line 331
    move-object/from16 v34, p5

    .line 332
    .line 333
    move-object/from16 v35, p4

    .line 334
    .line 335
    invoke-direct/range {v33 .. v39}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutHeader$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;LX/3C1;II)V

    .line 336
    .line 337
    .line 338
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 339
    .line 340
    :cond_9
    return-void

    .line 341
    :cond_a
    const v1, 0x48c8aa80    # 410964.0f

    .line 342
    .line 343
    .line 344
    invoke-static {v5, v7, v1}, LX/3Rr;->A0D(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)LX/2hg;

    .line 345
    .line 346
    .line 347
    move-result-object v23

    .line 348
    invoke-static {v5, v7}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 349
    .line 350
    .line 351
    move-result-wide v21

    .line 352
    move-object/from16 v20, v17

    .line 353
    .line 354
    move-object/from16 v24, v18

    .line 355
    .line 356
    move/from16 v27, v3

    .line 357
    .line 358
    move-object/from16 v31, v18

    .line 359
    .line 360
    move-object/from16 v34, v5

    .line 361
    .line 362
    move/from16 v35, v16

    .line 363
    .line 364
    move/from16 p1, p2

    .line 365
    .line 366
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 367
    .line 368
    .line 369
    goto :goto_2
.end method

.method public static final CheckoutReviewOrderFavicon-RPmYEkk(Ljava/lang/String;JLX/2d4;I)V
    .locals 23

    .line 0
    const v1, 0x45947b79

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p3

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v3, p4

    .line 9
    .line 10
    and-int/lit8 v1, p4, 0x6

    .line 11
    .line 12
    move-object/from16 v8, p0

    .line 13
    .line 14
    if-nez v1, :cond_4

    .line 15
    .line 16
    invoke-static {v0, v8}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    or-int v6, p4, v1

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v1, p4, 0x30

    .line 23
    .line 24
    move-wide/from16 v4, p1

    .line 25
    .line 26
    if-nez v1, :cond_0

    .line 27
    .line 28
    invoke-static {v0, v4, v5}, LX/008;->A0N(LX/2d4;J)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    or-int/2addr v6, v1

    .line 33
    :cond_0
    and-int/lit8 v2, v6, 0x13

    .line 34
    .line 35
    const/16 v1, 0x12

    .line 36
    .line 37
    const/4 v13, 0x0

    .line 38
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-static {v1, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_3

    .line 47
    .line 48
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 49
    .line 50
    sget v1, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutReviewFaviconSize:F

    .line 51
    .line 52
    invoke-static {v2, v1}, LX/1qF;->A02(LX/3C1;F)LX/3C1;

    .line 53
    .line 54
    .line 55
    move-result-object v7

    .line 56
    invoke-static {v0}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 61
    .line 62
    const/4 v11, 0x0

    .line 63
    invoke-static {v7, v1, v2}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    if-eqz p0, :cond_2

    .line 68
    .line 69
    const v1, 0x1a10992a

    .line 70
    .line 71
    .line 72
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 73
    .line 74
    .line 75
    sget-object v10, LX/32Y;->A00:LX/2vq;

    .line 76
    .line 77
    and-int/lit8 p2, v6, 0xe

    .line 78
    .line 79
    const v1, 0x6000d80

    .line 80
    .line 81
    .line 82
    or-int p2, p2, v1

    .line 83
    .line 84
    const/16 p4, 0x7ef0

    .line 85
    .line 86
    const-wide/16 v15, 0x0

    .line 87
    .line 88
    const/16 v17, 0x1

    .line 89
    .line 90
    move-object v12, v11

    .line 91
    move-object v14, v11

    .line 92
    move/from16 v18, v13

    .line 93
    .line 94
    move/from16 v19, v13

    .line 95
    .line 96
    move-object/from16 v20, v11

    .line 97
    .line 98
    move-object/from16 v21, v11

    .line 99
    .line 100
    move-object/from16 v22, v11

    .line 101
    .line 102
    move-object/from16 p0, v11

    .line 103
    .line 104
    move-object/from16 p1, v0

    .line 105
    .line 106
    move/from16 p3, v13

    .line 107
    .line 108
    invoke-static/range {v8 .. v27}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage-XRP3Ue8(Ljava/lang/String;LX/3C1;LX/2vq;Ljava/lang/String;Lcom/facebook/common/callercontext/ContextChain;ZLX/1Ot;JZZZLX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;III)V

    .line 109
    .line 110
    .line 111
    :goto_1
    invoke-static {v0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    if-eqz v1, :cond_1

    .line 119
    .line 120
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;

    .line 121
    .line 122
    invoke-direct {v0, v8, v4, v5, v3}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;-><init>(Ljava/lang/String;JI)V

    .line 123
    .line 124
    .line 125
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 126
    .line 127
    :cond_1
    return-void

    .line 128
    :cond_2
    const v1, 0x1a13b1b9

    .line 129
    .line 130
    .line 131
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 132
    .line 133
    .line 134
    const v1, 0x7f0801ae

    .line 135
    .line 136
    .line 137
    invoke-static {v0, v1, v13}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 138
    .line 139
    .line 140
    move-result-object v13

    .line 141
    sget-object v14, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 142
    .line 143
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 144
    .line 145
    invoke-static {v9, v1}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 146
    .line 147
    .line 148
    move-result-object v12

    .line 149
    invoke-static {}, LX/2l9;->A04()I

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    shl-int/lit8 v1, v6, 0x9

    .line 154
    .line 155
    invoke-static {v1, v2}, LX/002;->A09(II)I

    .line 156
    .line 157
    .line 158
    move-result v20

    .line 159
    const/16 v21, 0x20

    .line 160
    .line 161
    move-object v15, v11

    .line 162
    move-wide/from16 v16, v4

    .line 163
    .line 164
    move-object/from16 v18, v11

    .line 165
    .line 166
    move-object/from16 v19, v0

    .line 167
    .line 168
    invoke-static/range {v12 .. v21}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 169
    .line 170
    .line 171
    goto :goto_1

    .line 172
    :cond_3
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 173
    .line 174
    .line 175
    goto :goto_2

    .line 176
    :cond_4
    move v6, v3

    .line 177
    goto/16 :goto_0
.end method

.method public static final CheckoutScreenshot(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v11, p2

    .line 1
    .line 2
    const v0, 0x407d788f

    .line 3
    .line 4
    .line 5
    move-object/from16 v13, p3

    .line 6
    .line 7
    invoke-interface {v13, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v0, :cond_10

    .line 17
    .line 18
    invoke-static {v3, v13, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    or-int v4, v4, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v2, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v13, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v4, v0

    .line 39
    :cond_0
    move/from16 v20, p5

    .line 40
    .line 41
    and-int/lit8 v7, p5, 0x4

    .line 42
    .line 43
    if-eqz v7, :cond_f

    .line 44
    .line 45
    or-int/lit16 v4, v4, 0x180

    .line 46
    .line 47
    :cond_1
    :goto_1
    and-int/lit16 v5, v4, 0x93

    .line 48
    .line 49
    const/16 v0, 0x92

    .line 50
    .line 51
    const/4 v6, 0x0

    .line 52
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    invoke-static {v0, v13, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_c

    .line 61
    .line 62
    if-eqz v7, :cond_2

    .line 63
    .line 64
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 65
    .line 66
    :cond_2
    iget-object v14, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->browserTaskId:Ljava/lang/String;

    .line 67
    .line 68
    if-eqz v14, :cond_b

    .line 69
    .line 70
    const v0, 0x1701aaf0

    .line 71
    .line 72
    .line 73
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 74
    .line 75
    .line 76
    invoke-static {v13, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt;->isLiveBrowserPreviewBehindSheet(LX/2d4;I)Z

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    :goto_2
    move-object v5, v13

    .line 81
    check-cast v5, LX/J7I;

    .line 82
    .line 83
    const/4 v15, 0x0

    .line 84
    invoke-static {v5, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 85
    .line 86
    .line 87
    if-eqz v6, :cond_4

    .line 88
    .line 89
    const v0, -0x36cbbb60    # -738378.0f

    .line 90
    .line 91
    .line 92
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 93
    .line 94
    .line 95
    and-int/lit16 v0, v4, 0x3f0

    .line 96
    .line 97
    move-object/from16 v16, v11

    .line 98
    .line 99
    move-object/from16 v17, v13

    .line 100
    .line 101
    move/from16 v18, v0

    .line 102
    .line 103
    move/from16 v19, v15

    .line 104
    .line 105
    move-object v15, v2

    .line 106
    invoke-static/range {v14 .. v19}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt;->OpenBrowserLink(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 107
    .line 108
    .line 109
    invoke-static {v13, v5}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    if-eqz v4, :cond_3

    .line 114
    .line 115
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$1;

    .line 116
    .line 117
    move-object/from16 v17, v2

    .line 118
    .line 119
    move-object/from16 v18, v11

    .line 120
    .line 121
    move/from16 v19, v1

    .line 122
    .line 123
    move-object v15, v0

    .line 124
    move-object/from16 v16, v3

    .line 125
    .line 126
    invoke-direct/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 127
    .line 128
    .line 129
    :goto_3
    invoke-static {v4, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    :cond_3
    return-void

    .line 133
    :cond_4
    const v0, -0x36ca0bad

    .line 134
    .line 135
    .line 136
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 137
    .line 138
    .line 139
    invoke-static {v5, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 140
    .line 141
    .line 142
    invoke-static {v13}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    invoke-static {v13}, LX/3Rp;->A06(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 147
    .line 148
    .line 149
    move-result-object p5

    .line 150
    invoke-interface {v13, v5}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v6

    .line 158
    if-nez v0, :cond_5

    .line 159
    .line 160
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 161
    .line 162
    if-ne v6, v0, :cond_6

    .line 163
    .line 164
    :cond_5
    sget-object v0, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->INSTANCE:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;

    .line 165
    .line 166
    invoke-virtual {v0, v5}, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->opener(LX/AHE;)Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 167
    .line 168
    .line 169
    move-result-object v6

    .line 170
    invoke-interface {v13, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_6
    check-cast v6, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 174
    .line 175
    iget-object v7, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->screenshot:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutScreenshot;

    .line 176
    .line 177
    const/4 v9, 0x0

    .line 178
    if-eqz v7, :cond_a

    .line 179
    .line 180
    iget-object v0, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutScreenshot;->url:Ljava/lang/String;

    .line 181
    .line 182
    :goto_4
    invoke-static {v13, v0, v5}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v8

    .line 190
    if-nez v0, :cond_7

    .line 191
    .line 192
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 193
    .line 194
    if-ne v8, v0, :cond_8

    .line 195
    .line 196
    :cond_7
    if-eqz v7, :cond_9

    .line 197
    .line 198
    iget-object v8, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutScreenshot;->url:Ljava/lang/String;

    .line 199
    .line 200
    if-eqz v8, :cond_9

    .line 201
    .line 202
    invoke-static {v8}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    if-nez v0, :cond_9

    .line 207
    .line 208
    sget-object v0, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 209
    .line 210
    invoke-virtual {v0, v8, v5}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveRawAssetUrl(Ljava/lang/String;LX/AHE;)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v8

    .line 214
    :goto_5
    invoke-interface {v13, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    :cond_8
    check-cast v8, Ljava/lang/String;

    .line 218
    .line 219
    if-nez v8, :cond_d

    .line 220
    .line 221
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    if-eqz v4, :cond_3

    .line 226
    .line 227
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$2;

    .line 228
    .line 229
    move-object/from16 v17, v2

    .line 230
    .line 231
    move-object/from16 v18, v11

    .line 232
    .line 233
    move/from16 v19, v1

    .line 234
    .line 235
    move-object v15, v0

    .line 236
    move-object/from16 v16, v3

    .line 237
    .line 238
    invoke-direct/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 239
    .line 240
    .line 241
    goto :goto_3

    .line 242
    :cond_9
    move-object v8, v9

    .line 243
    goto :goto_5

    .line 244
    :cond_a
    move-object v0, v9

    .line 245
    goto :goto_4

    .line 246
    :cond_b
    const v0, -0x36cc481b

    .line 247
    .line 248
    .line 249
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 250
    .line 251
    .line 252
    goto/16 :goto_2

    .line 253
    .line 254
    :cond_c
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 255
    .line 256
    .line 257
    goto :goto_6

    .line 258
    :cond_d
    if-eqz v7, :cond_e

    .line 259
    .line 260
    iget v5, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutScreenshot;->width:I

    .line 261
    .line 262
    if-lez v5, :cond_e

    .line 263
    .line 264
    iget v0, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutScreenshot;->height:I

    .line 265
    .line 266
    if-lez v0, :cond_e

    .line 267
    .line 268
    int-to-float v5, v5

    .line 269
    int-to-float v0, v0

    .line 270
    div-float/2addr v5, v0

    .line 271
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 272
    .line 273
    .line 274
    move-result-object v9

    .line 275
    :cond_e
    iget-object v0, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->browserTaskId:Ljava/lang/String;

    .line 276
    .line 277
    sget-object v10, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutRowShape:LX/2bC;

    .line 278
    .line 279
    new-instance v5, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$3;

    .line 280
    .line 281
    move-object/from16 p0, v5

    .line 282
    .line 283
    move-object/from16 p1, v0

    .line 284
    .line 285
    move-object/from16 p2, v6

    .line 286
    .line 287
    move-object/from16 p3, v3

    .line 288
    .line 289
    move-object/from16 p4, v2

    .line 290
    .line 291
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$3;-><init>(Ljava/lang/String;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 292
    .line 293
    .line 294
    const v0, -0x1c116fec

    .line 295
    .line 296
    .line 297
    invoke-static {v13, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 298
    .line 299
    .line 300
    move-result-object v12

    .line 301
    shl-int/lit8 v0, v4, 0x3

    .line 302
    .line 303
    and-int/lit16 v0, v0, 0x1c00

    .line 304
    .line 305
    or-int/lit16 v14, v0, 0x6180

    .line 306
    .line 307
    invoke-static/range {v8 .. v15}, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt;->ApprovalBrowserScreenshot(Ljava/lang/String;Ljava/lang/Float;LX/2bW;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 308
    .line 309
    .line 310
    :goto_6
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 311
    .line 312
    .line 313
    move-result-object v4

    .line 314
    if-eqz v4, :cond_3

    .line 315
    .line 316
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$4;

    .line 317
    .line 318
    move-object v7, v2

    .line 319
    move-object v8, v11

    .line 320
    move v9, v1

    .line 321
    move-object v5, v0

    .line 322
    move-object v6, v3

    .line 323
    move/from16 v10, v20

    .line 324
    .line 325
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutScreenshot$4;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 326
    .line 327
    .line 328
    goto/16 :goto_3

    .line 329
    .line 330
    :cond_f
    and-int/lit16 v0, v1, 0x180

    .line 331
    .line 332
    if-nez v0, :cond_1

    .line 333
    .line 334
    invoke-static {v13, v11}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 335
    .line 336
    .line 337
    move-result v0

    .line 338
    or-int/2addr v4, v0

    .line 339
    goto/16 :goto_1

    .line 340
    .line 341
    :cond_10
    move v4, v1

    .line 342
    goto/16 :goto_0
.end method

.method public static final synthetic access$CheckoutHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutHeader(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;LX/2iK;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutReviewOrderFavicon-RPmYEkk(Ljava/lang/String;JLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutReviewOrderFavicon-RPmYEkk(Ljava/lang/String;JLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CheckoutScreenshot(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutScreenshot(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getCheckoutPaymentRowShape$p()LX/2bC;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutPaymentRowShape:LX/2bC;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final getCheckoutCardShape()LX/2bC;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutCardShape:LX/2bC;

    .line 1
    .line 2
    return-object v0
.end method
