.class public final Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $document:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

.field public final synthetic $fallbackText:Ljava/lang/String;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public final synthetic $textColor:J

.field public final synthetic $textStyle:LX/2hg;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$document:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$fallbackText:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$textStyle:LX/2hg;

    .line 5
    .line 6
    iput-wide p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$textColor:J

    .line 7
    .line 8
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 11
    .line 12
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$modifier:LX/3C1;

    .line 13
    .line 14
    iput p9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$$changed:I

    .line 15
    .line 16
    iput p10, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$$default:I

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 11

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$document:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$fallbackText:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$textStyle:LX/2hg;

    .line 5
    .line 6
    iget-wide v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$textColor:J

    .line 7
    .line 8
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 11
    .line 12
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$modifier:LX/3C1;

    .line 13
    .line 14
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$$changed:I

    .line 15
    .line 16
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 17
    .line 18
    .line 19
    move-result v10

    .line 20
    iget p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;->$$default:I

    .line 21
    .line 22
    move-object v9, p1

    .line 23
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->AgentPermissionRequestPreviewContent-hYmLsZ8(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
