.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $focusManager:LX/1Ju;

.field public final synthetic $keyboardController:LX/2M7;


# direct methods
.method public constructor <init>(LX/1Ju;LX/2M7;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;->$focusManager:LX/1Ju;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;->$keyboardController:LX/2M7;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;->$focusManager:LX/1Ju;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-interface {v1, v0}, LX/1Ju;->A6K(Z)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;->$keyboardController:LX/2M7;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-interface {v0}, LX/2M7;->hide()V

    .line 11
    .line 12
    .line 13
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1$invoke$$inlined$onDispose$1;

    .line 14
    .line 15
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
