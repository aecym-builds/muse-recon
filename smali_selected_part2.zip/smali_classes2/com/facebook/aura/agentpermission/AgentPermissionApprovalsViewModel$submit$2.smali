.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalsViewModel$submit$2"
    f = "AgentPermissionApprovalsViewModel.kt"
    l = {
        0xde
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $approvalId:Ljava/lang/String;

.field public final synthetic $option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;Ljava/lang/String;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;Ljava/lang/String;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->label:I

    .line 3
    .line 4
    const/4 v7, 0x1

    .line 5
    if-eqz v0, :cond_3

    .line 6
    .line 7
    if-ne v0, v7, :cond_4

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$DecideResult$Success;

    .line 13
    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 17
    .line 18
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->submittingApprovalIds:LX/2J2;

    .line 19
    .line 20
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approvalId:Ljava/lang/String;

    .line 21
    .line 22
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    move-object v0, v1

    .line 27
    check-cast v0, Ljava/util/Set;

    .line 28
    .line 29
    invoke-static {v2, v0}, LX/163;->A03(Ljava/lang/Object;Ljava/util/Set;)Ljava/util/Set;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-interface {v3, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    :cond_2
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 40
    .line 41
    return-object v1

    .line 42
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 46
    .line 47
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 48
    .line 49
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approvalId:Ljava/lang/String;

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 52
    .line 53
    iget-object v4, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 54
    .line 55
    iget-object v5, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->alwaysScope:Ljava/lang/String;

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 58
    .line 59
    iget-object v8, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->messageRevision:Ljava/lang/Long;

    .line 60
    .line 61
    iput v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$submit$2;->label:I

    .line 62
    .line 63
    const/4 v6, 0x0

    .line 64
    move-object v9, v6

    .line 65
    move-object v10, v6

    .line 66
    move-object v11, v6

    .line 67
    invoke-virtual/range {v2 .. v12}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->decideApproval(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v1, :cond_0

    .line 72
    .line 73
    return-object v1

    .line 74
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    throw v0
.end method
