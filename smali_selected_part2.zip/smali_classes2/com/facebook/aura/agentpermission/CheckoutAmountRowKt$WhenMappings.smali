.class public abstract synthetic Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    invoke-static {}, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->values()[Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    :try_start_0
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->PROVIDED:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 8
    .line 9
    invoke-static {v0, v1}, LX/007;->A1G(Ljava/lang/Enum;[I)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    .line 12
    :catch_0
    :try_start_1
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->ORDER_TOTAL:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A1H(Ljava/lang/Enum;[I)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 15
    .line 16
    .line 17
    :catch_1
    :try_start_2
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->STAY_TOTAL:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 18
    .line 19
    invoke-static {v0, v1}, LX/007;->A1I(Ljava/lang/Enum;[I)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 20
    .line 21
    .line 22
    :catch_2
    :try_start_3
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->BASE_RATE:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 23
    .line 24
    invoke-static {v0, v1}, LX/007;->A1J(Ljava/lang/Enum;[I)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 25
    .line 26
    .line 27
    :catch_3
    :try_start_4
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->TAXES_AND_FEES:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 28
    .line 29
    invoke-static {v0, v1}, LX/007;->A1K(Ljava/lang/Enum;[I)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 30
    .line 31
    .line 32
    :catch_4
    :try_start_5
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->PROPERTY_FEES:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/007;->A1L(Ljava/lang/Enum;[I)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 35
    .line 36
    .line 37
    :catch_5
    :try_start_6
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->DUE_NOW:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 38
    .line 39
    invoke-static {v0, v1}, LX/3Rr;->A17(Ljava/lang/Enum;[I)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 40
    .line 41
    .line 42
    :catch_6
    :try_start_7
    sget-object v0, Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;->DUE_AT_PROPERTY:Lcom/facebook/aura/agentpermission/CheckoutAmountLabel;

    .line 43
    .line 44
    invoke-static {v0, v1}, LX/3Rr;->A18(Ljava/lang/Enum;[I)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 45
    .line 46
    .line 47
    :catch_7
    sput-object v1, Lcom/facebook/aura/agentpermission/CheckoutAmountRowKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 48
    .line 49
    return-void
.end method
