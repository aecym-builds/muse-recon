.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final canLoadMoreHistory:Z

.field public final confirmingApprovalIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final history:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final historyLoadMoreKey:Ljava/lang/String;

.field public final historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

.field public final isLoadingMoreHistory:Z

.field public final openApprovals:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final rowDecisions:LX/0Xl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            ">;"
        }
    .end annotation
.end field

.field public final submittingApprovalIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 11

    .line 0
    const/16 v10, 0x1ff

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v4, 0x0

    .line 4
    move-object v0, p0

    .line 5
    move-object v2, v1

    .line 6
    move-object v3, v1

    .line 7
    move v5, v4

    .line 8
    move-object v6, v1

    .line 9
    move-object v7, v1

    .line 10
    move-object v8, v1

    .line 11
    move-object v9, v1

    .line 12
    move-object p0, v1

    .line 13
    invoke-direct/range {v0 .. v11}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;ILX/04f;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;",
            "ZZ",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    const/4 v0, 0x6

    .line 268435460
    invoke-static {p7, p8, p9, v0}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435461
    .line 268435462
    .line 268435463
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435464
    .line 268435465
    .line 268435466
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 268435467
    .line 268435468
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 268435469
    .line 268435470
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 268435471
    .line 268435472
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 268435473
    .line 268435474
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 268435475
    .line 268435476
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 268435477
    .line 268435478
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 268435479
    .line 268435480
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 268435481
    .line 268435482
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 268435483
    .line 268435484
    return-void
.end method

.method public synthetic constructor <init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;ILX/04f;)V
    .locals 1

    .line 536870912
    and-int/lit8 v0, p10, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    sget-object p1, LX/Dwg;->A01:LX/Dwg;

    .line 536870917
    .line 536870918
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    sget-object p2, LX/Dwg;->A01:LX/Dwg;

    .line 536870923
    .line 536870924
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    sget-object p3, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 536870929
    .line 536870930
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 536870931
    .line 536870932
    if-eqz v0, :cond_3

    .line 536870933
    .line 536870934
    const/4 p4, 0x1

    .line 536870935
    :cond_3
    invoke-static {p10, p5}, LX/3Rr;->A1Q(IZ)Z

    .line 536870936
    .line 536870937
    .line 536870938
    move-result p5

    .line 536870939
    and-int/lit8 v0, p10, 0x20

    .line 536870940
    .line 536870941
    if-eqz v0, :cond_4

    .line 536870942
    .line 536870943
    const/4 p6, 0x0

    .line 536870944
    :cond_4
    and-int/lit8 v0, p10, 0x40

    .line 536870945
    .line 536870946
    if-eqz v0, :cond_5

    .line 536870947
    .line 536870948
    sget-object p7, LX/0wX;->A00:LX/0wX;

    .line 536870949
    .line 536870950
    :cond_5
    and-int/lit16 v0, p10, 0x80

    .line 536870951
    .line 536870952
    if-eqz v0, :cond_6

    .line 536870953
    .line 536870954
    sget-object p8, LX/0wX;->A00:LX/0wX;

    .line 536870955
    .line 536870956
    :cond_6
    and-int/lit16 v0, p10, 0x100

    .line 536870957
    .line 536870958
    if-eqz v0, :cond_7

    .line 536870959
    .line 536870960
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 536870961
    .line 536870962
    .line 536870963
    move-result-object p9

    .line 536870964
    :cond_7
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)V

    .line 536870965
    .line 536870966
    .line 536870967
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p10, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 53
    .line 54
    :cond_8
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->copy(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0
.end method


# virtual methods
.method public final component1()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;",
            "ZZ",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 p0, 0x6

    .line 4
    invoke-static {p7, p8, p9, p0}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 8
    .line 9
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;ZZLjava/lang/String;Ljava/util/Set;Ljava/util/Set;LX/0Xl;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 37
    .line 38
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 43
    .line 44
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 45
    .line 46
    if-ne v1, v0, :cond_0

    .line 47
    .line 48
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 51
    .line 52
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_0

    .line 57
    .line 58
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 59
    .line 60
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 61
    .line 62
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_0

    .line 67
    .line 68
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 69
    .line 70
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 71
    .line 72
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_0

    .line 77
    .line 78
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 79
    .line 80
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 81
    .line 82
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-nez v0, :cond_1

    .line 87
    .line 88
    :cond_0
    return v2

    .line 89
    :cond_1
    return v3
.end method

.method public final getCanLoadMoreHistory()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getConfirmingApprovalIds()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHistory()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHistoryLoadMoreKey()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHistoryLoadingState()Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOpenApprovals()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRowDecisions()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubmittingApprovalIds()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->openApprovals:LX/Ddn;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->history:LX/Ddn;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->canLoadMoreHistory:Z

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadMoreKey:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 40
    .line 41
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 46
    .line 47
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 52
    .line 53
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    return v0
.end method

.method public final isLoadingMoreHistory()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->isLoadingMoreHistory:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
