.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final InlineConnectorOrderMaxHeight:F = 400.0f

.field public static final InlineDetailsMaxHeight:F = 155.0f

.field public static final InlineDetailsWithAttachmentsMaxHeight:F = 240.0f


# direct methods
.method public static final AgentPermissionInlineRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;ZLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;ZLX/2d4;II)V
    .locals 29

    .line 0
    move-object/from16 v7, p5

    .line 1
    .line 2
    move/from16 v6, p6

    .line 3
    .line 4
    const/4 v2, 0x3

    .line 5
    move-object/from16 p6, p3

    .line 6
    .line 7
    move-object/from16 p5, p4

    .line 8
    .line 9
    move-object/from16 v1, p6

    .line 10
    .line 11
    move-object/from16 v0, p5

    .line 12
    .line 13
    invoke-static {v1, v2, v0}, LX/003;->A0z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    const v0, -0x4782cb9f

    .line 17
    .line 18
    .line 19
    move-object/from16 v5, p7

    .line 20
    .line 21
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 22
    .line 23
    .line 24
    move/from16 v4, p8

    .line 25
    .line 26
    and-int/lit8 v0, p8, 0x6

    .line 27
    .line 28
    move-object/from16 v15, p0

    .line 29
    .line 30
    if-nez v0, :cond_e

    .line 31
    .line 32
    invoke-static {v15, v5, v4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, LX/003;->A06(I)I

    .line 37
    .line 38
    .line 39
    move-result v8

    .line 40
    or-int v8, v8, p8

    .line 41
    .line 42
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 43
    .line 44
    move-object/from16 v23, p1

    .line 45
    .line 46
    if-nez v0, :cond_0

    .line 47
    .line 48
    move-object/from16 v0, v23

    .line 49
    .line 50
    invoke-static {v5, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v8, v0

    .line 55
    :cond_0
    and-int/lit16 v0, v4, 0x180

    .line 56
    .line 57
    move/from16 v21, p2

    .line 58
    .line 59
    if-nez v0, :cond_1

    .line 60
    .line 61
    move/from16 v0, v21

    .line 62
    .line 63
    invoke-static {v5, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    or-int/2addr v8, v0

    .line 68
    :cond_1
    and-int/lit16 v0, v4, 0xc00

    .line 69
    .line 70
    if-nez v0, :cond_2

    .line 71
    .line 72
    invoke-static {v1, v5, v4}, LX/005;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, LX/003;->A02(I)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    or-int/2addr v8, v0

    .line 81
    :cond_2
    and-int/lit16 v0, v4, 0x6000

    .line 82
    .line 83
    if-nez v0, :cond_3

    .line 84
    .line 85
    invoke-virtual/range {p5 .. p5}, Ljava/lang/Enum;->ordinal()I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    invoke-static {v5, v0}, LX/004;->A0H(LX/2d4;I)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    or-int/2addr v8, v0

    .line 94
    :cond_3
    move/from16 p4, p9

    .line 95
    .line 96
    and-int/lit8 v9, p9, 0x20

    .line 97
    .line 98
    const/high16 v0, 0x30000

    .line 99
    .line 100
    if-nez v9, :cond_4

    .line 101
    .line 102
    and-int v0, v0, p8

    .line 103
    .line 104
    if-nez v0, :cond_5

    .line 105
    .line 106
    invoke-static {v5, v7}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    :cond_4
    or-int/2addr v8, v0

    .line 111
    :cond_5
    and-int/lit8 v2, p9, 0x40

    .line 112
    .line 113
    const/high16 v0, 0x180000

    .line 114
    .line 115
    if-nez v2, :cond_6

    .line 116
    .line 117
    and-int v0, v0, p8

    .line 118
    .line 119
    if-nez v0, :cond_7

    .line 120
    .line 121
    invoke-static {v5, v6}, LX/004;->A0o(LX/2d4;Z)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    :cond_6
    or-int/2addr v8, v0

    .line 126
    :cond_7
    const v1, 0x92493

    .line 127
    .line 128
    .line 129
    and-int/2addr v1, v8

    .line 130
    const v0, 0x92492

    .line 131
    .line 132
    .line 133
    const/4 v3, 0x0

    .line 134
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    invoke-static {v0, v5, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-eqz v0, :cond_12

    .line 143
    .line 144
    if-eqz v9, :cond_8

    .line 145
    .line 146
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 147
    .line 148
    :cond_8
    invoke-static {v2, v6}, LX/001;->A1P(IZ)Z

    .line 149
    .line 150
    .line 151
    move-result v6

    .line 152
    const/4 v2, 0x1

    .line 153
    invoke-static {v3, v5, v3, v2}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 154
    .line 155
    .line 156
    move-result-object v20

    .line 157
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 158
    .line 159
    const/4 v10, 0x6

    .line 160
    invoke-static {v5, v11}, LX/3Rs;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 161
    .line 162
    .line 163
    move-result-wide v18

    .line 164
    if-eqz p0, :cond_9

    .line 165
    .line 166
    iget-object v0, v15, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->listCells:Ljava/util/List;

    .line 167
    .line 168
    const/16 v17, 0x1

    .line 169
    .line 170
    if-nez v0, :cond_a

    .line 171
    .line 172
    :cond_9
    const/16 v17, 0x0

    .line 173
    .line 174
    :cond_a
    sget-object v16, LX/2sI;->A02:LX/2wD;

    .line 175
    .line 176
    move-object/from16 v0, v16

    .line 177
    .line 178
    invoke-interface {v7, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 179
    .line 180
    .line 181
    move-result-object v9

    .line 182
    if-eqz v17, :cond_b

    .line 183
    .line 184
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 185
    .line 186
    :goto_1
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 187
    .line 188
    invoke-static {v9, v0, v1}, LX/2sI;->A0A(LX/3C1;FF)LX/3C1;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-virtual {v11, v5, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getDimensions(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraDimensions;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    iget v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraDimensions;->sectionCornerRadius:F

    .line 197
    .line 198
    invoke-static {v1, v0}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 199
    .line 200
    .line 201
    move-result-object v9

    .line 202
    move-wide/from16 v0, v18

    .line 203
    .line 204
    invoke-static {v9, v0, v1}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    invoke-static {v3}, LX/001;->A0g(Z)LX/3BI;

    .line 209
    .line 210
    .line 211
    move-result-object v14

    .line 212
    move-object v1, v5

    .line 213
    check-cast v1, LX/J7I;

    .line 214
    .line 215
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 216
    .line 217
    .line 218
    move-result v13

    .line 219
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 220
    .line 221
    .line 222
    move-result-object v12

    .line 223
    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 224
    .line 225
    .line 226
    move-result-object v10

    .line 227
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 228
    .line 229
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 230
    .line 231
    if-nez v0, :cond_f

    .line 232
    .line 233
    invoke-static {}, LX/1VY;->A00()V

    .line 234
    .line 235
    .line 236
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    throw v0

    .line 241
    :cond_b
    if-eqz v6, :cond_c

    .line 242
    .line 243
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineConnectorOrderMaxHeight:F

    .line 244
    .line 245
    goto :goto_1

    .line 246
    :cond_c
    if-eqz p2, :cond_d

    .line 247
    .line 248
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineDetailsWithAttachmentsMaxHeight:F

    .line 249
    .line 250
    goto :goto_1

    .line 251
    :cond_d
    sget v1, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineDetailsMaxHeight:F

    .line 252
    .line 253
    goto :goto_1

    .line 254
    :cond_e
    move v8, v4

    .line 255
    goto/16 :goto_0

    .line 256
    .line 257
    :cond_f
    invoke-static {v5, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 258
    .line 259
    .line 260
    invoke-static {v5, v14, v12, v10, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 261
    .line 262
    .line 263
    sget-object v12, LX/3Jn;->A00:LX/3Jn;

    .line 264
    .line 265
    invoke-static {v5, v11}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 266
    .line 267
    .line 268
    move-result-object v24

    .line 269
    invoke-static {v5, v11}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 270
    .line 271
    .line 272
    move-result-wide v25

    .line 273
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 274
    .line 275
    move-object v11, v9

    .line 276
    invoke-static/range {v16 .. v16}, LX/2pj;->A03(LX/3C1;)LX/3C1;

    .line 277
    .line 278
    .line 279
    move-result-object v10

    .line 280
    if-nez v17, :cond_10

    .line 281
    .line 282
    move-object/from16 v0, v20

    .line 283
    .line 284
    invoke-static {v0, v9, v2}, LX/3J3;->A02(LX/3Lr;LX/3C1;Z)LX/3C1;

    .line 285
    .line 286
    .line 287
    move-result-object v9

    .line 288
    :cond_10
    invoke-interface {v10, v9}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 289
    .line 290
    .line 291
    move-result-object p0

    .line 292
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->$stable:I

    .line 293
    .line 294
    and-int/lit8 v0, v8, 0xe

    .line 295
    .line 296
    invoke-static {v9, v0, v8}, LX/3Rq;->A00(III)I

    .line 297
    .line 298
    .line 299
    move-result v0

    .line 300
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 301
    .line 302
    shl-int/lit8 v9, v9, 0xc

    .line 303
    .line 304
    or-int/2addr v0, v9

    .line 305
    shl-int/lit8 v8, v8, 0x3

    .line 306
    .line 307
    invoke-static {v8, v0}, LX/005;->A07(II)I

    .line 308
    .line 309
    .line 310
    move-result p2

    .line 311
    move-object/from16 v27, p6

    .line 312
    .line 313
    move-object/from16 v28, p5

    .line 314
    .line 315
    move-object/from16 p1, v5

    .line 316
    .line 317
    move/from16 p3, v3

    .line 318
    .line 319
    move-object/from16 v22, v15

    .line 320
    .line 321
    invoke-static/range {v22 .. v32}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->AgentPermissionRequestPreviewContent-hYmLsZ8(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 322
    .line 323
    .line 324
    if-nez v17, :cond_11

    .line 325
    .line 326
    const v0, -0x1cacd69f

    .line 327
    .line 328
    .line 329
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 330
    .line 331
    .line 332
    sget-object v0, LX/2Id;->A06:Landroidx/compose/ui/Alignment;

    .line 333
    .line 334
    invoke-virtual {v12, v0, v11}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 335
    .line 336
    .line 337
    move-result-object v11

    .line 338
    move-object/from16 v8, v20

    .line 339
    .line 340
    move-wide/from16 v9, v18

    .line 341
    .line 342
    move-object v12, v5

    .line 343
    move v13, v3

    .line 344
    move v14, v3

    .line 345
    invoke-static/range {v8 .. v14}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineRequestPreviewBottomFade-3IgeMak(LX/3Lr;JLX/3C1;LX/2d4;II)V

    .line 346
    .line 347
    .line 348
    :goto_2
    invoke-static {v1, v7, v3, v2}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 349
    .line 350
    .line 351
    move-result-object v7

    .line 352
    goto :goto_3

    .line 353
    :cond_11
    const v0, -0x1ca9ef59

    .line 354
    .line 355
    .line 356
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 357
    .line 358
    .line 359
    goto :goto_2

    .line 360
    :cond_12
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 361
    .line 362
    .line 363
    :goto_3
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 364
    .line 365
    .line 366
    move-result-object v1

    .line 367
    if-eqz v1, :cond_13

    .line 368
    .line 369
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$AgentPermissionInlineRequestPreview$2;

    .line 370
    .line 371
    move-object/from16 v24, v0

    .line 372
    .line 373
    move-object/from16 v25, v15

    .line 374
    .line 375
    move-object/from16 v26, v23

    .line 376
    .line 377
    move/from16 v27, v21

    .line 378
    .line 379
    move-object/from16 v28, p6

    .line 380
    .line 381
    move-object/from16 p0, p5

    .line 382
    .line 383
    move-object/from16 p1, v7

    .line 384
    .line 385
    move/from16 p2, v6

    .line 386
    .line 387
    move/from16 p3, v4

    .line 388
    .line 389
    invoke-direct/range {v24 .. v33}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$AgentPermissionInlineRequestPreview$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;ZLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;ZII)V

    .line 390
    .line 391
    .line 392
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 393
    .line 394
    :cond_13
    return-void
.end method

.method public static final InlineRequestPreviewBottomFade-3IgeMak(LX/3Lr;JLX/3C1;LX/2d4;II)V
    .locals 9

    .line 0
    move-object v7, p3

    .line 1
    const v0, -0x4560b195

    .line 2
    .line 3
    .line 4
    invoke-interface {p4, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    move v8, p5

    .line 8
    and-int/lit8 v0, p5, 0x6

    .line 9
    .line 10
    move-object v4, p0

    .line 11
    if-nez v0, :cond_a

    .line 12
    .line 13
    invoke-static {p4, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    or-int/2addr v2, p5

    .line 18
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 19
    .line 20
    move-wide v5, p1

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-static {p4, p1, p2}, LX/008;->A0N(LX/2d4;J)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    or-int/2addr v2, v0

    .line 28
    :cond_0
    move p0, p6

    .line 29
    and-int/lit8 v1, p6, 0x4

    .line 30
    .line 31
    if-eqz v1, :cond_9

    .line 32
    .line 33
    or-int/lit16 v2, v2, 0x180

    .line 34
    .line 35
    :cond_1
    :goto_1
    invoke-static {v2}, LX/005;->A1I(I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0, p4, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_8

    .line 44
    .line 45
    if-eqz v1, :cond_2

    .line 46
    .line 47
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 48
    .line 49
    :cond_2
    invoke-static {v2}, LX/008;->A1X(I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    if-nez v0, :cond_3

    .line 58
    .line 59
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 60
    .line 61
    if-ne v1, v0, :cond_4

    .line 62
    .line 63
    :cond_3
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;

    .line 64
    .line 65
    invoke-direct {v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;-><init>(LX/3Lr;)V

    .line 66
    .line 67
    .line 68
    invoke-static {p4, v0}, LX/004;->A10(LX/2d4;Lkotlin/jvm/functions/Function0;)LX/J75;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    :cond_4
    check-cast v1, LX/16A;

    .line 73
    .line 74
    invoke-static {v1}, LX/16A;->A0C(LX/16A;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_6

    .line 79
    .line 80
    invoke-interface {p4}, LX/2d4;->AAg()LX/J7V;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    if-eqz v0, :cond_5

    .line 85
    .line 86
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;

    .line 87
    .line 88
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$1;-><init>(LX/3Lr;JLX/3C1;II)V

    .line 89
    .line 90
    .line 91
    :goto_2
    invoke-static {v0, v3}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    :cond_5
    return-void

    .line 95
    :cond_6
    invoke-static {v2}, LX/004;->A1S(I)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    const/4 v1, 0x0

    .line 104
    if-nez v0, :cond_7

    .line 105
    .line 106
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 107
    .line 108
    if-eq v2, v0, :cond_7

    .line 109
    .line 110
    const/4 v3, 0x0

    .line 111
    :goto_3
    check-cast v2, LX/2hZ;

    .line 112
    .line 113
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    const/high16 v0, 0x42200000    # 40.0f

    .line 118
    .line 119
    invoke-static {v1, v0}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    sget-object v0, LX/2oZ;->A00:LX/2bW;

    .line 124
    .line 125
    invoke-static {v1, v2, v0}, LX/2pC;->A02(LX/3C1;LX/2hZ;LX/2bW;)LX/3C1;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    invoke-static {v0, p4, v3}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 130
    .line 131
    .line 132
    goto :goto_4

    .line 133
    :cond_7
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    const/4 v3, 0x0

    .line 138
    invoke-static {p1, p2, v1}, LX/JOw;->A04(JF)J

    .line 139
    .line 140
    .line 141
    move-result-wide v0

    .line 142
    invoke-static {v2, v0, v1}, LX/003;->A0o(Ljava/lang/Object;J)LX/IBK;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    const v0, 0x3f19999a    # 0.6f

    .line 147
    .line 148
    .line 149
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-static {v0, p1, p2}, LX/003;->A0o(Ljava/lang/Object;J)LX/IBK;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    const/high16 v0, 0x3f800000    # 1.0f

    .line 158
    .line 159
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    invoke-static {v0, p1, p2}, LX/003;->A0o(Ljava/lang/Object;J)LX/IBK;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    filled-new-array {v2, v1, v0}, [LX/IBK;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    const/high16 v0, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 172
    .line 173
    invoke-static {v1, v0}, LX/2hZ;->A03([LX/IBK;F)LX/2hU;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    invoke-interface {p4, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    goto :goto_3

    .line 181
    :cond_8
    invoke-interface {p4}, LX/2d4;->AgJ()V

    .line 182
    .line 183
    .line 184
    :goto_4
    invoke-interface {p4}, LX/2d4;->AAg()LX/J7V;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    if-eqz v0, :cond_5

    .line 189
    .line 190
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$2;

    .line 191
    .line 192
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$2;-><init>(LX/3Lr;JLX/3C1;II)V

    .line 193
    .line 194
    .line 195
    goto :goto_2

    .line 196
    :cond_9
    and-int/lit16 v0, p5, 0x180

    .line 197
    .line 198
    if-nez v0, :cond_1

    .line 199
    .line 200
    invoke-static {p4, p3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 201
    .line 202
    .line 203
    move-result v0

    .line 204
    or-int/2addr v2, v0

    .line 205
    goto/16 :goto_1

    .line 206
    .line 207
    :cond_a
    move v2, p5

    .line 208
    goto/16 :goto_0
.end method

.method public static final InlineRequestPreviewBottomFade_3IgeMak$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$InlineRequestPreviewBottomFade-3IgeMak(LX/3Lr;JLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt;->InlineRequestPreviewBottomFade-3IgeMak(LX/3Lr;JLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
