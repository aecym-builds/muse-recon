.class public final enum Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

.field public static final enum BODY_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

.field public static final enum EMPTY_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

.field public static final enum INVALID_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

.field public static final enum SAVE_FAILED:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

.field public static final enum SUBJECT_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const-string v1, "SAVE_FAILED"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 4
    .line 5
    invoke-direct {v6, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v6, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->SAVE_FAILED:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 9
    .line 10
    const-string v1, "INVALID_MESSAGE"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 14
    .line 15
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v5, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->INVALID_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 19
    .line 20
    const-string v1, "SUBJECT_TOO_LONG"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 24
    .line 25
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->SUBJECT_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 29
    .line 30
    const-string v1, "BODY_TOO_LONG"

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 34
    .line 35
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->BODY_TOO_LONG:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 39
    .line 40
    const-string v2, "EMPTY_MESSAGE"

    .line 41
    .line 42
    const/4 v1, 0x4

    .line 43
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 44
    .line 45
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->EMPTY_MESSAGE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 49
    .line 50
    filled-new-array {v6, v5, v4, v3, v0}, [Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->$VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 55
    .line 56
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->$ENTRIES:LX/0vk;

    .line 61
    .line 62
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;->$VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorError;

    .line 7
    .line 8
    return-object v0
.end method
