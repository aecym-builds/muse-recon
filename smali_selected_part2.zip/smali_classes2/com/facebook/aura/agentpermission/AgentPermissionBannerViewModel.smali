.class public final Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final primarySessionRepository:Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;

.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final screenSessionId:Ljava/lang/String;

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/AHE;Ljava/lang/String;)V
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;->Companion:Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository$Companion;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->primarySessionRepository:Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;

    .line 20
    .line 21
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->screenSessionId:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v3, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 24
    .line 25
    iget-object v2, v0, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;->primarySessionId:LX/2J3;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;

    .line 29
    .line 30
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;LX/2M4;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v0, v3, v2}, LX/EXj;->A03(LX/JDQ;LX/2Lw;LX/2Lw;)LX/EUU;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    sget-object v2, LX/5Lz;->A00:LX/5Ly;

    .line 42
    .line 43
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;

    .line 46
    .line 47
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;-><init>(Ljava/util/List;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v0, v3, v4, v2}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->uiState:LX/2J3;

    .line 55
    .line 56
    return-void
.end method

.method public static final synthetic access$getScreenSessionId$p(Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->screenSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method
