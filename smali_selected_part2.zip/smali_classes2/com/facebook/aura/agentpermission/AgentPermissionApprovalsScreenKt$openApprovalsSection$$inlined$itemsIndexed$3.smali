.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDO<",
        "LX/1Xg;",
        "Ljava/lang/Integer;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $items:Ljava/util/List;

.field public final synthetic $onOpen$inlined:LX/JDM;

.field public final synthetic $onSubmit$inlined:LX/JDN;

.field public final synthetic $uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;LX/JDN;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onSubmit$inlined:LX/JDN;

    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    check-cast p1, LX/1Xg;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v1

    .line 268435462
    check-cast p3, LX/2d4;

    .line 268435463
    .line 268435464
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    invoke-virtual {p0, p1, v1, p3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->invoke(LX/1Xg;ILX/2d4;I)V

    .line 268435469
    .line 268435470
    .line 268435471
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435472
    .line 268435473
    return-object v0
.end method

.method public final invoke(LX/1Xg;ILX/2d4;I)V
    .locals 12

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move-object v11, p3

    .line 3
    if-nez v0, :cond_7

    .line 4
    .line 5
    invoke-static {p3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    or-int v1, p4, v0

    .line 10
    .line 11
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-static {p3, p2}, LX/004;->A0F(LX/2d4;I)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    or-int/2addr v1, v0

    .line 20
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0, p3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_8

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 31
    .line 32
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    check-cast v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 37
    .line 38
    const v0, -0x16a794a4

    .line 39
    .line 40
    .line 41
    invoke-static {v4, p3, v0}, LX/002;->A1a(Ljava/lang/Object;LX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 46
    .line 47
    invoke-static {p3, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 52
    .line 53
    invoke-static {p3, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    if-nez v0, :cond_1

    .line 62
    .line 63
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v9, v0, :cond_2

    .line 66
    .line 67
    :cond_1
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 70
    .line 71
    new-instance v9, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;

    .line 72
    .line 73
    invoke-direct {v9, v4, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$onReview$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V

    .line 74
    .line 75
    .line 76
    invoke-interface {p3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_2
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 80
    .line 81
    invoke-static {v4}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->rendersCheckoutCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const/4 v5, 0x0

    .line 86
    if-eqz v0, :cond_3

    .line 87
    .line 88
    const v0, -0x534f8dbc

    .line 89
    .line 90
    .line 91
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 92
    .line 93
    .line 94
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 95
    .line 96
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 97
    .line 98
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 99
    .line 100
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 105
    .line 106
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 107
    .line 108
    or-int/lit16 v0, v0, 0xc00

    .line 109
    .line 110
    const/4 v8, 0x0

    .line 111
    move-object v2, v4

    .line 112
    move-object v4, v9

    .line 113
    move-object v6, p3

    .line 114
    move v7, v0

    .line 115
    invoke-static/range {v2 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->CheckoutApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 116
    .line 117
    .line 118
    :goto_1
    invoke-static {p3}, LX/004;->A1H(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    return-void

    .line 122
    :cond_3
    if-nez p2, :cond_6

    .line 123
    .line 124
    const v0, -0x534f6bd7

    .line 125
    .line 126
    .line 127
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 128
    .line 129
    .line 130
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 131
    .line 132
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->rowDecisions:LX/0Xl;

    .line 133
    .line 134
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 135
    .line 136
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    check-cast v5, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 141
    .line 142
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 143
    .line 144
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->submittingApprovalIds:Ljava/util/Set;

    .line 145
    .line 146
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 147
    .line 148
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v6

    .line 152
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$uiState$inlined:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 153
    .line 154
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->confirmingApprovalIds:Ljava/util/Set;

    .line 155
    .line 156
    iget-object v0, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 157
    .line 158
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    move-result v7

    .line 162
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onSubmit$inlined:LX/JDN;

    .line 163
    .line 164
    invoke-static {p3, v0, v4}, LX/003;->A1M(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v8

    .line 172
    if-nez v0, :cond_4

    .line 173
    .line 174
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 175
    .line 176
    if-ne v8, v0, :cond_5

    .line 177
    .line 178
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$3;->$onSubmit$inlined:LX/JDN;

    .line 179
    .line 180
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$1$1;

    .line 181
    .line 182
    invoke-direct {v8, v0, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$3$1$1;-><init>(LX/JDN;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 183
    .line 184
    .line 185
    invoke-interface {p3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    :cond_5
    check-cast v8, LX/JDM;

    .line 189
    .line 190
    sget-object v10, LX/2sI;->A02:LX/2wD;

    .line 191
    .line 192
    const/high16 v1, 0x180000

    .line 193
    .line 194
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 195
    .line 196
    or-int/2addr v1, v0

    .line 197
    sget v0, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;->$stable:I

    .line 198
    .line 199
    shl-int/lit8 p0, v0, 0x3

    .line 200
    .line 201
    or-int/2addr p0, v1

    .line 202
    const/4 p1, 0x0

    .line 203
    invoke-static/range {v4 .. v13}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ExpandedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 204
    .line 205
    .line 206
    goto :goto_1

    .line 207
    :cond_6
    const v0, -0x534f31c8

    .line 208
    .line 209
    .line 210
    invoke-interface {p3, v0}, LX/2d4;->Agj(I)V

    .line 211
    .line 212
    .line 213
    sget v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 214
    .line 215
    const/4 v8, 0x4

    .line 216
    move-object v3, v4

    .line 217
    move-object v4, v9

    .line 218
    move-object v6, p3

    .line 219
    invoke-static/range {v3 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->CollapsedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 220
    .line 221
    .line 222
    goto :goto_1

    .line 223
    :cond_7
    move/from16 v1, p4

    .line 224
    .line 225
    goto/16 :goto_0

    .line 226
    .line 227
    :cond_8
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 228
    .line 229
    .line 230
    return-void
.end method
