.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final agentPermissionApprovalImpression(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)LX/3C1;
    .locals 13

    .line 0
    move-object v1, p0

    .line 1
    move-object v5, p2

    .line 2
    invoke-static {p0, p1, p2}, LX/3Rs;->A1R(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 7
    .line 8
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 9
    .line 10
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 11
    .line 12
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_REQUEST_CARD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 13
    .line 14
    iget-object v7, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionImpressionMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object v8

    .line 20
    const/4 v9, 0x0

    .line 21
    const-wide/16 v10, 0x1f4

    .line 22
    .line 23
    const/4 v12, 0x0

    .line 24
    move-object p0, v9

    .line 25
    move-object p1, v9

    .line 26
    move-object p2, v9

    .line 27
    invoke-static/range {v1 .. v15}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method

.method public static final agentPermissionCardMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance v2, LX/Imj;

    .line 1
    .line 2
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    const-string v1, "approval_count"

    .line 6
    .line 7
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    const-string v1, "approval_id"

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 24
    .line 25
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->metadataValue(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const-string v0, "approval_type"

    .line 30
    .line 31
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    :cond_0
    if-eqz p2, :cond_1

    .line 35
    .line 36
    const-string v0, "decision"

    .line 37
    .line 38
    invoke-virtual {v2, v0, p2}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    :cond_1
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public static final agentPermissionCardMetadata(Ljava/util/List;Ljava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 268435456
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    const/4 v0, 0x1

    .line 268435461
    if-ne v1, v0, :cond_0

    .line 268435462
    .line 268435463
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 268435464
    .line 268435465
    .line 268435466
    move-result v1

    .line 268435467
    invoke-static {p0}, LX/B89;->A0X(Ljava/util/List;)Ljava/lang/Object;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435472
    .line 268435473
    invoke-static {v1, v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionCardMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/util/Map;

    .line 268435474
    .line 268435475
    .line 268435476
    move-result-object v0

    .line 268435477
    return-object v0

    .line 268435478
    :cond_0
    new-instance v2, LX/Imj;

    .line 268435479
    .line 268435480
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 268435481
    .line 268435482
    .line 268435483
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 268435484
    .line 268435485
    .line 268435486
    move-result v0

    .line 268435487
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 268435488
    .line 268435489
    .line 268435490
    move-result-object v1

    .line 268435491
    const-string v0, "approval_count"

    .line 268435492
    .line 268435493
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435494
    .line 268435495
    .line 268435496
    if-eqz p1, :cond_1

    .line 268435497
    .line 268435498
    const-string v0, "decision"

    .line 268435499
    .line 268435500
    invoke-virtual {v2, v0, p1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435501
    .line 268435502
    .line 268435503
    :cond_1
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 268435504
    .line 268435505
    .line 268435506
    move-result-object v0

    .line 268435507
    return-object v0
.end method

.method public static final agentPermissionImpressionMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance v2, LX/Imj;

    .line 1
    .line 2
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    const-string v1, "pending_count"

    .line 6
    .line 7
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    const-string v1, "approval_id"

    .line 15
    .line 16
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 22
    .line 23
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->metadataValue(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v0, "approval_type"

    .line 28
    .line 29
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method

.method public static final connectorCartCheckFailedImpression(LX/3C1;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;Ljava/lang/String;)LX/3C1;
    .locals 14

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v3, p0

    .line 2
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    move-object/from16 v7, p2

    .line 7
    .line 8
    move-object/from16 v2, p3

    .line 9
    .line 10
    invoke-static {p1, v7, v2, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 11
    .line 12
    .line 13
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 14
    .line 15
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 16
    .line 17
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 18
    .line 19
    sget-object v8, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CART_CHECK_FAILED_STATE:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 20
    .line 21
    iget-object v9, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionImpressionMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/util/Map;

    .line 24
    .line 25
    .line 26
    move-result-object v10

    .line 27
    invoke-virtual {v7}, Lcom/facebook/aura/analytics/hatch/HatchScreen;->getValue()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v0, ":"

    .line 32
    .line 33
    invoke-static {v2, v0, v1}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const/4 v11, 0x0

    .line 38
    const-wide/16 v12, 0x1f4

    .line 39
    .line 40
    const/4 p0, 0x0

    .line 41
    move-object/from16 p2, v11

    .line 42
    .line 43
    move-object/from16 p3, v11

    .line 44
    .line 45
    invoke-static/range {v3 .. v17}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    return-object v0
.end method

.method public static final logAgentPermissionApprovalImpression(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ILcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 7

    .line 0
    move-object v4, p2

    .line 1
    invoke-static {p0, p2}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 7
    .line 8
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 9
    .line 10
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 11
    .line 12
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_REQUEST_CARD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 13
    .line 14
    iget-object v6, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionImpressionMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Ljava/util/Map;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    const/4 p1, 0x0

    .line 21
    invoke-virtual/range {v0 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->logImpression(Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public static final logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    iget-object v6, p2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-static {v0, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionCardMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/util/Map;

    .line 10
    .line 11
    .line 12
    move-result-object v7

    .line 13
    const/4 v8, 0x0

    .line 14
    move-object v5, p0

    .line 15
    move-object v4, p1

    .line 16
    invoke-virtual/range {v1 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static final logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    move-object v4, p1

    .line 268435457
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435458
    .line 268435459
    .line 268435460
    const/4 v0, 0x6

    .line 268435461
    invoke-static {p6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435462
    .line 268435463
    .line 268435464
    const/4 p1, 0x0

    .line 268435465
    if-eqz p4, :cond_2

    .line 268435466
    .line 268435467
    iget-object v0, p4, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 268435468
    .line 268435469
    :goto_0
    if-eqz p3, :cond_1

    .line 268435470
    .line 268435471
    invoke-static {p3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionCardMetadata(Ljava/util/List;Ljava/lang/String;)Ljava/util/Map;

    .line 268435472
    .line 268435473
    .line 268435474
    move-result-object v0

    .line 268435475
    :goto_1
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 268435476
    .line 268435477
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 268435478
    .line 268435479
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 268435480
    .line 268435481
    if-eqz p2, :cond_0

    .line 268435482
    .line 268435483
    iget-object p1, p2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 268435484
    .line 268435485
    :cond_0
    invoke-static {v0, p6}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 268435486
    .line 268435487
    .line 268435488
    move-result-object p2

    .line 268435489
    const/4 p3, 0x0

    .line 268435490
    invoke-virtual/range {v1 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 268435491
    .line 268435492
    .line 268435493
    return-void

    .line 268435494
    :cond_1
    invoke-static {p5, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->agentPermissionCardMetadata(ILcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Ljava/util/Map;

    .line 268435495
    .line 268435496
    .line 268435497
    move-result-object v0

    .line 268435498
    goto :goto_1

    .line 268435499
    :cond_2
    move-object v0, p1

    .line 268435500
    goto :goto_0
.end method

.method public static synthetic logAgentPermissionCardClick$default(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;ILjava/lang/Object;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p7, 0x4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object p2, v1

    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    move-object p3, v1

    .line 11
    :cond_1
    and-int/lit8 v0, p7, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    move-object p4, v1

    .line 16
    :cond_2
    and-int/lit8 v0, p7, 0x20

    .line 17
    .line 18
    if-eqz v0, :cond_3

    .line 19
    .line 20
    const/4 p5, 0x1

    .line 21
    :cond_3
    and-int/lit8 v0, p7, 0x40

    .line 22
    .line 23
    invoke-static {v0, p6}, LX/3Rr;->A0w(ILjava/util/Map;)Ljava/util/Map;

    .line 24
    .line 25
    .line 26
    move-result-object p6

    .line 27
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public static final logAgentPermissionDecisionSheetConfirmClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)V
    .locals 3

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_DECISION_SHEET_CONFIRM_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 4
    .line 5
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 6
    .line 7
    iget-object v0, p1, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v2, v1, p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public static final logAgentPermissionSheetCloseClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 2

    .line 0
    const/4 v1, 0x1

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CLOSE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    invoke-static {v0, p1, p0, v1}, LX/3Rs;->A11(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static synthetic logAgentPermissionSheetCloseClick$default(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p1, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    :cond_0
    invoke-static {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionSheetCloseClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static final logApprovalsLoadMoreClick()V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->STATUS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BOT_SHEET_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BOT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchComponent;->LOAD_MORE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->TAB_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchComponent;->getValue()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    const/4 v7, 0x0

    .line 17
    move-object v8, v7

    .line 18
    invoke-virtual/range {v1 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public static final logCheckoutSheetBackClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchComponent;->BACK_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    invoke-static {v1, v0, p0}, LX/3Rs;->A10(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final logCheckoutTermsLinkClick(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 2

    .line 0
    invoke-static {p0, p1}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->BROWSER_CHECKOUT_TERMS_LINK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    invoke-static {v0, p1, p0, v1}, LX/3Rs;->A11(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static final metadataValue(Lcom/facebook/aura/gateway/AgentPermissionPayloadType;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->getWireValue()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    if-nez p0, :cond_0

    .line 5
    .line 6
    const-string p0, "unknown"

    .line 7
    .line 8
    :cond_0
    return-object p0
.end method
