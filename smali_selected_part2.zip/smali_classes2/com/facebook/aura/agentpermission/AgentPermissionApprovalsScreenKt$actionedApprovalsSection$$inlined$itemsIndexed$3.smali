.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDO<",
        "LX/1Xg;",
        "Ljava/lang/Integer;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $items:Ljava/util/List;

.field public final synthetic $onOpen$inlined:LX/JDM;


# direct methods
.method public constructor <init>(Ljava/util/List;LX/JDM;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    check-cast p1, LX/1Xg;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v1

    .line 268435462
    check-cast p3, LX/2d4;

    .line 268435463
    .line 268435464
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    invoke-virtual {p0, p1, v1, p3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->invoke(LX/1Xg;ILX/2d4;I)V

    .line 268435469
    .line 268435470
    .line 268435471
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435472
    .line 268435473
    return-object v0
.end method

.method public final invoke(LX/1Xg;ILX/2d4;I)V
    .locals 6

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move-object v5, p3

    .line 3
    if-nez v0, :cond_3

    .line 4
    .line 5
    invoke-static {p3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    or-int/2addr v1, p4

    .line 10
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-static {p3, p2}, LX/004;->A0F(LX/2d4;I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    or-int/2addr v1, v0

    .line 19
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0, p3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->$items:Ljava/util/List;

    .line 30
    .line 31
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 36
    .line 37
    const v0, -0x7c3f6d36

    .line 38
    .line 39
    .line 40
    invoke-static {v2, p3, v0}, LX/002;->A1a(Ljava/lang/Object;LX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 45
    .line 46
    invoke-static {p3, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 57
    .line 58
    if-ne v3, v0, :cond_2

    .line 59
    .line 60
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$$inlined$itemsIndexed$3;->$onOpen$inlined:LX/JDM;

    .line 61
    .line 62
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$3$1$1;

    .line 63
    .line 64
    invoke-direct {v3, v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$actionedApprovalsSection$3$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/JDM;)V

    .line 65
    .line 66
    .line 67
    invoke-interface {p3, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_2
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 71
    .line 72
    sget p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 73
    .line 74
    const/4 v4, 0x0

    .line 75
    const/4 p1, 0x4

    .line 76
    invoke-static/range {v2 .. v7}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ActionedApprovalRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 77
    .line 78
    .line 79
    invoke-static {p3}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :cond_3
    move v1, p4

    .line 84
    goto :goto_0

    .line 85
    :cond_4
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 86
    .line 87
    .line 88
    return-void
.end method
