.class public final Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

.field public final synthetic $formattedAmount:Ljava/lang/String;

.field public final synthetic $onOpenBrowserClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onShowDetails:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onShowEstimatedTotalInfo:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $totalPromoCaption:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onShowDetails:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$formattedAmount:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onShowEstimatedTotalInfo:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$totalPromoCaption:Ljava/lang/String;

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 16

    .line 268435456
    const/4 v10, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    move/from16 v1, p3

    .line 268435460
    .line 268435461
    invoke-static {v0, v10, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    move-object/from16 v11, p2

    .line 268435466
    .line 268435467
    invoke-static {v0, v11, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v0

    .line 268435471
    if-eqz v0, :cond_1

    .line 268435472
    .line 268435473
    move-object/from16 v0, p0

    .line 268435474
    .line 268435475
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 268435476
    .line 268435477
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 268435478
    .line 268435479
    sget v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->$stable:I

    .line 268435480
    .line 268435481
    const/4 v14, 0x0

    .line 268435482
    const/4 v6, 0x4

    .line 268435483
    move-object v3, v14

    .line 268435484
    move-object v4, v11

    .line 268435485
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutScreenshot(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435486
    .line 268435487
    .line 268435488
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 268435489
    .line 268435490
    iget-object v5, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->cardBrand:Ljava/lang/String;

    .line 268435491
    .line 268435492
    iget-object v6, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->cardLast4:Ljava/lang/String;

    .line 268435493
    .line 268435494
    iget-object v7, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->paymentMethodLabel:Ljava/lang/String;

    .line 268435495
    .line 268435496
    invoke-virtual {v1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->getPaymentSelection()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutPaymentSelection;

    .line 268435497
    .line 268435498
    .line 268435499
    move-result-object v1

    .line 268435500
    if-eqz v1, :cond_0

    .line 268435501
    .line 268435502
    iget-object v8, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutPaymentSelection;->paymentMethod:Ljava/lang/String;

    .line 268435503
    .line 268435504
    :goto_0
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 268435505
    .line 268435506
    sget-object v1, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutPaymentRowShape:LX/2bC;

    .line 268435507
    .line 268435508
    invoke-static {v2, v1}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 268435509
    .line 268435510
    .line 268435511
    move-result-object v3

    .line 268435512
    invoke-static {v11}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 268435513
    .line 268435514
    .line 268435515
    move-result-object v1

    .line 268435516
    iget-wide v1, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 268435517
    .line 268435518
    const/16 p3, 0x2

    .line 268435519
    .line 268435520
    invoke-static {v3, v1, v2}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 268435521
    .line 268435522
    .line 268435523
    move-result-object v4

    .line 268435524
    invoke-static {v10}, LX/1Y9;->A01(I)LX/1Y9;

    .line 268435525
    .line 268435526
    .line 268435527
    move-result-object v3

    .line 268435528
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onShowDetails:Lkotlin/jvm/functions/Function0;

    .line 268435529
    .line 268435530
    const/4 v1, 0x1

    .line 268435531
    invoke-static {v4, v3, v14, v2, v1}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 268435532
    .line 268435533
    .line 268435534
    move-result-object v1

    .line 268435535
    invoke-static {v1}, LX/2pj;->A03(LX/3C1;)LX/3C1;

    .line 268435536
    .line 268435537
    .line 268435538
    move-result-object v9

    .line 268435539
    const/16 v13, 0x20

    .line 268435540
    .line 268435541
    move v12, v10

    .line 268435542
    invoke-static/range {v5 .. v13}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->CheckoutPaymentRow(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 268435543
    .line 268435544
    .line 268435545
    iget-object v13, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$formattedAmount:Ljava/lang/String;

    .line 268435546
    .line 268435547
    iget-object v15, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$onShowEstimatedTotalInfo:Lkotlin/jvm/functions/Function0;

    .line 268435548
    .line 268435549
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$3;->$totalPromoCaption:Ljava/lang/String;

    .line 268435550
    .line 268435551
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->gatedTotalPromoCaption(Ljava/lang/String;)Ljava/lang/String;

    .line 268435552
    .line 268435553
    .line 268435554
    move-result-object p0

    .line 268435555
    move-object/from16 p1, v11

    .line 268435556
    .line 268435557
    move/from16 p2, v10

    .line 268435558
    .line 268435559
    invoke-static/range {v13 .. v19}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->CheckoutMaxTotal(Ljava/lang/String;LX/3C1;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/2d4;II)V

    .line 268435560
    .line 268435561
    .line 268435562
    return-void

    .line 268435563
    :cond_0
    const/4 v8, 0x0

    .line 268435564
    goto :goto_0

    .line 268435565
    :cond_1
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 268435566
    .line 268435567
    .line 268435568
    return-void
.end method
