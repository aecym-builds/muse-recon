.class public final Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDQ<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;",
        "Ljava/lang/String;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionBannerViewModel$uiState$1"
    f = "AgentPermissionBannerViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic L$1:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/util/List;

    .line 1
    .line 2
    check-cast p2, Ljava/lang/String;

    .line 3
    .line 4
    check-cast p3, LX/2M4;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->invoke(Ljava/util/List;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final invoke(Ljava/util/List;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 268435457
    .line 268435458
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;

    .line 268435459
    .line 268435460
    invoke-direct {p0, v0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->L$1:Ljava/lang/Object;

    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435470
    .line 268435471
    .line 268435472
    move-result-object v0

    .line 268435473
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v3, Ljava/util/List;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->L$1:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v2, Ljava/lang/String;

    .line 7
    .line 8
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->label:I

    .line 9
    .line 10
    if-nez v0, :cond_7

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->screenSessionId:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v0, v2}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->resolveThreadId(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    instance-of v0, v3, Ljava/util/Collection;

    .line 26
    .line 27
    const/4 p0, 0x0

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    :cond_0
    :goto_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    :cond_1
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_4

    .line 49
    .line 50
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    move-object v0, v2

    .line 55
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 56
    .line 57
    invoke-static {v0, p1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepositoryKt;->classifyApprovalPresentation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalPresentation;->NONBLOCKING:Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 62
    .line 63
    if-ne v1, v0, :cond_1

    .line 64
    .line 65
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_2
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_0

    .line 78
    .line 79
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 84
    .line 85
    invoke-static {v0, p1}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepositoryKt;->classifyApprovalPresentation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalPresentation;->BLOCKING:Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 90
    .line 91
    if-ne v1, v0, :cond_3

    .line 92
    .line 93
    const/4 p0, 0x1

    .line 94
    goto :goto_0

    .line 95
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1$invokeSuspend$$inlined$sortedBy$1;

    .line 96
    .line 97
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$uiState$1$invokeSuspend$$inlined$sortedBy$1;-><init>()V

    .line 98
    .line 99
    .line 100
    invoke-static {v4, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    if-nez p0, :cond_5

    .line 105
    .line 106
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->partitionExclusiveApprovals(Ljava/util/List;)Ljava/util/List;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v0}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    check-cast v1, Ljava/util/List;

    .line 115
    .line 116
    if-nez v1, :cond_6

    .line 117
    .line 118
    :cond_5
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 119
    .line 120
    :cond_6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;

    .line 121
    .line 122
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;-><init>(Ljava/util/List;)V

    .line 123
    .line 124
    .line 125
    return-object v0

    .line 126
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    throw v0
.end method
