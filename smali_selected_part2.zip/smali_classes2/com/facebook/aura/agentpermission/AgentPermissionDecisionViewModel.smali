.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _awaitingApproval:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final _submitting:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final approval:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final approvalId:Ljava/lang/String;

.field public final credentialSelections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final repositoryConfirming:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/AHE;Ljava/lang/String;)V
    .locals 10

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v8

    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->Companion:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;

    .line 16
    .line 17
    invoke-virtual {v0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->credentialSelections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 22
    .line 23
    iget-object v0, v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 24
    .line 25
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1;

    .line 26
    .line 27
    invoke-direct {v6, v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V

    .line 28
    .line 29
    .line 30
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    sget-object v7, LX/5Lz;->A00:LX/5Ly;

    .line 35
    .line 36
    invoke-static {v1}, LX/3Rs;->A0g(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;)Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    const/4 v5, 0x0

    .line 45
    if-eqz v0, :cond_4

    .line 46
    .line 47
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    move-object v0, v2

    .line 52
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 53
    .line 54
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 55
    .line 56
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    :goto_0
    invoke-static {v2, v4, v6, v7}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 65
    .line 66
    .line 67
    move-result-object v9

    .line 68
    iput-object v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approval:LX/2J3;

    .line 69
    .line 70
    const/4 v6, 0x0

    .line 71
    invoke-static {v8}, LX/3Rp;->A18(Z)LX/Ddv;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    iput-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_submitting:LX/2J2;

    .line 76
    .line 77
    invoke-virtual {v9}, LX/ERk;->getValue()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-nez v0, :cond_1

    .line 82
    .line 83
    const/4 v8, 0x1

    .line 84
    :cond_1
    invoke-static {v8}, LX/3Rp;->A18(Z)LX/Ddv;

    .line 85
    .line 86
    .line 87
    move-result-object v8

    .line 88
    iput-object v8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_awaitingApproval:LX/2J2;

    .line 89
    .line 90
    invoke-virtual {v8}, LX/Ddv;->getValue()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_2

    .line 99
    .line 100
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$1;

    .line 105
    .line 106
    invoke-direct {v0, p0, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;LX/2M4;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 110
    .line 111
    .line 112
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 113
    .line 114
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->confirmingApprovalIds:LX/2J3;

    .line 115
    .line 116
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$2;

    .line 117
    .line 118
    invoke-direct {v3, v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$2;-><init>(LX/2Lw;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V

    .line 119
    .line 120
    .line 121
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 126
    .line 127
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 128
    .line 129
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->isConfirmingDecision(Ljava/lang/String;)Z

    .line 130
    .line 131
    .line 132
    move-result v0

    .line 133
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    invoke-static {v0, v2, v3, v7}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    iput-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repositoryConfirming:LX/2J3;

    .line 142
    .line 143
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;

    .line 144
    .line 145
    invoke-direct {v0, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;-><init>(LX/2M4;)V

    .line 146
    .line 147
    .line 148
    invoke-static {v0, v9, v4, v8, v1}, LX/EXj;->A01(LX/JDR;LX/2Lw;LX/2Lw;LX/2Lw;LX/2Lw;)LX/5zp;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 153
    .line 154
    .line 155
    move-result-object v4

    .line 156
    invoke-virtual {v9}, LX/ERk;->getValue()Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v3

    .line 160
    check-cast v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 161
    .line 162
    invoke-virtual {v1}, LX/ERk;->getValue()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v2

    .line 170
    invoke-virtual {v9}, LX/ERk;->getValue()Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    if-nez v0, :cond_3

    .line 175
    .line 176
    invoke-virtual {v8}, LX/Ddv;->getValue()Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    move-result v0

    .line 184
    if-eqz v0, :cond_3

    .line 185
    .line 186
    const/4 v6, 0x1

    .line 187
    :cond_3
    invoke-virtual {v1}, LX/ERk;->getValue()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v1

    .line 195
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 196
    .line 197
    invoke-direct {v0, v3, v2, v6, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V

    .line 198
    .line 199
    .line 200
    invoke-static {v0, v4, v5, v7}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->uiState:LX/2J3;

    .line 205
    .line 206
    return-void

    .line 207
    :cond_4
    move-object v2, v5

    .line 208
    goto/16 :goto_0
.end method

.method public static final synthetic access$getApprovalId$p(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getCredentialSelections$p(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->credentialSelections:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_awaitingApproval$p(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_awaitingApproval:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_submitting$p(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_submitting:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static synthetic submit$default(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Ljava/lang/Long;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p4, p3}, LX/3Rr;->A0f(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->submit(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Ljava/lang/Long;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final submit(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Ljava/lang/Long;Ljava/lang/String;)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v5, p0

    .line 5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_submitting:LX/2J2;

    .line 6
    .line 7
    invoke-static {v0}, LX/3Rq;->A1V(LX/2J2;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v7, 0x0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    sget-object v3, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 17
    .line 18
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->ALREADY_SUBMITTING:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approval:LX/2J3;

    .line 21
    .line 22
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 27
    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 31
    .line 32
    :cond_0
    invoke-virtual {v3, v2, v1, v7}, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->logSkipped(Ljava/lang/String;Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;Lcom/facebook/aura/gateway/ApprovalOrigin;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approval:LX/2J3;

    .line 37
    .line 38
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v6

    .line 42
    check-cast v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 43
    .line 44
    if-nez v6, :cond_2

    .line 45
    .line 46
    sget-object v3, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 47
    .line 48
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 49
    .line 50
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->NOT_PENDING:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    :goto_0
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->logSkipped(Ljava/lang/String;Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;Lcom/facebook/aura/gateway/ApprovalOrigin;)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v1, v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->isConfirmingDecision(Ljava/lang/String;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_3

    .line 66
    .line 67
    sget-object v3, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 68
    .line 69
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 70
    .line 71
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->AWAITING_SNAPSHOT:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 72
    .line 73
    iget-object v0, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 74
    .line 75
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->logSkipped(Ljava/lang/String;Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;Lcom/facebook/aura/gateway/ApprovalOrigin;)V

    .line 76
    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 79
    .line 80
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->requestDecisionConfirmation()V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_3
    iget-object v0, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 85
    .line 86
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 87
    .line 88
    .line 89
    move-result-object v4

    .line 90
    :cond_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_5

    .line 95
    .line 96
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    move-object v2, v3

    .line 101
    check-cast v2, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 102
    .line 103
    iget-object v1, v2, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 104
    .line 105
    iget-object v0, p1, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 106
    .line 107
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_4

    .line 112
    .line 113
    iget-object v1, v2, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->alwaysScope:Ljava/lang/String;

    .line 114
    .line 115
    iget-object v0, p1, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->alwaysScope:Ljava/lang/String;

    .line 116
    .line 117
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    if-eqz v0, :cond_4

    .line 122
    .line 123
    move-object v7, v3

    .line 124
    :cond_5
    check-cast v7, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 125
    .line 126
    if-nez v7, :cond_6

    .line 127
    .line 128
    sget-object v3, Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalDecisionAnalytics;

    .line 129
    .line 130
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 131
    .line 132
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;->OPTION_UNAVAILABLE:Lcom/facebook/aura/gateway/ApprovalDecisionSkipReason;

    .line 133
    .line 134
    iget-object v0, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->origin:Lcom/facebook/aura/gateway/ApprovalOrigin;

    .line 135
    .line 136
    goto :goto_0

    .line 137
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->_submitting:LX/2J2;

    .line 138
    .line 139
    invoke-static {v0}, LX/3Rs;->A1L(LX/2J2;)V

    .line 140
    .line 141
    .line 142
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    const/4 p1, 0x0

    .line 147
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$submit$1;

    .line 148
    .line 149
    move-object v8, p2

    .line 150
    move-object p0, p3

    .line 151
    invoke-direct/range {v4 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$submit$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Ljava/lang/Long;Ljava/lang/String;LX/2M4;)V

    .line 152
    .line 153
    .line 154
    invoke-static {v4, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 155
    .line 156
    .line 157
    return-void
.end method
