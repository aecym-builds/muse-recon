.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $confirming:Z

.field public final synthetic $decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

.field public final synthetic $onDecision:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onReview:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $submitting:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$submitting:Z

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$onDecision:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$onReview:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-boolean p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$confirming:Z

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 26

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    and-int/lit8 v0, p2, 0x3

    .line 3
    .line 4
    const/4 v5, 0x2

    .line 5
    invoke-static {v0, v5}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object/from16 v6, p1

    .line 10
    .line 11
    invoke-static {v0, v6, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_3

    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    sget-object v9, LX/2sI;->A02:LX/2wD;

    .line 19
    .line 20
    const/high16 v0, 0x41200000    # 10.0f

    .line 21
    .line 22
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    move-object/from16 v0, p0

    .line 27
    .line 28
    iget-object v14, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 29
    .line 30
    iget-object v15, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$decisions:Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;

    .line 31
    .line 32
    iget-boolean v7, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$submitting:Z

    .line 33
    .line 34
    iget-object v13, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$onDecision:LX/JDM;

    .line 35
    .line 36
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$onReview:Lkotlin/jvm/functions/Function0;

    .line 37
    .line 38
    iget-boolean v3, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ExpandedApprovalRow$1;->$confirming:Z

    .line 39
    .line 40
    sget-object v1, LX/2Id;->A02:LX/2sS;

    .line 41
    .line 42
    const/4 v0, 0x6

    .line 43
    invoke-static {v2, v6, v1, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 44
    .line 45
    .line 46
    move-result-object v10

    .line 47
    move-object v2, v6

    .line 48
    check-cast v2, LX/J7I;

    .line 49
    .line 50
    iget-wide v0, v2, LX/J7I;->A06:J

    .line 51
    .line 52
    const/16 v22, 0x20

    .line 53
    .line 54
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 55
    .line 56
    .line 57
    move-result v12

    .line 58
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 59
    .line 60
    .line 61
    move-result-object v11

    .line 62
    invoke-static {v6, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v9

    .line 66
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 67
    .line 68
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 69
    .line 70
    if-nez v0, :cond_0

    .line 71
    .line 72
    invoke-static {}, LX/1VY;->A00()V

    .line 73
    .line 74
    .line 75
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    throw v0

    .line 80
    :cond_0
    invoke-static {v6, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 81
    .line 82
    .line 83
    invoke-static {v6, v10, v11, v9, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 84
    .line 85
    .line 86
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 87
    .line 88
    invoke-static {v6, v0}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 89
    .line 90
    .line 91
    move-result-object v9

    .line 92
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 93
    .line 94
    const/4 v0, 0x0

    .line 95
    invoke-static {v14, v9, v6, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PermissionCaption(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2hg;LX/2d4;II)V

    .line 96
    .line 97
    .line 98
    sget-object v24, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 99
    .line 100
    or-int/lit8 p1, v1, 0x30

    .line 101
    .line 102
    const/16 p2, 0x4

    .line 103
    .line 104
    move-object/from16 v23, v14

    .line 105
    .line 106
    move-object/from16 v25, v4

    .line 107
    .line 108
    move-object/from16 p0, v6

    .line 109
    .line 110
    invoke-static/range {v23 .. v28}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionPurposeCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 111
    .line 112
    .line 113
    if-eqz v15, :cond_2

    .line 114
    .line 115
    const v9, 0x2ce749bb

    .line 116
    .line 117
    .line 118
    invoke-interface {v6, v9}, LX/2d4;->Agj(I)V

    .line 119
    .line 120
    .line 121
    xor-int/lit8 v16, v7, 0x1

    .line 122
    .line 123
    sget v7, Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;->$stable:I

    .line 124
    .line 125
    shl-int/lit8 v7, v7, 0x3

    .line 126
    .line 127
    or-int v21, v1, v7

    .line 128
    .line 129
    move-object/from16 v20, v6

    .line 130
    .line 131
    move-object/from16 v19, v4

    .line 132
    .line 133
    move-object/from16 v18, v8

    .line 134
    .line 135
    move-object/from16 v17, v13

    .line 136
    .line 137
    invoke-static/range {v14 .. v22}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->ApprovalDecisionButtons(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalRowDecisions;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 138
    .line 139
    .line 140
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 141
    .line 142
    .line 143
    :goto_0
    if-eqz v3, :cond_1

    .line 144
    .line 145
    const v3, 0x2ceb8e7b

    .line 146
    .line 147
    .line 148
    invoke-interface {v6, v3}, LX/2d4;->Agj(I)V

    .line 149
    .line 150
    .line 151
    invoke-static/range {v23 .. v28}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionConfirmingStatus(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 152
    .line 153
    .line 154
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 155
    .line 156
    .line 157
    :goto_1
    invoke-static {v14, v4, v6, v1, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionFooter(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V

    .line 158
    .line 159
    .line 160
    const/4 v0, 0x1

    .line 161
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 162
    .line 163
    .line 164
    return-void

    .line 165
    :cond_1
    const v3, 0x2cee62fc

    .line 166
    .line 167
    .line 168
    invoke-interface {v6, v3}, LX/2d4;->Agj(I)V

    .line 169
    .line 170
    .line 171
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 172
    .line 173
    .line 174
    goto :goto_1

    .line 175
    :cond_2
    const v7, 0x2ceb0e7c

    .line 176
    .line 177
    .line 178
    invoke-interface {v6, v7}, LX/2d4;->Agj(I)V

    .line 179
    .line 180
    .line 181
    invoke-static {v2, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 182
    .line 183
    .line 184
    goto :goto_0

    .line 185
    :cond_3
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 186
    .line 187
    .line 188
    return-void
.end method
