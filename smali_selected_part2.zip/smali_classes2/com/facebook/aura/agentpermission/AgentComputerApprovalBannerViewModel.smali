.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final approval:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 12
    .line 13
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 14
    .line 15
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1;

    .line 16
    .line 17
    invoke-direct {v3, v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1;-><init>(LX/2Lw;)V

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    sget-object v1, LX/5Lz;->A00:LX/5Ly;

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    invoke-static {v0, v2, v3, v1}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;->approval:LX/2J3;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final getApproval()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel;->approval:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method
