.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $buttonPadding:LX/2or;

.field public final synthetic $buttonSpacing:F

.field public final synthetic $confirming:Z

.field public final synthetic $enabled:Z

.field public final synthetic $horizontalPadding:F

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onDecisionClick:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZII)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "FZ",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "F",
            "LX/2or;",
            "ZII)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$horizontalPadding:F

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$enabled:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$onDecisionClick:LX/JDN;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$modifier:LX/3C1;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$buttonSpacing:F

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$buttonPadding:LX/2or;

    .line 15
    .line 16
    iput-boolean p9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$confirming:Z

    .line 17
    .line 18
    iput p10, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$$changed:I

    .line 19
    .line 20
    iput p11, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$$default:I

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 12

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    iget v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$horizontalPadding:F

    .line 5
    .line 6
    iget-boolean v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$enabled:Z

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$onDecisionClick:LX/JDN;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$modifier:LX/3C1;

    .line 11
    .line 12
    iget v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$buttonSpacing:F

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$buttonPadding:LX/2or;

    .line 15
    .line 16
    iget-boolean v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$confirming:Z

    .line 17
    .line 18
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$$changed:I

    .line 19
    .line 20
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 21
    .line 22
    .line 23
    move-result v11

    .line 24
    iget p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionApprovalContent$2;->$$default:I

    .line 25
    .line 26
    move-object v10, p1

    .line 27
    invoke-static/range {v1 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionApprovalContent-7UH0Qls(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;FZLX/JDN;LX/3C1;FLX/2or;ZLX/2d4;II)V

    .line 28
    .line 29
    .line 30
    return-void
.end method
