.class public final Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 5

    .line 268435456
    and-int/lit8 v1, p3, 0x11

    .line 268435457
    .line 268435458
    const/16 v0, 0x10

    .line 268435459
    .line 268435460
    const/4 v4, 0x1

    .line 268435461
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435466
    .line 268435467
    .line 268435468
    move-result v0

    .line 268435469
    if-eqz v0, :cond_1

    .line 268435470
    .line 268435471
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 268435472
    .line 268435473
    new-instance v1, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;

    .line 268435474
    .line 268435475
    invoke-direct {v1, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;)V

    .line 268435476
    .line 268435477
    .line 268435478
    const v0, 0xaf87ffc

    .line 268435479
    .line 268435480
    .line 268435481
    invoke-static {p2, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435482
    .line 268435483
    .line 268435484
    move-result-object v0

    .line 268435485
    const/4 v3, 0x0

    .line 268435486
    const/16 v2, 0x30

    .line 268435487
    .line 268435488
    invoke-static {v3, v0, p2, v2, v4}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationSection(LX/3C1;LX/JDN;LX/2d4;II)V

    .line 268435489
    .line 268435490
    .line 268435491
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 268435492
    .line 268435493
    iget-boolean v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->isPostpaid:Z

    .line 268435494
    .line 268435495
    if-eqz v0, :cond_0

    .line 268435496
    .line 268435497
    const v0, -0x2c0f026f

    .line 268435498
    .line 268435499
    .line 268435500
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435501
    .line 268435502
    .line 268435503
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 268435504
    .line 268435505
    new-instance v1, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$2;

    .line 268435506
    .line 268435507
    invoke-direct {v1, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;)V

    .line 268435508
    .line 268435509
    .line 268435510
    const v0, 0x20157b81

    .line 268435511
    .line 268435512
    .line 268435513
    invoke-static {p2, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 268435514
    .line 268435515
    .line 268435516
    move-result-object v0

    .line 268435517
    invoke-static {v3, v0, p2, v2, v4}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationSection(LX/3C1;LX/JDN;LX/2d4;II)V

    .line 268435518
    .line 268435519
    .line 268435520
    :goto_0
    invoke-static {p2}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 268435521
    .line 268435522
    .line 268435523
    return-void

    .line 268435524
    :cond_0
    const v0, -0x2c099cff

    .line 268435525
    .line 268435526
    .line 268435527
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 268435528
    .line 268435529
    .line 268435530
    goto :goto_0

    .line 268435531
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435532
    .line 268435533
    .line 268435534
    return-void
.end method
