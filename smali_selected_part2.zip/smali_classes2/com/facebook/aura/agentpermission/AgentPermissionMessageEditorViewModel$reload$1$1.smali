.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$reload$1$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {
        0x83,
        0x84
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;

    .line 3
    .line 4
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    if-eq v0, v1, :cond_4

    .line 9
    .line 10
    if-ne v0, v2, :cond_6

    .line 11
    .line 12
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :cond_0
    invoke-static {p0}, LX/3Rp;->A1O(LX/Btl;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$checkOwner(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 28
    .line 29
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-nez v0, :cond_2

    .line 34
    .line 35
    check-cast v2, Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 36
    .line 37
    invoke-static {v1, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$applyEditor(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/gateway/EditableMessageEditor;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    :goto_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 41
    .line 42
    return-object v3

    .line 43
    :cond_2
    invoke-static {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$handleLoadFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 51
    .line 52
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 53
    .line 54
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->hasLoadedServerApprovals:LX/2J3;

    .line 55
    .line 56
    invoke-static {v0}, LX/3Rq;->A1W(LX/2J3;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-nez v0, :cond_5

    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 63
    .line 64
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 65
    .line 66
    iput v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->label:I

    .line 67
    .line 68
    invoke-virtual {v0, p0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->refreshApprovals(LX/2M4;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    if-ne v0, v3, :cond_5

    .line 73
    .line 74
    return-object v3

    .line 75
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 79
    .line 80
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 81
    .line 82
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->approvalId:Ljava/lang/String;

    .line 83
    .line 84
    iput v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$reload$1$1;->label:I

    .line 85
    .line 86
    invoke-virtual {v1, v0, p0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->fetchEditableMessage-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    if-ne v2, v3, :cond_0

    .line 91
    .line 92
    return-object v3

    .line 93
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    throw v0
.end method
