.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDR;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDR<",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        "Ljava/lang/Boolean;",
        "Ljava/lang/Boolean;",
        "Ljava/lang/Boolean;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionDecisionViewModel$uiState$1"
    f = "AgentPermissionDecisionViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic Z$0:Z

.field public synthetic Z$1:Z

.field public synthetic Z$2:Z

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x5

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZLX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "ZZZ",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;

    .line 268435457
    .line 268435458
    invoke-direct {p0, p5}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 268435462
    .line 268435463
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$0:Z

    .line 268435464
    .line 268435465
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$1:Z

    .line 268435466
    .line 268435467
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$2:Z

    .line 268435468
    .line 268435469
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435470
    .line 268435471
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435472
    .line 268435473
    .line 268435474
    move-result-object v0

    .line 268435475
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p2

    .line 6
    invoke-static {p3}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result p3

    .line 10
    invoke-static {p4}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p4

    .line 14
    check-cast p5, LX/2M4;

    .line 15
    .line 16
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZLX/2M4;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iget-boolean v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$0:Z

    .line 5
    .line 6
    iget-boolean v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$1:Z

    .line 7
    .line 8
    iget-boolean v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->Z$2:Z

    .line 9
    .line 10
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$uiState$1;->label:I

    .line 11
    .line 12
    if-nez v0, :cond_5

    .line 13
    .line 14
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    if-nez v6, :cond_0

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    if-eqz v4, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 v2, 0x1

    .line 24
    :cond_1
    if-nez v7, :cond_2

    .line 25
    .line 26
    const/4 v1, 0x1

    .line 27
    if-nez v5, :cond_3

    .line 28
    .line 29
    :cond_2
    const/4 v1, 0x0

    .line 30
    :cond_3
    if-eqz v4, :cond_4

    .line 31
    .line 32
    if-nez v6, :cond_4

    .line 33
    .line 34
    const/4 v3, 0x1

    .line 35
    :cond_4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 36
    .line 37
    invoke-direct {v0, v7, v2, v1, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V

    .line 38
    .line 39
    .line 40
    return-object v0

    .line 41
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0
.end method
