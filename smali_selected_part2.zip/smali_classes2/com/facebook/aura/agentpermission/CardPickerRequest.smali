.class public final Lcom/facebook/aura/agentpermission/CardPickerRequest;
.super LX/07H;
.source ""


# instance fields
.field public final paymentMethod:Ljava/lang/String;

.field public final requestedAtMs:J


# direct methods
.method public constructor <init>(Ljava/lang/String;J)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 8
    .line 9
    iput-wide p2, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 10
    .line 11
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/CardPickerRequest;Ljava/lang/String;JILjava/lang/Object;)Lcom/facebook/aura/agentpermission/CardPickerRequest;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-wide p2, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/agentpermission/CardPickerRequest;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/CardPickerRequest;-><init>(Ljava/lang/String;J)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final copy(Ljava/lang/String;J)Lcom/facebook/aura/agentpermission/CardPickerRequest;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/CardPickerRequest;-><init>(Ljava/lang/String;J)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/CardPickerRequest;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/CardPickerRequest;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-wide v3, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 21
    .line 22
    iget-wide v1, p1, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 23
    .line 24
    cmp-long v0, v3, v1

    .line 25
    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    :cond_0
    return v5

    .line 29
    :cond_1
    return v6
.end method

.method public final getPaymentMethod()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRequestedAtMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->paymentMethod:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v2

    .line 6
    iget-wide v0, p0, Lcom/facebook/aura/agentpermission/CardPickerRequest;->requestedAtMs:J

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/002;->A0H(J)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v2, v0

    .line 13
    return v2
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
