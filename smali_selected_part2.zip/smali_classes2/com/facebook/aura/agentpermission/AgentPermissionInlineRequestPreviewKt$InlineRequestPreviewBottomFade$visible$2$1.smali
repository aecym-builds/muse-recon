.class public final Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $scrollState:LX/3Lr;


# direct methods
.method public constructor <init>(LX/3Lr;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;->$scrollState:LX/3Lr;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;->$scrollState:LX/3Lr;

    .line 1
    .line 2
    invoke-virtual {p0}, LX/3Lr;->ADX()Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionInlineRequestPreviewKt$InlineRequestPreviewBottomFade$visible$2$1;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
