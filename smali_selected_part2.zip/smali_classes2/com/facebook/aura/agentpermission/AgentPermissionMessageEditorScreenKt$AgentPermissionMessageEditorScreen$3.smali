.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $state$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->$state$delegate:LX/16A;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 14

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    and-int/lit8 v0, p2, 0x3

    .line 3
    .line 4
    const/4 v11, 0x0

    .line 5
    invoke-static {v0}, LX/004;->A1P(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object v13, p1

    .line 10
    invoke-static {v0, p1, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_5

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->$state$delegate:LX/16A;

    .line 17
    .line 18
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 23
    .line 24
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    const v0, 0x63db37c4

    .line 29
    .line 30
    .line 31
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 32
    .line 33
    .line 34
    const v0, 0x7f120117

    .line 35
    .line 36
    .line 37
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 42
    .line 43
    const/high16 v0, 0x42400000    # 48.0f

    .line 44
    .line 45
    invoke-static {v1, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v0, v11}, LX/001;->A0b(LX/3C1;Z)LX/3C1;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-interface {p1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-nez v1, :cond_0

    .line 62
    .line 63
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v0, v1, :cond_1

    .line 66
    .line 67
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3$1$1;

    .line 68
    .line 69
    invoke-direct {v0, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3$1$1;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_1
    check-cast v0, LX/JDM;

    .line 76
    .line 77
    invoke-static {p1, v2, v0}, LX/009;->A0x(LX/2d4;LX/3C1;LX/JDM;)V

    .line 78
    .line 79
    .line 80
    :goto_0
    invoke-static {v13}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_2
    const v0, 0x63e0b12f

    .line 85
    .line 86
    .line 87
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 88
    .line 89
    .line 90
    const v0, 0x7f0800e6

    .line 91
    .line 92
    .line 93
    invoke-static {p1, v0, v11}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    const v0, 0x7f120178

    .line 98
    .line 99
    .line 100
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 105
    .line 106
    invoke-interface {p1, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    if-nez v0, :cond_3

    .line 115
    .line 116
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 117
    .line 118
    if-ne v4, v0, :cond_4

    .line 119
    .line 120
    :cond_3
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3$2$1;

    .line 121
    .line 122
    invoke-direct {v4, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3$2$1;-><init>(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-interface {p1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :cond_4
    check-cast v4, LX/DqV;

    .line 129
    .line 130
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 131
    .line 132
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;->$state$delegate:LX/16A;

    .line 133
    .line 134
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 139
    .line 140
    invoke-virtual {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->getCanSave()Z

    .line 141
    .line 142
    .line 143
    move-result v6

    .line 144
    sget p0, LX/2l9;->$stable:I

    .line 145
    .line 146
    const/16 p2, 0x7e8

    .line 147
    .line 148
    const/4 v5, 0x0

    .line 149
    const/4 v7, 0x0

    .line 150
    move-object v8, v5

    .line 151
    move-object v9, v5

    .line 152
    move-object v10, v5

    .line 153
    move v12, v11

    .line 154
    move p1, v11

    .line 155
    invoke-static/range {v2 .. v16}, Lcom/facebook/aura/vds/compose/button/AuraElevatedButtonKt;->AuraElevatedIconButton-Xjqr6CI(LX/2l9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZFLcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;LX/3C1;ZZLX/2d4;III)V

    .line 156
    .line 157
    .line 158
    goto :goto_0

    .line 159
    :cond_5
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 160
    .line 161
    .line 162
    return-void
.end method
