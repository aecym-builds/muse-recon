.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
        "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $subject:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;->$subject:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 8

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;->$subject:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 8
    .line 9
    iget-object v4, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v5, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 12
    .line 13
    iget-boolean v6, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 14
    .line 15
    iget-boolean v7, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 16
    .line 17
    iget-boolean p0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 18
    .line 19
    iget-boolean p1, p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 20
    .line 21
    invoke-virtual/range {v1 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$updateSubject$1;->invoke(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
