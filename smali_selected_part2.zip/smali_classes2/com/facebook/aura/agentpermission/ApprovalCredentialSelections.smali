.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;


# instance fields
.field public final _choices:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;",
            ">;>;"
        }
    .end annotation
.end field

.field public final choices:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;",
            ">;>;"
        }
    .end annotation
.end field

.field public final nextLoadId:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final scope:LX/1EL;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->Companion:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    invoke-static {p1}, LX/3Rp;->A05(LX/AHE;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 8
    .line 9
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, LX/3Rq;->A1I(LX/BqD;)LX/EQC;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->scope:LX/1EL;

    .line 18
    .line 19
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->nextLoadId:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 25
    .line 26
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v0}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 35
    .line 36
    invoke-static {v0}, LX/3Rp;->A15(LX/2J3;)LX/ERk;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->choices:LX/2J3;

    .line 41
    .line 42
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;-><init>(LX/AHE;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;)Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_choices$p(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method


# virtual methods
.method public clearUserData()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->scope:LX/1EL;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-static {v0, v1}, LX/EPV;->A02(Ljava/util/concurrent/CancellationException;LX/1EL;)V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 7
    .line 8
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final enter(Ljava/lang/String;Ljava/lang/String;)V
    .locals 12

    .line 0
    move-object v8, p2

    .line 1
    invoke-static {p1, p2}, LX/004;->A1b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v10

    .line 5
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 6
    .line 7
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/Map;

    .line 12
    .line 13
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 20
    .line 21
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    move-object v1, v2

    .line 26
    check-cast v1, Ljava/util/Map;

    .line 27
    .line 28
    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 37
    .line 38
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 41
    .line 42
    iget v11, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 43
    .line 44
    invoke-static {v5, v7}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    new-instance v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 48
    .line 49
    move-object v9, p2

    .line 50
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1, v4, v1}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    :cond_1
    invoke-interface {v3, v2, v1}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->load$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    :cond_2
    return-void
.end method

.method public final getChoices$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;",
            ">;>;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->choices:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final load$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V
    .locals 19

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object/from16 v4, p1

    .line 2
    .line 3
    invoke-static {v4, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v5, p0

    .line 7
    .line 8
    iget-object v0, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->nextLoadId:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    iget-object v6, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 15
    .line 16
    :cond_0
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v8

    .line 20
    move-object v9, v8

    .line 21
    check-cast v9, Ljava/util/Map;

    .line 22
    .line 23
    invoke-interface {v9, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v13

    .line 27
    check-cast v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 28
    .line 29
    if-nez v13, :cond_1

    .line 30
    .line 31
    const/4 v15, 0x0

    .line 32
    sget-object v14, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 33
    .line 34
    sget-object v16, LX/0wV;->A00:LX/0wV;

    .line 35
    .line 36
    new-instance v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 37
    .line 38
    move-object/from16 v17, v15

    .line 39
    .line 40
    move-object/from16 v18, v15

    .line 41
    .line 42
    move/from16 p1, v7

    .line 43
    .line 44
    move/from16 p0, v7

    .line 45
    .line 46
    invoke-direct/range {v13 .. v20}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 47
    .line 48
    .line 49
    :cond_1
    sget-object v14, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 50
    .line 51
    const/4 v2, 0x0

    .line 52
    iget-object v12, v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v11, v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 55
    .line 56
    iget-object v10, v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v1, v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 59
    .line 60
    iget-boolean v0, v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 61
    .line 62
    invoke-static {v14, v11}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    new-instance v13, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 66
    .line 67
    move-object/from16 v18, v1

    .line 68
    .line 69
    move/from16 p0, v0

    .line 70
    .line 71
    move/from16 p1, v3

    .line 72
    .line 73
    move-object v15, v12

    .line 74
    move-object/from16 v16, v11

    .line 75
    .line 76
    move-object/from16 v17, v10

    .line 77
    .line 78
    invoke-direct/range {v13 .. v20}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 79
    .line 80
    .line 81
    invoke-static {v4, v13, v9}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-interface {v6, v8, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_0

    .line 90
    .line 91
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->scope:LX/1EL;

    .line 92
    .line 93
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;

    .line 94
    .line 95
    invoke-direct {v0, v5, v4, v3, v2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$load$2;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;Ljava/lang/String;ILX/2M4;)V

    .line 96
    .line 97
    .line 98
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 99
    .line 100
    .line 101
    return-void
.end method

.method public final loadIfNeeded$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/util/Map;

    .line 11
    .line 12
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->load$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void
.end method

.method public final onDecided$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;ZLjava/lang/String;)V
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/util/Map;

    .line 11
    .line 12
    if-eqz p2, :cond_3

    .line 13
    .line 14
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    iget-object v3, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 24
    .line 25
    :goto_0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 26
    .line 27
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    move-object v0, v1

    .line 32
    check-cast v0, Ljava/util/Map;

    .line 33
    .line 34
    invoke-static {p1, v0}, LX/1HA;->A0C(Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    if-eqz v3, :cond_1

    .line 45
    .line 46
    invoke-virtual {v3, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->scope:LX/1EL;

    .line 53
    .line 54
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$onDecided$2;

    .line 55
    .line 56
    invoke-direct {v0, p0, p1, v3, v4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$onDecided$2;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;Ljava/lang/String;Ljava/lang/String;LX/2M4;)V

    .line 57
    .line 58
    .line 59
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 60
    .line 61
    .line 62
    :cond_1
    return-void

    .line 63
    :cond_2
    move-object v3, v4

    .line 64
    goto :goto_0

    .line 65
    :cond_3
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->load$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method public final select$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    .line 0
    move-object v8, p2

    .line 1
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v10

    .line 5
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 6
    .line 7
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    move-object v1, v2

    .line 12
    check-cast v1, Ljava/util/Map;

    .line 13
    .line 14
    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 23
    .line 24
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v7, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 27
    .line 28
    iget-object v9, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 29
    .line 30
    iget p0, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 31
    .line 32
    invoke-static {v5, v7}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    new-instance v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 36
    .line 37
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 38
    .line 39
    .line 40
    invoke-static {p1, v4, v1}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    :cond_1
    invoke-interface {v3, v2, v1}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    return-void
.end method

.method public final takeEnteredLoginAllow$fbandroid_express_aura_java_com_facebook_aura_agentpermission_agentpermission(Ljava/lang/String;Ljava/util/Set;)Ljava/lang/String;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    move-object/from16 v3, p2

    .line 3
    .line 4
    invoke-static {v4, v3}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->_choices:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    move-object v1, v2

    .line 15
    check-cast v1, Ljava/util/Map;

    .line 16
    .line 17
    invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v6

    .line 21
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 22
    .line 23
    const/4 v9, 0x0

    .line 24
    if-eqz v6, :cond_1

    .line 25
    .line 26
    iget-object v8, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 27
    .line 28
    iget-boolean v0, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    if-eqz v8, :cond_1

    .line 33
    .line 34
    iget-object v7, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 37
    .line 38
    if-eq v7, v0, :cond_1

    .line 39
    .line 40
    invoke-virtual {v6, v3}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->selection(Ljava/util/Set;)Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-eqz v0, :cond_2

    .line 45
    .line 46
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;->credentialId:Ljava/lang/String;

    .line 47
    .line 48
    :goto_0
    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_1

    .line 53
    .line 54
    move-object v9, v8

    .line 55
    iget-object v11, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 56
    .line 57
    iget-object v12, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v13, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 60
    .line 61
    iget-object v14, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 62
    .line 63
    iget-object p0, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 64
    .line 65
    iget v0, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 66
    .line 67
    invoke-static {v11, v13}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    new-instance v10, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 71
    .line 72
    move/from16 p2, v0

    .line 73
    .line 74
    invoke-direct/range {v10 .. v17}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 75
    .line 76
    .line 77
    invoke-static {v4, v10, v1}, LX/3Rs;->A0n(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;)Ljava/util/Map;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    :cond_1
    invoke-interface {v5, v2, v1}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_0

    .line 86
    .line 87
    return-object v9

    .line 88
    :cond_2
    move-object v0, v9

    .line 89
    goto :goto_0
.end method
