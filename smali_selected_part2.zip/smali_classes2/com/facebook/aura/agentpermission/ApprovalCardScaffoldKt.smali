.class public abstract Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ApprovalCardScaffold(Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/JDQ;LX/3C1;Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;LX/JDQ;ZLX/JDN;LX/JDQ;LX/2d4;II)V
    .locals 26
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;",
            "Lcom/facebook/aura/agentpermission/RichApprovalSurface;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;Z",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v19, p3

    .line 1
    .line 2
    move-object/from16 v25, p4

    .line 3
    .line 4
    move-object/from16 v18, p5

    .line 5
    .line 6
    move/from16 v17, p6

    .line 7
    .line 8
    move-object/from16 v15, p7

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    move-object/from16 v21, p0

    .line 12
    .line 13
    move-object/from16 v6, p1

    .line 14
    .line 15
    move-object/from16 v23, p2

    .line 16
    .line 17
    move-object/from16 v1, v21

    .line 18
    .line 19
    move-object/from16 v0, v23

    .line 20
    .line 21
    invoke-static {v1, v6, v0}, LX/3Rs;->A1R(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v9

    .line 25
    const/16 v16, 0x8

    .line 26
    .line 27
    move-object/from16 v14, p8

    .line 28
    .line 29
    move/from16 v0, v16

    .line 30
    .line 31
    invoke-static {v14, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 32
    .line 33
    .line 34
    const v0, -0x6d851519

    .line 35
    .line 36
    .line 37
    move-object/from16 v5, p9

    .line 38
    .line 39
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 40
    .line 41
    .line 42
    move/from16 v4, p10

    .line 43
    .line 44
    and-int/lit8 v0, p10, 0x6

    .line 45
    .line 46
    if-nez v0, :cond_12

    .line 47
    .line 48
    invoke-static {v1, v5, v4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    invoke-static {v0}, LX/003;->A06(I)I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    or-int v1, v1, p10

    .line 57
    .line 58
    :goto_0
    and-int/lit8 v0, p10, 0x30

    .line 59
    .line 60
    if-nez v0, :cond_0

    .line 61
    .line 62
    invoke-static {v6, v5, v4}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    invoke-static {v0}, LX/003;->A07(I)I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    or-int/2addr v1, v0

    .line 71
    :cond_0
    and-int/lit16 v0, v4, 0x180

    .line 72
    .line 73
    if-nez v0, :cond_1

    .line 74
    .line 75
    move-object/from16 v0, v23

    .line 76
    .line 77
    invoke-static {v5, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    or-int/2addr v1, v0

    .line 82
    :cond_1
    move/from16 v3, p11

    .line 83
    .line 84
    and-int/lit8 v13, p11, 0x8

    .line 85
    .line 86
    if-eqz v13, :cond_11

    .line 87
    .line 88
    or-int/lit16 v1, v1, 0xc00

    .line 89
    .line 90
    :cond_2
    :goto_1
    and-int/lit8 v12, p11, 0x10

    .line 91
    .line 92
    if-eqz v12, :cond_10

    .line 93
    .line 94
    or-int/lit16 v1, v1, 0x6000

    .line 95
    .line 96
    :cond_3
    :goto_2
    and-int/lit8 v11, p11, 0x20

    .line 97
    .line 98
    const/high16 v0, 0x30000

    .line 99
    .line 100
    if-nez v11, :cond_4

    .line 101
    .line 102
    and-int v0, v0, p10

    .line 103
    .line 104
    if-nez v0, :cond_5

    .line 105
    .line 106
    move-object/from16 v0, v18

    .line 107
    .line 108
    invoke-static {v5, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    :cond_4
    or-int/2addr v1, v0

    .line 113
    :cond_5
    and-int/lit8 v7, p11, 0x40

    .line 114
    .line 115
    const/high16 v0, 0x180000

    .line 116
    .line 117
    if-nez v7, :cond_6

    .line 118
    .line 119
    and-int v0, p10, v0

    .line 120
    .line 121
    if-nez v0, :cond_7

    .line 122
    .line 123
    move/from16 v0, v17

    .line 124
    .line 125
    invoke-static {v5, v0}, LX/004;->A0o(LX/2d4;Z)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    :cond_6
    or-int/2addr v1, v0

    .line 130
    :cond_7
    and-int/lit16 v8, v3, 0x80

    .line 131
    .line 132
    const/high16 v0, 0xc00000

    .line 133
    .line 134
    if-nez v8, :cond_8

    .line 135
    .line 136
    and-int v0, p10, v0

    .line 137
    .line 138
    if-nez v0, :cond_9

    .line 139
    .line 140
    invoke-static {v5, v15}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    :cond_8
    or-int/2addr v1, v0

    .line 145
    :cond_9
    const/high16 v0, 0x6000000

    .line 146
    .line 147
    and-int v0, p10, v0

    .line 148
    .line 149
    if-nez v0, :cond_a

    .line 150
    .line 151
    invoke-static {v5, v14}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    or-int/2addr v1, v0

    .line 156
    :cond_a
    const v0, 0x2492493

    .line 157
    .line 158
    .line 159
    and-int v10, v1, v0

    .line 160
    .line 161
    const v0, 0x2492492

    .line 162
    .line 163
    .line 164
    invoke-static {v10, v0}, LX/003;->A1H(II)Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    invoke-static {v0, v5, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    if-eqz v0, :cond_1c

    .line 173
    .line 174
    if-eqz v13, :cond_b

    .line 175
    .line 176
    sget-object v19, LX/3C1;->A00:LX/3Cb;

    .line 177
    .line 178
    :cond_b
    if-eqz v12, :cond_c

    .line 179
    .line 180
    sget-object v25, Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;->CHECKOUT:Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;

    .line 181
    .line 182
    :cond_c
    const/16 p3, 0x0

    .line 183
    .line 184
    if-eqz v11, :cond_d

    .line 185
    .line 186
    move-object/from16 v18, p3

    .line 187
    .line 188
    :cond_d
    move/from16 v0, v17

    .line 189
    .line 190
    invoke-static {v7, v0}, LX/001;->A1Q(IZ)Z

    .line 191
    .line 192
    .line 193
    move-result v17

    .line 194
    if-eqz v8, :cond_e

    .line 195
    .line 196
    move-object/from16 v15, p3

    .line 197
    .line 198
    :cond_e
    invoke-static/range {v19 .. v19}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 199
    .line 200
    .line 201
    move-result-object v11

    .line 202
    iget-boolean v0, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->showCardBackground:Z

    .line 203
    .line 204
    const/4 v12, 0x6

    .line 205
    if-eqz v0, :cond_f

    .line 206
    .line 207
    const v0, -0x2093e1dd

    .line 208
    .line 209
    .line 210
    invoke-static {v5, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 211
    .line 212
    .line 213
    move-result-object v10

    .line 214
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 215
    .line 216
    invoke-virtual {v0, v5, v12}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 217
    .line 218
    .line 219
    move-result-object v7

    .line 220
    iget-wide v7, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->card:J

    .line 221
    .line 222
    invoke-virtual {v0, v5, v12}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getShapes(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->elevated:LX/2bW;

    .line 227
    .line 228
    invoke-static {v10, v0, v7, v8}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 229
    .line 230
    .line 231
    move-result-object v7

    .line 232
    invoke-static {v5}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    :goto_3
    invoke-interface {v11, v7}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 237
    .line 238
    .line 239
    move-result-object v10

    .line 240
    const/high16 v8, 0x41900000    # 18.0f

    .line 241
    .line 242
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 243
    .line 244
    invoke-static {v10, v8, v8, v8, v7}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 245
    .line 246
    .line 247
    move-result-object v7

    .line 248
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 249
    .line 250
    invoke-static {v5, v8, v2}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 251
    .line 252
    .line 253
    move-result-object v13

    .line 254
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 255
    .line 256
    .line 257
    move-result v12

    .line 258
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 259
    .line 260
    .line 261
    move-result-object v11

    .line 262
    invoke-static {v5, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 263
    .line 264
    .line 265
    move-result-object v10

    .line 266
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 267
    .line 268
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 269
    .line 270
    if-nez v7, :cond_13

    .line 271
    .line 272
    invoke-static {}, LX/1VY;->A00()V

    .line 273
    .line 274
    .line 275
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    throw v0

    .line 280
    :cond_f
    const v0, -0x2093d791

    .line 281
    .line 282
    .line 283
    invoke-static {v5, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 288
    .line 289
    goto :goto_3

    .line 290
    :cond_10
    and-int/lit16 v0, v4, 0x6000

    .line 291
    .line 292
    if-nez v0, :cond_3

    .line 293
    .line 294
    invoke-static/range {v25 .. v25}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 295
    .line 296
    .line 297
    move-result v0

    .line 298
    invoke-static {v5, v0}, LX/004;->A0H(LX/2d4;I)I

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    or-int/2addr v1, v0

    .line 303
    goto/16 :goto_2

    .line 304
    .line 305
    :cond_11
    and-int/lit16 v0, v4, 0xc00

    .line 306
    .line 307
    if-nez v0, :cond_2

    .line 308
    .line 309
    move-object/from16 v0, v19

    .line 310
    .line 311
    invoke-static {v5, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 312
    .line 313
    .line 314
    move-result v0

    .line 315
    or-int/2addr v1, v0

    .line 316
    goto/16 :goto_1

    .line 317
    .line 318
    :cond_12
    move v1, v4

    .line 319
    goto/16 :goto_0

    .line 320
    .line 321
    :cond_13
    invoke-static {v5, v0, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 322
    .line 323
    .line 324
    invoke-static {v5, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 325
    .line 326
    .line 327
    sget-object v7, LX/CgJ;->A00:LX/CgJ;

    .line 328
    .line 329
    shr-int/lit8 v8, v1, 0x3

    .line 330
    .line 331
    and-int/lit8 v8, v8, 0x70

    .line 332
    .line 333
    or-int/lit8 v10, v8, 0x6

    .line 334
    .line 335
    move-object/from16 v8, v23

    .line 336
    .line 337
    invoke-static {v7, v5, v8, v10}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 338
    .line 339
    .line 340
    shr-int/lit8 v8, v1, 0x15

    .line 341
    .line 342
    and-int/lit8 v10, v8, 0x70

    .line 343
    .line 344
    or-int/lit8 v10, v10, 0x6

    .line 345
    .line 346
    invoke-static {v7, v5, v14, v10}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 347
    .line 348
    .line 349
    iget-boolean v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->actionsInFooter:Z

    .line 350
    .line 351
    if-nez v10, :cond_1a

    .line 352
    .line 353
    const v10, 0x21c2bbc0

    .line 354
    .line 355
    .line 356
    invoke-interface {v5, v10}, LX/2d4;->Agj(I)V

    .line 357
    .line 358
    .line 359
    iget-boolean v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->actionsEnabled:Z

    .line 360
    .line 361
    if-eqz v10, :cond_14

    .line 362
    .line 363
    iget-boolean v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->submitting:Z

    .line 364
    .line 365
    const/16 p1, 0x1

    .line 366
    .line 367
    if-eqz v10, :cond_15

    .line 368
    .line 369
    :cond_14
    const/16 p1, 0x0

    .line 370
    .line 371
    :cond_15
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 372
    .line 373
    .line 374
    move-result v10

    .line 375
    if-eq v10, v2, :cond_19

    .line 376
    .line 377
    if-ne v10, v9, :cond_1b

    .line 378
    .line 379
    const v10, 0x21c8ae24

    .line 380
    .line 381
    .line 382
    invoke-interface {v5, v10}, LX/2d4;->Agj(I)V

    .line 383
    .line 384
    .line 385
    invoke-static {v5, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->PermissionCardDivider(LX/2d4;I)V

    .line 386
    .line 387
    .line 388
    iget-object v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->onDecision:LX/JDM;

    .line 389
    .line 390
    and-int/lit8 p8, v1, 0xe

    .line 391
    .line 392
    const/16 p9, 0x78

    .line 393
    .line 394
    const/16 p4, 0x0

    .line 395
    .line 396
    move-object/from16 p2, v10

    .line 397
    .line 398
    move-object/from16 p5, p3

    .line 399
    .line 400
    move-object/from16 p6, p3

    .line 401
    .line 402
    move-object/from16 p7, v5

    .line 403
    .line 404
    invoke-static/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionButtons-iHT-50w(Ljava/util/List;ZLX/JDM;LX/3C1;FLX/2or;LX/JDM;LX/2d4;II)V

    .line 405
    .line 406
    .line 407
    :goto_4
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 408
    .line 409
    .line 410
    iget-boolean v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->confirming:Z

    .line 411
    .line 412
    if-eqz v10, :cond_17

    .line 413
    .line 414
    const v8, 0x21cca393

    .line 415
    .line 416
    .line 417
    invoke-interface {v5, v8}, LX/2d4;->Agj(I)V

    .line 418
    .line 419
    .line 420
    iget-object v10, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 421
    .line 422
    iget-object v8, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 423
    .line 424
    sget p4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 425
    .line 426
    const/16 p5, 0x4

    .line 427
    .line 428
    move-object/from16 p0, v10

    .line 429
    .line 430
    move-object/from16 p1, v8

    .line 431
    .line 432
    move-object/from16 p2, p3

    .line 433
    .line 434
    move-object/from16 p3, v5

    .line 435
    .line 436
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionConfirmingStatus(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 437
    .line 438
    .line 439
    :goto_5
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 440
    .line 441
    .line 442
    :goto_6
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 443
    .line 444
    .line 445
    if-nez v18, :cond_16

    .line 446
    .line 447
    const v1, 0x21cfa9d8

    .line 448
    .line 449
    .line 450
    invoke-interface {v5, v1}, LX/2d4;->Agj(I)V

    .line 451
    .line 452
    .line 453
    :goto_7
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 454
    .line 455
    .line 456
    invoke-static {v0, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 457
    .line 458
    .line 459
    goto :goto_9

    .line 460
    :cond_16
    const v8, -0x7ac7c0b7

    .line 461
    .line 462
    .line 463
    invoke-interface {v5, v8}, LX/2d4;->Agj(I)V

    .line 464
    .line 465
    .line 466
    shr-int/lit8 v1, v1, 0xc

    .line 467
    .line 468
    and-int/lit8 v1, v1, 0x70

    .line 469
    .line 470
    or-int/lit8 v8, v1, 0x6

    .line 471
    .line 472
    move-object/from16 v1, v18

    .line 473
    .line 474
    invoke-static {v7, v5, v1, v8}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 475
    .line 476
    .line 477
    goto :goto_7

    .line 478
    :cond_17
    const v10, 0x21cf259d

    .line 479
    .line 480
    .line 481
    invoke-interface {v5, v10}, LX/2d4;->Agj(I)V

    .line 482
    .line 483
    .line 484
    if-nez v15, :cond_18

    .line 485
    .line 486
    const v8, 0x21cf259c

    .line 487
    .line 488
    .line 489
    invoke-interface {v5, v8}, LX/2d4;->Agj(I)V

    .line 490
    .line 491
    .line 492
    :goto_8
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 493
    .line 494
    .line 495
    goto :goto_5

    .line 496
    :cond_18
    const v10, -0x7ac7c4fb

    .line 497
    .line 498
    .line 499
    invoke-interface {v5, v10}, LX/2d4;->Agj(I)V

    .line 500
    .line 501
    .line 502
    invoke-static {v5, v15, v8}, LX/003;->A19(Ljava/lang/Object;LX/JDN;I)V

    .line 503
    .line 504
    .line 505
    goto :goto_8

    .line 506
    :cond_19
    const v10, -0x7ac81aef

    .line 507
    .line 508
    .line 509
    invoke-interface {v5, v10}, LX/2d4;->Agj(I)V

    .line 510
    .line 511
    .line 512
    iget-object v12, v6, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->onDecision:LX/JDM;

    .line 513
    .line 514
    and-int/lit8 v11, v1, 0xe

    .line 515
    .line 516
    shr-int/lit8 v10, v1, 0x6

    .line 517
    .line 518
    invoke-static {v10, v11}, LX/002;->A09(II)I

    .line 519
    .line 520
    .line 521
    move-result p6

    .line 522
    move-object/from16 p2, v12

    .line 523
    .line 524
    move/from16 p4, v17

    .line 525
    .line 526
    move-object/from16 p5, v5

    .line 527
    .line 528
    move/from16 p7, v16

    .line 529
    .line 530
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->SideBySideDecisionButtons(Ljava/util/List;ZLX/JDM;LX/3C1;ZLX/2d4;II)V

    .line 531
    .line 532
    .line 533
    goto :goto_4

    .line 534
    :cond_1a
    const v8, 0x21cf79e5

    .line 535
    .line 536
    .line 537
    invoke-interface {v5, v8}, LX/2d4;->Agj(I)V

    .line 538
    .line 539
    .line 540
    goto :goto_6

    .line 541
    :cond_1b
    const v1, -0x7ac82367

    .line 542
    .line 543
    .line 544
    invoke-static {v5, v0, v1}, LX/008;->A1D(LX/2d4;LX/J7I;I)Lkotlin/NoWhenBranchMatchedException;

    .line 545
    .line 546
    .line 547
    move-result-object v0

    .line 548
    throw v0

    .line 549
    :cond_1c
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 550
    .line 551
    .line 552
    :goto_9
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 553
    .line 554
    .line 555
    move-result-object v1

    .line 556
    if-eqz v1, :cond_1d

    .line 557
    .line 558
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt$ApprovalCardScaffold$2;

    .line 559
    .line 560
    move/from16 p1, v17

    .line 561
    .line 562
    move-object/from16 p2, v15

    .line 563
    .line 564
    move-object/from16 p3, v14

    .line 565
    .line 566
    move/from16 p4, v4

    .line 567
    .line 568
    move/from16 p5, v3

    .line 569
    .line 570
    move-object/from16 v20, v0

    .line 571
    .line 572
    move-object/from16 v22, v6

    .line 573
    .line 574
    move-object/from16 v24, v19

    .line 575
    .line 576
    move-object/from16 p0, v18

    .line 577
    .line 578
    invoke-direct/range {v20 .. v31}, Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt$ApprovalCardScaffold$2;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/JDQ;LX/3C1;Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;LX/JDQ;ZLX/JDN;LX/JDQ;II)V

    .line 579
    .line 580
    .line 581
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 582
    .line 583
    :cond_1d
    return-void
.end method
