.class public final enum Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

.field public static final enum IN_APP:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

.field public static final enum NONE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

.field public static final enum NOTIFICATION:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 0
    const-string v1, "IN_APP"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 4
    .line 5
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v4, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->IN_APP:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 9
    .line 10
    const-string v1, "NOTIFICATION"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->NOTIFICATION:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 19
    .line 20
    const-string v2, "NONE"

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 24
    .line 25
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->NONE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 29
    .line 30
    filled-new-array {v4, v3, v0}, [Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->$VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 35
    .line 36
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->$ENTRIES:LX/0vk;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->$VALUES:[Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 7
    .line 8
    return-object v0
.end method
