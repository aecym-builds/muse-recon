.class public final Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

.field public final synthetic $onTermsLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;->$onTermsLinkClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 4

    .line 268435456
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object p1, p2

    .line 268435461
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 268435468
    .line 268435469
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->networkTokenEligible:Ljava/lang/Boolean;

    .line 268435470
    .line 268435471
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->getPaymentSelection()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutPaymentSelection;

    .line 268435472
    .line 268435473
    .line 268435474
    move-result-object v0

    .line 268435475
    if-eqz v0, :cond_0

    .line 268435476
    .line 268435477
    iget-object v2, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutPaymentSelection;->paymentMethod:Ljava/lang/String;

    .line 268435478
    .line 268435479
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutApprovalCard$2;->$onTermsLinkClick:Lkotlin/jvm/functions/Function0;

    .line 268435480
    .line 268435481
    const/4 p2, 0x0

    .line 268435482
    const/16 p3, 0x8

    .line 268435483
    .line 268435484
    const/4 p0, 0x0

    .line 268435485
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt;->CheckoutTermsDisclosure(Ljava/lang/Boolean;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435486
    .line 268435487
    .line 268435488
    return-void

    .line 268435489
    :cond_0
    const/4 v2, 0x0

    .line 268435490
    goto :goto_0

    .line 268435491
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435492
    .line 268435493
    .line 268435494
    return-void
.end method
