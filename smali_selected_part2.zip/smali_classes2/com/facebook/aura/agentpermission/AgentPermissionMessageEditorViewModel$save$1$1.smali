.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$save$1$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {
        0xa3,
        0xa5
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1}, LX/DrA;->create(LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x2

    .line 5
    const/4 v9, 0x1

    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    if-eq v0, v9, :cond_4

    .line 9
    .line 10
    if-ne v0, v3, :cond_6

    .line 11
    .line 12
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :cond_0
    invoke-static {p0}, LX/3Rp;->A1O(LX/Btl;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$checkOwner(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 28
    .line 29
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-nez v0, :cond_2

    .line 34
    .line 35
    iget-object v1, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->_uiState:LX/2J2;

    .line 36
    .line 37
    invoke-interface {v1}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    check-cast v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 42
    .line 43
    const/4 v8, 0x0

    .line 44
    iget-object v3, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 45
    .line 46
    iget-object v4, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v6, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 51
    .line 52
    iget-boolean v7, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 53
    .line 54
    iget-boolean p0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 55
    .line 56
    invoke-virtual/range {v2 .. v10}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->copy(Lcom/facebook/aura/gateway/EditableMessageEditor;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :cond_1
    :goto_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 64
    .line 65
    return-object v4

    .line 66
    :cond_2
    invoke-static {v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$handleSaveFailure(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/Throwable;)V

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 74
    .line 75
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 76
    .line 77
    iput v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->label:I

    .line 78
    .line 79
    invoke-static {v1, v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$saveDraft-gIAlu-s(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    if-ne v2, v4, :cond_5

    .line 84
    .line 85
    return-object v4

    .line 86
    :cond_4
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    :cond_5
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    instance-of v0, v1, Lcom/facebook/aura/json/NetworkException;

    .line 95
    .line 96
    if-eqz v0, :cond_0

    .line 97
    .line 98
    check-cast v1, Lcom/facebook/aura/json/NetworkException;

    .line 99
    .line 100
    if-eqz v1, :cond_0

    .line 101
    .line 102
    iget v1, v1, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 103
    .line 104
    const/16 v0, 0x199

    .line 105
    .line 106
    if-ne v1, v0, :cond_0

    .line 107
    .line 108
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 109
    .line 110
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->$current:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 111
    .line 112
    const/4 v0, 0x0

    .line 113
    iput-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->L$0:Ljava/lang/Object;

    .line 114
    .line 115
    iput v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$save$1$1;->label:I

    .line 116
    .line 117
    invoke-static {v2, v1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->access$saveDraft-gIAlu-s(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;LX/2M4;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    if-ne v2, v4, :cond_0

    .line 122
    .line 123
    return-object v4

    .line 124
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0
.end method
