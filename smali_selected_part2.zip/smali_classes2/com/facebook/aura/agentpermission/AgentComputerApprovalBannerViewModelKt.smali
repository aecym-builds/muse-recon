.class public abstract Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModelKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final synthetic access$blocksItsOwnConversation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModelKt;->blocksItsOwnConversation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final blocksItsOwnConversation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->threadId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {p0, v0}, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepositoryKt;->classifyApprovalPresentation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;)Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalPresentation;->BLOCKING:Lcom/facebook/aura/gateway/ApprovalPresentation;

    .line 7
    .line 8
    invoke-static {p0, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method
