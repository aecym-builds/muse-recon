.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionNotificationRepository$start$1"
    f = "AgentPermissionNotificationRepository.kt"
    l = {
        0x53
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

.field public final synthetic $startedAtMs:J

.field public final synthetic $surface:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            ">;"
        }
    .end annotation
.end field

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;LX/2Lw;Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;",
            "LX/2Lw<",
            "+",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            ">;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$surface:LX/2Lw;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 5
    .line 6
    iput-wide p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$startedAtMs:J

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$surface:LX/2Lw;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 5
    .line 6
    iget-wide p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$startedAtMs:J

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;

    .line 9
    .line 10
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;LX/2Lw;Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;JLX/2M4;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v4, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v3

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 19
    .line 20
    iget-object v6, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 21
    .line 22
    iget-object v5, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->hasLoadedServerApprovals:LX/2J3;

    .line 23
    .line 24
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$surface:LX/2Lw;

    .line 25
    .line 26
    sget-object v1, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;->Companion:Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository$Companion;

    .line 27
    .line 28
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 29
    .line 30
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iget-object v1, v0, Lcom/facebook/aura/conversation/repo/HatchPrimarySessionRepository;->primarySessionId:LX/2J3;

    .line 37
    .line 38
    sget-object v7, Lcom/facebook/aura/gateway/HatchGatewayConnection;->Companion:Lcom/facebook/aura/gateway/HatchGatewayConnection$Companion;

    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 41
    .line 42
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;->userSession:LX/AHE;

    .line 43
    .line 44
    invoke-virtual {v7, v0}, Lcom/facebook/aura/gateway/HatchGatewayConnection$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/gateway/HatchGatewayConnection;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/HatchGatewayConnection;->getAiIdentity()LX/2J3;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;

    .line 53
    .line 54
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 55
    .line 56
    iget-wide v10, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->$startedAtMs:J

    .line 57
    .line 58
    const/4 v12, 0x0

    .line 59
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;

    .line 60
    .line 61
    invoke-direct/range {v7 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;JLX/2M4;)V

    .line 62
    .line 63
    .line 64
    filled-new-array {v6, v5, v2, v1, v0}, [LX/2Lw;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    const/4 v0, 0x3

    .line 69
    new-instance v1, LX/5zp;

    .line 70
    .line 71
    invoke-direct {v1, v0, v2, v7}, LX/5zp;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;

    .line 75
    .line 76
    iput v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1;->label:I

    .line 77
    .line 78
    invoke-virtual {v1, v0, p0}, LX/5zp;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-ne v0, v3, :cond_0

    .line 83
    .line 84
    return-object v3

    .line 85
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    throw v0
.end method
