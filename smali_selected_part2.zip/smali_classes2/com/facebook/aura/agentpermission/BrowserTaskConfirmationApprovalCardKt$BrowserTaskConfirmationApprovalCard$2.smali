.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

.field public final synthetic $onOpenBrowserClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 2

    .line 268435456
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    move-object p1, p2

    .line 268435461
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v0

    .line 268435465
    if-eqz v0, :cond_0

    .line 268435466
    .line 268435467
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 268435468
    .line 268435469
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 268435470
    .line 268435471
    sget p2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->$stable:I

    .line 268435472
    .line 268435473
    const/4 p0, 0x0

    .line 268435474
    const/4 p3, 0x4

    .line 268435475
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;->BrowserTaskConfirmationPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435476
    .line 268435477
    .line 268435478
    return-void

    .line 268435479
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435480
    .line 268435481
    .line 268435482
    return-void
.end method
