.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepositoryKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final APPROVAL_HISTORY_PAGE_SIZE:I = 0x32

.field public static final SNAPSHOT_HISTORY_SCHEMA:Ljava/lang/String; = "snapshot_v1"
