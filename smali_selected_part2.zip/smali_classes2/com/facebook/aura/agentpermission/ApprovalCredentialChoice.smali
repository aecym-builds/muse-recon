.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final allowsEnteredLogin:Z

.field public final candidates:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;",
            ">;"
        }
    .end annotation
.end field

.field public final enteredId:Ljava/lang/String;

.field public final loadId:I

.field public final loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

.field public final origin:Ljava/lang/String;

.field public final pickedId:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 7

    .line 0
    const/4 v2, 0x0

    .line 1
    sget-object v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 2
    .line 3
    sget-object v3, LX/0wV;->A00:LX/0wV;

    .line 4
    .line 5
    const/4 v6, 0x0

    .line 6
    move-object v0, p0

    .line 7
    move-object v4, v2

    .line 8
    move-object v5, v2

    .line 9
    move p0, v6

    .line 10
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZI)V"
        }
    .end annotation

    .line 536870912
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870916
    .line 536870917
    .line 536870918
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 536870919
    .line 536870920
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 536870921
    .line 536870922
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 536870923
    .line 536870924
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 536870925
    .line 536870926
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 536870927
    .line 536870928
    iput-boolean p6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 536870929
    .line 536870930
    iput p7, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 536870931
    .line 536870932
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZIILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p8, 0x1

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    sget-object p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 268435461
    .line 268435462
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 268435463
    .line 268435464
    const/4 v1, 0x0

    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    invoke-static {p3, p8}, LX/3Rr;->A0u(Ljava/util/List;I)Ljava/util/List;

    .line 268435469
    .line 268435470
    .line 268435471
    move-result-object p3

    .line 268435472
    and-int/lit8 v0, p8, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_2

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_2
    and-int/lit8 v0, p8, 0x10

    .line 268435478
    .line 268435479
    if-eqz v0, :cond_3

    .line 268435480
    .line 268435481
    move-object p5, v1

    .line 268435482
    :cond_3
    and-int/lit8 v0, p8, 0x20

    .line 268435483
    .line 268435484
    if-eqz v0, :cond_4

    .line 268435485
    .line 268435486
    const/4 p6, 0x0

    .line 268435487
    :cond_4
    and-int/lit8 v0, p8, 0x40

    .line 268435488
    .line 268435489
    if-eqz v0, :cond_5

    .line 268435490
    .line 268435491
    const/4 p7, 0x0

    .line 268435492
    :cond_5
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 268435493
    .line 268435494
    .line 268435495
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZIILjava/lang/Object;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;
    .locals 8

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-object v4, p4

    .line 4
    move-object v5, p5

    .line 5
    move v6, p6

    .line 6
    move v7, p7

    .line 7
    and-int/lit8 v0, p8, 0x1

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 12
    .line 13
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 18
    .line 19
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 20
    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 24
    .line 25
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 26
    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 30
    .line 31
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 32
    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 36
    .line 37
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 38
    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    iget-boolean v6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 42
    .line 43
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 44
    .line 45
    if-eqz v0, :cond_6

    .line 46
    .line 47
    iget v7, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 48
    .line 49
    :cond_6
    invoke-static {v1, v3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 53
    .line 54
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component7()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZI)",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 57
    .line 58
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 59
    .line 60
    if-ne v1, v0, :cond_0

    .line 61
    .line 62
    iget v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 63
    .line 64
    iget v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 65
    .line 66
    if-eq v1, v0, :cond_1

    .line 67
    .line 68
    :cond_0
    return v2

    .line 69
    :cond_1
    return v3
.end method

.method public final getAllowsEnteredLogin()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getCandidates()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEnteredId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoadId()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 1
    .line 2
    return p0
.end method

.method public final getLoadState()Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrigin()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPickedId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->origin:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v1, v0

    .line 28
    mul-int/lit8 v1, v1, 0x1f

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->allowsEnteredLogin:Z

    .line 40
    .line 41
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadId:I

    .line 46
    .line 47
    add-int/2addr v1, v0

    .line 48
    return v1
.end method

.method public final selection(Ljava/util/Set;)Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->candidates:Ljava/util/List;

    .line 5
    .line 6
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 7
    .line 8
    .line 9
    move-result-object v5

    .line 10
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    move-object v0, v1

    .line 25
    check-cast v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 26
    .line 27
    invoke-virtual {v0, p1}, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->offersAny(Ljava/util/Collection;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-virtual {v5, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 38
    .line 39
    const/4 v4, 0x0

    .line 40
    if-eqz v1, :cond_6

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_6

    .line 49
    .line 50
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    :cond_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_5

    .line 59
    .line 60
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    move-object v0, v2

    .line 65
    check-cast v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 66
    .line 67
    iget-object v1, v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_2

    .line 76
    .line 77
    :goto_1
    check-cast v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 78
    .line 79
    if-eqz v2, :cond_3

    .line 80
    .line 81
    iget-object v4, v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->decisionKinds:Ljava/util/List;

    .line 82
    .line 83
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->enteredId:Ljava/lang/String;

    .line 84
    .line 85
    if-nez v4, :cond_4

    .line 86
    .line 87
    sget-object v4, LX/0wV;->A00:LX/0wV;

    .line 88
    .line 89
    :cond_4
    sget-object v1, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->ALLOW_ONCE:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 90
    .line 91
    invoke-virtual {v1}, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->getWireValue()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-static {v1, v4}, LX/B89;->A0d(Ljava/lang/Object;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    :goto_2
    new-instance v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;

    .line 100
    .line 101
    invoke-direct {v1, v0, v2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialPick;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 102
    .line 103
    .line 104
    return-object v1

    .line 105
    :cond_5
    move-object v2, v4

    .line 106
    goto :goto_1

    .line 107
    :cond_6
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    :cond_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_9

    .line 116
    .line 117
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    move-object v0, v2

    .line 122
    check-cast v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 123
    .line 124
    iget-object v1, v0, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 125
    .line 126
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->pickedId:Ljava/lang/String;

    .line 127
    .line 128
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-eqz v0, :cond_7

    .line 133
    .line 134
    :goto_3
    check-cast v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 135
    .line 136
    if-nez v2, :cond_8

    .line 137
    .line 138
    invoke-static {v5}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    check-cast v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;

    .line 143
    .line 144
    if-eqz v2, :cond_a

    .line 145
    .line 146
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChoice;->loadState:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 147
    .line 148
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;->LOADED:Lcom/facebook/aura/agentpermission/ApprovalCredentialLoadState;

    .line 149
    .line 150
    if-ne v1, v0, :cond_a

    .line 151
    .line 152
    :cond_8
    iget-object v0, v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->credentialId:Ljava/lang/String;

    .line 153
    .line 154
    iget-object v2, v2, Lcom/facebook/aura/gateway/ApprovalCredentialCandidate;->decisionKinds:Ljava/util/List;

    .line 155
    .line 156
    goto :goto_2

    .line 157
    :cond_9
    move-object v2, v4

    .line 158
    goto :goto_3

    .line 159
    :cond_a
    return-object v4
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
