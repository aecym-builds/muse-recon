.class public abstract Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModelKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final credentialChooserMarker(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->credentialSelection:Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/gateway/MultiLoginGating;->INSTANCE:Lcom/facebook/aura/gateway/MultiLoginGating;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/MultiLoginGating;->isEnabled()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_0
    return-object v1
.end method
