.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDO<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        ">;",
        "Ljava/lang/String;",
        "Lcom/facebook/aura/auth/api/AuraSessionManager$SessionState;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$1$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x4

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p4, LX/2M4;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;

    .line 3
    .line 4
    invoke-direct {p1, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;-><init>(LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final invoke(Ljava/util/List;Ljava/lang/String;Lcom/facebook/aura/auth/api/AuraSessionManager$SessionState;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/auth/api/AuraSessionManager$SessionState;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;

    .line 268435457
    .line 268435458
    invoke-direct {p1, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object p0

    .line 268435467
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;->label:I

    .line 1
    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    throw p0
.end method
