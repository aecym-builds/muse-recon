.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionMessageEditorScreen(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 45

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    const/4 v4, 0x0

    .line 3
    move-object/from16 v2, p0

    .line 4
    .line 5
    invoke-static {v2, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x38838cb4

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p2

    .line 12
    .line 13
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v3, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_b

    .line 21
    .line 22
    invoke-static {v1, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    or-int v9, v9, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v6, p4

    .line 29
    .line 30
    and-int/lit8 v8, p4, 0x2

    .line 31
    .line 32
    if-eqz v8, :cond_a

    .line 33
    .line 34
    or-int/lit8 v9, v9, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v7, v9, 0x13

    .line 37
    .line 38
    const/16 v0, 0x12

    .line 39
    .line 40
    const/4 v11, 0x1

    .line 41
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0, v1, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_9

    .line 50
    .line 51
    if-eqz v8, :cond_1

    .line 52
    .line 53
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 54
    .line 55
    :cond_1
    invoke-static {v1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    new-instance v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Factory;

    .line 60
    .line 61
    invoke-direct {v9, v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$Factory;-><init>(LX/AHE;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    const/16 p1, 0x6

    .line 65
    .line 66
    invoke-static {v1}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    if-eqz v8, :cond_c

    .line 71
    .line 72
    invoke-static {v8}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 73
    .line 74
    .line 75
    move-result-object v7

    .line 76
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 77
    .line 78
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    const/4 v14, 0x0

    .line 83
    invoke-static {v9, v8, v7, v14, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 84
    .line 85
    .line 86
    move-result-object v9

    .line 87
    check-cast v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 88
    .line 89
    iget-object v0, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->uiState:LX/2J3;

    .line 90
    .line 91
    invoke-static {v1, v0, v4}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 92
    .line 93
    .line 94
    move-result-object v7

    .line 95
    invoke-static {v1}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 96
    .line 97
    .line 98
    move-result-object v10

    .line 99
    invoke-interface {v7}, LX/16A;->getValue()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 104
    .line 105
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saved:Z

    .line 106
    .line 107
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 108
    .line 109
    .line 110
    move-result-object v12

    .line 111
    invoke-static {v1, v7, v10}, LX/003;->A1M(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v8

    .line 115
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    if-nez v8, :cond_2

    .line 120
    .line 121
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 122
    .line 123
    if-ne v0, v8, :cond_3

    .line 124
    .line 125
    :cond_2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;

    .line 126
    .line 127
    invoke-direct {v0, v10, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;LX/16A;)V

    .line 128
    .line 129
    .line 130
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_3
    invoke-static {v1, v0, v12}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 137
    .line 138
    invoke-static {v5}, LX/6jg;->A00(LX/3C1;)LX/3C1;

    .line 139
    .line 140
    .line 141
    move-result-object v13

    .line 142
    invoke-interface {v7}, LX/16A;->getValue()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 147
    .line 148
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 149
    .line 150
    if-eqz v0, :cond_4

    .line 151
    .line 152
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 153
    .line 154
    .line 155
    move-result v8

    .line 156
    const v0, 0x7f12010c

    .line 157
    .line 158
    .line 159
    if-eq v8, v11, :cond_5

    .line 160
    .line 161
    :cond_4
    const v0, 0x7f12010d

    .line 162
    .line 163
    .line 164
    :cond_5
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v17

    .line 168
    invoke-static {v1, v9, v10}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    move-result v8

    .line 172
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    if-nez v8, :cond_6

    .line 177
    .line 178
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 179
    .line 180
    if-ne v0, v8, :cond_7

    .line 181
    .line 182
    :cond_6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$2$1;

    .line 183
    .line 184
    invoke-direct {v0, v9, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$2$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 185
    .line 186
    .line 187
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    :cond_7
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 191
    .line 192
    new-instance v10, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;

    .line 193
    .line 194
    invoke-direct {v10, v9, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$3;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/16A;)V

    .line 195
    .line 196
    .line 197
    const v8, 0x5e75b559

    .line 198
    .line 199
    .line 200
    invoke-static {v1, v10, v8}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 201
    .line 202
    .line 203
    move-result-object v29

    .line 204
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;

    .line 205
    .line 206
    invoke-direct {v8, v9, v2, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/16A;)V

    .line 207
    .line 208
    .line 209
    const v7, -0x12b55c2f

    .line 210
    .line 211
    .line 212
    invoke-static {v1, v8, v7}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 213
    .line 214
    .line 215
    move-result-object v44

    .line 216
    const/high16 p3, 0x36000000

    .line 217
    .line 218
    const p4, 0xffeffac

    .line 219
    .line 220
    .line 221
    const-wide/16 v15, 0x0

    .line 222
    .line 223
    const/16 v35, 0x0

    .line 224
    .line 225
    const/high16 p2, 0x180000

    .line 226
    .line 227
    move-object/from16 v18, v14

    .line 228
    .line 229
    move-object/from16 v20, v14

    .line 230
    .line 231
    move/from16 v22, v4

    .line 232
    .line 233
    move/from16 v23, v4

    .line 234
    .line 235
    move-object/from16 v24, v14

    .line 236
    .line 237
    move-object/from16 v25, v14

    .line 238
    .line 239
    move-object/from16 v26, v14

    .line 240
    .line 241
    move-object/from16 v27, v14

    .line 242
    .line 243
    move-object/from16 v28, v14

    .line 244
    .line 245
    move-wide/from16 v30, v15

    .line 246
    .line 247
    move-wide/from16 v32, v15

    .line 248
    .line 249
    move-object/from16 v34, v14

    .line 250
    .line 251
    move-object/from16 v36, v14

    .line 252
    .line 253
    move-object/from16 v37, v14

    .line 254
    .line 255
    move-object/from16 v38, v14

    .line 256
    .line 257
    move/from16 v39, v4

    .line 258
    .line 259
    move-object/from16 v40, v14

    .line 260
    .line 261
    move-object/from16 v41, v14

    .line 262
    .line 263
    move-object/from16 v42, v14

    .line 264
    .line 265
    move/from16 v43, v4

    .line 266
    .line 267
    move-object/from16 p0, v1

    .line 268
    .line 269
    move-object/from16 v19, v0

    .line 270
    .line 271
    move/from16 v21, v4

    .line 272
    .line 273
    invoke-static/range {v12 .. v49}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 274
    .line 275
    .line 276
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 277
    .line 278
    .line 279
    move-result-object v1

    .line 280
    if-eqz v1, :cond_8

    .line 281
    .line 282
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$5;

    .line 283
    .line 284
    invoke-direct {v0, v2, v5, v3, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$5;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 285
    .line 286
    .line 287
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 288
    .line 289
    :cond_8
    return-void

    .line 290
    :cond_9
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 291
    .line 292
    .line 293
    goto :goto_2

    .line 294
    :cond_a
    and-int/lit8 v0, p3, 0x30

    .line 295
    .line 296
    if-nez v0, :cond_0

    .line 297
    .line 298
    invoke-static {v1, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    or-int/2addr v9, v0

    .line 303
    goto/16 :goto_1

    .line 304
    .line 305
    :cond_b
    move v9, v3

    .line 306
    goto/16 :goto_0

    .line 307
    .line 308
    :cond_c
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 309
    .line 310
    .line 311
    move-result-object v0

    .line 312
    throw v0
.end method

.method public static final AgentPermissionMessageEditorScreen$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final MessageEditorAttachments(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/EditableMessageAttachment;",
            ">;",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "Z",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v22, p3

    .line 1
    .line 2
    const v0, 0x2632f2db

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v7, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 p5, p0

    .line 15
    .line 16
    if-nez v0, :cond_f

    .line 17
    .line 18
    move-object/from16 v0, p5

    .line 19
    .line 20
    invoke-static {v0, v2, v7}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    or-int/2addr v3, v7

    .line 29
    :goto_0
    and-int/lit8 v0, v7, 0x30

    .line 30
    .line 31
    move-object/from16 p4, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    move-object/from16 v0, p4

    .line 36
    .line 37
    invoke-static {v0, v2, v7}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0}, LX/003;->A07(I)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v3, v0

    .line 46
    :cond_0
    and-int/lit16 v0, v7, 0x180

    .line 47
    .line 48
    move/from16 p3, p2

    .line 49
    .line 50
    if-nez v0, :cond_1

    .line 51
    .line 52
    move/from16 v0, p3

    .line 53
    .line 54
    invoke-static {v2, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    or-int/2addr v3, v0

    .line 59
    :cond_1
    move/from16 p2, p6

    .line 60
    .line 61
    and-int/lit8 v4, p6, 0x8

    .line 62
    .line 63
    if-eqz v4, :cond_e

    .line 64
    .line 65
    or-int/lit16 v3, v3, 0xc00

    .line 66
    .line 67
    :cond_2
    :goto_1
    and-int/lit16 v1, v3, 0x493

    .line 68
    .line 69
    const/16 v0, 0x492

    .line 70
    .line 71
    const/4 v10, 0x1

    .line 72
    const/4 v6, 0x0

    .line 73
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-static {v0, v2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_c

    .line 82
    .line 83
    if-eqz v4, :cond_3

    .line 84
    .line 85
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 86
    .line 87
    :cond_3
    invoke-interface/range {p5 .. p5}, Ljava/util/List;->isEmpty()Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    if-eqz v1, :cond_4

    .line 98
    .line 99
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$1;

    .line 100
    .line 101
    move-object/from16 v40, v0

    .line 102
    .line 103
    move-object/from16 v41, p5

    .line 104
    .line 105
    move-object/from16 v42, p4

    .line 106
    .line 107
    move/from16 v43, p3

    .line 108
    .line 109
    move-object/from16 p0, v22

    .line 110
    .line 111
    move/from16 p1, v7

    .line 112
    .line 113
    invoke-direct/range {v40 .. v46}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$1;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;II)V

    .line 114
    .line 115
    .line 116
    :goto_2
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_4
    return-void

    .line 120
    :cond_5
    const/16 v28, 0x0

    .line 121
    .line 122
    invoke-static/range {v22 .. v22}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    invoke-static {v6, v2, v6, v10}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-static {v0, v1}, LX/3J3;->A01(LX/3Lr;LX/3C1;)LX/3C1;

    .line 131
    .line 132
    .line 133
    move-result-object v11

    .line 134
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 135
    .line 136
    invoke-static {v2, v0, v6}, LX/007;->A0g(LX/2d4;FI)LX/3BI;

    .line 137
    .line 138
    .line 139
    move-result-object v8

    .line 140
    move-object v4, v2

    .line 141
    check-cast v4, LX/J7I;

    .line 142
    .line 143
    iget-wide v0, v4, LX/J7I;->A06:J

    .line 144
    .line 145
    const/16 v21, 0x20

    .line 146
    .line 147
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 148
    .line 149
    .line 150
    move-result v9

    .line 151
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 152
    .line 153
    .line 154
    move-result-object v5

    .line 155
    invoke-static {v2, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    sget-object v20, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 160
    .line 161
    iget-object v0, v4, LX/J7I;->A0V:LX/3DJ;

    .line 162
    .line 163
    if-nez v0, :cond_6

    .line 164
    .line 165
    invoke-static {}, LX/1VY;->A00()V

    .line 166
    .line 167
    .line 168
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    throw v0

    .line 173
    :cond_6
    move-object/from16 v0, v20

    .line 174
    .line 175
    invoke-static {v2, v4, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 176
    .line 177
    .line 178
    sget-object v15, LX/3Cl;->A04:LX/JDN;

    .line 179
    .line 180
    invoke-static {v2, v8, v15}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 181
    .line 182
    .line 183
    move-result-object v14

    .line 184
    invoke-static {v2, v5, v14, v9}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 185
    .line 186
    .line 187
    move-result-object v19

    .line 188
    sget-object v11, LX/3Cl;->A02:LX/JDM;

    .line 189
    .line 190
    invoke-static {v2, v1, v11}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 191
    .line 192
    .line 193
    move-result-object v18

    .line 194
    const v1, 0x54f396b2

    .line 195
    .line 196
    .line 197
    move-object/from16 v0, p5

    .line 198
    .line 199
    invoke-static {v2, v0, v1}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 200
    .line 201
    .line 202
    move-result-object v17

    .line 203
    :goto_3
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    if-eqz v0, :cond_d

    .line 208
    .line 209
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v5

    .line 213
    check-cast v5, Lcom/facebook/aura/gateway/EditableMessageAttachment;

    .line 214
    .line 215
    const v1, 0x7b6fa43f

    .line 216
    .line 217
    .line 218
    iget-object v0, v5, Lcom/facebook/aura/gateway/EditableMessageAttachment;->id:Ljava/lang/String;

    .line 219
    .line 220
    invoke-interface {v2, v1, v0}, LX/2d4;->Agd(ILjava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    sget-object v9, LX/2Id;->A00:LX/2sS;

    .line 224
    .line 225
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 226
    .line 227
    sget-object v1, LX/Dn6;->A06:LX/Dps;

    .line 228
    .line 229
    const/16 v16, 0x30

    .line 230
    .line 231
    move/from16 v0, v16

    .line 232
    .line 233
    invoke-static {v1, v2, v9, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 234
    .line 235
    .line 236
    move-result-object v13

    .line 237
    invoke-static {v4}, LX/002;->A0J(LX/J7I;)I

    .line 238
    .line 239
    .line 240
    move-result v12

    .line 241
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 242
    .line 243
    .line 244
    move-result-object v9

    .line 245
    invoke-static {v2, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 246
    .line 247
    .line 248
    move-result-object v1

    .line 249
    move-object/from16 v0, v20

    .line 250
    .line 251
    invoke-static {v2, v4, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 252
    .line 253
    .line 254
    invoke-static {v2, v13, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 255
    .line 256
    .line 257
    invoke-static {v2, v9, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 258
    .line 259
    .line 260
    move-object/from16 v0, v19

    .line 261
    .line 262
    invoke-static {v11, v0, v2, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 263
    .line 264
    .line 265
    move-object/from16 v0, v18

    .line 266
    .line 267
    invoke-static {v2, v1, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 268
    .line 269
    .line 270
    invoke-static {v6}, LX/001;->A0g(Z)LX/3BI;

    .line 271
    .line 272
    .line 273
    move-result-object v13

    .line 274
    invoke-static {v4}, LX/002;->A0J(LX/J7I;)I

    .line 275
    .line 276
    .line 277
    move-result v12

    .line 278
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 279
    .line 280
    .line 281
    move-result-object v9

    .line 282
    invoke-static {v2, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 283
    .line 284
    .line 285
    move-result-object v1

    .line 286
    move-object/from16 v0, v20

    .line 287
    .line 288
    invoke-static {v2, v4, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 289
    .line 290
    .line 291
    invoke-static {v2, v13, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 292
    .line 293
    .line 294
    invoke-static {v2, v9, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 295
    .line 296
    .line 297
    move-object/from16 v0, v19

    .line 298
    .line 299
    invoke-static {v11, v0, v2, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 300
    .line 301
    .line 302
    move-object/from16 v0, v18

    .line 303
    .line 304
    invoke-static {v2, v1, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 305
    .line 306
    .line 307
    sget-object v12, LX/3Jn;->A00:LX/3Jn;

    .line 308
    .line 309
    iget-object v1, v5, Lcom/facebook/aura/gateway/EditableMessageAttachment;->preview:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;

    .line 310
    .line 311
    sget v31, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->$stable:I

    .line 312
    .line 313
    const/4 v0, 0x6

    .line 314
    move-object/from16 v27, v1

    .line 315
    .line 316
    move-object/from16 v29, v28

    .line 317
    .line 318
    move-object/from16 v30, v2

    .line 319
    .line 320
    move/from16 v32, v0

    .line 321
    .line 322
    invoke-static/range {v27 .. v32}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentMedia(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 323
    .line 324
    .line 325
    const v1, 0x7f0802e9

    .line 326
    .line 327
    .line 328
    invoke-static {v2, v1, v6}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 329
    .line 330
    .line 331
    move-result-object v30

    .line 332
    sget-object v31, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;

    .line 333
    .line 334
    sget-object v1, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;

    .line 335
    .line 336
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyles;->flat(LX/2d4;I)Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;

    .line 337
    .line 338
    .line 339
    move-result-object v9

    .line 340
    sget-object v13, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 341
    .line 342
    invoke-static {v2, v13}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 343
    .line 344
    .line 345
    move-result-wide v35

    .line 346
    iget-wide v0, v9, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;->iconColor:J

    .line 347
    .line 348
    move-wide/from16 v24, v0

    .line 349
    .line 350
    iget-object v0, v9, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;->gradientBrush:LX/2hZ;

    .line 351
    .line 352
    move-object/from16 v23, v0

    .line 353
    .line 354
    iget-boolean v0, v9, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;->requiresBackground:Z

    .line 355
    .line 356
    move v1, v0

    .line 357
    iget v0, v9, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;->elevation:F

    .line 358
    .line 359
    move-object/from16 v32, v9

    .line 360
    .line 361
    move-wide/from16 v33, v24

    .line 362
    .line 363
    move-object/from16 v37, v23

    .line 364
    .line 365
    move/from16 v38, v1

    .line 366
    .line 367
    move/from16 v39, v0

    .line 368
    .line 369
    invoke-virtual/range {v32 .. v39}, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;->copy-GCAZt4c(JJLX/2hZ;ZF)Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;

    .line 370
    .line 371
    .line 372
    move-result-object v32

    .line 373
    const v1, 0x7f120173

    .line 374
    .line 375
    .line 376
    iget-object v0, v5, Lcom/facebook/aura/gateway/EditableMessageAttachment;->name:Ljava/lang/String;

    .line 377
    .line 378
    invoke-static {v2, v0, v1}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v33

    .line 382
    sget-object v0, LX/2Id;->A0D:Landroidx/compose/ui/Alignment;

    .line 383
    .line 384
    invoke-virtual {v12, v0, v8}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 385
    .line 386
    .line 387
    move-result-object v9

    .line 388
    const/high16 v1, 0x41000000    # 8.0f

    .line 389
    .line 390
    const/high16 v0, -0x3f000000    # -8.0f

    .line 391
    .line 392
    invoke-static {v9, v1, v0}, LX/7mL;->A01(LX/3C1;FF)LX/3C1;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    sget-object v0, LX/2pc;->A00:LX/2pc;

    .line 397
    .line 398
    invoke-interface {v1, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 399
    .line 400
    .line 401
    move-result-object v29

    .line 402
    and-int/lit8 v1, v3, 0x70

    .line 403
    .line 404
    move/from16 v0, v21

    .line 405
    .line 406
    if-eq v1, v0, :cond_7

    .line 407
    .line 408
    and-int/lit8 v0, v3, 0x40

    .line 409
    .line 410
    if-eqz v0, :cond_b

    .line 411
    .line 412
    move-object/from16 v0, p4

    .line 413
    .line 414
    invoke-interface {v2, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 415
    .line 416
    .line 417
    move-result v0

    .line 418
    if-eqz v0, :cond_b

    .line 419
    .line 420
    :cond_7
    const/4 v0, 0x1

    .line 421
    :goto_4
    invoke-static {v2, v5, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 422
    .line 423
    .line 424
    move-result v1

    .line 425
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 426
    .line 427
    .line 428
    move-result-object v0

    .line 429
    if-nez v1, :cond_8

    .line 430
    .line 431
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 432
    .line 433
    if-ne v0, v1, :cond_9

    .line 434
    .line 435
    :cond_8
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$2$1$1$1$1$1;

    .line 436
    .line 437
    move-object/from16 v1, p4

    .line 438
    .line 439
    invoke-direct {v0, v1, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$2$1$1$1$1$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Lcom/facebook/aura/gateway/EditableMessageAttachment;)V

    .line 440
    .line 441
    .line 442
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 443
    .line 444
    .line 445
    :cond_9
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 446
    .line 447
    const/high16 v1, 0x41400000    # 12.0f

    .line 448
    .line 449
    invoke-static {v1}, LX/1Ot;->A02(F)LX/1Ot;

    .line 450
    .line 451
    .line 452
    move-result-object v38

    .line 453
    sget v1, LX/2l9;->$stable:I

    .line 454
    .line 455
    shl-int/lit8 v1, v1, 0x3

    .line 456
    .line 457
    const v9, 0x30000180

    .line 458
    .line 459
    .line 460
    or-int/2addr v1, v9

    .line 461
    shl-int/lit8 v9, v3, 0xf

    .line 462
    .line 463
    invoke-static {v9, v1}, LX/002;->A0A(II)I

    .line 464
    .line 465
    .line 466
    move-result v43

    .line 467
    const/16 p1, 0x1d40

    .line 468
    .line 469
    move-object/from16 v34, v0

    .line 470
    .line 471
    move-object/from16 v35, v28

    .line 472
    .line 473
    move/from16 v36, p3

    .line 474
    .line 475
    move-object/from16 v37, v28

    .line 476
    .line 477
    move-object/from16 v39, v28

    .line 478
    .line 479
    move-object/from16 v40, v28

    .line 480
    .line 481
    move-object/from16 v41, v28

    .line 482
    .line 483
    move-object/from16 v42, v2

    .line 484
    .line 485
    move/from16 p0, v6

    .line 486
    .line 487
    invoke-static/range {v29 .. v45}, Lcom/facebook/aura/vds/compose/icons/AuraIconButtonKt;->AuraIconButtonV2-X32rcYo(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonSizeV2;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonStyleConfig;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLX/JOw;LX/1Ot;Lcom/facebook/aura/vds/compose/icons/AuraIconButtonBackground;LX/3Gw;Ljava/lang/String;LX/2d4;III)V

    .line 488
    .line 489
    .line 490
    invoke-static {v4, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 491
    .line 492
    .line 493
    iget-object v0, v5, Lcom/facebook/aura/gateway/EditableMessageAttachment;->altText:Ljava/lang/String;

    .line 494
    .line 495
    if-nez v0, :cond_a

    .line 496
    .line 497
    const v0, -0x4a5e77a3

    .line 498
    .line 499
    .line 500
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 501
    .line 502
    .line 503
    invoke-static {v4, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 504
    .line 505
    .line 506
    :goto_5
    invoke-static {v4, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 507
    .line 508
    .line 509
    invoke-static {v4, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 510
    .line 511
    .line 512
    goto/16 :goto_3

    .line 513
    .line 514
    :cond_a
    const v1, -0x4a5e77a2

    .line 515
    .line 516
    .line 517
    invoke-static {v2, v13, v1}, LX/3Rr;->A0D(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)LX/2hg;

    .line 518
    .line 519
    .line 520
    move-result-object v27

    .line 521
    const/high16 v5, 0x43200000    # 160.0f

    .line 522
    .line 523
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 524
    .line 525
    invoke-static {v8, v1, v5}, LX/2sI;->A0D(LX/3C1;FF)LX/3C1;

    .line 526
    .line 527
    .line 528
    move-result-object v24

    .line 529
    const/16 v41, 0x3ff4

    .line 530
    .line 531
    const-wide/16 v25, 0x0

    .line 532
    .line 533
    move-object/from16 v23, v0

    .line 534
    .line 535
    move-object/from16 v29, v28

    .line 536
    .line 537
    move-object/from16 v30, v28

    .line 538
    .line 539
    move/from16 v31, v6

    .line 540
    .line 541
    move/from16 v32, v6

    .line 542
    .line 543
    move/from16 v33, v6

    .line 544
    .line 545
    move/from16 v34, v6

    .line 546
    .line 547
    move-object/from16 v36, v28

    .line 548
    .line 549
    move-object/from16 v38, v2

    .line 550
    .line 551
    move/from16 v39, v16

    .line 552
    .line 553
    move/from16 v40, v6

    .line 554
    .line 555
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 556
    .line 557
    .line 558
    invoke-static {v4, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 559
    .line 560
    .line 561
    goto :goto_5

    .line 562
    :cond_b
    const/4 v0, 0x0

    .line 563
    goto/16 :goto_4

    .line 564
    .line 565
    :cond_c
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 566
    .line 567
    .line 568
    goto :goto_6

    .line 569
    :cond_d
    move-object/from16 v0, v22

    .line 570
    .line 571
    invoke-static {v4, v0, v6, v10}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 572
    .line 573
    .line 574
    move-result-object v22

    .line 575
    :goto_6
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 576
    .line 577
    .line 578
    move-result-object v1

    .line 579
    if-eqz v1, :cond_4

    .line 580
    .line 581
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$3;

    .line 582
    .line 583
    move-object/from16 v40, v0

    .line 584
    .line 585
    move-object/from16 v41, p5

    .line 586
    .line 587
    move-object/from16 v42, p4

    .line 588
    .line 589
    move/from16 v43, p3

    .line 590
    .line 591
    move-object/from16 p0, v22

    .line 592
    .line 593
    move/from16 p1, v7

    .line 594
    .line 595
    invoke-direct/range {v40 .. v46}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorAttachments$3;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;II)V

    .line 596
    .line 597
    .line 598
    goto/16 :goto_2

    .line 599
    .line 600
    :cond_e
    and-int/lit16 v0, v7, 0xc00

    .line 601
    .line 602
    if-nez v0, :cond_2

    .line 603
    .line 604
    move-object/from16 v0, v22

    .line 605
    .line 606
    invoke-static {v2, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 607
    .line 608
    .line 609
    move-result v0

    .line 610
    or-int/2addr v3, v0

    .line 611
    goto/16 :goto_1

    .line 612
    .line 613
    :cond_f
    move v3, v7

    .line 614
    goto/16 :goto_0
.end method

.method public static final MessageEditorFields(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/3C1;LX/2d4;II)V
    .locals 44

    .line 0
    move-object/from16 v15, p2

    .line 1
    .line 2
    const v1, 0x306ed53f

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p3

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v8, p4

    .line 11
    .line 12
    and-int/lit8 v1, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v9, p0

    .line 15
    .line 16
    if-nez v1, :cond_4

    .line 17
    .line 18
    invoke-static {v9, v0, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    or-int v1, v1, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v2, p4, 0x30

    .line 29
    .line 30
    const/16 v19, 0x20

    .line 31
    .line 32
    move-object/from16 p4, p1

    .line 33
    .line 34
    if-nez v2, :cond_0

    .line 35
    .line 36
    move-object/from16 v2, p4

    .line 37
    .line 38
    invoke-static {v2, v0, v8}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    invoke-static {v2}, LX/003;->A07(I)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    or-int/2addr v1, v2

    .line 47
    :cond_0
    move/from16 p3, p5

    .line 48
    .line 49
    and-int/lit8 v4, p5, 0x4

    .line 50
    .line 51
    if-eqz v4, :cond_3

    .line 52
    .line 53
    or-int/lit16 v1, v1, 0x180

    .line 54
    .line 55
    :cond_1
    :goto_1
    and-int/lit16 v3, v1, 0x93

    .line 56
    .line 57
    const/16 v2, 0x92

    .line 58
    .line 59
    const/16 v18, 0x1

    .line 60
    .line 61
    const/4 v7, 0x0

    .line 62
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 63
    .line 64
    .line 65
    move-result v2

    .line 66
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-eqz v2, :cond_16

    .line 71
    .line 72
    if-eqz v4, :cond_2

    .line 73
    .line 74
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 75
    .line 76
    :cond_2
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 77
    .line 78
    const/16 v17, 0x6

    .line 79
    .line 80
    invoke-static {v0, v6}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 81
    .line 82
    .line 83
    move-result-wide v34

    .line 84
    move/from16 v2, v17

    .line 85
    .line 86
    invoke-virtual {v6, v0, v2}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    iget-object v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraColors;->textInput:Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;

    .line 91
    .line 92
    iget-wide v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;->cursorColor:J

    .line 93
    .line 94
    invoke-static {v0, v6}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 95
    .line 96
    .line 97
    move-result-wide v38

    .line 98
    sget-wide v40, LX/JOw;->A06:J

    .line 99
    .line 100
    invoke-static/range {v40 .. v41}, LX/001;->A0d(J)LX/JOw;

    .line 101
    .line 102
    .line 103
    move-result-object p2

    .line 104
    const/16 v16, 0x0

    .line 105
    .line 106
    new-instance v33, Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;

    .line 107
    .line 108
    move-wide/from16 v36, v2

    .line 109
    .line 110
    move-wide/from16 v42, v40

    .line 111
    .line 112
    move-wide/from16 p0, v40

    .line 113
    .line 114
    invoke-direct/range {v33 .. v46}, Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;-><init>(JJJJJJLX/JOw;)V

    .line 115
    .line 116
    .line 117
    iget-boolean v2, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 118
    .line 119
    move/from16 v36, v2

    .line 120
    .line 121
    invoke-static {v0}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 122
    .line 123
    .line 124
    move-result-object v12

    .line 125
    move-object v2, v0

    .line 126
    check-cast v2, LX/J7I;

    .line 127
    .line 128
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 129
    .line 130
    .line 131
    move-result v11

    .line 132
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 133
    .line 134
    .line 135
    move-result-object v10

    .line 136
    invoke-static {v0, v15}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    sget-object v4, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 141
    .line 142
    iget-object v3, v2, LX/J7I;->A0V:LX/3DJ;

    .line 143
    .line 144
    if-nez v3, :cond_5

    .line 145
    .line 146
    invoke-static {}, LX/1VY;->A00()V

    .line 147
    .line 148
    .line 149
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    throw v0

    .line 154
    :cond_3
    and-int/lit16 v2, v8, 0x180

    .line 155
    .line 156
    if-nez v2, :cond_1

    .line 157
    .line 158
    invoke-static {v0, v15}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    or-int/2addr v1, v2

    .line 163
    goto :goto_1

    .line 164
    :cond_4
    move v1, v8

    .line 165
    goto/16 :goto_0

    .line 166
    .line 167
    :cond_5
    invoke-static {v0, v2, v4}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 168
    .line 169
    .line 170
    invoke-static {v0, v12, v10, v5, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 171
    .line 172
    .line 173
    iget-object v3, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 174
    .line 175
    if-eqz v3, :cond_15

    .line 176
    .line 177
    invoke-virtual {v3}, Lcom/facebook/aura/gateway/EditableMessageEditor;->isEmail()Z

    .line 178
    .line 179
    .line 180
    move-result v4

    .line 181
    move/from16 v3, v18

    .line 182
    .line 183
    if-ne v4, v3, :cond_15

    .line 184
    .line 185
    const v3, 0x21b34914

    .line 186
    .line 187
    .line 188
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 189
    .line 190
    .line 191
    const v3, 0x7f120118

    .line 192
    .line 193
    .line 194
    invoke-static {v0, v3}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v4

    .line 198
    iget-object v12, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->subject:Ljava/lang/String;

    .line 199
    .line 200
    and-int/lit8 v5, v1, 0x70

    .line 201
    .line 202
    move/from16 v3, v19

    .line 203
    .line 204
    if-eq v5, v3, :cond_6

    .line 205
    .line 206
    and-int/lit8 v3, v1, 0x40

    .line 207
    .line 208
    if-eqz v3, :cond_14

    .line 209
    .line 210
    move-object/from16 v3, p4

    .line 211
    .line 212
    invoke-interface {v0, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v3

    .line 216
    if-eqz v3, :cond_14

    .line 217
    .line 218
    :cond_6
    const/4 v5, 0x1

    .line 219
    :goto_2
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v3

    .line 223
    if-nez v5, :cond_7

    .line 224
    .line 225
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 226
    .line 227
    if-ne v3, v5, :cond_8

    .line 228
    .line 229
    :cond_7
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$1$1;

    .line 230
    .line 231
    move-object/from16 v5, p4

    .line 232
    .line 233
    invoke-direct {v3, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$1$1;-><init>(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    :cond_8
    check-cast v3, LX/DqV;

    .line 240
    .line 241
    invoke-static {v0, v6}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 242
    .line 243
    .line 244
    move-result-object v27

    .line 245
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 246
    .line 247
    invoke-interface {v0, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v10

    .line 251
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v11

    .line 255
    if-nez v10, :cond_9

    .line 256
    .line 257
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 258
    .line 259
    if-ne v11, v10, :cond_a

    .line 260
    .line 261
    :cond_9
    new-instance v11, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$2$1;

    .line 262
    .line 263
    invoke-direct {v11, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$2$1;-><init>(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    invoke-interface {v0, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    :cond_a
    invoke-static {v5, v11, v7}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 270
    .line 271
    .line 272
    move-result-object v22

    .line 273
    new-instance v10, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;

    .line 274
    .line 275
    invoke-direct {v10, v4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;-><init>(Ljava/lang/String;)V

    .line 276
    .line 277
    .line 278
    const v4, -0x29c92a89

    .line 279
    .line 280
    .line 281
    invoke-static {v0, v10, v4}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 282
    .line 283
    .line 284
    move-result-object v31

    .line 285
    check-cast v3, LX/JDM;

    .line 286
    .line 287
    const p1, 0xad67a

    .line 288
    .line 289
    .line 290
    const/high16 v42, 0x6000000

    .line 291
    .line 292
    const v43, 0x6000030

    .line 293
    .line 294
    .line 295
    move-object/from16 v23, v16

    .line 296
    .line 297
    move-object/from16 v24, v16

    .line 298
    .line 299
    move-object/from16 v25, v16

    .line 300
    .line 301
    move-object/from16 v26, v16

    .line 302
    .line 303
    move/from16 v28, v18

    .line 304
    .line 305
    move/from16 v29, v7

    .line 306
    .line 307
    move/from16 v30, v7

    .line 308
    .line 309
    move-object/from16 v32, v16

    .line 310
    .line 311
    move-object/from16 v34, v16

    .line 312
    .line 313
    move/from16 v35, v7

    .line 314
    .line 315
    move/from16 v37, v7

    .line 316
    .line 317
    move/from16 v38, v18

    .line 318
    .line 319
    move-object/from16 v39, v16

    .line 320
    .line 321
    move-object/from16 v40, v3

    .line 322
    .line 323
    move-object/from16 v41, v0

    .line 324
    .line 325
    move/from16 p0, v7

    .line 326
    .line 327
    move-object/from16 v20, v12

    .line 328
    .line 329
    move-object/from16 v21, v16

    .line 330
    .line 331
    invoke-static/range {v20 .. v45}, Lcom/facebook/aura/vds/compose/input/AuraTextInputKt;->AuraTextInput(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/JDN;LX/3PN;LX/3PP;LX/2WL;LX/2hg;ZIILX/JDN;LX/JDN;Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;LX/3Gw;ZZZZLX/2bW;LX/JDM;LX/2d4;IIII)V

    .line 332
    .line 333
    .line 334
    invoke-static {v2, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 335
    .line 336
    .line 337
    :goto_3
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 338
    .line 339
    invoke-static {v5, v3}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 340
    .line 341
    .line 342
    move-result-object v20

    .line 343
    move-object/from16 v21, v16

    .line 344
    .line 345
    move/from16 v22, v7

    .line 346
    .line 347
    move-object/from16 v23, v0

    .line 348
    .line 349
    move/from16 v24, v7

    .line 350
    .line 351
    move/from16 v25, v17

    .line 352
    .line 353
    invoke-static/range {v20 .. v25}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraDivider(LX/3C1;Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle;ZLX/2d4;II)V

    .line 354
    .line 355
    .line 356
    const v3, 0x7f12010f

    .line 357
    .line 358
    .line 359
    invoke-static {v0, v3}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v14

    .line 363
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 364
    .line 365
    .line 366
    move-result-object v3

    .line 367
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 368
    .line 369
    invoke-static {v0, v3, v11}, LX/008;->A0x(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v10

    .line 373
    check-cast v10, LX/3Bk;

    .line 374
    .line 375
    sget-object v3, LX/3Fe;->A0E:LX/Ip3;

    .line 376
    .line 377
    invoke-interface {v0, v3}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v12

    .line 381
    check-cast v12, LX/2M7;

    .line 382
    .line 383
    iget-object v3, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 384
    .line 385
    if-eqz v3, :cond_13

    .line 386
    .line 387
    iget-wide v3, v3, Lcom/facebook/aura/gateway/EditableMessageEditor;->messageRevision:J

    .line 388
    .line 389
    move-wide/from16 v20, v3

    .line 390
    .line 391
    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 392
    .line 393
    .line 394
    move-result-object v13

    .line 395
    :goto_4
    invoke-interface {v0, v12}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 396
    .line 397
    .line 398
    move-result v3

    .line 399
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 400
    .line 401
    .line 402
    move-result-object v4

    .line 403
    if-nez v3, :cond_b

    .line 404
    .line 405
    if-ne v4, v11, :cond_c

    .line 406
    .line 407
    :cond_b
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;

    .line 408
    .line 409
    move-object/from16 v3, v16

    .line 410
    .line 411
    invoke-direct {v4, v10, v12, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;-><init>(LX/3Bk;LX/2M7;LX/2M4;)V

    .line 412
    .line 413
    .line 414
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 415
    .line 416
    .line 417
    :cond_c
    invoke-static {v0, v4, v13}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 418
    .line 419
    .line 420
    iget-object v13, v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->body:Ljava/lang/String;

    .line 421
    .line 422
    and-int/lit8 v4, v1, 0x70

    .line 423
    .line 424
    move/from16 v3, v19

    .line 425
    .line 426
    if-eq v4, v3, :cond_d

    .line 427
    .line 428
    and-int/lit8 v1, v1, 0x40

    .line 429
    .line 430
    if-eqz v1, :cond_12

    .line 431
    .line 432
    move-object/from16 v1, p4

    .line 433
    .line 434
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 435
    .line 436
    .line 437
    move-result v1

    .line 438
    if-eqz v1, :cond_12

    .line 439
    .line 440
    :cond_d
    :goto_5
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v1

    .line 444
    if-nez v18, :cond_e

    .line 445
    .line 446
    if-ne v1, v11, :cond_f

    .line 447
    .line 448
    :cond_e
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$5$1;

    .line 449
    .line 450
    move-object/from16 v3, p4

    .line 451
    .line 452
    invoke-direct {v1, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$5$1;-><init>(Ljava/lang/Object;)V

    .line 453
    .line 454
    .line 455
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 456
    .line 457
    .line 458
    :cond_f
    check-cast v1, LX/DqV;

    .line 459
    .line 460
    invoke-static {v0, v6}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 461
    .line 462
    .line 463
    move-result-object v25

    .line 464
    const/4 v6, 0x3

    .line 465
    const/4 v4, -0x1

    .line 466
    new-instance v12, LX/3PN;

    .line 467
    .line 468
    move-object/from16 v3, v16

    .line 469
    .line 470
    invoke-direct {v12, v3, v6, v7, v4}, LX/3PN;-><init>(Ljava/lang/Boolean;III)V

    .line 471
    .line 472
    .line 473
    invoke-static {v5, v10}, LX/3De;->A00(LX/3C1;LX/3Bk;)LX/3C1;

    .line 474
    .line 475
    .line 476
    move-result-object v4

    .line 477
    invoke-interface {v0, v14}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 478
    .line 479
    .line 480
    move-result v5

    .line 481
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v3

    .line 485
    if-nez v5, :cond_10

    .line 486
    .line 487
    if-ne v3, v11, :cond_11

    .line 488
    .line 489
    :cond_10
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$6$1;

    .line 490
    .line 491
    invoke-direct {v3, v14}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$6$1;-><init>(Ljava/lang/String;)V

    .line 492
    .line 493
    .line 494
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 495
    .line 496
    .line 497
    :cond_11
    invoke-static {v4, v3, v7}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 498
    .line 499
    .line 500
    move-result-object v20

    .line 501
    check-cast v1, LX/JDM;

    .line 502
    .line 503
    const v43, 0xedb6a

    .line 504
    .line 505
    .line 506
    const/16 v28, 0x8

    .line 507
    .line 508
    const/16 v40, 0x6000

    .line 509
    .line 510
    move-object/from16 v18, v13

    .line 511
    .line 512
    move-object/from16 v19, v16

    .line 513
    .line 514
    move-object/from16 v21, v16

    .line 515
    .line 516
    move-object/from16 v22, v12

    .line 517
    .line 518
    move-object/from16 v23, v16

    .line 519
    .line 520
    move-object/from16 v24, v16

    .line 521
    .line 522
    move/from16 v26, v7

    .line 523
    .line 524
    move/from16 v27, v7

    .line 525
    .line 526
    move-object/from16 v29, v16

    .line 527
    .line 528
    move-object/from16 v30, v16

    .line 529
    .line 530
    move-object/from16 v31, v33

    .line 531
    .line 532
    move-object/from16 v32, v16

    .line 533
    .line 534
    move/from16 v33, v7

    .line 535
    .line 536
    move/from16 v34, v36

    .line 537
    .line 538
    move/from16 v35, v7

    .line 539
    .line 540
    move/from16 v36, v7

    .line 541
    .line 542
    move-object/from16 v37, v16

    .line 543
    .line 544
    move-object/from16 v38, v1

    .line 545
    .line 546
    move-object/from16 v39, v0

    .line 547
    .line 548
    move/from16 v41, v17

    .line 549
    .line 550
    move/from16 v42, v7

    .line 551
    .line 552
    invoke-static/range {v18 .. v43}, Lcom/facebook/aura/vds/compose/input/AuraTextInputKt;->AuraTextInput(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/JDN;LX/3PN;LX/3PP;LX/2WL;LX/2hg;ZIILX/JDN;LX/JDN;Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;LX/3Gw;ZZZZLX/2bW;LX/JDM;LX/2d4;IIII)V

    .line 553
    .line 554
    .line 555
    invoke-static {v2, v15}, LX/002;->A0Y(LX/J7I;LX/3C1;)LX/3C1;

    .line 556
    .line 557
    .line 558
    move-result-object v15

    .line 559
    goto :goto_6

    .line 560
    :cond_12
    const/16 v18, 0x0

    .line 561
    .line 562
    goto :goto_5

    .line 563
    :cond_13
    const/4 v13, 0x0

    .line 564
    goto/16 :goto_4

    .line 565
    .line 566
    :cond_14
    const/4 v5, 0x0

    .line 567
    goto/16 :goto_2

    .line 568
    .line 569
    :cond_15
    const v3, 0x21bdcc06

    .line 570
    .line 571
    .line 572
    invoke-static {v0, v3}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 573
    .line 574
    .line 575
    move-result-object v5

    .line 576
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 577
    .line 578
    invoke-static {v0, v2, v5, v3, v7}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 579
    .line 580
    .line 581
    goto/16 :goto_3

    .line 582
    .line 583
    :cond_16
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 584
    .line 585
    .line 586
    :goto_6
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 587
    .line 588
    .line 589
    move-result-object v1

    .line 590
    if-eqz v1, :cond_17

    .line 591
    .line 592
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$2;

    .line 593
    .line 594
    move-object/from16 v42, v0

    .line 595
    .line 596
    move-object/from16 v43, v9

    .line 597
    .line 598
    move-object/from16 p0, p4

    .line 599
    .line 600
    move-object/from16 p1, v15

    .line 601
    .line 602
    move/from16 p2, v8

    .line 603
    .line 604
    invoke-direct/range {v42 .. v47}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/3C1;II)V

    .line 605
    .line 606
    .line 607
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 608
    .line 609
    :cond_17
    return-void
.end method

.method public static final MessageEditorPageState(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 23

    .line 0
    move-object/from16 v6, p3

    .line 1
    .line 2
    const v1, 0x722aef17

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p5

    .line 11
    .line 12
    and-int/lit8 v2, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v2, :cond_8

    .line 17
    .line 18
    invoke-static {v4, v0, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    invoke-static {v2}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    or-int v9, v9, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v2, p5, 0x30

    .line 29
    .line 30
    const/16 v10, 0x20

    .line 31
    .line 32
    move-object/from16 v7, p1

    .line 33
    .line 34
    if-nez v2, :cond_0

    .line 35
    .line 36
    invoke-static {v7, v0, v1}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-static {v2}, LX/003;->A07(I)I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    or-int/2addr v9, v2

    .line 45
    :cond_0
    and-int/lit16 v2, v1, 0x180

    .line 46
    .line 47
    move-object/from16 v8, p2

    .line 48
    .line 49
    if-nez v2, :cond_1

    .line 50
    .line 51
    invoke-static {v0, v8}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    or-int/2addr v9, v2

    .line 56
    :cond_1
    and-int/lit8 v12, p6, 0x8

    .line 57
    .line 58
    if-eqz v12, :cond_7

    .line 59
    .line 60
    or-int/lit16 v9, v9, 0xc00

    .line 61
    .line 62
    :cond_2
    :goto_1
    and-int/lit16 v11, v9, 0x493

    .line 63
    .line 64
    const/16 v2, 0x492

    .line 65
    .line 66
    const/4 v3, 0x1

    .line 67
    const/4 v5, 0x0

    .line 68
    invoke-static {v11, v2}, LX/003;->A1H(II)Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    invoke-static {v2, v0, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-eqz v2, :cond_10

    .line 77
    .line 78
    if-eqz v12, :cond_3

    .line 79
    .line 80
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    :cond_3
    sget-object v2, LX/3Fe;->A05:LX/Ip3;

    .line 83
    .line 84
    invoke-interface {v0, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v14

    .line 88
    check-cast v14, LX/1Ju;

    .line 89
    .line 90
    sget-object v2, LX/3Fe;->A0E:LX/Ip3;

    .line 91
    .line 92
    invoke-interface {v0, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v13

    .line 96
    check-cast v13, LX/2M7;

    .line 97
    .line 98
    sget-object v12, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 99
    .line 100
    invoke-static {v0, v14, v13}, LX/004;->A1U(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v11

    .line 104
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    if-nez v11, :cond_4

    .line 109
    .line 110
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 111
    .line 112
    if-ne v2, v11, :cond_5

    .line 113
    .line 114
    :cond_4
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;

    .line 115
    .line 116
    invoke-direct {v2, v14, v13}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$1$1;-><init>(LX/1Ju;LX/2M7;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {v0, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :cond_5
    check-cast v2, LX/JDM;

    .line 123
    .line 124
    invoke-static {v0, v12, v2}, LX/CdB;->A05(LX/2d4;Ljava/lang/Object;LX/JDM;)V

    .line 125
    .line 126
    .line 127
    iget-boolean v2, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 128
    .line 129
    const/4 v12, 0x0

    .line 130
    if-eqz v2, :cond_9

    .line 131
    .line 132
    const v2, -0x2db3ed67

    .line 133
    .line 134
    .line 135
    invoke-static {v0, v2}, LX/002;->A0t(LX/2d4;I)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v9

    .line 139
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 140
    .line 141
    if-ne v9, v2, :cond_6

    .line 142
    .line 143
    sget-object v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$2$1;

    .line 144
    .line 145
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_6
    invoke-static {v6, v9, v5}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 149
    .line 150
    .line 151
    move-result-object v10

    .line 152
    sget-object v11, LX/2Id;->A00:LX/2sS;

    .line 153
    .line 154
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 155
    .line 156
    sget-object v2, LX/2Id;->A04:LX/2rU;

    .line 157
    .line 158
    invoke-static {v2, v9}, LX/Dn6;->A02(LX/2rU;F)LX/CP5;

    .line 159
    .line 160
    .line 161
    move-result-object v9

    .line 162
    const/16 v2, 0x30

    .line 163
    .line 164
    invoke-static {v9, v0, v11, v2}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 165
    .line 166
    .line 167
    move-result-object v14

    .line 168
    move-object v2, v0

    .line 169
    check-cast v2, LX/J7I;

    .line 170
    .line 171
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 172
    .line 173
    .line 174
    move-result v13

    .line 175
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 176
    .line 177
    .line 178
    move-result-object v12

    .line 179
    invoke-static {v0, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 180
    .line 181
    .line 182
    move-result-object v11

    .line 183
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 184
    .line 185
    iget-object v9, v2, LX/J7I;->A0V:LX/3DJ;

    .line 186
    .line 187
    if-nez v9, :cond_11

    .line 188
    .line 189
    invoke-static {}, LX/1VY;->A00()V

    .line 190
    .line 191
    .line 192
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    throw v0

    .line 197
    :cond_7
    and-int/lit16 v2, v1, 0xc00

    .line 198
    .line 199
    if-nez v2, :cond_2

    .line 200
    .line 201
    invoke-static {v0, v6}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 202
    .line 203
    .line 204
    move-result v2

    .line 205
    or-int/2addr v9, v2

    .line 206
    goto/16 :goto_1

    .line 207
    .line 208
    :cond_8
    move v9, v1

    .line 209
    goto/16 :goto_0

    .line 210
    .line 211
    :cond_9
    const v2, -0x2dacb3f0

    .line 212
    .line 213
    .line 214
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 215
    .line 216
    .line 217
    iget-boolean v11, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 218
    .line 219
    const v2, 0x7f120115

    .line 220
    .line 221
    .line 222
    if-eqz v11, :cond_a

    .line 223
    .line 224
    const v2, 0x7f12011b

    .line 225
    .line 226
    .line 227
    :cond_a
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v11

    .line 231
    iget-boolean v2, v4, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 232
    .line 233
    if-eqz v2, :cond_b

    .line 234
    .line 235
    const v2, -0x2da89c9a

    .line 236
    .line 237
    .line 238
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 239
    .line 240
    .line 241
    :goto_2
    invoke-static {v0}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 242
    .line 243
    .line 244
    move-result-object v2

    .line 245
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 246
    .line 247
    sget-object v14, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 248
    .line 249
    sget-object v15, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 250
    .line 251
    sget-object v16, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_SINGLE_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 252
    .line 253
    shr-int/lit8 v3, v9, 0x3

    .line 254
    .line 255
    and-int/lit16 v3, v3, 0x380

    .line 256
    .line 257
    const v10, 0x36c00

    .line 258
    .line 259
    .line 260
    or-int/2addr v3, v10

    .line 261
    shl-int/lit8 v9, v9, 0xc

    .line 262
    .line 263
    invoke-static {v9, v3}, LX/001;->A06(II)I

    .line 264
    .line 265
    .line 266
    move-result v20

    .line 267
    const/16 v21, 0x80

    .line 268
    .line 269
    const/16 v18, 0x0

    .line 270
    .line 271
    move-object/from16 v17, v8

    .line 272
    .line 273
    move-object/from16 v19, v0

    .line 274
    .line 275
    move-object v13, v6

    .line 276
    invoke-static/range {v11 .. v21}, Lcom/facebook/aura/ui/HatchScreenErrorStateKt;->HatchScreenErrorState(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Ljava/lang/String;Ljava/util/Map;LX/2d4;II)V

    .line 277
    .line 278
    .line 279
    goto :goto_4

    .line 280
    :cond_b
    const v2, -0x2da87446

    .line 281
    .line 282
    .line 283
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 284
    .line 285
    .line 286
    and-int/lit8 v2, v9, 0x70

    .line 287
    .line 288
    if-eq v2, v10, :cond_c

    .line 289
    .line 290
    and-int/lit8 v2, v9, 0x40

    .line 291
    .line 292
    if-eqz v2, :cond_f

    .line 293
    .line 294
    invoke-interface {v0, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v2

    .line 298
    if-eqz v2, :cond_f

    .line 299
    .line 300
    :cond_c
    :goto_3
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v12

    .line 304
    if-nez v3, :cond_d

    .line 305
    .line 306
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 307
    .line 308
    if-ne v12, v2, :cond_e

    .line 309
    .line 310
    :cond_d
    new-instance v12, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$4$1;

    .line 311
    .line 312
    invoke-direct {v12, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$4$1;-><init>(Ljava/lang/Object;)V

    .line 313
    .line 314
    .line 315
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    :cond_e
    check-cast v12, LX/DqV;

    .line 319
    .line 320
    goto :goto_2

    .line 321
    :cond_f
    const/4 v3, 0x0

    .line 322
    goto :goto_3

    .line 323
    :cond_10
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 324
    .line 325
    .line 326
    goto :goto_5

    .line 327
    :cond_11
    invoke-static {v0, v2, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 328
    .line 329
    .line 330
    invoke-static {v0, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 331
    .line 332
    .line 333
    const/16 v16, 0x7

    .line 334
    .line 335
    const/4 v11, 0x0

    .line 336
    const-wide/16 v12, 0x0

    .line 337
    .line 338
    move-object v10, v11

    .line 339
    move-object v14, v0

    .line 340
    move v15, v5

    .line 341
    invoke-static/range {v10 .. v16}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerKt;->AuraSpinner-FNF3uiM(LX/3C1;Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;JLX/2d4;II)V

    .line 342
    .line 343
    .line 344
    const v9, 0x7f1202bb

    .line 345
    .line 346
    .line 347
    invoke-static {v0, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 348
    .line 349
    .line 350
    move-result-object v10

    .line 351
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 352
    .line 353
    invoke-static {v0, v9}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 354
    .line 355
    .line 356
    move-result-object v14

    .line 357
    invoke-static {v0, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 358
    .line 359
    .line 360
    move-result-wide v12

    .line 361
    const/16 p5, 0x3ff2

    .line 362
    .line 363
    move-object v15, v11

    .line 364
    move-object/from16 v16, v11

    .line 365
    .line 366
    move-object/from16 v17, v11

    .line 367
    .line 368
    move/from16 v19, v5

    .line 369
    .line 370
    move/from16 v20, v5

    .line 371
    .line 372
    move/from16 v21, v5

    .line 373
    .line 374
    move-object/from16 v22, v11

    .line 375
    .line 376
    move-object/from16 p0, v11

    .line 377
    .line 378
    move-object/from16 p1, v11

    .line 379
    .line 380
    move-object/from16 p2, v0

    .line 381
    .line 382
    move/from16 p3, v5

    .line 383
    .line 384
    move/from16 p4, v5

    .line 385
    .line 386
    move/from16 v18, v5

    .line 387
    .line 388
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 389
    .line 390
    .line 391
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 392
    .line 393
    .line 394
    :goto_4
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 395
    .line 396
    .line 397
    :goto_5
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 398
    .line 399
    .line 400
    move-result-object v2

    .line 401
    if-eqz v2, :cond_12

    .line 402
    .line 403
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$5;

    .line 404
    .line 405
    move-object/from16 p0, v0

    .line 406
    .line 407
    move-object/from16 p1, v4

    .line 408
    .line 409
    move-object/from16 p2, v7

    .line 410
    .line 411
    move-object/from16 p3, v8

    .line 412
    .line 413
    move-object/from16 p4, v6

    .line 414
    .line 415
    move/from16 p5, v1

    .line 416
    .line 417
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorPageState$5;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/3C1;II)V

    .line 418
    .line 419
    .line 420
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 421
    .line 422
    :cond_12
    return-void
.end method

.method public static final MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 20

    .line 0
    move-object/from16 v1, p2

    .line 1
    .line 2
    const v0, 0x3487c4bc

    .line 3
    .line 4
    .line 5
    move-object/from16 v5, p3

    .line 6
    .line 7
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move/from16 v4, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v5, v4}, LX/004;->A0E(LX/2d4;I)I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    or-int v8, v8, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v3, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v5, v3}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v8, v0

    .line 35
    :cond_0
    and-int/lit8 v7, p5, 0x4

    .line 36
    .line 37
    if-eqz v7, :cond_5

    .line 38
    .line 39
    or-int/lit16 v8, v8, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v6, v8, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v14, 0x0

    .line 46
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, v5, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_4

    .line 55
    .line 56
    if-eqz v7, :cond_2

    .line 57
    .line 58
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    invoke-static {v5, v3, v4}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 65
    .line 66
    invoke-static {v5, v0}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 67
    .line 68
    .line 69
    move-result-object v10

    .line 70
    invoke-static {v5, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 71
    .line 72
    .line 73
    move-result-wide v8

    .line 74
    const/4 v11, 0x0

    .line 75
    invoke-static {v1}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 76
    .line 77
    .line 78
    move-result-object v7

    .line 79
    const/16 p4, 0x3ff0

    .line 80
    .line 81
    move-object v12, v11

    .line 82
    move-object v13, v11

    .line 83
    move v15, v14

    .line 84
    move/from16 v16, v14

    .line 85
    .line 86
    move/from16 v17, v14

    .line 87
    .line 88
    move-object/from16 v18, v11

    .line 89
    .line 90
    move-object/from16 v19, v11

    .line 91
    .line 92
    move-object/from16 p0, v11

    .line 93
    .line 94
    move-object/from16 p1, v5

    .line 95
    .line 96
    move/from16 p2, v14

    .line 97
    .line 98
    move/from16 p3, v14

    .line 99
    .line 100
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 101
    .line 102
    .line 103
    :goto_2
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    if-eqz v5, :cond_3

    .line 108
    .line 109
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorRecipientRow$1;

    .line 110
    .line 111
    move-object/from16 p0, v0

    .line 112
    .line 113
    move/from16 p1, v4

    .line 114
    .line 115
    move-object/from16 p2, v3

    .line 116
    .line 117
    move-object/from16 p3, v1

    .line 118
    .line 119
    move/from16 p4, v2

    .line 120
    .line 121
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorRecipientRow$1;-><init>(ILjava/lang/String;LX/3C1;II)V

    .line 122
    .line 123
    .line 124
    iput-object v0, v5, LX/J7V;->A06:LX/JDN;

    .line 125
    .line 126
    :cond_3
    return-void

    .line 127
    :cond_4
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 128
    .line 129
    .line 130
    goto :goto_2

    .line 131
    :cond_5
    and-int/lit16 v0, v2, 0x180

    .line 132
    .line 133
    if-nez v0, :cond_1

    .line 134
    .line 135
    invoke-static {v5, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    or-int/2addr v8, v0

    .line 140
    goto :goto_1

    .line 141
    :cond_6
    move v8, v2

    .line 142
    goto :goto_0
.end method

.method public static final MessageEditorRecipients(Lcom/facebook/aura/gateway/EditableMessage;LX/3C1;LX/2d4;II)V
    .locals 10

    .line 0
    const v0, 0x4b1e90f0    # 1.0391792E7f

    .line 1
    .line 2
    .line 3
    move-object v7, p2

    .line 4
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 8
    .line 9
    if-nez v0, :cond_3

    .line 10
    .line 11
    invoke-static {p0, p2, p3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, LX/003;->A06(I)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    or-int/2addr v3, p3

    .line 20
    :goto_0
    and-int/lit8 v2, p4, 0x2

    .line 21
    .line 22
    if-eqz v2, :cond_2

    .line 23
    .line 24
    or-int/lit8 v3, v3, 0x30

    .line 25
    .line 26
    :cond_0
    :goto_1
    and-int/lit8 v1, v3, 0x13

    .line 27
    .line 28
    const/16 v0, 0x12

    .line 29
    .line 30
    const/4 v8, 0x0

    .line 31
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, p2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_4

    .line 40
    .line 41
    if-eqz v2, :cond_1

    .line 42
    .line 43
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 44
    .line 45
    :cond_1
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 46
    .line 47
    invoke-static {p2, v0, v8}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    move-object v0, v7

    .line 52
    check-cast v0, LX/J7I;

    .line 53
    .line 54
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    invoke-static {p2, p1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    sget-object v2, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 67
    .line 68
    iget-object v1, v0, LX/J7I;->A0V:LX/3DJ;

    .line 69
    .line 70
    if-nez v1, :cond_5

    .line 71
    .line 72
    invoke-static {}, LX/1VY;->A00()V

    .line 73
    .line 74
    .line 75
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    throw v0

    .line 80
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 81
    .line 82
    if-nez v0, :cond_0

    .line 83
    .line 84
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    or-int/2addr v3, v0

    .line 89
    goto :goto_1

    .line 90
    :cond_3
    move v3, p3

    .line 91
    goto :goto_0

    .line 92
    :cond_4
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 93
    .line 94
    .line 95
    goto :goto_5

    .line 96
    :cond_5
    invoke-static {p2, v0, v2}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 97
    .line 98
    .line 99
    invoke-static {p2, v6, v4, v3, v5}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 100
    .line 101
    .line 102
    iget-object v5, p0, Lcom/facebook/aura/gateway/EditableMessage;->from:Ljava/lang/String;

    .line 103
    .line 104
    if-nez v5, :cond_9

    .line 105
    .line 106
    const v1, -0x298245c5

    .line 107
    .line 108
    .line 109
    invoke-interface {p2, v1}, LX/2d4;->Agj(I)V

    .line 110
    .line 111
    .line 112
    :goto_2
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 113
    .line 114
    .line 115
    const v4, 0x7f12011a

    .line 116
    .line 117
    .line 118
    iget-object v3, p0, Lcom/facebook/aura/gateway/EditableMessage;->to:Ljava/util/List;

    .line 119
    .line 120
    const-string v2, ", "

    .line 121
    .line 122
    const/4 v6, 0x0

    .line 123
    const-string v1, ""

    .line 124
    .line 125
    invoke-static {v2, v1, v1, v3, v6}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    const/4 v9, 0x4

    .line 130
    invoke-static/range {v4 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 131
    .line 132
    .line 133
    iget-object v3, p0, Lcom/facebook/aura/gateway/EditableMessage;->cc:Ljava/util/List;

    .line 134
    .line 135
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    if-nez v3, :cond_8

    .line 140
    .line 141
    const v3, -0x297f1c03

    .line 142
    .line 143
    .line 144
    invoke-interface {p2, v3}, LX/2d4;->Agj(I)V

    .line 145
    .line 146
    .line 147
    const v4, 0x7f120111

    .line 148
    .line 149
    .line 150
    iget-object v3, p0, Lcom/facebook/aura/gateway/EditableMessage;->cc:Ljava/util/List;

    .line 151
    .line 152
    invoke-static {v2, v1, v1, v3, v6}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    invoke-static/range {v4 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 157
    .line 158
    .line 159
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 160
    .line 161
    .line 162
    :goto_3
    iget-object v3, p0, Lcom/facebook/aura/gateway/EditableMessage;->bcc:Ljava/util/List;

    .line 163
    .line 164
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 165
    .line 166
    .line 167
    move-result v3

    .line 168
    if-nez v3, :cond_7

    .line 169
    .line 170
    const v3, -0x297cf202

    .line 171
    .line 172
    .line 173
    invoke-interface {p2, v3}, LX/2d4;->Agj(I)V

    .line 174
    .line 175
    .line 176
    const v4, 0x7f12010e

    .line 177
    .line 178
    .line 179
    iget-object v3, p0, Lcom/facebook/aura/gateway/EditableMessage;->bcc:Ljava/util/List;

    .line 180
    .line 181
    invoke-static {v2, v1, v1, v3, v6}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v5

    .line 185
    invoke-static/range {v4 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 186
    .line 187
    .line 188
    :goto_4
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 189
    .line 190
    .line 191
    :goto_5
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    if-eqz v1, :cond_6

    .line 196
    .line 197
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorRecipients$2;

    .line 198
    .line 199
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorRecipients$2;-><init>(Lcom/facebook/aura/gateway/EditableMessage;LX/3C1;II)V

    .line 200
    .line 201
    .line 202
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 203
    .line 204
    :cond_6
    return-void

    .line 205
    :cond_7
    const v1, -0x297aebf8

    .line 206
    .line 207
    .line 208
    invoke-interface {p2, v1}, LX/2d4;->Agj(I)V

    .line 209
    .line 210
    .line 211
    goto :goto_4

    .line 212
    :cond_8
    const v3, -0x297d8a58

    .line 213
    .line 214
    .line 215
    invoke-interface {p2, v3}, LX/2d4;->Agj(I)V

    .line 216
    .line 217
    .line 218
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 219
    .line 220
    .line 221
    goto :goto_3

    .line 222
    :cond_9
    const v1, -0x298245c4

    .line 223
    .line 224
    .line 225
    invoke-interface {p2, v1}, LX/2d4;->Agj(I)V

    .line 226
    .line 227
    .line 228
    const v4, 0x7f120113

    .line 229
    .line 230
    .line 231
    const/4 v9, 0x4

    .line 232
    const/4 v6, 0x0

    .line 233
    invoke-static/range {v4 .. v9}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 234
    .line 235
    .line 236
    goto :goto_2
.end method

.method public static final synthetic access$AgentPermissionMessageEditorScreen$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$MessageEditorAttachments(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorAttachments(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MessageEditorFields(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorFields(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MessageEditorPageState(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorPageState(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipientRow(ILjava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$MessageEditorRecipients(Lcom/facebook/aura/gateway/EditableMessage;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipients(Lcom/facebook/aura/gateway/EditableMessage;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
