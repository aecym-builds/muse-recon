.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final awaitingApproval:Z

.field public final confirming:Z

.field public final submitting:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 1
    .line 2
    sput v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->$stable:I

    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 8
    .line 9
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZILX/04f;)V
    .locals 3

    .line 268435456
    invoke-static {p5, p2}, LX/3Rr;->A1O(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v2

    .line 268435460
    invoke-static {p5, p3}, LX/006;->A1X(IZ)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v1

    .line 268435464
    invoke-static {p5, p4}, LX/3Rr;->A1P(IZ)Z

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    invoke-direct {p0, p1, v2, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZILjava/lang/Object;)Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 23
    .line 24
    :cond_3
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 25
    .line 26
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;ZZZ)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 27
    .line 28
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 29
    .line 30
    if-ne v1, v0, :cond_0

    .line 31
    .line 32
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 33
    .line 34
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 35
    .line 36
    if-eq v1, v0, :cond_1

    .line 37
    .line 38
    :cond_0
    return v2

    .line 39
    :cond_1
    return v3
.end method

.method public final getApproval()Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAwaitingApproval()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getConfirming()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSubmitting()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->submitting:Z

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->awaitingApproval:Z

    .line 15
    .line 16
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionUiState;->confirming:Z

    .line 21
    .line 22
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
