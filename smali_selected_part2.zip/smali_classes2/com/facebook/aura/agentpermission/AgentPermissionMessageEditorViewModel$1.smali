.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorViewModel$1"
    f = "AgentPermissionMessageEditorViewModel.kt"
    l = {
        0x5c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v5, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v6

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 19
    .line 20
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->repository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 21
    .line 22
    iget-object v4, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->pendingApprovals:LX/2J3;

    .line 23
    .line 24
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->gatewayPrefs:Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;

    .line 25
    .line 26
    iget-object v3, v0, Lcom/facebook/aura/gateway/store/HatchGatewayPrefsStore;->hatcheryVmIdFlow:LX/2J3;

    .line 27
    .line 28
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 29
    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getState()LX/2J3;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    const/4 v1, 0x0

    .line 35
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;

    .line 36
    .line 37
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$1;-><init>(LX/2M4;)V

    .line 38
    .line 39
    .line 40
    invoke-static {v0, v4, v3, v2}, LX/EXj;->A00(LX/JDO;LX/2Lw;LX/2Lw;LX/2Lw;)LX/5zp;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 45
    .line 46
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;

    .line 47
    .line 48
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1$2;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;)V

    .line 49
    .line 50
    .line 51
    iput v5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel$1;->label:I

    .line 52
    .line 53
    invoke-virtual {v2, v0, p0}, LX/5zp;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-ne v0, v6, :cond_0

    .line 58
    .line 59
    return-object v6

    .line 60
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    throw v0
.end method
