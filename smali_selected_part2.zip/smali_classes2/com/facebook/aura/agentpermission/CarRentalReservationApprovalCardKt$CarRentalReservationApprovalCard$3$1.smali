.class public final Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 0
    and-int/lit8 v1, p2, 0x3

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    const/4 v9, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object v8, p1

    .line 10
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 17
    .line 18
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;->$stable:I

    .line 19
    .line 20
    invoke-static {v1, p1, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDetailRows(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;LX/2d4;I)V

    .line 21
    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-static {v4, p1, v9, v2}, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt;->CarRentalReservationDivider(LX/3C1;LX/2d4;II)V

    .line 25
    .line 26
    .line 27
    const v0, 0x7f12063b

    .line 28
    .line 29
    .line 30
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/CarRentalReservationApprovalCardKt$CarRentalReservationApprovalCard$3$1;->$checkout:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 35
    .line 36
    invoke-static {}, LX/3Rr;->A0v()Ljava/util/Locale;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-static {v1, v0}, Lcom/facebook/aura/agentpermission/CarRentalReservationFormattingKt;->formattedTotal(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;Ljava/util/Locale;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    const/16 p0, 0x3c

    .line 45
    .line 46
    move-object v5, v4

    .line 47
    move-object v6, v4

    .line 48
    move-object v7, v4

    .line 49
    invoke-static/range {v2 .. v10}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->CheckoutTotalRow(Ljava/lang/String;Ljava/lang/String;LX/3C1;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Ljava/lang/String;LX/2d4;II)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    return-void
.end method
