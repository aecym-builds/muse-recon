.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionBannerKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionBanner(Ljava/lang/String;LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/3C1;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p1

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    move-object/from16 v8, p2

    .line 4
    .line 5
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x1084d922

    .line 9
    .line 10
    .line 11
    move-object/from16 v7, p3

    .line 12
    .line 13
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v6, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_4

    .line 21
    .line 22
    invoke-static {v7, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    or-int v5, v5, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v1, p5, 0x2

    .line 29
    .line 30
    if-eqz v1, :cond_3

    .line 31
    .line 32
    or-int/lit8 v5, v5, 0x30

    .line 33
    .line 34
    :cond_0
    :goto_1
    and-int/lit16 v0, v6, 0x180

    .line 35
    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    invoke-static {v7, v8}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v5, v0

    .line 43
    :cond_1
    invoke-static {v5}, LX/005;->A1I(I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0, v7, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_6

    .line 52
    .line 53
    if-eqz v1, :cond_2

    .line 54
    .line 55
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 56
    .line 57
    :cond_2
    invoke-static {v7}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->INSTANCE:Lcom/facebook/aura/gateway/ApprovalConversationIdentity;

    .line 62
    .line 63
    invoke-virtual {v0, p0}, Lcom/facebook/aura/gateway/ApprovalConversationIdentity;->normalize(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    const-string v0, "agent_permission_banner_"

    .line 68
    .line 69
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v10

    .line 73
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;

    .line 74
    .line 75
    invoke-direct {v3, v2, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;-><init>(LX/AHE;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-static {v7}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-eqz v2, :cond_5

    .line 83
    .line 84
    invoke-static {v2}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    const-class v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 89
    .line 90
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    const/4 v4, 0x0

    .line 95
    invoke-static {v3, v2, v1, v10, v0}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 100
    .line 101
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;->uiState:LX/2J3;

    .line 102
    .line 103
    const/16 p1, 0x0

    .line 104
    .line 105
    invoke-static {v7, v0, v4}, LX/3Rr;->A0Z(LX/2d4;LX/2J3;I)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;

    .line 110
    .line 111
    iget-object v14, v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;->approvals:Ljava/util/List;

    .line 112
    .line 113
    invoke-interface {v14}, Ljava/util/List;->isEmpty()Z

    .line 114
    .line 115
    .line 116
    move-result v13

    .line 117
    invoke-static {v9}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    invoke-static {v4}, LX/001;->A0g(Z)LX/3BI;

    .line 122
    .line 123
    .line 124
    move-result-object v12

    .line 125
    move-object v3, v7

    .line 126
    check-cast v3, LX/J7I;

    .line 127
    .line 128
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 129
    .line 130
    .line 131
    move-result v11

    .line 132
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 133
    .line 134
    .line 135
    move-result-object v10

    .line 136
    invoke-static {v7, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 137
    .line 138
    .line 139
    move-result-object v2

    .line 140
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 141
    .line 142
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 143
    .line 144
    if-nez v0, :cond_7

    .line 145
    .line 146
    invoke-static {}, LX/1VY;->A00()V

    .line 147
    .line 148
    .line 149
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    throw v0

    .line 154
    :cond_3
    and-int/lit8 v0, p4, 0x30

    .line 155
    .line 156
    if-nez v0, :cond_0

    .line 157
    .line 158
    invoke-static {v7, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    or-int/2addr v5, v0

    .line 163
    goto/16 :goto_1

    .line 164
    .line 165
    :cond_4
    move v5, v6

    .line 166
    goto/16 :goto_0

    .line 167
    .line 168
    :cond_5
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    throw v0

    .line 173
    :cond_6
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 174
    .line 175
    .line 176
    goto :goto_3

    .line 177
    :cond_7
    invoke-static {v7, v3, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 178
    .line 179
    .line 180
    invoke-static {v7, v12, v10, v2, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 181
    .line 182
    .line 183
    if-nez v13, :cond_a

    .line 184
    .line 185
    const v0, 0x381a7cf5

    .line 186
    .line 187
    .line 188
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 189
    .line 190
    .line 191
    shl-int/lit8 v0, v5, 0x3

    .line 192
    .line 193
    and-int/lit8 p3, v0, 0x70

    .line 194
    .line 195
    const/16 p4, 0x4

    .line 196
    .line 197
    move-object/from16 p2, v7

    .line 198
    .line 199
    invoke-static/range {v14 .. v19}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt;->AgentPermissionBannerCard(Ljava/util/List;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 200
    .line 201
    .line 202
    :goto_2
    invoke-static {v3, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 203
    .line 204
    .line 205
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 206
    .line 207
    if-nez v13, :cond_8

    .line 208
    .line 209
    const/high16 v0, 0x41f00000    # 30.0f

    .line 210
    .line 211
    invoke-static {v1, v0}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 212
    .line 213
    .line 214
    move-result-object v1

    .line 215
    :cond_8
    shr-int/lit8 v0, v5, 0x3

    .line 216
    .line 217
    and-int/lit8 v0, v0, 0x70

    .line 218
    .line 219
    invoke-static {v1, v7, v8, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 220
    .line 221
    .line 222
    invoke-static {v3, v9}, LX/002;->A0Y(LX/J7I;LX/3C1;)LX/3C1;

    .line 223
    .line 224
    .line 225
    move-result-object v9

    .line 226
    :goto_3
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    if-eqz v1, :cond_9

    .line 231
    .line 232
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerKt$AgentPermissionBanner$2;

    .line 233
    .line 234
    move-object/from16 p1, p0

    .line 235
    .line 236
    move-object/from16 p2, v9

    .line 237
    .line 238
    move-object/from16 p3, v8

    .line 239
    .line 240
    move/from16 p4, v6

    .line 241
    .line 242
    move-object p0, v0

    .line 243
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerKt$AgentPermissionBanner$2;-><init>(Ljava/lang/String;LX/3C1;LX/JDQ;II)V

    .line 244
    .line 245
    .line 246
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 247
    .line 248
    :cond_9
    return-void

    .line 249
    :cond_a
    const v0, 0x381bbc0a    # 3.7130005E-5f

    .line 250
    .line 251
    .line 252
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 253
    .line 254
    .line 255
    goto :goto_2
.end method

.method public static final AgentPermissionBanner$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerUiState;

    .line 5
    .line 6
    return-object p0
.end method
