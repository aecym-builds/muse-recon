.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDQ<",
        "Ljava/lang/Boolean;",
        "Ljava/lang/Boolean;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionNotificationRepository$start$surface$1"
    f = "AgentPermissionNotificationRepository.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic Z$0:Z

.field public synthetic Z$1:Z

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    invoke-static {p2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    check-cast p3, LX/2M4;

    .line 9
    .line 10
    invoke-virtual {p0, v1, v0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->invoke(ZZLX/2M4;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public final invoke(ZZLX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;

    .line 268435457
    .line 268435458
    invoke-direct {p0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    iput-boolean p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->Z$0:Z

    .line 268435462
    .line 268435463
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->Z$1:Z

    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-boolean v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->Z$0:Z

    .line 1
    .line 2
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->Z$1:Z

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$surface$1;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_2

    .line 7
    .line 8
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->IN_APP:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    if-eqz v1, :cond_1

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->NOTIFICATION:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 19
    .line 20
    return-object v0

    .line 21
    :cond_1
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;->NONE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$ApprovalSurface;

    .line 22
    .line 23
    return-object v0

    .line 24
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    throw v0
.end method
