.class public final Lcom/facebook/aura/agentpermission/ApprovalHistoryState;
.super LX/07H;
.source ""


# instance fields
.field public final canLoadMore:Z

.field public final isLoadingMore:Z

.field public final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

.field public final nextCursor:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 0
    const/4 v3, 0x0

    .line 1
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 2
    .line 3
    sget-object v2, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    const/4 v4, 0x1

    .line 7
    move-object v0, p0

    .line 8
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;",
            "Ljava/lang/String;",
            "ZZ)V"
        }
    .end annotation

    .line 536870912
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870916
    .line 536870917
    .line 536870918
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 536870919
    .line 536870920
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 536870921
    .line 536870922
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 536870923
    .line 536870924
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 536870925
    .line 536870926
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 536870927
    .line 536870928
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZILX/04f;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p6}, LX/3Rr;->A0s(Ljava/util/List;I)Ljava/util/List;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    and-int/lit8 v0, p6, 0x2

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    sget-object p2, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 268435465
    .line 268435466
    :cond_0
    invoke-static {p6, p3}, LX/3Rr;->A0f(ILjava/lang/String;)Ljava/lang/String;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object p3

    .line 268435470
    and-int/lit8 v0, p6, 0x8

    .line 268435471
    .line 268435472
    if-eqz v0, :cond_1

    .line 268435473
    .line 268435474
    const/4 p4, 0x1

    .line 268435475
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 268435476
    .line 268435477
    invoke-static {v0, p5}, LX/001;->A1P(IZ)Z

    .line 268435478
    .line 268435479
    .line 268435480
    move-result p5

    .line 268435481
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)V

    .line 268435482
    .line 268435483
    .line 268435484
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/ApprovalHistoryState;Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZILjava/lang/Object;)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;",
            "Ljava/lang/String;",
            "ZZ)",
            "Lcom/facebook/aura/agentpermission/ApprovalHistoryState;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;-><init>(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 37
    .line 38
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 43
    .line 44
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 45
    .line 46
    if-eq v1, v0, :cond_1

    .line 47
    .line 48
    :cond_0
    return v2

    .line 49
    :cond_1
    return v3
.end method

.method public final getCanLoadMore()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getItems()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoadingState()Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getNextCursor()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 22
    .line 23
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 28
    .line 29
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    return v0
.end method

.method public final isLoadingMore()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->isLoadingMore:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
