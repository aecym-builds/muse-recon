.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionRequestPreviewContent-hYmLsZ8(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V
    .locals 35

    .line 0
    move-object/from16 v4, p7

    .line 1
    .line 2
    const/4 v1, 0x2

    .line 3
    move-object/from16 v20, p2

    .line 4
    .line 5
    move-object/from16 v0, v20

    .line 6
    .line 7
    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    move-object/from16 v14, p5

    .line 11
    .line 12
    move-object/from16 p7, p6

    .line 13
    .line 14
    move-object/from16 v0, p7

    .line 15
    .line 16
    invoke-static {v14, v0}, LX/004;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const v1, 0x75a44887

    .line 20
    .line 21
    .line 22
    move-object/from16 v0, p8

    .line 23
    .line 24
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 25
    .line 26
    .line 27
    move/from16 v3, p9

    .line 28
    .line 29
    and-int/lit8 v1, p9, 0x6

    .line 30
    .line 31
    move-object/from16 v6, p0

    .line 32
    .line 33
    if-nez v1, :cond_15

    .line 34
    .line 35
    invoke-static {v6, v0, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    invoke-static {v1}, LX/003;->A06(I)I

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    or-int v5, v5, p9

    .line 44
    .line 45
    :goto_0
    and-int/lit8 v1, p9, 0x30

    .line 46
    .line 47
    move-object/from16 v16, p1

    .line 48
    .line 49
    if-nez v1, :cond_0

    .line 50
    .line 51
    move-object/from16 v1, v16

    .line 52
    .line 53
    invoke-static {v0, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    or-int/2addr v5, v1

    .line 58
    :cond_0
    and-int/lit16 v1, v3, 0x180

    .line 59
    .line 60
    if-nez v1, :cond_1

    .line 61
    .line 62
    move-object/from16 v1, v20

    .line 63
    .line 64
    invoke-static {v0, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    or-int/2addr v5, v1

    .line 69
    :cond_1
    and-int/lit16 v1, v3, 0xc00

    .line 70
    .line 71
    move-wide/from16 p8, p3

    .line 72
    .line 73
    if-nez v1, :cond_2

    .line 74
    .line 75
    move-wide/from16 v1, p8

    .line 76
    .line 77
    invoke-static {v0, v1, v2}, LX/004;->A0O(LX/2d4;J)I

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    or-int/2addr v5, v1

    .line 82
    :cond_2
    and-int/lit16 v1, v3, 0x6000

    .line 83
    .line 84
    if-nez v1, :cond_3

    .line 85
    .line 86
    const v1, 0x8000

    .line 87
    .line 88
    .line 89
    invoke-static {v0, v14, v1, v3}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    invoke-static {v1}, LX/3Rp;->A00(I)I

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    or-int/2addr v5, v1

    .line 98
    :cond_3
    const/high16 v1, 0x30000

    .line 99
    .line 100
    and-int/2addr v1, v3

    .line 101
    if-nez v1, :cond_4

    .line 102
    .line 103
    invoke-virtual/range {p7 .. p7}, Ljava/lang/Enum;->ordinal()I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    invoke-static {v0, v1}, LX/008;->A0M(LX/2d4;I)I

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    or-int/2addr v5, v1

    .line 112
    :cond_4
    move/from16 p6, p10

    .line 113
    .line 114
    and-int/lit8 v8, p10, 0x40

    .line 115
    .line 116
    const/high16 v1, 0x180000

    .line 117
    .line 118
    if-nez v8, :cond_5

    .line 119
    .line 120
    and-int/2addr v1, v3

    .line 121
    if-nez v1, :cond_6

    .line 122
    .line 123
    invoke-static {v0, v4}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 124
    .line 125
    .line 126
    move-result v1

    .line 127
    :cond_5
    or-int/2addr v5, v1

    .line 128
    :cond_6
    const v7, 0x92493

    .line 129
    .line 130
    .line 131
    and-int/2addr v7, v5

    .line 132
    const v2, 0x92492

    .line 133
    .line 134
    .line 135
    const/4 v1, 0x0

    .line 136
    invoke-static {v7, v2}, LX/003;->A1H(II)Z

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    invoke-static {v2, v0, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 141
    .line 142
    .line 143
    move-result v2

    .line 144
    if-eqz v2, :cond_12

    .line 145
    .line 146
    if-eqz v8, :cond_7

    .line 147
    .line 148
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 149
    .line 150
    :cond_7
    const/16 v21, 0x0

    .line 151
    .line 152
    if-nez p0, :cond_a

    .line 153
    .line 154
    const v2, 0x18d8b5cc

    .line 155
    .line 156
    .line 157
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 158
    .line 159
    .line 160
    if-eqz p1, :cond_9

    .line 161
    .line 162
    invoke-static/range {v16 .. v16}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 163
    .line 164
    .line 165
    move-result v2

    .line 166
    if-nez v2, :cond_9

    .line 167
    .line 168
    const v2, 0x18d9682b

    .line 169
    .line 170
    .line 171
    invoke-static {v4, v0, v2}, LX/3Rr;->A0A(LX/3C1;LX/2d4;I)LX/3C1;

    .line 172
    .line 173
    .line 174
    move-result-object v17

    .line 175
    shr-int/lit8 v2, v5, 0x3

    .line 176
    .line 177
    and-int/lit16 v7, v2, 0x380

    .line 178
    .line 179
    shl-int/lit8 v2, v5, 0x3

    .line 180
    .line 181
    and-int/lit16 v2, v2, 0x1c00

    .line 182
    .line 183
    or-int/2addr v7, v2

    .line 184
    const/16 v34, 0x3ff0

    .line 185
    .line 186
    move-object/from16 v22, v21

    .line 187
    .line 188
    move-object/from16 v23, v21

    .line 189
    .line 190
    move/from16 v24, v1

    .line 191
    .line 192
    move/from16 v25, v1

    .line 193
    .line 194
    move/from16 v26, v1

    .line 195
    .line 196
    move/from16 v27, v1

    .line 197
    .line 198
    move-object/from16 v28, v21

    .line 199
    .line 200
    move-object/from16 v29, v21

    .line 201
    .line 202
    move-object/from16 v30, v21

    .line 203
    .line 204
    move-object/from16 v31, v0

    .line 205
    .line 206
    move/from16 v32, v7

    .line 207
    .line 208
    move/from16 v33, v1

    .line 209
    .line 210
    move-wide/from16 v18, p8

    .line 211
    .line 212
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 213
    .line 214
    .line 215
    :goto_1
    invoke-static {v0}, LX/007;->A1M(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    if-eqz v1, :cond_8

    .line 223
    .line 224
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$3;

    .line 225
    .line 226
    move-object/from16 v31, v0

    .line 227
    .line 228
    move-object/from16 v32, v6

    .line 229
    .line 230
    move-object/from16 v33, v16

    .line 231
    .line 232
    move-object/from16 v34, v20

    .line 233
    .line 234
    move-wide/from16 p0, p8

    .line 235
    .line 236
    move-object/from16 p2, v14

    .line 237
    .line 238
    move-object/from16 p3, p7

    .line 239
    .line 240
    move-object/from16 p4, v4

    .line 241
    .line 242
    move/from16 p5, v3

    .line 243
    .line 244
    invoke-direct/range {v31 .. v41}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 245
    .line 246
    .line 247
    :goto_2
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    :cond_8
    return-void

    .line 251
    :cond_9
    const v1, 0x18d9682a

    .line 252
    .line 253
    .line 254
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 255
    .line 256
    .line 257
    goto :goto_1

    .line 258
    :cond_a
    const v2, 0x18dc36fb

    .line 259
    .line 260
    .line 261
    invoke-static {v0, v2}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 262
    .line 263
    .line 264
    move-result-object v2

    .line 265
    iget-object v8, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->listCells:Ljava/util/List;

    .line 266
    .line 267
    if-eqz v8, :cond_b

    .line 268
    .line 269
    const v7, 0x18dd384e

    .line 270
    .line 271
    .line 272
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 273
    .line 274
    .line 275
    shr-int/lit8 v5, v5, 0xf

    .line 276
    .line 277
    and-int/lit8 v5, v5, 0x70

    .line 278
    .line 279
    invoke-static {v8, v4, v0, v5, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewListCells(Ljava/util/List;LX/3C1;LX/2d4;II)V

    .line 280
    .line 281
    .line 282
    invoke-static {v0, v2}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 283
    .line 284
    .line 285
    move-result-object v1

    .line 286
    if-eqz v1, :cond_8

    .line 287
    .line 288
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;

    .line 289
    .line 290
    move-object/from16 v31, v0

    .line 291
    .line 292
    move-object/from16 v32, v6

    .line 293
    .line 294
    move-object/from16 v33, v16

    .line 295
    .line 296
    move-object/from16 v34, v20

    .line 297
    .line 298
    move-wide/from16 p0, p8

    .line 299
    .line 300
    move-object/from16 p2, v14

    .line 301
    .line 302
    move-object/from16 p3, p7

    .line 303
    .line 304
    move-object/from16 p4, v4

    .line 305
    .line 306
    move/from16 p5, v3

    .line 307
    .line 308
    invoke-direct/range {v31 .. v41}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$4;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 309
    .line 310
    .line 311
    goto :goto_2

    .line 312
    :cond_b
    const v7, 0x18de595b

    .line 313
    .line 314
    .line 315
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 316
    .line 317
    .line 318
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 319
    .line 320
    .line 321
    sget-object v15, LX/2sI;->A02:LX/2wD;

    .line 322
    .line 323
    invoke-interface {v4, v15}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 324
    .line 325
    .line 326
    move-result-object v7

    .line 327
    const/high16 v8, 0x41400000    # 12.0f

    .line 328
    .line 329
    invoke-static {v8}, LX/Dn6;->A00(F)LX/CP5;

    .line 330
    .line 331
    .line 332
    move-result-object v10

    .line 333
    sget-object v9, LX/2Id;->A02:LX/2sS;

    .line 334
    .line 335
    const/4 v8, 0x6

    .line 336
    invoke-static {v10, v0, v9, v8}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 337
    .line 338
    .line 339
    move-result-object v13

    .line 340
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 341
    .line 342
    .line 343
    move-result v12

    .line 344
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 345
    .line 346
    .line 347
    move-result-object v11

    .line 348
    invoke-static {v0, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 349
    .line 350
    .line 351
    move-result-object v10

    .line 352
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 353
    .line 354
    iget-object v7, v2, LX/J7I;->A0V:LX/3DJ;

    .line 355
    .line 356
    if-nez v7, :cond_c

    .line 357
    .line 358
    invoke-static {}, LX/1VY;->A00()V

    .line 359
    .line 360
    .line 361
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 362
    .line 363
    .line 364
    move-result-object v0

    .line 365
    throw v0

    .line 366
    :cond_c
    invoke-static {v0, v2, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 367
    .line 368
    .line 369
    invoke-static {v0, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 370
    .line 371
    .line 372
    const v7, 0x1983f2a1

    .line 373
    .line 374
    .line 375
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 376
    .line 377
    .line 378
    iget-object v7, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->blocks:Ljava/util/List;

    .line 379
    .line 380
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 381
    .line 382
    .line 383
    move-result-object v12

    .line 384
    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 385
    .line 386
    .line 387
    move-result v7

    .line 388
    if-eqz v7, :cond_13

    .line 389
    .line 390
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 391
    .line 392
    .line 393
    move-result-object v7

    .line 394
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock;

    .line 395
    .line 396
    instance-of v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;

    .line 397
    .line 398
    if-eqz v9, :cond_d

    .line 399
    .line 400
    const v9, 0x20e19cd0

    .line 401
    .line 402
    .line 403
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 404
    .line 405
    .line 406
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;

    .line 407
    .line 408
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;->$stable:I

    .line 409
    .line 410
    invoke-static {v7, v0, v9}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewFields(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;LX/2d4;I)V

    .line 411
    .line 412
    .line 413
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 414
    .line 415
    .line 416
    goto :goto_3

    .line 417
    :cond_d
    instance-of v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;

    .line 418
    .line 419
    if-eqz v9, :cond_f

    .line 420
    .line 421
    const v9, -0x4aca87a

    .line 422
    .line 423
    .line 424
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 425
    .line 426
    .line 427
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;

    .line 428
    .line 429
    iget-object v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;->inlineLink:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;

    .line 430
    .line 431
    if-nez v9, :cond_e

    .line 432
    .line 433
    const v9, -0x4aba0bc

    .line 434
    .line 435
    .line 436
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 437
    .line 438
    .line 439
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;->$stable:I

    .line 440
    .line 441
    shr-int/lit8 v9, v5, 0x3

    .line 442
    .line 443
    invoke-static {v9, v10}, LX/002;->A0B(II)I

    .line 444
    .line 445
    .line 446
    move-result v27

    .line 447
    move-object/from16 v23, v20

    .line 448
    .line 449
    move-wide/from16 v24, p8

    .line 450
    .line 451
    move-object/from16 v26, v0

    .line 452
    .line 453
    move-object/from16 v22, v7

    .line 454
    .line 455
    invoke-static/range {v22 .. v27}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewText-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;LX/2hg;JLX/2d4;I)V

    .line 456
    .line 457
    .line 458
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 459
    .line 460
    .line 461
    :goto_4
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 462
    .line 463
    .line 464
    goto :goto_3

    .line 465
    :cond_e
    const v10, -0x4a9f6f8

    .line 466
    .line 467
    .line 468
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 469
    .line 470
    .line 471
    iget-object v7, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;->text:Ljava/lang/String;

    .line 472
    .line 473
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;->$stable:I

    .line 474
    .line 475
    shl-int/lit8 v10, v10, 0x3

    .line 476
    .line 477
    invoke-static {v5, v10}, LX/002;->A0C(II)I

    .line 478
    .line 479
    .line 480
    move-result v11

    .line 481
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 482
    .line 483
    shl-int/lit8 v10, v10, 0xc

    .line 484
    .line 485
    or-int/2addr v11, v10

    .line 486
    invoke-static {v5, v11}, LX/005;->A06(II)I

    .line 487
    .line 488
    .line 489
    move-result v31

    .line 490
    const/16 v32, 0x40

    .line 491
    .line 492
    move-object/from16 v22, v7

    .line 493
    .line 494
    move-object/from16 v23, v9

    .line 495
    .line 496
    move-object/from16 v24, v20

    .line 497
    .line 498
    move-wide/from16 v25, p8

    .line 499
    .line 500
    move-object/from16 v27, v14

    .line 501
    .line 502
    move-object/from16 v28, p7

    .line 503
    .line 504
    move-object/from16 v29, v21

    .line 505
    .line 506
    move-object/from16 v30, v0

    .line 507
    .line 508
    invoke-static/range {v22 .. v32}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt;->PreviewInlineLinkText-hYmLsZ8(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 509
    .line 510
    .line 511
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 512
    .line 513
    .line 514
    goto :goto_4

    .line 515
    :cond_f
    instance-of v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;

    .line 516
    .line 517
    if-eqz v9, :cond_10

    .line 518
    .line 519
    const v9, 0x20e1eb44

    .line 520
    .line 521
    .line 522
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 523
    .line 524
    .line 525
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;

    .line 526
    .line 527
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;->$stable:I

    .line 528
    .line 529
    shr-int/lit8 v9, v5, 0x3

    .line 530
    .line 531
    invoke-static {v9, v10}, LX/002;->A0B(II)I

    .line 532
    .line 533
    .line 534
    move-result v27

    .line 535
    move-object/from16 v23, v20

    .line 536
    .line 537
    move-wide/from16 v24, p8

    .line 538
    .line 539
    move-object/from16 v26, v0

    .line 540
    .line 541
    move-object/from16 v22, v7

    .line 542
    .line 543
    invoke-static/range {v22 .. v27}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewList-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;LX/2hg;JLX/2d4;I)V

    .line 544
    .line 545
    .line 546
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 547
    .line 548
    .line 549
    goto/16 :goto_3

    .line 550
    .line 551
    :cond_10
    instance-of v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;

    .line 552
    .line 553
    if-eqz v9, :cond_11

    .line 554
    .line 555
    const v9, 0x20e1fd23

    .line 556
    .line 557
    .line 558
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 559
    .line 560
    .line 561
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;

    .line 562
    .line 563
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;->$stable:I

    .line 564
    .line 565
    shr-int/lit8 v9, v5, 0x3

    .line 566
    .line 567
    and-int/lit8 v9, v9, 0x70

    .line 568
    .line 569
    or-int/2addr v10, v9

    .line 570
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 571
    .line 572
    shl-int/2addr v9, v8

    .line 573
    or-int/2addr v10, v9

    .line 574
    shr-int/lit8 v9, v5, 0x6

    .line 575
    .line 576
    invoke-static {v9, v10}, LX/002;->A0C(II)I

    .line 577
    .line 578
    .line 579
    move-result v27

    .line 580
    move-object/from16 v23, v20

    .line 581
    .line 582
    move-object/from16 v24, v14

    .line 583
    .line 584
    move-object/from16 v25, p7

    .line 585
    .line 586
    move-object/from16 v26, v0

    .line 587
    .line 588
    move-object/from16 v22, v7

    .line 589
    .line 590
    invoke-static/range {v22 .. v27}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt;->PreviewLinks(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;LX/2hg;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V

    .line 591
    .line 592
    .line 593
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 594
    .line 595
    .line 596
    goto/16 :goto_3

    .line 597
    .line 598
    :cond_11
    instance-of v9, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;

    .line 599
    .line 600
    if-eqz v9, :cond_16

    .line 601
    .line 602
    const v9, 0x20e21ae3

    .line 603
    .line 604
    .line 605
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 606
    .line 607
    .line 608
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;

    .line 609
    .line 610
    sget v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;->$stable:I

    .line 611
    .line 612
    sget v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 613
    .line 614
    shl-int/lit8 v9, v9, 0x3

    .line 615
    .line 616
    or-int/2addr v10, v9

    .line 617
    shr-int/lit8 v9, v5, 0x9

    .line 618
    .line 619
    invoke-static {v9, v10}, LX/002;->A0B(II)I

    .line 620
    .line 621
    .line 622
    move-result v10

    .line 623
    move-object/from16 v9, p7

    .line 624
    .line 625
    invoke-static {v7, v14, v9, v0, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachments(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V

    .line 626
    .line 627
    .line 628
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 629
    .line 630
    .line 631
    goto/16 :goto_3

    .line 632
    .line 633
    :cond_12
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 634
    .line 635
    .line 636
    goto :goto_6

    .line 637
    :cond_13
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 638
    .line 639
    .line 640
    iget-boolean v5, v6, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->truncated:Z

    .line 641
    .line 642
    if-eqz v5, :cond_14

    .line 643
    .line 644
    const v5, 0x170c7bc3

    .line 645
    .line 646
    .line 647
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 648
    .line 649
    .line 650
    const v5, 0x7f120174

    .line 651
    .line 652
    .line 653
    invoke-static {v0, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 654
    .line 655
    .line 656
    move-result-object v22

    .line 657
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 658
    .line 659
    invoke-static {v0, v5}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 660
    .line 661
    .line 662
    move-result-object v26

    .line 663
    invoke-static {v0, v5}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 664
    .line 665
    .line 666
    move-result-wide v24

    .line 667
    const/16 p5, 0x3ff0

    .line 668
    .line 669
    const/16 p3, 0x30

    .line 670
    .line 671
    move-object/from16 v23, v15

    .line 672
    .line 673
    move-object/from16 v27, v21

    .line 674
    .line 675
    move-object/from16 v28, v21

    .line 676
    .line 677
    move-object/from16 v29, v21

    .line 678
    .line 679
    move/from16 v30, v1

    .line 680
    .line 681
    move/from16 v31, v1

    .line 682
    .line 683
    move/from16 v32, v1

    .line 684
    .line 685
    move/from16 v33, v1

    .line 686
    .line 687
    move-object/from16 v34, v21

    .line 688
    .line 689
    move-object/from16 p0, v21

    .line 690
    .line 691
    move-object/from16 p1, v21

    .line 692
    .line 693
    move-object/from16 p2, v0

    .line 694
    .line 695
    move/from16 p4, v1

    .line 696
    .line 697
    invoke-static/range {v22 .. v40}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 698
    .line 699
    .line 700
    :goto_5
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 701
    .line 702
    .line 703
    :goto_6
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 704
    .line 705
    .line 706
    move-result-object v1

    .line 707
    if-eqz v1, :cond_8

    .line 708
    .line 709
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$6;

    .line 710
    .line 711
    move-object v5, v0

    .line 712
    move-object/from16 v7, v16

    .line 713
    .line 714
    move-object/from16 v8, v20

    .line 715
    .line 716
    move-wide/from16 v9, p8

    .line 717
    .line 718
    move-object v11, v14

    .line 719
    move-object/from16 v12, p7

    .line 720
    .line 721
    move-object v13, v4

    .line 722
    move v14, v3

    .line 723
    move/from16 v15, p6

    .line 724
    .line 725
    invoke-direct/range {v5 .. v15}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$AgentPermissionRequestPreviewContent$6;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 726
    .line 727
    .line 728
    goto/16 :goto_2

    .line 729
    .line 730
    :cond_14
    const v1, 0x17105b85

    .line 731
    .line 732
    .line 733
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 734
    .line 735
    .line 736
    goto :goto_5

    .line 737
    :cond_15
    move v5, v3

    .line 738
    goto/16 :goto_0

    .line 739
    .line 740
    :cond_16
    const v1, 0x20e19861

    .line 741
    .line 742
    .line 743
    invoke-static {v0, v2, v1}, LX/008;->A1D(LX/2d4;LX/J7I;I)Lkotlin/NoWhenBranchMatchedException;

    .line 744
    .line 745
    .line 746
    move-result-object v0

    .line 747
    throw v0
.end method

.method public static final PreviewFields(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;LX/2d4;I)V
    .locals 33

    .line 0
    const v0, -0x25579001

    .line 1
    .line 2
    .line 3
    move-object/from16 v4, p1

    .line 4
    .line 5
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v3, p2

    .line 9
    .line 10
    and-int/lit8 v0, p2, 0x6

    .line 11
    .line 12
    move-object/from16 v13, p0

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-static {v13, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    or-int v1, v1, p2

    .line 25
    .line 26
    :goto_0
    invoke-static {v1}, LX/004;->A1R(I)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, v4, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    const/4 v1, 0x6

    .line 37
    const/high16 v0, 0x40c00000    # 6.0f

    .line 38
    .line 39
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 44
    .line 45
    invoke-static {v0, v4, v1}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 46
    .line 47
    .line 48
    move-result-object v8

    .line 49
    move-object v1, v4

    .line 50
    check-cast v1, LX/J7I;

    .line 51
    .line 52
    iget-wide v5, v1, LX/J7I;->A06:J

    .line 53
    .line 54
    invoke-static {v5, v6}, LX/001;->A0A(J)I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    invoke-static {v4, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    sget-object v12, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 67
    .line 68
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 69
    .line 70
    if-nez v0, :cond_1

    .line 71
    .line 72
    invoke-static {}, LX/1VY;->A00()V

    .line 73
    .line 74
    .line 75
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    throw v0

    .line 80
    :cond_0
    move v1, v3

    .line 81
    goto :goto_0

    .line 82
    :cond_1
    invoke-static {v4, v1, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    sget-object v11, LX/3Cl;->A04:LX/JDN;

    .line 86
    .line 87
    invoke-static {v4, v8, v11}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 88
    .line 89
    .line 90
    move-result-object v10

    .line 91
    invoke-static {v4, v6, v10, v7}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 92
    .line 93
    .line 94
    move-result-object v15

    .line 95
    sget-object v9, LX/3Cl;->A02:LX/JDM;

    .line 96
    .line 97
    invoke-static {v4, v5, v9}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 98
    .line 99
    .line 100
    move-result-object v14

    .line 101
    const v0, 0x12d2c8ce

    .line 102
    .line 103
    .line 104
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 105
    .line 106
    .line 107
    iget-object v0, v13, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;->rows:Ljava/util/List;

    .line 108
    .line 109
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 110
    .line 111
    .line 112
    move-result-object v16

    .line 113
    :goto_1
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_3

    .line 118
    .line 119
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    check-cast v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;

    .line 124
    .line 125
    sget-object v0, LX/2sI;->A02:LX/2wD;

    .line 126
    .line 127
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 128
    .line 129
    invoke-static {v5}, LX/Dn6;->A00(F)LX/CP5;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    sget-object v5, LX/2Id;->A05:LX/2rU;

    .line 134
    .line 135
    invoke-static {v6, v4, v5}, LX/3Rr;->A0B(LX/Cl0;LX/2d4;LX/2rU;)LX/3BI;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 140
    .line 141
    .line 142
    move-result v6

    .line 143
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    invoke-static {v4, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-static {v4, v1, v12}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 152
    .line 153
    .line 154
    invoke-static {v4, v7, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 155
    .line 156
    .line 157
    invoke-static {v4, v5, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 158
    .line 159
    .line 160
    invoke-static {v9, v15, v4, v6}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 161
    .line 162
    .line 163
    invoke-static {v4, v0, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 164
    .line 165
    .line 166
    sget-object v6, LX/CgK;->A00:LX/CgK;

    .line 167
    .line 168
    iget-object v0, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;->label:Ljava/lang/String;

    .line 169
    .line 170
    move-object/from16 v17, v0

    .line 171
    .line 172
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 173
    .line 174
    invoke-static {v4, v7}, LX/3Rq;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 175
    .line 176
    .line 177
    move-result-object v21

    .line 178
    invoke-static {v4, v7}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 179
    .line 180
    .line 181
    move-result-wide v19

    .line 182
    const/16 v22, 0x0

    .line 183
    .line 184
    const/high16 v5, 0x3f800000    # 1.0f

    .line 185
    .line 186
    const/4 v0, 0x1

    .line 187
    invoke-virtual {v6, v2, v5, v0}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 188
    .line 189
    .line 190
    move-result-object v18

    .line 191
    const/16 v25, 0x0

    .line 192
    .line 193
    const/16 p2, 0x3ff0

    .line 194
    .line 195
    move-object/from16 v23, v22

    .line 196
    .line 197
    move-object/from16 v24, v22

    .line 198
    .line 199
    move/from16 v26, v25

    .line 200
    .line 201
    move/from16 v27, v25

    .line 202
    .line 203
    move/from16 v28, v25

    .line 204
    .line 205
    move-object/from16 v29, v22

    .line 206
    .line 207
    move-object/from16 v30, v22

    .line 208
    .line 209
    move-object/from16 v31, v22

    .line 210
    .line 211
    move-object/from16 v32, v4

    .line 212
    .line 213
    move/from16 p0, v25

    .line 214
    .line 215
    move/from16 p1, v25

    .line 216
    .line 217
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 218
    .line 219
    .line 220
    iget-object v8, v8, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewField;->value:Ljava/lang/String;

    .line 221
    .line 222
    invoke-static {v4, v7}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 223
    .line 224
    .line 225
    move-result-object v21

    .line 226
    invoke-static {v4, v7}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 227
    .line 228
    .line 229
    move-result-wide v19

    .line 230
    invoke-virtual {v6, v2, v5, v0}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 231
    .line 232
    .line 233
    move-result-object v18

    .line 234
    move-object/from16 v17, v8

    .line 235
    .line 236
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 237
    .line 238
    .line 239
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_1

    .line 243
    .line 244
    :cond_2
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 245
    .line 246
    .line 247
    goto :goto_2

    .line 248
    :cond_3
    invoke-static {v1}, LX/003;->A0u(LX/J7I;)V

    .line 249
    .line 250
    .line 251
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 252
    .line 253
    .line 254
    move-result-object v1

    .line 255
    if-eqz v1, :cond_4

    .line 256
    .line 257
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewFields$2;

    .line 258
    .line 259
    invoke-direct {v0, v13, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewFields$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;I)V

    .line 260
    .line 261
    .line 262
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 263
    .line 264
    :cond_4
    return-void
.end method

.method public static final PreviewLabel(Ljava/lang/String;LX/2d4;I)V
    .locals 20

    .line 0
    const/4 v12, 0x0

    .line 1
    move-object/from16 v4, p0

    .line 2
    .line 3
    invoke-static {v4, v12}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const v0, -0x311c1652

    .line 7
    .line 8
    .line 9
    move-object/from16 v3, p1

    .line 10
    .line 11
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 12
    .line 13
    .line 14
    move/from16 v2, p2

    .line 15
    .line 16
    and-int/lit8 v0, p2, 0x6

    .line 17
    .line 18
    if-nez v0, :cond_2

    .line 19
    .line 20
    invoke-static {v3, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int v1, p2, v0

    .line 25
    .line 26
    :goto_0
    invoke-static {v1}, LX/004;->A1R(I)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 37
    .line 38
    invoke-static {v3, v0}, LX/3Rq;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 39
    .line 40
    .line 41
    move-result-object v8

    .line 42
    invoke-static {v3, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 43
    .line 44
    .line 45
    move-result-wide v6

    .line 46
    const/4 v9, 0x0

    .line 47
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 48
    .line 49
    and-int/lit8 v0, v1, 0xe

    .line 50
    .line 51
    or-int/lit8 p0, v0, 0x30

    .line 52
    .line 53
    const/16 p2, 0x3ff0

    .line 54
    .line 55
    move-object v10, v9

    .line 56
    move-object v11, v9

    .line 57
    move v13, v12

    .line 58
    move v14, v12

    .line 59
    move v15, v12

    .line 60
    move-object/from16 v16, v9

    .line 61
    .line 62
    move-object/from16 v17, v9

    .line 63
    .line 64
    move-object/from16 v18, v9

    .line 65
    .line 66
    move-object/from16 v19, v3

    .line 67
    .line 68
    move/from16 p1, v12

    .line 69
    .line 70
    invoke-static/range {v4 .. v22}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 71
    .line 72
    .line 73
    :goto_1
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    if-eqz v1, :cond_0

    .line 78
    .line 79
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewLabel$1;

    .line 80
    .line 81
    invoke-direct {v0, v4, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewLabel$1;-><init>(Ljava/lang/String;I)V

    .line 82
    .line 83
    .line 84
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 85
    .line 86
    :cond_0
    return-void

    .line 87
    :cond_1
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_2
    move v1, v2

    .line 92
    goto :goto_0
.end method

.method public static final PreviewList-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;LX/2hg;JLX/2d4;I)V
    .locals 34

    .line 0
    const v0, -0x414b3ba3

    .line 1
    .line 2
    .line 3
    move-object/from16 v9, p4

    .line 4
    .line 5
    invoke-interface {v9, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v8, p5

    .line 9
    .line 10
    and-int/lit8 v0, p5, 0x6

    .line 11
    .line 12
    move-object/from16 v14, p0

    .line 13
    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    invoke-static {v14, v9, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v7

    .line 24
    or-int v7, v7, p5

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 27
    .line 28
    move-object/from16 v23, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    move-object/from16 v0, v23

    .line 33
    .line 34
    invoke-static {v9, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v7, v0

    .line 39
    :cond_0
    and-int/lit16 v0, v8, 0x180

    .line 40
    .line 41
    move-wide/from16 p4, p2

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    move-wide/from16 v0, p4

    .line 46
    .line 47
    invoke-static {v9, v0, v1}, LX/004;->A0N(LX/2d4;J)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v7, v0

    .line 52
    :cond_1
    and-int/lit16 v1, v7, 0x93

    .line 53
    .line 54
    const/16 v0, 0x92

    .line 55
    .line 56
    const/4 v6, 0x0

    .line 57
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-static {v0, v9, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_5

    .line 66
    .line 67
    const/4 v1, 0x6

    .line 68
    const/high16 v0, 0x40c00000    # 6.0f

    .line 69
    .line 70
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 75
    .line 76
    invoke-static {v0, v9, v1}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    move-object v4, v9

    .line 81
    check-cast v4, LX/J7I;

    .line 82
    .line 83
    iget-wide v0, v4, LX/J7I;->A06:J

    .line 84
    .line 85
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 86
    .line 87
    .line 88
    move-result v12

    .line 89
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    invoke-static {v9, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    sget-object v11, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 98
    .line 99
    iget-object v0, v4, LX/J7I;->A0V:LX/3DJ;

    .line 100
    .line 101
    if-nez v0, :cond_3

    .line 102
    .line 103
    invoke-static {}, LX/1VY;->A00()V

    .line 104
    .line 105
    .line 106
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0

    .line 111
    :cond_2
    move v7, v8

    .line 112
    goto :goto_0

    .line 113
    :cond_3
    invoke-static {v9, v4, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 114
    .line 115
    .line 116
    sget-object v10, LX/3Cl;->A04:LX/JDN;

    .line 117
    .line 118
    invoke-static {v9, v3, v10}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    invoke-static {v9, v2, v3, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 123
    .line 124
    .line 125
    move-result-object v18

    .line 126
    sget-object v2, LX/3Cl;->A02:LX/JDM;

    .line 127
    .line 128
    invoke-static {v9, v1, v2}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 129
    .line 130
    .line 131
    move-result-object v17

    .line 132
    iget-object v1, v14, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;->label:Ljava/lang/String;

    .line 133
    .line 134
    if-nez v1, :cond_4

    .line 135
    .line 136
    const v0, 0x425121d6

    .line 137
    .line 138
    .line 139
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 140
    .line 141
    .line 142
    :goto_1
    invoke-static {v4, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 143
    .line 144
    .line 145
    const v0, -0x69372930

    .line 146
    .line 147
    .line 148
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 149
    .line 150
    .line 151
    iget-object v0, v14, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;->items:Ljava/util/List;

    .line 152
    .line 153
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 154
    .line 155
    .line 156
    move-result-object v16

    .line 157
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    if-eqz v0, :cond_6

    .line 162
    .line 163
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v19

    .line 167
    check-cast v19, Ljava/lang/String;

    .line 168
    .line 169
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 170
    .line 171
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 172
    .line 173
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 174
    .line 175
    .line 176
    move-result-object v12

    .line 177
    sget-object v0, LX/2Id;->A05:LX/2rU;

    .line 178
    .line 179
    invoke-static {v12, v9, v0}, LX/3Rr;->A0B(LX/Cl0;LX/2d4;LX/2rU;)LX/3BI;

    .line 180
    .line 181
    .line 182
    move-result-object v13

    .line 183
    invoke-static {v4}, LX/002;->A0J(LX/J7I;)I

    .line 184
    .line 185
    .line 186
    move-result v12

    .line 187
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-static {v9, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    invoke-static {v9, v4, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 196
    .line 197
    .line 198
    invoke-static {v9, v13, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 199
    .line 200
    .line 201
    invoke-static {v9, v0, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 202
    .line 203
    .line 204
    move-object/from16 v0, v18

    .line 205
    .line 206
    invoke-static {v2, v0, v9, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 207
    .line 208
    .line 209
    move-object/from16 v0, v17

    .line 210
    .line 211
    invoke-static {v9, v1, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 212
    .line 213
    .line 214
    sget-object v15, LX/CgK;->A00:LX/CgK;

    .line 215
    .line 216
    const/16 v24, 0x0

    .line 217
    .line 218
    const/high16 v0, 0x40e00000    # 7.0f

    .line 219
    .line 220
    invoke-static {v5, v0}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    const/high16 v0, 0x40800000    # 4.0f

    .line 225
    .line 226
    invoke-static {v1, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 227
    .line 228
    .line 229
    move-result-object v13

    .line 230
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 231
    .line 232
    invoke-static {v9, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 233
    .line 234
    .line 235
    move-result-wide v0

    .line 236
    sget-object v12, LX/2bA;->A00:LX/2bC;

    .line 237
    .line 238
    invoke-static {v13, v12, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    invoke-static {v0, v9, v6}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 243
    .line 244
    .line 245
    const/high16 v0, 0x3f800000    # 1.0f

    .line 246
    .line 247
    const/4 v1, 0x1

    .line 248
    invoke-virtual {v15, v5, v0, v1}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 249
    .line 250
    .line 251
    move-result-object v20

    .line 252
    and-int/lit16 v0, v7, 0x380

    .line 253
    .line 254
    shl-int/lit8 v12, v7, 0x6

    .line 255
    .line 256
    and-int/lit16 v12, v12, 0x1c00

    .line 257
    .line 258
    or-int/2addr v0, v12

    .line 259
    const/16 p3, 0x3ff0

    .line 260
    .line 261
    move-wide/from16 v21, p4

    .line 262
    .line 263
    move-object/from16 v25, v24

    .line 264
    .line 265
    move-object/from16 v26, v24

    .line 266
    .line 267
    move/from16 v27, v6

    .line 268
    .line 269
    move/from16 v28, v6

    .line 270
    .line 271
    move/from16 v29, v6

    .line 272
    .line 273
    move/from16 v30, v6

    .line 274
    .line 275
    move-object/from16 v31, v24

    .line 276
    .line 277
    move-object/from16 v32, v24

    .line 278
    .line 279
    move-object/from16 v33, v24

    .line 280
    .line 281
    move-object/from16 p0, v9

    .line 282
    .line 283
    move/from16 p1, v0

    .line 284
    .line 285
    move/from16 p2, v6

    .line 286
    .line 287
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 288
    .line 289
    .line 290
    invoke-static {v4, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 291
    .line 292
    .line 293
    goto/16 :goto_2

    .line 294
    .line 295
    :cond_4
    const v0, 0x425121d7

    .line 296
    .line 297
    .line 298
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 299
    .line 300
    .line 301
    invoke-static {v1, v9, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewLabel(Ljava/lang/String;LX/2d4;I)V

    .line 302
    .line 303
    .line 304
    goto/16 :goto_1

    .line 305
    .line 306
    :cond_5
    invoke-interface {v9}, LX/2d4;->AgJ()V

    .line 307
    .line 308
    .line 309
    goto :goto_3

    .line 310
    :cond_6
    invoke-static {v4}, LX/003;->A0u(LX/J7I;)V

    .line 311
    .line 312
    .line 313
    :goto_3
    invoke-interface {v9}, LX/2d4;->AAg()LX/J7V;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    if-eqz v1, :cond_7

    .line 318
    .line 319
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewList$2;

    .line 320
    .line 321
    move-object v2, v0

    .line 322
    move-object v3, v14

    .line 323
    move-object/from16 v4, v23

    .line 324
    .line 325
    move-wide/from16 v5, p4

    .line 326
    .line 327
    move v7, v8

    .line 328
    invoke-direct/range {v2 .. v7}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewList$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;LX/2hg;JI)V

    .line 329
    .line 330
    .line 331
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 332
    .line 333
    :cond_7
    return-void
.end method

.method public static final PreviewListCell(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;LX/3C1;LX/2d4;II)V
    .locals 34

    .line 0
    move-object/from16 v14, p1

    .line 1
    .line 2
    const v1, 0xc20ddc9

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p2

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v1, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v1, :cond_3

    .line 17
    .line 18
    invoke-static {v4, v0, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    or-int v6, p3, v1

    .line 27
    .line 28
    :goto_0
    move/from16 v19, p4

    .line 29
    .line 30
    and-int/lit8 v5, p4, 0x2

    .line 31
    .line 32
    if-eqz v5, :cond_2

    .line 33
    .line 34
    or-int/lit8 v6, v6, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v3, v6, 0x13

    .line 37
    .line 38
    const/16 v1, 0x12

    .line 39
    .line 40
    const/16 v18, 0x0

    .line 41
    .line 42
    invoke-static {v3, v1}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    invoke-static {v1, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_4

    .line 51
    .line 52
    if-eqz v5, :cond_1

    .line 53
    .line 54
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    :cond_1
    invoke-static {v14}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 57
    .line 58
    .line 59
    move-result-object v9

    .line 60
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 61
    .line 62
    invoke-static {v1}, LX/Dn6;->A00(F)LX/CP5;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    sget-object v1, LX/2Id;->A04:LX/2rU;

    .line 67
    .line 68
    const/16 v12, 0x30

    .line 69
    .line 70
    invoke-static {v3, v0, v1, v12}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 71
    .line 72
    .line 73
    move-result-object v8

    .line 74
    move-object v1, v0

    .line 75
    check-cast v1, LX/J7I;

    .line 76
    .line 77
    iget-wide v5, v1, LX/J7I;->A06:J

    .line 78
    .line 79
    invoke-static {v5, v6}, LX/001;->A0A(J)I

    .line 80
    .line 81
    .line 82
    move-result v7

    .line 83
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    invoke-static {v0, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    sget-object v11, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 92
    .line 93
    iget-object v3, v1, LX/J7I;->A0V:LX/3DJ;

    .line 94
    .line 95
    if-nez v3, :cond_5

    .line 96
    .line 97
    invoke-static {}, LX/1VY;->A00()V

    .line 98
    .line 99
    .line 100
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    throw v0

    .line 105
    :cond_2
    and-int/lit8 v1, p3, 0x30

    .line 106
    .line 107
    if-nez v1, :cond_0

    .line 108
    .line 109
    invoke-static {v0, v14}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    or-int/2addr v6, v1

    .line 114
    goto :goto_1

    .line 115
    :cond_3
    move v6, v2

    .line 116
    goto :goto_0

    .line 117
    :cond_4
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 118
    .line 119
    .line 120
    goto/16 :goto_3

    .line 121
    .line 122
    :cond_5
    invoke-static {v0, v1, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 123
    .line 124
    .line 125
    sget-object v10, LX/3Cl;->A04:LX/JDN;

    .line 126
    .line 127
    invoke-static {v0, v8, v10}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 128
    .line 129
    .line 130
    move-result-object v9

    .line 131
    invoke-static {v0, v6, v9, v7}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 132
    .line 133
    .line 134
    move-result-object v17

    .line 135
    sget-object v8, LX/3Cl;->A02:LX/JDM;

    .line 136
    .line 137
    invoke-static {v0, v5, v8}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 138
    .line 139
    .line 140
    move-result-object v15

    .line 141
    sget-object v7, LX/CgK;->A00:LX/CgK;

    .line 142
    .line 143
    iget-object v3, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;->label:Ljava/lang/String;

    .line 144
    .line 145
    move-object/from16 v20, v3

    .line 146
    .line 147
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 148
    .line 149
    const/16 v16, 0x6

    .line 150
    .line 151
    invoke-static {v0, v3}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 152
    .line 153
    .line 154
    move-result-object v24

    .line 155
    invoke-static {v0, v3}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 156
    .line 157
    .line 158
    move-result-wide v22

    .line 159
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 160
    .line 161
    const/16 v25, 0x0

    .line 162
    .line 163
    const/high16 v5, 0x3f800000    # 1.0f

    .line 164
    .line 165
    const/4 v13, 0x1

    .line 166
    invoke-virtual {v7, v6, v5, v13}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 167
    .line 168
    .line 169
    move-result-object v21

    .line 170
    const/16 p4, 0x3ff0

    .line 171
    .line 172
    move-object/from16 v26, v25

    .line 173
    .line 174
    move-object/from16 v27, v25

    .line 175
    .line 176
    move/from16 v28, v18

    .line 177
    .line 178
    move/from16 v29, v18

    .line 179
    .line 180
    move/from16 v30, v18

    .line 181
    .line 182
    move/from16 v31, v18

    .line 183
    .line 184
    move-object/from16 v32, v25

    .line 185
    .line 186
    move-object/from16 v33, v25

    .line 187
    .line 188
    move-object/from16 p0, v25

    .line 189
    .line 190
    move-object/from16 p1, v0

    .line 191
    .line 192
    move/from16 p2, v18

    .line 193
    .line 194
    move/from16 p3, v18

    .line 195
    .line 196
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v7, v6, v5, v13}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 200
    .line 201
    .line 202
    move-result-object v7

    .line 203
    sget-object v6, LX/2Id;->A01:LX/2sS;

    .line 204
    .line 205
    sget-object v5, LX/Dn6;->A06:LX/Dps;

    .line 206
    .line 207
    invoke-static {v5, v0, v6, v12}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 208
    .line 209
    .line 210
    move-result-object v12

    .line 211
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 212
    .line 213
    .line 214
    move-result v6

    .line 215
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    invoke-static {v0, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 220
    .line 221
    .line 222
    move-result-object v7

    .line 223
    invoke-static {v0, v1, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 224
    .line 225
    .line 226
    invoke-static {v0, v12, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 227
    .line 228
    .line 229
    invoke-static {v0, v5, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 230
    .line 231
    .line 232
    move-object/from16 v5, v17

    .line 233
    .line 234
    invoke-static {v8, v5, v0, v6}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 235
    .line 236
    .line 237
    invoke-static {v0, v7, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 238
    .line 239
    .line 240
    iget-object v5, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;->value:Ljava/lang/String;

    .line 241
    .line 242
    invoke-static {v0, v3}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 243
    .line 244
    .line 245
    move-result-object v24

    .line 246
    invoke-static {v0, v3}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 247
    .line 248
    .line 249
    move-result-wide v22

    .line 250
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 251
    .line 252
    .line 253
    move-result-object v27

    .line 254
    const/16 p4, 0x3fb2

    .line 255
    .line 256
    move-object/from16 v20, v5

    .line 257
    .line 258
    move-object/from16 v21, v25

    .line 259
    .line 260
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 261
    .line 262
    .line 263
    iget-object v6, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;->caption:Ljava/lang/String;

    .line 264
    .line 265
    if-nez v6, :cond_7

    .line 266
    .line 267
    const v3, 0x6d9f5db9

    .line 268
    .line 269
    .line 270
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 271
    .line 272
    .line 273
    :goto_2
    move/from16 v3, v18

    .line 274
    .line 275
    invoke-static {v1, v3, v13}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 276
    .line 277
    .line 278
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    if-eqz v3, :cond_6

    .line 283
    .line 284
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewListCell$2;

    .line 285
    .line 286
    move/from16 v0, v19

    .line 287
    .line 288
    invoke-direct {v1, v4, v14, v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewListCell$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;LX/3C1;II)V

    .line 289
    .line 290
    .line 291
    iput-object v1, v3, LX/J7V;->A06:LX/JDN;

    .line 292
    .line 293
    :cond_6
    return-void

    .line 294
    :cond_7
    const v5, 0x6d9f5dba

    .line 295
    .line 296
    .line 297
    invoke-static {v0, v3, v5}, LX/3Rr;->A0D(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)LX/2hg;

    .line 298
    .line 299
    .line 300
    move-result-object v24

    .line 301
    invoke-static {v0, v3}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 302
    .line 303
    .line 304
    move-result-wide v22

    .line 305
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 306
    .line 307
    .line 308
    move-result-object v27

    .line 309
    move-object/from16 v20, v6

    .line 310
    .line 311
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 312
    .line 313
    .line 314
    goto :goto_2
.end method

.method public static final PreviewListCells(Ljava/util/List;LX/3C1;LX/2d4;II)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    const v0, -0x3c216c69

    .line 1
    .line 2
    .line 3
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v0, p3, 0x6

    .line 7
    .line 8
    const/4 v7, 0x2

    .line 9
    if-nez v0, :cond_6

    .line 10
    .line 11
    invoke-static {p0, p2, p3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, LX/003;->A06(I)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    or-int/2addr v3, p3

    .line 20
    :goto_0
    and-int/lit8 v2, p4, 0x2

    .line 21
    .line 22
    if-eqz v2, :cond_5

    .line 23
    .line 24
    or-int/lit8 v3, v3, 0x30

    .line 25
    .line 26
    :cond_0
    :goto_1
    and-int/lit8 v1, v3, 0x13

    .line 27
    .line 28
    const/16 v0, 0x12

    .line 29
    .line 30
    const/4 v6, 0x0

    .line 31
    const/4 v5, 0x1

    .line 32
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0, p2, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_7

    .line 41
    .line 42
    if-eqz v2, :cond_1

    .line 43
    .line 44
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 45
    .line 46
    :cond_1
    const/4 v4, 0x0

    .line 47
    invoke-static {p1}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const/high16 v0, 0x41400000    # 12.0f

    .line 52
    .line 53
    invoke-static {p2, v0}, LX/3Rs;->A09(LX/2d4;F)LX/3BI;

    .line 54
    .line 55
    .line 56
    move-result-object v10

    .line 57
    move-object v3, p2

    .line 58
    check-cast v3, LX/J7I;

    .line 59
    .line 60
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 61
    .line 62
    .line 63
    move-result v9

    .line 64
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 65
    .line 66
    .line 67
    move-result-object v8

    .line 68
    invoke-static {p2, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 73
    .line 74
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 75
    .line 76
    if-nez v0, :cond_2

    .line 77
    .line 78
    invoke-static {}, LX/1VY;->A00()V

    .line 79
    .line 80
    .line 81
    :goto_2
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    throw v0

    .line 86
    :cond_2
    invoke-static {p2, v3, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 87
    .line 88
    .line 89
    invoke-static {p2, v10, v8, v2, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 90
    .line 91
    .line 92
    const v0, -0x1bee97cc

    .line 93
    .line 94
    .line 95
    invoke-static {p2, p0, v0}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 96
    .line 97
    .line 98
    move-result-object v9

    .line 99
    const/4 v8, 0x0

    .line 100
    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_8

    .line 105
    .line 106
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    add-int/lit8 v1, v8, 0x1

    .line 111
    .line 112
    if-gez v8, :cond_3

    .line 113
    .line 114
    invoke-static {}, LX/B8B;->A1A()V

    .line 115
    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_3
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;

    .line 119
    .line 120
    if-lez v8, :cond_4

    .line 121
    .line 122
    const v0, 0x39ba87b7    # 3.55778E-4f

    .line 123
    .line 124
    .line 125
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 126
    .line 127
    .line 128
    invoke-static {v4, p2, v6, v5}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 129
    .line 130
    .line 131
    :goto_4
    invoke-static {v3, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 132
    .line 133
    .line 134
    sget v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;->$stable:I

    .line 135
    .line 136
    invoke-static {v2, v4, p2, v0, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewListCell(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;LX/3C1;LX/2d4;II)V

    .line 137
    .line 138
    .line 139
    move v8, v1

    .line 140
    goto :goto_3

    .line 141
    :cond_4
    const v0, -0x26954c5

    .line 142
    .line 143
    .line 144
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 145
    .line 146
    .line 147
    goto :goto_4

    .line 148
    :cond_5
    and-int/lit8 v0, p3, 0x30

    .line 149
    .line 150
    if-nez v0, :cond_0

    .line 151
    .line 152
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    or-int/2addr v3, v0

    .line 157
    goto/16 :goto_1

    .line 158
    .line 159
    :cond_6
    move v3, p3

    .line 160
    goto/16 :goto_0

    .line 161
    .line 162
    :cond_7
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 163
    .line 164
    .line 165
    goto :goto_5

    .line 166
    :cond_8
    invoke-static {v3, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 167
    .line 168
    .line 169
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 170
    .line 171
    .line 172
    :goto_5
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 173
    .line 174
    .line 175
    move-result-object v1

    .line 176
    if-eqz v1, :cond_9

    .line 177
    .line 178
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewListCells$2;

    .line 179
    .line 180
    invoke-direct {v0, p0, p1, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewListCells$2;-><init>(Ljava/util/List;LX/3C1;II)V

    .line 181
    .line 182
    .line 183
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 184
    .line 185
    :cond_9
    return-void
.end method

.method public static final PreviewText-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;LX/2hg;JLX/2d4;I)V
    .locals 23

    .line 0
    const v0, 0x5aa3aa50

    .line 1
    .line 2
    .line 3
    move-object/from16 v4, p4

    .line 4
    .line 5
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v1, p5

    .line 9
    .line 10
    and-int/lit8 v0, p5, 0x6

    .line 11
    .line 12
    move-object/from16 v2, p0

    .line 13
    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    invoke-static {v2, v4, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v6

    .line 24
    or-int v6, v6, p5

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 27
    .line 28
    move-object/from16 v14, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-static {v4, v14}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v6, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 38
    .line 39
    move-wide/from16 v12, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v4, v12, v13}, LX/004;->A0N(LX/2d4;J)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v6, v0

    .line 48
    :cond_1
    and-int/lit16 v3, v6, 0x93

    .line 49
    .line 50
    const/16 v0, 0x92

    .line 51
    .line 52
    const/4 v5, 0x0

    .line 53
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-static {v0, v4, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_5

    .line 62
    .line 63
    const/high16 v0, 0x40800000    # 4.0f

    .line 64
    .line 65
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 70
    .line 71
    sget-object v3, LX/2Id;->A02:LX/2sS;

    .line 72
    .line 73
    const/4 v0, 0x6

    .line 74
    invoke-static {v8, v4, v3, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 75
    .line 76
    .line 77
    move-result-object v11

    .line 78
    move-object v3, v4

    .line 79
    check-cast v3, LX/J7I;

    .line 80
    .line 81
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 82
    .line 83
    .line 84
    move-result v10

    .line 85
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 86
    .line 87
    .line 88
    move-result-object v9

    .line 89
    invoke-static {v4, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v8

    .line 93
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 96
    .line 97
    if-nez v0, :cond_3

    .line 98
    .line 99
    invoke-static {}, LX/1VY;->A00()V

    .line 100
    .line 101
    .line 102
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    throw v0

    .line 107
    :cond_2
    move v6, v1

    .line 108
    goto :goto_0

    .line 109
    :cond_3
    invoke-static {v4, v3, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 110
    .line 111
    .line 112
    invoke-static {v4, v11, v9, v8, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 113
    .line 114
    .line 115
    iget-object v7, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;->label:Ljava/lang/String;

    .line 116
    .line 117
    if-nez v7, :cond_4

    .line 118
    .line 119
    const v0, 0x7fc78803

    .line 120
    .line 121
    .line 122
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 123
    .line 124
    .line 125
    :goto_1
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 126
    .line 127
    .line 128
    iget-object v10, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;->text:Ljava/lang/String;

    .line 129
    .line 130
    const/4 v15, 0x0

    .line 131
    sget-object v11, LX/2sI;->A02:LX/2wD;

    .line 132
    .line 133
    and-int/lit16 v0, v6, 0x380

    .line 134
    .line 135
    or-int/lit8 p3, v0, 0x30

    .line 136
    .line 137
    shl-int/lit8 v0, v6, 0x6

    .line 138
    .line 139
    and-int/lit16 v0, v0, 0x1c00

    .line 140
    .line 141
    or-int p3, p3, v0

    .line 142
    .line 143
    const/16 p5, 0x3ff0

    .line 144
    .line 145
    move-object/from16 v16, v15

    .line 146
    .line 147
    move-object/from16 v17, v15

    .line 148
    .line 149
    move/from16 v19, v5

    .line 150
    .line 151
    move/from16 v20, v5

    .line 152
    .line 153
    move/from16 v21, v5

    .line 154
    .line 155
    move-object/from16 v22, v15

    .line 156
    .line 157
    move-object/from16 p0, v15

    .line 158
    .line 159
    move-object/from16 p1, v15

    .line 160
    .line 161
    move-object/from16 p2, v4

    .line 162
    .line 163
    move/from16 p4, v5

    .line 164
    .line 165
    move/from16 v18, v5

    .line 166
    .line 167
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 168
    .line 169
    .line 170
    const/4 v0, 0x1

    .line 171
    invoke-static {v3, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 172
    .line 173
    .line 174
    goto :goto_2

    .line 175
    :cond_4
    const v0, 0x7fc78804

    .line 176
    .line 177
    .line 178
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 179
    .line 180
    .line 181
    invoke-static {v7, v4, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewLabel(Ljava/lang/String;LX/2d4;I)V

    .line 182
    .line 183
    .line 184
    goto :goto_1

    .line 185
    :cond_5
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 186
    .line 187
    .line 188
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    if-eqz v0, :cond_6

    .line 193
    .line 194
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewText$2;

    .line 195
    .line 196
    move-object v5, v14

    .line 197
    move-wide v6, v12

    .line 198
    move v8, v1

    .line 199
    move-object v4, v2

    .line 200
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt$PreviewText$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;LX/2hg;JI)V

    .line 201
    .line 202
    .line 203
    iput-object v3, v0, LX/J7V;->A06:LX/JDN;

    .line 204
    .line 205
    :cond_6
    return-void
.end method

.method public static final synthetic access$PreviewFields(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewFields(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Fields;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PreviewList-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;LX/2hg;JLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewList-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$ItemList;LX/2hg;JLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PreviewListCell(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewListCell(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewListCell;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PreviewListCells(Ljava/util/List;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewListCells(Ljava/util/List;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PreviewText-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;LX/2hg;JLX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewText-XO-JAsU(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Text;LX/2hg;JLX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final hasDetailsRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPresentation:Lcom/facebook/aura/gateway/AgentPermissionRequestPresentation;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/gateway/AgentPermissionRequestPresentation;->DETAILS:Lcom/facebook/aura/gateway/AgentPermissionRequestPresentation;

    .line 7
    .line 8
    if-ne v1, v0, :cond_0

    .line 9
    .line 10
    invoke-static {p0}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->hasRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 v2, 0x1

    .line 17
    :cond_0
    return v2
.end method

.method public static final hasRequestPreviewAttachments(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->blocks:Ljava/util/List;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    instance-of v0, v1, Ljava/util/Collection;

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :cond_0
    return v2

    .line 23
    :cond_1
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    :cond_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    instance-of v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;

    .line 38
    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    const/4 v2, 0x1

    .line 42
    return v2
.end method
