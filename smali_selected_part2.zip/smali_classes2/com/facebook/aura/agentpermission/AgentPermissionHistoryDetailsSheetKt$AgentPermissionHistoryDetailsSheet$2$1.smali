.class public final Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$uiState$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$uiState$delegate:LX/16A;

    .line 5
    .line 6
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;->historyLoadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 15
    .line 16
    if-ne v1, v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 19
    .line 20
    invoke-interface {v0}, Lcom/facebook/aura/navigation/AuraNavigator;->back()Z

    .line 21
    .line 22
    .line 23
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1$invoke$$inlined$onDispose$1;

    .line 24
    .line 25
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 26
    .line 27
    .line 28
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$2$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
