.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/2or;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $buttonPadding:LX/2or;


# direct methods
.method public constructor <init>(LX/2or;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;->$buttonPadding:LX/2or;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()LX/2or;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;->$buttonPadding:LX/2or;

    .line 1
    .line 2
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionButtons$2$1$2$1;->$buttonPadding:LX/2or;

    .line 268435457
    .line 268435458
    return-object p0
.end method
