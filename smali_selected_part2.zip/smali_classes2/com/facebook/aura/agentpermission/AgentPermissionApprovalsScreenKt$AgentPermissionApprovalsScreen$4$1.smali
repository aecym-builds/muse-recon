.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/1O1;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $sessionId:Ljava/lang/String;

.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;LX/16A;Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;",
            ">;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$uiState$delegate:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$sessionId:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1O1;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->invoke(LX/1O1;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/1O1;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$uiState$delegate:LX/16A;

    .line 5
    .line 6
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    check-cast v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 13
    .line 14
    new-instance v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$1;

    .line 15
    .line 16
    invoke-direct {v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$1;-><init>(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;

    .line 22
    .line 23
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 24
    .line 25
    .line 26
    invoke-static {p1, v3, v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->openApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDN;LX/JDM;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$uiState$delegate:LX/16A;

    .line 30
    .line 31
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 36
    .line 37
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 38
    .line 39
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$sessionId:Ljava/lang/String;

    .line 40
    .line 41
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$3;

    .line 42
    .line 43
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$3;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->actionedApprovalsSection(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;LX/JDM;)V

    .line 47
    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$uiState$delegate:LX/16A;

    .line 50
    .line 51
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;

    .line 56
    .line 57
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 58
    .line 59
    new-instance v1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$4;

    .line 60
    .line 61
    invoke-direct {v1, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$4;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;)V

    .line 62
    .line 63
    .line 64
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$5;

    .line 65
    .line 66
    invoke-direct {v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$5;-><init>(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    invoke-static {p1, v3, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt;->approvalsStatusItem(LX/1O1;Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 70
    .line 71
    .line 72
    return-void
.end method
