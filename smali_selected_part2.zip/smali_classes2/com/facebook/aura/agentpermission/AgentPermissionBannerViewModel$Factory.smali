.class public final Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final sessionId:Ljava/lang/String;

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;->sessionId:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;->create()Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;->userSession:LX/AHE;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel$Factory;->sessionId:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerViewModel;-><init>(LX/AHE;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method
