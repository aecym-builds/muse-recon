.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionApprovalsViewModel$loadHistory$1"
    f = "AgentPermissionApprovalsViewModel.kt"
    l = {
        0x9b,
        0x9f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $reset:Z

.field public I$0:I

.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public Z$0:Z

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;ZLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;",
            "Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->$reset:Z

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 1
    .line 2
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->$reset:Z

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;ZLX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    sget-object v13, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v2, p0

    .line 5
    .line 6
    iget v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->label:I

    .line 7
    .line 8
    const/4 v12, 0x2

    .line 9
    const/4 v11, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    if-eqz v0, :cond_7

    .line 12
    .line 13
    if-eq v0, v3, :cond_d

    .line 14
    .line 15
    if-ne v0, v12, :cond_12

    .line 16
    .line 17
    iget-boolean v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->Z$0:Z

    .line 18
    .line 19
    iget-wide v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->J$0:J

    .line 20
    .line 21
    iget-object v6, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$3:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 24
    .line 25
    iget-object v9, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$2:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v9, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 28
    .line 29
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v4, Ljava/util/List;

    .line 33
    .line 34
    iget-object v9, v9, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 35
    .line 36
    :cond_1
    invoke-interface {v9}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v8

    .line 40
    move-object v13, v8

    .line 41
    check-cast v13, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 42
    .line 43
    if-eqz v5, :cond_6

    .line 44
    .line 45
    move-object v14, v4

    .line 46
    :cond_2
    sget-object v15, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 47
    .line 48
    iget-object v10, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;->nextCursor:Ljava/lang/String;

    .line 49
    .line 50
    if-eqz v10, :cond_3

    .line 51
    .line 52
    invoke-static {v10}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 53
    .line 54
    .line 55
    move-result v11

    .line 56
    const/4 v7, 0x0

    .line 57
    if-eqz v11, :cond_4

    .line 58
    .line 59
    :cond_3
    const/4 v7, 0x1

    .line 60
    :cond_4
    xor-int/lit8 v17, v7, 0x1

    .line 61
    .line 62
    const/16 v18, 0x0

    .line 63
    .line 64
    move-object/from16 v16, v10

    .line 65
    .line 66
    invoke-virtual/range {v13 .. v18}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    invoke-interface {v9, v8, v7}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v7

    .line 74
    if-eqz v7, :cond_1

    .line 75
    .line 76
    :goto_0
    iget-object v4, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 77
    .line 78
    iget-object v4, v4, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 79
    .line 80
    iget-object v4, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->historyRefreshVersion:LX/2J3;

    .line 81
    .line 82
    invoke-interface {v4}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-static {v4}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 87
    .line 88
    .line 89
    move-result-wide v5

    .line 90
    cmp-long v4, v0, v5

    .line 91
    .line 92
    if-eqz v4, :cond_5

    .line 93
    .line 94
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 95
    .line 96
    invoke-virtual {v0, v3}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->loadHistory(Z)V

    .line 97
    .line 98
    .line 99
    :cond_5
    sget-object v13, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 100
    .line 101
    return-object v13

    .line 102
    :cond_6
    iget-object v7, v13, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 103
    .line 104
    invoke-static {v4, v7}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 105
    .line 106
    .line 107
    move-result-object v7

    .line 108
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 109
    .line 110
    .line 111
    move-result-object v11

    .line 112
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 113
    .line 114
    .line 115
    move-result-object v14

    .line 116
    invoke-virtual {v7}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 117
    .line 118
    .line 119
    move-result-object v12

    .line 120
    :goto_1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 121
    .line 122
    .line 123
    move-result v7

    .line 124
    if-eqz v7, :cond_2

    .line 125
    .line 126
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v10

    .line 130
    move-object v7, v10

    .line 131
    check-cast v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 132
    .line 133
    iget-object v7, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 134
    .line 135
    invoke-static {v7, v10, v11, v14}, LX/3Rs;->A1A(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;Ljava/util/AbstractCollection;)V

    .line 136
    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_7
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 143
    .line 144
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->approvalsRepository:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;

    .line 145
    .line 146
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository;->historyRefreshVersion:LX/2J3;

    .line 147
    .line 148
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    invoke-static {v0}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 153
    .line 154
    .line 155
    move-result-wide v0

    .line 156
    iget-object v4, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 157
    .line 158
    iget-object v4, v4, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 159
    .line 160
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v6

    .line 164
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 165
    .line 166
    iget-boolean v10, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->$reset:Z

    .line 167
    .line 168
    if-nez v10, :cond_8

    .line 169
    .line 170
    iget-object v5, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 171
    .line 172
    sget-object v4, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->IDLE:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 173
    .line 174
    const/4 v7, 0x0

    .line 175
    if-ne v5, v4, :cond_c

    .line 176
    .line 177
    :cond_8
    const/4 v7, 0x1

    .line 178
    if-eqz v10, :cond_c

    .line 179
    .line 180
    move-object v4, v11

    .line 181
    :goto_2
    iget-object v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 182
    .line 183
    iget-object v9, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 184
    .line 185
    :cond_9
    invoke-interface {v9}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v8

    .line 189
    move-object v6, v8

    .line 190
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 191
    .line 192
    if-eqz v7, :cond_b

    .line 193
    .line 194
    iget-object v14, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 195
    .line 196
    sget-object v17, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 197
    .line 198
    if-eqz v10, :cond_a

    .line 199
    .line 200
    move-object v5, v11

    .line 201
    :goto_3
    const/16 p0, 0x0

    .line 202
    .line 203
    move/from16 v19, v3

    .line 204
    .line 205
    move-object v15, v6

    .line 206
    move-object/from16 v16, v14

    .line 207
    .line 208
    move-object/from16 v18, v5

    .line 209
    .line 210
    invoke-virtual/range {v15 .. v20}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 211
    .line 212
    .line 213
    move-result-object v5

    .line 214
    :goto_4
    invoke-interface {v9, v8, v5}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result v5

    .line 218
    if-eqz v5, :cond_9

    .line 219
    .line 220
    iget-object v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 221
    .line 222
    iget-object v6, v5, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyRepository:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;

    .line 223
    .line 224
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$0:Ljava/lang/Object;

    .line 225
    .line 226
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$1:Ljava/lang/Object;

    .line 227
    .line 228
    iput-wide v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->J$0:J

    .line 229
    .line 230
    iput v7, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->I$0:I

    .line 231
    .line 232
    iput v3, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->label:I

    .line 233
    .line 234
    const/16 v5, 0x32

    .line 235
    .line 236
    invoke-virtual {v6, v4, v5, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalHistoryRepository;->getApprovalHistory-0E7RQCE(Ljava/lang/String;ILX/2M4;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v6

    .line 240
    if-ne v6, v13, :cond_e

    .line 241
    .line 242
    return-object v13

    .line 243
    :cond_a
    iget-object v5, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 244
    .line 245
    goto :goto_3

    .line 246
    :cond_b
    iget-object v5, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 247
    .line 248
    move-object/from16 v17, v5

    .line 249
    .line 250
    iget-object v15, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->loadingState:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 251
    .line 252
    iget-object v14, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 253
    .line 254
    iget-boolean v5, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 255
    .line 256
    move-object/from16 v16, v6

    .line 257
    .line 258
    move-object/from16 v18, v15

    .line 259
    .line 260
    move-object/from16 v19, v14

    .line 261
    .line 262
    move/from16 p0, v5

    .line 263
    .line 264
    move/from16 p1, v3

    .line 265
    .line 266
    invoke-virtual/range {v16 .. v21}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 267
    .line 268
    .line 269
    move-result-object v5

    .line 270
    goto :goto_4

    .line 271
    :cond_c
    iget-object v4, v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 272
    .line 273
    goto :goto_2

    .line 274
    :cond_d
    iget v7, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->I$0:I

    .line 275
    .line 276
    iget-wide v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->J$0:J

    .line 277
    .line 278
    invoke-static {v4}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object v6

    .line 282
    :cond_e
    iget-object v9, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;

    .line 283
    .line 284
    iget-boolean v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->$reset:Z

    .line 285
    .line 286
    invoke-static {v6}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 287
    .line 288
    .line 289
    move-result-object v4

    .line 290
    if-nez v4, :cond_f

    .line 291
    .line 292
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;

    .line 293
    .line 294
    sget-object v4, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 295
    .line 296
    invoke-virtual {v4}, Lcom/facebook/aura/executors/AuraDispatchers;->default()LX/BqD;

    .line 297
    .line 298
    .line 299
    move-result-object v8

    .line 300
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;

    .line 301
    .line 302
    invoke-direct {v4, v6, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1$2$decodedItems$1;-><init>(Lcom/facebook/aura/agentpermission/ApprovalHistoryPage;LX/2M4;)V

    .line 303
    .line 304
    .line 305
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$0:Ljava/lang/Object;

    .line 306
    .line 307
    iput-object v11, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$1:Ljava/lang/Object;

    .line 308
    .line 309
    iput-object v9, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$2:Ljava/lang/Object;

    .line 310
    .line 311
    iput-object v6, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->L$3:Ljava/lang/Object;

    .line 312
    .line 313
    iput-wide v0, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->J$0:J

    .line 314
    .line 315
    iput v7, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->I$0:I

    .line 316
    .line 317
    iput-boolean v5, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->Z$0:Z

    .line 318
    .line 319
    iput v12, v2, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel$loadHistory$1;->label:I

    .line 320
    .line 321
    invoke-static {v2, v8, v4}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v4

    .line 325
    if-ne v4, v13, :cond_0

    .line 326
    .line 327
    return-object v13

    .line 328
    :cond_f
    iget-object v6, v9, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsViewModel;->historyState:LX/2J2;

    .line 329
    .line 330
    :cond_10
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v5

    .line 334
    move-object v8, v5

    .line 335
    check-cast v8, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 336
    .line 337
    if-eqz v7, :cond_11

    .line 338
    .line 339
    sget-object v10, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->ERROR:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 340
    .line 341
    :goto_5
    iget-object v9, v8, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->items:Ljava/util/List;

    .line 342
    .line 343
    iget-object v11, v8, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->nextCursor:Ljava/lang/String;

    .line 344
    .line 345
    iget-boolean v12, v8, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->canLoadMore:Z

    .line 346
    .line 347
    const/4 v13, 0x0

    .line 348
    invoke-virtual/range {v8 .. v13}, Lcom/facebook/aura/agentpermission/ApprovalHistoryState;->copy(Ljava/util/List;Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalHistoryState;

    .line 349
    .line 350
    .line 351
    move-result-object v4

    .line 352
    invoke-interface {v6, v5, v4}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 353
    .line 354
    .line 355
    move-result v4

    .line 356
    if-eqz v4, :cond_10

    .line 357
    .line 358
    goto/16 :goto_0

    .line 359
    .line 360
    :cond_11
    sget-object v10, Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;->SUCCESS:Lcom/facebook/aura/agentpermission/ApprovalHistoryLoadingState;

    .line 361
    .line 362
    goto :goto_5

    .line 363
    :cond_12
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    throw v0
.end method
