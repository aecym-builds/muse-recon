.class public abstract Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final BrowserTaskConfirmationPreviewShape:LX/2bC;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    const/high16 v0, 0x41c00000    # 24.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;->BrowserTaskConfirmationPreviewShape:LX/2bC;

    .line 7
    .line 8
    return-void
.end method

.method public static final BrowserTaskConfirmationApprovalCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "LX/2iK;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;",
            "Lcom/facebook/aura/agentpermission/RichApprovalSurface;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p9

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v10, p0

    .line 4
    .line 5
    invoke-static {v10, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v12, 0x1

    .line 9
    move-object/from16 v9, p1

    .line 10
    .line 11
    move-object/from16 v13, p5

    .line 12
    .line 13
    move-object/from16 v8, p6

    .line 14
    .line 15
    move-object/from16 v7, p7

    .line 16
    .line 17
    invoke-static {v9, v13, v8, v7, v12}, LX/005;->A14(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    const/16 v0, 0x8

    .line 21
    .line 22
    move-object/from16 v6, p8

    .line 23
    .line 24
    invoke-static {v6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    const v0, 0x17b4bf4

    .line 28
    .line 29
    .line 30
    move-object/from16 v5, p10

    .line 31
    .line 32
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 33
    .line 34
    .line 35
    move/from16 v4, p11

    .line 36
    .line 37
    and-int/lit8 v0, p11, 0x6

    .line 38
    .line 39
    if-nez v0, :cond_f

    .line 40
    .line 41
    invoke-static {v10, v5, v4}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0}, LX/003;->A06(I)I

    .line 46
    .line 47
    .line 48
    move-result v11

    .line 49
    or-int v11, v11, p11

    .line 50
    .line 51
    :goto_0
    and-int/lit8 v0, p11, 0x30

    .line 52
    .line 53
    if-nez v0, :cond_0

    .line 54
    .line 55
    invoke-static {v5, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    or-int/2addr v11, v0

    .line 60
    :cond_0
    and-int/lit16 v0, v4, 0x180

    .line 61
    .line 62
    move-object/from16 p11, p2

    .line 63
    .line 64
    if-nez v0, :cond_1

    .line 65
    .line 66
    move-object/from16 v0, p11

    .line 67
    .line 68
    invoke-static {v5, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    or-int/2addr v11, v0

    .line 73
    :cond_1
    and-int/lit16 v0, v4, 0xc00

    .line 74
    .line 75
    move-object/from16 p10, p3

    .line 76
    .line 77
    if-nez v0, :cond_2

    .line 78
    .line 79
    move-object/from16 v0, p10

    .line 80
    .line 81
    invoke-static {v5, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    or-int/2addr v11, v0

    .line 86
    :cond_2
    and-int/lit16 v0, v4, 0x6000

    .line 87
    .line 88
    move-object/from16 v14, p4

    .line 89
    .line 90
    if-nez v0, :cond_3

    .line 91
    .line 92
    invoke-static {v5, v14}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    or-int/2addr v11, v0

    .line 97
    :cond_3
    const/high16 v0, 0x30000

    .line 98
    .line 99
    and-int/2addr v0, v4

    .line 100
    if-nez v0, :cond_4

    .line 101
    .line 102
    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    invoke-static {v5, v0}, LX/008;->A0M(LX/2d4;I)I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    or-int/2addr v11, v0

    .line 111
    :cond_4
    const/high16 v0, 0x180000

    .line 112
    .line 113
    and-int/2addr v0, v4

    .line 114
    if-nez v0, :cond_5

    .line 115
    .line 116
    const/high16 v0, 0x200000

    .line 117
    .line 118
    invoke-static {v5, v8, v0, v4}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    invoke-static {v0}, LX/003;->A03(I)I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    or-int/2addr v11, v0

    .line 127
    :cond_5
    const/high16 v0, 0xc00000

    .line 128
    .line 129
    and-int/2addr v0, v4

    .line 130
    if-nez v0, :cond_7

    .line 131
    .line 132
    const/high16 v0, 0x1000000

    .line 133
    .line 134
    invoke-static {v5, v7, v0, v4}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    const/high16 v0, 0x400000

    .line 139
    .line 140
    if-eqz v3, :cond_6

    .line 141
    .line 142
    const/high16 v0, 0x800000

    .line 143
    .line 144
    :cond_6
    or-int/2addr v11, v0

    .line 145
    :cond_7
    const/high16 v0, 0x6000000

    .line 146
    .line 147
    and-int/2addr v0, v4

    .line 148
    if-nez v0, :cond_8

    .line 149
    .line 150
    invoke-static {v5, v6}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    or-int/2addr v11, v0

    .line 155
    :cond_8
    move/from16 v3, p12

    .line 156
    .line 157
    and-int/lit16 v15, v3, 0x200

    .line 158
    .line 159
    const/high16 v0, 0x30000000

    .line 160
    .line 161
    if-nez v15, :cond_9

    .line 162
    .line 163
    and-int/2addr v0, v4

    .line 164
    if-nez v0, :cond_a

    .line 165
    .line 166
    invoke-static {v5, v1}, LX/005;->A0C(LX/2d4;Ljava/lang/Object;)I

    .line 167
    .line 168
    .line 169
    move-result v0

    .line 170
    :cond_9
    or-int/2addr v11, v0

    .line 171
    :cond_a
    invoke-static {v11}, LX/005;->A1M(I)Z

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    invoke-static {v0, v5, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    if-eqz v0, :cond_e

    .line 180
    .line 181
    if-eqz v15, :cond_b

    .line 182
    .line 183
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 184
    .line 185
    :cond_b
    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    if-eq v0, v2, :cond_d

    .line 190
    .line 191
    if-ne v0, v12, :cond_10

    .line 192
    .line 193
    sget-object p2, Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;->CHECKOUT:Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;

    .line 194
    .line 195
    :goto_1
    new-instance v12, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;

    .line 196
    .line 197
    move-object/from16 p3, v12

    .line 198
    .line 199
    move-object/from16 p4, p11

    .line 200
    .line 201
    move-object/from16 p5, p10

    .line 202
    .line 203
    move-object/from16 p6, v14

    .line 204
    .line 205
    move-object/from16 p7, v13

    .line 206
    .line 207
    move-object/from16 p8, v9

    .line 208
    .line 209
    invoke-direct/range {p3 .. p8}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;LX/2iK;)V

    .line 210
    .line 211
    .line 212
    const v0, -0x2b185ab4

    .line 213
    .line 214
    .line 215
    invoke-static {v5, v12, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 216
    .line 217
    .line 218
    move-result-object p0

    .line 219
    new-instance v12, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;

    .line 220
    .line 221
    invoke-direct {v12, v10, v6}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;)V

    .line 222
    .line 223
    .line 224
    const v0, -0x2c09227a

    .line 225
    .line 226
    .line 227
    invoke-static {v5, v12, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 228
    .line 229
    .line 230
    move-result-object p6

    .line 231
    shr-int/lit8 v12, v11, 0x12

    .line 232
    .line 233
    and-int/lit8 v11, v12, 0xe

    .line 234
    .line 235
    const v0, 0x6000180

    .line 236
    .line 237
    .line 238
    or-int/2addr v11, v0

    .line 239
    sget v0, Lcom/facebook/aura/agentpermission/RichApprovalSurface;->$stable:I

    .line 240
    .line 241
    shl-int/lit8 v0, v0, 0x3

    .line 242
    .line 243
    invoke-static {v11, v0, v12}, LX/3Rq;->A00(III)I

    .line 244
    .line 245
    .line 246
    move-result v11

    .line 247
    and-int/lit16 v0, v12, 0x1c00

    .line 248
    .line 249
    or-int/2addr v0, v11

    .line 250
    const/16 p9, 0xe0

    .line 251
    .line 252
    const/16 p3, 0x0

    .line 253
    .line 254
    move-object v15, v8

    .line 255
    move-object/from16 v16, v7

    .line 256
    .line 257
    move-object/from16 p1, v1

    .line 258
    .line 259
    move/from16 p4, v2

    .line 260
    .line 261
    move-object/from16 p5, p3

    .line 262
    .line 263
    move-object/from16 p7, v5

    .line 264
    .line 265
    move/from16 p8, v0

    .line 266
    .line 267
    invoke-static/range {v15 .. v26}, Lcom/facebook/aura/agentpermission/ApprovalCardScaffoldKt;->ApprovalCardScaffold(Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;LX/JDQ;LX/3C1;Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;LX/JDQ;ZLX/JDN;LX/JDQ;LX/2d4;II)V

    .line 268
    .line 269
    .line 270
    :goto_2
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 271
    .line 272
    .line 273
    move-result-object v2

    .line 274
    if-eqz v2, :cond_c

    .line 275
    .line 276
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;

    .line 277
    .line 278
    move/from16 p3, v4

    .line 279
    .line 280
    move/from16 p4, v3

    .line 281
    .line 282
    move-object/from16 p0, v7

    .line 283
    .line 284
    move-object/from16 p1, v6

    .line 285
    .line 286
    move-object/from16 p2, v1

    .line 287
    .line 288
    move-object v15, v13

    .line 289
    move-object/from16 v16, v8

    .line 290
    .line 291
    move-object v11, v9

    .line 292
    move-object/from16 v12, p11

    .line 293
    .line 294
    move-object/from16 v13, p10

    .line 295
    .line 296
    move-object v9, v0

    .line 297
    invoke-direct/range {v9 .. v21}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 298
    .line 299
    .line 300
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 301
    .line 302
    :cond_c
    return-void

    .line 303
    :cond_d
    sget-object p2, Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;->PERMISSION:Lcom/facebook/aura/agentpermission/ApprovalCardActionsStyle;

    .line 304
    .line 305
    goto :goto_1

    .line 306
    :cond_e
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 307
    .line 308
    .line 309
    goto :goto_2

    .line 310
    :cond_f
    move v11, v4

    .line 311
    goto/16 :goto_0

    .line 312
    .line 313
    :cond_10
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    throw v0
.end method

.method public static final BrowserTaskConfirmationPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p2

    .line 1
    .line 2
    const v0, -0x796c541

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p3

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_18

    .line 17
    .line 18
    invoke-static {v5, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v7

    .line 26
    or-int v7, v7, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v4, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v3, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v7, v0

    .line 39
    :cond_0
    and-int/lit8 v9, p5, 0x4

    .line 40
    .line 41
    if-eqz v9, :cond_17

    .line 42
    .line 43
    or-int/lit16 v7, v7, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    and-int/lit16 v8, v7, 0x93

    .line 46
    .line 47
    const/16 v0, 0x92

    .line 48
    .line 49
    const/4 v6, 0x0

    .line 50
    invoke-static {v8, v0}, LX/003;->A1H(II)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-static {v0, v3, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_4

    .line 59
    .line 60
    if-eqz v9, :cond_2

    .line 61
    .line 62
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    :cond_2
    invoke-static {v3, v6}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt;->isLiveBrowserPreviewBehindSheet(LX/2d4;I)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_5

    .line 69
    .line 70
    const v0, -0x225180df

    .line 71
    .line 72
    .line 73
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 74
    .line 75
    .line 76
    iget-object v8, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 77
    .line 78
    and-int/lit16 v0, v7, 0x3f0

    .line 79
    .line 80
    move-object v9, v1

    .line 81
    move-object v10, v3

    .line 82
    move v11, v0

    .line 83
    move v12, v6

    .line 84
    move-object v7, v8

    .line 85
    move-object v8, v4

    .line 86
    invoke-static/range {v7 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionOpenBrowserLinkKt;->OpenBrowserLink(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 87
    .line 88
    .line 89
    invoke-static {v3, v3}, LX/003;->A0W(LX/2d4;Ljava/lang/Object;)LX/J7V;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    if-eqz v3, :cond_3

    .line 94
    .line 95
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$1;

    .line 96
    .line 97
    move-object/from16 p0, v0

    .line 98
    .line 99
    move-object/from16 p1, v5

    .line 100
    .line 101
    move-object/from16 p2, v4

    .line 102
    .line 103
    move-object/from16 p3, v1

    .line 104
    .line 105
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 106
    .line 107
    .line 108
    :goto_2
    invoke-static {v3, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :cond_3
    return-void

    .line 112
    :cond_4
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 113
    .line 114
    .line 115
    goto/16 :goto_8

    .line 116
    .line 117
    :cond_5
    const v0, -0x224f20bd

    .line 118
    .line 119
    .line 120
    invoke-static {v3, v0}, LX/003;->A0q(LX/2d4;I)V

    .line 121
    .line 122
    .line 123
    invoke-static {v3}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 124
    .line 125
    .line 126
    move-result-object v8

    .line 127
    invoke-static {v3}, LX/3Rp;->A06(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 128
    .line 129
    .line 130
    move-result-object p4

    .line 131
    invoke-interface {v3, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v10

    .line 139
    if-nez v0, :cond_6

    .line 140
    .line 141
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 142
    .line 143
    if-ne v10, v0, :cond_7

    .line 144
    .line 145
    :cond_6
    sget-object v0, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->INSTANCE:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;

    .line 146
    .line 147
    invoke-virtual {v0, v8}, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpeners;->opener(LX/AHE;)Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 148
    .line 149
    .line 150
    move-result-object v10

    .line 151
    invoke-interface {v3, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    :cond_7
    check-cast v10, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 155
    .line 156
    invoke-interface {v3, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v11

    .line 164
    if-nez v0, :cond_8

    .line 165
    .line 166
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 167
    .line 168
    if-ne v11, v0, :cond_9

    .line 169
    .line 170
    :cond_8
    sget-object v0, Lcom/facebook/aura/browsertask/api/BrowserTasks;->INSTANCE:Lcom/facebook/aura/browsertask/api/BrowserTasks;

    .line 171
    .line 172
    invoke-virtual {v0, v8}, Lcom/facebook/aura/browsertask/api/BrowserTasks;->source(LX/AHE;)Lcom/facebook/aura/browsertask/api/BrowserTaskSource;

    .line 173
    .line 174
    .line 175
    move-result-object v11

    .line 176
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_9
    check-cast v11, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;

    .line 180
    .line 181
    invoke-interface {v11}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getActiveTasks()LX/2J3;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-static {v3, v0, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 186
    .line 187
    .line 188
    move-result-object v9

    .line 189
    invoke-interface {v11}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getPresentedTask()LX/2J3;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-static {v3, v0, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 194
    .line 195
    .line 196
    move-result-object v13

    .line 197
    invoke-interface {v11}, Lcom/facebook/aura/browsertask/api/BrowserTaskSource;->getPresentedThumbnailUri()LX/2J3;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    invoke-static {v3, v0, v6}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 202
    .line 203
    .line 204
    move-result-object v14

    .line 205
    invoke-static {v9}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 210
    .line 211
    .line 212
    move-result-object v12

    .line 213
    :cond_a
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    const/4 v15, 0x0

    .line 218
    if-eqz v0, :cond_16

    .line 219
    .line 220
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v9

    .line 224
    move-object v0, v9

    .line 225
    check-cast v0, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 226
    .line 227
    iget-object v11, v0, Lcom/facebook/aura/model/BrowserTaskPresentation;->browserTaskId:Ljava/lang/String;

    .line 228
    .line 229
    iget-object v0, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 230
    .line 231
    invoke-static {v11, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    if-eqz v0, :cond_a

    .line 236
    .line 237
    :goto_3
    check-cast v9, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 238
    .line 239
    if-nez v9, :cond_b

    .line 240
    .line 241
    invoke-interface {v13}, LX/16A;->getValue()Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v9

    .line 245
    check-cast v9, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 246
    .line 247
    if-eqz v9, :cond_15

    .line 248
    .line 249
    iget-object v11, v9, Lcom/facebook/aura/model/BrowserTaskPresentation;->browserTaskId:Ljava/lang/String;

    .line 250
    .line 251
    iget-object v0, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 252
    .line 253
    invoke-static {v11, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    move-result v0

    .line 257
    if-eqz v0, :cond_15

    .line 258
    .line 259
    :cond_b
    :goto_4
    invoke-interface {v13}, LX/16A;->getValue()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    check-cast v0, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 264
    .line 265
    if-eqz v0, :cond_14

    .line 266
    .line 267
    iget-object v11, v0, Lcom/facebook/aura/model/BrowserTaskPresentation;->browserTaskId:Ljava/lang/String;

    .line 268
    .line 269
    :goto_5
    iget-object v0, v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 270
    .line 271
    invoke-static {v11, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v13

    .line 275
    if-eqz v9, :cond_12

    .line 276
    .line 277
    iget-object v11, v9, Lcom/facebook/aura/model/BrowserTaskPresentation;->latestScreenshot:Lcom/facebook/aura/model/BrowserTaskScreenshot;

    .line 278
    .line 279
    if-eqz v11, :cond_13

    .line 280
    .line 281
    iget-object v0, v11, Lcom/facebook/aura/model/BrowserTaskScreenshot;->url:Ljava/lang/String;

    .line 282
    .line 283
    :goto_6
    invoke-static {v3, v0, v8}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 284
    .line 285
    .line 286
    move-result v12

    .line 287
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    if-nez v12, :cond_c

    .line 292
    .line 293
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 294
    .line 295
    if-ne v0, v12, :cond_d

    .line 296
    .line 297
    :cond_c
    if-eqz v11, :cond_11

    .line 298
    .line 299
    iget-object v12, v11, Lcom/facebook/aura/model/BrowserTaskScreenshot;->url:Ljava/lang/String;

    .line 300
    .line 301
    if-eqz v12, :cond_11

    .line 302
    .line 303
    sget-object v0, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 304
    .line 305
    invoke-virtual {v0, v12, v8}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveRawAssetUrl(Ljava/lang/String;LX/AHE;)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    :goto_7
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    :cond_d
    check-cast v0, Ljava/lang/String;

    .line 313
    .line 314
    if-eqz v13, :cond_e

    .line 315
    .line 316
    invoke-static {v14}, LX/3Rq;->A19(LX/16A;)Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v14

    .line 320
    if-nez v14, :cond_f

    .line 321
    .line 322
    :cond_e
    move-object v14, v0

    .line 323
    :cond_f
    invoke-static {v14, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    move-result v0

    .line 327
    if-eqz v0, :cond_10

    .line 328
    .line 329
    if-eqz v11, :cond_10

    .line 330
    .line 331
    iget v8, v11, Lcom/facebook/aura/model/BrowserTaskScreenshot;->width:I

    .line 332
    .line 333
    if-lez v8, :cond_10

    .line 334
    .line 335
    iget v0, v11, Lcom/facebook/aura/model/BrowserTaskScreenshot;->height:I

    .line 336
    .line 337
    if-lez v0, :cond_10

    .line 338
    .line 339
    int-to-float v8, v8

    .line 340
    int-to-float v0, v0

    .line 341
    div-float/2addr v8, v0

    .line 342
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 343
    .line 344
    .line 345
    move-result-object v15

    .line 346
    :cond_10
    sget-object v16, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;->BrowserTaskConfirmationPreviewShape:LX/2bC;

    .line 347
    .line 348
    new-instance v8, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;

    .line 349
    .line 350
    move-object/from16 v18, v14

    .line 351
    .line 352
    move-object/from16 p1, v10

    .line 353
    .line 354
    move-object/from16 p2, v9

    .line 355
    .line 356
    move-object/from16 p3, v4

    .line 357
    .line 358
    move-object/from16 v17, v8

    .line 359
    .line 360
    invoke-direct/range {v17 .. v23}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2;-><init>(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Lcom/facebook/aura/model/BrowserTaskPresentation;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 361
    .line 362
    .line 363
    const v0, 0x6a410d1a

    .line 364
    .line 365
    .line 366
    invoke-static {v3, v8, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 367
    .line 368
    .line 369
    move-result-object v18

    .line 370
    shl-int/lit8 v0, v7, 0x3

    .line 371
    .line 372
    and-int/lit16 v0, v0, 0x1c00

    .line 373
    .line 374
    or-int/lit16 v0, v0, 0x6180

    .line 375
    .line 376
    move/from16 p1, v0

    .line 377
    .line 378
    move/from16 p2, v6

    .line 379
    .line 380
    move-object/from16 p0, v3

    .line 381
    .line 382
    move-object/from16 v17, v1

    .line 383
    .line 384
    invoke-static/range {v14 .. v21}, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt;->ApprovalBrowserScreenshot(Ljava/lang/String;Ljava/lang/Float;LX/2bW;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 385
    .line 386
    .line 387
    :goto_8
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 388
    .line 389
    .line 390
    move-result-object v3

    .line 391
    if-eqz v3, :cond_3

    .line 392
    .line 393
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$3;

    .line 394
    .line 395
    move-object/from16 p0, v0

    .line 396
    .line 397
    move-object/from16 p1, v5

    .line 398
    .line 399
    move-object/from16 p2, v4

    .line 400
    .line 401
    move-object/from16 p3, v1

    .line 402
    .line 403
    move/from16 p4, v2

    .line 404
    .line 405
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 406
    .line 407
    .line 408
    goto/16 :goto_2

    .line 409
    .line 410
    :cond_11
    move-object v0, v15

    .line 411
    goto :goto_7

    .line 412
    :cond_12
    move-object v11, v15

    .line 413
    :cond_13
    move-object v0, v15

    .line 414
    goto/16 :goto_6

    .line 415
    .line 416
    :cond_14
    move-object v11, v15

    .line 417
    goto/16 :goto_5

    .line 418
    .line 419
    :cond_15
    move-object v9, v15

    .line 420
    goto/16 :goto_4

    .line 421
    .line 422
    :cond_16
    move-object v9, v15

    .line 423
    goto/16 :goto_3

    .line 424
    .line 425
    :cond_17
    and-int/lit16 v0, v2, 0x180

    .line 426
    .line 427
    if-nez v0, :cond_1

    .line 428
    .line 429
    invoke-static {v3, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 430
    .line 431
    .line 432
    move-result v0

    .line 433
    or-int/2addr v7, v0

    .line 434
    goto/16 :goto_1

    .line 435
    .line 436
    :cond_18
    move v7, v2

    .line 437
    goto/16 :goto_0
.end method

.method public static final BrowserTaskConfirmationPreview$lambda$2(LX/16A;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Ljava/util/List<",
            "Lcom/facebook/aura/model/BrowserTaskPresentation;",
            ">;>;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/model/BrowserTaskPresentation;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/3Rp;->A0x(LX/16A;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final BrowserTaskConfirmationPreview$lambda$3(LX/16A;)Lcom/facebook/aura/model/BrowserTaskPresentation;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/model/BrowserTaskPresentation;",
            ">;)",
            "Lcom/facebook/aura/model/BrowserTaskPresentation;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final BrowserTaskConfirmationPreview$lambda$4(LX/16A;)Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/3Rq;->A19(LX/16A;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$BrowserTaskConfirmationPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;->BrowserTaskConfirmationPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
