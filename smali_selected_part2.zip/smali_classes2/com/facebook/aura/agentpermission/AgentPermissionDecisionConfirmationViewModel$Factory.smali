.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;->userSession:LX/AHE;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 3
    .line 4
    invoke-direct {v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;-><init>(LX/AHE;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public create()Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;
    .locals 1

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel$Factory;->userSession:LX/AHE;

    .line 268435457
    .line 268435458
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 268435459
    .line 268435460
    invoke-direct {v0, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;-><init>(LX/AHE;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object v0
.end method
