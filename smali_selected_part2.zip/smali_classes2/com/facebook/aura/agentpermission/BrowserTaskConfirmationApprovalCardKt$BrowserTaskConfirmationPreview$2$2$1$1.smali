.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $onOpenBrowserClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$opener:Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 8
    .line 9
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationPreview$2$2$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 12
    .line 13
    invoke-interface {v2, v1, v0}, Lcom/facebook/aura/browsertask/api/navigation/BrowserTaskOpener;->openPreview(Ljava/lang/String;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
