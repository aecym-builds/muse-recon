.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $attentionLabel:Ljava/lang/String;

.field public final synthetic $confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

.field public final synthetic $decisionOptions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $headline:LX/2iK;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $narrative:Ljava/lang/String;

.field public final synthetic $onOpenBrowserClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reviewText:Ljava/lang/String;

.field public final synthetic $surface:Lcom/facebook/aura/agentpermission/RichApprovalSurface;

.field public final synthetic $treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;",
            "LX/2iK;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            ">;",
            "Lcom/facebook/aura/agentpermission/RichApprovalSurface;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$headline:LX/2iK;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$narrative:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$attentionLabel:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$reviewText:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$decisionOptions:Ljava/util/List;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$surface:Lcom/facebook/aura/agentpermission/RichApprovalSurface;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$modifier:LX/3C1;

    .line 19
    .line 20
    iput p11, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$$changed:I

    .line 21
    .line 22
    iput p12, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$$default:I

    .line 23
    .line 24
    const/4 v0, 0x2

    .line 25
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 26
    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 13

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$confirmation:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$headline:LX/2iK;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$narrative:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$attentionLabel:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$reviewText:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$decisionOptions:Ljava/util/List;

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$surface:Lcom/facebook/aura/agentpermission/RichApprovalSurface;

    .line 15
    .line 16
    iget-object v9, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$onOpenBrowserClick:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iget-object v10, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$modifier:LX/3C1;

    .line 19
    .line 20
    iget v0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$$changed:I

    .line 21
    .line 22
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 23
    .line 24
    .line 25
    move-result v12

    .line 26
    iget p0, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$3;->$$default:I

    .line 27
    .line 28
    move-object v11, p1

    .line 29
    invoke-static/range {v1 .. v13}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt;->BrowserTaskConfirmationApprovalCard(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;LX/2iK;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;Ljava/util/List;Lcom/facebook/aura/agentpermission/RichApprovalSurface;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 30
    .line 31
    .line 32
    return-void
.end method
