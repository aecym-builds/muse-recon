.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;->invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$AgentPermissionApprovalsScreen$4$1$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iget-object v1, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;

    .line 9
    .line 10
    invoke-direct {v0, v1}, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-interface {v2, v0, v3}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
