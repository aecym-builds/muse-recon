.class public final Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $outcome:Ljava/lang/String;

.field public final synthetic $requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

.field public final synthetic $summary:Ljava/lang/String;

.field public final synthetic $title:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$outcome:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$title:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$summary:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 9
    .line 10
    const/4 v0, 0x3

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3dS;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->invoke(LX/3dS;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 56

    .line 268435456
    const/4 v7, 0x0

    .line 268435457
    move-object/from16 v0, p1

    .line 268435458
    .line 268435459
    move/from16 v2, p3

    .line 268435460
    .line 268435461
    invoke-static {v0, v7, v2}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 268435462
    .line 268435463
    .line 268435464
    move-result v1

    .line 268435465
    move-object/from16 v0, p2

    .line 268435466
    .line 268435467
    invoke-static {v1, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435468
    .line 268435469
    .line 268435470
    move-result v1

    .line 268435471
    if-eqz v1, :cond_3

    .line 268435472
    .line 268435473
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 268435474
    .line 268435475
    const/16 v18, 0x0

    .line 268435476
    .line 268435477
    sget-object v16, LX/2sI;->A02:LX/2wD;

    .line 268435478
    .line 268435479
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 268435480
    .line 268435481
    const/4 v4, 0x6

    .line 268435482
    invoke-static {v0, v1}, LX/07H;->A00(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)F

    .line 268435483
    .line 268435484
    .line 268435485
    move-result v5

    .line 268435486
    const/4 v6, 0x0

    .line 268435487
    move-object/from16 v3, v16

    .line 268435488
    .line 268435489
    invoke-static {v3, v5, v6}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 268435490
    .line 268435491
    .line 268435492
    move-result-object v3

    .line 268435493
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 268435494
    .line 268435495
    const/16 v22, 0x7

    .line 268435496
    .line 268435497
    invoke-static {v3, v6, v6, v6, v5}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 268435498
    .line 268435499
    .line 268435500
    move-result-object v3

    .line 268435501
    move-object/from16 v9, p0

    .line 268435502
    .line 268435503
    iget-object v15, v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435504
    .line 268435505
    iget-object v6, v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$outcome:Ljava/lang/String;

    .line 268435506
    .line 268435507
    move-object/from16 v17, v6

    .line 268435508
    .line 268435509
    iget-object v6, v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$title:Ljava/lang/String;

    .line 268435510
    .line 268435511
    move-object/from16 v36, v6

    .line 268435512
    .line 268435513
    iget-object v8, v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$summary:Ljava/lang/String;

    .line 268435514
    .line 268435515
    iget-object v14, v9, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt$AgentPermissionHistoryDetailsSheet$4;->$requestPreviewDocument:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;

    .line 268435516
    .line 268435517
    invoke-static {v0}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 268435518
    .line 268435519
    .line 268435520
    move-result-object v13

    .line 268435521
    move-object v6, v0

    .line 268435522
    check-cast v6, LX/J7I;

    .line 268435523
    .line 268435524
    invoke-static {v6}, LX/003;->A0F(LX/J7I;)I

    .line 268435525
    .line 268435526
    .line 268435527
    move-result v12

    .line 268435528
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 268435529
    .line 268435530
    .line 268435531
    move-result-object v11

    .line 268435532
    invoke-static {v0, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 268435533
    .line 268435534
    .line 268435535
    move-result-object v10

    .line 268435536
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 268435537
    .line 268435538
    iget-object v3, v6, LX/J7I;->A0V:LX/3DJ;

    .line 268435539
    .line 268435540
    if-nez v3, :cond_0

    .line 268435541
    .line 268435542
    invoke-static {}, LX/1VY;->A00()V

    .line 268435543
    .line 268435544
    .line 268435545
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435546
    .line 268435547
    .line 268435548
    move-result-object v0

    .line 268435549
    throw v0

    .line 268435550
    :cond_0
    invoke-static {v0, v6, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 268435551
    .line 268435552
    .line 268435553
    invoke-static {v0, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435554
    .line 268435555
    .line 268435556
    sget p2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 268435557
    .line 268435558
    const/16 p3, 0x4

    .line 268435559
    .line 268435560
    move-object/from16 v54, v15

    .line 268435561
    .line 268435562
    move-object/from16 v55, v17

    .line 268435563
    .line 268435564
    move-object/from16 p0, v18

    .line 268435565
    .line 268435566
    move-object/from16 p1, v0

    .line 268435567
    .line 268435568
    invoke-static/range {v54 .. v59}, Lcom/facebook/aura/agentpermission/AgentPermissionHistoryDetailsSheetKt;->HistoryMetadataRow(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 268435569
    .line 268435570
    .line 268435571
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 268435572
    .line 268435573
    invoke-static {v0, v2, v3}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435574
    .line 268435575
    .line 268435576
    move-object/from16 v17, v18

    .line 268435577
    .line 268435578
    move/from16 v19, v7

    .line 268435579
    .line 268435580
    move-object/from16 v20, v0

    .line 268435581
    .line 268435582
    move/from16 v21, v7

    .line 268435583
    .line 268435584
    invoke-static/range {v17 .. v22}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraDivider(LX/3C1;Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle;ZLX/2d4;II)V

    .line 268435585
    .line 268435586
    .line 268435587
    invoke-static {v0, v2, v5}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435588
    .line 268435589
    .line 268435590
    invoke-virtual {v1, v0, v4}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 268435591
    .line 268435592
    .line 268435593
    move-result-object v9

    .line 268435594
    iget-object v9, v9, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title3Emphasized:LX/2hg;

    .line 268435595
    .line 268435596
    invoke-static {v0, v1}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 268435597
    .line 268435598
    .line 268435599
    move-result-wide v19

    .line 268435600
    const/16 v35, 0x3ff2

    .line 268435601
    .line 268435602
    move-object/from16 v22, v18

    .line 268435603
    .line 268435604
    move-object/from16 v23, v18

    .line 268435605
    .line 268435606
    move-object/from16 v24, v18

    .line 268435607
    .line 268435608
    move/from16 v25, v7

    .line 268435609
    .line 268435610
    move/from16 v26, v7

    .line 268435611
    .line 268435612
    move/from16 v27, v7

    .line 268435613
    .line 268435614
    move/from16 v28, v7

    .line 268435615
    .line 268435616
    move-object/from16 v29, v18

    .line 268435617
    .line 268435618
    move-object/from16 v30, v18

    .line 268435619
    .line 268435620
    move-object/from16 v31, v18

    .line 268435621
    .line 268435622
    move-object/from16 v32, v0

    .line 268435623
    .line 268435624
    move/from16 v33, v7

    .line 268435625
    .line 268435626
    move/from16 v34, v7

    .line 268435627
    .line 268435628
    move-object/from16 v17, v36

    .line 268435629
    .line 268435630
    move-object/from16 v21, v9

    .line 268435631
    .line 268435632
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 268435633
    .line 268435634
    .line 268435635
    if-nez v8, :cond_2

    .line 268435636
    .line 268435637
    const v8, 0x3f9a9897

    .line 268435638
    .line 268435639
    .line 268435640
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 268435641
    .line 268435642
    .line 268435643
    invoke-static {v6, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435644
    .line 268435645
    .line 268435646
    :goto_0
    if-nez v14, :cond_1

    .line 268435647
    .line 268435648
    invoke-static {v15}, Lcom/facebook/aura/gateway/AgentPermissionHeadlineKt;->hasRequestPreview(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 268435649
    .line 268435650
    .line 268435651
    move-result v8

    .line 268435652
    if-nez v8, :cond_1

    .line 268435653
    .line 268435654
    const v1, 0x3fab7e2f

    .line 268435655
    .line 268435656
    .line 268435657
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 268435658
    .line 268435659
    .line 268435660
    :goto_1
    invoke-static {v6}, LX/003;->A0u(LX/J7I;)V

    .line 268435661
    .line 268435662
    .line 268435663
    return-void

    .line 268435664
    :cond_1
    const v8, 0x3f9fd995

    .line 268435665
    .line 268435666
    .line 268435667
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 268435668
    .line 268435669
    .line 268435670
    invoke-static {v0, v2, v5}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435671
    .line 268435672
    .line 268435673
    const v5, 0x7f120144

    .line 268435674
    .line 268435675
    .line 268435676
    invoke-static {v0, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435677
    .line 268435678
    .line 268435679
    move-result-object v17

    .line 268435680
    invoke-virtual {v1, v0, v4}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 268435681
    .line 268435682
    .line 268435683
    move-result-object v4

    .line 268435684
    iget-object v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->footnoteEmphasized:LX/2hg;

    .line 268435685
    .line 268435686
    sget-object v38, LX/IzA;->A01:LX/36I;

    .line 268435687
    .line 268435688
    const v49, 0xffffdf

    .line 268435689
    .line 268435690
    .line 268435691
    const-wide/16 v50, 0x0

    .line 268435692
    .line 268435693
    move-object/from16 v36, v18

    .line 268435694
    .line 268435695
    move-object/from16 v37, v4

    .line 268435696
    .line 268435697
    move-object/from16 v39, v18

    .line 268435698
    .line 268435699
    move-object/from16 v40, v18

    .line 268435700
    .line 268435701
    move-object/from16 v41, v18

    .line 268435702
    .line 268435703
    move-object/from16 v42, v18

    .line 268435704
    .line 268435705
    move-object/from16 v43, v18

    .line 268435706
    .line 268435707
    move-object/from16 v44, v18

    .line 268435708
    .line 268435709
    move-object/from16 v45, v18

    .line 268435710
    .line 268435711
    move/from16 v46, v7

    .line 268435712
    .line 268435713
    move/from16 v47, v7

    .line 268435714
    .line 268435715
    move/from16 v48, v7

    .line 268435716
    .line 268435717
    move-wide/from16 v52, v50

    .line 268435718
    .line 268435719
    move-wide/from16 v54, v50

    .line 268435720
    .line 268435721
    move-wide/from16 p0, v50

    .line 268435722
    .line 268435723
    invoke-static/range {v36 .. v57}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 268435724
    .line 268435725
    .line 268435726
    move-result-object v21

    .line 268435727
    invoke-static {v0, v1}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 268435728
    .line 268435729
    .line 268435730
    move-result-wide v19

    .line 268435731
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 268435732
    .line 268435733
    .line 268435734
    invoke-static {v0, v2, v3}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435735
    .line 268435736
    .line 268435737
    iget-object v2, v15, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestPreview:Ljava/lang/String;

    .line 268435738
    .line 268435739
    invoke-static {v0, v1}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 268435740
    .line 268435741
    .line 268435742
    move-result-object v19

    .line 268435743
    invoke-static {v0, v1}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 268435744
    .line 268435745
    .line 268435746
    move-result-wide v20

    .line 268435747
    sget-object v23, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_MULTI_APPROVAL_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 268435748
    .line 268435749
    const/high16 v26, 0x1b0000

    .line 268435750
    .line 268435751
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;->$stable:I

    .line 268435752
    .line 268435753
    or-int v26, v26, v1

    .line 268435754
    .line 268435755
    shl-int/lit8 v1, p2, 0xc

    .line 268435756
    .line 268435757
    or-int v26, v26, v1

    .line 268435758
    .line 268435759
    move-object/from16 v17, v14

    .line 268435760
    .line 268435761
    move-object/from16 v18, v2

    .line 268435762
    .line 268435763
    move-object/from16 v22, v15

    .line 268435764
    .line 268435765
    move-object/from16 v24, v16

    .line 268435766
    .line 268435767
    move-object/from16 v25, v0

    .line 268435768
    .line 268435769
    invoke-static/range {v17 .. v27}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->AgentPermissionRequestPreviewContent-hYmLsZ8(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewDocument;Ljava/lang/String;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V

    .line 268435770
    .line 268435771
    .line 268435772
    goto :goto_1

    .line 268435773
    :cond_2
    const v9, 0x3f9a9898

    .line 268435774
    .line 268435775
    .line 268435776
    invoke-interface {v0, v9}, LX/2d4;->Agj(I)V

    .line 268435777
    .line 268435778
    .line 268435779
    invoke-static {v0, v2, v3}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 268435780
    .line 268435781
    .line 268435782
    invoke-static {v0, v1}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 268435783
    .line 268435784
    .line 268435785
    move-result-object v21

    .line 268435786
    invoke-static {v0, v1}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 268435787
    .line 268435788
    .line 268435789
    move-result-wide v19

    .line 268435790
    move-object/from16 v17, v8

    .line 268435791
    .line 268435792
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 268435793
    .line 268435794
    .line 268435795
    invoke-static {v6, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435796
    .line 268435797
    .line 268435798
    goto/16 :goto_0

    .line 268435799
    .line 268435800
    :cond_3
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 268435801
    .line 268435802
    .line 268435803
    return-void
.end method
