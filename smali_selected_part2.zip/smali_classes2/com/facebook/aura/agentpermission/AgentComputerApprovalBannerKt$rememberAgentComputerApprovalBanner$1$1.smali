.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3C1;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3C1;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;->invoke(LX/3C1;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3C1;LX/2d4;I)V
    .locals 4

    .line 268435456
    const/4 v3, 0x0

    .line 268435457
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    and-int/lit8 v0, p3, 0x6

    .line 268435461
    .line 268435462
    if-nez v0, :cond_0

    .line 268435463
    .line 268435464
    invoke-static {p2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435465
    .line 268435466
    .line 268435467
    move-result v0

    .line 268435468
    or-int/2addr p3, v0

    .line 268435469
    :cond_0
    invoke-static {p3}, LX/005;->A1G(I)Z

    .line 268435470
    .line 268435471
    .line 268435472
    move-result v0

    .line 268435473
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435474
    .line 268435475
    .line 268435476
    move-result v0

    .line 268435477
    if-eqz v0, :cond_1

    .line 268435478
    .line 268435479
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$rememberAgentComputerApprovalBanner$1$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 268435480
    .line 268435481
    sget v1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->$stable:I

    .line 268435482
    .line 268435483
    shl-int/lit8 v0, p3, 0x3

    .line 268435484
    .line 268435485
    and-int/lit8 v0, v0, 0x70

    .line 268435486
    .line 268435487
    or-int/2addr v0, v1

    .line 268435488
    invoke-static {v2, p1, p2, v0, v3}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt;->AgentComputerApprovalBanner(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3C1;LX/2d4;II)V

    .line 268435489
    .line 268435490
    .line 268435491
    return-void

    .line 268435492
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435493
    .line 268435494
    .line 268435495
    return-void
.end method
