.class public abstract Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CALLER_CONTEXT:Ljava/lang/String; = "AgentApprovalNotification"

.field public static final ICON_FETCH_TIMEOUT_MS:J = 0xbb8L


# direct methods
.method public static final approvalLogoUri(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/JDM;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconUrl:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-static {v0}, LX/3Rr;->A0k(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v3

    .line 7
    iget-object v2, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->richPayload:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRichPayload;

    .line 8
    .line 9
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;

    .line 14
    .line 15
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserTaskConfirmationApproval;->browserTaskId:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Ljava/lang/String;

    .line 22
    .line 23
    :goto_0
    invoke-static {v2, v1}, Lcom/facebook/aura/agentpermission/CheckoutApprovalSharedKt;->checkoutFaviconUri(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    :cond_0
    return-object v0

    .line 28
    :cond_1
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 29
    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;

    .line 33
    .line 34
    iget-object v2, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$BrowserCheckoutApproval;->merchantUrl:Ljava/lang/String;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$StripeLinkCheckoutApproval;

    .line 38
    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$StripeLinkCheckoutApproval;

    .line 42
    .line 43
    iget-object v2, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$StripeLinkCheckoutApproval;->merchantUrl:Ljava/lang/String;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_3
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ShopifyCheckoutApproval;

    .line 47
    .line 48
    if-eqz v0, :cond_5

    .line 49
    .line 50
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ShopifyCheckoutApproval;

    .line 51
    .line 52
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ShopifyCheckoutApproval;->merchant:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;

    .line 53
    .line 54
    if-eqz v0, :cond_4

    .line 55
    .line 56
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;->iconUrl:Ljava/lang/String;

    .line 57
    .line 58
    if-eqz v0, :cond_4

    .line 59
    .line 60
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->trimToNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    if-nez v0, :cond_0

    .line 65
    .line 66
    :cond_4
    if-nez v3, :cond_a

    .line 67
    .line 68
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ShopifyCheckoutApproval;->merchant:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;

    .line 69
    .line 70
    :goto_1
    if-eqz v0, :cond_7

    .line 71
    .line 72
    iget-object v2, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;->url:Ljava/lang/String;

    .line 73
    .line 74
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;->name:Ljava/lang/String;

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_5
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$FlightCheckoutApproval;

    .line 78
    .line 79
    if-eqz v0, :cond_8

    .line 80
    .line 81
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$FlightCheckoutApproval;

    .line 82
    .line 83
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$FlightCheckoutApproval;->merchant:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;

    .line 84
    .line 85
    if-eqz v0, :cond_6

    .line 86
    .line 87
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;->iconUrl:Ljava/lang/String;

    .line 88
    .line 89
    if-eqz v0, :cond_6

    .line 90
    .line 91
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->trimToNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    if-nez v0, :cond_0

    .line 96
    .line 97
    :cond_6
    if-nez v3, :cond_a

    .line 98
    .line 99
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$FlightCheckoutApproval;->merchant:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;

    .line 100
    .line 101
    goto :goto_1

    .line 102
    :cond_7
    move-object v2, v1

    .line 103
    goto :goto_0

    .line 104
    :cond_8
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ReservationCheckoutApproval;

    .line 105
    .line 106
    if-eqz v0, :cond_9

    .line 107
    .line 108
    if-nez v3, :cond_a

    .line 109
    .line 110
    check-cast v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ReservationCheckoutApproval;

    .line 111
    .line 112
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$ReservationCheckoutApproval;->merchant:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;

    .line 113
    .line 114
    if-eqz v0, :cond_b

    .line 115
    .line 116
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CheckoutMerchant;->iconUrl:Ljava/lang/String;

    .line 117
    .line 118
    if-eqz v0, :cond_b

    .line 119
    .line 120
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/CheckoutRowPrimitivesKt;->trimToNonEmpty(Ljava/lang/String;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    return-object v0

    .line 125
    :cond_9
    instance-of v0, v2, Lcom/facebook/aura/gateway/DeliveryCheckoutApproval;

    .line 126
    .line 127
    if-nez v0, :cond_a

    .line 128
    .line 129
    instance-of v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$CarRentalReservationApproval;

    .line 130
    .line 131
    if-nez v0, :cond_a

    .line 132
    .line 133
    instance-of v0, v2, Lcom/facebook/aura/gateway/ConnectorOrderCheckout;

    .line 134
    .line 135
    if-nez v0, :cond_a

    .line 136
    .line 137
    if-eqz v3, :cond_b

    .line 138
    .line 139
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->payloadType:Lcom/facebook/aura/gateway/AgentPermissionPayloadType;

    .line 140
    .line 141
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/AgentPermissionPayloadType;->getRendersAsConnectorCard()Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-eqz v0, :cond_b

    .line 146
    .line 147
    :cond_a
    return-object v3

    .line 148
    :cond_b
    return-object v1
.end method

.method public static final approvalNotificationIcon(Landroid/content/Context;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;

    .line 1
    .line 2
    if-eqz v0, :cond_6

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_6

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v4, :cond_7

    .line 28
    .line 29
    iget-object p1, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$1:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 32
    .line 33
    iget-object p0, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$0:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p0, Landroid/content/Context;

    .line 36
    .line 37
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    check-cast v1, Landroid/graphics/Bitmap;

    .line 41
    .line 42
    if-eqz v1, :cond_3

    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->INSTANCE:Lcom/facebook/aura/notifications/attention/AttentionNotifications;

    .line 45
    .line 46
    invoke-virtual {v0, p0, v1}, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->iconTile(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    .line 47
    .line 48
    .line 49
    move-result-object v6

    .line 50
    :cond_1
    return-object v6

    .line 51
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const v0, 0x1050005

    .line 59
    .line 60
    .line 61
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    invoke-static {p1, p2}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt;->approvalLogoUri(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/JDM;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    const/4 v1, 0x0

    .line 70
    if-eqz v2, :cond_3

    .line 71
    .line 72
    const/4 v0, 0x0

    .line 73
    :try_start_0
    invoke-static {v2}, LX/ATP;->A01(Ljava/lang/String;)Landroid/net/Uri;

    .line 74
    .line 75
    .line 76
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 77
    :catch_0
    if-eqz v0, :cond_3

    .line 78
    .line 79
    new-instance v2, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;

    .line 80
    .line 81
    invoke-direct {v2, v0, v3, v1}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$logo$2$1;-><init>(Landroid/net/Uri;ILX/2M4;)V

    .line 82
    .line 83
    .line 84
    iput-object p0, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$0:Ljava/lang/Object;

    .line 85
    .line 86
    iput-object p1, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$1:Ljava/lang/Object;

    .line 87
    .line 88
    iput-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$2:Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v1, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->L$3:Ljava/lang/Object;

    .line 91
    .line 92
    iput v3, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->I$0:I

    .line 93
    .line 94
    iput v4, v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;->label:I

    .line 95
    .line 96
    const-wide/16 v0, 0xbb8

    .line 97
    .line 98
    invoke-static {v5, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    if-ne v1, v6, :cond_0

    .line 103
    .line 104
    return-object v6

    .line 105
    :cond_3
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->richPayload:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRichPayload;

    .line 106
    .line 107
    if-eqz v0, :cond_4

    .line 108
    .line 109
    instance-of v0, v0, Lcom/facebook/aura/gateway/ConnectorOrderCheckout;

    .line 110
    .line 111
    if-nez v0, :cond_4

    .line 112
    .line 113
    sget-object v3, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->INSTANCE:Lcom/facebook/aura/notifications/attention/AttentionNotifications;

    .line 114
    .line 115
    const v2, 0x7f0801ae

    .line 116
    .line 117
    .line 118
    :goto_1
    const v0, -0x66fffbf7

    .line 119
    .line 120
    .line 121
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    const v0, 0x3f22e8ba

    .line 126
    .line 127
    .line 128
    invoke-virtual {v3, p0, v2, v1, v0}, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->iconTile(Landroid/content/Context;ILjava/lang/Integer;F)Landroid/graphics/Bitmap;

    .line 129
    .line 130
    .line 131
    move-result-object v6

    .line 132
    return-object v6

    .line 133
    :cond_4
    iget-object v0, p1, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->iconRes:Ljava/lang/Integer;

    .line 134
    .line 135
    if-eqz v0, :cond_5

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    sget-object v2, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->INSTANCE:Lcom/facebook/aura/notifications/attention/AttentionNotifications;

    .line 142
    .line 143
    const/4 v1, 0x0

    .line 144
    const/high16 v0, 0x3f800000    # 1.0f

    .line 145
    .line 146
    invoke-virtual {v2, p0, v3, v1, v0}, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->iconTile(Landroid/content/Context;ILjava/lang/Integer;F)Landroid/graphics/Bitmap;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    if-nez v6, :cond_1

    .line 151
    .line 152
    :cond_5
    sget-object v3, Lcom/facebook/aura/notifications/attention/AttentionNotifications;->INSTANCE:Lcom/facebook/aura/notifications/attention/AttentionNotifications;

    .line 153
    .line 154
    invoke-static {p1}, Lcom/facebook/aura/agentpermission/AgentPermissionIconsKt;->approvalGlyphRes(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)I

    .line 155
    .line 156
    .line 157
    move-result v2

    .line 158
    goto :goto_1

    .line 159
    :cond_6
    new-instance v5, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;

    .line 160
    .line 161
    invoke-direct {v5, p3}, Lcom/facebook/aura/agentpermission/ApprovalNotificationIconKt$approvalNotificationIcon$1;-><init>(LX/2M4;)V

    .line 162
    .line 163
    .line 164
    goto/16 :goto_0

    .line 165
    .line 166
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    throw v0
.end method
