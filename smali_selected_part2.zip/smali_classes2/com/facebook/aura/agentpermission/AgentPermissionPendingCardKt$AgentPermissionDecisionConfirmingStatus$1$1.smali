.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionDecisionConfirmingStatus$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionConfirmationViewModel;->checkAgain(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
