.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $bottomSpacing:F

.field public final synthetic $includeAllApprovals:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $retainContentOnDismiss:Z

.field public final synthetic $sessionId:Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/3C1;Ljava/lang/String;ZFZ)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$modifier:LX/3C1;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$sessionId:Ljava/lang/String;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$includeAllApprovals:Z

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$bottomSpacing:F

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$retainContentOnDismiss:Z

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 6

    .line 0
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object v5, p1

    .line 5
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$modifier:LX/3C1;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$sessionId:Ljava/lang/String;

    .line 14
    .line 15
    iget-boolean v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$includeAllApprovals:Z

    .line 16
    .line 17
    iget v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$bottomSpacing:F

    .line 18
    .line 19
    iget-boolean v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt$AgentPermissionPendingCard$1;->$retainContentOnDismiss:Z

    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    move p1, p0

    .line 23
    invoke-static/range {v0 .. v7}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionPendingCardContainer-hGBTI10(LX/3C1;Ljava/lang/String;ZFZLX/2d4;II)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 28
    .line 29
    .line 30
    return-void
.end method
