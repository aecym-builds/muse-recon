.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approvalId:Ljava/lang/String;

.field public final synthetic $state$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;",
            "Ljava/lang/String;",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x4

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 17

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move/from16 v7, p1

    .line 3
    .line 4
    move-object/from16 v13, p3

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    invoke-static {v13, v7}, LX/004;->A09(LX/2d4;F)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    or-int v3, p4, v0

    .line 13
    .line 14
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 15
    .line 16
    move/from16 v2, p2

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    invoke-static {v13, v2}, LX/004;->A0A(LX/2d4;F)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int/2addr v3, v0

    .line 25
    :cond_0
    and-int/lit16 v1, v3, 0x93

    .line 26
    .line 27
    const/16 v0, 0x92

    .line 28
    .line 29
    const/4 v5, 0x1

    .line 30
    const/4 v15, 0x0

    .line 31
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, v13, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    move-object/from16 v1, p0

    .line 42
    .line 43
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 44
    .line 45
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 50
    .line 51
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->loading:Z

    .line 52
    .line 53
    const/16 p1, 0x0

    .line 54
    .line 55
    if-nez v0, :cond_4

    .line 56
    .line 57
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 58
    .line 59
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 64
    .line 65
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->unavailable:Z

    .line 66
    .line 67
    if-nez v0, :cond_4

    .line 68
    .line 69
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 70
    .line 71
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 76
    .line 77
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 78
    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    const v0, -0x1f0d941f

    .line 82
    .line 83
    .line 84
    invoke-static {v13, v0}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    invoke-static {v13}, LX/3J3;->A03(LX/2d4;)LX/3C1;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    iget-object v9, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 93
    .line 94
    iget-object v3, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 95
    .line 96
    invoke-static {v13}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 97
    .line 98
    .line 99
    move-result-object v12

    .line 100
    move-object v1, v13

    .line 101
    check-cast v1, LX/J7I;

    .line 102
    .line 103
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 104
    .line 105
    .line 106
    move-result v11

    .line 107
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 108
    .line 109
    .line 110
    move-result-object v10

    .line 111
    invoke-static {v13, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 112
    .line 113
    .line 114
    move-result-object v8

    .line 115
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 118
    .line 119
    if-nez v0, :cond_2

    .line 120
    .line 121
    invoke-static {}, LX/1VY;->A00()V

    .line 122
    .line 123
    .line 124
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0

    .line 129
    :cond_1
    move/from16 v3, p4

    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_2
    invoke-static {v13, v1, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 133
    .line 134
    .line 135
    invoke-static {v13, v12, v10, v8, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 136
    .line 137
    .line 138
    invoke-static {v13, v4, v7}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 139
    .line 140
    .line 141
    invoke-interface {v9}, LX/16A;->getValue()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 146
    .line 147
    iget-object v6, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->editor:Lcom/facebook/aura/gateway/EditableMessageEditor;

    .line 148
    .line 149
    if-nez v6, :cond_3

    .line 150
    .line 151
    const v0, -0x2de3991d

    .line 152
    .line 153
    .line 154
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 155
    .line 156
    .line 157
    :goto_1
    invoke-static {v1, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 158
    .line 159
    .line 160
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 161
    .line 162
    add-float/2addr v0, v2

    .line 163
    invoke-static {v13, v1, v4, v0, v5}, LX/1Vt;->A01(LX/2d4;LX/J7I;LX/3C1;FZ)V

    .line 164
    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_3
    const v0, -0x2de3991c

    .line 168
    .line 169
    .line 170
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 171
    .line 172
    .line 173
    iget-object v10, v6, Lcom/facebook/aura/gateway/EditableMessageEditor;->message:Lcom/facebook/aura/gateway/EditableMessage;

    .line 174
    .line 175
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 176
    .line 177
    const/4 v6, 0x0

    .line 178
    invoke-static {v4, v7, v6}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 179
    .line 180
    .line 181
    move-result-object v8

    .line 182
    sget v0, Lcom/facebook/aura/gateway/EditableMessage;->$stable:I

    .line 183
    .line 184
    invoke-static {v10, v8, v13, v0, v15}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorRecipients(Lcom/facebook/aura/gateway/EditableMessage;LX/3C1;LX/2d4;II)V

    .line 185
    .line 186
    .line 187
    invoke-interface {v9}, LX/16A;->getValue()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v16

    .line 191
    check-cast v16, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 192
    .line 193
    sget p3, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->$stable:I

    .line 194
    .line 195
    sget v10, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->$stable:I

    .line 196
    .line 197
    shl-int/lit8 v0, v10, 0x3

    .line 198
    .line 199
    or-int p3, p3, v0

    .line 200
    .line 201
    const/16 p4, 0x4

    .line 202
    .line 203
    move-object/from16 p0, v3

    .line 204
    .line 205
    move-object/from16 p2, v13

    .line 206
    .line 207
    invoke-static/range {v16 .. v21}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorFields(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;LX/3C1;LX/2d4;II)V

    .line 208
    .line 209
    .line 210
    invoke-interface {v9}, LX/16A;->getValue()Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 215
    .line 216
    iget-object v8, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->attachments:Ljava/util/List;

    .line 217
    .line 218
    invoke-interface {v9}, LX/16A;->getValue()Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    check-cast v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 223
    .line 224
    iget-boolean v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->saving:Z

    .line 225
    .line 226
    xor-int/lit8 v11, v0, 0x1

    .line 227
    .line 228
    invoke-static {v4, v7, v6}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 229
    .line 230
    .line 231
    move-result-object v12

    .line 232
    shl-int/lit8 v14, v10, 0x3

    .line 233
    .line 234
    move-object v10, v3

    .line 235
    move-object v9, v8

    .line 236
    invoke-static/range {v9 .. v15}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorAttachments(Ljava/util/List;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;ZLX/3C1;LX/2d4;II)V

    .line 237
    .line 238
    .line 239
    goto :goto_1

    .line 240
    :cond_4
    const v0, -0x1f10e997

    .line 241
    .line 242
    .line 243
    invoke-interface {v13, v0}, LX/2d4;->Agj(I)V

    .line 244
    .line 245
    .line 246
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$state$delegate:LX/16A;

    .line 247
    .line 248
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v9

    .line 252
    check-cast v9, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;

    .line 253
    .line 254
    iget-object v10, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$viewModel:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;

    .line 255
    .line 256
    iget-object v11, v1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$AgentPermissionMessageEditorScreen$4;->$approvalId:Ljava/lang/String;

    .line 257
    .line 258
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 259
    .line 260
    invoke-static {v0, v7, v2}, LX/2pj;->A08(LX/3C1;FF)LX/3C1;

    .line 261
    .line 262
    .line 263
    move-result-object v12

    .line 264
    sget v14, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;->$stable:I

    .line 265
    .line 266
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;->$stable:I

    .line 267
    .line 268
    shl-int/lit8 v0, v0, 0x3

    .line 269
    .line 270
    or-int/2addr v14, v0

    .line 271
    invoke-static/range {v9 .. v15}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt;->MessageEditorPageState(Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorUiState;Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorViewModel;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 272
    .line 273
    .line 274
    :goto_2
    invoke-static {v13}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    return-void

    .line 278
    :cond_5
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 279
    .line 280
    .line 281
    return-void
.end method
