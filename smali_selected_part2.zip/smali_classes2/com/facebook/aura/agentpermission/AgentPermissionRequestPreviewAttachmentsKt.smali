.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final PreviewAttachmentShape:LX/2bC;

.field public static final PreviewAttachmentSize:F = 120.0f

.field public static final SUPPORTED_INLINE_IMAGE_CONTENT_TYPES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final SUPPORTED_INLINE_VIDEO_CONTENT_TYPES:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const/high16 v0, 0x41400000    # 12.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/2bA;->A00(F)LX/2bC;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentShape:LX/2bC;

    .line 7
    .line 8
    const-string v0, "image/jpeg"

    .line 9
    .line 10
    const-string v1, "image/png"

    .line 11
    .line 12
    const-string v2, "image/gif"

    .line 13
    .line 14
    const-string v3, "image/webp"

    .line 15
    .line 16
    const-string v4, "image/avif"

    .line 17
    .line 18
    const-string v5, "image/heic"

    .line 19
    .line 20
    const-string v6, "image/heif"

    .line 21
    .line 22
    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->SUPPORTED_INLINE_IMAGE_CONTENT_TYPES:Ljava/util/Set;

    .line 31
    .line 32
    const-string v2, "video/mp4"

    .line 33
    .line 34
    const-string v1, "video/quicktime"

    .line 35
    .line 36
    const-string v0, "video/webm"

    .line 37
    .line 38
    filled-new-array {v2, v1, v0}, [Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->SUPPORTED_INLINE_VIDEO_CONTENT_TYPES:Ljava/util/Set;

    .line 47
    .line 48
    return-void
.end method

.method public static final PreviewAttachmentFallback(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;LX/2d4;II)V
    .locals 35

    .line 0
    move-object/from16 v15, p1

    .line 1
    .line 2
    const v0, -0x61ebdc33

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 p3, p0

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    move-object/from16 v0, p3

    .line 19
    .line 20
    invoke-static {v0, v1, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    or-int/2addr v5, v2

    .line 29
    :goto_0
    move/from16 v18, p4

    .line 30
    .line 31
    and-int/lit8 v4, p4, 0x2

    .line 32
    .line 33
    if-eqz v4, :cond_2

    .line 34
    .line 35
    or-int/lit8 v5, v5, 0x30

    .line 36
    .line 37
    :cond_0
    :goto_1
    and-int/lit8 v3, v5, 0x13

    .line 38
    .line 39
    const/16 v0, 0x12

    .line 40
    .line 41
    const/16 v17, 0x0

    .line 42
    .line 43
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0, v1, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_4

    .line 52
    .line 53
    if-eqz v4, :cond_1

    .line 54
    .line 55
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 56
    .line 57
    :cond_1
    sget v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentSize:F

    .line 58
    .line 59
    invoke-static {v15, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sget-object v8, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentShape:LX/2bC;

    .line 64
    .line 65
    invoke-static {v0, v8}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 70
    .line 71
    const/16 v16, 0x6

    .line 72
    .line 73
    invoke-static {v1, v7}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 74
    .line 75
    .line 76
    move-result-wide v3

    .line 77
    const/16 v20, 0x0

    .line 78
    .line 79
    invoke-static {v0, v3, v4}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    const/high16 v5, 0x3f800000    # 1.0f

    .line 84
    .line 85
    move/from16 v0, v16

    .line 86
    .line 87
    invoke-virtual {v7, v1, v0}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iget-wide v3, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->border:J

    .line 92
    .line 93
    invoke-static {v6, v8, v5, v3, v4}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    const/high16 v0, 0x41400000    # 12.0f

    .line 98
    .line 99
    invoke-static {v3, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 100
    .line 101
    .line 102
    move-result-object v9

    .line 103
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 104
    .line 105
    .line 106
    move-result-object v8

    .line 107
    move-object v0, v1

    .line 108
    check-cast v0, LX/J7I;

    .line 109
    .line 110
    iget-wide v3, v0, LX/J7I;->A06:J

    .line 111
    .line 112
    invoke-static {v3, v4}, LX/001;->A0A(J)I

    .line 113
    .line 114
    .line 115
    move-result v6

    .line 116
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 117
    .line 118
    .line 119
    move-result-object v5

    .line 120
    invoke-static {v1, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 121
    .line 122
    .line 123
    move-result-object v4

    .line 124
    sget-object v14, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 125
    .line 126
    iget-object v3, v0, LX/J7I;->A0V:LX/3DJ;

    .line 127
    .line 128
    if-nez v3, :cond_5

    .line 129
    .line 130
    invoke-static {}, LX/1VY;->A00()V

    .line 131
    .line 132
    .line 133
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    throw v0

    .line 138
    :cond_2
    and-int/lit8 v0, v2, 0x30

    .line 139
    .line 140
    if-nez v0, :cond_0

    .line 141
    .line 142
    invoke-static {v1, v15}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 143
    .line 144
    .line 145
    move-result v0

    .line 146
    or-int/2addr v5, v0

    .line 147
    goto :goto_1

    .line 148
    :cond_3
    move v5, v2

    .line 149
    goto :goto_0

    .line 150
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 151
    .line 152
    .line 153
    goto/16 :goto_2

    .line 154
    .line 155
    :cond_5
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 156
    .line 157
    .line 158
    sget-object v13, LX/3Cl;->A04:LX/JDN;

    .line 159
    .line 160
    invoke-static {v1, v8, v13}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 161
    .line 162
    .line 163
    move-result-object v12

    .line 164
    invoke-static {v1, v5, v12, v6}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 165
    .line 166
    .line 167
    move-result-object v11

    .line 168
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 169
    .line 170
    invoke-static {v1, v4, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 171
    .line 172
    .line 173
    move-result-object v9

    .line 174
    sget-object v3, LX/2Id;->A00:LX/2sS;

    .line 175
    .line 176
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 177
    .line 178
    invoke-static {v1, v3}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 183
    .line 184
    .line 185
    move-result v5

    .line 186
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 187
    .line 188
    .line 189
    move-result-object v4

    .line 190
    invoke-static {v1, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 191
    .line 192
    .line 193
    move-result-object v3

    .line 194
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 195
    .line 196
    .line 197
    invoke-static {v1, v6, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 198
    .line 199
    .line 200
    invoke-static {v1, v4, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 201
    .line 202
    .line 203
    invoke-static {v10, v11, v1, v5}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 204
    .line 205
    .line 206
    invoke-static {v1, v3, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 207
    .line 208
    .line 209
    move-object/from16 v3, p3

    .line 210
    .line 211
    iget-object v3, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 212
    .line 213
    invoke-static {v3}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->attachmentIcon(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;)I

    .line 214
    .line 215
    .line 216
    move-result v4

    .line 217
    move/from16 v3, v17

    .line 218
    .line 219
    invoke-static {v1, v4, v3}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 220
    .line 221
    .line 222
    move-result-object v21

    .line 223
    invoke-static {v1, v7}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 224
    .line 225
    .line 226
    move-result-wide v24

    .line 227
    sget-object v22, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 228
    .line 229
    invoke-static {}, LX/2l9;->A04()I

    .line 230
    .line 231
    .line 232
    move-result v28

    .line 233
    const/16 v29, 0x21

    .line 234
    .line 235
    move-object/from16 v23, v20

    .line 236
    .line 237
    move-object/from16 v26, v20

    .line 238
    .line 239
    move-object/from16 v27, v1

    .line 240
    .line 241
    invoke-static/range {v20 .. v29}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 242
    .line 243
    .line 244
    invoke-static {v1, v8}, LX/1Vt;->A02(LX/2d4;LX/3C1;)V

    .line 245
    .line 246
    .line 247
    move-object/from16 v3, p3

    .line 248
    .line 249
    iget-object v4, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->fileName:Ljava/lang/String;

    .line 250
    .line 251
    invoke-static {v1, v7}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 252
    .line 253
    .line 254
    move-result-object v23

    .line 255
    invoke-static {v1, v7}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 256
    .line 257
    .line 258
    move-result-wide v21

    .line 259
    invoke-static {}, LX/2wS;->A00()LX/2wS;

    .line 260
    .line 261
    .line 262
    move-result-object v26

    .line 263
    const/16 p2, 0x39b2

    .line 264
    .line 265
    const/16 v30, 0x5

    .line 266
    .line 267
    const/4 v3, 0x1

    .line 268
    const/high16 p0, 0x30000000

    .line 269
    .line 270
    move-object/from16 v24, v20

    .line 271
    .line 272
    move-object/from16 v25, v20

    .line 273
    .line 274
    move/from16 v27, v17

    .line 275
    .line 276
    move/from16 v28, v17

    .line 277
    .line 278
    move/from16 v29, v3

    .line 279
    .line 280
    move-object/from16 v31, v20

    .line 281
    .line 282
    move-object/from16 v32, v20

    .line 283
    .line 284
    move-object/from16 v33, v20

    .line 285
    .line 286
    move-object/from16 v34, v1

    .line 287
    .line 288
    move/from16 p1, v16

    .line 289
    .line 290
    move-object/from16 v19, v4

    .line 291
    .line 292
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 293
    .line 294
    .line 295
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 296
    .line 297
    .line 298
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 299
    .line 300
    .line 301
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 302
    .line 303
    .line 304
    move-result-object v4

    .line 305
    if-eqz v4, :cond_6

    .line 306
    .line 307
    new-instance v3, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentFallback$2;

    .line 308
    .line 309
    move-object/from16 v1, p3

    .line 310
    .line 311
    move/from16 v0, v18

    .line 312
    .line 313
    invoke-direct {v3, v1, v15, v2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentFallback$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;II)V

    .line 314
    .line 315
    .line 316
    iput-object v3, v4, LX/J7V;->A06:LX/JDN;

    .line 317
    .line 318
    :cond_6
    return-void
.end method

.method public static final PreviewAttachmentMedia(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 40
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;",
            "LX/3C1;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v23, p1

    .line 1
    .line 2
    move-object/from16 v7, p2

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    move-object/from16 v3, p0

    .line 6
    .line 7
    invoke-static {v3, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const v0, -0x310b554f

    .line 11
    .line 12
    .line 13
    move-object/from16 v1, p3

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v8, p4

    .line 19
    .line 20
    and-int/lit8 v0, p4, 0x6

    .line 21
    .line 22
    const/4 v5, 0x4

    .line 23
    if-nez v0, :cond_1e

    .line 24
    .line 25
    invoke-static {v3, v1, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0}, LX/003;->A06(I)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    or-int v4, v4, p4

    .line 34
    .line 35
    :goto_0
    move/from16 p4, p5

    .line 36
    .line 37
    and-int/lit8 v10, p5, 0x2

    .line 38
    .line 39
    if-eqz v10, :cond_1d

    .line 40
    .line 41
    or-int/lit8 v4, v4, 0x30

    .line 42
    .line 43
    :cond_0
    :goto_1
    and-int/lit8 v9, p5, 0x4

    .line 44
    .line 45
    const/16 v6, 0x100

    .line 46
    .line 47
    if-eqz v9, :cond_1c

    .line 48
    .line 49
    or-int/lit16 v4, v4, 0x180

    .line 50
    .line 51
    :cond_1
    :goto_2
    invoke-static {v4}, LX/005;->A1I(I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_1b

    .line 60
    .line 61
    if-eqz v10, :cond_2

    .line 62
    .line 63
    sget-object v23, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    if-eqz v9, :cond_4

    .line 66
    .line 67
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 72
    .line 73
    if-ne v7, v0, :cond_3

    .line 74
    .line 75
    sget-object v7, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$1$1;

    .line 76
    .line 77
    invoke-interface {v1, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    :cond_3
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 81
    .line 82
    :cond_4
    invoke-static {v1}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 83
    .line 84
    .line 85
    move-result-object v13

    .line 86
    invoke-static {v1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 87
    .line 88
    .line 89
    move-result-object v10

    .line 90
    iget-object v11, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->resource:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;

    .line 91
    .line 92
    const v0, -0x1b8b15f6

    .line 93
    .line 94
    .line 95
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 96
    .line 97
    .line 98
    if-eqz v11, :cond_1a

    .line 99
    .line 100
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 101
    .line 102
    invoke-static {v2}, LX/1Y9;->A01(I)LX/1Y9;

    .line 103
    .line 104
    .line 105
    move-result-object v9

    .line 106
    and-int/lit16 v0, v4, 0x380

    .line 107
    .line 108
    invoke-static {v0, v6}, LX/003;->A1I(II)Z

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    invoke-static {v1, v11, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 113
    .line 114
    .line 115
    move-result v6

    .line 116
    and-int/lit8 v0, v4, 0xe

    .line 117
    .line 118
    if-eq v0, v5, :cond_5

    .line 119
    .line 120
    and-int/lit8 v0, v4, 0x8

    .line 121
    .line 122
    if-eqz v0, :cond_19

    .line 123
    .line 124
    invoke-interface {v1, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_19

    .line 129
    .line 130
    :cond_5
    const/4 v0, 0x1

    .line 131
    :goto_3
    or-int/2addr v0, v6

    .line 132
    invoke-static {v1, v10, v13, v0}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v6

    .line 140
    if-nez v0, :cond_6

    .line 141
    .line 142
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 143
    .line 144
    if-ne v6, v0, :cond_7

    .line 145
    .line 146
    :cond_6
    new-instance v6, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;

    .line 147
    .line 148
    move-object v14, v6

    .line 149
    move-object v15, v7

    .line 150
    move-object/from16 v16, v11

    .line 151
    .line 152
    move-object/from16 v17, v3

    .line 153
    .line 154
    move-object/from16 v18, v10

    .line 155
    .line 156
    move-object/from16 v19, v13

    .line 157
    .line 158
    invoke-direct/range {v14 .. v19}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$openViewerModifier$1$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/AHE;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 159
    .line 160
    .line 161
    invoke-interface {v1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    :cond_7
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 165
    .line 166
    const/4 v5, 0x0

    .line 167
    const/4 v0, 0x1

    .line 168
    invoke-static {v12, v9, v5, v6, v0}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 169
    .line 170
    .line 171
    move-result-object v5

    .line 172
    move-object/from16 v0, v23

    .line 173
    .line 174
    invoke-interface {v0, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 175
    .line 176
    .line 177
    move-result-object v9

    .line 178
    :goto_4
    invoke-static {v1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    iget-object v5, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 183
    .line 184
    invoke-static {v1, v5}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 185
    .line 186
    .line 187
    move-result v5

    .line 188
    invoke-static {v1, v11, v10, v5}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 189
    .line 190
    .line 191
    move-result v6

    .line 192
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v5

    .line 196
    const/16 v22, 0x0

    .line 197
    .line 198
    if-nez v6, :cond_8

    .line 199
    .line 200
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 201
    .line 202
    if-ne v5, v6, :cond_9

    .line 203
    .line 204
    :cond_8
    if-eqz v11, :cond_18

    .line 205
    .line 206
    iget-object v13, v11, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->contentType:Ljava/lang/String;

    .line 207
    .line 208
    invoke-static {v11}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->versionedResourceUrl(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v12

    .line 212
    :goto_5
    iget-object v6, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 213
    .line 214
    sget-object v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;->IMAGE:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 215
    .line 216
    if-ne v6, v5, :cond_16

    .line 217
    .line 218
    sget-object v5, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->SUPPORTED_INLINE_IMAGE_CONTENT_TYPES:Ljava/util/Set;

    .line 219
    .line 220
    invoke-static {v5, v13}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 221
    .line 222
    .line 223
    move-result v5

    .line 224
    if-eqz v5, :cond_16

    .line 225
    .line 226
    sget-object v5, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 227
    .line 228
    invoke-virtual {v5, v12, v10}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveRawAssetUrl(Ljava/lang/String;LX/AHE;)Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    move-result-object v5

    .line 232
    :goto_6
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    :cond_9
    check-cast v5, Ljava/lang/String;

    .line 236
    .line 237
    if-nez v5, :cond_b

    .line 238
    .line 239
    const v5, -0x55c61a82

    .line 240
    .line 241
    .line 242
    invoke-interface {v1, v5}, LX/2d4;->Agj(I)V

    .line 243
    .line 244
    .line 245
    sget v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->$stable:I

    .line 246
    .line 247
    and-int/lit8 v4, v4, 0xe

    .line 248
    .line 249
    or-int/2addr v5, v4

    .line 250
    invoke-static {v3, v9, v1, v5, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentFallback(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;LX/2d4;II)V

    .line 251
    .line 252
    .line 253
    invoke-static {v1, v0}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    if-eqz v1, :cond_a

    .line 258
    .line 259
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$2;

    .line 260
    .line 261
    move-object/from16 v39, v0

    .line 262
    .line 263
    move-object/from16 p1, v23

    .line 264
    .line 265
    move-object/from16 p2, v7

    .line 266
    .line 267
    move/from16 p3, v8

    .line 268
    .line 269
    invoke-direct/range {v39 .. v44}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;II)V

    .line 270
    .line 271
    .line 272
    :goto_7
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 273
    .line 274
    :cond_a
    return-void

    .line 275
    :cond_b
    const v6, -0x55c4e2ef

    .line 276
    .line 277
    .line 278
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 279
    .line 280
    .line 281
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 282
    .line 283
    .line 284
    invoke-interface {v1, v5}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v6

    .line 288
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v10

    .line 292
    if-nez v6, :cond_c

    .line 293
    .line 294
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 295
    .line 296
    if-ne v10, v6, :cond_d

    .line 297
    .line 298
    :cond_c
    invoke-static {v1, v2}, LX/005;->A0Y(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 299
    .line 300
    .line 301
    move-result-object v10

    .line 302
    :cond_d
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 303
    .line 304
    invoke-static {v10}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 305
    .line 306
    .line 307
    move-result v6

    .line 308
    if-eqz v6, :cond_e

    .line 309
    .line 310
    const v5, -0x55c387c2

    .line 311
    .line 312
    .line 313
    invoke-interface {v1, v5}, LX/2d4;->Agj(I)V

    .line 314
    .line 315
    .line 316
    sget v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->$stable:I

    .line 317
    .line 318
    and-int/lit8 v4, v4, 0xe

    .line 319
    .line 320
    or-int/2addr v5, v4

    .line 321
    invoke-static {v3, v9, v1, v5, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentFallback(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;LX/2d4;II)V

    .line 322
    .line 323
    .line 324
    invoke-static {v1, v0}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 325
    .line 326
    .line 327
    move-result-object v1

    .line 328
    if-eqz v1, :cond_a

    .line 329
    .line 330
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$3;

    .line 331
    .line 332
    move-object/from16 v39, v0

    .line 333
    .line 334
    move-object/from16 p1, v23

    .line 335
    .line 336
    move-object/from16 p2, v7

    .line 337
    .line 338
    move/from16 p3, v8

    .line 339
    .line 340
    invoke-direct/range {v39 .. v44}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;II)V

    .line 341
    .line 342
    .line 343
    goto/16 :goto_b

    .line 344
    .line 345
    :cond_e
    const v4, -0x55c2502f

    .line 346
    .line 347
    .line 348
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 349
    .line 350
    .line 351
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 352
    .line 353
    .line 354
    if-eqz v11, :cond_f

    .line 355
    .line 356
    invoke-static {v11}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->aspectRatioOrNull(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;)Ljava/lang/Float;

    .line 357
    .line 358
    .line 359
    move-result-object v22

    .line 360
    :cond_f
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 361
    .line 362
    const/high16 v4, 0x42400000    # 48.0f

    .line 363
    .line 364
    invoke-static {v6, v4, v4}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 365
    .line 366
    .line 367
    move-result-object v4

    .line 368
    invoke-interface {v4, v9}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 369
    .line 370
    .line 371
    move-result-object v4

    .line 372
    sget-object v9, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 373
    .line 374
    invoke-static {v9, v2}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 375
    .line 376
    .line 377
    move-result-object v13

    .line 378
    iget-wide v11, v0, LX/J7I;->A06:J

    .line 379
    .line 380
    invoke-static {v11, v12}, LX/001;->A0A(J)I

    .line 381
    .line 382
    .line 383
    move-result v12

    .line 384
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 385
    .line 386
    .line 387
    move-result-object v11

    .line 388
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 389
    .line 390
    .line 391
    move-result-object v4

    .line 392
    sget-object v16, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 393
    .line 394
    iget-object v14, v0, LX/J7I;->A0V:LX/3DJ;

    .line 395
    .line 396
    if-nez v14, :cond_10

    .line 397
    .line 398
    invoke-static {}, LX/1VY;->A00()V

    .line 399
    .line 400
    .line 401
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 402
    .line 403
    .line 404
    move-result-object v0

    .line 405
    throw v0

    .line 406
    :cond_10
    move-object/from16 v14, v16

    .line 407
    .line 408
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 409
    .line 410
    .line 411
    sget-object v21, LX/3Cl;->A04:LX/JDN;

    .line 412
    .line 413
    move-object/from16 v14, v21

    .line 414
    .line 415
    invoke-static {v1, v13, v14}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 416
    .line 417
    .line 418
    move-result-object v20

    .line 419
    move-object/from16 v13, v20

    .line 420
    .line 421
    invoke-static {v1, v11, v13, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 422
    .line 423
    .line 424
    move-result-object v19

    .line 425
    sget-object v15, LX/3Cl;->A02:LX/JDM;

    .line 426
    .line 427
    invoke-static {v1, v15}, LX/2d5;->A0C(LX/2d4;LX/JDM;)V

    .line 428
    .line 429
    .line 430
    sget-object v13, LX/3Cl;->A05:LX/JDN;

    .line 431
    .line 432
    move-object/from16 p5, v13

    .line 433
    .line 434
    invoke-static {v1, v4, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 435
    .line 436
    .line 437
    sget-object v4, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentShape:LX/2bC;

    .line 438
    .line 439
    invoke-static {v6, v4}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 440
    .line 441
    .line 442
    move-result-object v14

    .line 443
    invoke-static {v1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 444
    .line 445
    .line 446
    move-result-object v4

    .line 447
    iget-wide v11, v4, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 448
    .line 449
    const/16 v28, 0x0

    .line 450
    .line 451
    sget-object v18, LX/2oZ;->A00:LX/2bW;

    .line 452
    .line 453
    move-object/from16 v4, v18

    .line 454
    .line 455
    invoke-static {v14, v4, v11, v12}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 456
    .line 457
    .line 458
    move-result-object v4

    .line 459
    invoke-static {v9, v2}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 460
    .line 461
    .line 462
    move-result-object v12

    .line 463
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 464
    .line 465
    .line 466
    move-result v17

    .line 467
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 468
    .line 469
    .line 470
    move-result-object v11

    .line 471
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 472
    .line 473
    .line 474
    move-result-object v14

    .line 475
    move-object/from16 v4, v16

    .line 476
    .line 477
    invoke-static {v1, v0, v4}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 478
    .line 479
    .line 480
    move-object/from16 v4, v21

    .line 481
    .line 482
    invoke-static {v1, v12, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 483
    .line 484
    .line 485
    move-object/from16 v4, v20

    .line 486
    .line 487
    invoke-static {v1, v11, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 488
    .line 489
    .line 490
    move-object/from16 v11, v19

    .line 491
    .line 492
    move/from16 v4, v17

    .line 493
    .line 494
    invoke-static {v15, v11, v1, v4}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 495
    .line 496
    .line 497
    invoke-static {v1, v14, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 498
    .line 499
    .line 500
    sget v4, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentSize:F

    .line 501
    .line 502
    invoke-static {v6, v4}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 503
    .line 504
    .line 505
    move-result-object v11

    .line 506
    if-eqz v22, :cond_11

    .line 507
    .line 508
    invoke-virtual/range {v22 .. v22}, Ljava/lang/Number;->floatValue()F

    .line 509
    .line 510
    .line 511
    move-result v12

    .line 512
    invoke-static {v6, v12}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->safeAspectRatio(LX/3C1;F)LX/3C1;

    .line 513
    .line 514
    .line 515
    move-result-object v12

    .line 516
    invoke-interface {v11, v12}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 517
    .line 518
    .line 519
    move-result-object v11

    .line 520
    :cond_11
    sget-object v26, LX/32Y;->A02:LX/2vq;

    .line 521
    .line 522
    iget-object v14, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->fileName:Ljava/lang/String;

    .line 523
    .line 524
    if-nez v22, :cond_15

    .line 525
    .line 526
    const/16 v29, 0x1

    .line 527
    .line 528
    invoke-static {v4}, LX/1Ot;->A02(F)LX/1Ot;

    .line 529
    .line 530
    .line 531
    move-result-object v30

    .line 532
    :goto_8
    invoke-interface {v1, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    move-result v12

    .line 536
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 537
    .line 538
    .line 539
    move-result-object v4

    .line 540
    if-nez v12, :cond_12

    .line 541
    .line 542
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 543
    .line 544
    if-ne v4, v12, :cond_13

    .line 545
    .line 546
    :cond_12
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$4$1$2$1;

    .line 547
    .line 548
    invoke-direct {v4, v10}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$4$1$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 549
    .line 550
    .line 551
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 552
    .line 553
    .line 554
    :cond_13
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 555
    .line 556
    const/16 p2, 0x30

    .line 557
    .line 558
    const/16 p3, 0x5690

    .line 559
    .line 560
    const-wide/16 v31, 0x0

    .line 561
    .line 562
    const/4 v13, 0x1

    .line 563
    const p1, 0x6000180

    .line 564
    .line 565
    .line 566
    const/4 v10, 0x6

    .line 567
    move-object/from16 v24, v5

    .line 568
    .line 569
    move-object/from16 v25, v11

    .line 570
    .line 571
    move-object/from16 v27, v14

    .line 572
    .line 573
    move/from16 v33, v13

    .line 574
    .line 575
    move/from16 v34, v2

    .line 576
    .line 577
    move/from16 v35, v2

    .line 578
    .line 579
    move-object/from16 v36, v28

    .line 580
    .line 581
    move-object/from16 v37, v28

    .line 582
    .line 583
    move-object/from16 v38, v4

    .line 584
    .line 585
    move-object/from16 v39, v28

    .line 586
    .line 587
    move-object/from16 p0, v1

    .line 588
    .line 589
    invoke-static/range {v24 .. v43}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage-XRP3Ue8(Ljava/lang/String;LX/3C1;LX/2vq;Ljava/lang/String;Lcom/facebook/common/callercontext/ContextChain;ZLX/1Ot;JZZZLX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;III)V

    .line 590
    .line 591
    .line 592
    iget-object v5, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 593
    .line 594
    sget-object v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;->VIDEO:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 595
    .line 596
    if-ne v5, v4, :cond_14

    .line 597
    .line 598
    const v4, -0x63868d02

    .line 599
    .line 600
    .line 601
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 602
    .line 603
    .line 604
    const/high16 v4, 0x42300000    # 44.0f

    .line 605
    .line 606
    invoke-static {v6, v4}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 607
    .line 608
    .line 609
    move-result-object v5

    .line 610
    const/high16 v4, 0x41b00000    # 22.0f

    .line 611
    .line 612
    invoke-static {v5, v4}, LX/1qF;->A01(LX/3C1;F)LX/3C1;

    .line 613
    .line 614
    .line 615
    move-result-object v12

    .line 616
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 617
    .line 618
    invoke-virtual {v6, v1, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 619
    .line 620
    .line 621
    move-result-object v4

    .line 622
    iget-wide v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraColors;->surfaceOnMedia:J

    .line 623
    .line 624
    move-object/from16 v11, v18

    .line 625
    .line 626
    invoke-static {v12, v11, v4, v5}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 627
    .line 628
    .line 629
    move-result-object v4

    .line 630
    invoke-static {v9, v2}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 631
    .line 632
    .line 633
    move-result-object v12

    .line 634
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 635
    .line 636
    .line 637
    move-result v11

    .line 638
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 639
    .line 640
    .line 641
    move-result-object v9

    .line 642
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 643
    .line 644
    .line 645
    move-result-object v5

    .line 646
    move-object/from16 v4, v16

    .line 647
    .line 648
    invoke-static {v1, v0, v4}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 649
    .line 650
    .line 651
    move-object/from16 v4, v21

    .line 652
    .line 653
    invoke-static {v1, v12, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 654
    .line 655
    .line 656
    move-object/from16 v4, v20

    .line 657
    .line 658
    invoke-static {v1, v9, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 659
    .line 660
    .line 661
    move-object/from16 v4, v19

    .line 662
    .line 663
    invoke-static {v15, v4, v1, v11}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 664
    .line 665
    .line 666
    move-object/from16 v4, p5

    .line 667
    .line 668
    invoke-static {v1, v5, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 669
    .line 670
    .line 671
    const v4, 0x7f080244

    .line 672
    .line 673
    .line 674
    invoke-static {v1, v4, v2}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 675
    .line 676
    .line 677
    move-result-object v26

    .line 678
    invoke-virtual {v6, v1, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 679
    .line 680
    .line 681
    move-result-object v4

    .line 682
    iget-wide v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraColors;->onMedia:J

    .line 683
    .line 684
    sget-object v27, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 685
    .line 686
    invoke-static {}, LX/2l9;->A04()I

    .line 687
    .line 688
    .line 689
    move-result v33

    .line 690
    const/16 v34, 0x21

    .line 691
    .line 692
    move-object/from16 v25, v28

    .line 693
    .line 694
    move-wide/from16 v29, v4

    .line 695
    .line 696
    move-object/from16 v31, v28

    .line 697
    .line 698
    move-object/from16 v32, v1

    .line 699
    .line 700
    invoke-static/range {v25 .. v34}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 701
    .line 702
    .line 703
    invoke-static {v0, v13}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 704
    .line 705
    .line 706
    :goto_9
    invoke-static {v0, v2, v13}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 707
    .line 708
    .line 709
    goto :goto_a

    .line 710
    :cond_14
    const v4, -0x637ef0bb

    .line 711
    .line 712
    .line 713
    invoke-interface {v1, v4}, LX/2d4;->Agj(I)V

    .line 714
    .line 715
    .line 716
    goto :goto_9

    .line 717
    :cond_15
    const/16 v29, 0x0

    .line 718
    .line 719
    const/16 v30, 0x0

    .line 720
    .line 721
    goto/16 :goto_8

    .line 722
    .line 723
    :cond_16
    iget-object v6, v3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->kind:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 724
    .line 725
    sget-object v5, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;->VIDEO:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;

    .line 726
    .line 727
    if-ne v6, v5, :cond_17

    .line 728
    .line 729
    sget-object v5, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->SUPPORTED_INLINE_VIDEO_CONTENT_TYPES:Ljava/util/Set;

    .line 730
    .line 731
    invoke-static {v5, v13}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 732
    .line 733
    .line 734
    move-result v5

    .line 735
    if-eqz v5, :cond_17

    .line 736
    .line 737
    sget-object v6, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->INSTANCE:Lcom/facebook/aura/gateway/WorkspaceUriResolver;

    .line 738
    .line 739
    sget-object v5, Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;->LARGE:Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;

    .line 740
    .line 741
    invoke-virtual {v6, v12, v10, v5}, Lcom/facebook/aura/gateway/WorkspaceUriResolver;->resolveThumbnailUrl(Ljava/lang/String;LX/AHE;Lcom/facebook/aura/gateway/HatchThumbnailDisplaySize;)Ljava/lang/String;

    .line 742
    .line 743
    .line 744
    move-result-object v5

    .line 745
    goto/16 :goto_6

    .line 746
    .line 747
    :cond_17
    move-object/from16 v5, v22

    .line 748
    .line 749
    goto/16 :goto_6

    .line 750
    .line 751
    :cond_18
    move-object/from16 v13, v22

    .line 752
    .line 753
    move-object v12, v13

    .line 754
    goto/16 :goto_5

    .line 755
    .line 756
    :cond_19
    const/4 v0, 0x0

    .line 757
    goto/16 :goto_3

    .line 758
    .line 759
    :cond_1a
    move-object/from16 v9, v23

    .line 760
    .line 761
    goto/16 :goto_4

    .line 762
    .line 763
    :cond_1b
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 764
    .line 765
    .line 766
    :goto_a
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 767
    .line 768
    .line 769
    move-result-object v1

    .line 770
    if-eqz v1, :cond_a

    .line 771
    .line 772
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$5;

    .line 773
    .line 774
    move-object/from16 v39, v0

    .line 775
    .line 776
    move-object/from16 p0, v3

    .line 777
    .line 778
    move-object/from16 p1, v23

    .line 779
    .line 780
    move-object/from16 p2, v7

    .line 781
    .line 782
    move/from16 p3, v8

    .line 783
    .line 784
    invoke-direct/range {v39 .. v44}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachmentMedia$5;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;II)V

    .line 785
    .line 786
    .line 787
    :goto_b
    check-cast v0, LX/JDN;

    .line 788
    .line 789
    goto/16 :goto_7

    .line 790
    .line 791
    :cond_1c
    and-int/lit16 v0, v8, 0x180

    .line 792
    .line 793
    if-nez v0, :cond_1

    .line 794
    .line 795
    invoke-static {v1, v7}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 796
    .line 797
    .line 798
    move-result v0

    .line 799
    or-int/2addr v4, v0

    .line 800
    goto/16 :goto_2

    .line 801
    .line 802
    :cond_1d
    and-int/lit8 v0, v8, 0x30

    .line 803
    .line 804
    if-nez v0, :cond_0

    .line 805
    .line 806
    move-object/from16 v0, v23

    .line 807
    .line 808
    invoke-static {v1, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 809
    .line 810
    .line 811
    move-result v0

    .line 812
    or-int/2addr v4, v0

    .line 813
    goto/16 :goto_1

    .line 814
    .line 815
    :cond_1e
    move v4, v8

    .line 816
    goto/16 :goto_0
.end method

.method public static final PreviewAttachmentMedia$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final PreviewAttachmentMedia$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final PreviewAttachments(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V
    .locals 22

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object/from16 v12, p0

    .line 2
    .line 3
    move-object/from16 v11, p1

    .line 4
    .line 5
    invoke-static {v12, v11}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v6

    .line 9
    const/16 v20, 0x2

    .line 10
    .line 11
    move-object/from16 v10, p2

    .line 12
    .line 13
    move/from16 v0, v20

    .line 14
    .line 15
    invoke-static {v10, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    const v0, -0x1a4671a6

    .line 19
    .line 20
    .line 21
    move-object/from16 v9, p3

    .line 22
    .line 23
    invoke-interface {v9, v0}, LX/2d4;->Agl(I)V

    .line 24
    .line 25
    .line 26
    move/from16 v8, p4

    .line 27
    .line 28
    and-int/lit8 v0, p4, 0x6

    .line 29
    .line 30
    if-nez v0, :cond_2

    .line 31
    .line 32
    invoke-static {v12, v9, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, LX/003;->A06(I)I

    .line 37
    .line 38
    .line 39
    move-result v5

    .line 40
    or-int v5, v5, p4

    .line 41
    .line 42
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 43
    .line 44
    if-nez v0, :cond_0

    .line 45
    .line 46
    invoke-static {v11, v9, v8}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0}, LX/003;->A07(I)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v5, v0

    .line 55
    :cond_0
    and-int/lit16 v0, v8, 0x180

    .line 56
    .line 57
    if-nez v0, :cond_1

    .line 58
    .line 59
    invoke-static {v9, v10}, LX/005;->A0B(LX/2d4;Ljava/lang/Enum;)I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    or-int/2addr v5, v0

    .line 64
    :cond_1
    invoke-static {v5}, LX/005;->A1I(I)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v0, v9, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_9

    .line 73
    .line 74
    sget v16, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 75
    .line 76
    invoke-static/range {v16 .. v16}, LX/Dn6;->A00(F)LX/CP5;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 81
    .line 82
    invoke-static {v0, v9, v7}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    move-object v4, v9

    .line 87
    check-cast v4, LX/J7I;

    .line 88
    .line 89
    iget-wide v0, v4, LX/J7I;->A06:J

    .line 90
    .line 91
    const/16 v19, 0x20

    .line 92
    .line 93
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 94
    .line 95
    .line 96
    move-result v15

    .line 97
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    invoke-static {v9, v13}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    sget-object v0, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 106
    .line 107
    iget-object v13, v4, LX/J7I;->A0V:LX/3DJ;

    .line 108
    .line 109
    if-nez v13, :cond_3

    .line 110
    .line 111
    invoke-static {}, LX/1VY;->A00()V

    .line 112
    .line 113
    .line 114
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    throw v0

    .line 119
    :cond_2
    move v5, v8

    .line 120
    goto :goto_0

    .line 121
    :cond_3
    invoke-static {v9, v4, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 122
    .line 123
    .line 124
    sget-object v14, LX/3Cl;->A04:LX/JDN;

    .line 125
    .line 126
    invoke-static {v9, v3, v14}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 127
    .line 128
    .line 129
    move-result-object v13

    .line 130
    invoke-static {v9, v2, v13, v15}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 131
    .line 132
    .line 133
    move-result-object v18

    .line 134
    sget-object v3, LX/3Cl;->A02:LX/JDM;

    .line 135
    .line 136
    invoke-static {v9, v1, v3}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 137
    .line 138
    .line 139
    move-result-object v17

    .line 140
    iget-object v2, v12, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;->label:Ljava/lang/String;

    .line 141
    .line 142
    if-nez v2, :cond_8

    .line 143
    .line 144
    const v1, -0x6754bf9b

    .line 145
    .line 146
    .line 147
    invoke-interface {v9, v1}, LX/2d4;->Agj(I)V

    .line 148
    .line 149
    .line 150
    :goto_1
    invoke-static {v4, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 151
    .line 152
    .line 153
    const/16 p0, 0x0

    .line 154
    .line 155
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 156
    .line 157
    invoke-static {v7, v9, v7, v6}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-static {v1, v2}, LX/3J3;->A01(LX/3Lr;LX/3C1;)LX/3C1;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    move/from16 v2, v16

    .line 166
    .line 167
    invoke-static {v9, v2, v7}, LX/007;->A0g(LX/2d4;FI)LX/3BI;

    .line 168
    .line 169
    .line 170
    move-result-object v16

    .line 171
    invoke-static {v4}, LX/002;->A0J(LX/J7I;)I

    .line 172
    .line 173
    .line 174
    move-result v15

    .line 175
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 176
    .line 177
    .line 178
    move-result-object v2

    .line 179
    invoke-static {v9, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    invoke-static {v9, v4, v0}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 184
    .line 185
    .line 186
    move-object/from16 v0, v16

    .line 187
    .line 188
    invoke-static {v9, v0, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 189
    .line 190
    .line 191
    invoke-static {v9, v2, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 192
    .line 193
    .line 194
    move-object/from16 v0, v18

    .line 195
    .line 196
    invoke-static {v3, v0, v9, v15}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 197
    .line 198
    .line 199
    move-object/from16 v0, v17

    .line 200
    .line 201
    invoke-static {v9, v1, v0}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 202
    .line 203
    .line 204
    const v0, -0x3683410a

    .line 205
    .line 206
    .line 207
    invoke-interface {v9, v0}, LX/2d4;->Agj(I)V

    .line 208
    .line 209
    .line 210
    iget-object v0, v12, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;->items:Ljava/util/List;

    .line 211
    .line 212
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 213
    .line 214
    .line 215
    move-result-object v3

    .line 216
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    if-eqz v0, :cond_a

    .line 221
    .line 222
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object v21

    .line 226
    check-cast v21, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;

    .line 227
    .line 228
    invoke-static {v5}, LX/005;->A1J(I)Z

    .line 229
    .line 230
    .line 231
    move-result v2

    .line 232
    and-int/lit8 v1, v5, 0x70

    .line 233
    .line 234
    move/from16 v0, v19

    .line 235
    .line 236
    if-eq v1, v0, :cond_4

    .line 237
    .line 238
    and-int/lit8 v0, v5, 0x40

    .line 239
    .line 240
    if-eqz v0, :cond_7

    .line 241
    .line 242
    invoke-interface {v9, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    if-eqz v0, :cond_7

    .line 247
    .line 248
    :cond_4
    const/4 v0, 0x1

    .line 249
    :goto_3
    or-int/2addr v2, v0

    .line 250
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    if-nez v2, :cond_5

    .line 255
    .line 256
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 257
    .line 258
    if-ne v0, v1, :cond_6

    .line 259
    .line 260
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachments$1$2$1$1$1;

    .line 261
    .line 262
    invoke-direct {v0, v10, v11}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachments$1$2$1$1$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)V

    .line 263
    .line 264
    .line 265
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    :cond_6
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 269
    .line 270
    sget p3, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;->$stable:I

    .line 271
    .line 272
    move-object/from16 p1, v0

    .line 273
    .line 274
    move-object/from16 p2, v9

    .line 275
    .line 276
    move/from16 p4, v20

    .line 277
    .line 278
    invoke-static/range {v21 .. v26}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentMedia(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 279
    .line 280
    .line 281
    goto :goto_2

    .line 282
    :cond_7
    const/4 v0, 0x0

    .line 283
    goto :goto_3

    .line 284
    :cond_8
    const v1, -0x6754bf9a

    .line 285
    .line 286
    .line 287
    invoke-interface {v9, v1}, LX/2d4;->Agj(I)V

    .line 288
    .line 289
    .line 290
    invoke-static {v2, v9, v7}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewLabel(Ljava/lang/String;LX/2d4;I)V

    .line 291
    .line 292
    .line 293
    goto/16 :goto_1

    .line 294
    .line 295
    :cond_9
    invoke-interface {v9}, LX/2d4;->AgJ()V

    .line 296
    .line 297
    .line 298
    goto :goto_4

    .line 299
    :cond_a
    invoke-static {v4, v7, v6}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 300
    .line 301
    .line 302
    :goto_4
    invoke-interface {v9}, LX/2d4;->AAg()LX/J7V;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    if-eqz v1, :cond_b

    .line 307
    .line 308
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachments$2;

    .line 309
    .line 310
    invoke-direct {v0, v12, v11, v10, v8}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt$PreviewAttachments$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Attachments;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;I)V

    .line 311
    .line 312
    .line 313
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 314
    .line 315
    :cond_b
    return-void
.end method

.method public static final synthetic access$PreviewAttachmentFallback(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewAttachmentsKt;->PreviewAttachmentFallback(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachment;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$PreviewAttachmentMedia$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final aspectRatioOrNull(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;)Ljava/lang/Float;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->width:Ljava/lang/Integer;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->height:Ljava/lang/Integer;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    int-to-float v1, v1

    .line 18
    int-to-float v0, v0

    .line 19
    div-float/2addr v1, v0

    .line 20
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0

    .line 25
    :cond_0
    return-object v2
.end method

.method public static final attachmentIcon(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentKind;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_2

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-ne p0, v0, :cond_0

    .line 12
    .line 13
    const v0, 0x7f080282

    .line 14
    .line 15
    .line 16
    return v0

    .line 17
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    throw v0

    .line 22
    :cond_1
    const v0, 0x7f0800d9

    .line 23
    .line 24
    .line 25
    return v0

    .line 26
    :cond_2
    const v0, 0x7f08021a

    .line 27
    .line 28
    .line 29
    return v0
.end method

.method public static final versionedResourceUrl(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;)Ljava/lang/String;
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->updatedAtMs:Ljava/lang/Long;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 5
    .line 6
    .line 7
    move-result-wide v2

    .line 8
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->url:Ljava/lang/String;

    .line 9
    .line 10
    const/16 v4, 0x3f

    .line 11
    .line 12
    invoke-static {v0, v4}, LX/AdT;->A0m(Ljava/lang/CharSequence;C)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    const/16 v4, 0x26

    .line 19
    .line 20
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->url:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    const-string v0, "v="

    .line 33
    .line 34
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    return-object v0

    .line 45
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewAttachmentResource;->url:Ljava/lang/String;

    .line 46
    .line 47
    return-object v0
.end method
