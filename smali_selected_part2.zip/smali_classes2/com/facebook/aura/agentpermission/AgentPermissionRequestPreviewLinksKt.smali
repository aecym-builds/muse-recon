.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "ApprovalPreviewLinks"


# direct methods
.method public static final PreviewInlineLinkText-hYmLsZ8(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;LX/2d4;II)V
    .locals 60

    .line 0
    move-object/from16 v17, p7

    .line 1
    .line 2
    const/16 v16, 0x0

    .line 3
    .line 4
    move-object/from16 v11, p0

    .line 5
    .line 6
    move-object/from16 v4, p1

    .line 7
    .line 8
    move-object/from16 v0, p2

    .line 9
    .line 10
    invoke-static {v11, v4, v0}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x4

    .line 14
    move-object/from16 v14, p5

    .line 15
    .line 16
    move-object/from16 v59, p6

    .line 17
    .line 18
    move-object/from16 v0, v59

    .line 19
    .line 20
    invoke-static {v14, v1, v0}, LX/003;->A10(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    const v0, -0x13cc9bc2

    .line 24
    .line 25
    .line 26
    move-object/from16 v3, p8

    .line 27
    .line 28
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 29
    .line 30
    .line 31
    move/from16 v2, p9

    .line 32
    .line 33
    and-int/lit8 v0, p9, 0x6

    .line 34
    .line 35
    if-nez v0, :cond_d

    .line 36
    .line 37
    invoke-static {v3, v11}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 38
    .line 39
    .line 40
    move-result v6

    .line 41
    or-int v6, v6, p9

    .line 42
    .line 43
    :goto_0
    and-int/lit8 v0, p9, 0x30

    .line 44
    .line 45
    if-nez v0, :cond_0

    .line 46
    .line 47
    invoke-static {v4, v3, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0}, LX/003;->A07(I)I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    or-int/2addr v6, v0

    .line 56
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 57
    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    move-object/from16 v0, p2

    .line 61
    .line 62
    invoke-static {v3, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v6, v0

    .line 67
    :cond_1
    and-int/lit16 v0, v2, 0xc00

    .line 68
    .line 69
    move-wide/from16 p0, p3

    .line 70
    .line 71
    if-nez v0, :cond_2

    .line 72
    .line 73
    move-wide/from16 v0, p0

    .line 74
    .line 75
    invoke-static {v3, v0, v1}, LX/004;->A0O(LX/2d4;J)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    or-int/2addr v6, v0

    .line 80
    :cond_2
    and-int/lit16 v0, v2, 0x6000

    .line 81
    .line 82
    const v8, 0x8000

    .line 83
    .line 84
    .line 85
    if-nez v0, :cond_3

    .line 86
    .line 87
    invoke-static {v3, v14, v2, v8}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    invoke-static {v0}, LX/3Rp;->A00(I)I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    or-int/2addr v6, v0

    .line 96
    :cond_3
    const/high16 v0, 0x30000

    .line 97
    .line 98
    and-int v0, v0, p9

    .line 99
    .line 100
    if-nez v0, :cond_4

    .line 101
    .line 102
    invoke-virtual/range {v59 .. v59}, Ljava/lang/Enum;->ordinal()I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    invoke-static {v3, v0}, LX/008;->A0M(LX/2d4;I)I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    or-int/2addr v6, v0

    .line 111
    :cond_4
    move/from16 v58, p10

    .line 112
    .line 113
    and-int/lit8 v1, p10, 0x40

    .line 114
    .line 115
    const/high16 v0, 0x180000

    .line 116
    .line 117
    if-nez v1, :cond_5

    .line 118
    .line 119
    and-int v0, p9, v0

    .line 120
    .line 121
    if-nez v0, :cond_6

    .line 122
    .line 123
    move-object/from16 v0, v17

    .line 124
    .line 125
    invoke-static {v3, v0}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    :cond_5
    or-int/2addr v6, v0

    .line 130
    :cond_6
    const v0, 0x92493

    .line 131
    .line 132
    .line 133
    invoke-static {v6, v0}, LX/005;->A1O(II)Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    invoke-static {v0, v3, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    if-eqz v0, :cond_e

    .line 142
    .line 143
    if-eqz v1, :cond_7

    .line 144
    .line 145
    sget-object v17, LX/3C1;->A00:LX/3Cb;

    .line 146
    .line 147
    :cond_7
    sget-object v0, LX/3Fe;->A0G:LX/Ip3;

    .line 148
    .line 149
    invoke-interface {v3, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    check-cast v9, LX/18m;

    .line 154
    .line 155
    invoke-static {v3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 160
    .line 161
    invoke-static {v6}, LX/008;->A1X(I)Z

    .line 162
    .line 163
    .line 164
    move-result v7

    .line 165
    and-int/lit8 v10, v6, 0x70

    .line 166
    .line 167
    const/16 v5, 0x20

    .line 168
    .line 169
    if-eq v10, v5, :cond_8

    .line 170
    .line 171
    and-int/lit8 v5, v6, 0x40

    .line 172
    .line 173
    if-eqz v5, :cond_c

    .line 174
    .line 175
    invoke-interface {v3, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    move-result v5

    .line 179
    if-eqz v5, :cond_c

    .line 180
    .line 181
    :cond_8
    const/4 v5, 0x1

    .line 182
    :goto_1
    or-int/2addr v7, v5

    .line 183
    invoke-interface {v3, v0, v1}, LX/2d4;->A68(J)Z

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    invoke-static {v3, v9, v7, v5}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 188
    .line 189
    .line 190
    move-result v10

    .line 191
    const v7, 0xe000

    .line 192
    .line 193
    .line 194
    and-int/2addr v7, v6

    .line 195
    const/16 v5, 0x4000

    .line 196
    .line 197
    if-eq v7, v5, :cond_9

    .line 198
    .line 199
    and-int v5, v6, v8

    .line 200
    .line 201
    if-eqz v5, :cond_b

    .line 202
    .line 203
    invoke-interface {v3, v14}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    move-result v5

    .line 207
    if-eqz v5, :cond_b

    .line 208
    .line 209
    :cond_9
    const/4 v5, 0x1

    .line 210
    :goto_2
    or-int/2addr v10, v5

    .line 211
    invoke-static {v6}, LX/009;->A1L(I)Z

    .line 212
    .line 213
    .line 214
    move-result v5

    .line 215
    or-int/2addr v10, v5

    .line 216
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v5

    .line 220
    const/4 v13, 0x0

    .line 221
    if-nez v10, :cond_a

    .line 222
    .line 223
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 224
    .line 225
    if-ne v5, v7, :cond_f

    .line 226
    .line 227
    :cond_a
    iget-object v7, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;->link:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;

    .line 228
    .line 229
    iget v5, v4, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;->start:I

    .line 230
    .line 231
    sget-object v27, LX/2RW;->A03:LX/2RW;

    .line 232
    .line 233
    sget-wide v32, LX/2hw;->A01:J

    .line 234
    .line 235
    sget-wide v36, LX/JOw;->A07:J

    .line 236
    .line 237
    new-instance v12, LX/2hh;

    .line 238
    .line 239
    move-object/from16 v19, v13

    .line 240
    .line 241
    move-object/from16 v20, v13

    .line 242
    .line 243
    move-object/from16 v21, v13

    .line 244
    .line 245
    move-object/from16 v22, v13

    .line 246
    .line 247
    move-object/from16 v23, v13

    .line 248
    .line 249
    move-object/from16 v24, v13

    .line 250
    .line 251
    move-object/from16 v25, v13

    .line 252
    .line 253
    move-object/from16 v26, v13

    .line 254
    .line 255
    move-object/from16 v28, v13

    .line 256
    .line 257
    move-object/from16 v29, v13

    .line 258
    .line 259
    move-wide/from16 v30, v0

    .line 260
    .line 261
    move-wide/from16 v34, v32

    .line 262
    .line 263
    move-object/from16 v18, v12

    .line 264
    .line 265
    invoke-direct/range {v18 .. v37}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 266
    .line 267
    .line 268
    invoke-static {}, LX/2b4;->A00()LX/2b4;

    .line 269
    .line 270
    .line 271
    move-result-object v8

    .line 272
    move/from16 v10, v16

    .line 273
    .line 274
    invoke-virtual {v8, v11, v10, v5}, LX/2b4;->A0D(Ljava/lang/CharSequence;II)V

    .line 275
    .line 276
    .line 277
    iget-object v15, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;->url:Ljava/lang/String;

    .line 278
    .line 279
    const v10, 0x3df5c28f    # 0.12f

    .line 280
    .line 281
    .line 282
    invoke-static {v0, v1, v10}, LX/JOw;->A04(JF)J

    .line 283
    .line 284
    .line 285
    move-result-wide v56

    .line 286
    new-instance v0, LX/2hh;

    .line 287
    .line 288
    move-object/from16 v38, v0

    .line 289
    .line 290
    move-object/from16 v39, v13

    .line 291
    .line 292
    move-object/from16 v40, v13

    .line 293
    .line 294
    move-object/from16 v41, v13

    .line 295
    .line 296
    move-object/from16 v42, v13

    .line 297
    .line 298
    move-object/from16 v43, v13

    .line 299
    .line 300
    move-object/from16 v44, v13

    .line 301
    .line 302
    move-object/from16 v45, v13

    .line 303
    .line 304
    move-object/from16 v46, v13

    .line 305
    .line 306
    move-object/from16 v47, v13

    .line 307
    .line 308
    move-object/from16 v48, v13

    .line 309
    .line 310
    move-object/from16 v49, v13

    .line 311
    .line 312
    move-wide/from16 v50, v36

    .line 313
    .line 314
    move-wide/from16 v52, v32

    .line 315
    .line 316
    move-wide/from16 v54, v32

    .line 317
    .line 318
    invoke-direct/range {v38 .. v57}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v12, v0}, LX/2hh;->A04(LX/2hh;)LX/2hh;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    new-instance v1, LX/2iS;

    .line 326
    .line 327
    invoke-direct {v1, v12, v0, v13, v13}, LX/2iS;-><init>(LX/2hh;LX/2hh;LX/2hh;LX/2hh;)V

    .line 328
    .line 329
    .line 330
    new-instance v10, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewInlineLinkText$annotatedText$1$1$1;

    .line 331
    .line 332
    move-object/from16 v20, v14

    .line 333
    .line 334
    move-object/from16 v21, v8

    .line 335
    .line 336
    move-object/from16 v22, v9

    .line 337
    .line 338
    move-object/from16 v23, v7

    .line 339
    .line 340
    move-object/from16 v18, v10

    .line 341
    .line 342
    move-object/from16 v19, v59

    .line 343
    .line 344
    invoke-direct/range {v18 .. v23}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewInlineLinkText$annotatedText$1$1$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/2b4;LX/18m;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;)V

    .line 345
    .line 346
    .line 347
    new-instance v0, LX/2iL;

    .line 348
    .line 349
    invoke-direct {v0, v10, v1, v15}, LX/2iL;-><init>(LX/2D4;LX/2iS;Ljava/lang/String;)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v8, v0}, LX/2b4;->A02(LX/2D7;)I

    .line 353
    .line 354
    .line 355
    move-result v1

    .line 356
    goto :goto_3

    .line 357
    :cond_b
    const/4 v5, 0x0

    .line 358
    goto/16 :goto_2

    .line 359
    .line 360
    :cond_c
    const/4 v5, 0x0

    .line 361
    goto/16 :goto_1

    .line 362
    .line 363
    :cond_d
    move v6, v2

    .line 364
    goto/16 :goto_0

    .line 365
    .line 366
    :goto_3
    :try_start_0
    iget-object v0, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;->label:Ljava/lang/String;

    .line 367
    .line 368
    invoke-virtual {v8, v0}, LX/2b4;->A0E(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    goto :goto_4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 372
    :catchall_0
    move-exception v0

    .line 373
    invoke-virtual {v8, v1}, LX/2b4;->A06(I)V

    .line 374
    .line 375
    .line 376
    throw v0

    .line 377
    :cond_e
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 378
    .line 379
    .line 380
    goto :goto_5

    .line 381
    :goto_4
    invoke-virtual {v8, v1}, LX/2b4;->A06(I)V

    .line 382
    .line 383
    .line 384
    iget-object v0, v7, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;->label:Ljava/lang/String;

    .line 385
    .line 386
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 387
    .line 388
    .line 389
    move-result v0

    .line 390
    add-int/2addr v5, v0

    .line 391
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 392
    .line 393
    .line 394
    move-result v0

    .line 395
    invoke-virtual {v8, v11, v5, v0}, LX/2b4;->A0D(Ljava/lang/CharSequence;II)V

    .line 396
    .line 397
    .line 398
    invoke-static {v3, v8}, LX/3Rr;->A0C(LX/2d4;LX/2b4;)LX/2iK;

    .line 399
    .line 400
    .line 401
    move-result-object v5

    .line 402
    :cond_f
    check-cast v5, LX/2iK;

    .line 403
    .line 404
    invoke-static/range {v17 .. v17}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 405
    .line 406
    .line 407
    move-result-object v19

    .line 408
    shr-int/lit8 v0, v6, 0x3

    .line 409
    .line 410
    and-int/lit16 v1, v0, 0x380

    .line 411
    .line 412
    shl-int/lit8 v0, v6, 0x3

    .line 413
    .line 414
    and-int/lit16 v0, v0, 0x1c00

    .line 415
    .line 416
    or-int/2addr v1, v0

    .line 417
    const/16 v38, 0x7ff0

    .line 418
    .line 419
    const-wide/16 v26, 0x0

    .line 420
    .line 421
    move-object/from16 v24, v13

    .line 422
    .line 423
    move-object/from16 v25, v13

    .line 424
    .line 425
    move/from16 v29, v16

    .line 426
    .line 427
    move/from16 v30, v16

    .line 428
    .line 429
    move/from16 v31, v16

    .line 430
    .line 431
    move-object/from16 v32, v13

    .line 432
    .line 433
    move-object/from16 v33, v13

    .line 434
    .line 435
    move-object/from16 v34, v13

    .line 436
    .line 437
    move-object/from16 v35, v3

    .line 438
    .line 439
    move/from16 v36, v1

    .line 440
    .line 441
    move/from16 v37, v16

    .line 442
    .line 443
    move-wide/from16 v20, p0

    .line 444
    .line 445
    move-object/from16 v22, p2

    .line 446
    .line 447
    move-object/from16 v23, v13

    .line 448
    .line 449
    move/from16 v28, v16

    .line 450
    .line 451
    move-object/from16 v18, v5

    .line 452
    .line 453
    invoke-static/range {v18 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 454
    .line 455
    .line 456
    :goto_5
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 457
    .line 458
    .line 459
    move-result-object v1

    .line 460
    if-eqz v1, :cond_10

    .line 461
    .line 462
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewInlineLinkText$1;

    .line 463
    .line 464
    move-object/from16 v48, v0

    .line 465
    .line 466
    move-object/from16 v49, v11

    .line 467
    .line 468
    move-object/from16 v50, v4

    .line 469
    .line 470
    move-object/from16 v51, p2

    .line 471
    .line 472
    move-wide/from16 v52, p0

    .line 473
    .line 474
    move-object/from16 v54, v14

    .line 475
    .line 476
    move-object/from16 v55, v59

    .line 477
    .line 478
    move-object/from16 v56, v17

    .line 479
    .line 480
    move/from16 v57, v2

    .line 481
    .line 482
    invoke-direct/range {v48 .. v58}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewInlineLinkText$1;-><init>(Ljava/lang/String;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewInlineLink;LX/2hg;JLcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/3C1;II)V

    .line 483
    .line 484
    .line 485
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 486
    .line 487
    :cond_10
    return-void
.end method

.method public static final PreviewLinks(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;LX/2hg;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)V
    .locals 43

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v10, p0

    .line 2
    .line 3
    invoke-static {v10, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/4 v8, 0x1

    .line 7
    move-object/from16 v14, p2

    .line 8
    .line 9
    move-object/from16 p0, p3

    .line 10
    .line 11
    move-object/from16 v1, p0

    .line 12
    .line 13
    move-object/from16 v0, p1

    .line 14
    .line 15
    invoke-static {v0, v14, v1, v8}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    const v0, -0x5448e685    # -1.3010004E-12f

    .line 19
    .line 20
    .line 21
    move-object/from16 v7, p4

    .line 22
    .line 23
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 24
    .line 25
    .line 26
    move/from16 v6, p5

    .line 27
    .line 28
    and-int/lit8 v0, p5, 0x6

    .line 29
    .line 30
    if-nez v0, :cond_3

    .line 31
    .line 32
    invoke-static {v10, v7, v6}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, LX/003;->A06(I)I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    or-int v4, v4, p5

    .line 41
    .line 42
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 43
    .line 44
    if-nez v0, :cond_0

    .line 45
    .line 46
    move-object/from16 v0, p1

    .line 47
    .line 48
    invoke-static {v7, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    or-int/2addr v4, v0

    .line 53
    :cond_0
    and-int/lit16 v0, v6, 0x180

    .line 54
    .line 55
    if-nez v0, :cond_1

    .line 56
    .line 57
    invoke-static {v14, v7, v6}, LX/005;->A1Y(Ljava/lang/Object;LX/2d4;I)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-static {v0}, LX/003;->A08(I)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    or-int/2addr v4, v0

    .line 66
    :cond_1
    and-int/lit16 v0, v6, 0xc00

    .line 67
    .line 68
    if-nez v0, :cond_2

    .line 69
    .line 70
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Enum;->ordinal()I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-static {v7, v0}, LX/008;->A0L(LX/2d4;I)I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    or-int/2addr v4, v0

    .line 79
    :cond_2
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    invoke-static {v0, v7, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_a

    .line 88
    .line 89
    sget-object v0, LX/3Fe;->A0G:LX/Ip3;

    .line 90
    .line 91
    invoke-interface {v7, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    check-cast v3, LX/18m;

    .line 96
    .line 97
    const/high16 v0, 0x40800000    # 4.0f

    .line 98
    .line 99
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 104
    .line 105
    sget-object v1, LX/2Id;->A02:LX/2sS;

    .line 106
    .line 107
    const/4 v0, 0x6

    .line 108
    invoke-static {v2, v7, v1, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 109
    .line 110
    .line 111
    move-result-object v13

    .line 112
    move-object v2, v7

    .line 113
    check-cast v2, LX/J7I;

    .line 114
    .line 115
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 120
    .line 121
    .line 122
    move-result-object v11

    .line 123
    invoke-static {v7, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 124
    .line 125
    .line 126
    move-result-object v9

    .line 127
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 128
    .line 129
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 130
    .line 131
    if-nez v0, :cond_4

    .line 132
    .line 133
    invoke-static {}, LX/1VY;->A00()V

    .line 134
    .line 135
    .line 136
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    throw v0

    .line 141
    :cond_3
    move v4, v6

    .line 142
    goto :goto_0

    .line 143
    :cond_4
    invoke-static {v7, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 144
    .line 145
    .line 146
    invoke-static {v7, v13, v11, v9, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 147
    .line 148
    .line 149
    sget-object v39, LX/CgJ;->A00:LX/CgJ;

    .line 150
    .line 151
    iget-object v1, v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;->label:Ljava/lang/String;

    .line 152
    .line 153
    if-nez v1, :cond_9

    .line 154
    .line 155
    const v0, -0x4db0545c

    .line 156
    .line 157
    .line 158
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 159
    .line 160
    .line 161
    :goto_1
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 162
    .line 163
    .line 164
    const v0, 0x2f0adb9d

    .line 165
    .line 166
    .line 167
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 168
    .line 169
    .line 170
    iget-object v0, v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;->items:Ljava/util/List;

    .line 171
    .line 172
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 173
    .line 174
    .line 175
    move-result-object v16

    .line 176
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 177
    .line 178
    .line 179
    move-result v0

    .line 180
    if-eqz v0, :cond_b

    .line 181
    .line 182
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v9

    .line 186
    check-cast v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;

    .line 187
    .line 188
    iget-object v0, v9, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;->label:Ljava/lang/String;

    .line 189
    .line 190
    move-object/from16 v42, v0

    .line 191
    .line 192
    sget-object v23, LX/2RW;->A03:LX/2RW;

    .line 193
    .line 194
    const v30, 0xffefff

    .line 195
    .line 196
    .line 197
    const/4 v15, 0x0

    .line 198
    const-wide/16 v31, 0x0

    .line 199
    .line 200
    move-object/from16 v19, v15

    .line 201
    .line 202
    move-object/from16 v20, v15

    .line 203
    .line 204
    move-object/from16 v21, v15

    .line 205
    .line 206
    move-object/from16 v22, v15

    .line 207
    .line 208
    move-object/from16 v24, v15

    .line 209
    .line 210
    move-object/from16 v25, v15

    .line 211
    .line 212
    move-object/from16 v26, v15

    .line 213
    .line 214
    move/from16 v27, v5

    .line 215
    .line 216
    move/from16 v28, v5

    .line 217
    .line 218
    move/from16 v29, v5

    .line 219
    .line 220
    move-wide/from16 v33, v31

    .line 221
    .line 222
    move-wide/from16 v35, v31

    .line 223
    .line 224
    move-wide/from16 v37, v31

    .line 225
    .line 226
    move-object/from16 v17, v15

    .line 227
    .line 228
    move-object/from16 v18, p1

    .line 229
    .line 230
    invoke-static/range {v17 .. v38}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 231
    .line 232
    .line 233
    move-result-object v21

    .line 234
    invoke-static {v7}, LX/001;->A0k(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 239
    .line 240
    move-wide/from16 v22, v0

    .line 241
    .line 242
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 243
    .line 244
    const/high16 v0, 0x42400000    # 48.0f

    .line 245
    .line 246
    invoke-static {v1, v0}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 247
    .line 248
    .line 249
    move-result-object v13

    .line 250
    invoke-static {v5}, LX/1Y9;->A01(I)LX/1Y9;

    .line 251
    .line 252
    .line 253
    move-result-object v12

    .line 254
    invoke-static {v4}, LX/005;->A1L(I)Z

    .line 255
    .line 256
    .line 257
    move-result v11

    .line 258
    and-int/lit16 v1, v4, 0x380

    .line 259
    .line 260
    const/16 v0, 0x100

    .line 261
    .line 262
    if-eq v1, v0, :cond_5

    .line 263
    .line 264
    and-int/lit16 v0, v4, 0x200

    .line 265
    .line 266
    if-eqz v0, :cond_8

    .line 267
    .line 268
    invoke-interface {v7, v14}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    move-result v0

    .line 272
    if-eqz v0, :cond_8

    .line 273
    .line 274
    :cond_5
    const/4 v0, 0x1

    .line 275
    :goto_3
    or-int/2addr v11, v0

    .line 276
    invoke-static {v7, v3, v9, v11}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 277
    .line 278
    .line 279
    move-result v1

    .line 280
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    if-nez v1, :cond_6

    .line 285
    .line 286
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 287
    .line 288
    if-ne v0, v1, :cond_7

    .line 289
    .line 290
    :cond_6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;

    .line 291
    .line 292
    move-object/from16 v37, p0

    .line 293
    .line 294
    move-object/from16 v38, v14

    .line 295
    .line 296
    move-object/from16 v40, v3

    .line 297
    .line 298
    move-object/from16 v41, v9

    .line 299
    .line 300
    move-object/from16 v36, v0

    .line 301
    .line 302
    invoke-direct/range {v36 .. v41}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$1$2$1$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;LX/3dS;LX/18m;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewLink;)V

    .line 303
    .line 304
    .line 305
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 306
    .line 307
    .line 308
    :cond_7
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 309
    .line 310
    invoke-static {v13, v12, v15, v0, v8}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    const/high16 v0, 0x41400000    # 12.0f

    .line 315
    .line 316
    invoke-static {v1, v0}, LX/2pj;->A05(LX/3C1;F)LX/3C1;

    .line 317
    .line 318
    .line 319
    move-result-object v18

    .line 320
    const/16 v35, 0x3ff0

    .line 321
    .line 322
    move-object/from16 v17, v42

    .line 323
    .line 324
    move-wide/from16 v19, v22

    .line 325
    .line 326
    move-object/from16 v22, v15

    .line 327
    .line 328
    move-object/from16 v23, v15

    .line 329
    .line 330
    move/from16 v25, v5

    .line 331
    .line 332
    move/from16 v26, v5

    .line 333
    .line 334
    move-object/from16 v29, v15

    .line 335
    .line 336
    move-object/from16 v30, v15

    .line 337
    .line 338
    move-object/from16 v31, v15

    .line 339
    .line 340
    move-object/from16 v32, v7

    .line 341
    .line 342
    move/from16 v33, v5

    .line 343
    .line 344
    move/from16 v34, v5

    .line 345
    .line 346
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 347
    .line 348
    .line 349
    goto/16 :goto_2

    .line 350
    .line 351
    :cond_8
    const/4 v0, 0x0

    .line 352
    goto :goto_3

    .line 353
    :cond_9
    const v0, -0x4db0545b

    .line 354
    .line 355
    .line 356
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 357
    .line 358
    .line 359
    invoke-static {v1, v7, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewKt;->PreviewLabel(Ljava/lang/String;LX/2d4;I)V

    .line 360
    .line 361
    .line 362
    goto/16 :goto_1

    .line 363
    .line 364
    :cond_a
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 365
    .line 366
    .line 367
    goto :goto_4

    .line 368
    :cond_b
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 369
    .line 370
    .line 371
    invoke-static {v2, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 372
    .line 373
    .line 374
    :goto_4
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 375
    .line 376
    .line 377
    move-result-object v1

    .line 378
    if-eqz v1, :cond_c

    .line 379
    .line 380
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$2;

    .line 381
    .line 382
    move-object v7, v0

    .line 383
    move-object v8, v10

    .line 384
    move-object/from16 v9, p1

    .line 385
    .line 386
    move-object v10, v14

    .line 387
    move-object/from16 v11, p0

    .line 388
    .line 389
    move v12, v6

    .line 390
    invoke-direct/range {v7 .. v12}, Lcom/facebook/aura/agentpermission/AgentPermissionRequestPreviewLinksKt$PreviewLinks$2;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionRequestPreviewBlock$Links;LX/2hg;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;I)V

    .line 391
    .line 392
    .line 393
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 394
    .line 395
    :cond_c
    return-void
.end method
