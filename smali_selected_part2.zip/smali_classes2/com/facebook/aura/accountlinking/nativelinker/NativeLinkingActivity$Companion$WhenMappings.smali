.class public abstract synthetic Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->values()[Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->FACEBOOK:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 9
    .line 10
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    :catch_0
    const/4 v2, 0x2

    .line 14
    :try_start_1
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->MESSENGER:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 15
    .line 16
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 17
    .line 18
    .line 19
    :catch_1
    :try_start_2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->INSTAGRAM:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 20
    .line 21
    invoke-static {v0, v1}, LX/007;->A1I(Ljava/lang/Enum;[I)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 22
    .line 23
    .line 24
    :catch_2
    :try_start_3
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->THREADS:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 25
    .line 26
    invoke-static {v0, v1}, LX/007;->A1J(Ljava/lang/Enum;[I)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 27
    .line 28
    .line 29
    :catch_3
    sput-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 30
    .line 31
    invoke-static {}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->values()[Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    array-length v0, v0

    .line 36
    new-array v1, v0, [I

    .line 37
    .line 38
    :try_start_4
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->FACEBOOK:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 39
    .line 40
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 41
    .line 42
    .line 43
    :catch_4
    :try_start_5
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->INSTAGRAM:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 44
    .line 45
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 46
    .line 47
    .line 48
    :catch_5
    sput-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$WhenMappings;->$EnumSwitchMapping$1:[I

    .line 49
    .line 50
    return-void
.end method
