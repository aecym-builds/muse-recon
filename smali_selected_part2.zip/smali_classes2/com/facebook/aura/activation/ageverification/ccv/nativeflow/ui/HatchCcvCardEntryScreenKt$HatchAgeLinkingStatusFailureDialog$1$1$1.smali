.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $dismissLabel:Ljava/lang/String;

.field public final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRetry:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $retryLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$retryLabel:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$onRetry:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$dismissLabel:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 9

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    move-object v0, p0

    .line 6
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$retryLabel:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$onRetry:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x1

    .line 12
    const-string v6, "primary_button"

    .line 13
    .line 14
    const p0, 0x7fffffff

    .line 15
    .line 16
    .line 17
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 18
    .line 19
    move-object v8, v3

    .line 20
    invoke-interface/range {v1 .. v10}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(Ljava/lang/String;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ILX/3C1;)V

    .line 21
    .line 22
    .line 23
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$dismissLabel:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 26
    .line 27
    const-string v6, "secondary_button"

    .line 28
    .line 29
    move-object v7, v0

    .line 30
    move-object p0, p1

    .line 31
    invoke-interface/range {v1 .. v9}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->secondaryButton(Ljava/lang/String;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
