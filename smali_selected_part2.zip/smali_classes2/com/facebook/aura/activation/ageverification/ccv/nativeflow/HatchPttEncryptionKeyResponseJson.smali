.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson$Companion;


# instance fields
.field public final dev_external:Z

.field public final id:Ljava/lang/String;

.field public final platform_trust_token:Ljava/lang/String;

.field public final trust_chain:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v0, v2, v2, v2}, [Lkotlin/Lazy;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 805306368
    const/4 v2, 0x0

    .line 805306369
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    const/4 v0, 0x0

    .line 805306372
    invoke-direct {p0, v1, v2, v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/util/List;Ljava/lang/String;Ljava/lang/String;ZLX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-static {p2, p1}, LX/3Rp;->A0z(Ljava/util/List;I)Ljava/util/List;

    .line 536870916
    .line 536870917
    .line 536870918
    move-result-object v0

    .line 536870919
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 536870920
    .line 536870921
    and-int/lit8 v0, p1, 0x2

    .line 536870922
    .line 536870923
    const/4 v1, 0x0

    .line 536870924
    if-nez v0, :cond_1

    .line 536870925
    .line 536870926
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 536870927
    .line 536870928
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_0

    .line 536870931
    .line 536870932
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 536870933
    .line 536870934
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 536870935
    .line 536870936
    if-nez v0, :cond_2

    .line 536870937
    .line 536870938
    const/4 v0, 0x0

    .line 536870939
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 536870940
    .line 536870941
    return-void

    .line 536870942
    :cond_0
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 536870943
    .line 536870944
    goto :goto_1

    .line 536870945
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 536870946
    .line 536870947
    goto :goto_0

    .line 536870948
    :cond_2
    iput-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 536870949
    .line 536870950
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 12
    .line 13
    iput-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZILX/04f;)V
    .locals 3

    .line 268435456
    invoke-static {p1, p5}, LX/3Rr;->A0s(Ljava/util/List;I)Ljava/util/List;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object v2

    .line 268435460
    and-int/lit8 v0, p5, 0x2

    .line 268435461
    .line 268435462
    const/4 v1, 0x0

    .line 268435463
    if-eqz v0, :cond_0

    .line 268435464
    .line 268435465
    move-object p2, v1

    .line 268435466
    :cond_0
    and-int/lit8 v0, p5, 0x4

    .line 268435467
    .line 268435468
    if-eqz v0, :cond_1

    .line 268435469
    .line 268435470
    move-object p3, v1

    .line 268435471
    :cond_1
    invoke-static {p5, p4}, LX/3Rr;->A1P(IZ)Z

    .line 268435472
    .line 268435473
    .line 268435474
    move-result v0

    .line 268435475
    invoke-direct {p0, v2, p2, p3, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 268435476
    .line 268435477
    .line 268435478
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 23
    .line 24
    :cond_3
    const/4 v0, 0x0

    .line 25
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;

    .line 29
    .line 30
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    invoke-static {v1, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 24
    .line 25
    .line 26
    :cond_1
    const/4 v2, 0x1

    .line 27
    if-nez v3, :cond_2

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v0, :cond_3

    .line 32
    .line 33
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 36
    .line 37
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_3
    const/4 v2, 0x2

    .line 41
    if-nez v3, :cond_4

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 44
    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 50
    .line 51
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 52
    .line 53
    .line 54
    :cond_5
    const/4 v1, 0x3

    .line 55
    if-nez v3, :cond_6

    .line 56
    .line 57
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 58
    .line 59
    if-eqz v0, :cond_7

    .line 60
    .line 61
    :cond_6
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 62
    .line 63
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 64
    .line 65
    .line 66
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 41
    .line 42
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 43
    .line 44
    if-eq v1, v0, :cond_1

    .line 45
    .line 46
    :cond_0
    return v2

    .line 47
    :cond_1
    return v3
.end method

.method public final getDev_external()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlatform_trust_token()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTrust_chain()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->platform_trust_token:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    mul-int/lit8 v1, v1, 0x1f

    .line 23
    .line 24
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->dev_external:Z

    .line 25
    .line 26
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
