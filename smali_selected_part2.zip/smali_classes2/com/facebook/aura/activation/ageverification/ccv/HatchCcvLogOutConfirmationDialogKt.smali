.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final HatchCcvLogOutConfirmationDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v13, p0

    .line 1
    .line 2
    move-object/from16 v3, p1

    .line 3
    .line 4
    move-object/from16 v7, p2

    .line 5
    .line 6
    invoke-static {v13, v3}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v15

    .line 10
    const v0, -0x7b994541

    .line 11
    .line 12
    .line 13
    move-object/from16 v1, p3

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v2, p4

    .line 19
    .line 20
    and-int/lit8 v0, p4, 0x6

    .line 21
    .line 22
    if-nez v0, :cond_6

    .line 23
    .line 24
    invoke-static {v1, v13}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    or-int v5, v5, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v1, v3}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v5, v0

    .line 39
    :cond_0
    and-int/lit8 v4, p5, 0x4

    .line 40
    .line 41
    if-eqz v4, :cond_5

    .line 42
    .line 43
    or-int/lit16 v5, v5, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    invoke-static {v5}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v1, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_4

    .line 54
    .line 55
    if-eqz v4, :cond_2

    .line 56
    .line 57
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    const v0, 0x7f12081b

    .line 60
    .line 61
    .line 62
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v8

    .line 66
    const v0, 0x7f120809

    .line 67
    .line 68
    .line 69
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v6

    .line 73
    const v0, 0x7f1210b4

    .line 74
    .line 75
    .line 76
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v9

    .line 80
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt$HatchCcvLogOutConfirmationDialog$1;

    .line 81
    .line 82
    invoke-direct {v4, v8, v3, v6, v13}, Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt$HatchCcvLogOutConfirmationDialog$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    const v0, -0x40e5e0f2

    .line 86
    .line 87
    .line 88
    invoke-static {v1, v4, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 89
    .line 90
    .line 91
    move-result-object v12

    .line 92
    shr-int/lit8 v0, v5, 0x6

    .line 93
    .line 94
    and-int/lit8 v4, v0, 0xe

    .line 95
    .line 96
    const/high16 v0, 0x30000

    .line 97
    .line 98
    or-int/2addr v4, v0

    .line 99
    shl-int/lit8 v0, v5, 0x12

    .line 100
    .line 101
    invoke-static {v0, v4}, LX/001;->A06(II)I

    .line 102
    .line 103
    .line 104
    move-result p2

    .line 105
    const/16 p4, 0x798

    .line 106
    .line 107
    const/4 v10, 0x0

    .line 108
    move-object v11, v10

    .line 109
    move-object v14, v10

    .line 110
    move/from16 v16, v15

    .line 111
    .line 112
    move-object/from16 p0, v10

    .line 113
    .line 114
    move/from16 p3, v15

    .line 115
    .line 116
    move-object/from16 p1, v1

    .line 117
    .line 118
    invoke-static/range {v7 .. v21}, Lcom/facebook/aura/vds/compose/dialog/AuraAlertDialogKt;->AuraAlertDialog(LX/3C1;Ljava/lang/String;Ljava/lang/String;LX/JDN;LX/JDN;LX/JDN;Lkotlin/jvm/functions/Function0;LX/0yv;ZZLX/JDM;LX/2d4;III)V

    .line 119
    .line 120
    .line 121
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    if-eqz v1, :cond_3

    .line 126
    .line 127
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt$HatchCcvLogOutConfirmationDialog$2;

    .line 128
    .line 129
    move-object/from16 p0, v0

    .line 130
    .line 131
    move-object/from16 p1, v13

    .line 132
    .line 133
    move-object/from16 p2, v3

    .line 134
    .line 135
    move-object/from16 p3, v7

    .line 136
    .line 137
    move/from16 p4, v2

    .line 138
    .line 139
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt$HatchCcvLogOutConfirmationDialog$2;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 140
    .line 141
    .line 142
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 143
    .line 144
    :cond_3
    return-void

    .line 145
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 146
    .line 147
    .line 148
    goto :goto_2

    .line 149
    :cond_5
    and-int/lit16 v0, v2, 0x180

    .line 150
    .line 151
    if-nez v0, :cond_1

    .line 152
    .line 153
    invoke-static {v1, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    or-int/2addr v5, v0

    .line 158
    goto :goto_1

    .line 159
    :cond_6
    move v5, v2

    .line 160
    goto/16 :goto_0
.end method
