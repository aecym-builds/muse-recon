.class public abstract Lcom/facebook/aura/activation/repo/InviteTooltipRepositoryKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INVITE_TOOLTIP_SEEN:Ljava/lang/String; = "invite_button_tooltip_seen"
