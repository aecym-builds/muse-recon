.class public final Lcom/facebook/aura/activation/repo/InviteTooltipRepository;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HE;


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion;


# instance fields
.field public final _seen:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final prefs:LX/BVu;

.field public final seen:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->Companion:Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/common/prefs/HatchPrefsStore;->INSTANCE:Lcom/facebook/aura/common/prefs/HatchPrefsStore;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lcom/facebook/aura/common/prefs/HatchPrefsStore;->userPrefs(LX/AHE;)LX/BVu;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    iput-object v2, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->prefs:LX/BVu;

    .line 10
    .line 11
    const-string v1, "invite_button_tooltip_seen"

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-interface {v2, v1, v0}, LX/BVu;->getBoolean(Ljava/lang/String;Z)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-static {v0}, LX/3Rp;->A18(Z)LX/Ddv;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->_seen:LX/2J2;

    .line 23
    .line 24
    invoke-static {v0}, LX/002;->A1G(LX/2J3;)LX/ERk;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->seen:LX/2J3;

    .line 29
    .line 30
    return-void
.end method

.method public synthetic constructor <init>(LX/AHE;LX/04f;)V
    .locals 0

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;-><init>(LX/AHE;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method


# virtual methods
.method public clearUserData()V
    .locals 0

    .line 0
    return-void
.end method

.method public final getSeen()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->seen:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final markSeen()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->prefs:LX/BVu;

    .line 1
    .line 2
    invoke-interface {v0}, LX/BVu;->A9u()LX/Df3;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    const-string v0, "invite_button_tooltip_seen"

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {v2, v0, v1}, LX/Df3;->A08(Ljava/lang/String;Z)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v2}, LX/Df3;->apply()V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->_seen:LX/2J2;

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/3Rp;->A1P(LX/2J2;Z)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
