.class public final Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$Companion;


# instance fields
.field public final agreement_status:Ljava/lang/String;

.field public final company_name:Ljava/lang/String;

.field public final email:Ljava/lang/String;

.field public final mode:Ljava/lang/String;

.field public final name:Ljava/lang/String;

.field public final recipient_view_id:Ljava/lang/String;

.field public final term:Lcom/facebook/aura/activation/repo/NdaTermJson;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->Companion:Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 7

    .line 0
    const/4 v4, 0x0

    .line 1
    const-string v1, ""

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    move-object v2, v1

    .line 5
    move-object v3, v1

    .line 6
    move-object v5, v4

    .line 7
    move-object v6, v4

    .line 8
    move-object p0, v4

    .line 9
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const-string v1, ""

    .line 268435462
    .line 268435463
    if-nez v0, :cond_5

    .line 268435464
    .line 268435465
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 268435466
    .line 268435467
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435468
    .line 268435469
    if-nez v0, :cond_4

    .line 268435470
    .line 268435471
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 268435472
    .line 268435473
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435474
    .line 268435475
    if-nez v0, :cond_3

    .line 268435476
    .line 268435477
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 268435478
    .line 268435479
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 268435480
    .line 268435481
    const/4 v1, 0x0

    .line 268435482
    if-nez v0, :cond_2

    .line 268435483
    .line 268435484
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 268435485
    .line 268435486
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 268435487
    .line 268435488
    if-nez v0, :cond_1

    .line 268435489
    .line 268435490
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 268435491
    .line 268435492
    :goto_4
    and-int/lit8 v0, p1, 0x20

    .line 268435493
    .line 268435494
    if-nez v0, :cond_0

    .line 268435495
    .line 268435496
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 268435497
    .line 268435498
    :goto_5
    and-int/lit8 v0, p1, 0x40

    .line 268435499
    .line 268435500
    if-nez v0, :cond_6

    .line 268435501
    .line 268435502
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 268435503
    .line 268435504
    return-void

    .line 268435505
    :cond_0
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 268435506
    .line 268435507
    goto :goto_5

    .line 268435508
    :cond_1
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 268435509
    .line 268435510
    goto :goto_4

    .line 268435511
    :cond_2
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 268435512
    .line 268435513
    goto :goto_3

    .line 268435514
    :cond_3
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 268435515
    .line 268435516
    goto :goto_2

    .line 268435517
    :cond_4
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 268435518
    .line 268435519
    goto :goto_1

    .line 268435520
    :cond_5
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 268435521
    .line 268435522
    goto :goto_0

    .line 268435523
    :cond_6
    iput-object p8, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 268435524
    .line 268435525
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 536870912
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870916
    .line 536870917
    .line 536870918
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 536870919
    .line 536870920
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 536870921
    .line 536870922
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 536870923
    .line 536870924
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 536870925
    .line 536870926
    iput-object p5, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 536870927
    .line 536870928
    iput-object p6, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 536870929
    .line 536870930
    iput-object p7, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 536870931
    .line 536870932
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 805306368
    and-int/lit8 v0, p8, 0x1

    .line 805306369
    .line 805306370
    const-string v1, ""

    .line 805306371
    .line 805306372
    if-eqz v0, :cond_0

    .line 805306373
    .line 805306374
    move-object p1, v1

    .line 805306375
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 805306376
    .line 805306377
    if-eqz v0, :cond_1

    .line 805306378
    .line 805306379
    move-object p2, v1

    .line 805306380
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 805306381
    .line 805306382
    if-eqz v0, :cond_2

    .line 805306383
    .line 805306384
    move-object p3, v1

    .line 805306385
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 805306386
    .line 805306387
    const/4 v1, 0x0

    .line 805306388
    if-eqz v0, :cond_3

    .line 805306389
    .line 805306390
    move-object p4, v1

    .line 805306391
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 805306392
    .line 805306393
    if-eqz v0, :cond_4

    .line 805306394
    .line 805306395
    move-object p5, v1

    .line 805306396
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 805306397
    .line 805306398
    if-eqz v0, :cond_5

    .line 805306399
    .line 805306400
    move-object p6, v1

    .line 805306401
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 805306402
    .line 805306403
    if-eqz v0, :cond_6

    .line 805306404
    .line 805306405
    move-object p7, v1

    .line 805306406
    :cond_6
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 805306407
    .line 805306408
    .line 805306409
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;
    .locals 8

    .line 0
    move-object v1, p1

    .line 1
    move-object v2, p2

    .line 2
    move-object v3, p3

    .line 3
    move-object v4, p4

    .line 4
    move-object v5, p5

    .line 5
    move-object v6, p6

    .line 6
    move-object v7, p7

    .line 7
    and-int/lit8 v0, p8, 0x1

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 12
    .line 13
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 18
    .line 19
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 20
    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    iget-object v3, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 24
    .line 25
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 26
    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    iget-object v4, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 30
    .line 31
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 32
    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    iget-object v5, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 36
    .line 37
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 38
    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    iget-object v6, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 42
    .line 43
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 44
    .line 45
    if-eqz v0, :cond_6

    .line 46
    .line 47
    iget-object v7, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 48
    .line 49
    :cond_6
    invoke-static {v1, v2, v3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 53
    .line 54
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    const-string v2, ""

    .line 6
    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x1

    .line 23
    if-nez v3, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    const/4 v1, 0x2

    .line 39
    if-nez v3, :cond_4

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-nez v0, :cond_5

    .line 48
    .line 49
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 50
    .line 51
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 52
    .line 53
    .line 54
    :cond_5
    const/4 v2, 0x3

    .line 55
    if-nez v3, :cond_6

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 58
    .line 59
    if-eqz v0, :cond_7

    .line 60
    .line 61
    :cond_6
    sget-object v1, Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 64
    .line 65
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 66
    .line 67
    .line 68
    :cond_7
    const/4 v2, 0x4

    .line 69
    if-nez v3, :cond_8

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 72
    .line 73
    if-eqz v0, :cond_9

    .line 74
    .line 75
    :cond_8
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 76
    .line 77
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 78
    .line 79
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 80
    .line 81
    .line 82
    :cond_9
    const/4 v2, 0x5

    .line 83
    if-nez v3, :cond_a

    .line 84
    .line 85
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 86
    .line 87
    if-eqz v0, :cond_b

    .line 88
    .line 89
    :cond_a
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 90
    .line 91
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 92
    .line 93
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 94
    .line 95
    .line 96
    :cond_b
    const/4 v2, 0x6

    .line 97
    if-nez v3, :cond_c

    .line 98
    .line 99
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 100
    .line 101
    if-eqz v0, :cond_d

    .line 102
    .line 103
    :cond_c
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 104
    .line 105
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 106
    .line 107
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 108
    .line 109
    .line 110
    :cond_d
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Lcom/facebook/aura/activation/repo/NdaTermJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_1

    .line 79
    .line 80
    :cond_0
    return v2

    .line 81
    :cond_1
    return v3
.end method

.method public final getAgreement_status()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCompany_name()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEmail()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRecipient_view_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTerm()Lcom/facebook/aura/activation/repo/NdaTermJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 37
    .line 38
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v1, v0

    .line 43
    mul-int/lit8 v1, v1, 0x1f

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 46
    .line 47
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    add-int/2addr v1, v0

    .line 52
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/activation/data/HatchNdaAgreement;
    .locals 8

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->recipient_view_id:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->agreement_status:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->mode:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->term:Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v4, v0, Lcom/facebook/aura/activation/repo/NdaTermJson;->text:Ljava/lang/String;

    .line 11
    .line 12
    if-nez v4, :cond_1

    .line 13
    .line 14
    :cond_0
    const-string v4, ""

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    :cond_1
    iget-object v5, v0, Lcom/facebook/aura/activation/repo/NdaTermJson;->required_fields:Ljava/util/List;

    .line 19
    .line 20
    if-nez v5, :cond_3

    .line 21
    .line 22
    :cond_2
    sget-object v5, LX/0wV;->A00:LX/0wV;

    .line 23
    .line 24
    :cond_3
    iget-object v6, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->name:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v7, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->email:Ljava/lang/String;

    .line 27
    .line 28
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->company_name:Ljava/lang/String;

    .line 29
    .line 30
    new-instance v0, Lcom/facebook/aura/activation/data/HatchNdaAgreement;

    .line 31
    .line 32
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/activation/data/HatchNdaAgreement;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
