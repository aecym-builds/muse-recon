.class public final synthetic Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v2, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x7

    .line 8
    const-string v0, "com.facebook.aura.activation.repo.NdaAgreementResponseJson"

    .line 9
    .line 10
    invoke-static {v0, v2, v1}, LX/3Rp;->A1G(Ljava/lang/String;LX/D8a;I)LX/DZp;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v0, "recipient_view_id"

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    const-string v0, "agreement_status"

    .line 21
    .line 22
    invoke-static {v0, v2, v1}, LX/3Rr;->A1C(Ljava/lang/String;LX/DZp;Z)V

    .line 23
    .line 24
    .line 25
    const-string v0, "term"

    .line 26
    .line 27
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 28
    .line 29
    .line 30
    const-string v0, "company_name"

    .line 31
    .line 32
    invoke-static {v0, v2, v1}, LX/3Rp;->A1J(Ljava/lang/String;LX/DZp;Z)V

    .line 33
    .line 34
    .line 35
    const-string v0, "email"

    .line 36
    .line 37
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 38
    .line 39
    .line 40
    sput-object v2, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->descriptor:LX/Da5;

    .line 41
    .line 42
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;

    .line 3
    .line 4
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 9
    .line 10
    .line 11
    move-result-object v5

    .line 12
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    move-object v2, v1

    .line 21
    move-object v3, v1

    .line 22
    filled-new-array/range {v1 .. v7}, [LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;
    .locals 16

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v6, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v6}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v5

    .line 12
    const/4 v4, 0x6

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v2, 0x3

    .line 15
    const/4 v1, 0x4

    .line 16
    const/4 v0, 0x2

    .line 17
    const/4 v10, 0x0

    .line 18
    move-object/from16 p0, v10

    .line 19
    .line 20
    move-object v11, v10

    .line 21
    move-object v12, v10

    .line 22
    move-object v13, v10

    .line 23
    move-object v14, v10

    .line 24
    move-object v15, v10

    .line 25
    const/4 v9, 0x0

    .line 26
    :goto_0
    invoke-interface {v5, v6}, LX/Da7;->A8S(LX/Da5;)I

    .line 27
    .line 28
    .line 29
    move-result v8

    .line 30
    packed-switch v8, :pswitch_data_0

    .line 31
    .line 32
    .line 33
    invoke-static {v8}, LX/3Rp;->A1C(I)Lkotlinx/serialization/UnknownFieldException;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    throw v0

    .line 38
    :pswitch_0
    invoke-interface {v5, v6, v7}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v10

    .line 42
    or-int/lit8 v9, v9, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :pswitch_1
    invoke-static {v6, v5}, LX/3Rr;->A0o(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v11

    .line 49
    or-int/lit8 v9, v9, 0x2

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :pswitch_2
    invoke-interface {v5, v6, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v12

    .line 56
    or-int/lit8 v9, v9, 0x4

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :pswitch_3
    sget-object v8, Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/repo/NdaTermJson$$serializer;

    .line 60
    .line 61
    invoke-interface {v5, v8, v6, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v13

    .line 65
    check-cast v13, Lcom/facebook/aura/activation/repo/NdaTermJson;

    .line 66
    .line 67
    or-int/lit8 v9, v9, 0x8

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :pswitch_4
    invoke-static {v6, v5, v1}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v14

    .line 74
    or-int/lit8 v9, v9, 0x10

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :pswitch_5
    invoke-static {v6, v5, v3}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v15

    .line 81
    or-int/lit8 v9, v9, 0x20

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :pswitch_6
    invoke-static {v6, v5, v4}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p0

    .line 88
    or-int/lit8 v9, v9, 0x40

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :pswitch_7
    invoke-interface {v5, v6}, LX/Da7;->AAi(LX/Da5;)V

    .line 92
    .line 93
    .line 94
    const/16 p1, 0x0

    .line 95
    .line 96
    new-instance v8, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 97
    .line 98
    invoke-direct/range {v8 .. v17}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/repo/NdaTermJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 99
    .line 100
    .line 101
    return-object v8

    .line 102
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_7
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/repo/NdaAgreementResponseJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
