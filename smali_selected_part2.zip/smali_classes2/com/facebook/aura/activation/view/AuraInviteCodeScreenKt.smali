.class public abstract Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final InviteCodeHeaderButtons:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/header/view/HeaderButton;",
            ">;"
        }
    .end annotation
.end field

.field public static final TitleWidthFraction:F = 0.72f


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/header/view/HeaderButton;->Settings:Lcom/facebook/aura/header/view/HeaderButton;

    .line 1
    .line 2
    filled-new-array {v0}, [Lcom/facebook/aura/header/view/HeaderButton;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/Dwp;->A05([Ljava/lang/Object;)LX/Dwf;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->InviteCodeHeaderButtons:LX/Dwf;

    .line 11
    .line 12
    return-void
.end method

.method public static final AuraInviteCodeScreen(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;Ljava/lang/String;ZLX/2d4;III)V
    .locals 67
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lcom/facebook/aura/activation/model/InviteCodeError;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Z",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 0
    move-object/from16 v15, p0

    .line 1
    .line 2
    move-object/from16 v14, p1

    .line 3
    .line 4
    move-object/from16 v17, p8

    .line 5
    .line 6
    move-object/from16 v4, p9

    .line 7
    .line 8
    move/from16 v5, p10

    .line 9
    .line 10
    invoke-static {v15, v14}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v29

    .line 14
    const/4 v13, 0x2

    .line 15
    move-object/from16 p10, p2

    .line 16
    .line 17
    move-object/from16 v10, p3

    .line 18
    .line 19
    move-object/from16 v0, p10

    .line 20
    .line 21
    invoke-static {v0, v13, v10}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    move-object/from16 v9, p4

    .line 26
    .line 27
    move-object/from16 v0, p7

    .line 28
    .line 29
    invoke-static {v9, v1, v0}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    const v0, -0x643f6c85

    .line 33
    .line 34
    .line 35
    move-object/from16 v1, p11

    .line 36
    .line 37
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 38
    .line 39
    .line 40
    move/from16 v2, p12

    .line 41
    .line 42
    and-int/lit8 v0, p12, 0x6

    .line 43
    .line 44
    if-nez v0, :cond_1c

    .line 45
    .line 46
    invoke-static {v1, v15}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    or-int v0, v0, p12

    .line 51
    .line 52
    :goto_0
    and-int/lit8 v3, p12, 0x30

    .line 53
    .line 54
    if-nez v3, :cond_0

    .line 55
    .line 56
    invoke-static {v1, v14}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v3

    .line 60
    or-int/2addr v0, v3

    .line 61
    :cond_0
    and-int/lit16 v3, v2, 0x180

    .line 62
    .line 63
    if-nez v3, :cond_1

    .line 64
    .line 65
    move-object/from16 v3, p10

    .line 66
    .line 67
    invoke-static {v1, v3}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    or-int/2addr v0, v3

    .line 72
    :cond_1
    and-int/lit16 v3, v2, 0xc00

    .line 73
    .line 74
    if-nez v3, :cond_2

    .line 75
    .line 76
    invoke-static {v1, v10}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    or-int/2addr v0, v3

    .line 81
    :cond_2
    and-int/lit16 v3, v2, 0x6000

    .line 82
    .line 83
    if-nez v3, :cond_3

    .line 84
    .line 85
    invoke-static {v1, v9}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    or-int/2addr v0, v3

    .line 90
    :cond_3
    const/high16 v3, 0x30000

    .line 91
    .line 92
    and-int v3, v3, p12

    .line 93
    .line 94
    move/from16 p9, p5

    .line 95
    .line 96
    if-nez v3, :cond_4

    .line 97
    .line 98
    move/from16 v3, p9

    .line 99
    .line 100
    invoke-static {v1, v3}, LX/004;->A0n(LX/2d4;Z)I

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    or-int/2addr v0, v3

    .line 105
    :cond_4
    const/high16 v3, 0x180000

    .line 106
    .line 107
    and-int v3, p12, v3

    .line 108
    .line 109
    move-object/from16 p8, p6

    .line 110
    .line 111
    if-nez v3, :cond_5

    .line 112
    .line 113
    const/high16 v6, 0x200000

    .line 114
    .line 115
    move-object/from16 v3, p8

    .line 116
    .line 117
    invoke-static {v1, v3, v2, v6}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 118
    .line 119
    .line 120
    move-result v3

    .line 121
    invoke-static {v3}, LX/003;->A03(I)I

    .line 122
    .line 123
    .line 124
    move-result v3

    .line 125
    or-int/2addr v0, v3

    .line 126
    :cond_5
    const/high16 v3, 0xc00000

    .line 127
    .line 128
    and-int v3, p12, v3

    .line 129
    .line 130
    if-nez v3, :cond_6

    .line 131
    .line 132
    move-object/from16 v3, p7

    .line 133
    .line 134
    invoke-static {v1, v3}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    or-int/2addr v0, v3

    .line 139
    :cond_6
    move/from16 v8, p14

    .line 140
    .line 141
    and-int/lit16 v12, v8, 0x100

    .line 142
    .line 143
    const/high16 v3, 0x6000000

    .line 144
    .line 145
    if-nez v12, :cond_7

    .line 146
    .line 147
    and-int v3, p12, v3

    .line 148
    .line 149
    if-nez v3, :cond_8

    .line 150
    .line 151
    move-object/from16 v3, v17

    .line 152
    .line 153
    invoke-static {v1, v3}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    :cond_7
    or-int/2addr v0, v3

    .line 158
    :cond_8
    and-int/lit16 v11, v8, 0x200

    .line 159
    .line 160
    const/high16 v3, 0x30000000

    .line 161
    .line 162
    if-nez v11, :cond_9

    .line 163
    .line 164
    and-int v3, p12, v3

    .line 165
    .line 166
    if-nez v3, :cond_a

    .line 167
    .line 168
    invoke-static {v1, v4}, LX/005;->A0C(LX/2d4;Ljava/lang/Object;)I

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    :cond_9
    or-int/2addr v0, v3

    .line 173
    :cond_a
    and-int/lit16 v7, v8, 0x400

    .line 174
    .line 175
    move/from16 v58, p13

    .line 176
    .line 177
    if-eqz v7, :cond_1a

    .line 178
    .line 179
    or-int/lit8 v19, p13, 0x6

    .line 180
    .line 181
    :goto_1
    const v3, 0x12492493

    .line 182
    .line 183
    .line 184
    and-int v6, v0, v3

    .line 185
    .line 186
    const v3, 0x12492492

    .line 187
    .line 188
    .line 189
    const/16 v18, 0x0

    .line 190
    .line 191
    if-ne v6, v3, :cond_b

    .line 192
    .line 193
    and-int/lit8 v6, v19, 0x3

    .line 194
    .line 195
    const/4 v3, 0x0

    .line 196
    if-eq v6, v13, :cond_c

    .line 197
    .line 198
    :cond_b
    const/4 v3, 0x1

    .line 199
    :cond_c
    invoke-static {v3, v1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 200
    .line 201
    .line 202
    move-result v3

    .line 203
    if-eqz v3, :cond_19

    .line 204
    .line 205
    if-eqz v12, :cond_d

    .line 206
    .line 207
    sget-object v17, LX/3C1;->A00:LX/3Cb;

    .line 208
    .line 209
    :cond_d
    if-eqz v11, :cond_e

    .line 210
    .line 211
    const-string v4, ""

    .line 212
    .line 213
    :cond_e
    invoke-static {v7, v5}, LX/001;->A1Q(IZ)Z

    .line 214
    .line 215
    .line 216
    move-result v5

    .line 217
    sget-object v12, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 218
    .line 219
    const/high16 v16, 0x70000000

    .line 220
    .line 221
    and-int v11, v0, v16

    .line 222
    .line 223
    const/high16 v7, 0x20000000

    .line 224
    .line 225
    invoke-static {v11, v7}, LX/003;->A1I(II)Z

    .line 226
    .line 227
    .line 228
    move-result v3

    .line 229
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v6

    .line 233
    if-nez v3, :cond_f

    .line 234
    .line 235
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 236
    .line 237
    if-ne v6, v3, :cond_10

    .line 238
    .line 239
    :cond_f
    new-instance v6, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$1$1;

    .line 240
    .line 241
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$1$1;-><init>(Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    invoke-interface {v1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_10
    check-cast v6, LX/JDM;

    .line 248
    .line 249
    invoke-static {v1, v12, v6}, LX/CdB;->A05(LX/2d4;Ljava/lang/Object;LX/JDM;)V

    .line 250
    .line 251
    .line 252
    invoke-static {v11, v7}, LX/003;->A1I(II)Z

    .line 253
    .line 254
    .line 255
    move-result v6

    .line 256
    invoke-static {v0}, LX/008;->A1X(I)Z

    .line 257
    .line 258
    .line 259
    move-result v3

    .line 260
    or-int/2addr v6, v3

    .line 261
    invoke-static {v0}, LX/005;->A1H(I)Z

    .line 262
    .line 263
    .line 264
    move-result v3

    .line 265
    or-int/2addr v6, v3

    .line 266
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v3

    .line 270
    if-nez v6, :cond_11

    .line 271
    .line 272
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 273
    .line 274
    if-ne v3, v6, :cond_12

    .line 275
    .line 276
    :cond_11
    new-instance v3, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;

    .line 277
    .line 278
    invoke-direct {v3, v4, v15, v14}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;-><init>(Ljava/lang/String;Ljava/lang/String;LX/JDM;)V

    .line 279
    .line 280
    .line 281
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 282
    .line 283
    .line 284
    :cond_12
    invoke-static {v1, v3, v4}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 285
    .line 286
    .line 287
    invoke-static {v1}, LX/001;->A0k(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 288
    .line 289
    .line 290
    move-result-object v3

    .line 291
    sget-object v20, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 292
    .line 293
    sget-object v22, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 294
    .line 295
    iget-wide v11, v3, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 296
    .line 297
    const/16 v26, 0x0

    .line 298
    .line 299
    new-instance v13, Lcom/facebook/aura/header/view/ScrimConfig$Heavy;

    .line 300
    .line 301
    invoke-direct {v13, v11, v12}, Lcom/facebook/aura/header/view/ScrimConfig$Heavy;-><init>(J)V

    .line 302
    .line 303
    .line 304
    sget-object v34, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->InviteCodeHeaderButtons:LX/Dwf;

    .line 305
    .line 306
    sget-object v60, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 307
    .line 308
    sget-object v61, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 309
    .line 310
    sget-object v62, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 311
    .line 312
    sget-object v63, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 313
    .line 314
    sget-object v64, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_CODE_FORM:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 315
    .line 316
    const/16 v43, 0x0

    .line 317
    .line 318
    const-wide/16 p1, 0x1f4

    .line 319
    .line 320
    move-object/from16 v59, v17

    .line 321
    .line 322
    move-object/from16 v65, v26

    .line 323
    .line 324
    move-object/from16 v66, v26

    .line 325
    .line 326
    move-object/from16 p0, v26

    .line 327
    .line 328
    move/from16 p3, v43

    .line 329
    .line 330
    move-object/from16 p4, v26

    .line 331
    .line 332
    move-object/from16 p5, v26

    .line 333
    .line 334
    move-object/from16 p6, v26

    .line 335
    .line 336
    invoke-static/range {v59 .. v73}, Lcom/facebook/aura/analytics/hatch/HatchImpressionModifierKt;->hatchImpression(LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;JFLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 337
    .line 338
    .line 339
    move-result-object v21

    .line 340
    invoke-static {v0}, LX/005;->A1L(I)Z

    .line 341
    .line 342
    .line 343
    move-result v6

    .line 344
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v3

    .line 348
    if-nez v6, :cond_13

    .line 349
    .line 350
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 351
    .line 352
    if-ne v3, v6, :cond_14

    .line 353
    .line 354
    :cond_13
    new-instance v3, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$3$1;

    .line 355
    .line 356
    invoke-direct {v3, v10}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$3$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 357
    .line 358
    .line 359
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    :cond_14
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 363
    .line 364
    const v6, 0xe000

    .line 365
    .line 366
    .line 367
    and-int/2addr v6, v0

    .line 368
    const/16 v0, 0x4000

    .line 369
    .line 370
    if-ne v6, v0, :cond_15

    .line 371
    .line 372
    const/16 v18, 0x1

    .line 373
    .line 374
    :cond_15
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 375
    .line 376
    .line 377
    move-result-object v0

    .line 378
    if-nez v18, :cond_16

    .line 379
    .line 380
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 381
    .line 382
    if-ne v0, v6, :cond_17

    .line 383
    .line 384
    :cond_16
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;

    .line 385
    .line 386
    invoke-direct {v0, v9}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 387
    .line 388
    .line 389
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 390
    .line 391
    .line 392
    :cond_17
    check-cast v0, LX/JDM;

    .line 393
    .line 394
    new-instance v7, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;

    .line 395
    .line 396
    move-object/from16 v35, v7

    .line 397
    .line 398
    move-object/from16 v36, v15

    .line 399
    .line 400
    move-object/from16 v37, v14

    .line 401
    .line 402
    move-object/from16 v38, p10

    .line 403
    .line 404
    move/from16 v39, p9

    .line 405
    .line 406
    move-object/from16 v40, p8

    .line 407
    .line 408
    move-object/from16 v41, p7

    .line 409
    .line 410
    invoke-direct/range {v35 .. v41}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;-><init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;)V

    .line 411
    .line 412
    .line 413
    const v6, 0x8e623c0

    .line 414
    .line 415
    .line 416
    invoke-static {v1, v7, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 417
    .line 418
    .line 419
    move-result-object v52

    .line 420
    shl-int/lit8 v6, v19, 0x1b

    .line 421
    .line 422
    and-int v6, v6, v16

    .line 423
    .line 424
    or-int/lit16 v6, v6, 0x6186

    .line 425
    .line 426
    const/high16 v56, 0x30000000

    .line 427
    .line 428
    const v57, 0x1fdf9da0

    .line 429
    .line 430
    .line 431
    const-string v25, ""

    .line 432
    .line 433
    const-wide/16 v38, 0x0

    .line 434
    .line 435
    const/16 v55, 0xc00

    .line 436
    .line 437
    move-object/from16 v27, v3

    .line 438
    .line 439
    move-object/from16 v28, v26

    .line 440
    .line 441
    move/from16 v30, v5

    .line 442
    .line 443
    move/from16 v31, v29

    .line 444
    .line 445
    move-object/from16 v32, v26

    .line 446
    .line 447
    move-object/from16 v33, v26

    .line 448
    .line 449
    move-object/from16 v35, v0

    .line 450
    .line 451
    move-object/from16 v36, v26

    .line 452
    .line 453
    move-object/from16 v37, v26

    .line 454
    .line 455
    move-wide/from16 v40, v38

    .line 456
    .line 457
    move-object/from16 v42, v26

    .line 458
    .line 459
    move-object/from16 v44, v13

    .line 460
    .line 461
    move-object/from16 v45, v26

    .line 462
    .line 463
    move-object/from16 v46, v26

    .line 464
    .line 465
    move/from16 v47, v29

    .line 466
    .line 467
    move-object/from16 v48, v26

    .line 468
    .line 469
    move-object/from16 v49, v26

    .line 470
    .line 471
    move-object/from16 v50, v26

    .line 472
    .line 473
    move/from16 v51, v29

    .line 474
    .line 475
    move-object/from16 v53, v1

    .line 476
    .line 477
    move/from16 v54, v6

    .line 478
    .line 479
    move-wide/from16 v23, v11

    .line 480
    .line 481
    invoke-static/range {v20 .. v57}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 482
    .line 483
    .line 484
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 485
    .line 486
    .line 487
    move-result-object v1

    .line 488
    if-eqz v1, :cond_18

    .line 489
    .line 490
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;

    .line 491
    .line 492
    move-object/from16 v45, v0

    .line 493
    .line 494
    move-object/from16 v46, v15

    .line 495
    .line 496
    move-object/from16 v47, v14

    .line 497
    .line 498
    move-object/from16 v48, p10

    .line 499
    .line 500
    move-object/from16 v49, v10

    .line 501
    .line 502
    move-object/from16 v50, v9

    .line 503
    .line 504
    move/from16 v51, p9

    .line 505
    .line 506
    move-object/from16 v52, p8

    .line 507
    .line 508
    move-object/from16 v53, p7

    .line 509
    .line 510
    move-object/from16 v54, v17

    .line 511
    .line 512
    move-object/from16 v55, v4

    .line 513
    .line 514
    move/from16 v56, v5

    .line 515
    .line 516
    move/from16 v57, v2

    .line 517
    .line 518
    move/from16 v59, v8

    .line 519
    .line 520
    invoke-direct/range {v45 .. v59}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;-><init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;Ljava/lang/String;ZIII)V

    .line 521
    .line 522
    .line 523
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 524
    .line 525
    :cond_18
    return-void

    .line 526
    :cond_19
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 527
    .line 528
    .line 529
    goto :goto_2

    .line 530
    :cond_1a
    and-int/lit8 v3, p13, 0x6

    .line 531
    .line 532
    const/4 v7, 0x0

    .line 533
    if-nez v3, :cond_1b

    .line 534
    .line 535
    invoke-static {v1, v5}, LX/004;->A0i(LX/2d4;Z)I

    .line 536
    .line 537
    .line 538
    move-result v3

    .line 539
    or-int v19, p13, v3

    .line 540
    .line 541
    goto/16 :goto_1

    .line 542
    .line 543
    :cond_1b
    move/from16 v19, v58

    .line 544
    .line 545
    goto/16 :goto_1

    .line 546
    .line 547
    :cond_1c
    move v0, v2

    .line 548
    goto/16 :goto_0
.end method

.method public static final InviteCodeContent-lVwrFTI(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/2d4;I)V
    .locals 56
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FF",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;ZZ",
            "Lcom/facebook/aura/activation/model/InviteCodeError;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v1, -0x6162e9fd

    .line 1
    .line 2
    .line 3
    move-object/from16 v0, p9

    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v3, p10

    .line 9
    .line 10
    and-int/lit8 v1, p10, 0x6

    .line 11
    .line 12
    if-nez v1, :cond_9

    .line 13
    .line 14
    move/from16 v1, p0

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/004;->A09(LX/2d4;F)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    or-int v1, v1, p10

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v2, p10, 0x30

    .line 23
    .line 24
    move/from16 v30, p1

    .line 25
    .line 26
    if-nez v2, :cond_0

    .line 27
    .line 28
    move/from16 v2, v30

    .line 29
    .line 30
    invoke-static {v0, v2}, LX/004;->A0A(LX/2d4;F)I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    or-int/2addr v1, v2

    .line 35
    :cond_0
    and-int/lit16 v2, v3, 0x180

    .line 36
    .line 37
    move-object/from16 v55, p2

    .line 38
    .line 39
    if-nez v2, :cond_1

    .line 40
    .line 41
    move-object/from16 v2, v55

    .line 42
    .line 43
    invoke-static {v0, v2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    or-int/2addr v1, v2

    .line 48
    :cond_1
    and-int/lit16 v2, v3, 0xc00

    .line 49
    .line 50
    move-object/from16 v54, p3

    .line 51
    .line 52
    if-nez v2, :cond_2

    .line 53
    .line 54
    move-object/from16 v2, v54

    .line 55
    .line 56
    invoke-static {v0, v2}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    or-int/2addr v1, v2

    .line 61
    :cond_2
    and-int/lit16 v2, v3, 0x6000

    .line 62
    .line 63
    move-object/from16 v53, p4

    .line 64
    .line 65
    if-nez v2, :cond_3

    .line 66
    .line 67
    move-object/from16 v2, v53

    .line 68
    .line 69
    invoke-static {v0, v2}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    or-int/2addr v1, v2

    .line 74
    :cond_3
    const/high16 v2, 0x30000

    .line 75
    .line 76
    and-int v2, v2, p10

    .line 77
    .line 78
    move/from16 v29, p5

    .line 79
    .line 80
    if-nez v2, :cond_4

    .line 81
    .line 82
    move/from16 v2, v29

    .line 83
    .line 84
    invoke-static {v0, v2}, LX/004;->A0n(LX/2d4;Z)I

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    or-int/2addr v1, v2

    .line 89
    :cond_4
    const/high16 v2, 0x180000

    .line 90
    .line 91
    and-int v2, v2, p10

    .line 92
    .line 93
    move/from16 v52, p6

    .line 94
    .line 95
    if-nez v2, :cond_5

    .line 96
    .line 97
    move/from16 v2, v52

    .line 98
    .line 99
    invoke-static {v0, v2}, LX/004;->A0o(LX/2d4;Z)I

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    or-int/2addr v1, v2

    .line 104
    :cond_5
    const/high16 v2, 0xc00000

    .line 105
    .line 106
    and-int v2, v2, p10

    .line 107
    .line 108
    move-object/from16 v8, p7

    .line 109
    .line 110
    if-nez v2, :cond_7

    .line 111
    .line 112
    const/high16 v2, 0x1000000

    .line 113
    .line 114
    invoke-static {v0, v8, v2, v3}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    .line 115
    .line 116
    .line 117
    move-result v4

    .line 118
    const/high16 v2, 0x400000

    .line 119
    .line 120
    if-eqz v4, :cond_6

    .line 121
    .line 122
    const/high16 v2, 0x800000

    .line 123
    .line 124
    :cond_6
    or-int/2addr v1, v2

    .line 125
    :cond_7
    const/high16 v2, 0x6000000

    .line 126
    .line 127
    and-int v2, v2, p10

    .line 128
    .line 129
    move-object/from16 v51, p8

    .line 130
    .line 131
    if-nez v2, :cond_8

    .line 132
    .line 133
    move-object/from16 v2, v51

    .line 134
    .line 135
    invoke-static {v0, v2}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 136
    .line 137
    .line 138
    move-result v2

    .line 139
    or-int/2addr v1, v2

    .line 140
    :cond_8
    const v2, 0x2492493

    .line 141
    .line 142
    .line 143
    and-int v4, v1, v2

    .line 144
    .line 145
    const v2, 0x2492492

    .line 146
    .line 147
    .line 148
    const/16 v28, 0x1

    .line 149
    .line 150
    const/4 v5, 0x0

    .line 151
    invoke-static {v4, v2}, LX/003;->A1H(II)Z

    .line 152
    .line 153
    .line 154
    move-result v2

    .line 155
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 156
    .line 157
    .line 158
    move-result v2

    .line 159
    if-eqz v2, :cond_a

    .line 160
    .line 161
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 162
    .line 163
    const/16 v27, 0x6

    .line 164
    .line 165
    move/from16 v2, v27

    .line 166
    .line 167
    invoke-virtual {v7, v0, v2}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 168
    .line 169
    .line 170
    move-result-object v26

    .line 171
    const v2, 0x7f1202b7

    .line 172
    .line 173
    .line 174
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v25

    .line 178
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 179
    .line 180
    const/4 v6, 0x0

    .line 181
    const/16 v36, 0x0

    .line 182
    .line 183
    invoke-static {v0}, LX/3J3;->A03(LX/2d4;)LX/3C1;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 188
    .line 189
    invoke-static {v2, v11, v6}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 190
    .line 191
    .line 192
    move-result-object v9

    .line 193
    add-float v2, v11, p1

    .line 194
    .line 195
    invoke-static {v9, v6, v6, v6, v2}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 196
    .line 197
    .line 198
    move-result-object v13

    .line 199
    sget-object v24, LX/2Id;->A00:LX/2sS;

    .line 200
    .line 201
    sget-object v23, LX/Dn6;->A06:LX/Dps;

    .line 202
    .line 203
    const/16 v10, 0x36

    .line 204
    .line 205
    move-object/from16 v9, v23

    .line 206
    .line 207
    move-object/from16 v2, v24

    .line 208
    .line 209
    invoke-static {v9, v0, v2, v10}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 210
    .line 211
    .line 212
    move-result-object v12

    .line 213
    move-object v2, v0

    .line 214
    check-cast v2, LX/J7I;

    .line 215
    .line 216
    iget-wide v9, v2, LX/J7I;->A06:J

    .line 217
    .line 218
    invoke-static {v9, v10}, LX/001;->A0A(J)I

    .line 219
    .line 220
    .line 221
    move-result v14

    .line 222
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 223
    .line 224
    .line 225
    move-result-object v10

    .line 226
    invoke-static {v0, v13}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 227
    .line 228
    .line 229
    move-result-object v9

    .line 230
    sget-object v22, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 231
    .line 232
    iget-object v13, v2, LX/J7I;->A0V:LX/3DJ;

    .line 233
    .line 234
    if-nez v13, :cond_b

    .line 235
    .line 236
    invoke-static {}, LX/1VY;->A00()V

    .line 237
    .line 238
    .line 239
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    throw v0

    .line 244
    :cond_9
    move v1, v3

    .line 245
    goto/16 :goto_0

    .line 246
    .line 247
    :cond_a
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 248
    .line 249
    .line 250
    goto/16 :goto_4

    .line 251
    .line 252
    :cond_b
    move-object/from16 v13, v22

    .line 253
    .line 254
    invoke-static {v0, v2, v13}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 255
    .line 256
    .line 257
    sget-object v21, LX/3Cl;->A04:LX/JDN;

    .line 258
    .line 259
    move-object/from16 v13, v21

    .line 260
    .line 261
    invoke-static {v0, v12, v13}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 262
    .line 263
    .line 264
    move-result-object v20

    .line 265
    move-object/from16 v12, v20

    .line 266
    .line 267
    invoke-static {v0, v10, v12, v14}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 268
    .line 269
    .line 270
    move-result-object v19

    .line 271
    sget-object v15, LX/3Cl;->A02:LX/JDM;

    .line 272
    .line 273
    invoke-static {v0, v9, v15}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 274
    .line 275
    .line 276
    move-result-object v18

    .line 277
    move/from16 v9, p0

    .line 278
    .line 279
    invoke-static {v0, v4, v9}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 280
    .line 281
    .line 282
    sget-object v17, LX/2sI;->A02:LX/2wD;

    .line 283
    .line 284
    const/16 v16, 0x30

    .line 285
    .line 286
    move/from16 v12, v16

    .line 287
    .line 288
    move-object/from16 v10, v23

    .line 289
    .line 290
    move-object/from16 v9, v24

    .line 291
    .line 292
    invoke-static {v10, v0, v9, v12}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 293
    .line 294
    .line 295
    move-result-object v14

    .line 296
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 297
    .line 298
    .line 299
    move-result v13

    .line 300
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 301
    .line 302
    .line 303
    move-result-object v12

    .line 304
    move-object/from16 v9, v17

    .line 305
    .line 306
    invoke-static {v0, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 307
    .line 308
    .line 309
    move-result-object v10

    .line 310
    move-object/from16 v9, v22

    .line 311
    .line 312
    invoke-static {v0, v2, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 313
    .line 314
    .line 315
    move-object/from16 v9, v21

    .line 316
    .line 317
    invoke-static {v0, v14, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 318
    .line 319
    .line 320
    move-object/from16 v9, v20

    .line 321
    .line 322
    invoke-static {v0, v12, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 323
    .line 324
    .line 325
    move-object/from16 v9, v19

    .line 326
    .line 327
    invoke-static {v15, v9, v0, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 328
    .line 329
    .line 330
    move-object/from16 v9, v18

    .line 331
    .line 332
    invoke-static {v0, v10, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 333
    .line 334
    .line 335
    const v9, 0x7f0801e0

    .line 336
    .line 337
    .line 338
    invoke-static {v0, v9, v5}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 339
    .line 340
    .line 341
    move-result-object v35

    .line 342
    const/high16 v9, 0x42500000    # 52.0f

    .line 343
    .line 344
    invoke-static {v4, v9}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 345
    .line 346
    .line 347
    move-result-object v33

    .line 348
    sget v9, LX/2l9;->$stable:I

    .line 349
    .line 350
    or-int/lit16 v9, v9, 0x1b0

    .line 351
    .line 352
    const/16 v40, 0x78

    .line 353
    .line 354
    move-object/from16 v31, v0

    .line 355
    .line 356
    move-object/from16 v32, v36

    .line 357
    .line 358
    move-object/from16 v34, v36

    .line 359
    .line 360
    move-object/from16 v37, v36

    .line 361
    .line 362
    move/from16 v38, v6

    .line 363
    .line 364
    move/from16 v39, v9

    .line 365
    .line 366
    invoke-static/range {v31 .. v40}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 367
    .line 368
    .line 369
    invoke-static {v0, v4, v11}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 370
    .line 371
    .line 372
    move-object/from16 v9, v51

    .line 373
    .line 374
    iget-object v9, v9, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->title:Ljava/lang/String;

    .line 375
    .line 376
    move-object/from16 v31, v9

    .line 377
    .line 378
    move/from16 v9, v27

    .line 379
    .line 380
    invoke-virtual {v7, v0, v9}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 381
    .line 382
    .line 383
    move-result-object v9

    .line 384
    iget-object v9, v9, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Emphasized:LX/2hg;

    .line 385
    .line 386
    move-object/from16 v35, v9

    .line 387
    .line 388
    move-object/from16 v9, v26

    .line 389
    .line 390
    iget-wide v10, v9, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 391
    .line 392
    const/4 v14, 0x3

    .line 393
    const v9, 0x3f3851ec    # 0.72f

    .line 394
    .line 395
    .line 396
    invoke-static {v4, v9}, LX/2sI;->A03(LX/3C1;F)LX/3C1;

    .line 397
    .line 398
    .line 399
    move-result-object v13

    .line 400
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 401
    .line 402
    .line 403
    move-result-object v12

    .line 404
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 405
    .line 406
    if-ne v12, v9, :cond_c

    .line 407
    .line 408
    sget-object v12, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$1$1$1;

    .line 409
    .line 410
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 411
    .line 412
    .line 413
    :cond_c
    invoke-static {v13, v12, v5}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 414
    .line 415
    .line 416
    move-result-object v32

    .line 417
    invoke-static {v14}, LX/2wS;->A01(I)LX/2wS;

    .line 418
    .line 419
    .line 420
    move-result-object v38

    .line 421
    const/16 v49, 0x3fb0

    .line 422
    .line 423
    move-wide/from16 v33, v10

    .line 424
    .line 425
    move/from16 v39, v5

    .line 426
    .line 427
    move/from16 v40, v5

    .line 428
    .line 429
    move/from16 v41, v5

    .line 430
    .line 431
    move/from16 v42, v5

    .line 432
    .line 433
    move-object/from16 v43, v36

    .line 434
    .line 435
    move-object/from16 v44, v36

    .line 436
    .line 437
    move-object/from16 v45, v36

    .line 438
    .line 439
    move-object/from16 v46, v0

    .line 440
    .line 441
    move/from16 v47, v5

    .line 442
    .line 443
    move/from16 v48, v5

    .line 444
    .line 445
    invoke-static/range {v31 .. v49}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 446
    .line 447
    .line 448
    invoke-static {v0, v4}, LX/1Vt;->A02(LX/2d4;LX/3C1;)V

    .line 449
    .line 450
    .line 451
    move-object/from16 v10, v51

    .line 452
    .line 453
    iget-object v12, v10, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->subtitle:Ljava/lang/String;

    .line 454
    .line 455
    invoke-static {v0, v7}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 456
    .line 457
    .line 458
    move-result-object v35

    .line 459
    move-object/from16 v10, v26

    .line 460
    .line 461
    iget-wide v10, v10, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 462
    .line 463
    invoke-static {v14}, LX/2wS;->A01(I)LX/2wS;

    .line 464
    .line 465
    .line 466
    move-result-object v38

    .line 467
    const/16 v49, 0x3fb2

    .line 468
    .line 469
    move-object/from16 v31, v12

    .line 470
    .line 471
    move-object/from16 v32, v36

    .line 472
    .line 473
    move-wide/from16 v33, v10

    .line 474
    .line 475
    invoke-static/range {v31 .. v49}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 476
    .line 477
    .line 478
    const/high16 v10, 0x41d00000    # 26.0f

    .line 479
    .line 480
    invoke-static {v0, v4, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 481
    .line 482
    .line 483
    invoke-static {v8}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 484
    .line 485
    .line 486
    move-result v39

    .line 487
    const/16 v40, 0x2

    .line 488
    .line 489
    xor-int/lit8 v44, p5, 0x1

    .line 490
    .line 491
    move-object/from16 v10, v51

    .line 492
    .line 493
    iget-object v13, v10, Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;->title:Ljava/lang/String;

    .line 494
    .line 495
    shr-int/lit8 v11, v1, 0x6

    .line 496
    .line 497
    and-int/lit8 v12, v11, 0xe

    .line 498
    .line 499
    const v10, 0x6c00180

    .line 500
    .line 501
    .line 502
    invoke-static {v12, v10, v11}, LX/3Rq;->A00(III)I

    .line 503
    .line 504
    .line 505
    move-result v48

    .line 506
    const/16 v50, 0x2638

    .line 507
    .line 508
    move-object/from16 v33, v55

    .line 509
    .line 510
    move-object/from16 v34, v54

    .line 511
    .line 512
    move/from16 v35, v27

    .line 513
    .line 514
    move/from16 v37, v6

    .line 515
    .line 516
    move/from16 v38, v5

    .line 517
    .line 518
    move/from16 v41, v28

    .line 519
    .line 520
    move/from16 v43, v5

    .line 521
    .line 522
    move-object/from16 v45, v13

    .line 523
    .line 524
    move-object/from16 v46, v36

    .line 525
    .line 526
    move-object/from16 v47, v0

    .line 527
    .line 528
    move/from16 v49, v5

    .line 529
    .line 530
    invoke-static/range {v33 .. v50}, Lcom/facebook/aura/vds/compose/input/AuraCodeInputKt;->AuraCodeInput-OOXMnFM(Ljava/lang/String;LX/JDM;ILX/3C1;FZZIIZZZLjava/lang/String;Ljava/lang/String;LX/2d4;III)V

    .line 531
    .line 532
    .line 533
    if-eqz p7, :cond_13

    .line 534
    .line 535
    const v10, -0x65060ec4

    .line 536
    .line 537
    .line 538
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 539
    .line 540
    .line 541
    instance-of v10, v8, Lcom/facebook/aura/activation/model/InviteCodeError$Invalid;

    .line 542
    .line 543
    if-eqz v10, :cond_12

    .line 544
    .line 545
    const v10, -0x6504a436

    .line 546
    .line 547
    .line 548
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 549
    .line 550
    .line 551
    move-object v10, v8

    .line 552
    check-cast v10, Lcom/facebook/aura/activation/model/InviteCodeError$Invalid;

    .line 553
    .line 554
    iget-object v10, v10, Lcom/facebook/aura/activation/model/InviteCodeError$Invalid;->serverMessage:Ljava/lang/String;

    .line 555
    .line 556
    if-nez v10, :cond_11

    .line 557
    .line 558
    const v10, 0x1dc610ab

    .line 559
    .line 560
    .line 561
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 562
    .line 563
    .line 564
    const v10, 0x7f1204b4

    .line 565
    .line 566
    .line 567
    invoke-static {v0, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 568
    .line 569
    .line 570
    move-result-object v10

    .line 571
    :goto_1
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 572
    .line 573
    .line 574
    :goto_2
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 575
    .line 576
    .line 577
    invoke-static {v0, v7}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 578
    .line 579
    .line 580
    move-result-object v35

    .line 581
    move-object/from16 v7, v26

    .line 582
    .line 583
    iget-wide v12, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->negativeAccent:J

    .line 584
    .line 585
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 586
    .line 587
    move-object/from16 v7, v17

    .line 588
    .line 589
    invoke-static {v7, v11, v11, v11, v6}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 590
    .line 591
    .line 592
    move-result-object v7

    .line 593
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 594
    .line 595
    .line 596
    move-result-object v6

    .line 597
    if-ne v6, v9, :cond_d

    .line 598
    .line 599
    sget-object v6, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$1$2$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$1$2$1;

    .line 600
    .line 601
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 602
    .line 603
    .line 604
    :cond_d
    invoke-static {v7, v6, v5}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 605
    .line 606
    .line 607
    move-result-object v32

    .line 608
    invoke-static {v14}, LX/2wS;->A01(I)LX/2wS;

    .line 609
    .line 610
    .line 611
    move-result-object v38

    .line 612
    const/16 v49, 0x3fb0

    .line 613
    .line 614
    move-object/from16 v31, v10

    .line 615
    .line 616
    move-wide/from16 v33, v12

    .line 617
    .line 618
    move-object/from16 v37, v36

    .line 619
    .line 620
    move/from16 v39, v5

    .line 621
    .line 622
    move/from16 v40, v5

    .line 623
    .line 624
    move/from16 v41, v5

    .line 625
    .line 626
    move-object/from16 v43, v36

    .line 627
    .line 628
    move-object/from16 v44, v36

    .line 629
    .line 630
    move-object/from16 v45, v36

    .line 631
    .line 632
    move-object/from16 v46, v0

    .line 633
    .line 634
    move/from16 v47, v5

    .line 635
    .line 636
    move/from16 v48, v5

    .line 637
    .line 638
    invoke-static/range {v31 .. v49}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 639
    .line 640
    .line 641
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 642
    .line 643
    .line 644
    :goto_3
    move/from16 v5, v28

    .line 645
    .line 646
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 647
    .line 648
    .line 649
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 650
    .line 651
    invoke-static {v0, v4, v5}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 652
    .line 653
    .line 654
    move/from16 v7, v16

    .line 655
    .line 656
    move-object/from16 v6, v23

    .line 657
    .line 658
    move-object/from16 v5, v24

    .line 659
    .line 660
    invoke-static {v6, v0, v5, v7}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 661
    .line 662
    .line 663
    move-result-object v10

    .line 664
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 665
    .line 666
    .line 667
    move-result v7

    .line 668
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 669
    .line 670
    .line 671
    move-result-object v6

    .line 672
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 673
    .line 674
    .line 675
    move-result-object v5

    .line 676
    move-object/from16 v4, v22

    .line 677
    .line 678
    invoke-static {v0, v2, v4}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 679
    .line 680
    .line 681
    move-object/from16 v4, v21

    .line 682
    .line 683
    invoke-static {v0, v10, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 684
    .line 685
    .line 686
    move-object/from16 v4, v20

    .line 687
    .line 688
    invoke-static {v0, v6, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 689
    .line 690
    .line 691
    move-object/from16 v4, v19

    .line 692
    .line 693
    invoke-static {v15, v4, v0, v7}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 694
    .line 695
    .line 696
    move-object/from16 v4, v18

    .line 697
    .line 698
    invoke-static {v0, v5, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 699
    .line 700
    .line 701
    move-object/from16 v4, v25

    .line 702
    .line 703
    invoke-interface {v0, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 704
    .line 705
    .line 706
    move-result v6

    .line 707
    const/high16 v4, 0x380000

    .line 708
    .line 709
    invoke-static {v1, v4}, LX/005;->A1P(II)Z

    .line 710
    .line 711
    .line 712
    move-result v4

    .line 713
    or-int/2addr v6, v4

    .line 714
    const/high16 v4, 0x70000

    .line 715
    .line 716
    and-int v5, v1, v4

    .line 717
    .line 718
    const/high16 v4, 0x20000

    .line 719
    .line 720
    invoke-static {v5, v4}, LX/003;->A1I(II)Z

    .line 721
    .line 722
    .line 723
    move-result v4

    .line 724
    or-int/2addr v6, v4

    .line 725
    invoke-static {v1}, LX/009;->A1M(I)Z

    .line 726
    .line 727
    .line 728
    move-result v1

    .line 729
    or-int/2addr v6, v1

    .line 730
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 731
    .line 732
    .line 733
    move-result-object v7

    .line 734
    if-nez v6, :cond_e

    .line 735
    .line 736
    if-ne v7, v9, :cond_f

    .line 737
    .line 738
    :cond_e
    new-instance v7, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$2$1$1;

    .line 739
    .line 740
    move-object/from16 v6, v25

    .line 741
    .line 742
    move/from16 v5, v52

    .line 743
    .line 744
    move/from16 v4, v29

    .line 745
    .line 746
    move-object/from16 v1, v53

    .line 747
    .line 748
    invoke-direct {v7, v6, v5, v4, v1}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$1$2$1$1;-><init>(Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;)V

    .line 749
    .line 750
    .line 751
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 752
    .line 753
    .line 754
    :cond_f
    check-cast v7, LX/JDM;

    .line 755
    .line 756
    const v19, 0xc00006

    .line 757
    .line 758
    .line 759
    const/16 v20, 0x7e

    .line 760
    .line 761
    move-object/from16 v9, v17

    .line 762
    .line 763
    move-object/from16 v10, v36

    .line 764
    .line 765
    move-object v11, v10

    .line 766
    move-object v12, v10

    .line 767
    move-object v13, v10

    .line 768
    move-object v14, v10

    .line 769
    move-object v15, v10

    .line 770
    move/from16 v16, v28

    .line 771
    .line 772
    move-object/from16 v17, v7

    .line 773
    .line 774
    move-object/from16 v18, v0

    .line 775
    .line 776
    invoke-static/range {v9 .. v20}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupsKt;->AuraButtonGroupStyleExplicit-FLdL6rA(LX/3C1;LX/2iK;LX/2wS;LX/JDM;LX/2iK;LX/2wS;Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupSize;ZLX/JDM;LX/2d4;II)V

    .line 777
    .line 778
    .line 779
    move/from16 v1, v28

    .line 780
    .line 781
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 782
    .line 783
    .line 784
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 785
    .line 786
    .line 787
    :goto_4
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 788
    .line 789
    .line 790
    move-result-object v1

    .line 791
    if-eqz v1, :cond_10

    .line 792
    .line 793
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;

    .line 794
    .line 795
    move-object v9, v0

    .line 796
    move/from16 v10, p0

    .line 797
    .line 798
    move/from16 v11, v30

    .line 799
    .line 800
    move-object/from16 v12, v55

    .line 801
    .line 802
    move-object/from16 v13, v54

    .line 803
    .line 804
    move-object/from16 v14, v53

    .line 805
    .line 806
    move/from16 v15, v29

    .line 807
    .line 808
    move/from16 v16, v52

    .line 809
    .line 810
    move-object/from16 v17, v8

    .line 811
    .line 812
    move-object/from16 v18, v51

    .line 813
    .line 814
    move/from16 v19, v3

    .line 815
    .line 816
    invoke-direct/range {v9 .. v19}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;-><init>(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;I)V

    .line 817
    .line 818
    .line 819
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 820
    .line 821
    :cond_10
    return-void

    .line 822
    :cond_11
    const v11, 0x1dc60b38

    .line 823
    .line 824
    .line 825
    invoke-interface {v0, v11}, LX/2d4;->Agj(I)V

    .line 826
    .line 827
    .line 828
    goto/16 :goto_1

    .line 829
    .line 830
    :cond_12
    sget-object v10, Lcom/facebook/aura/activation/model/InviteCodeError$Generic;->INSTANCE:Lcom/facebook/aura/activation/model/InviteCodeError$Generic;

    .line 831
    .line 832
    invoke-virtual {v8, v10}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 833
    .line 834
    .line 835
    move-result v10

    .line 836
    if-eqz v10, :cond_14

    .line 837
    .line 838
    const v10, 0x1dc61fab

    .line 839
    .line 840
    .line 841
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 842
    .line 843
    .line 844
    const v10, 0x7f1204b3

    .line 845
    .line 846
    .line 847
    invoke-static {v0, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 848
    .line 849
    .line 850
    move-result-object v10

    .line 851
    goto/16 :goto_2

    .line 852
    .line 853
    :cond_13
    const v6, -0x64fa756d

    .line 854
    .line 855
    .line 856
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 857
    .line 858
    .line 859
    invoke-static {v2, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 860
    .line 861
    .line 862
    goto/16 :goto_3

    .line 863
    .line 864
    :cond_14
    const v1, 0x1dc6026b

    .line 865
    .line 866
    .line 867
    invoke-static {v0, v2, v1}, LX/008;->A1D(LX/2d4;LX/J7I;I)Lkotlin/NoWhenBranchMatchedException;

    .line 868
    .line 869
    .line 870
    move-result-object v0

    .line 871
    throw v0
.end method

.method public static final synthetic access$InviteCodeContent-lVwrFTI(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p10}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->InviteCodeContent-lVwrFTI(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
