.class public final Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/header/view/HeaderButton;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/header/view/HeaderButton;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;->invoke(Lcom/facebook/aura/header/view/HeaderButton;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/header/view/HeaderButton;)V
    .locals 8

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/header/view/HeaderButton;->Settings:Lcom/facebook/aura/header/view/HeaderButton;

    .line 5
    .line 6
    if-ne p1, v0, :cond_0

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 9
    .line 10
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 11
    .line 12
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_CODE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 13
    .line 14
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->TAB_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    move-object v5, v2

    .line 18
    move-object v6, v2

    .line 19
    move-object v7, v2

    .line 20
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$4$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 24
    .line 25
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void
.end method
