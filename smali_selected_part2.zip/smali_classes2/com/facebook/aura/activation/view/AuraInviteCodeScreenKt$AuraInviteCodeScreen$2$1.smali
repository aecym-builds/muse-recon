.class public final Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $code:Ljava/lang/String;

.field public final synthetic $initialCode:Ljava/lang/String;

.field public final synthetic $onCodeChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$initialCode:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$code:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$onCodeChange:LX/JDM;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$initialCode:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-lez v0, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$code:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->$onCodeChange:LX/JDM;

    .line 17
    .line 18
    invoke-interface {v0, v1}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    sget-object p0, Lcom/facebook/aura/perf/HatchActivationQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchActivationQplLogger;

    .line 22
    .line 23
    const-string v1, "has_prefill_code"

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/perf/HatchActivationQplLogger;->annotateFlow(Ljava/lang/String;Z)V

    .line 27
    .line 28
    .line 29
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1$invoke$$inlined$onDispose$1;

    .line 30
    .line 31
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 32
    .line 33
    .line 34
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$2$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
