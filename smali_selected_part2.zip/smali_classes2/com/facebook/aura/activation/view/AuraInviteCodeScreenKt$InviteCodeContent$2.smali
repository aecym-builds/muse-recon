.class public final Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $bottomPadding:F

.field public final synthetic $code:Ljava/lang/String;

.field public final synthetic $enabled:Z

.field public final synthetic $error:Lcom/facebook/aura/activation/model/InviteCodeError;

.field public final synthetic $isLoading:Z

.field public final synthetic $onCodeChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onContinueClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

.field public final synthetic $topPadding:F


# direct methods
.method public constructor <init>(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FF",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;ZZ",
            "Lcom/facebook/aura/activation/model/InviteCodeError;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "I)V"
        }
    .end annotation

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$topPadding:F

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$bottomPadding:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$code:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$onCodeChange:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-boolean p6, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$isLoading:Z

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$enabled:Z

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 17
    .line 18
    iput p10, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$$changed:I

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 11

    .line 0
    iget v1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$topPadding:F

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$bottomPadding:F

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$code:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$onCodeChange:LX/JDM;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iget-boolean v6, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$isLoading:Z

    .line 11
    .line 12
    iget-boolean v7, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$enabled:Z

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 15
    .line 16
    iget-object v9, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 17
    .line 18
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$InviteCodeContent$2;->$$changed:I

    .line 19
    .line 20
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    move-object v10, p1

    .line 25
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->InviteCodeContent-lVwrFTI(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/2d4;I)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
