.class public final Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/subscription/api/GetMoreTokensTabContributor;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab;->INSTANCE:Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberTab$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method


# virtual methods
.method public rememberTab(LX/2d4;I)Lcom/facebook/aura/subscription/api/GetMoreTokensTab;
    .locals 5

    .line 0
    const v0, 0x355eb50d

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    sget-object v0, Lcom/facebook/aura/utils/HatchUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchUtils;

    .line 11
    .line 12
    invoke-virtual {v0, p0}, Lcom/facebook/aura/utils/HatchUtils;->isInviteFriendsAvailable(LX/AHE;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const/4 v4, 0x0

    .line 22
    return-object v4

    .line 23
    :cond_0
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 34
    .line 35
    if-ne v1, v0, :cond_2

    .line 36
    .line 37
    :cond_1
    sget-object v0, Lcom/facebook/aura/invite/api/InviteBadges;->INSTANCE:Lcom/facebook/aura/invite/api/InviteBadges;

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Lcom/facebook/aura/invite/api/InviteBadges;->hasUnseenInviteRedemptions(LX/AHE;)LX/2J3;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-interface {p1, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_2
    check-cast v1, LX/2J3;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    invoke-static {p1, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-static {v2}, LX/16A;->A0C(LX/16A;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-interface {p1, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-interface {p1, v0}, LX/2d4;->A6A(Z)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    or-int/2addr v0, v1

    .line 66
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    if-nez v0, :cond_3

    .line 71
    .line 72
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 73
    .line 74
    if-ne v4, v0, :cond_4

    .line 75
    .line 76
    :cond_3
    const v3, 0x7f1204c3

    .line 77
    .line 78
    .line 79
    invoke-static {v2}, LX/16A;->A0C(LX/16A;)Z

    .line 80
    .line 81
    .line 82
    move-result v2

    .line 83
    new-instance v1, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$1;

    .line 84
    .line 85
    invoke-direct {v1, p0}, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$1;-><init>(LX/AHE;)V

    .line 86
    .line 87
    .line 88
    sget-object v0, Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;->INSTANCE:Lcom/facebook/aura/activation/view/InviteGetMoreTokensTab$rememberTab$1$2;

    .line 89
    .line 90
    new-instance v4, Lcom/facebook/aura/subscription/api/GetMoreTokensTab;

    .line 91
    .line 92
    invoke-direct {v4, v3, v2, v1, v0}, Lcom/facebook/aura/subscription/api/GetMoreTokensTab;-><init>(IZLkotlin/jvm/functions/Function0;LX/JDN;)V

    .line 93
    .line 94
    .line 95
    invoke-interface {p1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_4
    check-cast v4, Lcom/facebook/aura/subscription/api/GetMoreTokensTab;

    .line 99
    .line 100
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    return-object v4
.end method
