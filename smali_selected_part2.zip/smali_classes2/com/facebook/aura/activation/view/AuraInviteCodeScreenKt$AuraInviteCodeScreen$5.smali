.class public final Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $code:Ljava/lang/String;

.field public final synthetic $error:Lcom/facebook/aura/activation/model/InviteCodeError;

.field public final synthetic $isLoading:Z

.field public final synthetic $onCodeChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onContinueClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lcom/facebook/aura/activation/model/InviteCodeError;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$code:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onCodeChange:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$isLoading:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 11
    .line 12
    const/4 v0, 0x4

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 13

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move v5, p1

    .line 3
    move-object/from16 p1, p3

    .line 4
    .line 5
    if-nez v0, :cond_4

    .line 6
    .line 7
    invoke-static {p1, v5}, LX/004;->A09(LX/2d4;F)I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    or-int v2, v2, p4

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 14
    .line 15
    move v6, p2

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {p1, p2}, LX/004;->A0A(LX/2d4;F)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    or-int/2addr v2, v0

    .line 23
    :cond_0
    and-int/lit16 v1, v2, 0x93

    .line 24
    .line 25
    const/16 v0, 0x92

    .line 26
    .line 27
    const/4 v11, 0x1

    .line 28
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {v0, p1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_5

    .line 37
    .line 38
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$code:Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {p1, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onCodeChange:LX/JDM;

    .line 45
    .line 46
    invoke-static {p1, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 51
    .line 52
    invoke-static {p1, v0, v1}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$code:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onCodeChange:LX/JDM;

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 61
    .line 62
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v8

    .line 66
    if-nez v0, :cond_1

    .line 67
    .line 68
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 69
    .line 70
    if-ne v8, v0, :cond_2

    .line 71
    .line 72
    :cond_1
    new-instance v8, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5$1$1;

    .line 73
    .line 74
    invoke-direct {v8, v4, v3, v1}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5$1$1;-><init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;)V

    .line 75
    .line 76
    .line 77
    invoke-interface {p1, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    :cond_2
    check-cast v8, LX/JDM;

    .line 81
    .line 82
    iget-object v9, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 83
    .line 84
    iget-boolean v10, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$isLoading:Z

    .line 85
    .line 86
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$code:Ljava/lang/String;

    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    const/4 v0, 0x6

    .line 93
    if-ge v1, v0, :cond_3

    .line 94
    .line 95
    const/4 v11, 0x0

    .line 96
    :cond_3
    iget-object v12, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 97
    .line 98
    iget-object p0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$5;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 99
    .line 100
    and-int/lit8 p2, v2, 0x7e

    .line 101
    .line 102
    invoke-static/range {v5 .. v15}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->InviteCodeContent-lVwrFTI(FFLjava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ZZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/2d4;I)V

    .line 103
    .line 104
    .line 105
    return-void

    .line 106
    :cond_4
    move/from16 v2, p4

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_5
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 110
    .line 111
    .line 112
    return-void
.end method
