.class public final Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$changed1:I

.field public final synthetic $$default:I

.field public final synthetic $code:Ljava/lang/String;

.field public final synthetic $error:Lcom/facebook/aura/activation/model/InviteCodeError;

.field public final synthetic $initialCode:Ljava/lang/String;

.field public final synthetic $isLoading:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onBackClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onCodeChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onContinueClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

.field public final synthetic $showBackButton:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;Ljava/lang/String;ZIII)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lcom/facebook/aura/activation/model/InviteCodeError;",
            "Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "ZIII)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$code:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onCodeChange:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onBackClick:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-boolean p6, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$isLoading:Z

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$modifier:LX/3C1;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$initialCode:Ljava/lang/String;

    .line 19
    .line 20
    iput-boolean p11, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$showBackButton:Z

    .line 21
    .line 22
    iput p12, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$changed:I

    .line 23
    .line 24
    iput p13, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$changed1:I

    .line 25
    .line 26
    iput p14, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$default:I

    .line 27
    .line 28
    const/4 v0, 0x2

    .line 29
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 15

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$code:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onCodeChange:LX/JDM;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onContinueClick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onBackClick:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iget-boolean v6, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$isLoading:Z

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$error:Lcom/facebook/aura/activation/model/InviteCodeError;

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$screenCopy:Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;

    .line 15
    .line 16
    iget-object v9, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$modifier:LX/3C1;

    .line 17
    .line 18
    iget-object v10, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$initialCode:Ljava/lang/String;

    .line 19
    .line 20
    iget-boolean v11, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$showBackButton:Z

    .line 21
    .line 22
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$changed:I

    .line 23
    .line 24
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 25
    .line 26
    .line 27
    move-result v13

    .line 28
    iget v0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$changed1:I

    .line 29
    .line 30
    invoke-static {v0}, LX/0z0;->A01(I)I

    .line 31
    .line 32
    .line 33
    move-result v14

    .line 34
    iget p0, p0, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt$AuraInviteCodeScreen$6;->$$default:I

    .line 35
    .line 36
    move-object/from16 v12, p1

    .line 37
    .line 38
    invoke-static/range {v1 .. v15}, Lcom/facebook/aura/activation/view/AuraInviteCodeScreenKt;->AuraInviteCodeScreen(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/activation/model/InviteCodeError;Lcom/facebook/aura/activation/data/HatchActivationWaitlistInviteCopy$Screen;LX/3C1;Ljava/lang/String;ZLX/2d4;III)V

    .line 39
    .line 40
    .line 41
    return-void
.end method
