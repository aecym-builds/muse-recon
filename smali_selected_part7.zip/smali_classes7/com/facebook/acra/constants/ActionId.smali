.class public Lcom/facebook/acra/constants/ActionId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ABORTED:S = 0x69s

.field public static final ACTION_BAR_COMPLETE:S = 0x68s

.field public static final ACTIVITY_CREATED:S = 0x7s

.field public static final ACTIVITY_LAUNCHED:S = 0x4as

.field public static final ACTIVITY_ON_CREATE:S = 0x50s

.field public static final ACTIVITY_PAUSED:S = 0x4bs

.field public static final ACTIVITY_RESUME:S = 0x8fs

.field public static final ACTIVITY_RESUMED:S = 0x4ds

.field public static final ACTIVITY_START:S = 0x90s

.field public static final ACTIVITY_STARTED:S = 0x4cs

.field public static final ANIMATION_END:S = 0x5ds

.field public static final APPLY_FINISHED_LIST:S = 0x99s

.field public static final APPLY_FINISHED_LIST_AGAIN:S = 0x9as

.field public static final APPLY_OPTIMISTICS:S = 0x98s

.field public static final APP_DID_BECOME_ACTIVE:S = 0x83s

.field public static final APP_DID_ENTER_BACKGROUND:S = 0x85s

.field public static final APP_DID_FINISH_LAUNCHING:S = 0x82s

.field public static final APP_FIRST_VIEW_CONTROLLER:S = 0x8bs

.field public static final APP_MAIN:S = 0x86s

.field public static final APP_WILL_ENTER_FOREGROUND:S = 0x84s

.field public static final ASNYC_FAILED:S = 0xa1s

.field public static final ASYNC_ACTION_FAIL:S = 0xa8s

.field public static final ASYNC_ACTION_SUCCESS:S = 0xa7s

.field public static final ASYNC_BEGIN:S = 0x25s

.field public static final ASYNC_END:S = 0x26s

.field public static final ASYNC_FAIL:S = 0xa2s

.field public static final BEGIN_START_ACTIVITY:S = 0x91s

.field public static final BROADCAST_DONE:S = 0x29s

.field public static final CACHE_FETCH:S = 0x22s

.field public static final CACHE_UPDATED:S = 0x1ds

.field public static final CANCEL:S = 0x4s

.field public static final CARD_DATA_LOADED:S = 0x7as

.field public static final COMPONENTS_DATA_SOURCE_DID_END_UPDATES:S = 0x7es

.field public static final COMPONENTS_DATA_SOURCE_WILL_BEGIN_UPDATES:S = 0x7ds

.field public static final CONNECTIVITY_CHANGED:S = 0xa9s

.field public static final CONSISTENCY_MODEL_UPDATER:S = 0x8s

.field public static final CONSISTENCY_UPDATE:S = 0x13s

.field public static final CONTROLLER_INITIATED:S = 0x72s

.field public static final COUNTER:S = 0x3ds

.field public static final DATA_EMPTY:S = 0x21s

.field public static final DATA_LOAD_START:S = 0x66s

.field public static final DATA_RECEIVED:S = 0x1fs

.field public static final DB_FETCH:S = 0x17s

.field public static final DB_UPDATED:S = 0x1es

.field public static final DEQUEUE:S = 0xfs

.field public static final DISK_CACHE_VISIT:S = 0x12s

.field public static final DISPLAYED:S = 0xa5s

.field public static final DISPLAYED_ON_SCREEN:S = 0xa6s

.field public static final DRAW_COMPLETE:S = 0x5s

.field public static final DRAW_VIEW:S = 0x20s

.field public static final EDGE_PROCESSING_BEGIN:S = 0x63s

.field public static final END_START_ACTIVITY:S = 0x92s

.field public static final ERROR:S = 0x57s

.field public static final FAIL:S = 0x3s

.field public static final FAIL_FILE_TOO_LARGE:S = 0x9fs

.field public static final FILE_SYSTEM_FAIL:S = 0x93s

.field public static final FINALLY:S = 0x59s

.field public static final FORMAT_ERROR:S = 0x94s

.field public static final FRAGMENT_CREATED:S = 0x4es

.field public static final FRAGMENT_INSTANCE_CREATED:S = 0x55s

.field public static final FRAGMENT_NEW_INSTANCE:S = 0x53s

.field public static final FRAGMENT_ON_CREATE:S = 0x52s

.field public static final FRAGMENT_RESUMED:S = 0x4fs

.field public static final FUTURE_LISTENERS_COMPLETE:S = 0x9bs

.field public static final HEADER_DATA_LOADED:S = 0x79s

.field public static final INIT:S = 0x32s

.field public static final INTENT_MAPPED:S = 0x49s

.field public static final INTENT_MAPPING_BEGIN:S = 0x51s

.field public static final INTERACTION_LOAD_EVENT_PERMALINK:S = 0x3fs

.field public static final INTERACTION_LOAD_GROUPS_FEED:S = 0x40s

.field public static final INTERACTION_LOAD_PAGE_HEADER:S = 0x41s

.field public static final INTERACTION_LOAD_PAGE_HEADER_ADMIN:S = 0x42s

.field public static final INTERACTION_LOAD_PERMALINK:S = 0x43s

.field public static final INTERACTION_LOAD_TIMELINE_HEADER:S = 0x3es

.field public static final INTERACTION_LOAD_WEB_VIEW:S = 0x48s

.field public static final INTERACTION_OPEN_CHECK_IN:S = 0x47s

.field public static final INTERACTION_OPEN_COMPOSER:S = 0x44s

.field public static final INTERACTION_OPEN_MEDIA_PICKER:S = 0x45s

.field public static final INTERACTION_OPEN_PHOTO_GALLERY:S = 0x46s

.field public static final INTERRUPTED:S = 0x60s

.field public static final IN_PROGRESS:S = 0x31s

.field public static final LEGACY_MARKER:S = 0x67s

.field public static final LOAD_VIEW_BEGIN:S = 0x7fs

.field public static final MAIN_COMPLETE:S = 0x5fs

.field public static final MARKER_SWAPPED:S = 0x54s

.field public static final MEDIA_PREVIEW_VISIBLE:S = 0x3cs

.field public static final MEMORY_CACHE_VISIT:S = 0x11s

.field public static final MESSAGE_UPDATE_END:S = 0x3as

.field public static final MESSAGE_UPDATE_START:S = 0x39s

.field public static final MESSENGER_DELTA_REQUEST:S = 0x8as

.field public static final MESSENGER_QUEUE_CREATION:S = 0x81s

.field public static final MESSENGER_THREAD_LIST_DISPLAYED:S = 0x8ds

.field public static final MESSENGER_THREAD_LIST_LOADED:S = 0x8cs

.field public static final METHOD_INVOKE:S = 0x58s

.field public static final MINIPREVIEW_COMPLETE:S = 0x5bs

.field public static final MISSED_EVENT:S = 0x70s

.field public static final MQTT_CONNECTED:S = 0x88s

.field public static final MQTT_CONNECTING:S = 0x87s

.field public static final MQTT_DISCONNECTED:S = 0x89s

.field public static final NETWORK_COMPLETE:S = 0x10s

.field public static final NETWORK_FAILED:S = 0x61s

.field public static final NETWORK_RESPONSE:S = 0x62s

.field public static final NETWORK_RESPONSE_INITIAL_SCAN:S = 0x96s

.field public static final NEWSFEED_PROCESS_RESPONSE:S = 0x64s

.field public static final NEW_START_FOUND:S = 0x6fs

.field public static final NOTIFY_SUBSCRIBERS:S = 0x9es

.field public static final OFFLINE:S = 0xa0s

.field public static final ON_ACTIVITY_CREATED_END:S = 0x2es

.field public static final ON_ATTACH_END:S = 0x2bs

.field public static final ON_ATTACH_FRAGMENT:S = 0xa3s

.field public static final ON_CREATE_VIEW_END:S = 0x2ds

.field public static final ON_FRAGMENT_CREATE_END:S = 0x2cs

.field public static final ON_RESUME:S = 0x6s

.field public static final ON_RESUME_END:S = 0x2as

.field public static final ON_START_END:S = 0x2fs

.field public static final ON_VIEW_CREATED_END:S = 0x65s

.field public static final PHASE_ONE:S = 0xds

.field public static final PHASE_TWO:S = 0xes

.field public static final PHOTO_CAPTURED:S = 0x3bs

.field public static final PHOTO_DOWNLOAD_COMPLETE:S = 0x5as

.field public static final PHOTO_UPLOAD_COMPLETE:S = 0x15s

.field public static final POPULATE_CONSISTENCY_MEMORY_CACHE:S = 0x97s

.field public static final PREPARE_BEGIN:S = 0x23s

.field public static final PREPARE_END:S = 0x24s

.field public static final PREV_ACTIVITY_PAUSE:S = 0x8es

.field public static final PREV_ACTIVITY_PAUSED:S = 0x56s

.field public static final PRIVACY_VIOLATION:S = 0x95s

.field public static final QUERY_READY:S = 0x6as

.field public static final QUEUED:S = 0x30s

.field public static final QUEUEING_BEGIN:S = 0x36s

.field public static final QUEUEING_FAIL:S = 0x38s

.field public static final QUEUEING_SUCCESS:S = 0x37s

.field public static final REMOVE_BEGIN:S = 0x27s

.field public static final REMOVE_END:S = 0x28s

.field public static final REQUESTED_PLAYING:S = 0x6cs

.field public static final RETRY_AFTER_FAILURE:S = 0x34s

.field public static final RETRY_AFTER_RECONNECT:S = 0x35s

.field public static final RETURN_TO_CALLER:S = 0x14s

.field public static final RTMP_CONNECTION_CONNECTED:S = 0x75s

.field public static final RTMP_CONNECTION_FAILED:S = 0x76s

.field public static final RTMP_CONNECTION_INTERCEPTED:S = 0x77s

.field public static final RTMP_CONNECTION_RELEASE:S = 0x6es

.field public static final RTMP_CONNECTION_REQUESTED:S = 0x6ds

.field public static final RTMP_FIRST_KEY_FRAME_RECEIVED:S = 0x80s

.field public static final RTMP_PACKET_RECEIVED:S = 0x6bs

.field public static final RTMP_STREAM_PREPARED:S = 0x73s

.field public static final SEARCH_TYPEAHEAD:S = 0x5cs

.field public static final SEND_MESSAGE:S = 0x9s

.field public static final SERVER_FETCH:S = 0x18s

.field public static final SERVICE_ON_START_COMMAND:S = 0x9cs

.field public static final START:S = 0x1s

.field public static final SUCCESS:S = 0x2s

.field public static final SUCCESS_CACHE:S = 0x19s

.field public static final SUCCESS_COLD:S = 0xas

.field public static final SUCCESS_DB:S = 0x1as

.field public static final SUCCESS_LOCAL_UNSPECIFIED:S = 0x1cs

.field public static final SUCCESS_NETWORK:S = 0x1bs

.field public static final SUCCESS_WARM:S = 0xbs

.field public static final TIMEOUT:S = 0x71s

.field public static final UDP_REQUEST_SEND:S = 0x5es

.field public static final UI_IDLE:S = 0xcs

.field public static final UNKNOWN:S = 0x33s

.field public static final USER_NAVIGATION_CANCELLATION:S = 0x16s

.field public static final VIDEO_DISPLAYED:S = 0xaas

.field public static final VIDEO_PLAYING:S = 0x74s

.field public static final VIDEO_REQUESTED_PLAYING:S = 0xabs

.field public static final VIDEO_SET_RENDERER_CONTEXT:S = 0x78s

.field public static final VIEW_DID_APPEAR_BEGIN:S = 0xa4s

.field public static final VIEW_DID_LOAD_BEGIN:S = 0x7cs

.field public static final VIEW_WILL_APPEAR_BEGIN:S = 0x7bs

.field public static final WAIT_FOR_BLOCKERS:S = 0x9ds


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getActionName(I)Ljava/lang/String;
    .locals 0

    .line 0
    packed-switch p0, :pswitch_data_0

    .line 1
    .line 2
    .line 3
    const-string p0, "UNDEFINED_QPL_ACTION"

    .line 4
    .line 5
    return-object p0

    .line 6
    :pswitch_0
    const-string p0, "VIDEO_REQUESTED_PLAYING"

    .line 7
    .line 8
    return-object p0

    .line 9
    :pswitch_1
    const-string p0, "VIDEO_DISPLAYED"

    .line 10
    .line 11
    return-object p0

    .line 12
    :pswitch_2
    const-string p0, "CONNECTIVITY_CHANGED"

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_3
    const-string p0, "ASYNC_ACTION_FAIL"

    .line 16
    .line 17
    return-object p0

    .line 18
    :pswitch_4
    const-string p0, "ASYNC_ACTION_SUCCESS"

    .line 19
    .line 20
    return-object p0

    .line 21
    :pswitch_5
    const-string p0, "DISPLAYED_ON_SCREEN"

    .line 22
    .line 23
    return-object p0

    .line 24
    :pswitch_6
    const-string p0, "DISPLAYED"

    .line 25
    .line 26
    return-object p0

    .line 27
    :pswitch_7
    const-string p0, "VIEW_DID_APPEAR_BEGIN"

    .line 28
    .line 29
    return-object p0

    .line 30
    :pswitch_8
    const-string p0, "ON_ATTACH_FRAGMENT"

    .line 31
    .line 32
    return-object p0

    .line 33
    :pswitch_9
    const-string p0, "ASYNC_FAIL"

    .line 34
    .line 35
    return-object p0

    .line 36
    :pswitch_a
    const-string p0, "ASNYC_FAILED"

    .line 37
    .line 38
    return-object p0

    .line 39
    :pswitch_b
    const-string p0, "OFFLINE"

    .line 40
    .line 41
    return-object p0

    .line 42
    :pswitch_c
    const-string p0, "FAIL_FILE_TOO_LARGE"

    .line 43
    .line 44
    return-object p0

    .line 45
    :pswitch_d
    const-string p0, "NOTIFY_SUBSCRIBERS"

    .line 46
    .line 47
    return-object p0

    .line 48
    :pswitch_e
    const-string p0, "WAIT_FOR_BLOCKERS"

    .line 49
    .line 50
    return-object p0

    .line 51
    :pswitch_f
    const-string p0, "SERVICE_ON_START_COMMAND"

    .line 52
    .line 53
    return-object p0

    .line 54
    :pswitch_10
    const-string p0, "FUTURE_LISTENERS_COMPLETE"

    .line 55
    .line 56
    return-object p0

    .line 57
    :pswitch_11
    const-string p0, "APPLY_FINISHED_LIST_AGAIN"

    .line 58
    .line 59
    return-object p0

    .line 60
    :pswitch_12
    const-string p0, "APPLY_FINISHED_LIST"

    .line 61
    .line 62
    return-object p0

    .line 63
    :pswitch_13
    const-string p0, "APPLY_OPTIMISTICS"

    .line 64
    .line 65
    return-object p0

    .line 66
    :pswitch_14
    const-string p0, "POPULATE_CONSISTENCY_MEMORY_CACHE"

    .line 67
    .line 68
    return-object p0

    .line 69
    :pswitch_15
    const-string p0, "NETWORK_RESPONSE_INITIAL_SCAN"

    .line 70
    .line 71
    return-object p0

    .line 72
    :pswitch_16
    const-string p0, "PRIVACY_VIOLATION"

    .line 73
    .line 74
    return-object p0

    .line 75
    :pswitch_17
    const-string p0, "FORMAT_ERROR"

    .line 76
    .line 77
    return-object p0

    .line 78
    :pswitch_18
    const-string p0, "FILE_SYSTEM_FAIL"

    .line 79
    .line 80
    return-object p0

    .line 81
    :pswitch_19
    const-string p0, "END_START_ACTIVITY"

    .line 82
    .line 83
    return-object p0

    .line 84
    :pswitch_1a
    const-string p0, "BEGIN_START_ACTIVITY"

    .line 85
    .line 86
    return-object p0

    .line 87
    :pswitch_1b
    const-string p0, "ACTIVITY_START"

    .line 88
    .line 89
    return-object p0

    .line 90
    :pswitch_1c
    const-string p0, "ACTIVITY_RESUME"

    .line 91
    .line 92
    return-object p0

    .line 93
    :pswitch_1d
    const-string p0, "PREV_ACTIVITY_PAUSE"

    .line 94
    .line 95
    return-object p0

    .line 96
    :pswitch_1e
    const-string p0, "MESSENGER_THREAD_LIST_DISPLAYED"

    .line 97
    .line 98
    return-object p0

    .line 99
    :pswitch_1f
    const-string p0, "MESSENGER_THREAD_LIST_LOADED"

    .line 100
    .line 101
    return-object p0

    .line 102
    :pswitch_20
    const-string p0, "APP_FIRST_VIEW_CONTROLLER"

    .line 103
    .line 104
    return-object p0

    .line 105
    :pswitch_21
    const-string p0, "MESSENGER_DELTA_REQUEST"

    .line 106
    .line 107
    return-object p0

    .line 108
    :pswitch_22
    const-string p0, "MQTT_DISCONNECTED"

    .line 109
    .line 110
    return-object p0

    .line 111
    :pswitch_23
    const-string p0, "MQTT_CONNECTED"

    .line 112
    .line 113
    return-object p0

    .line 114
    :pswitch_24
    const-string p0, "MQTT_CONNECTING"

    .line 115
    .line 116
    return-object p0

    .line 117
    :pswitch_25
    const-string p0, "APP_MAIN"

    .line 118
    .line 119
    return-object p0

    .line 120
    :pswitch_26
    const-string p0, "APP_DID_ENTER_BACKGROUND"

    .line 121
    .line 122
    return-object p0

    .line 123
    :pswitch_27
    const-string p0, "APP_WILL_ENTER_FOREGROUND"

    .line 124
    .line 125
    return-object p0

    .line 126
    :pswitch_28
    const-string p0, "APP_DID_BECOME_ACTIVE"

    .line 127
    .line 128
    return-object p0

    .line 129
    :pswitch_29
    const-string p0, "APP_DID_FINISH_LAUNCHING"

    .line 130
    .line 131
    return-object p0

    .line 132
    :pswitch_2a
    const-string p0, "MESSENGER_QUEUE_CREATION"

    .line 133
    .line 134
    return-object p0

    .line 135
    :pswitch_2b
    const-string p0, "RTMP_FIRST_KEY_FRAME_RECEIVED"

    .line 136
    .line 137
    return-object p0

    .line 138
    :pswitch_2c
    const-string p0, "LOAD_VIEW_BEGIN"

    .line 139
    .line 140
    return-object p0

    .line 141
    :pswitch_2d
    const-string p0, "COMPONENTS_DATA_SOURCE_DID_END_UPDATES"

    .line 142
    .line 143
    return-object p0

    .line 144
    :pswitch_2e
    const-string p0, "COMPONENTS_DATA_SOURCE_WILL_BEGIN_UPDATES"

    .line 145
    .line 146
    return-object p0

    .line 147
    :pswitch_2f
    const-string p0, "VIEW_DID_LOAD_BEGIN"

    .line 148
    .line 149
    return-object p0

    .line 150
    :pswitch_30
    const-string p0, "VIEW_WILL_APPEAR_BEGIN"

    .line 151
    .line 152
    return-object p0

    .line 153
    :pswitch_31
    const-string p0, "CARD_DATA_LOADED"

    .line 154
    .line 155
    return-object p0

    .line 156
    :pswitch_32
    const-string p0, "HEADER_DATA_LOADED"

    .line 157
    .line 158
    return-object p0

    .line 159
    :pswitch_33
    const-string p0, "VIDEO_SET_RENDERER_CONTEXT"

    .line 160
    .line 161
    return-object p0

    .line 162
    :pswitch_34
    const-string p0, "RTMP_CONNECTION_INTERCEPTED"

    .line 163
    .line 164
    return-object p0

    .line 165
    :pswitch_35
    const-string p0, "RTMP_CONNECTION_FAILED"

    .line 166
    .line 167
    return-object p0

    .line 168
    :pswitch_36
    const-string p0, "RTMP_CONNECTION_CONNECTED"

    .line 169
    .line 170
    return-object p0

    .line 171
    :pswitch_37
    const-string p0, "VIDEO_PLAYING"

    .line 172
    .line 173
    return-object p0

    .line 174
    :pswitch_38
    const-string p0, "RTMP_STREAM_PREPARED"

    .line 175
    .line 176
    return-object p0

    .line 177
    :pswitch_39
    const-string p0, "CONTROLLER_INITIATED"

    .line 178
    .line 179
    return-object p0

    .line 180
    :pswitch_3a
    const-string p0, "TIMEOUT"

    .line 181
    .line 182
    return-object p0

    .line 183
    :pswitch_3b
    const-string p0, "MISSED_EVENT"

    .line 184
    .line 185
    return-object p0

    .line 186
    :pswitch_3c
    const-string p0, "NEW_START_FOUND"

    .line 187
    .line 188
    return-object p0

    .line 189
    :pswitch_3d
    const-string p0, "RTMP_CONNECTION_RELEASE"

    .line 190
    .line 191
    return-object p0

    .line 192
    :pswitch_3e
    const-string p0, "RTMP_CONNECTION_REQUESTED"

    .line 193
    .line 194
    return-object p0

    .line 195
    :pswitch_3f
    const-string p0, "REQUESTED_PLAYING"

    .line 196
    .line 197
    return-object p0

    .line 198
    :pswitch_40
    const-string p0, "RTMP_PACKET_RECEIVED"

    .line 199
    .line 200
    return-object p0

    .line 201
    :pswitch_41
    const-string p0, "QUERY_READY"

    .line 202
    .line 203
    return-object p0

    .line 204
    :pswitch_42
    const-string p0, "ABORTED"

    .line 205
    .line 206
    return-object p0

    .line 207
    :pswitch_43
    const-string p0, "ACTION_BAR_COMPLETE"

    .line 208
    .line 209
    return-object p0

    .line 210
    :pswitch_44
    const-string p0, "LEGACY_MARKER"

    .line 211
    .line 212
    return-object p0

    .line 213
    :pswitch_45
    const-string p0, "DATA_LOAD_START"

    .line 214
    .line 215
    return-object p0

    .line 216
    :pswitch_46
    const-string p0, "ON_VIEW_CREATED_END"

    .line 217
    .line 218
    return-object p0

    .line 219
    :pswitch_47
    const-string p0, "NEWSFEED_PROCESS_RESPONSE"

    .line 220
    .line 221
    return-object p0

    .line 222
    :pswitch_48
    const-string p0, "EDGE_PROCESSING_BEGIN"

    .line 223
    .line 224
    return-object p0

    .line 225
    :pswitch_49
    const-string p0, "NETWORK_RESPONSE"

    .line 226
    .line 227
    return-object p0

    .line 228
    :pswitch_4a
    const-string p0, "NETWORK_FAILED"

    .line 229
    .line 230
    return-object p0

    .line 231
    :pswitch_4b
    const-string p0, "INTERRUPTED"

    .line 232
    .line 233
    return-object p0

    .line 234
    :pswitch_4c
    const-string p0, "MAIN_COMPLETE"

    .line 235
    .line 236
    return-object p0

    .line 237
    :pswitch_4d
    const-string p0, "UDP_REQUEST_SEND"

    .line 238
    .line 239
    return-object p0

    .line 240
    :pswitch_4e
    const-string p0, "ANIMATION_END"

    .line 241
    .line 242
    return-object p0

    .line 243
    :pswitch_4f
    const-string p0, "SEARCH_TYPEAHEAD"

    .line 244
    .line 245
    return-object p0

    .line 246
    :pswitch_50
    const-string p0, "MINIPREVIEW_COMPLETE"

    .line 247
    .line 248
    return-object p0

    .line 249
    :pswitch_51
    const-string p0, "PHOTO_DOWNLOAD_COMPLETE"

    .line 250
    .line 251
    return-object p0

    .line 252
    :pswitch_52
    const-string p0, "FINALLY"

    .line 253
    .line 254
    return-object p0

    .line 255
    :pswitch_53
    const-string p0, "METHOD_INVOKE"

    .line 256
    .line 257
    return-object p0

    .line 258
    :pswitch_54
    const-string p0, "ERROR"

    .line 259
    .line 260
    return-object p0

    .line 261
    :pswitch_55
    const-string p0, "PREV_ACTIVITY_PAUSED"

    .line 262
    .line 263
    return-object p0

    .line 264
    :pswitch_56
    const-string p0, "FRAGMENT_INSTANCE_CREATED"

    .line 265
    .line 266
    return-object p0

    .line 267
    :pswitch_57
    const-string p0, "MARKER_SWAPPED"

    .line 268
    .line 269
    return-object p0

    .line 270
    :pswitch_58
    const-string p0, "FRAGMENT_NEW_INSTANCE"

    .line 271
    .line 272
    return-object p0

    .line 273
    :pswitch_59
    const-string p0, "FRAGMENT_ON_CREATE"

    .line 274
    .line 275
    return-object p0

    .line 276
    :pswitch_5a
    const-string p0, "INTENT_MAPPING_BEGIN"

    .line 277
    .line 278
    return-object p0

    .line 279
    :pswitch_5b
    const-string p0, "ACTIVITY_ON_CREATE"

    .line 280
    .line 281
    return-object p0

    .line 282
    :pswitch_5c
    const-string p0, "FRAGMENT_RESUMED"

    .line 283
    .line 284
    return-object p0

    .line 285
    :pswitch_5d
    const-string p0, "FRAGMENT_CREATED"

    .line 286
    .line 287
    return-object p0

    .line 288
    :pswitch_5e
    const-string p0, "ACTIVITY_RESUMED"

    .line 289
    .line 290
    return-object p0

    .line 291
    :pswitch_5f
    const-string p0, "ACTIVITY_STARTED"

    .line 292
    .line 293
    return-object p0

    .line 294
    :pswitch_60
    const-string p0, "ACTIVITY_PAUSED"

    .line 295
    .line 296
    return-object p0

    .line 297
    :pswitch_61
    const-string p0, "ACTIVITY_LAUNCHED"

    .line 298
    .line 299
    return-object p0

    .line 300
    :pswitch_62
    const-string p0, "INTENT_MAPPED"

    .line 301
    .line 302
    return-object p0

    .line 303
    :pswitch_63
    const-string p0, "INTERACTION_LOAD_WEB_VIEW"

    .line 304
    .line 305
    return-object p0

    .line 306
    :pswitch_64
    const-string p0, "INTERACTION_OPEN_CHECK_IN"

    .line 307
    .line 308
    return-object p0

    .line 309
    :pswitch_65
    const-string p0, "INTERACTION_OPEN_PHOTO_GALLERY"

    .line 310
    .line 311
    return-object p0

    .line 312
    :pswitch_66
    const-string p0, "INTERACTION_OPEN_MEDIA_PICKER"

    .line 313
    .line 314
    return-object p0

    .line 315
    :pswitch_67
    const-string p0, "INTERACTION_OPEN_COMPOSER"

    .line 316
    .line 317
    return-object p0

    .line 318
    :pswitch_68
    const-string p0, "INTERACTION_LOAD_PERMALINK"

    .line 319
    .line 320
    return-object p0

    .line 321
    :pswitch_69
    const-string p0, "INTERACTION_LOAD_PAGE_HEADER_ADMIN"

    .line 322
    .line 323
    return-object p0

    .line 324
    :pswitch_6a
    const-string p0, "INTERACTION_LOAD_PAGE_HEADER"

    .line 325
    .line 326
    return-object p0

    .line 327
    :pswitch_6b
    const-string p0, "INTERACTION_LOAD_GROUPS_FEED"

    .line 328
    .line 329
    return-object p0

    .line 330
    :pswitch_6c
    const-string p0, "INTERACTION_LOAD_EVENT_PERMALINK"

    .line 331
    .line 332
    return-object p0

    .line 333
    :pswitch_6d
    const-string p0, "INTERACTION_LOAD_TIMELINE_HEADER"

    .line 334
    .line 335
    return-object p0

    .line 336
    :pswitch_6e
    const-string p0, "COUNTER"

    .line 337
    .line 338
    return-object p0

    .line 339
    :pswitch_6f
    const-string p0, "MEDIA_PREVIEW_VISIBLE"

    .line 340
    .line 341
    return-object p0

    .line 342
    :pswitch_70
    const-string p0, "PHOTO_CAPTURED"

    .line 343
    .line 344
    return-object p0

    .line 345
    :pswitch_71
    const-string p0, "MESSAGE_UPDATE_END"

    .line 346
    .line 347
    return-object p0

    .line 348
    :pswitch_72
    const-string p0, "MESSAGE_UPDATE_START"

    .line 349
    .line 350
    return-object p0

    .line 351
    :pswitch_73
    const-string p0, "QUEUEING_FAIL"

    .line 352
    .line 353
    return-object p0

    .line 354
    :pswitch_74
    const-string p0, "QUEUEING_SUCCESS"

    .line 355
    .line 356
    return-object p0

    .line 357
    :pswitch_75
    const-string p0, "QUEUEING_BEGIN"

    .line 358
    .line 359
    return-object p0

    .line 360
    :pswitch_76
    const-string p0, "RETRY_AFTER_RECONNECT"

    .line 361
    .line 362
    return-object p0

    .line 363
    :pswitch_77
    const-string p0, "RETRY_AFTER_FAILURE"

    .line 364
    .line 365
    return-object p0

    .line 366
    :pswitch_78
    const-string p0, "UNKNOWN"

    .line 367
    .line 368
    return-object p0

    .line 369
    :pswitch_79
    const-string p0, "INIT"

    .line 370
    .line 371
    return-object p0

    .line 372
    :pswitch_7a
    const-string p0, "IN_PROGRESS"

    .line 373
    .line 374
    return-object p0

    .line 375
    :pswitch_7b
    const-string p0, "QUEUED"

    .line 376
    .line 377
    return-object p0

    .line 378
    :pswitch_7c
    const-string p0, "ON_START_END"

    .line 379
    .line 380
    return-object p0

    .line 381
    :pswitch_7d
    const-string p0, "ON_ACTIVITY_CREATED_END"

    .line 382
    .line 383
    return-object p0

    .line 384
    :pswitch_7e
    const-string p0, "ON_CREATE_VIEW_END"

    .line 385
    .line 386
    return-object p0

    .line 387
    :pswitch_7f
    const-string p0, "ON_FRAGMENT_CREATE_END"

    .line 388
    .line 389
    return-object p0

    .line 390
    :pswitch_80
    const-string p0, "ON_ATTACH_END"

    .line 391
    .line 392
    return-object p0

    .line 393
    :pswitch_81
    const-string p0, "ON_RESUME_END"

    .line 394
    .line 395
    return-object p0

    .line 396
    :pswitch_82
    const-string p0, "BROADCAST_DONE"

    .line 397
    .line 398
    return-object p0

    .line 399
    :pswitch_83
    const-string p0, "REMOVE_END"

    .line 400
    .line 401
    return-object p0

    .line 402
    :pswitch_84
    const-string p0, "REMOVE_BEGIN"

    .line 403
    .line 404
    return-object p0

    .line 405
    :pswitch_85
    const-string p0, "ASYNC_END"

    .line 406
    .line 407
    return-object p0

    .line 408
    :pswitch_86
    const-string p0, "ASYNC_BEGIN"

    .line 409
    .line 410
    return-object p0

    .line 411
    :pswitch_87
    const-string p0, "PREPARE_END"

    .line 412
    .line 413
    return-object p0

    .line 414
    :pswitch_88
    const-string p0, "PREPARE_BEGIN"

    .line 415
    .line 416
    return-object p0

    .line 417
    :pswitch_89
    const-string p0, "CACHE_FETCH"

    .line 418
    .line 419
    return-object p0

    .line 420
    :pswitch_8a
    const-string p0, "DATA_EMPTY"

    .line 421
    .line 422
    return-object p0

    .line 423
    :pswitch_8b
    const-string p0, "DRAW_VIEW"

    .line 424
    .line 425
    return-object p0

    .line 426
    :pswitch_8c
    const-string p0, "DATA_RECEIVED"

    .line 427
    .line 428
    return-object p0

    .line 429
    :pswitch_8d
    const-string p0, "DB_UPDATED"

    .line 430
    .line 431
    return-object p0

    .line 432
    :pswitch_8e
    const-string p0, "CACHE_UPDATED"

    .line 433
    .line 434
    return-object p0

    .line 435
    :pswitch_8f
    const-string p0, "SUCCESS_LOCAL_UNSPECIFIED"

    .line 436
    .line 437
    return-object p0

    .line 438
    :pswitch_90
    const-string p0, "SUCCESS_NETWORK"

    .line 439
    .line 440
    return-object p0

    .line 441
    :pswitch_91
    const-string p0, "SUCCESS_DB"

    .line 442
    .line 443
    return-object p0

    .line 444
    :pswitch_92
    const-string p0, "SUCCESS_CACHE"

    .line 445
    .line 446
    return-object p0

    .line 447
    :pswitch_93
    const-string p0, "SERVER_FETCH"

    .line 448
    .line 449
    return-object p0

    .line 450
    :pswitch_94
    const-string p0, "DB_FETCH"

    .line 451
    .line 452
    return-object p0

    .line 453
    :pswitch_95
    const-string p0, "USER_NAVIGATION_CANCELLATION"

    .line 454
    .line 455
    return-object p0

    .line 456
    :pswitch_96
    const-string p0, "PHOTO_UPLOAD_COMPLETE"

    .line 457
    .line 458
    return-object p0

    .line 459
    :pswitch_97
    const-string p0, "RETURN_TO_CALLER"

    .line 460
    .line 461
    return-object p0

    .line 462
    :pswitch_98
    const-string p0, "CONSISTENCY_UPDATE"

    .line 463
    .line 464
    return-object p0

    .line 465
    :pswitch_99
    const-string p0, "DISK_CACHE_VISIT"

    .line 466
    .line 467
    return-object p0

    .line 468
    :pswitch_9a
    const-string p0, "MEMORY_CACHE_VISIT"

    .line 469
    .line 470
    return-object p0

    .line 471
    :pswitch_9b
    const-string p0, "NETWORK_COMPLETE"

    .line 472
    .line 473
    return-object p0

    .line 474
    :pswitch_9c
    const-string p0, "DEQUEUE"

    .line 475
    .line 476
    return-object p0

    .line 477
    :pswitch_9d
    const-string p0, "PHASE_TWO"

    .line 478
    .line 479
    return-object p0

    .line 480
    :pswitch_9e
    const-string p0, "PHASE_ONE"

    .line 481
    .line 482
    return-object p0

    .line 483
    :pswitch_9f
    const-string p0, "UI_IDLE"

    .line 484
    .line 485
    return-object p0

    .line 486
    :pswitch_a0
    const-string p0, "SUCCESS_WARM"

    .line 487
    .line 488
    return-object p0

    .line 489
    :pswitch_a1
    const-string p0, "SUCCESS_COLD"

    .line 490
    .line 491
    return-object p0

    .line 492
    :pswitch_a2
    const-string p0, "SEND_MESSAGE"

    .line 493
    .line 494
    return-object p0

    .line 495
    :pswitch_a3
    const-string p0, "CONSISTENCY_MODEL_UPDATER"

    .line 496
    .line 497
    return-object p0

    .line 498
    :pswitch_a4
    const-string p0, "ACTIVITY_CREATED"

    .line 499
    .line 500
    return-object p0

    .line 501
    :pswitch_a5
    const-string p0, "ON_RESUME"

    .line 502
    .line 503
    return-object p0

    .line 504
    :pswitch_a6
    const-string p0, "DRAW_COMPLETE"

    .line 505
    .line 506
    return-object p0

    .line 507
    :pswitch_a7
    const-string p0, "CANCEL"

    .line 508
    .line 509
    return-object p0

    .line 510
    :pswitch_a8
    const-string p0, "FAIL"

    .line 511
    .line 512
    return-object p0

    .line 513
    :pswitch_a9
    const-string p0, "SUCCESS"

    .line 514
    .line 515
    return-object p0

    .line 516
    :pswitch_aa
    const-string p0, "START"

    .line 517
    .line 518
    return-object p0

    .line 519
    nop

    .line 520
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_aa
        :pswitch_a9
        :pswitch_a8
        :pswitch_a7
        :pswitch_a6
        :pswitch_a5
        :pswitch_a4
        :pswitch_a3
        :pswitch_a2
        :pswitch_a1
        :pswitch_a0
        :pswitch_9f
        :pswitch_9e
        :pswitch_9d
        :pswitch_9c
        :pswitch_9b
        :pswitch_9a
        :pswitch_99
        :pswitch_98
        :pswitch_97
        :pswitch_96
        :pswitch_95
        :pswitch_94
        :pswitch_93
        :pswitch_92
        :pswitch_91
        :pswitch_90
        :pswitch_8f
        :pswitch_8e
        :pswitch_8d
        :pswitch_8c
        :pswitch_8b
        :pswitch_8a
        :pswitch_89
        :pswitch_88
        :pswitch_87
        :pswitch_86
        :pswitch_85
        :pswitch_84
        :pswitch_83
        :pswitch_82
        :pswitch_81
        :pswitch_80
        :pswitch_7f
        :pswitch_7e
        :pswitch_7d
        :pswitch_7c
        :pswitch_7b
        :pswitch_7a
        :pswitch_79
        :pswitch_78
        :pswitch_77
        :pswitch_76
        :pswitch_75
        :pswitch_74
        :pswitch_73
        :pswitch_72
        :pswitch_71
        :pswitch_70
        :pswitch_6f
        :pswitch_6e
        :pswitch_6d
        :pswitch_6c
        :pswitch_6b
        :pswitch_6a
        :pswitch_69
        :pswitch_68
        :pswitch_67
        :pswitch_66
        :pswitch_65
        :pswitch_64
        :pswitch_63
        :pswitch_62
        :pswitch_61
        :pswitch_60
        :pswitch_5f
        :pswitch_5e
        :pswitch_5d
        :pswitch_5c
        :pswitch_5b
        :pswitch_5a
        :pswitch_59
        :pswitch_58
        :pswitch_57
        :pswitch_56
        :pswitch_55
        :pswitch_54
        :pswitch_53
        :pswitch_52
        :pswitch_51
        :pswitch_50
        :pswitch_4f
        :pswitch_4e
        :pswitch_4d
        :pswitch_4c
        :pswitch_4b
        :pswitch_4a
        :pswitch_49
        :pswitch_48
        :pswitch_47
        :pswitch_46
        :pswitch_45
        :pswitch_44
        :pswitch_43
        :pswitch_42
        :pswitch_41
        :pswitch_40
        :pswitch_3f
        :pswitch_3e
        :pswitch_3d
        :pswitch_3c
        :pswitch_3b
        :pswitch_3a
        :pswitch_39
        :pswitch_38
        :pswitch_37
        :pswitch_36
        :pswitch_35
        :pswitch_34
        :pswitch_33
        :pswitch_32
        :pswitch_31
        :pswitch_30
        :pswitch_2f
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
