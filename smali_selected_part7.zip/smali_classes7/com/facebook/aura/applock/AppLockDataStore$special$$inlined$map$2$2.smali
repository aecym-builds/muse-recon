.class public final Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;


# direct methods
.method public constructor <init>(LX/39x;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 6

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_4

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v2, p0, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Landroidx/datastore/preferences/core/Preferences;

    .line 41
    .line 42
    sget-object v1, Lcom/facebook/aura/applock/AppLockTimeout;->Companion:Lcom/facebook/aura/applock/AppLockTimeout$Companion;

    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/applock/AppLockDataStore;->KEY_TIMEOUT_SECONDS:LX/8vg;

    .line 45
    .line 46
    invoke-virtual {p1, v0}, Landroidx/datastore/preferences/core/Preferences;->A05(LX/8vg;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Ljava/lang/Number;

    .line 51
    .line 52
    if-eqz v0, :cond_2

    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    :goto_1
    invoke-virtual {v1, v0}, Lcom/facebook/aura/applock/AppLockTimeout$Companion;->fromSeconds(I)Lcom/facebook/aura/applock/AppLockTimeout;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    const/4 v0, 0x0

    .line 63
    iput-object v0, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->L$0:Ljava/lang/Object;

    .line 64
    .line 65
    iput-object v0, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->L$1:Ljava/lang/Object;

    .line 66
    .line 67
    iput-object v0, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->L$2:Ljava/lang/Object;

    .line 68
    .line 69
    iput-object v0, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->L$3:Ljava/lang/Object;

    .line 70
    .line 71
    iput v3, v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;->label:I

    .line 72
    .line 73
    invoke-interface {v2, v1, v5}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-ne v0, v4, :cond_0

    .line 78
    .line 79
    return-object v4

    .line 80
    :cond_2
    invoke-static {}, Lcom/facebook/aura/applock/AppLockTimeout;->access$getDEFAULT$cp()Lcom/facebook/aura/applock/AppLockTimeout;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-virtual {v0}, Lcom/facebook/aura/applock/AppLockTimeout;->getSeconds()I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    goto :goto_1

    .line 89
    :cond_3
    new-instance v5, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;

    .line 90
    .line 91
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2$1;-><init>(Lcom/facebook/aura/applock/AppLockDataStore$special$$inlined$map$2$2;LX/2M4;)V

    .line 92
    .line 93
    .line 94
    goto :goto_0

    .line 95
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    throw v0
.end method
