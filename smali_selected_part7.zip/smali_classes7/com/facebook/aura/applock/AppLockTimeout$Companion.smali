.class public final Lcom/facebook/aura/applock/AppLockTimeout$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final fromSeconds(I)Lcom/facebook/aura/applock/AppLockTimeout;
    .locals 4

    .line 0
    invoke-static {}, Lcom/facebook/aura/applock/AppLockTimeout;->values()[Lcom/facebook/aura/applock/AppLockTimeout;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    array-length v3, p0

    .line 5
    const/4 v2, 0x0

    .line 6
    :goto_0
    if-ge v2, v3, :cond_0

    .line 7
    .line 8
    aget-object v1, p0, v2

    .line 9
    .line 10
    invoke-virtual {v1}, Lcom/facebook/aura/applock/AppLockTimeout;->getSeconds()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eq v0, p1, :cond_1

    .line 15
    .line 16
    add-int/lit8 v2, v2, 0x1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-static {}, Lcom/facebook/aura/applock/AppLockTimeout;->access$getDEFAULT$cp()Lcom/facebook/aura/applock/AppLockTimeout;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    :cond_1
    return-object v1
.end method

.method public final getDEFAULT()Lcom/facebook/aura/applock/AppLockTimeout;
    .locals 0

    .line 0
    invoke-static {}, Lcom/facebook/aura/applock/AppLockTimeout;->access$getDEFAULT$cp()Lcom/facebook/aura/applock/AppLockTimeout;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
