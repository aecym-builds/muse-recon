.class public final enum Lcom/facebook/aura/applock/AppLockTimeout;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/applock/AppLockTimeout;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/applock/AppLockTimeout;

.field public static final Companion:Lcom/facebook/aura/applock/AppLockTimeout$Companion;

.field public static final DEFAULT:Lcom/facebook/aura/applock/AppLockTimeout;

.field public static final enum FIFTEEN_MINUTES:Lcom/facebook/aura/applock/AppLockTimeout;

.field public static final enum FIVE_MINUTES:Lcom/facebook/aura/applock/AppLockTimeout;

.field public static final enum IMMEDIATE:Lcom/facebook/aura/applock/AppLockTimeout;

.field public static final enum ONE_MINUTE:Lcom/facebook/aura/applock/AppLockTimeout;


# instance fields
.field public final seconds:I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const-string v1, "IMMEDIATE"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v6, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 4
    .line 5
    invoke-direct {v6, v1, v0, v0}, Lcom/facebook/aura/applock/AppLockTimeout;-><init>(Ljava/lang/String;II)V

    .line 6
    .line 7
    .line 8
    sput-object v6, Lcom/facebook/aura/applock/AppLockTimeout;->IMMEDIATE:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    const/16 v1, 0x3c

    .line 12
    .line 13
    const-string v0, "ONE_MINUTE"

    .line 14
    .line 15
    new-instance v5, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 16
    .line 17
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/applock/AppLockTimeout;-><init>(Ljava/lang/String;II)V

    .line 18
    .line 19
    .line 20
    sput-object v5, Lcom/facebook/aura/applock/AppLockTimeout;->ONE_MINUTE:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 21
    .line 22
    const/4 v2, 0x2

    .line 23
    const/16 v1, 0x12c

    .line 24
    .line 25
    const-string v0, "FIVE_MINUTES"

    .line 26
    .line 27
    new-instance v4, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 28
    .line 29
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/applock/AppLockTimeout;-><init>(Ljava/lang/String;II)V

    .line 30
    .line 31
    .line 32
    sput-object v4, Lcom/facebook/aura/applock/AppLockTimeout;->FIVE_MINUTES:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 33
    .line 34
    const/4 v3, 0x3

    .line 35
    const/16 v2, 0x384

    .line 36
    .line 37
    const-string v0, "FIFTEEN_MINUTES"

    .line 38
    .line 39
    new-instance v1, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 40
    .line 41
    invoke-direct {v1, v0, v3, v2}, Lcom/facebook/aura/applock/AppLockTimeout;-><init>(Ljava/lang/String;II)V

    .line 42
    .line 43
    .line 44
    sput-object v1, Lcom/facebook/aura/applock/AppLockTimeout;->FIFTEEN_MINUTES:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 45
    .line 46
    filled-new-array {v6, v5, v4, v1}, [Lcom/facebook/aura/applock/AppLockTimeout;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    sput-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->$VALUES:[Lcom/facebook/aura/applock/AppLockTimeout;

    .line 51
    .line 52
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    sput-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->$ENTRIES:LX/0vk;

    .line 57
    .line 58
    new-instance v0, Lcom/facebook/aura/applock/AppLockTimeout$Companion;

    .line 59
    .line 60
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 61
    .line 62
    .line 63
    sput-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->Companion:Lcom/facebook/aura/applock/AppLockTimeout$Companion;

    .line 64
    .line 65
    sput-object v1, Lcom/facebook/aura/applock/AppLockTimeout;->DEFAULT:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 66
    .line 67
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput p3, p0, Lcom/facebook/aura/applock/AppLockTimeout;->seconds:I

    .line 4
    .line 5
    return-void
.end method

.method public static final synthetic access$getDEFAULT$cp()Lcom/facebook/aura/applock/AppLockTimeout;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->DEFAULT:Lcom/facebook/aura/applock/AppLockTimeout;

    .line 1
    .line 2
    return-object v0
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/applock/AppLockTimeout;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/applock/AppLockTimeout;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/applock/AppLockTimeout;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/applock/AppLockTimeout;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/applock/AppLockTimeout;->$VALUES:[Lcom/facebook/aura/applock/AppLockTimeout;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/applock/AppLockTimeout;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getSeconds()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/applock/AppLockTimeout;->seconds:I

    .line 1
    .line 2
    return p0
.end method
