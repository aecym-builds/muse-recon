.class public abstract synthetic Lcom/facebook/aura/common/coroutines/SingleFlight$-CC;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static synthetic forget$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 1

    .line 0
    if-nez p3, :cond_1

    .line 1
    .line 2
    and-int/lit8 v0, p2, 0x1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    :cond_0
    invoke-interface {p0, p1}, Lcom/facebook/aura/common/coroutines/SingleFlight;->forget(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_1
    const-string v0, "Super calls with default arguments not supported in this target, function: forget"

    .line 13
    .line 14
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    throw v0
.end method

.method public static synthetic invoke$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;LX/JDM;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    if-nez p5, :cond_1

    .line 1
    .line 2
    and-int/lit8 v0, p4, 0x1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    :cond_0
    invoke-interface {p0, p1, p2, p3}, Lcom/facebook/aura/common/coroutines/SingleFlight;->invoke(Ljava/lang/Object;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :cond_1
    const-string v0, "Super calls with default arguments not supported in this target, function: invoke"

    .line 14
    .line 15
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    throw v0
.end method
