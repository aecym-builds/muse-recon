.class public abstract Lcom/facebook/aura/common/coroutines/SingleFlight$DefaultImpls;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static synthetic forget$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/common/coroutines/SingleFlight$-CC;->forget$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic invoke$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;LX/JDM;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/common/coroutines/SingleFlight$-CC;->invoke$default(Lcom/facebook/aura/common/coroutines/SingleFlight;Ljava/lang/Object;LX/JDM;LX/2M4;ILjava/lang/Object;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
