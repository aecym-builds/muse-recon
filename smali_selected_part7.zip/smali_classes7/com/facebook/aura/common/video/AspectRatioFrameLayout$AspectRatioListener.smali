.class public interface abstract Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onAspectRatioUpdated(FFZ)V
.end method
