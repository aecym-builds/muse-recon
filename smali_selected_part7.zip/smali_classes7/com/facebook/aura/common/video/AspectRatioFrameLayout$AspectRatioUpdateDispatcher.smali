.class public final Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public aspectRatioMismatch:Z

.field public isScheduled:Z

.field public naturalAspectRatio:F

.field public targetAspectRatio:F

.field public final synthetic this$0:Lcom/facebook/aura/common/video/AspectRatioFrameLayout;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/common/video/AspectRatioFrameLayout;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->this$0:Lcom/facebook/aura/common/video/AspectRatioFrameLayout;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->isScheduled:Z

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->this$0:Lcom/facebook/aura/common/video/AspectRatioFrameLayout;

    .line 4
    .line 5
    iget-object v3, v0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioListener:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;

    .line 6
    .line 7
    if-eqz v3, :cond_0

    .line 8
    .line 9
    iget v2, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->targetAspectRatio:F

    .line 10
    .line 11
    iget v1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->naturalAspectRatio:F

    .line 12
    .line 13
    iget-boolean v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->aspectRatioMismatch:Z

    .line 14
    .line 15
    invoke-interface {v3, v2, v1, v0}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;->onAspectRatioUpdated(FFZ)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final scheduleUpdate(FFZ)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->targetAspectRatio:F

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->naturalAspectRatio:F

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->aspectRatioMismatch:Z

    .line 5
    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->isScheduled:Z

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    iput-boolean v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->isScheduled:Z

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->this$0:Lcom/facebook/aura/common/video/AspectRatioFrameLayout;

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method
