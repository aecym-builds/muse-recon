.class public final synthetic Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/1EY;
.implements LX/FFm;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;->INSTANCE:Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final accept(Landroid/media/MediaCodec;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/media/MediaCodec;->detachOutputSurface()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p1, Landroid/media/MediaCodec;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;->accept(Landroid/media/MediaCodec;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 0
    instance-of v0, p1, LX/FFm;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p1, LX/1EY;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;->getFunctionDelegate()LX/1EZ;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {p1, v0}, LX/8mk;->A1W(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0

    .line 18
    :cond_0
    return v1
.end method

.method public final getFunctionDelegate()LX/1EZ;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/1EZ<",
            "*>;"
        }
    .end annotation

    .line 0
    const-class v2, Landroid/media/MediaCodec;

    .line 1
    .line 2
    const-string v4, "detachOutputSurface()V"

    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v3, "detachOutputSurface"

    .line 7
    .line 8
    new-instance v0, LX/DVE;

    .line 9
    .line 10
    invoke-direct/range {v0 .. v5}, LX/DVE;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final hashCode()I
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/common/video/HatchVideoPrefetcher$ensureConfigured$1$playerDependencyModule$1$configureMediaCodecForSDK35$1;->getFunctionDelegate()LX/1EZ;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method
