.class public final Lcom/facebook/aura/common/video/HatchVideoPlayerConfig;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final DEFAULT_VIDEO_PREFETCH_BYTES:I = 0x100000

.field public static final GROOT_CACHE_SIZE_MB:I = 0x64

.field public static final GROOT_PLAYER_MAX_POOL_SIZE:I = 0x4

.field public static final INSTANCE:Lcom/facebook/aura/common/video/HatchVideoPlayerConfig;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/common/video/HatchVideoPlayerConfig;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/common/video/HatchVideoPlayerConfig;->INSTANCE:Lcom/facebook/aura/common/video/HatchVideoPlayerConfig;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getCacheSizeInBytes()I
    .locals 0

    .line 0
    const/high16 p0, 0x6400000

    .line 1
    .line 2
    return p0
.end method

.method public final getConversationVideoPlayerPoolSize()I
    .locals 0

    .line 0
    const/4 p0, 0x4

    .line 1
    return p0
.end method

.method public final getGrootPlayerMaxPoolSize()I
    .locals 0

    .line 0
    const/4 p0, 0x4

    .line 1
    return p0
.end method

.method public final getVideoPrefetchBytes()I
    .locals 0

    .line 0
    const/high16 p0, 0x100000

    .line 1
    .line 2
    return p0
.end method
