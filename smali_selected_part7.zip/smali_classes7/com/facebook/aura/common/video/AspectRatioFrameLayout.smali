.class public final Lcom/facebook/aura/common/video/AspectRatioFrameLayout;
.super Landroid/widget/FrameLayout;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$Companion;

.field public static final MAX_ASPECT_RATIO_DEFORMATION_FRACTION:F = 0.01f

.field public static final RESIZE_MODE_FILL:I = 0x3

.field public static final RESIZE_MODE_FIT:I = 0x0

.field public static final RESIZE_MODE_FIXED_HEIGHT:I = 0x2

.field public static final RESIZE_MODE_FIXED_WIDTH:I = 0x1

.field public static final RESIZE_MODE_ZOOM:I = 0x4


# instance fields
.field public aspectRatioListener:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;

.field public final aspectRatioUpdateDispatcher:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

.field public resizeMode:I

.field public videoAspectRatio:F


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->Companion:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 536870912
    const/4 v0, 0x0

    .line 536870913
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 536870914
    .line 536870915
    .line 536870916
    const/4 v0, 0x0

    .line 536870917
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 536870918
    .line 536870919
    .line 536870920
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 5
    .line 6
    .line 7
    new-instance v0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    .line 8
    .line 9
    invoke-direct {v0, p0}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;-><init>(Lcom/facebook/aura/common/video/AspectRatioFrameLayout;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    .line 13
    .line 14
    if-eqz p2, :cond_0

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    sget-object v0, LX/IxS;->A00:[I

    .line 21
    .line 22
    invoke-virtual {v1, p2, v0, v2, v2}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :try_start_0
    invoke-virtual {v1, v2, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    iput v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->resizeMode:I

    .line 34
    .line 35
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    :catchall_0
    move-exception v0

    .line 37
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 38
    .line 39
    .line 40
    throw v0

    .line 41
    :goto_0
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 42
    .line 43
    .line 44
    :cond_0
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;ILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p3, 0x2

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    const/4 p2, 0x0

    .line 268435461
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 268435462
    .line 268435463
    .line 268435464
    return-void
.end method

.method public static final synthetic access$getAspectRatioListener$p(Lcom/facebook/aura/common/video/AspectRatioFrameLayout;)Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioListener:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;

    .line 1
    .line 2
    return-object p0
.end method

.method public static synthetic getResizeMode$annotations()V
    .locals 0

    .line 0
    return-void
.end method


# virtual methods
.method public final getResizeMode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->resizeMode:I

    .line 1
    .line 2
    return p0
.end method

.method public onMeasure(II)V
    .locals 11

    .line 0
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 1
    .line 2
    .line 3
    iget v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 4
    .line 5
    const/4 v10, 0x0

    .line 6
    cmpg-float v0, v0, v10

    .line 7
    .line 8
    if-lez v0, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    :goto_0
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    :goto_1
    int-to-float v8, v6

    .line 31
    int-to-float v7, v5

    .line 32
    div-float v4, v8, v7

    .line 33
    .line 34
    iget v3, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 35
    .line 36
    div-float v9, v3, v4

    .line 37
    .line 38
    const/4 v2, 0x1

    .line 39
    const/high16 v0, 0x3f800000    # 1.0f

    .line 40
    .line 41
    sub-float/2addr v9, v0

    .line 42
    invoke-static {v9}, Ljava/lang/Math;->abs(F)F

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    const v0, 0x3c23d70a    # 0.01f

    .line 47
    .line 48
    .line 49
    cmpg-float v0, v1, v0

    .line 50
    .line 51
    if-gtz v0, :cond_3

    .line 52
    .line 53
    iget-object v1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-virtual {v1, v3, v4, v0}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->scheduleUpdate(FFZ)V

    .line 57
    .line 58
    .line 59
    :cond_0
    return-void

    .line 60
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    goto :goto_1

    .line 65
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 66
    .line 67
    .line 68
    move-result v6

    .line 69
    goto :goto_0

    .line 70
    :cond_3
    iget v1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->resizeMode:I

    .line 71
    .line 72
    if-eqz v1, :cond_7

    .line 73
    .line 74
    if-eq v1, v2, :cond_8

    .line 75
    .line 76
    const/4 v0, 0x2

    .line 77
    if-eq v1, v0, :cond_4

    .line 78
    .line 79
    const/4 v0, 0x4

    .line 80
    if-ne v1, v0, :cond_5

    .line 81
    .line 82
    cmpl-float v0, v9, v10

    .line 83
    .line 84
    if-lez v0, :cond_6

    .line 85
    .line 86
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_6

    .line 91
    .line 92
    iget v3, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 93
    .line 94
    :cond_4
    mul-float/2addr v7, v3

    .line 95
    float-to-int v6, v7

    .line 96
    :cond_5
    :goto_2
    iget-object v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    .line 97
    .line 98
    invoke-virtual {v0, v3, v4, v2}, Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->scheduleUpdate(FFZ)V

    .line 99
    .line 100
    .line 101
    const/high16 v0, 0x40000000    # 2.0f

    .line 102
    .line 103
    invoke-static {v6, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    invoke-static {v5, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-super {p0, v1, v0}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 112
    .line 113
    .line 114
    return-void

    .line 115
    :cond_6
    iget v3, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 116
    .line 117
    goto :goto_3

    .line 118
    :cond_7
    cmpl-float v0, v9, v10

    .line 119
    .line 120
    if-lez v0, :cond_4

    .line 121
    .line 122
    :cond_8
    :goto_3
    div-float/2addr v8, v3

    .line 123
    float-to-int v5, v8

    .line 124
    goto :goto_2
.end method

.method public final setAspectRatio(F)V
    .locals 1

    .line 0
    iget v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 1
    .line 2
    cmpg-float v0, v0, p1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iput p1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final setAspectRatioListener(Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->aspectRatioListener:Lcom/facebook/aura/common/video/AspectRatioFrameLayout$AspectRatioListener;

    .line 1
    .line 2
    return-void
.end method

.method public final setResizeMode(I)V
    .locals 1

    .line 0
    iget v0, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->resizeMode:I

    .line 1
    .line 2
    if-eq v0, p1, :cond_0

    .line 3
    .line 4
    iput p1, p0, Lcom/facebook/aura/common/video/AspectRatioFrameLayout;->resizeMode:I

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
.end method
