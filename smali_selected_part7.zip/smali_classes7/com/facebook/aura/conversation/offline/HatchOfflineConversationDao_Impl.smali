.class public final Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;
.super Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao;
.source ""


# instance fields
.field public final __db:LX/DPY;

.field public final __insertAdapterOfHatchOfflineKeyEntity:LX/IBa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/IBa<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;",
            ">;"
        }
    .end annotation
.end field

.field public final __insertAdapterOfHatchOfflineMessageEntity:LX/IBa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/IBa<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;",
            ">;"
        }
    .end annotation
.end field

.field public final __insertAdapterOfHatchOfflineThreadEntity:LX/IBa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/IBa<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DPY;)V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$1;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$1;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineMessageEntity:LX/IBa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$2;

    .line 13
    .line 14
    invoke-direct {v0, p0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$2;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineThreadEntity:LX/IBa;

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$3;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$3;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineKeyEntity:LX/IBa;

    .line 25
    .line 26
    return-void
.end method

.method public static getRequiredConverters()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Class<",
            "*>;>;"
        }
    .end annotation

    .line 0
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic lambda$clearAllDataKeys$0(LX/Bpd;)Ljava/lang/Object;
    .locals 1

    .line 0
    const-string v0, "DELETE FROM offline_keys"

    .line 1
    .line 2
    invoke-interface {p0, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :try_start_0
    invoke-interface {p0}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    .line 9
    invoke-interface {p0}, LX/DQY;->close()V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return-object v0

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    invoke-interface {p0}, LX/DQY;->close()V

    .line 16
    .line 17
    .line 18
    throw v0
.end method

.method public static synthetic lambda$clearAllMessages$0(LX/Bpd;)Ljava/lang/Object;
    .locals 1

    .line 0
    const-string v0, "DELETE FROM offline_messages"

    .line 1
    .line 2
    invoke-interface {p0, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :try_start_0
    invoke-interface {p0}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    .line 9
    invoke-interface {p0}, LX/DQY;->close()V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return-object v0

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    invoke-interface {p0}, LX/DQY;->close()V

    .line 16
    .line 17
    .line 18
    throw v0
.end method

.method public static synthetic lambda$clearAllThreads$0(LX/Bpd;)Ljava/lang/Object;
    .locals 1

    .line 0
    const-string v0, "DELETE FROM offline_threads"

    .line 1
    .line 2
    invoke-interface {p0, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :try_start_0
    invoke-interface {p0}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    .line 9
    invoke-interface {p0}, LX/DQY;->close()V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return-object v0

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    invoke-interface {p0}, LX/DQY;->close()V

    .line 16
    .line 17
    .line 18
    throw v0
.end method

.method public static synthetic lambda$deleteMessagesBySeq$0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;LX/Bpd;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-interface {p4, p0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 1
    .line 2
    .line 3
    move-result-object p4

    .line 4
    :try_start_0
    invoke-static {p4, p1, p2}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object p3

    .line 11
    const/4 p2, 0x3

    .line 12
    :goto_0
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    if-eqz p0, :cond_0

    .line 17
    .line 18
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    check-cast p0, Ljava/lang/Long;

    .line 23
    .line 24
    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    .line 25
    .line 26
    .line 27
    move-result-wide p0

    .line 28
    invoke-interface {p4, p2, p0, p1}, LX/DQY;->A5F(IJ)V

    .line 29
    .line 30
    .line 31
    add-int/lit8 p2, p2, 0x1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    invoke-interface {p4}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 35
    .line 36
    .line 37
    invoke-interface {p4}, LX/DQY;->close()V

    .line 38
    .line 39
    .line 40
    const/4 p0, 0x0

    .line 41
    return-object p0

    .line 42
    :catchall_0
    move-exception p0

    .line 43
    invoke-interface {p4}, LX/DQY;->close()V

    .line 44
    .line 45
    .line 46
    throw p0
.end method

.method public static synthetic lambda$deleteMessagesExceptVm$0(Ljava/lang/String;LX/Bpd;)Ljava/lang/Object;
    .locals 2

    .line 0
    const-string v0, "DELETE FROM offline_messages WHERE vm_id != ?"

    .line 1
    .line 2
    invoke-interface {p1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const/4 v0, 0x1

    .line 7
    :try_start_0
    invoke-interface {v1, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v1}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    .line 13
    invoke-interface {v1}, LX/DQY;->close()V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    return-object v0

    .line 18
    :catchall_0
    move-exception v0

    .line 19
    invoke-interface {v1}, LX/DQY;->close()V

    .line 20
    .line 21
    .line 22
    throw v0
.end method

.method public static synthetic lambda$deleteMessagesForEvictedThreads$0(Ljava/lang/String;Ljava/lang/String;ILX/Bpd;)Ljava/lang/Object;
    .locals 4

    .line 0
    const-string v0, "DELETE FROM offline_messages WHERE vm_id = ? AND session_id != ? AND session_id NOT IN (SELECT session_id FROM offline_threads WHERE vm_id = ? ORDER BY last_opened_at DESC LIMIT ?)"

    .line 1
    .line 2
    invoke-interface {p3, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    :try_start_0
    invoke-static {v3, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    invoke-interface {v3, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v2, 0x4

    .line 14
    int-to-long v0, p2

    .line 15
    invoke-interface {v3, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 16
    .line 17
    .line 18
    invoke-interface {v3}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    invoke-interface {v3}, LX/DQY;->close()V

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    return-object v0

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    invoke-interface {v3}, LX/DQY;->close()V

    .line 28
    .line 29
    .line 30
    throw v0
.end method

.method public static synthetic lambda$deleteMessagesForSession$0(Ljava/lang/String;Ljava/lang/String;LX/Bpd;)Ljava/lang/Object;
    .locals 2

    .line 0
    const-string v0, "DELETE FROM offline_messages WHERE vm_id = ? AND session_id = ?"

    .line 1
    .line 2
    invoke-interface {p2, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    :try_start_0
    invoke-static {v1, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-interface {v1}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-interface {v1}, LX/DQY;->close()V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    return-object v0

    .line 17
    :catchall_0
    move-exception v0

    .line 18
    invoke-interface {v1}, LX/DQY;->close()V

    .line 19
    .line 20
    .line 21
    throw v0
.end method

.method public static synthetic lambda$deleteThread$0(Ljava/lang/String;Ljava/lang/String;LX/Bpd;)Ljava/lang/Object;
    .locals 2

    .line 0
    const-string v0, "DELETE FROM offline_threads WHERE vm_id = ? AND session_id = ?"

    .line 1
    .line 2
    invoke-interface {p2, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    :try_start_0
    invoke-static {v1, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-interface {v1}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-interface {v1}, LX/DQY;->close()V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    return-object v0

    .line 17
    :catchall_0
    move-exception v0

    .line 18
    invoke-interface {v1}, LX/DQY;->close()V

    .line 19
    .line 20
    .line 21
    throw v0
.end method

.method public static synthetic lambda$deleteThreadsBeyondLru$0(Ljava/lang/String;ILX/Bpd;)Ljava/lang/Object;
    .locals 4

    .line 0
    const-string v0, "DELETE FROM offline_threads WHERE vm_id = ? AND session_id NOT IN (SELECT session_id FROM offline_threads WHERE vm_id = ? ORDER BY last_opened_at DESC LIMIT ?)"

    .line 1
    .line 2
    invoke-interface {p2, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    const/4 v0, 0x1

    .line 7
    :try_start_0
    invoke-interface {v3, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-interface {v3, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const/4 v2, 0x3

    .line 15
    int-to-long v0, p1

    .line 16
    invoke-interface {v3, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 17
    .line 18
    .line 19
    invoke-interface {v3}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    .line 21
    .line 22
    invoke-interface {v3}, LX/DQY;->close()V

    .line 23
    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    return-object v0

    .line 27
    :catchall_0
    move-exception v0

    .line 28
    invoke-interface {v3}, LX/DQY;->close()V

    .line 29
    .line 30
    .line 31
    throw v0
.end method

.method public static synthetic lambda$deleteThreadsExceptVm$0(Ljava/lang/String;LX/Bpd;)Ljava/lang/Object;
    .locals 2

    .line 0
    const-string v0, "DELETE FROM offline_threads WHERE vm_id != ?"

    .line 1
    .line 2
    invoke-interface {p1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const/4 v0, 0x1

    .line 7
    :try_start_0
    invoke-interface {v1, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v1}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    .line 13
    invoke-interface {v1}, LX/DQY;->close()V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    return-object v0

    .line 18
    :catchall_0
    move-exception v0

    .line 19
    invoke-interface {v1}, LX/DQY;->close()V

    .line 20
    .line 21
    .line 22
    throw v0
.end method

.method public static synthetic lambda$getThread$0(Ljava/lang/String;Ljava/lang/String;LX/Bpd;)Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;
    .locals 28

    .line 0
    const-string v0, "SELECT * FROM offline_threads WHERE vm_id = ? AND session_id = ? LIMIT 1"

    .line 1
    .line 2
    move-object/from16 v1, p2

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    :try_start_0
    move-object/from16 v2, p0

    .line 9
    .line 10
    move-object/from16 v1, p1

    .line 11
    .line 12
    invoke-static {v0, v2, v1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v1, "vm_id"

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v14

    .line 21
    const-string v1, "session_id"

    .line 22
    .line 23
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v13

    .line 27
    const-string v1, "title"

    .line 28
    .line 29
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v12

    .line 33
    const-string v1, "snippet"

    .line 34
    .line 35
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v11

    .line 39
    const-string v1, "created_at"

    .line 40
    .line 41
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v10

    .line 45
    const-string v1, "updated_at"

    .line 46
    .line 47
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    const-string v1, "is_thread"

    .line 52
    .line 53
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v6

    .line 57
    const-string v1, "status"

    .line 58
    .line 59
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    const-string v1, "unread_count"

    .line 64
    .line 65
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    const-string v1, "is_pinned"

    .line 70
    .line 71
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    const-string v1, "last_opened_at"

    .line 76
    .line 77
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v7

    .line 81
    const-string v1, "channel"

    .line 82
    .line 83
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    const-string v2, "account_username"

    .line 88
    .line 89
    invoke-static {v0, v2}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    const-string v9, "can_send_messages"

    .line 94
    .line 95
    invoke-static {v0, v9}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 96
    .line 97
    .line 98
    move-result v9

    .line 99
    invoke-interface {v0}, LX/DQY;->Ags()Z

    .line 100
    .line 101
    .line 102
    move-result v15

    .line 103
    const/16 p1, 0x0

    .line 104
    .line 105
    if-eqz v15, :cond_4

    .line 106
    .line 107
    invoke-interface {v0, v14}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v14

    .line 111
    invoke-interface {v0, v13}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v15

    .line 115
    invoke-interface {v0, v12}, LX/DQY;->isNull(I)Z

    .line 116
    .line 117
    .line 118
    move-result v13

    .line 119
    if-eqz v13, :cond_0

    .line 120
    .line 121
    move-object/from16 v16, p1

    .line 122
    .line 123
    goto :goto_0

    .line 124
    :cond_0
    invoke-interface {v0, v12}, LX/DQY;->getBlob(I)[B

    .line 125
    .line 126
    .line 127
    move-result-object v16

    .line 128
    :goto_0
    invoke-interface {v0, v11}, LX/DQY;->isNull(I)Z

    .line 129
    .line 130
    .line 131
    move-result v12

    .line 132
    if-eqz v12, :cond_1

    .line 133
    .line 134
    move-object/from16 v17, p1

    .line 135
    .line 136
    goto :goto_1

    .line 137
    :cond_1
    invoke-interface {v0, v11}, LX/DQY;->getBlob(I)[B

    .line 138
    .line 139
    .line 140
    move-result-object v17

    .line 141
    :goto_1
    invoke-interface {v0, v10}, LX/DQY;->getLong(I)J

    .line 142
    .line 143
    .line 144
    move-result-wide v18

    .line 145
    invoke-interface {v0, v8}, LX/DQY;->getLong(I)J

    .line 146
    .line 147
    .line 148
    move-result-wide v20

    .line 149
    invoke-static {v0, v6}, LX/IEa;->A05(LX/DQY;I)I

    .line 150
    .line 151
    .line 152
    move-result v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 153
    invoke-static {v6}, LX/003;->A1B(I)Z

    .line 154
    .line 155
    .line 156
    move-result v22

    .line 157
    :try_start_1
    invoke-interface {v0, v5}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v23

    .line 161
    invoke-static {v0, v4}, LX/IEa;->A05(LX/DQY;I)I

    .line 162
    .line 163
    .line 164
    move-result v24

    .line 165
    invoke-static {v0, v3}, LX/IEa;->A05(LX/DQY;I)I

    .line 166
    .line 167
    .line 168
    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 169
    invoke-static {v3}, LX/003;->A1B(I)Z

    .line 170
    .line 171
    .line 172
    move-result v25

    .line 173
    :try_start_2
    invoke-interface {v0, v7}, LX/DQY;->getLong(I)J

    .line 174
    .line 175
    .line 176
    move-result-wide v26

    .line 177
    invoke-interface {v0, v1}, LX/DQY;->isNull(I)Z

    .line 178
    .line 179
    .line 180
    move-result v3

    .line 181
    if-eqz v3, :cond_2

    .line 182
    .line 183
    move-object/from16 p0, p1

    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_2
    invoke-interface {v0, v1}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object p0

    .line 190
    :goto_2
    invoke-interface {v0, v2}, LX/DQY;->isNull(I)Z

    .line 191
    .line 192
    .line 193
    move-result v1

    .line 194
    if-nez v1, :cond_3

    .line 195
    .line 196
    invoke-interface {v0, v2}, LX/DQY;->getBlob(I)[B

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    :cond_3
    invoke-static {v0, v9}, LX/IEa;->A05(LX/DQY;I)I

    .line 201
    .line 202
    .line 203
    move-result v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 204
    invoke-static {v1}, LX/003;->A1B(I)Z

    .line 205
    .line 206
    .line 207
    move-result p2

    .line 208
    :try_start_3
    new-instance v13, Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;

    .line 209
    .line 210
    invoke-direct/range {v13 .. v30}, Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;-><init>(Ljava/lang/String;Ljava/lang/String;[B[BJJZLjava/lang/String;IZJLjava/lang/String;[BZ)V

    .line 211
    .line 212
    .line 213
    move-object/from16 p1, v13
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 214
    .line 215
    :cond_4
    invoke-interface {v0}, LX/DQY;->close()V

    .line 216
    .line 217
    .line 218
    return-object p1

    .line 219
    :catchall_0
    move-exception v1

    .line 220
    invoke-interface {v0}, LX/DQY;->close()V

    .line 221
    .line 222
    .line 223
    throw v1
.end method

.method public static synthetic lambda$loadDataKey$0(ILX/Bpd;)Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;
    .locals 4

    .line 0
    const-string v0, "SELECT * FROM offline_keys WHERE id = ?"

    .line 1
    .line 2
    invoke-interface {p1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    const/4 v2, 0x1

    .line 7
    int-to-long v0, p0

    .line 8
    :try_start_0
    invoke-interface {v3, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 9
    .line 10
    .line 11
    const-string v0, "id"

    .line 12
    .line 13
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const-string v0, "wrapped_key"

    .line 18
    .line 19
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-interface {v3}, LX/DQY;->Ags()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-static {v3, v2}, LX/IEa;->A05(LX/DQY;I)I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    invoke-interface {v3, v1}, LX/DQY;->getBlob(I)[B

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;

    .line 38
    .line 39
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;-><init>(I[B)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    const/4 v0, 0x0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    :goto_0
    invoke-interface {v3}, LX/DQY;->close()V

    .line 45
    .line 46
    .line 47
    return-object v0

    .line 48
    :catchall_0
    move-exception v0

    .line 49
    invoke-interface {v3}, LX/DQY;->close()V

    .line 50
    .line 51
    .line 52
    throw v0
.end method

.method public static synthetic lambda$loadLatestMessages$0(Ljava/lang/String;Ljava/lang/String;ILX/Bpd;)Ljava/util/List;
    .locals 15

    .line 0
    const-string v0, "SELECT * FROM offline_messages WHERE vm_id = ? AND session_id = ? ORDER BY seq DESC LIMIT ?"

    .line 1
    .line 2
    move-object/from16 v1, p3

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    :try_start_0
    move-object/from16 v0, p1

    .line 9
    .line 10
    invoke-static {v4, p0, v0}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v2, 0x3

    .line 14
    move/from16 v0, p2

    .line 15
    .line 16
    int-to-long v0, v0

    .line 17
    invoke-interface {v4, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 18
    .line 19
    .line 20
    const-string v0, "vm_id"

    .line 21
    .line 22
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    move-result v8

    .line 26
    const-string v0, "session_id"

    .line 27
    .line 28
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v7

    .line 32
    const-string v0, "seq"

    .line 33
    .line 34
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 35
    .line 36
    .line 37
    move-result v6

    .line 38
    const-string v0, "timestamp"

    .line 39
    .line 40
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    const-string v0, "server_message_id"

    .line 45
    .line 46
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    const-string v0, "role"

    .line 51
    .line 52
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    const-string v0, "json"

    .line 57
    .line 58
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    :goto_0
    invoke-interface {v4}, LX/DQY;->Ags()Z

    .line 67
    .line 68
    .line 69
    move-result v9

    .line 70
    if-eqz v9, :cond_1

    .line 71
    .line 72
    invoke-interface {v4, v8}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v10

    .line 76
    invoke-interface {v4, v7}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v11

    .line 80
    invoke-interface {v4, v6}, LX/DQY;->getLong(I)J

    .line 81
    .line 82
    .line 83
    move-result-wide v12

    .line 84
    invoke-interface {v4, v5}, LX/DQY;->getLong(I)J

    .line 85
    .line 86
    .line 87
    move-result-wide v14

    .line 88
    invoke-interface {v4, v3}, LX/DQY;->isNull(I)Z

    .line 89
    .line 90
    .line 91
    move-result v9

    .line 92
    if-eqz v9, :cond_0

    .line 93
    .line 94
    const/16 p1, 0x0

    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_0
    invoke-interface {v4, v3}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    :goto_1
    invoke-interface {v4, v2}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p2

    .line 105
    invoke-interface {v4, v1}, LX/DQY;->getBlob(I)[B

    .line 106
    .line 107
    .line 108
    move-result-object p3

    .line 109
    new-instance v9, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;

    .line 110
    .line 111
    invoke-direct/range {v9 .. v18}, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;-><init>(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;[B)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0, v9}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 118
    :cond_1
    invoke-interface {v4}, LX/DQY;->close()V

    .line 119
    .line 120
    .line 121
    return-object v0

    .line 122
    :catchall_0
    move-exception v0

    .line 123
    invoke-interface {v4}, LX/DQY;->close()V

    .line 124
    .line 125
    .line 126
    throw v0
.end method

.method public static synthetic lambda$loadMessage$0(Ljava/lang/String;Ljava/lang/String;JLX/Bpd;)Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;
    .locals 12

    .line 0
    const-string v0, "SELECT * FROM offline_messages WHERE vm_id = ? AND session_id = ? AND seq = ? LIMIT 1"

    .line 1
    .line 2
    move-object/from16 v1, p4

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    :try_start_0
    invoke-static {v1, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x3

    .line 12
    invoke-interface {v1, v0, p2, p3}, LX/DQY;->A5F(IJ)V

    .line 13
    .line 14
    .line 15
    const-string v0, "vm_id"

    .line 16
    .line 17
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v8

    .line 21
    const-string v0, "session_id"

    .line 22
    .line 23
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    const-string v0, "seq"

    .line 28
    .line 29
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v6

    .line 33
    const-string v0, "timestamp"

    .line 34
    .line 35
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    const-string v0, "server_message_id"

    .line 40
    .line 41
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    const-string v0, "role"

    .line 46
    .line 47
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    const-string v0, "json"

    .line 52
    .line 53
    invoke-static {v1, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    invoke-interface {v1}, LX/DQY;->Ags()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    const/4 p2, 0x0

    .line 62
    if-eqz v0, :cond_1

    .line 63
    .line 64
    invoke-interface {v1, v8}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v8

    .line 68
    invoke-interface {v1, v7}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v9

    .line 72
    invoke-interface {v1, v6}, LX/DQY;->getLong(I)J

    .line 73
    .line 74
    .line 75
    move-result-wide v10

    .line 76
    invoke-interface {v1, v5}, LX/DQY;->getLong(I)J

    .line 77
    .line 78
    .line 79
    move-result-wide p0

    .line 80
    invoke-interface {v1, v4}, LX/DQY;->isNull(I)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-nez v0, :cond_0

    .line 85
    .line 86
    invoke-interface {v1, v4}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p2

    .line 90
    :cond_0
    invoke-interface {v1, v3}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p3

    .line 94
    invoke-interface {v1, v2}, LX/DQY;->getBlob(I)[B

    .line 95
    .line 96
    .line 97
    move-result-object p4

    .line 98
    new-instance v7, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;

    .line 99
    .line 100
    invoke-direct/range {v7 .. v16}, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;-><init>(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;[B)V

    .line 101
    .line 102
    .line 103
    move-object p2, v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 104
    :cond_1
    invoke-interface {v1}, LX/DQY;->close()V

    .line 105
    .line 106
    .line 107
    return-object p2

    .line 108
    :catchall_0
    move-exception v0

    .line 109
    invoke-interface {v1}, LX/DQY;->close()V

    .line 110
    .line 111
    .line 112
    throw v0
.end method

.method public static synthetic lambda$loadMessagesBefore$0(Ljava/lang/String;Ljava/lang/String;JILX/Bpd;)Ljava/util/List;
    .locals 13

    .line 0
    const-string v0, "SELECT * FROM offline_messages WHERE vm_id = ? AND session_id = ? AND seq < ? ORDER BY seq DESC LIMIT ?"

    .line 1
    .line 2
    move-object/from16 v1, p5

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    :try_start_0
    invoke-static {v3, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x3

    .line 12
    move-wide v1, p2

    .line 13
    invoke-interface {v3, v0, v1, v2}, LX/DQY;->A5F(IJ)V

    .line 14
    .line 15
    .line 16
    const/4 v2, 0x4

    .line 17
    move/from16 v0, p4

    .line 18
    .line 19
    int-to-long v0, v0

    .line 20
    invoke-interface {v3, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 21
    .line 22
    .line 23
    const-string v0, "vm_id"

    .line 24
    .line 25
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 26
    .line 27
    .line 28
    move-result v8

    .line 29
    const-string v0, "session_id"

    .line 30
    .line 31
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    const-string v0, "seq"

    .line 36
    .line 37
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v6

    .line 41
    const-string v0, "timestamp"

    .line 42
    .line 43
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    const-string v0, "server_message_id"

    .line 48
    .line 49
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 50
    .line 51
    .line 52
    move-result v4

    .line 53
    const-string v0, "role"

    .line 54
    .line 55
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    const-string v0, "json"

    .line 60
    .line 61
    invoke-static {v3, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    :goto_0
    invoke-interface {v3}, LX/DQY;->Ags()Z

    .line 70
    .line 71
    .line 72
    move-result v9

    .line 73
    if-eqz v9, :cond_1

    .line 74
    .line 75
    invoke-interface {v3, v8}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    invoke-interface {v3, v7}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v11

    .line 83
    invoke-interface {v3, v6}, LX/DQY;->getLong(I)J

    .line 84
    .line 85
    .line 86
    move-result-wide v12

    .line 87
    invoke-interface {v3, v5}, LX/DQY;->getLong(I)J

    .line 88
    .line 89
    .line 90
    move-result-wide p1

    .line 91
    invoke-interface {v3, v4}, LX/DQY;->isNull(I)Z

    .line 92
    .line 93
    .line 94
    move-result v9

    .line 95
    if-eqz v9, :cond_0

    .line 96
    .line 97
    const/16 p3, 0x0

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_0
    invoke-interface {v3, v4}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p3

    .line 104
    :goto_1
    invoke-interface {v3, v2}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p4

    .line 108
    invoke-interface {v3, v1}, LX/DQY;->getBlob(I)[B

    .line 109
    .line 110
    .line 111
    move-result-object p5

    .line 112
    new-instance v9, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;

    .line 113
    .line 114
    invoke-direct/range {v9 .. v18}, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;-><init>(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;[B)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v0, v9}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 121
    :cond_1
    invoke-interface {v3}, LX/DQY;->close()V

    .line 122
    .line 123
    .line 124
    return-object v0

    .line 125
    :catchall_0
    move-exception v0

    .line 126
    invoke-interface {v3}, LX/DQY;->close()V

    .line 127
    .line 128
    .line 129
    throw v0
.end method

.method public static synthetic lambda$loadMessagesPage$0(Ljava/lang/String;IILX/Bpd;)Ljava/util/List;
    .locals 15

    .line 0
    const-string v0, "SELECT * FROM offline_messages WHERE vm_id = ? ORDER BY timestamp DESC, session_id, seq DESC LIMIT ? OFFSET ?"

    .line 1
    .line 2
    move-object/from16 v1, p3

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    const/4 v0, 0x1

    .line 9
    :try_start_0
    invoke-interface {v4, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    move/from16 v0, p1

    .line 14
    .line 15
    int-to-long v0, v0

    .line 16
    invoke-interface {v4, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 17
    .line 18
    .line 19
    const/4 v2, 0x3

    .line 20
    move/from16 v0, p2

    .line 21
    .line 22
    int-to-long v0, v0

    .line 23
    invoke-interface {v4, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 24
    .line 25
    .line 26
    const-string v0, "vm_id"

    .line 27
    .line 28
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v8

    .line 32
    const-string v0, "session_id"

    .line 33
    .line 34
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 35
    .line 36
    .line 37
    move-result v7

    .line 38
    const-string v0, "seq"

    .line 39
    .line 40
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    const-string v0, "timestamp"

    .line 45
    .line 46
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    const-string v0, "server_message_id"

    .line 51
    .line 52
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 53
    .line 54
    .line 55
    move-result v3

    .line 56
    const-string v0, "role"

    .line 57
    .line 58
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    const-string v0, "json"

    .line 63
    .line 64
    invoke-static {v4, v0}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    :goto_0
    invoke-interface {v4}, LX/DQY;->Ags()Z

    .line 73
    .line 74
    .line 75
    move-result v9

    .line 76
    if-eqz v9, :cond_1

    .line 77
    .line 78
    invoke-interface {v4, v8}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v10

    .line 82
    invoke-interface {v4, v7}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v11

    .line 86
    invoke-interface {v4, v6}, LX/DQY;->getLong(I)J

    .line 87
    .line 88
    .line 89
    move-result-wide v12

    .line 90
    invoke-interface {v4, v5}, LX/DQY;->getLong(I)J

    .line 91
    .line 92
    .line 93
    move-result-wide v14

    .line 94
    invoke-interface {v4, v3}, LX/DQY;->isNull(I)Z

    .line 95
    .line 96
    .line 97
    move-result v9

    .line 98
    if-eqz v9, :cond_0

    .line 99
    .line 100
    const/16 p1, 0x0

    .line 101
    .line 102
    goto :goto_1

    .line 103
    :cond_0
    invoke-interface {v4, v3}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    :goto_1
    invoke-interface {v4, v2}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p2

    .line 111
    invoke-interface {v4, v1}, LX/DQY;->getBlob(I)[B

    .line 112
    .line 113
    .line 114
    move-result-object p3

    .line 115
    new-instance v9, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;

    .line 116
    .line 117
    invoke-direct/range {v9 .. v18}, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;-><init>(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;[B)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0, v9}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 124
    :cond_1
    invoke-interface {v4}, LX/DQY;->close()V

    .line 125
    .line 126
    .line 127
    return-object v0

    .line 128
    :catchall_0
    move-exception v0

    .line 129
    invoke-interface {v4}, LX/DQY;->close()V

    .line 130
    .line 131
    .line 132
    throw v0
.end method

.method public static synthetic lambda$loadThreads$0(Ljava/lang/String;LX/Bpd;)Ljava/util/List;
    .locals 33

    .line 0
    const-string v0, "SELECT * FROM offline_threads WHERE vm_id = ? ORDER BY last_opened_at DESC"

    .line 1
    .line 2
    move-object/from16 v1, p1

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v1, 0x1

    .line 9
    :try_start_0
    move-object/from16 v2, p0

    .line 10
    .line 11
    invoke-interface {v0, v1, v2}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v1, "vm_id"

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 17
    .line 18
    .line 19
    move-result v16

    .line 20
    const-string v1, "session_id"

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    move-result v15

    .line 26
    const-string v1, "title"

    .line 27
    .line 28
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    const-string v1, "snippet"

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    const-string v1, "created_at"

    .line 39
    .line 40
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 41
    .line 42
    .line 43
    move-result v14

    .line 44
    const-string v1, "updated_at"

    .line 45
    .line 46
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v13

    .line 50
    const-string v1, "is_thread"

    .line 51
    .line 52
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 53
    .line 54
    .line 55
    move-result v12

    .line 56
    const-string v1, "status"

    .line 57
    .line 58
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 59
    .line 60
    .line 61
    move-result v11

    .line 62
    const-string v1, "unread_count"

    .line 63
    .line 64
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    move-result v10

    .line 68
    const-string v1, "is_pinned"

    .line 69
    .line 70
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 71
    .line 72
    .line 73
    move-result v9

    .line 74
    const-string v1, "last_opened_at"

    .line 75
    .line 76
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 77
    .line 78
    .line 79
    move-result v8

    .line 80
    const-string v1, "channel"

    .line 81
    .line 82
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    const-string v1, "account_username"

    .line 87
    .line 88
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    move-result v2

    .line 92
    const-string v1, "can_send_messages"

    .line 93
    .line 94
    invoke-static {v0, v1}, LX/DQf;->A00(LX/DQY;Ljava/lang/String;)I

    .line 95
    .line 96
    .line 97
    move-result v7

    .line 98
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    :goto_0
    invoke-interface {v0}, LX/DQY;->Ags()Z

    .line 103
    .line 104
    .line 105
    move-result v6

    .line 106
    if-eqz v6, :cond_4

    .line 107
    .line 108
    move/from16 v6, v16

    .line 109
    .line 110
    invoke-interface {v0, v6}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v18

    .line 114
    invoke-interface {v0, v15}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v19

    .line 118
    invoke-interface {v0, v5}, LX/DQY;->isNull(I)Z

    .line 119
    .line 120
    .line 121
    move-result v6

    .line 122
    const/16 p0, 0x0

    .line 123
    .line 124
    if-eqz v6, :cond_0

    .line 125
    .line 126
    move-object/from16 v20, p0

    .line 127
    .line 128
    goto :goto_1

    .line 129
    :cond_0
    invoke-interface {v0, v5}, LX/DQY;->getBlob(I)[B

    .line 130
    .line 131
    .line 132
    move-result-object v20

    .line 133
    :goto_1
    invoke-interface {v0, v4}, LX/DQY;->isNull(I)Z

    .line 134
    .line 135
    .line 136
    move-result v6

    .line 137
    if-eqz v6, :cond_1

    .line 138
    .line 139
    move-object/from16 v21, p0

    .line 140
    .line 141
    goto :goto_2

    .line 142
    :cond_1
    invoke-interface {v0, v4}, LX/DQY;->getBlob(I)[B

    .line 143
    .line 144
    .line 145
    move-result-object v21

    .line 146
    :goto_2
    invoke-interface {v0, v14}, LX/DQY;->getLong(I)J

    .line 147
    .line 148
    .line 149
    move-result-wide v22

    .line 150
    invoke-interface {v0, v13}, LX/DQY;->getLong(I)J

    .line 151
    .line 152
    .line 153
    move-result-wide v24

    .line 154
    invoke-static {v0, v12}, LX/IEa;->A05(LX/DQY;I)I

    .line 155
    .line 156
    .line 157
    move-result v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 158
    invoke-static {v6}, LX/003;->A1B(I)Z

    .line 159
    .line 160
    .line 161
    move-result v26

    .line 162
    :try_start_1
    invoke-interface {v0, v11}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v27

    .line 166
    invoke-static {v0, v10}, LX/IEa;->A05(LX/DQY;I)I

    .line 167
    .line 168
    .line 169
    move-result v28

    .line 170
    invoke-static {v0, v9}, LX/IEa;->A05(LX/DQY;I)I

    .line 171
    .line 172
    .line 173
    move-result v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 174
    invoke-static {v6}, LX/003;->A1B(I)Z

    .line 175
    .line 176
    .line 177
    move-result v29

    .line 178
    :try_start_2
    invoke-interface {v0, v8}, LX/DQY;->getLong(I)J

    .line 179
    .line 180
    .line 181
    move-result-wide v30

    .line 182
    invoke-interface {v0, v3}, LX/DQY;->isNull(I)Z

    .line 183
    .line 184
    .line 185
    move-result v6

    .line 186
    if-eqz v6, :cond_2

    .line 187
    .line 188
    move-object/from16 v32, p0

    .line 189
    .line 190
    goto :goto_3

    .line 191
    :cond_2
    invoke-interface {v0, v3}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v32

    .line 195
    :goto_3
    invoke-interface {v0, v2}, LX/DQY;->isNull(I)Z

    .line 196
    .line 197
    .line 198
    move-result v6

    .line 199
    if-nez v6, :cond_3

    .line 200
    .line 201
    invoke-interface {v0, v2}, LX/DQY;->getBlob(I)[B

    .line 202
    .line 203
    .line 204
    move-result-object p0

    .line 205
    :cond_3
    invoke-static {v0, v7}, LX/IEa;->A05(LX/DQY;I)I

    .line 206
    .line 207
    .line 208
    move-result v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 209
    invoke-static {v6}, LX/003;->A1B(I)Z

    .line 210
    .line 211
    .line 212
    move-result p1

    .line 213
    :try_start_3
    new-instance v6, Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;

    .line 214
    .line 215
    move-object/from16 v17, v6

    .line 216
    .line 217
    invoke-direct/range {v17 .. v34}, Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;-><init>(Ljava/lang/String;Ljava/lang/String;[B[BJJZLjava/lang/String;IZJLjava/lang/String;[BZ)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v1, v6}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 221
    .line 222
    .line 223
    goto :goto_0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 224
    :cond_4
    invoke-interface {v0}, LX/DQY;->close()V

    .line 225
    .line 226
    .line 227
    return-object v1

    .line 228
    :catchall_0
    move-exception v1

    .line 229
    invoke-interface {v0}, LX/DQY;->close()V

    .line 230
    .line 231
    .line 232
    throw v1
.end method

.method public static synthetic lambda$oldestEvictableThread$0(Ljava/lang/String;Ljava/lang/String;LX/Bpd;)Ljava/lang/String;
    .locals 1

    .line 0
    const-string v0, "SELECT session_id FROM offline_threads WHERE vm_id = ? AND session_id != ? ORDER BY last_opened_at ASC LIMIT 1"

    .line 1
    .line 2
    invoke-interface {p2, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object p2

    .line 6
    :try_start_0
    invoke-static {p2, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-interface {p2}, LX/DQY;->Ags()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 p1, 0x0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 p0, 0x0

    .line 17
    invoke-interface {p2, p0}, LX/DQY;->isNull(I)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-interface {p2, p0}, LX/DQY;->ALe(I)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    :cond_0
    invoke-interface {p2}, LX/DQY;->close()V

    .line 28
    .line 29
    .line 30
    return-object p1

    .line 31
    :catchall_0
    move-exception v0

    .line 32
    invoke-interface {p2}, LX/DQY;->close()V

    .line 33
    .line 34
    .line 35
    throw v0
.end method

.method public static synthetic lambda$totalJsonBytes$0(Ljava/lang/String;LX/Bpd;)Ljava/lang/Long;
    .locals 1

    .line 0
    const-string v0, "SELECT COALESCE(SUM(LENGTH(json)), 0) FROM offline_messages WHERE vm_id = ?"

    .line 1
    .line 2
    invoke-interface {p1, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    const/4 v0, 0x1

    .line 7
    :try_start_0
    invoke-interface {p1, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p1}, LX/DQY;->Ags()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    invoke-interface {p1, v0}, LX/DQY;->getLong(I)J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    :goto_0
    invoke-static {v0, p0}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    goto :goto_1

    .line 26
    :cond_0
    const-wide/16 v0, 0x0

    .line 27
    .line 28
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    :goto_1
    invoke-interface {p1}, LX/DQY;->close()V

    .line 30
    .line 31
    .line 32
    return-object v0

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    invoke-interface {p1}, LX/DQY;->close()V

    .line 35
    .line 36
    .line 37
    throw v0
.end method

.method public static synthetic lambda$trimMessagesToCap$0(Ljava/lang/String;Ljava/lang/String;ILX/Bpd;)Ljava/lang/Object;
    .locals 4

    .line 0
    const-string v0, "DELETE FROM offline_messages WHERE vm_id = ? AND session_id = ? AND seq NOT IN (SELECT seq FROM offline_messages WHERE vm_id = ? AND session_id = ? ORDER BY seq DESC LIMIT ?)"

    .line 1
    .line 2
    invoke-interface {p3, v0}, LX/Bpd;->AYk(Ljava/lang/String;)LX/DQY;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    :try_start_0
    invoke-static {v3, p0, p1}, LX/IEa;->A13(LX/DQY;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    invoke-interface {v3, v0, p0}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x4

    .line 14
    invoke-interface {v3, v0, p1}, LX/DQY;->A5I(ILjava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x5

    .line 18
    int-to-long v0, p2

    .line 19
    invoke-interface {v3, v2, v0, v1}, LX/DQY;->A5F(IJ)V

    .line 20
    .line 21
    .line 22
    invoke-interface {v3}, LX/DQY;->Ags()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    .line 24
    .line 25
    invoke-interface {v3}, LX/DQY;->close()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    return-object v0

    .line 30
    :catchall_0
    move-exception v0

    .line 31
    invoke-interface {v3}, LX/DQY;->close()V

    .line 32
    .line 33
    .line 34
    throw v0
.end method


# virtual methods
.method public clearAllDataKeys()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda4;

    .line 3
    .line 4
    invoke-direct {v0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda4;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public clearAllMessages()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda2;

    .line 3
    .line 4
    invoke-direct {v0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda2;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public clearAllThreads()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda18;

    .line 3
    .line 4
    invoke-direct {v0}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda18;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteMessagesBySeq(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const-string v0, "DELETE FROM offline_messages WHERE vm_id = ? AND session_id = ? AND seq IN ("

    .line 5
    .line 6
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {v1, v0}, LX/Hs7;->A00(Ljava/lang/StringBuilder;I)V

    .line 14
    .line 15
    .line 16
    invoke-static {v1}, LX/007;->A11(Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    iget-object v1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 21
    .line 22
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda8;

    .line 23
    .line 24
    invoke-direct {v0, v2, p1, p2, p3}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda8;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 25
    .line 26
    .line 27
    invoke-static {v1, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public deleteMessagesExceptVm(Ljava/lang/String;)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda19;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda19;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteMessagesForEvictedThreads(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda16;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda16;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteMessagesForSession(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda11;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda11;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteThread(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda12;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda12;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteThreadsBeyondLru(Ljava/lang/String;I)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda0;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public deleteThreadsExceptVm(Ljava/lang/String;)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda21;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda21;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public getThread(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda9;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda9;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;

    .line 12
    .line 13
    return-object v0
.end method

.method public synthetic lambda$upsertDataKey$0$com-facebook-aura-conversation-offline-HatchOfflineConversationDao_Impl(Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;LX/Bpd;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineKeyEntity:LX/IBa;

    .line 1
    .line 2
    invoke-virtual {p0, p2, p1}, LX/IBa;->insert(LX/Bpd;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0
.end method

.method public synthetic lambda$upsertMessages$0$com-facebook-aura-conversation-offline-HatchOfflineConversationDao_Impl(Ljava/util/List;LX/Bpd;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineMessageEntity:LX/IBa;

    .line 1
    .line 2
    invoke-virtual {p0, p2, p1}, LX/IBa;->insert(LX/Bpd;Ljava/lang/Iterable;)V

    .line 3
    .line 4
    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0
.end method

.method public synthetic lambda$upsertThread$0$com-facebook-aura-conversation-offline-HatchOfflineConversationDao_Impl(Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;LX/Bpd;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineThreadEntity:LX/IBa;

    .line 1
    .line 2
    invoke-virtual {p0, p2, p1}, LX/IBa;->insert(LX/Bpd;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    const/4 p0, 0x0

    .line 6
    return-object p0
.end method

.method public loadDataKey(I)Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda10;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda10;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;

    .line 12
    .line 13
    return-object v0
.end method

.method public loadLatestMessages(Ljava/lang/String;Ljava/lang/String;I)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda5;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda5;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/List;

    .line 12
    .line 13
    return-object v0
.end method

.method public loadMessage(Ljava/lang/String;Ljava/lang/String;J)Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda6;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda6;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;

    .line 12
    .line 13
    return-object v0
.end method

.method public loadMessagesBefore(Ljava/lang/String;Ljava/lang/String;JI)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "JI)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda13;

    .line 3
    .line 4
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda13;-><init>(Ljava/lang/String;Ljava/lang/String;JI)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0, p0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/List;

    .line 12
    .line 13
    return-object v0
.end method

.method public loadMessagesPage(Ljava/lang/String;II)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "II)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;-><init>(Ljava/lang/String;II)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/List;

    .line 12
    .line 13
    return-object v0
.end method

.method public loadThreads(Ljava/lang/String;)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda14;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda14;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/List;

    .line 12
    .line 13
    return-object v0
.end method

.method public oldestEvictableThread(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda1;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/String;

    .line 12
    .line 13
    return-object v0
.end method

.method public totalJsonBytes(Ljava/lang/String;)J
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda3;

    .line 3
    .line 4
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A0b(LX/DPY;LX/JDM;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    return-wide v0
.end method

.method public trimMessagesToCap(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda22;

    .line 3
    .line 4
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda22;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public upsertDataKey(Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;

    .line 6
    .line 7
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v1, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public upsertMessages(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntity;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda20;

    .line 6
    .line 7
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda20;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;Ljava/util/List;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v1, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public upsertThread(Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__db:LX/DPY;

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda15;

    .line 6
    .line 7
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda15;-><init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;Lcom/facebook/aura/conversation/offline/HatchOfflineThreadEntity;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v1, v0}, LX/IEa;->A12(LX/DPY;LX/JDM;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
