.class public Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl$1;
.super LX/DPl;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl$1;->this$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl;

    .line 1
    .line 2
    invoke-direct {p0, p2, p3, p4}, LX/DPl;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public createAllTables(LX/Bpd;)V
    .locals 0

    .line 0
    const-string p0, "CREATE TABLE IF NOT EXISTS `offline_messages` (`vm_id` TEXT NOT NULL, `session_id` TEXT NOT NULL, `seq` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, `server_message_id` TEXT, `role` TEXT NOT NULL, `json` BLOB NOT NULL, PRIMARY KEY(`vm_id`, `session_id`, `seq`))"

    .line 1
    .line 2
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    const-string p0, "CREATE INDEX IF NOT EXISTS `index_offline_messages_timestamp` ON `offline_messages` (`timestamp`)"

    .line 6
    .line 7
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string p0, "CREATE TABLE IF NOT EXISTS `offline_threads` (`vm_id` TEXT NOT NULL, `session_id` TEXT NOT NULL, `title` BLOB, `snippet` BLOB, `created_at` INTEGER NOT NULL, `updated_at` INTEGER NOT NULL, `is_thread` INTEGER NOT NULL, `status` TEXT NOT NULL, `unread_count` INTEGER NOT NULL, `is_pinned` INTEGER NOT NULL, `last_opened_at` INTEGER NOT NULL, `channel` TEXT, `account_username` BLOB, `can_send_messages` INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(`vm_id`, `session_id`))"

    .line 11
    .line 12
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string p0, "CREATE TABLE IF NOT EXISTS `offline_keys` (`id` INTEGER NOT NULL, `wrapped_key` BLOB NOT NULL, PRIMARY KEY(`id`))"

    .line 16
    .line 17
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const-string p0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 21
    .line 22
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const-string p0, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'3411a1c9f95eef5e0a6921cac1d5eb8b\')"

    .line 26
    .line 27
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public dropAllTables(LX/Bpd;)V
    .locals 0

    .line 0
    const-string p0, "DROP TABLE IF EXISTS `offline_messages`"

    .line 1
    .line 2
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 3
    .line 4
    .line 5
    const-string p0, "DROP TABLE IF EXISTS `offline_threads`"

    .line 6
    .line 7
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string p0, "DROP TABLE IF EXISTS `offline_keys`"

    .line 11
    .line 12
    invoke-static {p1, p0}, LX/Bpc;->A00(LX/Bpd;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onCreate(LX/Bpd;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onOpen(LX/Bpd;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl$1;->this$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDatabase_Impl;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, LX/DPY;->internalInitInvalidationTracker(LX/Bpd;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public onPostMigrate(LX/Bpd;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onPreMigrate(LX/Bpd;)V
    .locals 0

    .line 0
    invoke-static {p1}, LX/BqS;->A00(LX/Bpd;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public onValidateSchema(LX/Bpd;)LX/DPt;
    .locals 20

    .line 0
    const/4 v0, 0x7

    .line 1
    new-instance v4, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v4, v0}, Ljava/util/HashMap;-><init>(I)V

    .line 4
    .line 5
    .line 6
    const/4 v12, 0x0

    .line 7
    const/4 v14, 0x1

    .line 8
    const-string v7, "vm_id"

    .line 9
    .line 10
    const-string v11, "TEXT"

    .line 11
    .line 12
    invoke-static {v7, v11, v4}, LX/IEa;->A1H(Ljava/lang/String;Ljava/lang/String;Ljava/util/AbstractMap;)V

    .line 13
    .line 14
    .line 15
    const-string v6, "session_id"

    .line 16
    .line 17
    const/4 v0, 0x2

    .line 18
    invoke-static {v6, v11, v12, v0}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v4, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    const-string v2, "seq"

    .line 26
    .line 27
    const-string v1, "INTEGER"

    .line 28
    .line 29
    const/4 v0, 0x3

    .line 30
    invoke-static {v2, v1, v12, v0}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v4, v2, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    const-string v8, "timestamp"

    .line 38
    .line 39
    const/4 v13, 0x0

    .line 40
    invoke-static {v8, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {v4, v8, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    const-string v10, "server_message_id"

    .line 48
    .line 49
    new-instance v9, LX/DR2;

    .line 50
    .line 51
    move v15, v13

    .line 52
    invoke-direct/range {v9 .. v15}, LX/DR2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v4, v10, v9}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    const-string v2, "role"

    .line 59
    .line 60
    invoke-static {v2, v11, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v4, v2, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    const-string v3, "json"

    .line 68
    .line 69
    const-string v2, "BLOB"

    .line 70
    .line 71
    invoke-static {v3, v2, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v4, v3, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    new-instance v9, Ljava/util/HashSet;

    .line 79
    .line 80
    invoke-direct {v9, v13}, Ljava/util/HashSet;-><init>(I)V

    .line 81
    .line 82
    .line 83
    new-instance v5, Ljava/util/HashSet;

    .line 84
    .line 85
    invoke-direct {v5, v14}, Ljava/util/HashSet;-><init>(I)V

    .line 86
    .line 87
    .line 88
    filled-new-array {v8}, [Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    const-string v0, "ASC"

    .line 97
    .line 98
    filled-new-array {v0}, [Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    const-string v0, "index_offline_messages_timestamp"

    .line 107
    .line 108
    invoke-static {v0, v5, v8, v3}, LX/IEa;->A1I(Ljava/lang/String;Ljava/util/AbstractCollection;Ljava/util/List;Ljava/util/List;)V

    .line 109
    .line 110
    .line 111
    const/16 v0, 0x3a

    .line 112
    .line 113
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    new-instance v8, LX/DR3;

    .line 118
    .line 119
    invoke-direct {v8, v0, v4, v9, v5}, LX/DR3;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    .line 120
    .line 121
    .line 122
    move-object/from16 v4, p1

    .line 123
    .line 124
    invoke-static {v4, v13}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 125
    .line 126
    .line 127
    invoke-static {v4, v0}, LX/DQU;->A00(LX/Bpd;Ljava/lang/String;)LX/DR3;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    invoke-virtual {v8, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    const-string v3, "\n Found:\n"

    .line 136
    .line 137
    if-nez v0, :cond_0

    .line 138
    .line 139
    const-string v0, "offline_messages(com.facebook.aura.conversation.offline.HatchOfflineMessageEntity).\n Expected:\n"

    .line 140
    .line 141
    invoke-static {v8, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    :goto_0
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    new-instance v0, LX/DPt;

    .line 156
    .line 157
    invoke-direct {v0, v13, v1}, LX/DPt;-><init>(ZLjava/lang/String;)V

    .line 158
    .line 159
    .line 160
    return-object v0

    .line 161
    :cond_0
    const/16 v0, 0xe

    .line 162
    .line 163
    new-instance v5, Ljava/util/HashMap;

    .line 164
    .line 165
    invoke-direct {v5, v0}, Ljava/util/HashMap;-><init>(I)V

    .line 166
    .line 167
    .line 168
    invoke-static {v7, v11, v5}, LX/IEa;->A1H(Ljava/lang/String;Ljava/lang/String;Ljava/util/AbstractMap;)V

    .line 169
    .line 170
    .line 171
    const/4 v7, 0x2

    .line 172
    invoke-static {v6, v11, v12, v7}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    const-string v0, "title"

    .line 180
    .line 181
    new-instance v15, LX/DR2;

    .line 182
    .line 183
    move-object/from16 v18, v12

    .line 184
    .line 185
    move/from16 v19, v13

    .line 186
    .line 187
    move/from16 p0, v14

    .line 188
    .line 189
    move/from16 p1, v13

    .line 190
    .line 191
    move-object/from16 v17, v2

    .line 192
    .line 193
    move-object/from16 v16, v0

    .line 194
    .line 195
    invoke-direct/range {v15 .. v21}, LX/DR2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v5, v0, v15}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    const-string v0, "snippet"

    .line 202
    .line 203
    new-instance v15, LX/DR2;

    .line 204
    .line 205
    move-object/from16 v16, v0

    .line 206
    .line 207
    invoke-direct/range {v15 .. v21}, LX/DR2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v5, v0, v15}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    const-string v6, "created_at"

    .line 214
    .line 215
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    const-string v6, "updated_at"

    .line 223
    .line 224
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    const-string v6, "is_thread"

    .line 232
    .line 233
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    const-string v6, "status"

    .line 241
    .line 242
    invoke-static {v6, v11, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    const-string v6, "unread_count"

    .line 250
    .line 251
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    const-string v6, "is_pinned"

    .line 259
    .line 260
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    const-string v6, "last_opened_at"

    .line 268
    .line 269
    invoke-static {v6, v1, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 270
    .line 271
    .line 272
    move-result-object v0

    .line 273
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    const-string v6, "channel"

    .line 277
    .line 278
    new-instance v0, LX/DR2;

    .line 279
    .line 280
    move-object v9, v0

    .line 281
    move-object v10, v6

    .line 282
    move v15, v13

    .line 283
    invoke-direct/range {v9 .. v15}, LX/DR2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    const-string v10, "account_username"

    .line 290
    .line 291
    new-instance v9, LX/DR2;

    .line 292
    .line 293
    move-object v11, v2

    .line 294
    invoke-direct/range {v9 .. v15}, LX/DR2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v5, v10, v9}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    const-string v0, "1"

    .line 301
    .line 302
    const-string v6, "can_send_messages"

    .line 303
    .line 304
    invoke-static {v6, v1, v0, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 305
    .line 306
    .line 307
    move-result-object v0

    .line 308
    invoke-virtual {v5, v6, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 309
    .line 310
    .line 311
    new-instance v9, Ljava/util/HashSet;

    .line 312
    .line 313
    invoke-direct {v9, v13}, Ljava/util/HashSet;-><init>(I)V

    .line 314
    .line 315
    .line 316
    new-instance v8, Ljava/util/HashSet;

    .line 317
    .line 318
    invoke-direct {v8, v13}, Ljava/util/HashSet;-><init>(I)V

    .line 319
    .line 320
    .line 321
    const/16 v0, 0x3b

    .line 322
    .line 323
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    new-instance v6, LX/DR3;

    .line 328
    .line 329
    invoke-direct {v6, v0, v5, v9, v8}, LX/DR3;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    .line 330
    .line 331
    .line 332
    invoke-static {v4, v0}, LX/DQU;->A00(LX/Bpd;Ljava/lang/String;)LX/DR3;

    .line 333
    .line 334
    .line 335
    move-result-object v5

    .line 336
    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 337
    .line 338
    .line 339
    move-result v0

    .line 340
    if-nez v0, :cond_1

    .line 341
    .line 342
    const-string v0, "offline_threads(com.facebook.aura.conversation.offline.HatchOfflineThreadEntity).\n Expected:\n"

    .line 343
    .line 344
    :goto_1
    invoke-static {v6, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 345
    .line 346
    .line 347
    move-result-object v0

    .line 348
    goto/16 :goto_0

    .line 349
    .line 350
    :cond_1
    new-instance v5, Ljava/util/HashMap;

    .line 351
    .line 352
    invoke-direct {v5, v7}, Ljava/util/HashMap;-><init>(I)V

    .line 353
    .line 354
    .line 355
    const-string v0, "id"

    .line 356
    .line 357
    invoke-static {v0, v1, v5}, LX/IEa;->A1H(Ljava/lang/String;Ljava/lang/String;Ljava/util/AbstractMap;)V

    .line 358
    .line 359
    .line 360
    const-string v1, "wrapped_key"

    .line 361
    .line 362
    invoke-static {v1, v2, v12, v13}, LX/IEa;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)LX/DR2;

    .line 363
    .line 364
    .line 365
    move-result-object v0

    .line 366
    invoke-virtual {v5, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    new-instance v2, Ljava/util/HashSet;

    .line 370
    .line 371
    invoke-direct {v2, v13}, Ljava/util/HashSet;-><init>(I)V

    .line 372
    .line 373
    .line 374
    new-instance v1, Ljava/util/HashSet;

    .line 375
    .line 376
    invoke-direct {v1, v13}, Ljava/util/HashSet;-><init>(I)V

    .line 377
    .line 378
    .line 379
    const/16 v0, 0x39

    .line 380
    .line 381
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v0

    .line 385
    new-instance v6, LX/DR3;

    .line 386
    .line 387
    invoke-direct {v6, v0, v5, v2, v1}, LX/DR3;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    .line 388
    .line 389
    .line 390
    invoke-static {v4, v0}, LX/DQU;->A00(LX/Bpd;Ljava/lang/String;)LX/DR3;

    .line 391
    .line 392
    .line 393
    move-result-object v5

    .line 394
    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    move-result v0

    .line 398
    if-nez v0, :cond_2

    .line 399
    .line 400
    const-string v0, "offline_keys(com.facebook.aura.conversation.offline.HatchOfflineKeyEntity).\n Expected:\n"

    .line 401
    .line 402
    goto :goto_1

    .line 403
    :cond_2
    new-instance v0, LX/DPt;

    .line 404
    .line 405
    invoke-direct {v0, v14, v12}, LX/DPt;-><init>(ZLjava/lang/String;)V

    .line 406
    .line 407
    .line 408
    return-object v0
.end method
