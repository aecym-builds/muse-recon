.class public final synthetic Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:I

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$0:Ljava/lang/String;

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$1:I

    .line 6
    .line 7
    iput p3, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$2:I

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$0:Ljava/lang/String;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$1:I

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda7;->f$2:I

    .line 5
    .line 6
    check-cast p1, LX/Bpd;

    .line 7
    .line 8
    invoke-static {v2, v1, v0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->lambda$loadMessagesPage$0(Ljava/lang/String;IILX/Bpd;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
