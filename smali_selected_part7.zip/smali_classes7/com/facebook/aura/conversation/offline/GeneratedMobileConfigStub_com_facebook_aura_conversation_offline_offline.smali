.class public interface abstract Lcom/facebook/aura/conversation/offline/GeneratedMobileConfigStub_com_facebook_aura_conversation_offline_offline;
.super Ljava/lang/Object;
.source ""
