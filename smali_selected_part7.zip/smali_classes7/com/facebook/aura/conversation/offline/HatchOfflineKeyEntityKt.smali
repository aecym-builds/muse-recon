.class public abstract Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntityKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final OFFLINE_DATA_KEY_ROW_ID:I = 0x1
