.class public abstract Lcom/facebook/aura/conversation/offline/HatchOfflineMessageEntityKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final MAX_MESSAGE_BLOB_BYTES:I = 0x80000
