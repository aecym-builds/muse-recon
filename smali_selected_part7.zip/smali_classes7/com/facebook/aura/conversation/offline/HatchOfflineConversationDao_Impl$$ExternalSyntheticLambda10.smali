.class public final synthetic Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# instance fields
.field public final synthetic f$0:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda10;->f$0:I

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda10;->f$0:I

    .line 1
    .line 2
    check-cast p1, LX/Bpd;

    .line 3
    .line 4
    invoke-static {p0, p1}, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->lambda$loadDataKey$0(ILX/Bpd;)Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method
