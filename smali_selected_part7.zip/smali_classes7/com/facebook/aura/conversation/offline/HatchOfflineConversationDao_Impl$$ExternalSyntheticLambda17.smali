.class public final synthetic Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# instance fields
.field public final synthetic f$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;

.field public final synthetic f$1:Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;


# direct methods
.method public synthetic constructor <init>(Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;->f$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;->f$1:Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;->f$0:Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl$$ExternalSyntheticLambda17;->f$1:Lcom/facebook/aura/conversation/offline/HatchOfflineKeyEntity;

    .line 3
    .line 4
    check-cast p1, LX/Bpd;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/conversation/offline/HatchOfflineConversationDao_Impl;->__insertAdapterOfHatchOfflineKeyEntity:LX/IBa;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p0}, LX/IBa;->insert(LX/Bpd;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0
.end method
