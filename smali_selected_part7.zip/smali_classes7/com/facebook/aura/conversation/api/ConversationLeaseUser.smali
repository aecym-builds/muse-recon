.class public interface abstract Lcom/facebook/aura/conversation/api/ConversationLeaseUser;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract holdsConversationLeases()Z
.end method
