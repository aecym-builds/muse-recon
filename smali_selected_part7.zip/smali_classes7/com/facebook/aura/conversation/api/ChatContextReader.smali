.class public interface abstract Lcom/facebook/aura/conversation/api/ChatContextReader;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract readsChatContext()Z
.end method
