.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final appContext:Landroid/content/Context;

.field public final id:I

.field public volatile isReady:Z

.field public final pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "LX/JDM<",
            "Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public volatile rendererGone:Z

.field public volatile timedOut:Z

.field public webView:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>(ILandroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->id:I

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->appContext:Landroid/content/Context;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {v0}, LX/EYt;->A1C(Ljava/lang/Object;)Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    .line 18
    return-void
.end method

.method public static final synthetic access$captureBitmap(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;IIII)Landroid/graphics/Bitmap;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->captureBitmap(IIII)Landroid/graphics/Bitmap;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final captureBitmap(IIII)Landroid/graphics/Bitmap;
    .locals 6

    .line 0
    sget-object v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->INSTANCE:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;

    .line 1
    .line 2
    invoke-static {v0, p3, p4}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->access$isBitmapSizeAllowed(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;II)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/4 v5, 0x0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    return-object v5

    .line 10
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    const/high16 v0, 0x40000000    # 2.0f

    .line 15
    .line 16
    const/16 v3, 0x1000

    .line 17
    .line 18
    invoke-static {v3, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/16 v2, 0x800

    .line 23
    .line 24
    invoke-static {v2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-virtual {v4, v1, v0}, Landroid/view/View;->measure(II)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    const/4 v0, 0x0

    .line 36
    invoke-virtual {v1, v0, v0, v3, v2}, Landroid/view/View;->layout(IIII)V

    .line 37
    .line 38
    .line 39
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 40
    .line 41
    invoke-static {p3, p4, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    invoke-static {v3}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    new-instance v2, Landroid/graphics/Canvas;

    .line 49
    .line 50
    invoke-direct {v2, v3}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 51
    .line 52
    .line 53
    int-to-float v0, p1

    .line 54
    neg-float v1, v0

    .line 55
    int-to-float v0, p2

    .line 56
    neg-float v0, v0

    .line 57
    invoke-virtual {v2, v1, v0}, Landroid/graphics/Canvas;->translate(FF)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v0, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 65
    .line 66
    .line 67
    return-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    :catchall_0
    move-exception v2

    .line 69
    iget v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->id:I

    .line 70
    .line 71
    const-string v0, "Failed to capture KaTeX bitmap from pooled WebView "

    .line 72
    .line 73
    invoke-static {v0, v1}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    const-string v0, "HatchKatexRenderer"

    .line 78
    .line 79
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 80
    .line 81
    .line 82
    return-object v5
.end method


# virtual methods
.method public final destroy()V
    .locals 2

    .line 0
    new-instance v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;

    .line 1
    .line 2
    invoke-direct {v1, p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;-><init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V

    .line 3
    .line 4
    .line 5
    invoke-static {}, LX/004;->A1O()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->run()V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    sget-object v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->uiHandler:Landroid/os/Handler;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final getAppContext()Landroid/content/Context;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->appContext:Landroid/content/Context;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getId()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->id:I

    .line 1
    .line 2
    return p0
.end method

.method public final getPendingCallback()Ljava/util/concurrent/atomic/AtomicReference;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "LX/JDM<",
            "Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRendererGone()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->rendererGone:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getTimedOut()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->timedOut:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getWebView()Landroid/webkit/WebView;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->webView:Landroid/webkit/WebView;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    return-object p0

    .line 5
    :cond_0
    const-string p0, "webView"

    .line 6
    .line 7
    invoke-static {p0}, LX/I1c;->A0i(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    throw p0
.end method

.method public final initOnUiThread()V
    .locals 10

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->appContext:Landroid/content/Context;

    .line 1
    .line 2
    new-instance v4, Landroid/webkit/WebView;

    .line 3
    .line 4
    invoke-direct {v4, v0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    .line 5
    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    invoke-virtual {v4, v3, v5}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-virtual {v4, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 14
    .line 15
    .line 16
    const/16 v1, 0x1000

    .line 17
    .line 18
    const/16 v0, 0x800

    .line 19
    .line 20
    invoke-virtual {v4, v2, v2, v1, v0}, Landroid/view/View;->layout(IIII)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v4}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 28
    .line 29
    .line 30
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;

    .line 31
    .line 32
    invoke-direct {v0, p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;-><init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v4, v0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 36
    .line 37
    .line 38
    new-instance v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;

    .line 39
    .line 40
    invoke-direct {v1, p0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;-><init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V

    .line 41
    .line 42
    .line 43
    const-string v0, "KatexBridge"

    .line 44
    .line 45
    invoke-virtual {v4, v1, v0}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    sget v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->$stable:I

    .line 49
    .line 50
    const-string v6, "<!DOCTYPE html>\n<html>\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\">\n  <link rel=\"stylesheet\"\n        href=\"https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css\">\n  <script defer\n          src=\"https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js\"></script>\n  <style>\n    html, body { margin: 0; padding: 0; background: transparent; }\n    /* Inline-block so the container shrinks to the rendered KaTeX content\'s natural width,\n       not the body\'s width. Generous padding gives descenders / italic overhang and\n       KaTeX\'s negative-margin tricks (limits, accents) room before the captured bounds. */\n    #container { display: inline-block; padding: 6px 12px; white-space: nowrap; }\n    /* KaTeX block math defaults to display:block, which expands to parent width and centers\n       \u2014 we want the actual content width, so override. */\n    #container .katex-display { display: inline-block; margin: 0; }\n    #container > .katex { display: inline-block; }\n  </style>\n</head>\n<body>\n  <div id=\"container\"></div>\n  <script>\n    function renderKatex(expression, displayMode, textColor, density, fontSizeSp) {\n      try {\n        if (typeof katex === \'undefined\') {\n          KatexBridge.onRenderError(\'katex not loaded\');\n          return;\n        }\n        var container = document.getElementById(\'container\');\n        container.innerHTML = \'\';\n        container.style.color = textColor;\n        // Set the CSS font-size for the math container. KaTeX\'s stylesheet sets\n        // `.katex { font-size: 1.21em }`, which scales the rendered glyphs to ~1.21x\n        // the input \u2014 so passing the surrounding text\'s size as-is would yield math\n        // glyphs visibly larger than the body text. Divide by 1.21 here so the\n        // rendered glyph cap height matches the body text\'s; callers can keep passing\n        // the surrounding font size directly without being aware of KaTeX\'s internal\n        // scaling. Also: the WebView\'s CSS-to-device-px mapping is 1 CSS px = density\n        // device px (so 16 CSS px = 48 device px on xxhdpi); we compensate for that\n        // by multiplying the measured CSS-px dimensions by `density` below when\n        // bridging back to Android.\n        var KATEX_INTRINSIC_SCALE = 1.21;\n        var effectiveFontPx = (fontSizeSp || 16) / KATEX_INTRINSIC_SCALE;\n        container.style.fontSize = effectiveFontPx + \'px\';\n        katex.render(expression, container, {\n          displayMode: displayMode,\n          output: \'html\',\n          throwOnError: false,\n          strict: \'ignore\',\n        });\n        // KaTeX loads its math fonts (KaTeX_*.woff2) asynchronously. If we measure\n        // immediately, the layout is computed with fallback metrics \u2192 reported size is\n        // wrong \u2192 the bitmap captures a smaller region than the final rendered content.\n        // document.fonts.ready resolves once all @font-face fonts referenced by the\n        // current DOM have downloaded; one rAF after that ensures the post-load layout\n        // has been committed before we measure.\n        var fontsReady = (document.fonts && document.fonts.ready)\n          ? document.fonts.ready\n          : Promise.resolve();\n        fontsReady.then(function() {\n          requestAnimationFrame(function() {\n            // Measure the `.katex` (inline) or `.katex-display` (block) root element\n            // directly, then add fixed overhang padding to capture KaTeX\'s negative-\n            // margin glyphs (limits above big operators, accents, sqrt extenders).\n            //\n            // Why not union descendant bounds? KaTeX\'s HTML output contains `.vlist` and\n            // `.strut` elements whose `getBoundingClientRect` reports widths far beyond\n            // the actual painted content (vertical-layout helpers with absolute children\n            // that float to extreme positions). Unioning them inflated bitmaps to\n            // thousands of pixels of empty whitespace flanking a tiny strip of math.\n            // The .katex root\'s own bounds are tight to the visible glyph stack; the\n            // overhang padding is a small constant that handles the negative-margin\n            // ascenders/descenders without picking up off-flow helpers.\n            var katexRoot =\n                container.querySelector(\'.katex-display\') ||\n                container.querySelector(\'.katex\');\n            if (!katexRoot) {\n              KatexBridge.onRenderError(\'katex root element not found after render\');\n              return;\n            }\n            var rect = katexRoot.getBoundingClientRect();\n            var OVERHANG_TOP = 8;\n            var OVERHANG_BOTTOM = 4;\n            var OVERHANG_X = 4;\n            // Multiply CSS-px values by density to convert to device px. The WebView\n            // paints content at density-scaled positions on its drawing surface, so the\n            // captured Bitmap (allocated in device px and filled by wv.draw(canvas))\n            // must use device-px dimensions to encompass the full painted area.\n            var d = density || 1;\n            var offsetX = Math.floor((rect.left - OVERHANG_X) * d);\n            var offsetY = Math.floor((rect.top - OVERHANG_TOP) * d);\n            var width = Math.ceil((rect.width + OVERHANG_X * 2) * d);\n            var height = Math.ceil((rect.height + OVERHANG_TOP + OVERHANG_BOTTOM) * d);\n            KatexBridge.onMeasured(offsetX, offsetY, width, height);\n          });\n        });\n      } catch(e) {\n        KatexBridge.onRenderError(e.message || \'Unknown error\');\n      }\n    }\n  </script>\n</body>\n</html>"

    .line 51
    .line 52
    const-string v8, "UTF-8"

    .line 53
    .line 54
    const-string v7, "text/html"

    .line 55
    .line 56
    move-object v9, v5

    .line 57
    invoke-virtual/range {v4 .. v9}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    iput-object v4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->webView:Landroid/webkit/WebView;

    .line 61
    .line 62
    return-void
.end method

.method public final isReady()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->isReady:Z

    .line 1
    .line 2
    return p0
.end method

.method public final setReady(Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->isReady:Z

    .line 1
    .line 2
    return-void
.end method

.method public final setRendererGone(Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->rendererGone:Z

    .line 1
    .line 2
    return-void
.end method

.method public final setTimedOut(Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->timedOut:Z

    .line 1
    .line 2
    return-void
.end method

.method public final setWebView(Landroid/webkit/WebView;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->webView:Landroid/webkit/WebView;

    .line 5
    .line 6
    return-void
.end method
