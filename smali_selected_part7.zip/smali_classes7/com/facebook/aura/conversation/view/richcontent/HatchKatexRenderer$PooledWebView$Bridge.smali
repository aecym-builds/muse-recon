.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public static final synthetic access$captureMeasured(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;IIII)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->captureMeasured(IIII)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final captureMeasured(IIII)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    invoke-static {v0, p1, p2, p3, p4}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->access$captureBitmap(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;IIII)Landroid/graphics/Bitmap;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Success;

    .line 9
    .line 10
    invoke-direct {v0, v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Success;-><init>(Landroid/graphics/Bitmap;)V

    .line 11
    .line 12
    .line 13
    :goto_0
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 14
    .line 15
    iget-object v1, v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 16
    .line 17
    invoke-static {v1}, LX/IEa;->A0d(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, LX/JDM;

    .line 22
    .line 23
    if-eqz v1, :cond_0

    .line 24
    .line 25
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void

    .line 29
    :cond_1
    const-string v2, "Failed to capture WebView as bitmap ("

    .line 30
    .line 31
    const-string v1, "x"

    .line 32
    .line 33
    const-string v0, ")"

    .line 34
    .line 35
    invoke-static {v2, v1, v0, p3, p4}, LX/Gi8;->A0q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;

    .line 40
    .line 41
    invoke-direct {v0, v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    goto :goto_0
.end method


# virtual methods
.method public final onMeasured(IIII)V
    .locals 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->uiHandler:Landroid/os/Handler;

    .line 1
    .line 2
    iget-object v4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 3
    .line 4
    new-instance v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;

    .line 5
    .line 6
    move v2, p3

    .line 7
    move v3, p4

    .line 8
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;-><init>(IILcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;II)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final onRenderError(Ljava/lang/String;)V
    .locals 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 5
    .line 6
    iget v2, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->id:I

    .line 7
    .line 8
    const-string v1, "KaTeX render error on pooled WebView "

    .line 9
    .line 10
    const-string v0, ": "

    .line 11
    .line 12
    invoke-static {v1, v0, p1, v2}, LX/Gi8;->A0o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const-string v0, "HatchKatexRenderer"

    .line 17
    .line 18
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 22
    .line 23
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 24
    .line 25
    invoke-static {v0}, LX/IEa;->A0d(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    check-cast v1, LX/JDM;

    .line 30
    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;

    .line 34
    .line 35
    invoke-direct {v0, p1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    :cond_0
    return-void
.end method
