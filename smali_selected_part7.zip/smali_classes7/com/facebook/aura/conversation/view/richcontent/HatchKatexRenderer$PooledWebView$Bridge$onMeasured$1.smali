.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $height:I

.field public final synthetic $offsetX:I

.field public final synthetic $offsetY:I

.field public final synthetic $width:I

.field public final synthetic this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

.field public final synthetic this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;


# direct methods
.method public constructor <init>(IILcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;II)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$width:I

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$height:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$offsetX:I

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$offsetY:I

    .line 11
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 0
    sget-object v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->INSTANCE:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;

    .line 1
    .line 2
    iget v3, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$width:I

    .line 3
    .line 4
    iget v4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$height:I

    .line 5
    .line 6
    invoke-static {v0, v3, v4}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->access$isBitmapSizeAllowed(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 13
    .line 14
    iget v5, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->id:I

    .line 15
    .line 16
    const-string v0, "Rejected oversized KaTeX bitmap "

    .line 17
    .line 18
    const-string v1, "x"

    .line 19
    .line 20
    const-string v2, " on renderer "

    .line 21
    .line 22
    invoke-static/range {v0 .. v5}, LX/Gi8;->A0r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;III)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const-string v0, "HatchKatexRenderer"

    .line 27
    .line 28
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 32
    .line 33
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 34
    .line 35
    invoke-static {v0}, LX/IEa;->A0d(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, LX/JDM;

    .line 40
    .line 41
    if-eqz v2, :cond_0

    .line 42
    .line 43
    const-string v1, "Rendered math is too large to display"

    .line 44
    .line 45
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;

    .line 46
    .line 47
    invoke-direct {v0, v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {v2, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    :cond_0
    return-void

    .line 54
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 55
    .line 56
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 65
    .line 66
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    iget-object v4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 71
    .line 72
    iget-object v5, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;

    .line 73
    .line 74
    iget v6, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$offsetX:I

    .line 75
    .line 76
    iget v7, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$offsetY:I

    .line 77
    .line 78
    iget v8, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$width:I

    .line 79
    .line 80
    iget p0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1;->$height:I

    .line 81
    .line 82
    new-instance v3, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;

    .line 83
    .line 84
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;-><init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;IIII)V

    .line 85
    .line 86
    .line 87
    const-wide/16 v0, 0x0

    .line 88
    .line 89
    invoke-virtual {v2, v0, v1, v3}, Landroid/webkit/WebView;->postVisualStateCallback(JLandroid/webkit/WebView$VisualStateCallback;)V

    .line 90
    .line 91
    .line 92
    return-void
.end method
