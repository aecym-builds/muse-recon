.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Throwable;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

.field public final synthetic $timeoutRunnable:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Ljava/lang/Runnable;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->$pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->$timeoutRunnable:Ljava/lang/Runnable;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/Throwable;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->invoke(Ljava/lang/Throwable;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->$pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer;->uiHandler:Landroid/os/Handler;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->$timeoutRunnable:Ljava/lang/Runnable;

    .line 11
    .line 12
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$3;->$pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iput-boolean v0, v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->timedOut:Z

    .line 19
    .line 20
    return-void
.end method
