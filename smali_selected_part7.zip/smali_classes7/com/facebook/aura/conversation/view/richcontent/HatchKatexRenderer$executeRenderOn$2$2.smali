.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $js:Ljava/lang/String;

.field public final synthetic $pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$2;->$pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$2;->$js:Ljava/lang/String;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$2;->$pooled:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$executeRenderOn$2$2;->$js:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-virtual {v2, v1, v0}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
