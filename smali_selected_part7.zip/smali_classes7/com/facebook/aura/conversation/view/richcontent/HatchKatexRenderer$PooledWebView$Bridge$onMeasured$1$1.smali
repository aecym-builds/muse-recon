.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;
.super Landroid/webkit/WebView$VisualStateCallback;
.source ""


# instance fields
.field public final synthetic $height:I

.field public final synthetic $offsetX:I

.field public final synthetic $offsetY:I

.field public final synthetic $width:I

.field public final synthetic this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

.field public final synthetic this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;IIII)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$offsetX:I

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$offsetY:I

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$width:I

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$height:I

    .line 11
    .line 12
    invoke-direct {p0}, Landroid/webkit/WebView$VisualStateCallback;-><init>()V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public onComplete(J)V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v4, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->this$1:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;

    .line 11
    .line 12
    iget v3, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$offsetX:I

    .line 13
    .line 14
    iget v2, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$offsetY:I

    .line 15
    .line 16
    iget v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$width:I

    .line 17
    .line 18
    iget v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge$onMeasured$1$1;->$height:I

    .line 19
    .line 20
    invoke-static {v4, v3, v2, v1, v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;->access$captureMeasured(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$Bridge;IIII)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method
