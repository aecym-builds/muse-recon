.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    iput-boolean v0, v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->isReady:Z

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 6
    .line 7
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 8
    .line 9
    invoke-static {v0}, LX/IEa;->A0d(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    check-cast v2, LX/JDM;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    const-string v1, "Renderer released"

    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;

    .line 20
    .line 21
    invoke-direct {v0, v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {v2, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 28
    .line 29
    iget-object v0, v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->webView:Landroid/webkit/WebView;

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    :try_start_0
    invoke-virtual {v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v0, "KatexBridge"

    .line 38
    .line 39
    invoke-virtual {v1, v0}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    :catchall_0
    move-exception v0

    .line 44
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 45
    .line 46
    .line 47
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 48
    .line 49
    iget-boolean v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->rendererGone:Z

    .line 50
    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 54
    .line 55
    :try_start_1
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v0}, Landroid/webkit/WebView;->stopLoading()V

    .line 60
    .line 61
    .line 62
    goto :goto_1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 63
    :catchall_1
    move-exception v0

    .line 64
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 65
    .line 66
    .line 67
    :goto_1
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 68
    .line 69
    :try_start_2
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    const-string v0, "about:blank"

    .line 74
    .line 75
    invoke-virtual {v1, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    goto :goto_2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 79
    :catchall_2
    move-exception v0

    .line 80
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 81
    .line 82
    .line 83
    :goto_2
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 84
    .line 85
    :try_start_3
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {v0}, Landroid/webkit/WebView;->clearHistory()V

    .line 90
    .line 91
    .line 92
    goto :goto_3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 93
    :catchall_3
    move-exception v0

    .line 94
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 95
    .line 96
    .line 97
    :cond_1
    :goto_3
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 98
    .line 99
    :try_start_4
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 104
    .line 105
    .line 106
    goto :goto_4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 107
    :catchall_4
    move-exception v0

    .line 108
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 109
    .line 110
    .line 111
    :goto_4
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$destroy$destroyAction$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 112
    .line 113
    :try_start_5
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->getWebView()Landroid/webkit/WebView;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 118
    .line 119
    .line 120
    return-void
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 121
    :catchall_5
    move-exception v0

    .line 122
    invoke-static {v0}, LX/2PI;->A02(Ljava/lang/Throwable;)LX/2PH;

    .line 123
    .line 124
    .line 125
    :cond_2
    return-void
.end method
