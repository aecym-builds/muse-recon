.class public final Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;
.super Landroid/webkit/WebViewClient;
.source ""


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    const/4 p0, 0x1

    .line 3
    iput-boolean p0, p1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->isReady:Z

    .line 4
    .line 5
    return-void
.end method

.method public onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 1
    .line 2
    const/4 p1, 0x1

    .line 3
    iput-boolean p1, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->rendererGone:Z

    .line 4
    .line 5
    iget-object v1, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-boolean v0, v1, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->isReady:Z

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView$initOnUiThread$1$1;->this$0:Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$PooledWebView;->pendingCallback:Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    .line 14
    invoke-static {v0}, LX/IEa;->A0d(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    check-cast p0, LX/JDM;

    .line 19
    .line 20
    if-eqz p0, :cond_0

    .line 21
    .line 22
    const-string v1, "Renderer gone"

    .line 23
    .line 24
    new-instance v0, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;

    .line 25
    .line 26
    invoke-direct {v0, v1}, Lcom/facebook/aura/conversation/view/richcontent/HatchKatexRenderer$RenderResult$Error;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_0
    return p1
.end method
