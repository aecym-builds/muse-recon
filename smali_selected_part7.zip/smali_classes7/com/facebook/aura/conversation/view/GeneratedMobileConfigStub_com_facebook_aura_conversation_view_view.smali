.class public interface abstract Lcom/facebook/aura/conversation/view/GeneratedMobileConfigStub_com_facebook_aura_conversation_view_view;
.super Ljava/lang/Object;
.source ""
