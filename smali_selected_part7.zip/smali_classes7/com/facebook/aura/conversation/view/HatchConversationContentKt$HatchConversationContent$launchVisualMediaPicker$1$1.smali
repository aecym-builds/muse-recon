.class public final Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/JmT;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $filePickerLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $filePickerTitle:Ljava/lang/String;

.field public final synthetic $viewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

.field public final synthetic $visualMediaPickerLauncher:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;LX/166;Landroid/content/Context;LX/166;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;",
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;",
            "Landroid/content/Context;",
            "LX/166<",
            "Landroid/content/Intent;",
            "Landroidx/activity/result/ActivityResult;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$viewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$visualMediaPickerLauncher:LX/166;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$filePickerLauncher:LX/166;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$filePickerTitle:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/JmT;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->invoke(LX/JmT;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/JmT;)V
    .locals 12

    .line 0
    const/4 v8, 0x0

    .line 1
    invoke-static {p1, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$viewModel:Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/conversation/viewmodel/HatchConversationViewModel;->attachmentPickerLimit()Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_8

    .line 11
    .line 12
    iget-object v6, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$visualMediaPickerLauncher:LX/166;

    .line 13
    .line 14
    iget-object v11, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$context:Landroid/content/Context;

    .line 15
    .line 16
    iget-object v2, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$filePickerLauncher:LX/166;

    .line 17
    .line 18
    iget-object v4, p0, Lcom/facebook/aura/conversation/view/HatchConversationContentKt$HatchConversationContent$launchVisualMediaPicker$1$1;->$filePickerTitle:Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    invoke-static {}, LX/JJX;->A00()I

    .line 25
    .line 26
    .line 27
    move-result v10

    .line 28
    invoke-static {}, LX/JJX;->A00()I

    .line 29
    .line 30
    .line 31
    invoke-static {}, LX/JJX;->A00()I

    .line 32
    .line 33
    .line 34
    const/4 v3, 0x1

    .line 35
    if-le v5, v3, :cond_0

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    :try_start_0
    invoke-static {v11, p1}, LX/JJU;->A00(Landroid/content/Context;LX/JmT;)Landroid/content/Intent;

    .line 39
    .line 40
    .line 41
    move-result-object v7

    .line 42
    goto :goto_1

    .line 43
    :goto_0
    invoke-static {v11, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 44
    .line 45
    .line 46
    invoke-static {}, LX/JJU;->A04()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_2

    .line 51
    .line 52
    const-string v0, "android.provider.action.PICK_IMAGES"

    .line 53
    .line 54
    invoke-static {p1, v0}, LX/JJU;->A02(LX/JmT;Ljava/lang/String;)Landroid/content/Intent;

    .line 55
    .line 56
    .line 57
    move-result-object v7

    .line 58
    invoke-static {v5, v10}, Ljava/lang/Math;->min(II)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-le v1, v3, :cond_6

    .line 63
    .line 64
    invoke-static {}, Landroid/provider/MediaStore;->getPickImagesMaxLimit()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-gt v1, v0, :cond_6

    .line 69
    .line 70
    const-string v0, "android.provider.extra.PICK_IMAGES_MAX"

    .line 71
    .line 72
    invoke-virtual {v7, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 73
    .line 74
    .line 75
    const-string v0, "android.provider.extra.PICK_IMAGES_LAUNCH_TAB"

    .line 76
    .line 77
    invoke-virtual {v7, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 78
    .line 79
    .line 80
    const-string v0, "android.provider.extra.PICK_IMAGES_IN_ORDER"

    .line 81
    .line 82
    invoke-virtual {v7, v0, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 83
    .line 84
    .line 85
    :cond_1
    :goto_1
    invoke-virtual {v6, v7}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    goto :goto_2

    .line 89
    :cond_2
    invoke-virtual {v11}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    const-string v9, "androidx.activity.result.contract.action.PICK_IMAGES"

    .line 94
    .line 95
    new-instance v0, Landroid/content/Intent;

    .line 96
    .line 97
    invoke-direct {v0, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    const/high16 v7, 0x110000

    .line 101
    .line 102
    invoke-virtual {v1, v0, v7}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    if-eqz v0, :cond_3

    .line 107
    .line 108
    invoke-virtual {v11}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    new-instance v0, Landroid/content/Intent;

    .line 113
    .line 114
    invoke-direct {v0, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v1, v0, v7}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    if-eqz v0, :cond_5

    .line 122
    .line 123
    invoke-static {v0, p1}, LX/JJU;->A01(Landroid/content/pm/ResolveInfo;LX/JmT;)Landroid/content/Intent;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    invoke-static {v5, v10}, Ljava/lang/Math;->min(II)I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    if-le v1, v3, :cond_4

    .line 132
    .line 133
    const-string v0, "androidx.activity.result.contract.extra.PICK_IMAGES_MAX"

    .line 134
    .line 135
    invoke-virtual {v7, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 136
    .line 137
    .line 138
    const-string v0, "androidx.activity.result.contract.extra.PICK_IMAGES_LAUNCH_TAB"

    .line 139
    .line 140
    invoke-virtual {v7, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 141
    .line 142
    .line 143
    const-string v0, "androidx.activity.result.contract.extra.PICK_IMAGES_IN_ORDER"

    .line 144
    .line 145
    invoke-virtual {v7, v0, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 146
    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_3
    const/16 v0, 0x9

    .line 150
    .line 151
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-static {p1, v0}, LX/JJU;->A02(LX/JmT;Ljava/lang/String;)Landroid/content/Intent;

    .line 156
    .line 157
    .line 158
    move-result-object v7

    .line 159
    const/4 v0, 0x2

    .line 160
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-virtual {v7, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 165
    .line 166
    .line 167
    invoke-virtual {v7}, Landroid/content/Intent;->getType()Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    if-nez v0, :cond_1

    .line 172
    .line 173
    const-string v0, "*/*"

    .line 174
    .line 175
    invoke-virtual {v7, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 176
    .line 177
    .line 178
    const-string v1, "image/*"

    .line 179
    .line 180
    const-string v0, "video/*"

    .line 181
    .line 182
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v1

    .line 186
    const/16 v0, 0xc

    .line 187
    .line 188
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-virtual {v7, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 193
    .line 194
    .line 195
    goto :goto_1

    .line 196
    :goto_2
    return-void

    .line 197
    :cond_4
    const-string v0, "Max items must be greater than 1"

    .line 198
    .line 199
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    goto :goto_3

    .line 204
    :cond_5
    invoke-static {}, LX/006;->A0p()Ljava/lang/IllegalStateException;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    goto :goto_3

    .line 209
    :cond_6
    const-string v0, "Max items must be greater than 1 and lesser than or equal to MediaStore.getPickImagesMaxLimit()"

    .line 210
    .line 211
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    :goto_3
    throw v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 216
    :catch_0
    const/16 v0, 0x15

    .line 217
    .line 218
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    new-instance v1, Landroid/content/Intent;

    .line 223
    .line 224
    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    const/16 v0, 0xb

    .line 228
    .line 229
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    invoke-virtual {v1, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 234
    .line 235
    .line 236
    sget-object v0, LX/Jm4;->A00:LX/Jm4;

    .line 237
    .line 238
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    move-result v0

    .line 242
    if-eqz v0, :cond_9

    .line 243
    .line 244
    const-string v0, "video/*"

    .line 245
    .line 246
    :goto_4
    invoke-virtual {v1, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 247
    .line 248
    .line 249
    if-gt v5, v3, :cond_7

    .line 250
    .line 251
    const/4 v3, 0x0

    .line 252
    :cond_7
    const/4 v0, 0x2

    .line 253
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    invoke-virtual {v1, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 258
    .line 259
    .line 260
    invoke-static {v1, v4}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v2, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    :cond_8
    return-void

    .line 271
    :cond_9
    const-string v0, "image/*"

    .line 272
    .line 273
    goto :goto_4
.end method
