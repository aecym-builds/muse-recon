.class public interface abstract Lcom/facebook/aura/conversation/repo/GeneratedMobileConfigStub_com_facebook_aura_conversation_repo_repo;
.super Ljava/lang/Object;
.source ""
