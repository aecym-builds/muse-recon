.class public final Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $requestId$inlined:Ljava/lang/String;

.field public final synthetic $this_unsafeFlow:LX/39x;


# direct methods
.method public constructor <init>(LX/39x;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;->$requestId$inlined:Ljava/lang/String;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 8

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_4

    .line 3
    .line 4
    move-object v7, p2

    .line 5
    check-cast v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 6
    .line 7
    iget v2, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_4

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v5, :cond_5

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v6

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v4, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Lcom/facebook/aura/conversation/repo/HatchConversationState;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/conversation/repo/HatchConversationState;->messages:Ljava/util/List;

    .line 43
    .line 44
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    :cond_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    const/4 v2, 0x0

    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    move-object v0, v2

    .line 60
    check-cast v0, Lcom/facebook/aura/model/HatchMessage;

    .line 61
    .line 62
    iget-object v1, v0, Lcom/facebook/aura/model/HatchMessage;->requestId:Ljava/lang/String;

    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;->$requestId$inlined:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_2

    .line 71
    .line 72
    :cond_3
    check-cast v2, Lcom/facebook/aura/model/HatchMessage;

    .line 73
    .line 74
    if-eqz v2, :cond_0

    .line 75
    .line 76
    iget-object v1, v2, Lcom/facebook/aura/model/HatchMessage;->sendStatus:Lcom/facebook/aura/model/HatchMessageSendStatus;

    .line 77
    .line 78
    if-eqz v1, :cond_0

    .line 79
    .line 80
    const/4 v0, 0x0

    .line 81
    iput-object v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$0:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$1:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$2:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$3:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v0, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$4:Ljava/lang/Object;

    .line 90
    .line 91
    iput v5, v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 92
    .line 93
    invoke-interface {v4, v1, v7}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    if-ne v0, v6, :cond_0

    .line 98
    .line 99
    return-object v6

    .line 100
    :cond_4
    new-instance v7, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 101
    .line 102
    invoke-direct {v7, p0, p2}, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2$1;-><init>(Lcom/facebook/aura/conversation/repo/HatchConversationRepository$awaitSendLeavesSending$status$1$invokeSuspend$$inlined$mapNotNull$1$2;LX/2M4;)V

    .line 103
    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0
.end method
