.class public final Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;


# direct methods
.method public constructor <init>(LX/39x;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 6

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v2, p0, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Lcom/facebook/aura/conversation/repo/HatchConversationState;

    .line 41
    .line 42
    new-instance v1, Lcom/facebook/aura/conversation/repo/ConversationReplies;

    .line 43
    .line 44
    invoke-direct {v1, p1}, Lcom/facebook/aura/conversation/repo/ConversationReplies;-><init>(Lcom/facebook/aura/conversation/repo/HatchConversationState;)V

    .line 45
    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    iput-object v0, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->L$0:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v0, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->L$1:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v0, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->L$2:Ljava/lang/Object;

    .line 53
    .line 54
    iput-object v0, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->L$3:Ljava/lang/Object;

    .line 55
    .line 56
    iput v3, v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;->label:I

    .line 57
    .line 58
    invoke-interface {v2, v1, v5}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-ne v0, v4, :cond_0

    .line 63
    .line 64
    return-object v4

    .line 65
    :cond_2
    new-instance v5, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;

    .line 66
    .line 67
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2$1;-><init>(Lcom/facebook/aura/conversation/repo/HatchConversationRepository$liveConversation$1$special$$inlined$map$1$2;LX/2M4;)V

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    throw v0
.end method
