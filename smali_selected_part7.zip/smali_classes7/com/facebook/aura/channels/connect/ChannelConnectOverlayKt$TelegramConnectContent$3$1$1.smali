.class public final Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/settings/HatchTelegramViewModel;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/aura/settings/HatchTelegramViewModel;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/settings/HatchTelegramViewModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$viewModel:Lcom/facebook/aura/settings/HatchTelegramViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/settings/TelegramEffect;LX/2M4;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/settings/TelegramEffect;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/settings/TelegramEffect$ShowToast;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    check-cast p1, Lcom/facebook/aura/settings/TelegramEffect$ShowToast;

    .line 7
    .line 8
    iget v1, p1, Lcom/facebook/aura/settings/TelegramEffect$ShowToast;->messageResId:I

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-static {v2, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 16
    .line 17
    .line 18
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    return-object v0

    .line 21
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/settings/TelegramEffect$OpenDeeplink;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    iget-object v3, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$viewModel:Lcom/facebook/aura/settings/HatchTelegramViewModel;

    .line 26
    .line 27
    iget-object v2, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$context:Landroid/content/Context;

    .line 28
    .line 29
    sget-object v1, Lcom/facebook/aura/channels/ChannelApp;->TELEGRAM:Lcom/facebook/aura/channels/ChannelApp;

    .line 30
    .line 31
    check-cast p1, Lcom/facebook/aura/settings/TelegramEffect$OpenDeeplink;

    .line 32
    .line 33
    iget-object v0, p1, Lcom/facebook/aura/settings/TelegramEffect$OpenDeeplink;->uri:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/channels/ChannelAppLauncherKt;->launchChannelUrl(Landroid/content/Context;Lcom/facebook/aura/channels/ChannelApp;Ljava/lang/String;)Lcom/facebook/aura/channels/ChannelLaunchOutcome;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v3, v0}, Lcom/facebook/aura/settings/HatchTelegramViewModel;->onDeeplinkLaunched(Lcom/facebook/aura/channels/ChannelLaunchOutcome;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    instance-of v0, p1, Lcom/facebook/aura/settings/TelegramEffect$Dismiss;

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    iget-object v0, p0, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 48
    .line 49
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_2
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/settings/TelegramEffect;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/channels/connect/ChannelConnectOverlayKt$TelegramConnectContent$3$1$1;->emit(Lcom/facebook/aura/settings/TelegramEffect;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
