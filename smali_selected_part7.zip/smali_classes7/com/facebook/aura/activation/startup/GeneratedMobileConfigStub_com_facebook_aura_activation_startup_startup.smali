.class public interface abstract Lcom/facebook/aura/activation/startup/GeneratedMobileConfigStub_com_facebook_aura_activation_startup_startup;
.super Ljava/lang/Object;
.source ""
