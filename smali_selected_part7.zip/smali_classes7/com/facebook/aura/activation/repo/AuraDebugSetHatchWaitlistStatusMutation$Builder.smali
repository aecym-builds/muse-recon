.class public interface abstract Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0Dj;
.implements Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$BuilderForStatus;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$BuilderForStatus;",
        "LX/0Dj<",
        "LX/0Dk<",
        "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
        ">;",
        "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
        ">;"
    }
.end annotation


# virtual methods
.method public abstract setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;
.end method
