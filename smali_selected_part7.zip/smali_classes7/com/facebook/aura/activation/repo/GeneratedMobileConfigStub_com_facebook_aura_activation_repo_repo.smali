.class public interface abstract Lcom/facebook/aura/activation/repo/GeneratedMobileConfigStub_com_facebook_aura_activation_repo_repo;
.super Ljava/lang/Object;
.source ""
