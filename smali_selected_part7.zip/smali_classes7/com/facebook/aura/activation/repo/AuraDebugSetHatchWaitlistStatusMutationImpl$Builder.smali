.class public final Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;


# instance fields
.field public isStatusSet:Z

.field public final params:LX/ISf;

.field public final transientParams:LX/ISf;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, LX/ISf;

    .line 4
    .line 5
    invoke-direct {v0}, LX/ISf;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->params:LX/ISf;

    .line 9
    .line 10
    new-instance v0, LX/ISf;

    .line 11
    .line 12
    invoke-direct {v0}, LX/ISf;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->transientParams:LX/ISf;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public bridge synthetic build()LX/0Dk;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->build()Lcom/facebook/pando/PandoGraphQLRequest;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public bridge synthetic build()LX/0Eb;
    .locals 0

    .line 536870912
    invoke-virtual {p0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->build()Lcom/facebook/pando/PandoGraphQLRequest;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object p0

    .line 536870916
    return-object p0
.end method

.method public build()Lcom/facebook/pando/PandoGraphQLRequest;
    .locals 10

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->isStatusSet:Z

    .line 1
    .line 2
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 3
    .line 4
    .line 5
    invoke-static {}, LX/IUK;->A00()LX/IVB;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->params:LX/ISf;

    .line 10
    .line 11
    invoke-static {v0}, LX/ISf;->A00(LX/ISf;)Ljava/util/TreeMap;

    .line 12
    .line 13
    .line 14
    move-result-object v6

    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->transientParams:LX/ISf;

    .line 16
    .line 17
    invoke-static {v0}, LX/ISf;->A00(LX/ISf;)Ljava/util/TreeMap;

    .line 18
    .line 19
    .line 20
    move-result-object v7

    .line 21
    sget-object v8, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder$build$1;->INSTANCE:Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder$build$1;

    .line 22
    .line 23
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 24
    .line 25
    .line 26
    move-result-object v5

    .line 27
    const/4 v3, 0x0

    .line 28
    const-string v2, "AuraDebugSetHatchWaitlistStatusMutation"

    .line 29
    .line 30
    const-string v4, "xab_debug_set_hatch_waitlist_status"

    .line 31
    .line 32
    const/4 p0, 0x1

    .line 33
    const/4 v9, 0x0

    .line 34
    invoke-static/range {v1 .. v10}, LX/IUg;->A00(LX/IVB;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/Map;Ljava/util/Map;LX/JDM;IZ)Lcom/facebook/pando/PandoGraphQLRequest;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0
.end method

.method public bridge synthetic setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;

    .line 268435457
    .line 268435458
    .line 268435459
    return-object p0
.end method

.method public setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->params:LX/ISf;

    .line 5
    .line 6
    const-string v1, "status"

    .line 7
    .line 8
    iget-object v0, v0, LX/ISf;->A00:LX/Jgm;

    .line 9
    .line 10
    invoke-virtual {v0, v1, p1}, Lcom/facebook/graphql/calls/GraphQlCallInput;->A08(Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;->isStatusSet:Z

    .line 15
    .line 16
    return-object p0
.end method
