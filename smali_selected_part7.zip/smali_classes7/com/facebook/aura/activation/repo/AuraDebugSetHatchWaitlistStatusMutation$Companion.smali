.class public final Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final create()Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$BuilderForStatus;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;

    .line 1
    .line 2
    invoke-direct {p0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method
