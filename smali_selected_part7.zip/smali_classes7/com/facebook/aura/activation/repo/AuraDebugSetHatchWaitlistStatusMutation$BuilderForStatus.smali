.class public interface abstract Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$BuilderForStatus;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract setStatus(Ljava/lang/String;)Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$Builder;
.end method
