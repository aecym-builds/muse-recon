.class public final Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Companion;

.field public static final QUERY_NAME:Ljava/lang/String; = "AuraDebugSetHatchWaitlistStatusMutation"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl;->Companion:Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final create()Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutation$BuilderForStatus;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationImpl$Builder;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method
