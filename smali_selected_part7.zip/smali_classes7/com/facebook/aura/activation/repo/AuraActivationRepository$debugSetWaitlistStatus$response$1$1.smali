.class public final Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0HU;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/0HU;"
    }
.end annotation


# instance fields
.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DT0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DT0<",
            "-",
            "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$1;->$continuation:LX/DT0;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke(LX/09Z;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/09Z<",
            "Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    check-cast p1, LX/0Du;

    .line 5
    .line 6
    iget-object v1, p1, LX/0Du;->A01:Ljava/lang/Object;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/AuraActivationRepository$debugSetWaitlistStatus$response$1$1;->$continuation:LX/DT0;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    const-string v1, "Null response for AuraDebugSetHatchWaitlistStatusMutation"

    .line 13
    .line 14
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    new-instance v1, LX/2PH;

    .line 20
    .line 21
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-interface {p0, v1}, LX/2M4;->resumeWith(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method
