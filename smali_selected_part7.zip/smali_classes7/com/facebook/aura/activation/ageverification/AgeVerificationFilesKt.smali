.class public abstract Lcom/facebook/aura/activation/ageverification/AgeVerificationFilesKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final JPEG_QUALITY:I = 0x5a
