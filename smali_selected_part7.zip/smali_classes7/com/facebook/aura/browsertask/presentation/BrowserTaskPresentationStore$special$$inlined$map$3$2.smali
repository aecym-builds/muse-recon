.class public final Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;


# direct methods
.method public constructor <init>(LX/39x;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 7

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v4, :cond_4

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v5

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v3, p0, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Lcom/facebook/aura/model/BrowserTaskPresentation;

    .line 41
    .line 42
    const/4 v2, 0x0

    .line 43
    if-eqz p1, :cond_2

    .line 44
    .line 45
    iget-object v1, p1, Lcom/facebook/aura/model/BrowserTaskPresentation;->displayStatus:Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v1, :cond_2

    .line 48
    .line 49
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_2

    .line 54
    .line 55
    move-object v2, v1

    .line 56
    :cond_2
    const/4 v0, 0x0

    .line 57
    iput-object v0, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->L$0:Ljava/lang/Object;

    .line 58
    .line 59
    iput-object v0, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->L$1:Ljava/lang/Object;

    .line 60
    .line 61
    iput-object v0, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->L$2:Ljava/lang/Object;

    .line 62
    .line 63
    iput-object v0, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->L$3:Ljava/lang/Object;

    .line 64
    .line 65
    iput v4, v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;->label:I

    .line 66
    .line 67
    invoke-interface {v3, v2, v6}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    if-ne v0, v5, :cond_0

    .line 72
    .line 73
    return-object v5

    .line 74
    :cond_3
    new-instance v6, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;

    .line 75
    .line 76
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2$1;-><init>(Lcom/facebook/aura/browsertask/presentation/BrowserTaskPresentationStore$special$$inlined$map$3$2;LX/2M4;)V

    .line 77
    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    throw v0
.end method
