.class public interface abstract Lcom/facebook/aura/browsertask/conversation/GeneratedMobileConfigStub_com_facebook_aura_browsertask_conversation_conversation;
.super Ljava/lang/Object;
.source ""
