.class public abstract Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ERROR_STOP_CLEANUP_PENDING:Ljava/lang/String; = "browser_stop_cleanup_pending"

.field public static final ERROR_STOP_SETTLING:Ljava/lang/String; = "browser_stop_owner_settling"

.field public static final ERROR_STOP_UNCONFIRMED:Ljava/lang/String; = "browser_stop_outcome_unconfirmed"

.field public static final HTTP_CONFLICT:I = 0x199

.field public static final HTTP_OK:I = 0xc8

.field public static final HTTP_SERVICE_UNAVAILABLE:I = 0x1f7

.field public static final STOP_MAX_RETRIES:I = 0x3

.field public static final STOP_RETRY_DELAY_MS:J = 0x3e8L


# direct methods
.method public static final stopWithRetry(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    const/4 v4, 0x0

    .line 26
    const/4 v3, 0x1

    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    if-eq v0, v3, :cond_1

    .line 30
    .line 31
    if-ne v0, v5, :cond_6

    .line 32
    .line 33
    iget v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->I$0:I

    .line 34
    .line 35
    iget-object p1, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$1:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Ljava/lang/String;

    .line 38
    .line 39
    iget-object p0, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;

    .line 42
    .line 43
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    :goto_1
    iput-object p0, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$0:Ljava/lang/Object;

    .line 47
    .line 48
    iput-object p1, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$1:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v4, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$2:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v4, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$3:Ljava/lang/Object;

    .line 53
    .line 54
    iput v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->I$0:I

    .line 55
    .line 56
    iput v3, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->label:I

    .line 57
    .line 58
    invoke-virtual {p0, p1, v6}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->stop-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    if-ne v1, v7, :cond_2

    .line 63
    .line 64
    return-object v7

    .line 65
    :cond_1
    iget v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->I$0:I

    .line 66
    .line 67
    iget-object p1, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$1:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast p1, Ljava/lang/String;

    .line 70
    .line 71
    iget-object p0, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$0:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;

    .line 74
    .line 75
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    :cond_2
    instance-of v0, v1, LX/2PH;

    .line 80
    .line 81
    xor-int/lit8 v0, v0, 0x1

    .line 82
    .line 83
    if-nez v0, :cond_8

    .line 84
    .line 85
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 86
    .line 87
    .line 88
    move-result-object v8

    .line 89
    instance-of v0, v8, Lcom/facebook/aura/json/NetworkException;

    .line 90
    .line 91
    if-eqz v0, :cond_7

    .line 92
    .line 93
    check-cast v8, Lcom/facebook/aura/json/NetworkException;

    .line 94
    .line 95
    if-eqz v8, :cond_7

    .line 96
    .line 97
    iget v1, v8, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 98
    .line 99
    const/16 v0, 0xc8

    .line 100
    .line 101
    if-eq v1, v0, :cond_8

    .line 102
    .line 103
    const/16 v0, 0x199

    .line 104
    .line 105
    if-eq v1, v0, :cond_8

    .line 106
    .line 107
    const/16 v0, 0x1f7

    .line 108
    .line 109
    if-ne v1, v0, :cond_7

    .line 110
    .line 111
    iget-object v1, v8, Lcom/facebook/aura/json/NetworkException;->errorCode:Ljava/lang/String;

    .line 112
    .line 113
    const-string v0, "browser_stop_outcome_unconfirmed"

    .line 114
    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-nez v0, :cond_3

    .line 120
    .line 121
    const-string v0, "browser_stop_owner_settling"

    .line 122
    .line 123
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    if-nez v0, :cond_3

    .line 128
    .line 129
    const-string v0, "browser_stop_cleanup_pending"

    .line 130
    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    if-eqz v0, :cond_7

    .line 136
    .line 137
    :cond_3
    const/4 v0, 0x3

    .line 138
    if-ge v2, v0, :cond_7

    .line 139
    .line 140
    add-int/lit8 v2, v2, 0x1

    .line 141
    .line 142
    iput-object p0, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$0:Ljava/lang/Object;

    .line 143
    .line 144
    iput-object p1, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$1:Ljava/lang/Object;

    .line 145
    .line 146
    iput-object v4, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$2:Ljava/lang/Object;

    .line 147
    .line 148
    iput-object v4, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->L$3:Ljava/lang/Object;

    .line 149
    .line 150
    iput v2, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->I$0:I

    .line 151
    .line 152
    iput v3, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->I$1:I

    .line 153
    .line 154
    iput v5, v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;->label:I

    .line 155
    .line 156
    const-wide/16 v0, 0x3e8

    .line 157
    .line 158
    invoke-static {v0, v1, v6}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    if-ne v0, v7, :cond_0

    .line 163
    .line 164
    return-object v7

    .line 165
    :cond_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    const/4 v2, 0x0

    .line 169
    goto :goto_1

    .line 170
    :cond_5
    new-instance v6, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;

    .line 171
    .line 172
    invoke-direct {v6, p2}, Lcom/facebook/aura/browsertask/control/BrowserTaskStopKt$stopWithRetry$1;-><init>(LX/2M4;)V

    .line 173
    .line 174
    .line 175
    goto/16 :goto_0

    .line 176
    .line 177
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    throw v0

    .line 182
    :cond_7
    const/4 v3, 0x0

    .line 183
    :cond_8
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 184
    .line 185
    .line 186
    move-result-object v7

    .line 187
    return-object v7
.end method
