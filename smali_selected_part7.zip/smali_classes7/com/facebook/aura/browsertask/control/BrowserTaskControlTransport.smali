.class public final Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final CONTROL_REQUEST_TIMEOUT_SECONDS:J = 0xaL
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$Companion;


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->Companion:Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->userSession:LX/AHE;

    .line 8
    .line 9
    return-void
.end method

.method public static final synthetic access$getUserSession$p(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;)LX/AHE;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->userSession:LX/AHE;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$request-hUnOzRk(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/network/http/RequestType;",
            "Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;",
            "J",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p7

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;

    .line 3
    .line 4
    move-object v10, p0

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    move-object v4, v3

    .line 8
    check-cast v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;

    .line 9
    .line 10
    iget v2, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 11
    .line 12
    const/high16 v1, -0x80000000

    .line 13
    .line 14
    and-int v0, v2, v1

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    sub-int/2addr v2, v1

    .line 19
    iput v2, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 20
    .line 21
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->result:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 24
    .line 25
    iget v0, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    if-ne v0, v1, :cond_3

    .line 31
    .line 32
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    check-cast v3, LX/2PJ;

    .line 36
    .line 37
    iget-object v0, v3, LX/2PJ;->value:Ljava/lang/Object;

    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_1
    invoke-static {v3}, LX/2PI;->A03(Ljava/lang/Object;)LX/BqD;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    const/4 p0, 0x0

    .line 45
    new-instance v5, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$2;

    .line 46
    .line 47
    move-object v6, p1

    .line 48
    move-object v7, p2

    .line 49
    move-object/from16 v9, p3

    .line 50
    .line 51
    move-object/from16 v8, p4

    .line 52
    .line 53
    move-wide/from16 v11, p5

    .line 54
    .line 55
    invoke-direct/range {v5 .. v13}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$2;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;JLX/2M4;)V

    .line 56
    .line 57
    .line 58
    iput-object p0, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object p0, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->L$1:Ljava/lang/Object;

    .line 61
    .line 62
    iput-object p0, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->L$2:Ljava/lang/Object;

    .line 63
    .line 64
    iput-object p0, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->L$3:Ljava/lang/Object;

    .line 65
    .line 66
    iput-wide v11, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->J$0:J

    .line 67
    .line 68
    iput v1, v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 69
    .line 70
    invoke-static {v4, v0, v5}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    if-ne v3, v2, :cond_0

    .line 75
    .line 76
    return-object v2

    .line 77
    :cond_2
    new-instance v4, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;

    .line 78
    .line 79
    invoke-direct {v4, p0, v3}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 80
    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    throw v0
.end method

.method public static synthetic request-hUnOzRk$default(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    and-int/lit8 v0, p8, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p3, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    const/4 p4, 0x0

    .line 11
    :cond_1
    and-int/lit8 v0, p8, 0x10

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    const-wide/16 p5, 0xa

    .line 16
    .line 17
    :cond_2
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method


# virtual methods
.method public final heartbeat-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p2

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->label:I

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v0, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v8, 0x0

    .line 39
    iput-object v8, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;->label:I

    .line 42
    .line 43
    const/16 v0, 0xb

    .line 44
    .line 45
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 50
    .line 51
    const-wide/16 v9, 0xa

    .line 52
    .line 53
    move-object v5, p1

    .line 54
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    if-ne v0, v2, :cond_0

    .line 59
    .line 60
    return-object v2

    .line 61
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;

    .line 62
    .line 63
    invoke-direct {p0, v4, p2}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$heartbeat$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 64
    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    throw v0
.end method

.method public final present-0E7RQCE(Ljava/lang/String;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p3

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    if-ne v0, v1, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->L$1:Ljava/lang/Object;

    .line 42
    .line 43
    iput v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;->label:I

    .line 44
    .line 45
    const-string v6, "present"

    .line 46
    .line 47
    const-wide/16 v9, 0x186

    .line 48
    .line 49
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 50
    .line 51
    move-object v5, p1

    .line 52
    move-object v8, p2

    .line 53
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-ne v0, v2, :cond_0

    .line 58
    .line 59
    return-object v2

    .line 60
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;

    .line 61
    .line 62
    invoke-direct {p0, v4, p3}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$present$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    throw v0
.end method

.method public final release-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p2

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->label:I

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v0, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v8, 0x0

    .line 39
    iput-object v8, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;->label:I

    .line 42
    .line 43
    const-string v6, "release"

    .line 44
    .line 45
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 46
    .line 47
    const-wide/16 v9, 0xa

    .line 48
    .line 49
    move-object v5, p1

    .line 50
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    if-ne v0, v2, :cond_0

    .line 55
    .line 56
    return-object v2

    .line 57
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;

    .line 58
    .line 59
    invoke-direct {p0, v4, p2}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$release$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method

.method public final stop-gIAlu-s(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p2

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->label:I

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v0, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v8, 0x0

    .line 39
    iput-object v8, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;->label:I

    .line 42
    .line 43
    const-string v6, "stop"

    .line 44
    .line 45
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 46
    .line 47
    const-wide/16 v9, 0xa

    .line 48
    .line 49
    move-object v5, p1

    .line 50
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    if-ne v0, v2, :cond_0

    .line 55
    .line 56
    return-object v2

    .line 57
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;

    .line 58
    .line 59
    invoke-direct {p0, v4, p2}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$stop$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method

.method public final takeover-0E7RQCE(Ljava/lang/String;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p3

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    if-ne v0, v1, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->L$1:Ljava/lang/Object;

    .line 42
    .line 43
    iput v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;->label:I

    .line 44
    .line 45
    const-string v6, "takeover"

    .line 46
    .line 47
    const-wide/16 v9, 0x186

    .line 48
    .line 49
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 50
    .line 51
    move-object v5, p1

    .line 52
    move-object v8, p2

    .line 53
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-ne v0, v2, :cond_0

    .line 58
    .line 59
    return-object v2

    .line 60
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;

    .line 61
    .line 62
    invoke-direct {p0, v4, p3}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$takeover$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    throw v0
.end method

.method public final updateViewer-0E7RQCE(Ljava/lang/String;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskSnapshotJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;

    .line 1
    .line 2
    move-object v4, p0

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    move-object p0, p3

    .line 6
    check-cast p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;

    .line 7
    .line 8
    iget v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v3, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    if-ne v0, v1, :cond_3

    .line 29
    .line 30
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :cond_0
    return-object v0

    .line 35
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->PATCH:Lcom/facebook/aura/network/http/RequestType;

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->L$0:Ljava/lang/Object;

    .line 42
    .line 43
    iput-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->L$1:Ljava/lang/Object;

    .line 44
    .line 45
    iput v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;->label:I

    .line 46
    .line 47
    const-string v6, "viewer"

    .line 48
    .line 49
    const-wide/16 v9, 0xa

    .line 50
    .line 51
    move-object v5, p1

    .line 52
    move-object v8, p2

    .line 53
    invoke-direct/range {v4 .. v11}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->request-hUnOzRk(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-ne v0, v2, :cond_0

    .line 58
    .line 59
    return-object v2

    .line 60
    :cond_2
    new-instance p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;

    .line 61
    .line 62
    invoke-direct {p0, v4, p3}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$updateViewer$1;-><init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    throw v0
.end method
