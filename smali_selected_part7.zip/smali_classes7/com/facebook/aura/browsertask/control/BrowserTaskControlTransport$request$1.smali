.class public final Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.browsertask.control.BrowserTaskControlTransport"
    f = "BrowserTaskControlTransport.kt"
    l = {
        0x2f
    }
    m = "request-hUnOzRk"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->this$0:Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport$request$1;->this$0:Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;

    .line 10
    .line 11
    const-wide/16 v5, 0x0

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    move-object v2, v1

    .line 15
    move-object v3, v1

    .line 16
    move-object v4, v1

    .line 17
    invoke-static/range {v0 .. v7}, Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;->access$request-hUnOzRk(Lcom/facebook/aura/browsertask/control/BrowserTaskControlTransport;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/network/http/RequestType;Lcom/facebook/aura/browsertask/control/BrowserViewerPreference;JLX/2M4;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, LX/3Rs;->A0C(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0
.end method
