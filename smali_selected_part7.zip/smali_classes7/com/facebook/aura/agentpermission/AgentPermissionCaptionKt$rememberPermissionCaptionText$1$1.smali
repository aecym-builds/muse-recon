.class public final Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1"
    f = "AgentPermissionCaption.kt"
    l = {
        0x1b
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $caption:Ljava/lang/String;

.field public final synthetic $formattedCaption:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2iK;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $linkColor:J

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;Ljava/lang/String;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2iK;",
            ">;",
            "Ljava/lang/String;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$formattedCaption:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$caption:Ljava/lang/String;

    .line 3
    .line 4
    iput-wide p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$linkColor:J

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$formattedCaption:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$caption:Ljava/lang/String;

    .line 3
    .line 4
    iget-wide p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$linkColor:J

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;

    .line 7
    .line 8
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;-><init>(Landroidx/compose/runtime/MutableState;Ljava/lang/String;JLX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->label:I

    .line 3
    .line 4
    const/4 v7, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v7, :cond_2

    .line 8
    .line 9
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->L$0:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v6, Landroidx/compose/runtime/MutableState;

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    invoke-interface {v6, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$formattedCaption:Landroidx/compose/runtime/MutableState;

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 28
    .line 29
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->default()LX/BqD;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$caption:Ljava/lang/String;

    .line 34
    .line 35
    iget-wide v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->$linkColor:J

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;

    .line 39
    .line 40
    invoke-direct {v0, v4, v2, v3, v1}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;-><init>(Ljava/lang/String;JLX/2M4;)V

    .line 41
    .line 42
    .line 43
    iput-object v6, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->L$0:Ljava/lang/Object;

    .line 44
    .line 45
    iput v7, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1;->label:I

    .line 46
    .line 47
    invoke-static {p0, v5, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    if-ne p1, v8, :cond_0

    .line 52
    .line 53
    return-object v8

    .line 54
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    throw v0
.end method
