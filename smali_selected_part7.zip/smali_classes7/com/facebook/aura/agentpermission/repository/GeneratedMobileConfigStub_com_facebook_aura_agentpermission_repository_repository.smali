.class public interface abstract Lcom/facebook/aura/agentpermission/repository/GeneratedMobileConfigStub_com_facebook_aura_agentpermission_repository_repository;
.super Ljava/lang/Object;
.source ""
