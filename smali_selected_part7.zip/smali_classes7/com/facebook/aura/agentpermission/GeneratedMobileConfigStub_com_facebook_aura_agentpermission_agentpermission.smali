.class public interface abstract Lcom/facebook/aura/agentpermission/GeneratedMobileConfigStub_com_facebook_aura_agentpermission_agentpermission;
.super Ljava/lang/Object;
.source ""
