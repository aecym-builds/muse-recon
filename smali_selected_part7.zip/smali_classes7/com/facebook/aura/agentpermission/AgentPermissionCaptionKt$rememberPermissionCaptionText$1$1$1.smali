.class public final Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2iK;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1"
    f = "AgentPermissionCaption.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $caption:Ljava/lang/String;

.field public final synthetic $linkColor:J

.field public label:I


# direct methods
.method public constructor <init>(Ljava/lang/String;JLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$caption:Ljava/lang/String;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$linkColor:J

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$caption:Ljava/lang/String;

    .line 1
    .line 2
    iget-wide v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$linkColor:J

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, v1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;-><init>(Ljava/lang/String;JLX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2iK;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 49

    .line 0
    move-object/from16 v4, p0

    .line 1
    .line 2
    iget v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->label:I

    .line 3
    .line 4
    if-nez v0, :cond_14

    .line 5
    .line 6
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v9, 0x0

    .line 11
    const/4 v6, 0x1

    .line 12
    new-instance v3, LX/IwA;

    .line 13
    .line 14
    invoke-direct {v3, v6, v5}, LX/IwA;-><init>(ZZ)V

    .line 15
    .line 16
    .line 17
    sget-object v0, LX/Iup;->A00:LX/Iup;

    .line 18
    .line 19
    new-instance v1, LX/IvM;

    .line 20
    .line 21
    invoke-direct {v1, v3, v0, v5}, LX/IvM;-><init>(LX/IwA;Lorg/intellij/markdown/parser/CancellationToken;Z)V

    .line 22
    .line 23
    .line 24
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$caption:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, LX/IvM;->A00(Ljava/lang/String;)LX/Ivx;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    iget-object v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$caption:Ljava/lang/String;

    .line 31
    .line 32
    new-instance v2, LX/IwP;

    .line 33
    .line 34
    invoke-direct {v2, v0, v1, v3}, LX/IwP;-><init>(Ljava/lang/String;LX/Ivx;LX/IwA;)V

    .line 35
    .line 36
    .line 37
    sget-object v1, LX/IXw;->A00:LX/JDQ;

    .line 38
    .line 39
    new-instance v0, LX/IXv;

    .line 40
    .line 41
    invoke-direct {v0, v1}, LX/IXv;-><init>(LX/JDQ;)V

    .line 42
    .line 43
    .line 44
    new-instance v1, LX/IwO;

    .line 45
    .line 46
    invoke-direct {v1, v0, v2}, LX/IwO;-><init>(LX/IXv;LX/IwP;)V

    .line 47
    .line 48
    .line 49
    iget-object v0, v2, LX/IwP;->A03:LX/Ivx;

    .line 50
    .line 51
    invoke-virtual {v1, v0}, LX/Iw1;->A00(LX/Ivx;)V

    .line 52
    .line 53
    .line 54
    iget-object v0, v2, LX/IwP;->A01:Ljava/lang/StringBuilder;

    .line 55
    .line 56
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    iget-wide v0, v4, Lcom/facebook/aura/agentpermission/AgentPermissionCaptionKt$rememberPermissionCaptionText$1$1$1;->$linkColor:J

    .line 61
    .line 62
    sget-object v20, LX/2RW;->A03:LX/2RW;

    .line 63
    .line 64
    sget-wide v25, LX/2hw;->A01:J

    .line 65
    .line 66
    sget-wide v29, LX/JOw;->A07:J

    .line 67
    .line 68
    new-instance v2, LX/2hh;

    .line 69
    .line 70
    move-object v11, v2

    .line 71
    move-object v12, v9

    .line 72
    move-object v13, v9

    .line 73
    move-object v14, v9

    .line 74
    move-object v15, v9

    .line 75
    move-object/from16 v16, v9

    .line 76
    .line 77
    move-object/from16 v17, v9

    .line 78
    .line 79
    move-object/from16 v18, v9

    .line 80
    .line 81
    move-object/from16 v19, v9

    .line 82
    .line 83
    move-object/from16 v21, v9

    .line 84
    .line 85
    move-object/from16 v22, v9

    .line 86
    .line 87
    move-wide/from16 v23, v0

    .line 88
    .line 89
    move-wide/from16 v27, v25

    .line 90
    .line 91
    invoke-direct/range {v11 .. v30}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 92
    .line 93
    .line 94
    new-instance v14, LX/2iS;

    .line 95
    .line 96
    invoke-direct {v14, v2, v9, v9, v9}, LX/2iS;-><init>(LX/2hh;LX/2hh;LX/2hh;LX/2hh;)V

    .line 97
    .line 98
    .line 99
    const-string v0, "<ContentHandlerReplacementTag />"

    .line 100
    .line 101
    invoke-static {v0, v3}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    sget-object v1, LX/IzF;->A00:LX/IzD;

    .line 106
    .line 107
    const/16 v0, 0x3f

    .line 108
    .line 109
    invoke-static {v2, v0, v9, v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;ILandroid/text/Html$ImageGetter;Landroid/text/Html$TagHandler;)Landroid/text/Spanned;

    .line 110
    .line 111
    .line 112
    move-result-object v12

    .line 113
    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    new-instance v2, LX/2b4;

    .line 118
    .line 119
    invoke-direct {v2, v0}, LX/2b4;-><init>(I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v2, v12}, LX/2b4;->A0C(Ljava/lang/CharSequence;)V

    .line 123
    .line 124
    .line 125
    iget-object v0, v2, LX/2b4;->A00:Ljava/lang/StringBuilder;

    .line 126
    .line 127
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    const-class v0, Ljava/lang/Object;

    .line 132
    .line 133
    const/4 v10, 0x0

    .line 134
    invoke-interface {v12, v5, v1, v0}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v13

    .line 138
    array-length v15, v13

    .line 139
    :goto_0
    if-ge v10, v15, :cond_13

    .line 140
    .line 141
    aget-object v3, v13, v10

    .line 142
    .line 143
    invoke-interface {v12, v3}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    invoke-interface {v12, v3}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    invoke-static {v1, v0}, LX/2iP;->A00(II)J

    .line 152
    .line 153
    .line 154
    move-result-wide v16

    .line 155
    const/16 v11, 0x20

    .line 156
    .line 157
    shr-long v0, v16, v11

    .line 158
    .line 159
    long-to-int v8, v0

    .line 160
    invoke-static/range {v16 .. v17}, LX/3P9;->A00(J)I

    .line 161
    .line 162
    .line 163
    move-result v7

    .line 164
    instance-of v0, v3, Landroid/text/style/AbsoluteSizeSpan;

    .line 165
    .line 166
    if-nez v0, :cond_0

    .line 167
    .line 168
    instance-of v0, v3, Landroid/text/style/AlignmentSpan;

    .line 169
    .line 170
    if-eqz v0, :cond_4

    .line 171
    .line 172
    check-cast v3, Landroid/text/style/AlignmentSpan;

    .line 173
    .line 174
    invoke-interface {v3}, Landroid/text/style/AlignmentSpan;->getAlignment()Landroid/text/Layout$Alignment;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    if-eqz v0, :cond_3

    .line 179
    .line 180
    sget-object v1, LX/0jL;->A00:[I

    .line 181
    .line 182
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    aget v1, v1, v0

    .line 187
    .line 188
    if-eq v1, v6, :cond_2

    .line 189
    .line 190
    const/4 v0, 0x2

    .line 191
    if-eq v1, v0, :cond_1

    .line 192
    .line 193
    const/4 v0, 0x3

    .line 194
    if-ne v1, v0, :cond_3

    .line 195
    .line 196
    const/16 v36, 0x6

    .line 197
    .line 198
    :goto_1
    new-instance v0, LX/2hj;

    .line 199
    .line 200
    move-object/from16 v31, v0

    .line 201
    .line 202
    move-object/from16 v32, v9

    .line 203
    .line 204
    move-object/from16 v33, v9

    .line 205
    .line 206
    move-object/from16 v34, v9

    .line 207
    .line 208
    move-object/from16 v35, v9

    .line 209
    .line 210
    move/from16 v37, v5

    .line 211
    .line 212
    move/from16 v38, v5

    .line 213
    .line 214
    move/from16 v39, v5

    .line 215
    .line 216
    move-wide/from16 v40, v25

    .line 217
    .line 218
    invoke-direct/range {v31 .. v41}, LX/2hj;-><init>(LX/2hn;LX/2iI;LX/2Qv;LX/2hr;IIIIJ)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v2, v0, v8, v7}, LX/2b4;->A09(LX/2hj;II)V

    .line 222
    .line 223
    .line 224
    :cond_0
    :goto_2
    add-int/lit8 v10, v10, 0x1

    .line 225
    .line 226
    goto :goto_0

    .line 227
    :cond_1
    const/16 v36, 0x3

    .line 228
    .line 229
    goto :goto_1

    .line 230
    :cond_2
    const/16 v36, 0x5

    .line 231
    .line 232
    goto :goto_1

    .line 233
    :cond_3
    const/16 v36, 0x0

    .line 234
    .line 235
    goto :goto_1

    .line 236
    :cond_4
    instance-of v0, v3, LX/IzG;

    .line 237
    .line 238
    if-eqz v0, :cond_5

    .line 239
    .line 240
    check-cast v3, LX/IzG;

    .line 241
    .line 242
    iget-object v0, v3, LX/IzG;->A00:Ljava/lang/String;

    .line 243
    .line 244
    iget-object v1, v3, LX/IzG;->A01:Ljava/lang/String;

    .line 245
    .line 246
    invoke-virtual {v2, v0, v1, v8, v7}, LX/2b4;->A0G(Ljava/lang/String;Ljava/lang/String;II)V

    .line 247
    .line 248
    .line 249
    goto :goto_2

    .line 250
    :cond_5
    instance-of v0, v3, Landroid/text/style/BackgroundColorSpan;

    .line 251
    .line 252
    if-eqz v0, :cond_6

    .line 253
    .line 254
    check-cast v3, Landroid/text/style/BackgroundColorSpan;

    .line 255
    .line 256
    invoke-virtual {v3}, Landroid/text/style/BackgroundColorSpan;->getBackgroundColor()I

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    int-to-long v3, v0

    .line 261
    shl-long/2addr v3, v11

    .line 262
    new-instance v0, LX/2hh;

    .line 263
    .line 264
    move-object/from16 v31, v0

    .line 265
    .line 266
    move-object/from16 v32, v9

    .line 267
    .line 268
    move-object/from16 v33, v9

    .line 269
    .line 270
    move-object/from16 v34, v9

    .line 271
    .line 272
    move-object/from16 v35, v9

    .line 273
    .line 274
    move-object/from16 v36, v9

    .line 275
    .line 276
    move-object/from16 v37, v9

    .line 277
    .line 278
    move-object/from16 v38, v9

    .line 279
    .line 280
    move-object/from16 v39, v9

    .line 281
    .line 282
    move-object/from16 v40, v9

    .line 283
    .line 284
    move-object/from16 v41, v9

    .line 285
    .line 286
    move-object/from16 v42, v9

    .line 287
    .line 288
    move-wide/from16 v43, v29

    .line 289
    .line 290
    move-wide/from16 v45, v25

    .line 291
    .line 292
    move-wide/from16 v47, v25

    .line 293
    .line 294
    move-wide/from16 p0, v3

    .line 295
    .line 296
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 297
    .line 298
    .line 299
    :goto_3
    invoke-virtual {v2, v0, v8, v7}, LX/2b4;->A0A(LX/2hh;II)V

    .line 300
    .line 301
    .line 302
    goto :goto_2

    .line 303
    :cond_6
    instance-of v0, v3, LX/Iz6;

    .line 304
    .line 305
    if-eqz v0, :cond_7

    .line 306
    .line 307
    sget-wide v18, LX/2R9;->A05:J

    .line 308
    .line 309
    check-cast v3, LX/Iz6;

    .line 310
    .line 311
    iget v11, v3, LX/Iz6;->A00:I

    .line 312
    .line 313
    invoke-static/range {v18 .. v19}, LX/2S9;->A04(J)V

    .line 314
    .line 315
    .line 316
    const-wide v16, 0xff00000000L

    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    and-long v0, v18, v16

    .line 322
    .line 323
    invoke-static/range {v18 .. v19}, LX/2hw;->A00(J)F

    .line 324
    .line 325
    .line 326
    move-result v4

    .line 327
    int-to-float v11, v11

    .line 328
    mul-float/2addr v4, v11

    .line 329
    invoke-static {v0, v1, v4}, LX/2S9;->A03(JF)J

    .line 330
    .line 331
    .line 332
    move-result-wide v0

    .line 333
    iget-object v3, v3, LX/Iz6;->A02:LX/2R9;

    .line 334
    .line 335
    new-instance v4, LX/2Qv;

    .line 336
    .line 337
    invoke-direct {v4, v0, v1, v0, v1}, LX/2Qv;-><init>(JJ)V

    .line 338
    .line 339
    .line 340
    new-instance v11, LX/2hj;

    .line 341
    .line 342
    move-object/from16 v31, v11

    .line 343
    .line 344
    move-object/from16 v32, v9

    .line 345
    .line 346
    move-object/from16 v33, v9

    .line 347
    .line 348
    move-object/from16 v34, v4

    .line 349
    .line 350
    move-object/from16 v35, v9

    .line 351
    .line 352
    move/from16 v36, v5

    .line 353
    .line 354
    move/from16 v37, v5

    .line 355
    .line 356
    move/from16 v38, v5

    .line 357
    .line 358
    move/from16 v39, v5

    .line 359
    .line 360
    move-wide/from16 v40, v25

    .line 361
    .line 362
    invoke-direct/range {v31 .. v41}, LX/2hj;-><init>(LX/2hn;LX/2iI;LX/2Qv;LX/2hr;IIIIJ)V

    .line 363
    .line 364
    .line 365
    iget-object v4, v2, LX/2b4;->A01:Ljava/util/List;

    .line 366
    .line 367
    const-string v1, ""

    .line 368
    .line 369
    new-instance v0, LX/2b3;

    .line 370
    .line 371
    invoke-direct {v0, v11, v1, v8, v7}, LX/2b3;-><init>(Ljava/lang/Object;Ljava/lang/String;II)V

    .line 372
    .line 373
    .line 374
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    :goto_4
    new-instance v0, LX/2b3;

    .line 378
    .line 379
    invoke-direct {v0, v3, v1, v8, v7}, LX/2b3;-><init>(Ljava/lang/Object;Ljava/lang/String;II)V

    .line 380
    .line 381
    .line 382
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 383
    .line 384
    .line 385
    goto/16 :goto_2

    .line 386
    .line 387
    :cond_7
    instance-of v0, v3, Landroid/text/style/ForegroundColorSpan;

    .line 388
    .line 389
    if-eqz v0, :cond_8

    .line 390
    .line 391
    check-cast v3, Landroid/text/style/ForegroundColorSpan;

    .line 392
    .line 393
    invoke-virtual {v3}, Landroid/text/style/ForegroundColorSpan;->getForegroundColor()I

    .line 394
    .line 395
    .line 396
    move-result v0

    .line 397
    int-to-long v3, v0

    .line 398
    shl-long/2addr v3, v11

    .line 399
    new-instance v0, LX/2hh;

    .line 400
    .line 401
    move-object/from16 v31, v0

    .line 402
    .line 403
    move-object/from16 v32, v9

    .line 404
    .line 405
    move-object/from16 v33, v9

    .line 406
    .line 407
    move-object/from16 v34, v9

    .line 408
    .line 409
    move-object/from16 v35, v9

    .line 410
    .line 411
    move-object/from16 v36, v9

    .line 412
    .line 413
    move-object/from16 v37, v9

    .line 414
    .line 415
    move-object/from16 v38, v9

    .line 416
    .line 417
    move-object/from16 v39, v9

    .line 418
    .line 419
    move-object/from16 v40, v9

    .line 420
    .line 421
    move-object/from16 v41, v9

    .line 422
    .line 423
    move-object/from16 v42, v9

    .line 424
    .line 425
    move-wide/from16 v43, v3

    .line 426
    .line 427
    move-wide/from16 v45, v25

    .line 428
    .line 429
    move-wide/from16 v47, v25

    .line 430
    .line 431
    move-wide/from16 p0, v29

    .line 432
    .line 433
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 434
    .line 435
    .line 436
    goto/16 :goto_3

    .line 437
    .line 438
    :cond_8
    instance-of v0, v3, Landroid/text/style/RelativeSizeSpan;

    .line 439
    .line 440
    if-eqz v0, :cond_9

    .line 441
    .line 442
    check-cast v3, Landroid/text/style/RelativeSizeSpan;

    .line 443
    .line 444
    invoke-virtual {v3}, Landroid/text/style/RelativeSizeSpan;->getSizeChange()F

    .line 445
    .line 446
    .line 447
    move-result v3

    .line 448
    const-wide v0, 0x200000000L

    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    invoke-static {v0, v1, v3}, LX/2S9;->A03(JF)J

    .line 454
    .line 455
    .line 456
    move-result-wide v45

    .line 457
    new-instance v0, LX/2hh;

    .line 458
    .line 459
    move-object/from16 v31, v0

    .line 460
    .line 461
    move-object/from16 v32, v9

    .line 462
    .line 463
    move-object/from16 v33, v9

    .line 464
    .line 465
    move-object/from16 v34, v9

    .line 466
    .line 467
    move-object/from16 v35, v9

    .line 468
    .line 469
    move-object/from16 v36, v9

    .line 470
    .line 471
    move-object/from16 v37, v9

    .line 472
    .line 473
    move-object/from16 v38, v9

    .line 474
    .line 475
    move-object/from16 v39, v9

    .line 476
    .line 477
    move-object/from16 v40, v9

    .line 478
    .line 479
    move-object/from16 v41, v9

    .line 480
    .line 481
    move-object/from16 v42, v9

    .line 482
    .line 483
    move-wide/from16 v43, v29

    .line 484
    .line 485
    move-wide/from16 v47, v25

    .line 486
    .line 487
    move-wide/from16 p0, v29

    .line 488
    .line 489
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 490
    .line 491
    .line 492
    goto/16 :goto_3

    .line 493
    .line 494
    :cond_9
    instance-of v0, v3, Landroid/text/style/StrikethroughSpan;

    .line 495
    .line 496
    if-eqz v0, :cond_a

    .line 497
    .line 498
    sget-object v40, LX/2RW;->A01:LX/2RW;

    .line 499
    .line 500
    :goto_5
    new-instance v0, LX/2hh;

    .line 501
    .line 502
    move-object/from16 v31, v0

    .line 503
    .line 504
    move-object/from16 v32, v9

    .line 505
    .line 506
    move-object/from16 v33, v9

    .line 507
    .line 508
    move-object/from16 v34, v9

    .line 509
    .line 510
    move-object/from16 v35, v9

    .line 511
    .line 512
    move-object/from16 v36, v9

    .line 513
    .line 514
    move-object/from16 v37, v9

    .line 515
    .line 516
    move-object/from16 v38, v9

    .line 517
    .line 518
    move-object/from16 v39, v9

    .line 519
    .line 520
    move-object/from16 v41, v9

    .line 521
    .line 522
    move-object/from16 v42, v9

    .line 523
    .line 524
    move-wide/from16 v43, v29

    .line 525
    .line 526
    move-wide/from16 v45, v25

    .line 527
    .line 528
    move-wide/from16 v47, v25

    .line 529
    .line 530
    move-wide/from16 p0, v29

    .line 531
    .line 532
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 533
    .line 534
    .line 535
    goto/16 :goto_3

    .line 536
    .line 537
    :cond_a
    instance-of v0, v3, Landroid/text/style/StyleSpan;

    .line 538
    .line 539
    if-eqz v0, :cond_b

    .line 540
    .line 541
    check-cast v3, Landroid/text/style/StyleSpan;

    .line 542
    .line 543
    invoke-virtual {v3}, Landroid/text/style/StyleSpan;->getStyle()I

    .line 544
    .line 545
    .line 546
    move-result v1

    .line 547
    if-eq v1, v6, :cond_12

    .line 548
    .line 549
    const/4 v0, 0x2

    .line 550
    if-eq v1, v0, :cond_11

    .line 551
    .line 552
    const/4 v0, 0x3

    .line 553
    if-ne v1, v0, :cond_0

    .line 554
    .line 555
    sget-object v37, LX/2W8;->A01:LX/2W8;

    .line 556
    .line 557
    new-instance v1, LX/2i5;

    .line 558
    .line 559
    invoke-direct {v1, v6}, LX/2i5;-><init>(I)V

    .line 560
    .line 561
    .line 562
    new-instance v0, LX/2hh;

    .line 563
    .line 564
    move-object/from16 v31, v0

    .line 565
    .line 566
    move-object/from16 v32, v9

    .line 567
    .line 568
    move-object/from16 v33, v9

    .line 569
    .line 570
    move-object/from16 v34, v9

    .line 571
    .line 572
    move-object/from16 v35, v1

    .line 573
    .line 574
    move-object/from16 v36, v9

    .line 575
    .line 576
    move-object/from16 v38, v9

    .line 577
    .line 578
    move-object/from16 v39, v9

    .line 579
    .line 580
    move-object/from16 v40, v9

    .line 581
    .line 582
    move-object/from16 v41, v9

    .line 583
    .line 584
    move-object/from16 v42, v9

    .line 585
    .line 586
    move-wide/from16 v43, v29

    .line 587
    .line 588
    move-wide/from16 v45, v25

    .line 589
    .line 590
    move-wide/from16 v47, v25

    .line 591
    .line 592
    move-wide/from16 p0, v29

    .line 593
    .line 594
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 595
    .line 596
    .line 597
    goto/16 :goto_3

    .line 598
    .line 599
    :cond_b
    instance-of v0, v3, Landroid/text/style/SubscriptSpan;

    .line 600
    .line 601
    if-eqz v0, :cond_c

    .line 602
    .line 603
    const/high16 v0, -0x41000000    # -0.5f

    .line 604
    .line 605
    :goto_6
    new-instance v1, LX/2hq;

    .line 606
    .line 607
    invoke-direct {v1, v0}, LX/2hq;-><init>(F)V

    .line 608
    .line 609
    .line 610
    new-instance v0, LX/2hh;

    .line 611
    .line 612
    move-object/from16 v31, v0

    .line 613
    .line 614
    move-object/from16 v32, v9

    .line 615
    .line 616
    move-object/from16 v33, v9

    .line 617
    .line 618
    move-object/from16 v34, v9

    .line 619
    .line 620
    move-object/from16 v35, v9

    .line 621
    .line 622
    move-object/from16 v36, v9

    .line 623
    .line 624
    move-object/from16 v37, v9

    .line 625
    .line 626
    move-object/from16 v38, v9

    .line 627
    .line 628
    move-object/from16 v39, v1

    .line 629
    .line 630
    move-object/from16 v40, v9

    .line 631
    .line 632
    move-object/from16 v41, v9

    .line 633
    .line 634
    move-object/from16 v42, v9

    .line 635
    .line 636
    move-wide/from16 v43, v29

    .line 637
    .line 638
    move-wide/from16 v45, v25

    .line 639
    .line 640
    move-wide/from16 v47, v25

    .line 641
    .line 642
    move-wide/from16 p0, v29

    .line 643
    .line 644
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 645
    .line 646
    .line 647
    goto/16 :goto_3

    .line 648
    .line 649
    :cond_c
    instance-of v0, v3, Landroid/text/style/SuperscriptSpan;

    .line 650
    .line 651
    if-eqz v0, :cond_d

    .line 652
    .line 653
    const/high16 v0, 0x3f000000    # 0.5f

    .line 654
    .line 655
    goto :goto_6

    .line 656
    :cond_d
    instance-of v0, v3, Landroid/text/style/TypefaceSpan;

    .line 657
    .line 658
    if-eqz v0, :cond_f

    .line 659
    .line 660
    check-cast v3, Landroid/text/style/TypefaceSpan;

    .line 661
    .line 662
    invoke-virtual {v3}, Landroid/text/style/TypefaceSpan;->getFamily()Ljava/lang/String;

    .line 663
    .line 664
    .line 665
    move-result-object v4

    .line 666
    sget-object v1, LX/IzA;->A00:LX/36I;

    .line 667
    .line 668
    const-string v0, "cursive"

    .line 669
    .line 670
    invoke-virtual {v0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 671
    .line 672
    .line 673
    move-result v0

    .line 674
    if-nez v0, :cond_e

    .line 675
    .line 676
    sget-object v1, LX/IzA;->A01:LX/36I;

    .line 677
    .line 678
    const-string v0, "monospace"

    .line 679
    .line 680
    invoke-virtual {v0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 681
    .line 682
    .line 683
    move-result v0

    .line 684
    if-nez v0, :cond_e

    .line 685
    .line 686
    sget-object v1, LX/IzA;->A02:LX/36I;

    .line 687
    .line 688
    const-string v0, "sans-serif"

    .line 689
    .line 690
    invoke-virtual {v0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 691
    .line 692
    .line 693
    move-result v0

    .line 694
    if-nez v0, :cond_e

    .line 695
    .line 696
    sget-object v1, LX/IzA;->A03:LX/36I;

    .line 697
    .line 698
    const-string v0, "serif"

    .line 699
    .line 700
    invoke-virtual {v0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 701
    .line 702
    .line 703
    move-result v0

    .line 704
    if-nez v0, :cond_e

    .line 705
    .line 706
    invoke-virtual {v3}, Landroid/text/style/TypefaceSpan;->getFamily()Ljava/lang/String;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    const/4 v1, 0x0

    .line 711
    if-eqz v0, :cond_e

    .line 712
    .line 713
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 714
    .line 715
    .line 716
    move-result v3

    .line 717
    if-eqz v3, :cond_e

    .line 718
    .line 719
    invoke-static {v0, v5}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 720
    .line 721
    .line 722
    move-result-object v3

    .line 723
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 724
    .line 725
    invoke-static {v3, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 726
    .line 727
    .line 728
    move-result v4

    .line 729
    if-nez v4, :cond_e

    .line 730
    .line 731
    invoke-static {v0, v5}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 732
    .line 733
    .line 734
    move-result-object v0

    .line 735
    invoke-static {v3, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 736
    .line 737
    .line 738
    move-result v0

    .line 739
    if-nez v0, :cond_e

    .line 740
    .line 741
    if-eqz v3, :cond_e

    .line 742
    .line 743
    new-instance v0, LX/E2d;

    .line 744
    .line 745
    invoke-direct {v0, v3}, LX/E2d;-><init>(Landroid/graphics/Typeface;)V

    .line 746
    .line 747
    .line 748
    new-instance v1, LX/Jlp;

    .line 749
    .line 750
    invoke-direct {v1, v0}, LX/Jlp;-><init>(LX/Jnx;)V

    .line 751
    .line 752
    .line 753
    :cond_e
    new-instance v0, LX/2hh;

    .line 754
    .line 755
    move-object/from16 v31, v0

    .line 756
    .line 757
    move-object/from16 v32, v9

    .line 758
    .line 759
    move-object/from16 v33, v9

    .line 760
    .line 761
    move-object/from16 v34, v1

    .line 762
    .line 763
    move-object/from16 v35, v9

    .line 764
    .line 765
    move-object/from16 v36, v9

    .line 766
    .line 767
    move-object/from16 v37, v9

    .line 768
    .line 769
    move-object/from16 v38, v9

    .line 770
    .line 771
    move-object/from16 v39, v9

    .line 772
    .line 773
    move-object/from16 v40, v9

    .line 774
    .line 775
    move-object/from16 v41, v9

    .line 776
    .line 777
    move-object/from16 v42, v9

    .line 778
    .line 779
    move-wide/from16 v43, v29

    .line 780
    .line 781
    move-wide/from16 v45, v25

    .line 782
    .line 783
    move-wide/from16 v47, v25

    .line 784
    .line 785
    move-wide/from16 p0, v29

    .line 786
    .line 787
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 788
    .line 789
    .line 790
    goto/16 :goto_3

    .line 791
    .line 792
    :cond_f
    instance-of v0, v3, Landroid/text/style/UnderlineSpan;

    .line 793
    .line 794
    if-eqz v0, :cond_10

    .line 795
    .line 796
    move-object/from16 v40, v20

    .line 797
    .line 798
    goto/16 :goto_5

    .line 799
    .line 800
    :cond_10
    instance-of v0, v3, Landroid/text/style/URLSpan;

    .line 801
    .line 802
    if-eqz v0, :cond_0

    .line 803
    .line 804
    check-cast v3, Landroid/text/style/URLSpan;

    .line 805
    .line 806
    invoke-virtual {v3}, Landroid/text/style/URLSpan;->getURL()Ljava/lang/String;

    .line 807
    .line 808
    .line 809
    move-result-object v0

    .line 810
    if-eqz v0, :cond_0

    .line 811
    .line 812
    new-instance v3, LX/2iL;

    .line 813
    .line 814
    invoke-direct {v3, v9, v14, v0}, LX/2iL;-><init>(LX/2D4;LX/2iS;Ljava/lang/String;)V

    .line 815
    .line 816
    .line 817
    iget-object v4, v2, LX/2b4;->A01:Ljava/util/List;

    .line 818
    .line 819
    const-string v1, ""

    .line 820
    .line 821
    goto/16 :goto_4

    .line 822
    .line 823
    :cond_11
    new-instance v1, LX/2i5;

    .line 824
    .line 825
    invoke-direct {v1, v6}, LX/2i5;-><init>(I)V

    .line 826
    .line 827
    .line 828
    new-instance v0, LX/2hh;

    .line 829
    .line 830
    move-object/from16 v31, v0

    .line 831
    .line 832
    move-object/from16 v32, v9

    .line 833
    .line 834
    move-object/from16 v33, v9

    .line 835
    .line 836
    move-object/from16 v34, v9

    .line 837
    .line 838
    move-object/from16 v35, v1

    .line 839
    .line 840
    move-object/from16 v36, v9

    .line 841
    .line 842
    move-object/from16 v37, v9

    .line 843
    .line 844
    move-object/from16 v38, v9

    .line 845
    .line 846
    move-object/from16 v39, v9

    .line 847
    .line 848
    move-object/from16 v40, v9

    .line 849
    .line 850
    move-object/from16 v41, v9

    .line 851
    .line 852
    move-object/from16 v42, v9

    .line 853
    .line 854
    move-wide/from16 v43, v29

    .line 855
    .line 856
    move-wide/from16 v45, v25

    .line 857
    .line 858
    move-wide/from16 v47, v25

    .line 859
    .line 860
    move-wide/from16 p0, v29

    .line 861
    .line 862
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 863
    .line 864
    .line 865
    goto/16 :goto_3

    .line 866
    .line 867
    :cond_12
    sget-object v37, LX/2W8;->A01:LX/2W8;

    .line 868
    .line 869
    new-instance v0, LX/2hh;

    .line 870
    .line 871
    move-object/from16 v31, v0

    .line 872
    .line 873
    move-object/from16 v32, v9

    .line 874
    .line 875
    move-object/from16 v33, v9

    .line 876
    .line 877
    move-object/from16 v34, v9

    .line 878
    .line 879
    move-object/from16 v35, v9

    .line 880
    .line 881
    move-object/from16 v36, v9

    .line 882
    .line 883
    move-object/from16 v38, v9

    .line 884
    .line 885
    move-object/from16 v39, v9

    .line 886
    .line 887
    move-object/from16 v40, v9

    .line 888
    .line 889
    move-object/from16 v41, v9

    .line 890
    .line 891
    move-object/from16 v42, v9

    .line 892
    .line 893
    move-wide/from16 v43, v29

    .line 894
    .line 895
    move-wide/from16 v45, v25

    .line 896
    .line 897
    move-wide/from16 v47, v25

    .line 898
    .line 899
    move-wide/from16 p0, v29

    .line 900
    .line 901
    invoke-direct/range {v31 .. v50}, LX/2hh;-><init>(LX/2RV;LX/2hz;LX/IzA;LX/2i5;LX/2ie;LX/2W8;LX/0wO;LX/2hq;LX/2RW;LX/2Qz;Ljava/lang/String;JJJJ)V

    .line 902
    .line 903
    .line 904
    goto/16 :goto_3

    .line 905
    .line 906
    :cond_13
    invoke-virtual {v2}, LX/2b4;->A04()LX/2iK;

    .line 907
    .line 908
    .line 909
    move-result-object v3

    .line 910
    iget-object v2, v3, LX/2iK;->A00:Ljava/lang/String;

    .line 911
    .line 912
    new-array v1, v6, [C

    .line 913
    .line 914
    const/16 v0, 0xa

    .line 915
    .line 916
    aput-char v0, v1, v5

    .line 917
    .line 918
    invoke-static {v2, v1}, LX/AdT;->A0d(Ljava/lang/String;[C)Ljava/lang/String;

    .line 919
    .line 920
    .line 921
    move-result-object v0

    .line 922
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 923
    .line 924
    .line 925
    move-result v0

    .line 926
    invoke-virtual {v3, v5, v0}, LX/2iK;->A01(II)LX/2iK;

    .line 927
    .line 928
    .line 929
    move-result-object v0

    .line 930
    return-object v0

    .line 931
    :cond_14
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 932
    .line 933
    .line 934
    move-result-object v0

    .line 935
    throw v0
.end method
