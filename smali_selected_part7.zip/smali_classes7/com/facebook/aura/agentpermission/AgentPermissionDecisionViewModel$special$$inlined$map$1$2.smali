.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;

.field public final synthetic this$0:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;


# direct methods
.method public constructor <init>(LX/39x;Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 8

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_4

    .line 3
    .line 4
    move-object v7, p2

    .line 5
    check-cast v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;

    .line 6
    .line 7
    iget v2, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_4

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v5, :cond_5

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v6

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Ljava/util/List;

    .line 41
    .line 42
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    :cond_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    move-object v0, v2

    .line 57
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 58
    .line 59
    iget-object v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;->this$0:Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;

    .line 62
    .line 63
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel;->approvalId:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_2

    .line 70
    .line 71
    :goto_1
    const/4 v0, 0x0

    .line 72
    iput-object v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->L$0:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->L$1:Ljava/lang/Object;

    .line 75
    .line 76
    iput-object v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->L$2:Ljava/lang/Object;

    .line 77
    .line 78
    iput-object v0, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->L$3:Ljava/lang/Object;

    .line 79
    .line 80
    iput v5, v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;->label:I

    .line 81
    .line 82
    invoke-interface {v4, v2, v7}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    if-ne v0, v6, :cond_0

    .line 87
    .line 88
    return-object v6

    .line 89
    :cond_3
    const/4 v2, 0x0

    .line 90
    goto :goto_1

    .line 91
    :cond_4
    new-instance v7, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;

    .line 92
    .line 93
    invoke-direct {v7, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2$1;-><init>(Lcom/facebook/aura/agentpermission/AgentPermissionDecisionViewModel$special$$inlined$map$1$2;LX/2M4;)V

    .line 94
    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    throw v0
.end method
