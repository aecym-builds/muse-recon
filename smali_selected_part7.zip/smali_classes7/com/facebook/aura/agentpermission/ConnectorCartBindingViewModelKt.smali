.class public abstract Lcom/facebook/aura/agentpermission/ConnectorCartBindingViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final STOP_TIMEOUT_MS:J = 0x1388L
