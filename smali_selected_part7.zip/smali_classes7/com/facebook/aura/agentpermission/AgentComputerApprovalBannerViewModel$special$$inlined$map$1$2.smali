.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;


# direct methods
.method public constructor <init>(LX/39x;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 10

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_8

    .line 3
    .line 4
    move-object v8, p2

    .line 5
    check-cast v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;

    .line 6
    .line 7
    iget v2, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_8

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->label:I

    .line 23
    .line 24
    const/4 v9, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v9, :cond_9

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v7

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Ljava/util/List;

    .line 41
    .line 42
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    :cond_2
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    move-object v0, v1

    .line 61
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 62
    .line 63
    invoke-static {v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModelKt;->blocksItsOwnConversation(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_2

    .line 68
    .line 69
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_3
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_5

    .line 82
    .line 83
    const/4 v6, 0x0

    .line 84
    :cond_4
    :goto_2
    const/4 v0, 0x0

    .line 85
    iput-object v0, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->L$0:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v0, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->L$1:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v0, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->L$2:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v0, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->L$3:Ljava/lang/Object;

    .line 92
    .line 93
    iput v9, v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;->label:I

    .line 94
    .line 95
    invoke-interface {p0, v6, v8}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-ne v0, v7, :cond_0

    .line 100
    .line 101
    return-object v7

    .line 102
    :cond_5
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_4

    .line 111
    .line 112
    move-object v0, v6

    .line 113
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 114
    .line 115
    iget-wide v4, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestedAtMs:J

    .line 116
    .line 117
    :cond_6
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v3

    .line 121
    move-object v0, v3

    .line 122
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 123
    .line 124
    iget-wide v1, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->requestedAtMs:J

    .line 125
    .line 126
    cmp-long v0, v4, v1

    .line 127
    .line 128
    if-gez v0, :cond_7

    .line 129
    .line 130
    move-object v6, v3

    .line 131
    move-wide v4, v1

    .line 132
    :cond_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-nez v0, :cond_6

    .line 137
    .line 138
    goto :goto_2

    .line 139
    :cond_8
    new-instance v8, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;

    .line 140
    .line 141
    invoke-direct {v8, p0, p2}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2$1;-><init>(Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerViewModel$special$$inlined$map$1$2;LX/2M4;)V

    .line 142
    .line 143
    .line 144
    goto :goto_0

    .line 145
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    throw v0
.end method
