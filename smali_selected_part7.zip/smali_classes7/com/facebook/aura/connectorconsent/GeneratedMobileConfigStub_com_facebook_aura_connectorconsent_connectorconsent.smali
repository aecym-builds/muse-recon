.class public interface abstract Lcom/facebook/aura/connectorconsent/GeneratedMobileConfigStub_com_facebook_aura_connectorconsent_connectorconsent;
.super Ljava/lang/Object;
.source ""
