.class public final Lcom/facebook/aura/composer/upload/ImageBudget;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/composer/upload/ImageBudget;

.field public static final MAX_IMAGES:I = 0xa

.field public static final PER_IMAGE_TARGET_BYTES:J = 0x200000L

.field public static final TOTAL_BYTES:J = 0x1400000L


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/composer/upload/ImageBudget;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/composer/upload/ImageBudget;->INSTANCE:Lcom/facebook/aura/composer/upload/ImageBudget;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
