.class public final Lcom/facebook/aura/composer/view/AttachmentMenuId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CAMERA:I = 0x0

.field public static final FILES:I = 0x3

.field public static final INSTANCE:Lcom/facebook/aura/composer/view/AttachmentMenuId;

.field public static final PHOTOS:I = 0x1

.field public static final VIDEOS:I = 0x2


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/composer/view/AttachmentMenuId;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/composer/view/AttachmentMenuId;->INSTANCE:Lcom/facebook/aura/composer/view/AttachmentMenuId;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
