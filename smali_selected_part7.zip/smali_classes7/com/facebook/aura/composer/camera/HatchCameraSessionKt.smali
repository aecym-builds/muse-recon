.class public abstract Lcom/facebook/aura/composer/camera/HatchCameraSessionKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CAMERA_TIMEOUT_MS:J = 0x3a98L
