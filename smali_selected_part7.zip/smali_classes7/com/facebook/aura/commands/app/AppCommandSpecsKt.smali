.class public abstract Lcom/facebook/aura/commands/app/AppCommandSpecsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ACTION_OUTCOMES:Ljava/lang/String; = "The result\'s outcome is completed when the user finished it, declined when they turned it down or did not finish, failed when it could not be started, expired when they did not respond in time, not_shown when no conversation was on screen to show the card, already_done when nothing was needed, or unsupported when this device can\'t do it."

.field public static final APP_ACTION_TIMEOUT_MS:J = 0x1d4c0L
