.class public abstract Lcom/facebook/aura/commands/location/LocationGetHandlerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FIX_SEND_MARGIN_MS:J = 0x1f4L
