.class public interface abstract Lcom/facebook/aura/commands/photos/GeneratedMobileConfigStub_com_facebook_aura_commands_photos_photos;
.super Ljava/lang/Object;
.source ""
