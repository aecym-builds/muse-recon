.class public abstract Lcom/facebook/aura/commands/notifications/BlockedAppsNotificationFilterKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "BlockedAppsNotificationFilter"
