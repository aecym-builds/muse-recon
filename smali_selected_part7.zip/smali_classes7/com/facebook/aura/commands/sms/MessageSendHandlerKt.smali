.class public abstract Lcom/facebook/aura/commands/sms/MessageSendHandlerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "MessageSendHandler"
