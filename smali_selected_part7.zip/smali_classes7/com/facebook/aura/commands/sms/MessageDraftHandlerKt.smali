.class public abstract Lcom/facebook/aura/commands/sms/MessageDraftHandlerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "MessageDraftHandler"
