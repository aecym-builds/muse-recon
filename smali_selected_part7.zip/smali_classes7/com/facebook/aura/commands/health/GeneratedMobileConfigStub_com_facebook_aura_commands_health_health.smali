.class public interface abstract Lcom/facebook/aura/commands/health/GeneratedMobileConfigStub_com_facebook_aura_commands_health_health;
.super Ljava/lang/Object;
.source ""
