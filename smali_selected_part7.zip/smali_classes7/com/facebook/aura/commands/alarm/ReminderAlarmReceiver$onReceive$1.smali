.class public final Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.ReminderAlarmReceiver$onReceive$1"
    f = "ReminderAlarmReceiver.kt"
    l = {
        0x30,
        0x3b,
        0x40,
        0x5c,
        0x5f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $action:Ljava/lang/String;

.field public final synthetic $appContext:Landroid/content/Context;

.field public final synthetic $intent:Landroid/content/Intent;

.field public final synthetic $pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

.field public final synthetic $reminderId:Ljava/lang/String;

.field public I$0:I

.field public I$1:I

.field public J$0:J

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;Landroid/content/Intent;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Landroid/content/BroadcastReceiver$PendingResult;",
            "Landroid/content/Intent;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$action:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$intent:Landroid/content/Intent;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$action:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$intent:Landroid/content/Intent;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;

    .line 11
    .line 12
    move-object p0, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;Landroid/content/Intent;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 17
    .line 18
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    const-string v7, "Reminder "

    .line 3
    .line 4
    const-string v14, "Failed to handle reminder fire "

    .line 5
    .line 6
    move-object/from16 v0, p0

    .line 7
    .line 8
    iget-object v12, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 9
    .line 10
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 11
    .line 12
    iget v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 13
    .line 14
    const-string v11, "ReminderAlarmReceiver"

    .line 15
    .line 16
    const/4 v10, 0x5

    .line 17
    const/4 v8, 0x4

    .line 18
    const/4 v13, 0x3

    .line 19
    const/4 v9, 0x2

    .line 20
    const/4 v6, 0x1

    .line 21
    if-eqz v1, :cond_5

    .line 22
    .line 23
    if-eq v1, v6, :cond_4

    .line 24
    .line 25
    if-eq v1, v9, :cond_3

    .line 26
    .line 27
    if-eq v1, v13, :cond_2

    .line 28
    .line 29
    if-eq v1, v8, :cond_1

    .line 30
    .line 31
    if-ne v1, v10, :cond_0

    .line 32
    .line 33
    :try_start_0
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    goto/16 :goto_b
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    throw v0

    .line 43
    :cond_1
    iget-object v10, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$4:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 46
    .line 47
    goto/16 :goto_a

    .line 48
    .line 49
    :cond_2
    iget-object v4, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 52
    .line 53
    goto/16 :goto_4

    .line 54
    .line 55
    :cond_3
    iget-object v6, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 58
    .line 59
    goto/16 :goto_3

    .line 60
    .line 61
    :cond_4
    iget-wide v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->J$0:J

    .line 62
    .line 63
    iget-object v4, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_5
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :try_start_1
    sget-object v2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 72
    .line 73
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 74
    .line 75
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v2, v1}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    iget-object v2, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$action:Ljava/lang/String;

    .line 83
    .line 84
    const-string v1, "com.facebook.aura.REMINDER_SNOOZE"

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    if-eqz v1, :cond_a

    .line 91
    .line 92
    sget-object v3, Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;

    .line 93
    .line 94
    iget-object v2, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 95
    .line 96
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 100
    .line 101
    invoke-virtual {v3, v2, v1}, Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;->cancel$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 105
    .line 106
    .line 107
    move-result-wide v1

    .line 108
    const-wide/32 v7, 0x927c0

    .line 109
    .line 110
    .line 111
    add-long/2addr v1, v7

    .line 112
    iget-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 113
    .line 114
    iput-object v12, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 115
    .line 116
    iput-object v4, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 117
    .line 118
    iput-wide v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->J$0:J

    .line 119
    .line 120
    iput v6, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 121
    .line 122
    invoke-virtual {v4, v3, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    if-ne v3, v5, :cond_6

    .line 127
    .line 128
    return-object v5

    .line 129
    :goto_0
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    :cond_6
    check-cast v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 133
    .line 134
    if-eqz v3, :cond_7

    .line 135
    .line 136
    const/16 p0, 0x37df

    .line 137
    .line 138
    const/4 v7, 0x0

    .line 139
    const/16 v18, 0x0

    .line 140
    .line 141
    const-wide/16 v26, 0x0

    .line 142
    .line 143
    move-object/from16 v17, v7

    .line 144
    .line 145
    move/from16 v19, v18

    .line 146
    .line 147
    move-object/from16 v20, v7

    .line 148
    .line 149
    move-wide/from16 v21, v1

    .line 150
    .line 151
    move-object/from16 v23, v7

    .line 152
    .line 153
    move-object/from16 v24, v7

    .line 154
    .line 155
    move-object/from16 v25, v7

    .line 156
    .line 157
    move/from16 v28, v18

    .line 158
    .line 159
    move/from16 v29, v6

    .line 160
    .line 161
    move-object/from16 v30, v7

    .line 162
    .line 163
    move-object/from16 v31, v7

    .line 164
    .line 165
    move-object/from16 p1, v7

    .line 166
    .line 167
    move-object v15, v3

    .line 168
    move-object/from16 v16, v7

    .line 169
    .line 170
    invoke-static/range {v15 .. v33}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 171
    .line 172
    .line 173
    move-result-object v6

    .line 174
    :goto_1
    iput-object v7, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 175
    .line 176
    iput-object v7, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 177
    .line 178
    iput-object v6, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 179
    .line 180
    iput-wide v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->J$0:J

    .line 181
    .line 182
    iput v9, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 183
    .line 184
    invoke-virtual {v4, v6, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    if-ne v1, v5, :cond_9

    .line 189
    .line 190
    goto :goto_2

    .line 191
    :cond_7
    iget-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 192
    .line 193
    iget-object v8, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$intent:Landroid/content/Intent;

    .line 194
    .line 195
    invoke-static {v1, v2}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 196
    .line 197
    .line 198
    move-result-object v7

    .line 199
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 200
    .line 201
    .line 202
    move-result-object v6

    .line 203
    invoke-virtual {v7, v6}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 204
    .line 205
    .line 206
    move-result-object v7

    .line 207
    sget-object v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;->$childSerializers:[Lkotlin/Lazy;

    .line 208
    .line 209
    const-string v6, "reminder_label"

    .line 210
    .line 211
    invoke-virtual {v8, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v17

    .line 215
    if-nez v17, :cond_8

    .line 216
    .line 217
    const-string v17, ""

    .line 218
    .line 219
    :cond_8
    invoke-virtual {v7}, Ljava/time/ZonedDateTime;->getHour()I

    .line 220
    .line 221
    .line 222
    move-result v18

    .line 223
    invoke-virtual {v7}, Ljava/time/ZonedDateTime;->getMinute()I

    .line 224
    .line 225
    .line 226
    move-result v19

    .line 227
    const/4 v7, 0x0

    .line 228
    const-string v20, ""

    .line 229
    .line 230
    const-wide/16 v26, 0x0

    .line 231
    .line 232
    const/16 v28, 0x0

    .line 233
    .line 234
    new-instance v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 235
    .line 236
    move-object v15, v6

    .line 237
    move-object/from16 v16, v3

    .line 238
    .line 239
    move-wide/from16 v21, v1

    .line 240
    .line 241
    move-object/from16 v23, v7

    .line 242
    .line 243
    move-object/from16 v24, v7

    .line 244
    .line 245
    move-object/from16 v25, v7

    .line 246
    .line 247
    move/from16 v29, v28

    .line 248
    .line 249
    move-object/from16 v30, v7

    .line 250
    .line 251
    move-object/from16 v31, v7

    .line 252
    .line 253
    invoke-direct/range {v15 .. v31}, Lcom/facebook/aura/commands/alarm/ShadowReminder;-><init>(Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;)V

    .line 254
    .line 255
    .line 256
    goto :goto_1

    .line 257
    :goto_2
    return-object v5

    .line 258
    :goto_3
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    :cond_9
    sget-object v2, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 262
    .line 263
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 264
    .line 265
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {v2, v1, v6}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Z

    .line 269
    .line 270
    .line 271
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 272
    .line 273
    goto :goto_5

    .line 274
    :cond_a
    iget-object v2, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 275
    .line 276
    const/4 v1, 0x0

    .line 277
    iput-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 278
    .line 279
    iput-object v4, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 280
    .line 281
    iput v13, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 282
    .line 283
    invoke-virtual {v4, v2, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v3

    .line 287
    if-ne v3, v5, :cond_b

    .line 288
    .line 289
    return-object v5

    .line 290
    :goto_4
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    :cond_b
    check-cast v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 294
    .line 295
    if-nez v3, :cond_c

    .line 296
    .line 297
    iget-object v2, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 298
    .line 299
    const-string v1, " fired but not found in store"

    .line 300
    .line 301
    invoke-static {v7, v2, v1}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object v1

    .line 305
    invoke-static {v11, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 309
    .line 310
    :goto_5
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 311
    .line 312
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 313
    .line 314
    .line 315
    return-object v5

    .line 316
    :cond_c
    :try_start_2
    sget-object v2, Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;

    .line 317
    .line 318
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 319
    .line 320
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v2, v1, v3}, Lcom/facebook/aura/commands/alarm/HatchReminderNotifier;->show$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v3}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 327
    .line 328
    .line 329
    move-result-object v9

    .line 330
    iget-boolean v1, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->pendingSnooze:Z

    .line 331
    .line 332
    if-eqz v1, :cond_d

    .line 333
    .line 334
    iget v7, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->firedCount:I

    .line 335
    .line 336
    goto :goto_6

    .line 337
    :cond_d
    iget v1, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->firedCount:I

    .line 338
    .line 339
    add-int/lit8 v7, v1, 0x1

    .line 340
    .line 341
    :goto_6
    if-eqz v9, :cond_e

    .line 342
    .line 343
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 344
    .line 345
    goto :goto_7

    .line 346
    :cond_e
    const/4 v1, 0x0

    .line 347
    :goto_7
    if-eqz v1, :cond_f

    .line 348
    .line 349
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 350
    .line 351
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 352
    .line 353
    .line 354
    move-result v1

    .line 355
    if-lt v7, v1, :cond_f

    .line 356
    .line 357
    goto :goto_8

    .line 358
    :cond_f
    const/4 v6, 0x0

    .line 359
    :goto_8
    const-wide/16 v15, -0x1

    .line 360
    .line 361
    if-eqz v9, :cond_10

    .line 362
    .line 363
    if-nez v6, :cond_10

    .line 364
    .line 365
    sget-object v17, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 366
    .line 367
    iget v13, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->hour:I

    .line 368
    .line 369
    iget v12, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->minute:I

    .line 370
    .line 371
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 372
    .line 373
    .line 374
    move-result-wide v21

    .line 375
    iget-wide v1, v3, Lcom/facebook/aura/commands/alarm/ShadowReminder;->anchorMs:J

    .line 376
    .line 377
    invoke-virtual {v3}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->zoneId()Ljava/time/ZoneId;

    .line 378
    .line 379
    .line 380
    move-result-object v25

    .line 381
    move-wide/from16 v23, v1

    .line 382
    .line 383
    move/from16 v18, v13

    .line 384
    .line 385
    move/from16 v19, v12

    .line 386
    .line 387
    move-object/from16 v20, v9

    .line 388
    .line 389
    invoke-virtual/range {v17 .. v25}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 390
    .line 391
    .line 392
    move-result-wide v1

    .line 393
    goto :goto_9

    .line 394
    :cond_10
    const-wide/16 v1, -0x1

    .line 395
    .line 396
    :goto_9
    cmp-long v9, v1, v15

    .line 397
    .line 398
    if-eqz v9, :cond_12

    .line 399
    .line 400
    const/16 p0, 0x33df

    .line 401
    .line 402
    const/4 v9, 0x0

    .line 403
    const/16 v18, 0x0

    .line 404
    .line 405
    const-wide/16 v26, 0x0

    .line 406
    .line 407
    move-object/from16 v17, v9

    .line 408
    .line 409
    move/from16 v19, v18

    .line 410
    .line 411
    move-object/from16 v20, v9

    .line 412
    .line 413
    move-wide/from16 v21, v1

    .line 414
    .line 415
    move-object/from16 v23, v9

    .line 416
    .line 417
    move-object/from16 v24, v9

    .line 418
    .line 419
    move-object/from16 v25, v9

    .line 420
    .line 421
    move/from16 v28, v7

    .line 422
    .line 423
    move/from16 v29, v18

    .line 424
    .line 425
    move-object/from16 v30, v9

    .line 426
    .line 427
    move-object/from16 v31, v9

    .line 428
    .line 429
    move-object/from16 p1, v9

    .line 430
    .line 431
    move-object v15, v3

    .line 432
    move-object/from16 v16, v9

    .line 433
    .line 434
    invoke-static/range {v15 .. v33}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 435
    .line 436
    .line 437
    move-result-object v10

    .line 438
    iput-object v9, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 439
    .line 440
    iput-object v9, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 441
    .line 442
    iput-object v9, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 443
    .line 444
    iput-object v9, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$3:Ljava/lang/Object;

    .line 445
    .line 446
    iput-object v10, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$4:Ljava/lang/Object;

    .line 447
    .line 448
    iput v7, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->I$0:I

    .line 449
    .line 450
    iput v6, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->I$1:I

    .line 451
    .line 452
    iput-wide v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->J$0:J

    .line 453
    .line 454
    iput v8, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 455
    .line 456
    invoke-virtual {v4, v10, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v1

    .line 460
    if-ne v1, v5, :cond_11

    .line 461
    .line 462
    return-object v5

    .line 463
    :goto_a
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 464
    .line 465
    .line 466
    :cond_11
    sget-object v2, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 467
    .line 468
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 469
    .line 470
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 471
    .line 472
    .line 473
    invoke-virtual {v2, v1, v10}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Z

    .line 474
    .line 475
    .line 476
    goto :goto_b

    .line 477
    :cond_12
    iget-object v8, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 478
    .line 479
    const/4 v3, 0x0

    .line 480
    iput-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 481
    .line 482
    iput-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 483
    .line 484
    iput-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 485
    .line 486
    iput-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->L$3:Ljava/lang/Object;

    .line 487
    .line 488
    iput v7, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->I$0:I

    .line 489
    .line 490
    iput v6, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->I$1:I

    .line 491
    .line 492
    iput-wide v1, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->J$0:J

    .line 493
    .line 494
    iput v10, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->label:I

    .line 495
    .line 496
    invoke-virtual {v4, v8, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 497
    .line 498
    .line 499
    move-result-object v1

    .line 500
    if-ne v1, v5, :cond_13

    .line 501
    .line 502
    return-object v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 503
    :catch_0
    move-exception v4

    .line 504
    :try_start_3
    iget-object v3, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$reminderId:Ljava/lang/String;

    .line 505
    .line 506
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 507
    .line 508
    .line 509
    move-result-object v2

    .line 510
    const-string v1, ": "

    .line 511
    .line 512
    invoke-static {v14, v3, v1, v2}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 513
    .line 514
    .line 515
    move-result-object v1

    .line 516
    invoke-static {v11, v1, v4}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 517
    .line 518
    .line 519
    :cond_13
    :goto_b
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 520
    .line 521
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 522
    .line 523
    .line 524
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 525
    .line 526
    return-object v5

    .line 527
    :catchall_0
    move-exception v1

    .line 528
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 529
    .line 530
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 531
    .line 532
    .line 533
    throw v1
.end method
