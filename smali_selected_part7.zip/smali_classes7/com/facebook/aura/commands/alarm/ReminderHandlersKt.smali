.class public abstract Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEFAULT_REMINDER_SNOOZE_MINUTES:I = 0xa

.field public static final MAX_REMINDERS:I = 0x64

.field public static final PARAM_REMINDERS:Ljava/lang/String; = "reminders"

.field public static final PARAM_REMINDERS_JSON:Ljava/lang/String; = "reminders_json"

.field public static final PARAM_TARGETS:Ljava/lang/String; = "targets"

.field public static final PARAM_TARGETS_JSON:Ljava/lang/String; = "targets_json"

.field public static final PARAM_UPDATES:Ljava/lang/String; = "updates"

.field public static final PARAM_UPDATES_JSON:Ljava/lang/String; = "updates_json"

.field public static final TAG:Ljava/lang/String; = "ReminderHandlers"

.field public static volatile legacyReminderEvictDone:Z


# direct methods
.method public static final synthetic access$computeReminderDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeReminderDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeReminderList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeReminderSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeReminderSnooze(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderSnooze(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeReminderUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->computeReminderUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$evictLegacyReminderRowsOnce(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rescheduleReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->rescheduleReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final asCalendarSnooze(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lcom/facebook/aura/commands/alarm/ShadowReminder;
    .locals 18

    .line 0
    move-object/from16 v2, p0

    .line 1
    .line 2
    iget-object v1, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->CALENDAR:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 5
    .line 6
    if-ne v1, v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v2}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-wide v0, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 19
    .line 20
    invoke-static {v0, v1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v2}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->zoneId()Ljava/time/ZoneId;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v1, v0}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v0}, Ljava/time/ZonedDateTime;->getHour()I

    .line 37
    .line 38
    .line 39
    move-result v5

    .line 40
    invoke-virtual {v0}, Ljava/time/ZonedDateTime;->getMinute()I

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    const/4 v10, 0x0

    .line 45
    const-string v7, ""

    .line 46
    .line 47
    iget-object v4, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->label:Ljava/lang/String;

    .line 48
    .line 49
    iget-wide v8, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 50
    .line 51
    iget-object v11, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->calendarId:Ljava/lang/Long;

    .line 52
    .line 53
    const-wide/16 v13, 0x0

    .line 54
    .line 55
    const/4 v15, 0x0

    .line 56
    iget-object v1, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->timezone:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v0, v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 59
    .line 60
    move-object v12, v10

    .line 61
    move/from16 v16, v15

    .line 62
    .line 63
    move-object/from16 v17, v1

    .line 64
    .line 65
    move-object/from16 p0, v0

    .line 66
    .line 67
    invoke-virtual/range {v2 .. v18}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy(Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    return-object v0

    .line 72
    :cond_0
    return-object p0
.end method

.method public static final calendarAccessError(Landroid/content/Context;Ljava/util/List;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Ljava/util/Collection;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return-object v0

    .line 12
    :cond_1
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 27
    .line 28
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 29
    .line 30
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->CALENDAR:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 31
    .line 32
    if-ne v1, v0, :cond_2

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 35
    .line 36
    invoke-virtual {v0, p0}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->hasAccess(Landroid/content/Context;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    const/4 v2, 0x0

    .line 43
    const-string v3, "Calendar access is off, so reminders saved in the user\'s calendar can\'t be changed here. The user can turn calendar access back on, or change them in their calendar app."

    .line 44
    .line 45
    const/4 v1, 0x0

    .line 46
    new-instance v0, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 47
    .line 48
    move-object p0, v2

    .line 49
    move-object p1, v2

    .line 50
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-object v0
.end method

.method public static final computeReminderDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;

    .line 1
    .line 2
    if-eqz v0, :cond_10

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_10

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x3

    .line 25
    const/4 v9, 0x2

    .line 26
    const/4 v8, 0x1

    .line 27
    if-eqz v2, :cond_4

    .line 28
    .line 29
    if-eq v2, v8, :cond_7

    .line 30
    .line 31
    if-eq v2, v9, :cond_3

    .line 32
    .line 33
    if-ne v2, v1, :cond_11

    .line 34
    .line 35
    iget-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$11:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v2, Ljava/util/Iterator;

    .line 38
    .line 39
    iget-object p1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$10:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p1, Ljava/util/List;

    .line 42
    .line 43
    iget-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p0, Ljava/util/Iterator;

    .line 46
    .line 47
    iget-object v9, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v9, LX/Bcq;

    .line 50
    .line 51
    iget-object v8, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$7:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v8, LX/Bcq;

    .line 54
    .line 55
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v7, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 58
    .line 59
    iget-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v3, Landroid/content/Context;

    .line 62
    .line 63
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v4, Ljava/util/List;

    .line 66
    .line 67
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_0
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_2

    .line 75
    .line 76
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 81
    .line 82
    const/4 v0, 0x0

    .line 83
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$0:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$1:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$2:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$6:Ljava/lang/Object;

    .line 96
    .line 97
    iput-object v8, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$7:Ljava/lang/Object;

    .line 98
    .line 99
    iput-object v9, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 100
    .line 101
    iput-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 102
    .line 103
    iput-object p1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$10:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$11:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$12:Ljava/lang/Object;

    .line 108
    .line 109
    const/4 v0, 0x3

    .line 110
    iput v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 111
    .line 112
    invoke-static {v3, v7, v1, v5}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    if-ne v0, v6, :cond_0

    .line 117
    .line 118
    :cond_1
    return-object v6

    .line 119
    :cond_2
    new-instance v2, LX/BcB;

    .line 120
    .line 121
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 122
    .line 123
    .line 124
    invoke-static {p1}, LX/B89;->A0T(Ljava/util/List;)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 129
    .line 130
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 131
    .line 132
    const-string v0, "reminder_id"

    .line 133
    .line 134
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 135
    .line 136
    .line 137
    const-string v1, "message"

    .line 138
    .line 139
    const-string v0, "Reminder dismissed"

    .line 140
    .line 141
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    invoke-virtual {v9, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 149
    .line 150
    .line 151
    goto/16 :goto_6

    .line 152
    .line 153
    :cond_3
    iget-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$12:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v2, Ljava/util/Collection;

    .line 156
    .line 157
    iget-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 158
    .line 159
    check-cast p0, Ljava/util/Iterator;

    .line 160
    .line 161
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 162
    .line 163
    check-cast v1, Ljava/util/Collection;

    .line 164
    .line 165
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v7, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 168
    .line 169
    iget-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast v3, Landroid/content/Context;

    .line 172
    .line 173
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast v4, Ljava/util/List;

    .line 176
    .line 177
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    goto :goto_4

    .line 181
    :cond_4
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    iget-object v0, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 185
    .line 186
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 187
    .line 188
    .line 189
    invoke-static {p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    :try_start_0
    const-string v1, "targets_json"

    .line 194
    .line 195
    const-string v0, "targets"

    .line 196
    .line 197
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    if-eqz v1, :cond_14

    .line 202
    .line 203
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    if-nez v0, :cond_13

    .line 208
    .line 209
    invoke-static {v1}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 210
    .line 211
    .line 212
    move-result-object v4

    .line 213
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 214
    .line 215
    .line 216
    move-result-object v3

    .line 217
    const/4 v2, 0x0

    .line 218
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 219
    .line 220
    .line 221
    move-result v0

    .line 222
    if-eqz v0, :cond_6

    .line 223
    .line 224
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    add-int/lit8 v1, v2, 0x1

    .line 229
    .line 230
    if-gez v2, :cond_5

    .line 231
    .line 232
    invoke-static {}, LX/B8B;->A1A()V

    .line 233
    .line 234
    .line 235
    goto/16 :goto_7

    .line 236
    .line 237
    :cond_5
    check-cast v0, Lkotlinx/serialization/json/JsonObject;

    .line 238
    .line 239
    invoke-static {v2, v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->parseReminderDismissTarget(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move v2, v1

    .line 247
    goto :goto_2
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 248
    :cond_6
    iget-object v3, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 249
    .line 250
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 251
    .line 252
    invoke-virtual {v0, v3}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 253
    .line 254
    .line 255
    move-result-object v7

    .line 256
    invoke-static {v4}, LX/0BR;->A04(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 257
    .line 258
    .line 259
    move-result-object v2

    .line 260
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 261
    .line 262
    .line 263
    move-result-object p0

    .line 264
    goto :goto_5

    .line 265
    :cond_7
    iget-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$12:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast v2, Ljava/util/Collection;

    .line 268
    .line 269
    iget-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 270
    .line 271
    check-cast p0, Ljava/util/Iterator;

    .line 272
    .line 273
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 274
    .line 275
    check-cast v1, Ljava/util/Collection;

    .line 276
    .line 277
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 278
    .line 279
    check-cast v7, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 280
    .line 281
    iget-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 282
    .line 283
    check-cast v3, Landroid/content/Context;

    .line 284
    .line 285
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 286
    .line 287
    check-cast v4, Ljava/util/List;

    .line 288
    .line 289
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    :goto_3
    invoke-static {v0}, LX/B8B;->A15(Ljava/lang/Object;)Ljava/util/List;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    :goto_4
    invoke-interface {v2, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 297
    .line 298
    .line 299
    move-object v2, v1

    .line 300
    :goto_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 301
    .line 302
    .line 303
    move-result v0

    .line 304
    if-eqz v0, :cond_b

    .line 305
    .line 306
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    check-cast v1, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;

    .line 311
    .line 312
    iget-object v0, v1, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;->reminderId:Ljava/lang/String;

    .line 313
    .line 314
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 315
    .line 316
    .line 317
    move-result v0

    .line 318
    if-lez v0, :cond_8

    .line 319
    .line 320
    iget-object v1, v1, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;->reminderId:Ljava/lang/String;

    .line 321
    .line 322
    const/4 v0, 0x0

    .line 323
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$0:Ljava/lang/Object;

    .line 324
    .line 325
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$1:Ljava/lang/Object;

    .line 326
    .line 327
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$2:Ljava/lang/Object;

    .line 328
    .line 329
    iput-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 330
    .line 331
    iput-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 332
    .line 333
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 334
    .line 335
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$6:Ljava/lang/Object;

    .line 336
    .line 337
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$7:Ljava/lang/Object;

    .line 338
    .line 339
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 340
    .line 341
    iput-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 342
    .line 343
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$10:Ljava/lang/Object;

    .line 344
    .line 345
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$11:Ljava/lang/Object;

    .line 346
    .line 347
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$12:Ljava/lang/Object;

    .line 348
    .line 349
    iput v8, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 350
    .line 351
    invoke-virtual {v7, v1, v5}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    if-eq v0, v6, :cond_1

    .line 356
    .line 357
    move-object v1, v2

    .line 358
    goto :goto_3

    .line 359
    :cond_8
    iget-object v0, v1, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;->messageLabel:Ljava/lang/String;

    .line 360
    .line 361
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 362
    .line 363
    .line 364
    move-result v0

    .line 365
    if-lez v0, :cond_9

    .line 366
    .line 367
    iget-object v1, v1, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;->messageLabel:Ljava/lang/String;

    .line 368
    .line 369
    const/4 v0, 0x0

    .line 370
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$0:Ljava/lang/Object;

    .line 371
    .line 372
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$1:Ljava/lang/Object;

    .line 373
    .line 374
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$2:Ljava/lang/Object;

    .line 375
    .line 376
    iput-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$3:Ljava/lang/Object;

    .line 377
    .line 378
    iput-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$4:Ljava/lang/Object;

    .line 379
    .line 380
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$5:Ljava/lang/Object;

    .line 381
    .line 382
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$6:Ljava/lang/Object;

    .line 383
    .line 384
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$7:Ljava/lang/Object;

    .line 385
    .line 386
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$8:Ljava/lang/Object;

    .line 387
    .line 388
    iput-object p0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$9:Ljava/lang/Object;

    .line 389
    .line 390
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$10:Ljava/lang/Object;

    .line 391
    .line 392
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$11:Ljava/lang/Object;

    .line 393
    .line 394
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->L$12:Ljava/lang/Object;

    .line 395
    .line 396
    iput v9, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;->label:I

    .line 397
    .line 398
    invoke-virtual {v7, v1, v5}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findByLabel(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object v0

    .line 402
    if-ne v0, v6, :cond_a

    .line 403
    .line 404
    return-object v6

    .line 405
    :cond_9
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 406
    .line 407
    :cond_a
    move-object v1, v2

    .line 408
    goto :goto_4

    .line 409
    :cond_b
    check-cast v2, Ljava/util/List;

    .line 410
    .line 411
    instance-of v0, v2, Ljava/util/Collection;

    .line 412
    .line 413
    if-eqz v0, :cond_d

    .line 414
    .line 415
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 416
    .line 417
    .line 418
    move-result v0

    .line 419
    if-eqz v0, :cond_d

    .line 420
    .line 421
    :cond_c
    invoke-static {v2}, LX/0BR;->A05(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    invoke-static {v3, v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->calendarAccessError(Landroid/content/Context;Ljava/util/List;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 426
    .line 427
    .line 428
    move-result-object v0

    .line 429
    if-nez v0, :cond_f

    .line 430
    .line 431
    new-instance v8, LX/Bcq;

    .line 432
    .line 433
    invoke-direct {v8}, LX/Bcq;-><init>()V

    .line 434
    .line 435
    .line 436
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 437
    .line 438
    .line 439
    move-result-object p0

    .line 440
    move-object v9, v8

    .line 441
    :goto_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 442
    .line 443
    .line 444
    move-result v0

    .line 445
    if-eqz v0, :cond_12

    .line 446
    .line 447
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 448
    .line 449
    .line 450
    move-result-object p1

    .line 451
    check-cast p1, Ljava/util/List;

    .line 452
    .line 453
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 454
    .line 455
    .line 456
    move-result-object v2

    .line 457
    goto/16 :goto_1

    .line 458
    .line 459
    :cond_d
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    :cond_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 464
    .line 465
    .line 466
    move-result v0

    .line 467
    if-eqz v0, :cond_c

    .line 468
    .line 469
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 470
    .line 471
    .line 472
    move-result-object v0

    .line 473
    check-cast v0, Ljava/util/List;

    .line 474
    .line 475
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 476
    .line 477
    .line 478
    move-result v0

    .line 479
    if-eqz v0, :cond_e

    .line 480
    .line 481
    const/4 v2, 0x0

    .line 482
    const-string v3, "No reminder found matching the given ID or label"

    .line 483
    .line 484
    const/4 v1, 0x0

    .line 485
    new-instance v0, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 486
    .line 487
    move-object v4, v2

    .line 488
    move-object v5, v2

    .line 489
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 490
    .line 491
    .line 492
    :cond_f
    return-object v0

    .line 493
    :cond_10
    new-instance v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;

    .line 494
    .line 495
    invoke-direct {v5, p2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismiss$1;-><init>(LX/2M4;)V

    .line 496
    .line 497
    .line 498
    goto/16 :goto_0

    .line 499
    .line 500
    :cond_11
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 501
    .line 502
    .line 503
    move-result-object v0

    .line 504
    throw v0

    .line 505
    :goto_7
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 506
    .line 507
    .line 508
    move-result-object v0

    .line 509
    goto :goto_8

    .line 510
    :cond_12
    invoke-virtual {v8}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 511
    .line 512
    .line 513
    move-result-object v3

    .line 514
    new-instance v2, LX/BcB;

    .line 515
    .line 516
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 517
    .line 518
    .line 519
    invoke-static {v4, v2}, LX/IEb;->A0D(Ljava/util/List;LX/BcB;)Ljava/lang/Integer;

    .line 520
    .line 521
    .line 522
    move-result-object v1

    .line 523
    const-string v0, "dismissed_count"

    .line 524
    .line 525
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 526
    .line 527
    .line 528
    const-string v0, "reminders"

    .line 529
    .line 530
    invoke-static {v0, v3, v2}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 531
    .line 532
    .line 533
    move-result-object v0

    .line 534
    return-object v0

    .line 535
    :cond_13
    :try_start_1
    const/16 v0, 0xc

    .line 536
    .line 537
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 538
    .line 539
    .line 540
    move-result-object v0

    .line 541
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 542
    .line 543
    .line 544
    move-result-object v0

    .line 545
    goto :goto_8

    .line 546
    :cond_14
    const/16 v0, 0x1a

    .line 547
    .line 548
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 549
    .line 550
    .line 551
    move-result-object v0

    .line 552
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 553
    .line 554
    .line 555
    move-result-object v0

    .line 556
    :goto_8
    throw v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 557
    :catch_0
    move-exception v0

    .line 558
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v0

    .line 562
    if-nez v0, :cond_15

    .line 563
    .line 564
    const-string v0, "Invalid reminder dismiss parameters"

    .line 565
    .line 566
    :cond_15
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 567
    .line 568
    .line 569
    move-result-object v0

    .line 570
    return-object v0
.end method

.method public static final computeReminderDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;

    .line 1
    .line 2
    if-eqz v0, :cond_c

    .line 3
    .line 4
    move-object v8, p1

    .line 5
    check-cast v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;

    .line 6
    .line 7
    iget v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_c

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v9, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 23
    .line 24
    const-string v7, "removed_ids"

    .line 25
    .line 26
    const/16 v0, 0x61

    .line 27
    .line 28
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v6

    .line 32
    const/4 v5, 0x3

    .line 33
    const/4 v10, 0x2

    .line 34
    const/4 v4, 0x1

    .line 35
    const/4 v3, 0x0

    .line 36
    if-eqz v2, :cond_5

    .line 37
    .line 38
    if-eq v2, v4, :cond_6

    .line 39
    .line 40
    if-eq v2, v10, :cond_8

    .line 41
    .line 42
    if-ne v2, v5, :cond_e

    .line 43
    .line 44
    iget-object p0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$4:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p0, Ljava/util/Iterator;

    .line 47
    .line 48
    iget-object v10, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$3:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v10, Ljava/util/List;

    .line 51
    .line 52
    iget-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, Landroid/content/Context;

    .line 55
    .line 56
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_0
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_4

    .line 64
    .line 65
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    check-cast p1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 70
    .line 71
    iget-object v1, p1, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 72
    .line 73
    if-nez v1, :cond_1

    .line 74
    .line 75
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 76
    .line 77
    :cond_1
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 78
    .line 79
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eq v0, v3, :cond_3

    .line 84
    .line 85
    if-ne v0, v4, :cond_d

    .line 86
    .line 87
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 88
    .line 89
    const/4 v0, 0x0

    .line 90
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$0:Ljava/lang/Object;

    .line 91
    .line 92
    iput-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$2:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v10, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$3:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object p0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$4:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$5:Ljava/lang/Object;

    .line 101
    .line 102
    iput v5, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 103
    .line 104
    invoke-virtual {v1, v2, p1, v8}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->remove(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    if-ne v0, v9, :cond_0

    .line 109
    .line 110
    :cond_2
    return-object v9

    .line 111
    :cond_3
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 112
    .line 113
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 114
    .line 115
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    goto :goto_1

    .line 119
    :cond_4
    new-instance v4, LX/BcB;

    .line 120
    .line 121
    invoke-direct {v4}, LX/BcB;-><init>()V

    .line 122
    .line 123
    .line 124
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-static {v0, v6, v4}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 133
    .line 134
    .line 135
    new-instance v2, LX/Bcq;

    .line 136
    .line 137
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 138
    .line 139
    .line 140
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_a

    .line 149
    .line 150
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 155
    .line 156
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 157
    .line 158
    invoke-static {v0, v2}, LX/BgH;->A06(Ljava/lang/String;LX/Bcq;)V

    .line 159
    .line 160
    .line 161
    goto :goto_2

    .line 162
    :cond_5
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    iget-object v0, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 166
    .line 167
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 168
    .line 169
    .line 170
    iget-object v2, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 171
    .line 172
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 173
    .line 174
    invoke-virtual {v0, v2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 175
    .line 176
    .line 177
    move-result-object p0

    .line 178
    const/4 v0, 0x0

    .line 179
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$0:Ljava/lang/Object;

    .line 180
    .line 181
    iput-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 182
    .line 183
    iput-object p0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$2:Ljava/lang/Object;

    .line 184
    .line 185
    iput-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$3:Ljava/lang/Object;

    .line 186
    .line 187
    iput v4, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 188
    .line 189
    invoke-virtual {p0, v8}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    if-eq v1, v9, :cond_2

    .line 194
    .line 195
    move-object v0, v2

    .line 196
    goto :goto_3

    .line 197
    :cond_6
    iget-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$3:Ljava/lang/Object;

    .line 198
    .line 199
    check-cast v0, Landroid/content/Context;

    .line 200
    .line 201
    iget-object p0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$2:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 204
    .line 205
    iget-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 206
    .line 207
    check-cast v2, Landroid/content/Context;

    .line 208
    .line 209
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    :goto_3
    check-cast v1, Ljava/util/List;

    .line 213
    .line 214
    invoke-static {v0, v1}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->calendarAccessError(Landroid/content/Context;Ljava/util/List;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    if-eqz v0, :cond_7

    .line 219
    .line 220
    return-object v0

    .line 221
    :cond_7
    const/4 v0, 0x0

    .line 222
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$0:Ljava/lang/Object;

    .line 223
    .line 224
    iput-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 225
    .line 226
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$2:Ljava/lang/Object;

    .line 227
    .line 228
    iput-object v0, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$3:Ljava/lang/Object;

    .line 229
    .line 230
    iput v10, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->label:I

    .line 231
    .line 232
    invoke-virtual {p0, v8}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->clear(LX/2M4;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    if-ne v1, v9, :cond_9

    .line 237
    .line 238
    return-object v9

    .line 239
    :cond_8
    iget-object v2, v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;->L$1:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v2, Landroid/content/Context;

    .line 242
    .line 243
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    :cond_9
    check-cast v1, Ljava/util/List;

    .line 247
    .line 248
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 249
    .line 250
    .line 251
    move-result v0

    .line 252
    if-eqz v0, :cond_b

    .line 253
    .line 254
    new-instance v4, LX/BcB;

    .line 255
    .line 256
    invoke-direct {v4}, LX/BcB;-><init>()V

    .line 257
    .line 258
    .line 259
    invoke-static {v3}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    invoke-static {v0, v6, v4}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 264
    .line 265
    .line 266
    new-instance v2, LX/Bcq;

    .line 267
    .line 268
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 269
    .line 270
    .line 271
    :cond_a
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    invoke-static {v7, v0, v4}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 276
    .line 277
    .line 278
    move-result-object v9

    .line 279
    return-object v9

    .line 280
    :cond_b
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    move-object v10, v1

    .line 285
    goto/16 :goto_1

    .line 286
    .line 287
    :cond_c
    new-instance v8, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;

    .line 288
    .line 289
    invoke-direct {v8, p1}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderDismissAll$1;-><init>(LX/2M4;)V

    .line 290
    .line 291
    .line 292
    goto/16 :goto_0

    .line 293
    .line 294
    :cond_d
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 295
    .line 296
    .line 297
    move-result-object v0

    .line 298
    throw v0

    .line 299
    :cond_e
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 300
    .line 301
    .line 302
    move-result-object v0

    .line 303
    throw v0
.end method

.method public static final computeReminderList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;

    .line 3
    .line 4
    if-eqz v0, :cond_5

    .line 5
    .line 6
    move-object v7, v3

    .line 7
    check-cast v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;

    .line 8
    .line 9
    iget v2, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_5

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v2, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->label:I

    .line 25
    .line 26
    const/4 v5, 0x2

    .line 27
    const/4 v4, 0x1

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    if-eq v0, v4, :cond_3

    .line 31
    .line 32
    if-ne v0, v5, :cond_8

    .line 33
    .line 34
    iget-wide v0, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->J$0:J

    .line 35
    .line 36
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    check-cast v2, Ljava/lang/Iterable;

    .line 40
    .line 41
    invoke-static {v2}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_6

    .line 54
    .line 55
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    check-cast v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 60
    .line 61
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 62
    .line 63
    sget-object v2, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->CALENDAR:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 64
    .line 65
    if-ne v3, v2, :cond_1

    .line 66
    .line 67
    invoke-static {v6, v0, v1}, Lcom/facebook/aura/commands/alarm/ReminderCalendarKt;->nextOccurrence(Lcom/facebook/aura/commands/alarm/ShadowReminder;J)J

    .line 68
    .line 69
    .line 70
    move-result-wide v12

    .line 71
    const/16 p0, 0x3fdf

    .line 72
    .line 73
    const/4 v7, 0x0

    .line 74
    const/4 v9, 0x0

    .line 75
    const-wide/16 v17, 0x0

    .line 76
    .line 77
    move-object v8, v7

    .line 78
    move v10, v9

    .line 79
    move-object v11, v7

    .line 80
    move-object v14, v7

    .line 81
    move-object v15, v7

    .line 82
    move-object/from16 v16, v7

    .line 83
    .line 84
    move/from16 v19, v9

    .line 85
    .line 86
    move/from16 v20, v9

    .line 87
    .line 88
    move-object/from16 v21, v7

    .line 89
    .line 90
    move-object/from16 v22, v7

    .line 91
    .line 92
    move-object/from16 p1, v7

    .line 93
    .line 94
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 95
    .line 96
    .line 97
    move-result-object v6

    .line 98
    :cond_1
    invoke-virtual {v5, v6}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    goto :goto_1

    .line 102
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    move-object/from16 v8, p0

    .line 106
    .line 107
    iget-object v0, v8, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 108
    .line 109
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 110
    .line 111
    .line 112
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 113
    .line 114
    iget-object v0, v8, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 115
    .line 116
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    sget-object v2, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 121
    .line 122
    iget-object v1, v8, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 123
    .line 124
    const/4 v0, 0x0

    .line 125
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->L$0:Ljava/lang/Object;

    .line 126
    .line 127
    iput-object v3, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->L$1:Ljava/lang/Object;

    .line 128
    .line 129
    iput v4, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->label:I

    .line 130
    .line 131
    invoke-virtual {v2, v1, v3, v7}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->pruneFinished(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-ne v0, v6, :cond_4

    .line 136
    .line 137
    return-object v6

    .line 138
    :cond_3
    iget-object v3, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->L$1:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v3, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 141
    .line 142
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    :cond_4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 146
    .line 147
    .line 148
    move-result-wide v0

    .line 149
    const/4 v2, 0x0

    .line 150
    iput-object v2, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->L$0:Ljava/lang/Object;

    .line 151
    .line 152
    iput-object v2, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->L$1:Ljava/lang/Object;

    .line 153
    .line 154
    iput-wide v0, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->J$0:J

    .line 155
    .line 156
    iput v5, v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;->label:I

    .line 157
    .line 158
    invoke-virtual {v3, v7}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    if-ne v2, v6, :cond_0

    .line 163
    .line 164
    return-object v6

    .line 165
    :cond_5
    new-instance v7, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;

    .line 166
    .line 167
    invoke-direct {v7, v3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$1;-><init>(LX/2M4;)V

    .line 168
    .line 169
    .line 170
    goto/16 :goto_0

    .line 171
    .line 172
    :cond_6
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$$inlined$sortedBy$1;

    .line 173
    .line 174
    invoke-direct {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderList$$inlined$sortedBy$1;-><init>()V

    .line 175
    .line 176
    .line 177
    invoke-static {v5, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    new-instance v3, LX/BcB;

    .line 182
    .line 183
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 184
    .line 185
    .line 186
    new-instance v2, LX/Bcq;

    .line 187
    .line 188
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 189
    .line 190
    .line 191
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-eqz v0, :cond_7

    .line 200
    .line 201
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 206
    .line 207
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lkotlinx/serialization/json/JsonObject;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 212
    .line 213
    .line 214
    goto :goto_2

    .line 215
    :cond_7
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    const-string v0, "reminders"

    .line 220
    .line 221
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 222
    .line 223
    .line 224
    move-result-object v6

    .line 225
    return-object v6

    .line 226
    :cond_8
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    throw v0
.end method

.method public static final computeReminderSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v11, v3

    .line 7
    check-cast v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;

    .line 8
    .line 9
    iget v2, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v12, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 25
    .line 26
    packed-switch v0, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    throw v0

    .line 34
    :cond_0
    new-instance v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;

    .line 35
    .line 36
    invoke-direct {v11, v3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;-><init>(LX/2M4;)V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :pswitch_0
    iget-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 41
    .line 42
    iget v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 43
    .line 44
    iget-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$11:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v7, Ljava/util/Iterator;

    .line 47
    .line 48
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 51
    .line 52
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v3, Landroid/content/Context;

    .line 55
    .line 56
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    goto/16 :goto_7

    .line 60
    .line 61
    :pswitch_1
    const/16 v29, 0x0

    .line 62
    .line 63
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    move-object/from16 v5, p0

    .line 67
    .line 68
    iget-object v0, v5, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 69
    .line 70
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 71
    .line 72
    .line 73
    invoke-static/range {p1 .. p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    :try_start_0
    const-string v1, "reminders_json"

    .line 78
    .line 79
    const-string v0, "reminders"

    .line 80
    .line 81
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    if-eqz v1, :cond_5

    .line 86
    .line 87
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-nez v0, :cond_4

    .line 92
    .line 93
    invoke-static {v1}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    const/4 v2, 0x0

    .line 102
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_2

    .line 107
    .line 108
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    add-int/lit8 v1, v2, 0x1

    .line 113
    .line 114
    if-gez v2, :cond_1

    .line 115
    .line 116
    invoke-static {}, LX/B8B;->A1A()V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_1
    check-cast v0, Lkotlinx/serialization/json/JsonObject;

    .line 121
    .line 122
    invoke-static {v2, v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->parseReminderSetRequest(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/ReminderSetRequest;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move v2, v1

    .line 130
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 131
    :goto_2
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    goto :goto_3

    .line 136
    :cond_2
    iget-object v3, v5, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 137
    .line 138
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 139
    .line 140
    invoke-virtual {v0, v3}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 145
    .line 146
    const/4 v0, 0x0

    .line 147
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 148
    .line 149
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 150
    .line 151
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 152
    .line 153
    iput-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 154
    .line 155
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 156
    .line 157
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 158
    .line 159
    const/4 v0, 0x1

    .line 160
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 161
    .line 162
    invoke-virtual {v1, v3, v5, v11}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->pruneFinished(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    if-ne v0, v4, :cond_3

    .line 167
    .line 168
    return-object v4

    .line 169
    :pswitch_2
    const/16 v29, 0x0

    .line 170
    .line 171
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 174
    .line 175
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 176
    .line 177
    check-cast v3, Landroid/content/Context;

    .line 178
    .line 179
    iget-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v6, Ljava/util/List;

    .line 182
    .line 183
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    :cond_3
    const/4 v0, 0x0

    .line 187
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 188
    .line 189
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 190
    .line 191
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 192
    .line 193
    iput-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 194
    .line 195
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 196
    .line 197
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 198
    .line 199
    const/4 v0, 0x2

    .line 200
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 201
    .line 202
    invoke-virtual {v5, v11}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v12

    .line 206
    if-ne v12, v4, :cond_7

    .line 207
    .line 208
    return-object v4

    .line 209
    :cond_4
    :try_start_1
    const/16 v0, 0x5f

    .line 210
    .line 211
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    goto :goto_3

    .line 220
    :cond_5
    const/16 v0, 0x5e

    .line 221
    .line 222
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    :goto_3
    throw v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 231
    :catch_0
    move-exception v0

    .line 232
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object p0

    .line 236
    if-nez p0, :cond_6

    .line 237
    .line 238
    const-string p0, "Invalid reminder parameters"

    .line 239
    .line 240
    :cond_6
    const/16 v30, 0x0

    .line 241
    .line 242
    goto :goto_4

    .line 243
    :pswitch_3
    const/16 v29, 0x0

    .line 244
    .line 245
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 248
    .line 249
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v3, Landroid/content/Context;

    .line 252
    .line 253
    iget-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v6, Ljava/util/List;

    .line 256
    .line 257
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    :cond_7
    check-cast v12, Ljava/util/List;

    .line 261
    .line 262
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 263
    .line 264
    .line 265
    move-result v10

    .line 266
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 267
    .line 268
    .line 269
    move-result v1

    .line 270
    add-int/2addr v1, v10

    .line 271
    const/16 v0, 0x64

    .line 272
    .line 273
    if-le v1, v0, :cond_d

    .line 274
    .line 275
    const/16 v30, 0x0

    .line 276
    .line 277
    const-string p0, "You can have at most 100 reminders. Dismiss some before adding more."

    .line 278
    .line 279
    :goto_4
    new-instance v4, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 280
    .line 281
    move-object/from16 v28, v4

    .line 282
    .line 283
    move-object/from16 p1, v30

    .line 284
    .line 285
    move-object/from16 p2, v30

    .line 286
    .line 287
    invoke-direct/range {v28 .. v33}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    return-object v4

    .line 291
    :pswitch_4
    const/16 v29, 0x0

    .line 292
    .line 293
    iget v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 294
    .line 295
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 298
    .line 299
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast v3, Landroid/content/Context;

    .line 302
    .line 303
    iget-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v6, Ljava/util/List;

    .line 306
    .line 307
    goto/16 :goto_9

    .line 308
    .line 309
    :pswitch_5
    iget-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 310
    .line 311
    iget v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 312
    .line 313
    iget-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$11:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 316
    .line 317
    iget-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$9:Ljava/lang/Object;

    .line 318
    .line 319
    check-cast v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;

    .line 320
    .line 321
    iget-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$8:Ljava/lang/Object;

    .line 322
    .line 323
    check-cast v6, Ljava/util/Iterator;

    .line 324
    .line 325
    iget-object v9, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$7:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v9, Ljava/util/List;

    .line 328
    .line 329
    iget-object v8, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$6:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast v8, Ljava/util/List;

    .line 332
    .line 333
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 334
    .line 335
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 336
    .line 337
    const/16 v29, 0x0

    .line 338
    .line 339
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 340
    .line 341
    check-cast v3, Landroid/content/Context;

    .line 342
    .line 343
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 344
    .line 345
    .line 346
    :goto_5
    invoke-interface {v9, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    iget-object v14, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 350
    .line 351
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->hour:I

    .line 352
    .line 353
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 354
    .line 355
    .line 356
    move-result-object v13

    .line 357
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->minute:I

    .line 358
    .line 359
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    const/4 v12, 0x2

    .line 364
    filled-new-array {v13, v0}, [Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v0

    .line 368
    invoke-static {v0, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v12

    .line 372
    const-string v0, "%02d:%02d"

    .line 373
    .line 374
    invoke-static {v0, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 375
    .line 376
    .line 377
    move-result-object v13

    .line 378
    const-string v12, "Reminder scheduled: id="

    .line 379
    .line 380
    const-string v0, " time="

    .line 381
    .line 382
    invoke-static {v12, v14, v0, v13}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 383
    .line 384
    .line 385
    move-result-object v12

    .line 386
    const-string v0, "ReminderHandlers"

    .line 387
    .line 388
    invoke-static {v0, v12}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 389
    .line 390
    .line 391
    iget-object v13, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->label:Ljava/lang/String;

    .line 392
    .line 393
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    .line 394
    .line 395
    .line 396
    move-result v0

    .line 397
    if-gtz v0, :cond_8

    .line 398
    .line 399
    const/4 v13, 0x0

    .line 400
    :cond_8
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->hour:I

    .line 401
    .line 402
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 403
    .line 404
    .line 405
    move-result-object v12

    .line 406
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->minute:I

    .line 407
    .line 408
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 409
    .line 410
    .line 411
    move-result-object v0

    .line 412
    iget-wide v14, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->triggerTimeMs:J

    .line 413
    .line 414
    invoke-static {v14, v15}, LX/602;->A0W(J)Ljava/lang/Long;

    .line 415
    .line 416
    .line 417
    move-result-object v14

    .line 418
    new-instance v7, Lcom/facebook/aura/commands/alarm/ReminderCardItemInput;

    .line 419
    .line 420
    invoke-direct {v7, v13, v12, v0, v14}, Lcom/facebook/aura/commands/alarm/ReminderCardItemInput;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Long;)V

    .line 421
    .line 422
    .line 423
    invoke-interface {v8, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 424
    .line 425
    .line 426
    :goto_6
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 427
    .line 428
    .line 429
    move-result v0

    .line 430
    if-eqz v0, :cond_13

    .line 431
    .line 432
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v7

    .line 436
    check-cast v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;

    .line 437
    .line 438
    sget-object v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->$childSerializers:[Lkotlin/Lazy;

    .line 439
    .line 440
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 441
    .line 442
    .line 443
    move-result-object v17

    .line 444
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->label:Ljava/lang/String;

    .line 445
    .line 446
    move-object/from16 v23, v0

    .line 447
    .line 448
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->hour:I

    .line 449
    .line 450
    move/from16 v22, v0

    .line 451
    .line 452
    iget v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->minute:I

    .line 453
    .line 454
    move/from16 v20, v0

    .line 455
    .line 456
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->days:Ljava/lang/String;

    .line 457
    .line 458
    move-object/from16 v21, v0

    .line 459
    .line 460
    iget-wide v14, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->triggerTimeMs:J

    .line 461
    .line 462
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 463
    .line 464
    move-object/from16 v19, v0

    .line 465
    .line 466
    iget-wide v12, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->anchorMs:J

    .line 467
    .line 468
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;->timezone:Ljava/lang/String;

    .line 469
    .line 470
    move-object/from16 v18, v0

    .line 471
    .line 472
    const/4 v0, 0x0

    .line 473
    new-instance v16, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 474
    .line 475
    move-object/from16 v25, v0

    .line 476
    .line 477
    move-object/from16 v26, v19

    .line 478
    .line 479
    move-wide/from16 v27, v12

    .line 480
    .line 481
    move/from16 v30, v29

    .line 482
    .line 483
    move-object/from16 p0, v18

    .line 484
    .line 485
    move-object/from16 p1, v0

    .line 486
    .line 487
    move-object/from16 v18, v23

    .line 488
    .line 489
    move/from16 v19, v22

    .line 490
    .line 491
    move-wide/from16 v22, v14

    .line 492
    .line 493
    move-object/from16 v24, v0

    .line 494
    .line 495
    invoke-direct/range {v16 .. v32}, Lcom/facebook/aura/commands/alarm/ShadowReminder;-><init>(Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;)V

    .line 496
    .line 497
    .line 498
    sget-object v12, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 499
    .line 500
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 501
    .line 502
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 503
    .line 504
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 505
    .line 506
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 507
    .line 508
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 509
    .line 510
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 511
    .line 512
    iput-object v8, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$6:Ljava/lang/Object;

    .line 513
    .line 514
    iput-object v9, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$7:Ljava/lang/Object;

    .line 515
    .line 516
    iput-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$8:Ljava/lang/Object;

    .line 517
    .line 518
    iput-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$9:Ljava/lang/Object;

    .line 519
    .line 520
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$10:Ljava/lang/Object;

    .line 521
    .line 522
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$11:Ljava/lang/Object;

    .line 523
    .line 524
    iput v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 525
    .line 526
    iput-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 527
    .line 528
    const/4 v0, 0x4

    .line 529
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 530
    .line 531
    move-object v13, v3

    .line 532
    move-object/from16 v14, v16

    .line 533
    .line 534
    move-wide v15, v1

    .line 535
    move-object/from16 v17, v11

    .line 536
    .line 537
    invoke-virtual/range {v12 .. v17}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->add(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;JLX/2M4;)Ljava/lang/Object;

    .line 538
    .line 539
    .line 540
    move-result-object v12

    .line 541
    if-ne v12, v4, :cond_a

    .line 542
    .line 543
    :cond_9
    return-object v4

    .line 544
    :pswitch_6
    const/16 v29, 0x0

    .line 545
    .line 546
    iget-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 547
    .line 548
    iget v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 549
    .line 550
    iget-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$9:Ljava/lang/Object;

    .line 551
    .line 552
    check-cast v7, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;

    .line 553
    .line 554
    iget-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$8:Ljava/lang/Object;

    .line 555
    .line 556
    check-cast v6, Ljava/util/Iterator;

    .line 557
    .line 558
    iget-object v9, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$7:Ljava/lang/Object;

    .line 559
    .line 560
    check-cast v9, Ljava/util/List;

    .line 561
    .line 562
    iget-object v8, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$6:Ljava/lang/Object;

    .line 563
    .line 564
    check-cast v8, Ljava/util/List;

    .line 565
    .line 566
    iget-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 567
    .line 568
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 569
    .line 570
    iget-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 571
    .line 572
    check-cast v3, Landroid/content/Context;

    .line 573
    .line 574
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 575
    .line 576
    .line 577
    :cond_a
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 578
    .line 579
    if-nez v12, :cond_12

    .line 580
    .line 581
    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 582
    .line 583
    .line 584
    move-result-object v7

    .line 585
    :cond_b
    :goto_7
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 586
    .line 587
    .line 588
    move-result v0

    .line 589
    if-eqz v0, :cond_c

    .line 590
    .line 591
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 592
    .line 593
    .line 594
    move-result-object v6

    .line 595
    check-cast v6, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 596
    .line 597
    const/4 v0, 0x0

    .line 598
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 599
    .line 600
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 601
    .line 602
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 603
    .line 604
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 605
    .line 606
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 607
    .line 608
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 609
    .line 610
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$6:Ljava/lang/Object;

    .line 611
    .line 612
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$7:Ljava/lang/Object;

    .line 613
    .line 614
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$8:Ljava/lang/Object;

    .line 615
    .line 616
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$9:Ljava/lang/Object;

    .line 617
    .line 618
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$10:Ljava/lang/Object;

    .line 619
    .line 620
    iput-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$11:Ljava/lang/Object;

    .line 621
    .line 622
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$12:Ljava/lang/Object;

    .line 623
    .line 624
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$13:Ljava/lang/Object;

    .line 625
    .line 626
    iput v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 627
    .line 628
    iput-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 629
    .line 630
    const/4 v0, 0x5

    .line 631
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 632
    .line 633
    invoke-static {v3, v5, v6, v11}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 634
    .line 635
    .line 636
    move-result-object v0

    .line 637
    if-ne v0, v4, :cond_b

    .line 638
    .line 639
    return-object v4

    .line 640
    :cond_c
    const-string v0, "The reminder couldn\'t be saved to the user\'s calendar."

    .line 641
    .line 642
    goto :goto_8

    .line 643
    :cond_d
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 644
    .line 645
    invoke-virtual {v1, v3}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->hasCalendarApp(Landroid/content/Context;)Z

    .line 646
    .line 647
    .line 648
    move-result v0

    .line 649
    if-nez v0, :cond_e

    .line 650
    .line 651
    const-string v0, "This phone has no calendar app to alert for the reminder."

    .line 652
    .line 653
    :goto_8
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->offerChatReminder(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 654
    .line 655
    .line 656
    move-result-object v4

    .line 657
    return-object v4

    .line 658
    :cond_e
    invoke-virtual {v1, v3}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->hasAccess(Landroid/content/Context;)Z

    .line 659
    .line 660
    .line 661
    move-result v0

    .line 662
    if-nez v0, :cond_f

    .line 663
    .line 664
    const-string v0, "The user hasn\'t allowed calendar access on this phone."

    .line 665
    .line 666
    goto :goto_8

    .line 667
    :cond_f
    :try_start_2
    const/4 v0, 0x0

    .line 668
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 669
    .line 670
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 671
    .line 672
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 673
    .line 674
    iput-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 675
    .line 676
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 677
    .line 678
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 679
    .line 680
    iput v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 681
    .line 682
    const/4 v0, 0x3

    .line 683
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 684
    .line 685
    invoke-virtual {v1, v3, v11}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->targetCalendarId(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 686
    .line 687
    .line 688
    move-result-object v12

    .line 689
    if-ne v12, v4, :cond_10

    .line 690
    .line 691
    goto :goto_b

    .line 692
    :goto_9
    invoke-static {v12}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 693
    .line 694
    .line 695
    :cond_10
    check-cast v12, Ljava/lang/Number;

    .line 696
    .line 697
    if-eqz v12, :cond_11

    .line 698
    .line 699
    goto :goto_a
    :try_end_2
    .catch Ljava/lang/NoSuchMethodError; {:try_start_2 .. :try_end_2} :catch_1

    .line 700
    :cond_11
    const-string v0, "This phone has no calendar account to save it to."

    .line 701
    .line 702
    goto :goto_8

    .line 703
    :goto_a
    invoke-virtual {v12}, Ljava/lang/Number;->longValue()J

    .line 704
    .line 705
    .line 706
    move-result-wide v1

    .line 707
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 708
    .line 709
    .line 710
    move-result-object v8

    .line 711
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 712
    .line 713
    .line 714
    move-result-object v9

    .line 715
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 716
    .line 717
    .line 718
    move-result-object v6

    .line 719
    goto/16 :goto_6

    .line 720
    .line 721
    :cond_12
    const/4 v0, 0x0

    .line 722
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$0:Ljava/lang/Object;

    .line 723
    .line 724
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$1:Ljava/lang/Object;

    .line 725
    .line 726
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$2:Ljava/lang/Object;

    .line 727
    .line 728
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$3:Ljava/lang/Object;

    .line 729
    .line 730
    iput-object v3, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$4:Ljava/lang/Object;

    .line 731
    .line 732
    iput-object v5, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$5:Ljava/lang/Object;

    .line 733
    .line 734
    iput-object v8, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$6:Ljava/lang/Object;

    .line 735
    .line 736
    iput-object v9, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$7:Ljava/lang/Object;

    .line 737
    .line 738
    iput-object v6, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$8:Ljava/lang/Object;

    .line 739
    .line 740
    iput-object v7, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$9:Ljava/lang/Object;

    .line 741
    .line 742
    iput-object v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$10:Ljava/lang/Object;

    .line 743
    .line 744
    iput-object v12, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->L$11:Ljava/lang/Object;

    .line 745
    .line 746
    iput v10, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->I$0:I

    .line 747
    .line 748
    iput-wide v1, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->J$0:J

    .line 749
    .line 750
    const/4 v0, 0x6

    .line 751
    iput v0, v11, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSet$1;->label:I

    .line 752
    .line 753
    invoke-virtual {v5, v12, v11}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 754
    .line 755
    .line 756
    move-result-object v0

    .line 757
    if-eq v0, v4, :cond_9

    .line 758
    .line 759
    move-object v0, v12

    .line 760
    goto/16 :goto_5

    .line 761
    .line 762
    :goto_b
    return-object v4

    .line 763
    :catch_1
    const-string v0, "The calendar on this phone can\'t be read."

    .line 764
    .line 765
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->offerChatReminder(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    return-object v0

    .line 770
    :cond_13
    const-string v0, "set"

    .line 771
    .line 772
    invoke-static {v0, v8}, Lcom/facebook/aura/commands/alarm/ReminderCardInstructionKt;->reminderCardEnvelope(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    .line 773
    .line 774
    .line 775
    move-result-object v8

    .line 776
    const/4 v6, 0x0

    .line 777
    const/4 v5, 0x1

    .line 778
    new-instance v4, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 779
    .line 780
    move-object v7, v6

    .line 781
    move-object v9, v6

    .line 782
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 783
    .line 784
    .line 785
    return-object v4

    .line 786
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_6
        :pswitch_0
        :pswitch_5
    .end packed-switch
.end method

.method public static final computeReminderSnooze(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v6, p0

    .line 1
    .line 2
    move-object/from16 v3, p2

    .line 3
    .line 4
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;

    .line 5
    .line 6
    if-eqz v0, :cond_10

    .line 7
    .line 8
    move-object v5, v3

    .line 9
    check-cast v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;

    .line 10
    .line 11
    iget v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_10

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v14, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 27
    .line 28
    const/4 v11, 0x3

    .line 29
    const/4 v10, 0x2

    .line 30
    const/4 v8, 0x1

    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    if-eq v0, v8, :cond_9

    .line 34
    .line 35
    if-eq v0, v10, :cond_1

    .line 36
    .line 37
    if-ne v0, v11, :cond_12

    .line 38
    .line 39
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$6:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v7, Ljava/util/List;

    .line 42
    .line 43
    invoke-static {v14}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    new-instance v3, LX/BcB;

    .line 47
    .line 48
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 49
    .line 50
    .line 51
    invoke-static {v7, v3}, LX/IEb;->A0D(Ljava/util/List;LX/BcB;)Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-string v0, "snoozed_count"

    .line 56
    .line 57
    invoke-static {v1, v0, v3}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 58
    .line 59
    .line 60
    new-instance v2, LX/Bcq;

    .line 61
    .line 62
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 63
    .line 64
    .line 65
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-eqz v0, :cond_11

    .line 74
    .line 75
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 80
    .line 81
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lkotlinx/serialization/json/JsonObject;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 86
    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_1
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$12:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v7, Ljava/util/Collection;

    .line 92
    .line 93
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$9:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v1, Ljava/util/Iterator;

    .line 96
    .line 97
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$8:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, Ljava/util/Collection;

    .line 100
    .line 101
    iget-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$4:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v3, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 104
    .line 105
    iget-object v6, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$0:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 108
    .line 109
    invoke-static {v14}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    goto/16 :goto_5

    .line 113
    .line 114
    :cond_2
    invoke-static {v14}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    iget-object v0, v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 118
    .line 119
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 120
    .line 121
    .line 122
    invoke-static/range {p1 .. p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    :try_start_0
    const-string v1, "targets_json"

    .line 127
    .line 128
    const-string v0, "targets"

    .line 129
    .line 130
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 131
    .line 132
    .line 133
    move-result-object v7

    .line 134
    if-eqz v7, :cond_13

    .line 135
    .line 136
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-nez v0, :cond_13
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 141
    .line 142
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 143
    .line 144
    iget-object v0, v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 145
    .line 146
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 147
    .line 148
    .line 149
    move-result-object v3

    .line 150
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v7

    .line 158
    const/4 v13, 0x0

    .line 159
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_c

    .line 164
    .line 165
    add-int/lit8 v9, v13, 0x1

    .line 166
    .line 167
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v12

    .line 171
    check-cast v12, Lkotlinx/serialization/json/JsonObject;

    .line 172
    .line 173
    const-string v1, "targets_json["

    .line 174
    .line 175
    const-string v0, "]"

    .line 176
    .line 177
    invoke-static {v1, v13, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v14

    .line 181
    const-string v0, "alarm_id"

    .line 182
    .line 183
    invoke-virtual {v12, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 188
    .line 189
    if-eqz v0, :cond_3

    .line 190
    .line 191
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 192
    .line 193
    if-eqz v1, :cond_3

    .line 194
    .line 195
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    if-nez v1, :cond_4

    .line 200
    .line 201
    :cond_3
    const-string v1, ""

    .line 202
    .line 203
    :cond_4
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    if-nez v0, :cond_6

    .line 208
    .line 209
    invoke-static {v14}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    const-string v1, ".alarm_id is required"

    .line 214
    .line 215
    :goto_3
    invoke-static {v1, v0}, LX/002;->A11(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 220
    .line 221
    .line 222
    move-result-object v4

    .line 223
    :cond_5
    return-object v4

    .line 224
    :cond_6
    const-string v0, "snooze_minutes"

    .line 225
    .line 226
    invoke-virtual {v12, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v12

    .line 230
    instance-of v0, v12, Lkotlinx/serialization/json/JsonPrimitive;

    .line 231
    .line 232
    if-eqz v0, :cond_7

    .line 233
    .line 234
    check-cast v12, Lkotlinx/serialization/json/JsonPrimitive;

    .line 235
    .line 236
    if-eqz v12, :cond_7

    .line 237
    .line 238
    invoke-static {v12}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    if-eqz v0, :cond_7

    .line 243
    .line 244
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 245
    .line 246
    .line 247
    move-result v12

    .line 248
    if-ge v12, v8, :cond_8

    .line 249
    .line 250
    invoke-static {v14}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    const-string v1, ".snooze_minutes must be a positive integer"

    .line 255
    .line 256
    goto :goto_3

    .line 257
    :cond_7
    const/16 v12, 0xa

    .line 258
    .line 259
    :cond_8
    iput-object v6, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$0:Ljava/lang/Object;

    .line 260
    .line 261
    const/4 v0, 0x0

    .line 262
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$1:Ljava/lang/Object;

    .line 263
    .line 264
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$2:Ljava/lang/Object;

    .line 265
    .line 266
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$3:Ljava/lang/Object;

    .line 267
    .line 268
    iput-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$4:Ljava/lang/Object;

    .line 269
    .line 270
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$5:Ljava/lang/Object;

    .line 271
    .line 272
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$6:Ljava/lang/Object;

    .line 273
    .line 274
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$7:Ljava/lang/Object;

    .line 275
    .line 276
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$8:Ljava/lang/Object;

    .line 277
    .line 278
    iput-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$9:Ljava/lang/Object;

    .line 279
    .line 280
    iput v9, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->I$0:I

    .line 281
    .line 282
    iput v13, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->I$1:I

    .line 283
    .line 284
    iput v12, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->I$2:I

    .line 285
    .line 286
    iput v8, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 287
    .line 288
    invoke-virtual {v3, v1, v5}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v14

    .line 292
    if-ne v14, v4, :cond_a

    .line 293
    .line 294
    return-object v4

    .line 295
    :cond_9
    iget v12, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->I$2:I

    .line 296
    .line 297
    iget v9, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->I$0:I

    .line 298
    .line 299
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$9:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast v1, Ljava/lang/String;

    .line 302
    .line 303
    iget-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$6:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v7, Ljava/util/Iterator;

    .line 306
    .line 307
    iget-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$5:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v2, Ljava/util/List;

    .line 310
    .line 311
    iget-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$4:Ljava/lang/Object;

    .line 312
    .line 313
    check-cast v3, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 314
    .line 315
    iget-object v6, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$0:Ljava/lang/Object;

    .line 316
    .line 317
    check-cast v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 318
    .line 319
    invoke-static {v14}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    :cond_a
    check-cast v14, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 323
    .line 324
    if-nez v14, :cond_b

    .line 325
    .line 326
    const-string v0, "No reminder found with id "

    .line 327
    .line 328
    invoke-static {v0}, LX/001;->A0y(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    goto :goto_3

    .line 333
    :cond_b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 334
    .line 335
    .line 336
    move-result-wide v20

    .line 337
    int-to-long v0, v12

    .line 338
    const-wide/32 v12, 0xea60

    .line 339
    .line 340
    .line 341
    mul-long/2addr v0, v12

    .line 342
    add-long v20, v20, v0

    .line 343
    .line 344
    const/16 p1, 0x3fdf

    .line 345
    .line 346
    const/4 v15, 0x0

    .line 347
    const/16 v17, 0x0

    .line 348
    .line 349
    const-wide/16 v25, 0x0

    .line 350
    .line 351
    move-object/from16 v16, v15

    .line 352
    .line 353
    move/from16 v18, v17

    .line 354
    .line 355
    move-object/from16 v19, v15

    .line 356
    .line 357
    move-object/from16 v22, v15

    .line 358
    .line 359
    move-object/from16 v23, v15

    .line 360
    .line 361
    move-object/from16 v24, v15

    .line 362
    .line 363
    move/from16 v27, v17

    .line 364
    .line 365
    move/from16 v28, v17

    .line 366
    .line 367
    move-object/from16 v29, v15

    .line 368
    .line 369
    move-object/from16 p0, v15

    .line 370
    .line 371
    move-object/from16 p2, v15

    .line 372
    .line 373
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 374
    .line 375
    .line 376
    move-result-object v0

    .line 377
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    move v13, v9

    .line 381
    goto/16 :goto_2

    .line 382
    .line 383
    :cond_c
    iget-object v0, v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 384
    .line 385
    invoke-static {v0, v2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->calendarAccessError(Landroid/content/Context;Ljava/util/List;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    if-nez v0, :cond_d

    .line 390
    .line 391
    invoke-static {v2}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 392
    .line 393
    .line 394
    move-result-object v7

    .line 395
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 396
    .line 397
    .line 398
    move-result-object v1

    .line 399
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 400
    .line 401
    .line 402
    move-result v0

    .line 403
    if-eqz v0, :cond_f

    .line 404
    .line 405
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 410
    .line 411
    iget-object v8, v6, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 412
    .line 413
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->asCalendarSnooze(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 414
    .line 415
    .line 416
    move-result-object v2

    .line 417
    iput-object v6, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$0:Ljava/lang/Object;

    .line 418
    .line 419
    const/4 v0, 0x0

    .line 420
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$1:Ljava/lang/Object;

    .line 421
    .line 422
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$2:Ljava/lang/Object;

    .line 423
    .line 424
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$3:Ljava/lang/Object;

    .line 425
    .line 426
    iput-object v3, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$4:Ljava/lang/Object;

    .line 427
    .line 428
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$5:Ljava/lang/Object;

    .line 429
    .line 430
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$6:Ljava/lang/Object;

    .line 431
    .line 432
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$7:Ljava/lang/Object;

    .line 433
    .line 434
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$8:Ljava/lang/Object;

    .line 435
    .line 436
    iput-object v1, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$9:Ljava/lang/Object;

    .line 437
    .line 438
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$10:Ljava/lang/Object;

    .line 439
    .line 440
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$11:Ljava/lang/Object;

    .line 441
    .line 442
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$12:Ljava/lang/Object;

    .line 443
    .line 444
    iput v10, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 445
    .line 446
    invoke-static {v8, v3, v2, v5}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->rescheduleReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 447
    .line 448
    .line 449
    move-result-object v14

    .line 450
    if-eq v14, v4, :cond_5

    .line 451
    .line 452
    move-object v0, v7

    .line 453
    :goto_5
    if-nez v14, :cond_e

    .line 454
    .line 455
    const/4 v2, 0x0

    .line 456
    const-string v3, "Failed to schedule reminder."

    .line 457
    .line 458
    const/4 v1, 0x0

    .line 459
    new-instance v0, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 460
    .line 461
    move-object v4, v2

    .line 462
    move-object v5, v2

    .line 463
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 464
    .line 465
    .line 466
    :cond_d
    return-object v0

    .line 467
    :cond_e
    invoke-interface {v7, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 468
    .line 469
    .line 470
    move-object v7, v0

    .line 471
    goto :goto_4

    .line 472
    :cond_f
    check-cast v7, Ljava/util/List;

    .line 473
    .line 474
    const/4 v0, 0x0

    .line 475
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$0:Ljava/lang/Object;

    .line 476
    .line 477
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$1:Ljava/lang/Object;

    .line 478
    .line 479
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$2:Ljava/lang/Object;

    .line 480
    .line 481
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$3:Ljava/lang/Object;

    .line 482
    .line 483
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$4:Ljava/lang/Object;

    .line 484
    .line 485
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$5:Ljava/lang/Object;

    .line 486
    .line 487
    iput-object v7, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$6:Ljava/lang/Object;

    .line 488
    .line 489
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$7:Ljava/lang/Object;

    .line 490
    .line 491
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$8:Ljava/lang/Object;

    .line 492
    .line 493
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$9:Ljava/lang/Object;

    .line 494
    .line 495
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$10:Ljava/lang/Object;

    .line 496
    .line 497
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$11:Ljava/lang/Object;

    .line 498
    .line 499
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->L$12:Ljava/lang/Object;

    .line 500
    .line 501
    iput v11, v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;->label:I

    .line 502
    .line 503
    invoke-virtual {v3, v7, v5}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->addAll(Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 504
    .line 505
    .line 506
    move-result-object v0

    .line 507
    if-ne v0, v4, :cond_0

    .line 508
    .line 509
    return-object v4

    .line 510
    :cond_10
    new-instance v5, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;

    .line 511
    .line 512
    invoke-direct {v5, v3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderSnooze$1;-><init>(LX/2M4;)V

    .line 513
    .line 514
    .line 515
    goto/16 :goto_0

    .line 516
    .line 517
    :cond_11
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 518
    .line 519
    .line 520
    move-result-object v1

    .line 521
    const-string v0, "reminders"

    .line 522
    .line 523
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    return-object v0

    .line 528
    :cond_12
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 529
    .line 530
    .line 531
    move-result-object v0

    .line 532
    throw v0

    .line 533
    :cond_13
    :try_start_1
    const/16 v0, 0xc

    .line 534
    .line 535
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 536
    .line 537
    .line 538
    move-result-object v0

    .line 539
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 540
    .line 541
    .line 542
    move-result-object v0

    .line 543
    throw v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 544
    :catch_0
    move-exception v0

    .line 545
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 546
    .line 547
    .line 548
    move-result-object v0

    .line 549
    if-nez v0, :cond_14

    .line 550
    .line 551
    const-string v0, "Invalid reminder snooze parameters"

    .line 552
    .line 553
    :cond_14
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 554
    .line 555
    .line 556
    move-result-object v0

    .line 557
    return-object v0
.end method

.method public static final computeReminderUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;

    .line 3
    .line 4
    if-eqz v0, :cond_e

    .line 5
    .line 6
    move-object v9, v3

    .line 7
    check-cast v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;

    .line 8
    .line 9
    iget v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_e

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 25
    .line 26
    const-string v14, "Invalid reminder update parameters"

    .line 27
    .line 28
    const/4 v7, 0x3

    .line 29
    const/4 v10, 0x2

    .line 30
    const/4 v12, 0x1

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    if-eq v0, v12, :cond_5

    .line 34
    .line 35
    if-eq v0, v10, :cond_9

    .line 36
    .line 37
    if-ne v0, v7, :cond_10

    .line 38
    .line 39
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$6:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v1, Ljava/util/List;

    .line 42
    .line 43
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    new-instance v3, LX/BcB;

    .line 47
    .line 48
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 49
    .line 50
    .line 51
    invoke-static {v1, v3}, LX/IEb;->A0D(Ljava/util/List;LX/BcB;)Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    const-string v0, "updated_count"

    .line 56
    .line 57
    invoke-static {v2, v0, v3}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 58
    .line 59
    .line 60
    new-instance v2, LX/Bcq;

    .line 61
    .line 62
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 63
    .line 64
    .line 65
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-eqz v0, :cond_f

    .line 74
    .line 75
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 80
    .line 81
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lkotlinx/serialization/json/JsonObject;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 86
    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    iget-object v0, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 93
    .line 94
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->evictLegacyReminderRowsOnce(Landroid/content/Context;)V

    .line 95
    .line 96
    .line 97
    invoke-static/range {p1 .. p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    :try_start_0
    const-string v1, "updates_json"

    .line 102
    .line 103
    const-string v0, "updates"

    .line 104
    .line 105
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    if-eqz v2, :cond_11

    .line 110
    .line 111
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-nez v0, :cond_11
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 116
    .line 117
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 118
    .line 119
    iget-object v0, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 120
    .line 121
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 126
    .line 127
    .line 128
    move-result-object v4

    .line 129
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 130
    .line 131
    .line 132
    move-result-object v11

    .line 133
    const/4 v2, 0x0

    .line 134
    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_8

    .line 139
    .line 140
    add-int/lit8 v5, v2, 0x1

    .line 141
    .line 142
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v13

    .line 146
    check-cast v13, Lkotlinx/serialization/json/JsonObject;

    .line 147
    .line 148
    const-string v1, "updates_json["

    .line 149
    .line 150
    const-string v0, "]"

    .line 151
    .line 152
    invoke-static {v1, v2, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    const-string v0, "alarm_id"

    .line 157
    .line 158
    invoke-virtual {v13, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 163
    .line 164
    if-eqz v0, :cond_2

    .line 165
    .line 166
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 167
    .line 168
    if-eqz v1, :cond_2

    .line 169
    .line 170
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    if-nez v1, :cond_3

    .line 175
    .line 176
    :cond_2
    const-string v1, ""

    .line 177
    .line 178
    :cond_3
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-nez v0, :cond_4

    .line 183
    .line 184
    invoke-static {v3}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    const-string v0, ".alarm_id is required"

    .line 189
    .line 190
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    :goto_3
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 198
    .line 199
    .line 200
    move-result-object v8

    .line 201
    return-object v8

    .line 202
    :cond_4
    iput-object p0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$0:Ljava/lang/Object;

    .line 203
    .line 204
    const/4 v0, 0x0

    .line 205
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$1:Ljava/lang/Object;

    .line 206
    .line 207
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$2:Ljava/lang/Object;

    .line 208
    .line 209
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$3:Ljava/lang/Object;

    .line 210
    .line 211
    iput-object v6, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$4:Ljava/lang/Object;

    .line 212
    .line 213
    iput-object v4, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$5:Ljava/lang/Object;

    .line 214
    .line 215
    iput-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$6:Ljava/lang/Object;

    .line 216
    .line 217
    iput-object v13, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$7:Ljava/lang/Object;

    .line 218
    .line 219
    iput-object v3, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$8:Ljava/lang/Object;

    .line 220
    .line 221
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$9:Ljava/lang/Object;

    .line 222
    .line 223
    iput v5, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->I$0:I

    .line 224
    .line 225
    iput v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->I$1:I

    .line 226
    .line 227
    iput v12, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 228
    .line 229
    invoke-virtual {v6, v1, v9}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v2

    .line 233
    if-ne v2, v8, :cond_6

    .line 234
    .line 235
    return-object v8

    .line 236
    :cond_5
    iget v5, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->I$0:I

    .line 237
    .line 238
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$9:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v1, Ljava/lang/String;

    .line 241
    .line 242
    iget-object v3, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$8:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v3, Ljava/lang/String;

    .line 245
    .line 246
    iget-object v13, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$7:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v13, Lkotlinx/serialization/json/JsonObject;

    .line 249
    .line 250
    iget-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$6:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v11, Ljava/util/Iterator;

    .line 253
    .line 254
    iget-object v4, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$5:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v4, Ljava/util/List;

    .line 257
    .line 258
    iget-object v6, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$4:Ljava/lang/Object;

    .line 259
    .line 260
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 261
    .line 262
    iget-object p0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$0:Ljava/lang/Object;

    .line 263
    .line 264
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 265
    .line 266
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    :cond_6
    check-cast v2, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 270
    .line 271
    if-nez v2, :cond_7

    .line 272
    .line 273
    const-string v0, "No reminder found with id "

    .line 274
    .line 275
    invoke-static {v0, v1}, LX/002;->A18(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    move-result-object v1

    .line 279
    goto :goto_3

    .line 280
    :cond_7
    :try_start_1
    invoke-static {v3, v13, v2}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->resolveReminderUpdate(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 281
    .line 282
    .line 283
    move-result-object v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 284
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move v2, v5

    .line 288
    goto/16 :goto_2

    .line 289
    .line 290
    :cond_8
    iget-object v0, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 291
    .line 292
    invoke-static {v0, v4}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->calendarAccessError(Landroid/content/Context;Ljava/util/List;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    if-nez v0, :cond_b

    .line 297
    .line 298
    invoke-static {v4}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 303
    .line 304
    .line 305
    move-result-object v5

    .line 306
    :goto_4
    move-object v0, v1

    .line 307
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 308
    .line 309
    .line 310
    move-result v2

    .line 311
    if-eqz v2, :cond_d

    .line 312
    .line 313
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v4

    .line 317
    check-cast v4, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 318
    .line 319
    iget-object v3, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 320
    .line 321
    iput-object p0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$0:Ljava/lang/Object;

    .line 322
    .line 323
    const/4 v2, 0x0

    .line 324
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$1:Ljava/lang/Object;

    .line 325
    .line 326
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$2:Ljava/lang/Object;

    .line 327
    .line 328
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$3:Ljava/lang/Object;

    .line 329
    .line 330
    iput-object v6, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$4:Ljava/lang/Object;

    .line 331
    .line 332
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$5:Ljava/lang/Object;

    .line 333
    .line 334
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$6:Ljava/lang/Object;

    .line 335
    .line 336
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$7:Ljava/lang/Object;

    .line 337
    .line 338
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$8:Ljava/lang/Object;

    .line 339
    .line 340
    iput-object v5, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$9:Ljava/lang/Object;

    .line 341
    .line 342
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$10:Ljava/lang/Object;

    .line 343
    .line 344
    iput-object v2, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$11:Ljava/lang/Object;

    .line 345
    .line 346
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$12:Ljava/lang/Object;

    .line 347
    .line 348
    iput v10, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 349
    .line 350
    invoke-static {v3, v6, v4, v9}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->rescheduleReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v2

    .line 354
    if-ne v2, v8, :cond_a

    .line 355
    .line 356
    return-object v8

    .line 357
    :cond_9
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$12:Ljava/lang/Object;

    .line 358
    .line 359
    check-cast v0, Ljava/util/Collection;

    .line 360
    .line 361
    iget-object v5, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$9:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v5, Ljava/util/Iterator;

    .line 364
    .line 365
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$8:Ljava/lang/Object;

    .line 366
    .line 367
    check-cast v1, Ljava/util/Collection;

    .line 368
    .line 369
    iget-object v6, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$4:Ljava/lang/Object;

    .line 370
    .line 371
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 372
    .line 373
    iget-object p0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$0:Ljava/lang/Object;

    .line 374
    .line 375
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 376
    .line 377
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 378
    .line 379
    .line 380
    :cond_a
    if-nez v2, :cond_c

    .line 381
    .line 382
    const/4 v2, 0x0

    .line 383
    const-string v3, "Failed to schedule reminder."

    .line 384
    .line 385
    const/4 v1, 0x0

    .line 386
    new-instance v0, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 387
    .line 388
    move-object v4, v2

    .line 389
    move-object v5, v2

    .line 390
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    :cond_b
    return-object v0

    .line 394
    :cond_c
    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    goto :goto_4

    .line 398
    :cond_d
    check-cast v1, Ljava/util/List;

    .line 399
    .line 400
    const/4 v0, 0x0

    .line 401
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$0:Ljava/lang/Object;

    .line 402
    .line 403
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$1:Ljava/lang/Object;

    .line 404
    .line 405
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$2:Ljava/lang/Object;

    .line 406
    .line 407
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$3:Ljava/lang/Object;

    .line 408
    .line 409
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$4:Ljava/lang/Object;

    .line 410
    .line 411
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$5:Ljava/lang/Object;

    .line 412
    .line 413
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$6:Ljava/lang/Object;

    .line 414
    .line 415
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$7:Ljava/lang/Object;

    .line 416
    .line 417
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$8:Ljava/lang/Object;

    .line 418
    .line 419
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$9:Ljava/lang/Object;

    .line 420
    .line 421
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$10:Ljava/lang/Object;

    .line 422
    .line 423
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$11:Ljava/lang/Object;

    .line 424
    .line 425
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->L$12:Ljava/lang/Object;

    .line 426
    .line 427
    iput v7, v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;->label:I

    .line 428
    .line 429
    invoke-virtual {v6, v1, v9}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->addAll(Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    if-ne v0, v8, :cond_0

    .line 434
    .line 435
    return-object v8

    .line 436
    :cond_e
    new-instance v9, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;

    .line 437
    .line 438
    invoke-direct {v9, v3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$computeReminderUpdate$1;-><init>(LX/2M4;)V

    .line 439
    .line 440
    .line 441
    goto/16 :goto_0

    .line 442
    .line 443
    :cond_f
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 444
    .line 445
    .line 446
    move-result-object v1

    .line 447
    const-string v0, "reminders"

    .line 448
    .line 449
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 450
    .line 451
    .line 452
    move-result-object v8

    .line 453
    return-object v8

    .line 454
    :cond_10
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 455
    .line 456
    .line 457
    move-result-object v0

    .line 458
    throw v0

    .line 459
    :cond_11
    :try_start_2
    const-string v0, "updates_json must contain at least one update"

    .line 460
    .line 461
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 462
    .line 463
    .line 464
    move-result-object v0

    .line 465
    throw v0
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_0

    .line 466
    :catch_0
    move-exception v0

    .line 467
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v0

    .line 471
    if-nez v0, :cond_12

    .line 472
    .line 473
    move-object v0, v14

    .line 474
    :cond_12
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    return-object v0
.end method

.method public static final evictLegacyReminderRowsOnce(Landroid/content/Context;)V
    .locals 7

    .line 0
    sget-boolean v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->legacyReminderEvictDone:Z

    .line 1
    .line 2
    if-nez v0, :cond_7

    .line 3
    .line 4
    sget-object v6, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$evictLegacyReminderRowsOnce$1;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$evictLegacyReminderRowsOnce$1;

    .line 5
    .line 6
    monitor-enter v6

    .line 7
    :try_start_0
    sget-boolean v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->legacyReminderEvictDone:Z

    .line 8
    .line 9
    if-nez v0, :cond_6

    .line 10
    .line 11
    sget-object v0, Lcom/facebook/aura/commands/alarm/AlarmStore;->Companion:Lcom/facebook/aura/commands/alarm/AlarmStore$Companion;

    .line 12
    .line 13
    invoke-virtual {v0, p0}, Lcom/facebook/aura/commands/alarm/AlarmStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AlarmStore;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    invoke-virtual {v5}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAll()Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    move-object v0, v2

    .line 40
    check-cast v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 41
    .line 42
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/commands/alarm/AlarmType;->REMINDER:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 45
    .line 46
    if-ne v1, v0, :cond_0

    .line 47
    .line 48
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    instance-of v0, v4, Ljava/util/Collection;

    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_3

    .line 62
    .line 63
    :cond_2
    :goto_1
    const/4 v0, 0x1

    .line 64
    sput-boolean v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->legacyReminderEvictDone:Z

    .line 65
    .line 66
    goto :goto_3

    .line 67
    :cond_3
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    :cond_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_5

    .line 76
    .line 77
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 82
    .line 83
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 84
    .line 85
    invoke-virtual {v5, v0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->remove(Ljava/lang/String;)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_4

    .line 90
    .line 91
    add-int/lit8 v3, v3, 0x1

    .line 92
    .line 93
    if-gez v3, :cond_4

    .line 94
    .line 95
    goto :goto_2

    .line 96
    :cond_5
    if-lez v3, :cond_2

    .line 97
    .line 98
    const-string v2, "ReminderHandlers"

    .line 99
    .line 100
    const-string v1, "Evicted "

    .line 101
    .line 102
    const-string v0, " legacy reminder rows from AlarmStore"

    .line 103
    .line 104
    invoke-static {v1, v3, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-static {v2, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    goto :goto_1

    .line 112
    :goto_2
    invoke-static {}, LX/B8B;->A19()V

    .line 113
    .line 114
    .line 115
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 120
    :cond_6
    :goto_3
    monitor-exit v6

    .line 121
    return-void

    .line 122
    :catchall_0
    move-exception v0

    .line 123
    monitor-exit v6

    .line 124
    throw v0

    .line 125
    :cond_7
    return-void
.end method

.method public static final offerChatReminder(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;
    .locals 1

    .line 0
    const-string v0, " The reminder was not set on the phone. Offer to set it for the user yourself as a chat reminder instead, and set it only if they agree."

    .line 1
    .line 2
    invoke-static {p0, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public static final parseReminderDismissTarget(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;
    .locals 3

    .line 0
    const-string v1, "targets_json["

    .line 1
    .line 2
    const-string v0, "]"

    .line 3
    .line 4
    invoke-static {v1, p0, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "alarm_id"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    :cond_0
    const-string v0, ""

    .line 28
    .line 29
    if-nez v2, :cond_1

    .line 30
    .line 31
    move-object v2, v0

    .line 32
    :cond_1
    const-string v0, "message"

    .line 33
    .line 34
    invoke-static {v0, p1}, LX/8ml;->A0M(Ljava/lang/Object;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_2

    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_2

    .line 49
    .line 50
    const-string v0, " must include either \'alarm_id\' or \'message\'."

    .line 51
    .line 52
    invoke-static {p0, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    throw v0

    .line 57
    :cond_2
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;

    .line 58
    .line 59
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/commands/alarm/ReminderDismissTarget;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    return-object v0
.end method

.method public static final parseReminderSetRequest(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/ReminderSetRequest;
    .locals 21

    .line 0
    const/16 v0, 0x60

    .line 1
    .line 2
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v0, "]"

    .line 7
    .line 8
    move/from16 v2, p0

    .line 9
    .line 10
    invoke-static {v1, v2, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "hour"

    .line 15
    .line 16
    move-object/from16 v3, p1

    .line 17
    .line 18
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 23
    .line 24
    const/4 v7, 0x0

    .line 25
    if-eqz v1, :cond_b

    .line 26
    .line 27
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 28
    .line 29
    if-eqz v2, :cond_b

    .line 30
    .line 31
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_b

    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 38
    .line 39
    .line 40
    move-result v5

    .line 41
    :goto_0
    const-string v1, "minutes"

    .line 42
    .line 43
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 48
    .line 49
    if-eqz v1, :cond_a

    .line 50
    .line 51
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 52
    .line 53
    if-eqz v2, :cond_a

    .line 54
    .line 55
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_a

    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    :goto_1
    if-ltz v5, :cond_f

    .line 66
    .line 67
    const/16 v1, 0x18

    .line 68
    .line 69
    if-ge v5, v1, :cond_f

    .line 70
    .line 71
    if-ltz v6, :cond_e

    .line 72
    .line 73
    const/16 v1, 0x3c

    .line 74
    .line 75
    if-ge v6, v1, :cond_e

    .line 76
    .line 77
    const-string v1, "message"

    .line 78
    .line 79
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 84
    .line 85
    if-eqz v1, :cond_0

    .line 86
    .line 87
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 88
    .line 89
    if-eqz v2, :cond_0

    .line 90
    .line 91
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v7

    .line 95
    :cond_0
    const-string v4, ""

    .line 96
    .line 97
    if-nez v7, :cond_1

    .line 98
    .line 99
    move-object v7, v4

    .line 100
    :cond_1
    const-string v1, "days"

    .line 101
    .line 102
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 107
    .line 108
    if-eqz v1, :cond_2

    .line 109
    .line 110
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 111
    .line 112
    if-eqz v2, :cond_2

    .line 113
    .line 114
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    if-nez v8, :cond_3

    .line 119
    .line 120
    :cond_2
    move-object v8, v4

    .line 121
    :cond_3
    const-string v1, "date"

    .line 122
    .line 123
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 128
    .line 129
    if-eqz v1, :cond_4

    .line 130
    .line 131
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 132
    .line 133
    if-eqz v2, :cond_4

    .line 134
    .line 135
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v19

    .line 139
    if-nez v19, :cond_5

    .line 140
    .line 141
    :cond_4
    move-object/from16 v19, v4

    .line 142
    .line 143
    :cond_5
    const-string v1, "frequency"

    .line 144
    .line 145
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 150
    .line 151
    if-eqz v1, :cond_9

    .line 152
    .line 153
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 154
    .line 155
    if-eqz v2, :cond_9

    .line 156
    .line 157
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    if-eqz v1, :cond_9

    .line 162
    .line 163
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    const/4 v2, 0x1

    .line 168
    xor-int/lit8 v1, v1, 0x1

    .line 169
    .line 170
    if-ne v1, v2, :cond_9

    .line 171
    .line 172
    :cond_6
    invoke-static {v0, v3}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseTimeZone(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v14

    .line 176
    if-eqz v14, :cond_7

    .line 177
    .line 178
    invoke-static {v14}, Ljava/time/ZoneId;->of(Ljava/lang/String;)Ljava/time/ZoneId;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    if-nez p1, :cond_8

    .line 183
    .line 184
    :cond_7
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    :cond_8
    invoke-static {v0, v3, v8}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseRecurrence(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 189
    .line 190
    .line 191
    move-result-object v11

    .line 192
    sget-object v15, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 193
    .line 194
    invoke-static/range {p1 .. p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    move/from16 v16, v5

    .line 198
    .line 199
    move/from16 v17, v6

    .line 200
    .line 201
    move-object/from16 v18, v11

    .line 202
    .line 203
    move-object/from16 v20, p1

    .line 204
    .line 205
    invoke-virtual/range {v15 .. v20}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->anchorMsFor$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;Ljava/time/ZoneId;)Ljava/lang/Long;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    if-eqz v1, :cond_d

    .line 210
    .line 211
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 212
    .line 213
    .line 214
    move-result-wide v12

    .line 215
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 216
    .line 217
    .line 218
    move-result-wide v20

    .line 219
    invoke-virtual/range {v15 .. v22}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeFirstTriggerTimeMs$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;JLjava/time/ZoneId;)J

    .line 220
    .line 221
    .line 222
    move-result-wide v9

    .line 223
    const-wide/16 v2, -0x1

    .line 224
    .line 225
    cmp-long v1, v9, v2

    .line 226
    .line 227
    if-eqz v1, :cond_c

    .line 228
    .line 229
    new-instance v4, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;

    .line 230
    .line 231
    invoke-direct/range {v4 .. v14}, Lcom/facebook/aura/commands/alarm/ReminderSetRequest;-><init>(IILjava/lang/String;Ljava/lang/String;JLcom/facebook/aura/commands/alarm/Recurrence;JLjava/lang/String;)V

    .line 232
    .line 233
    .line 234
    return-object v4

    .line 235
    :cond_9
    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->length()I

    .line 236
    .line 237
    .line 238
    move-result v1

    .line 239
    if-lez v1, :cond_6

    .line 240
    .line 241
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 242
    .line 243
    .line 244
    move-result v1

    .line 245
    if-lez v1, :cond_6

    .line 246
    .line 247
    const-string v1, " cannot combine \'date\' (one-time) with \'days\' (recurring). Pick one, or set \'frequency\'."

    .line 248
    .line 249
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    throw v0

    .line 254
    :cond_a
    const/4 v6, -0x1

    .line 255
    goto/16 :goto_1

    .line 256
    .line 257
    :cond_b
    const/4 v5, -0x1

    .line 258
    goto/16 :goto_0

    .line 259
    .line 260
    :cond_c
    const-string v1, " failed to compute trigger time"

    .line 261
    .line 262
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    throw v0

    .line 267
    :cond_d
    const-string v1, ".date must be a valid YYYY-MM-DD date"

    .line 268
    .line 269
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 270
    .line 271
    .line 272
    move-result-object v0

    .line 273
    throw v0

    .line 274
    :cond_e
    const-string v1, ".minutes is missing or invalid; it must be an integer from 0 to 59"

    .line 275
    .line 276
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    throw v0

    .line 281
    :cond_f
    const-string v1, ".hour is missing or invalid; it must be an integer from 0 to 23"

    .line 282
    .line 283
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    throw v0
.end method

.method public static final removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;

    .line 1
    .line 2
    if-eqz v0, :cond_6

    .line 3
    .line 4
    move-object v3, p3

    .line 5
    check-cast v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_6

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x2

    .line 25
    const/4 v6, 0x1

    .line 26
    const/4 v5, 0x0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    if-eq v0, v6, :cond_4

    .line 30
    .line 31
    if-ne v0, v4, :cond_7

    .line 32
    .line 33
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 37
    .line 38
    return-object v2

    .line 39
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 43
    .line 44
    if-nez v1, :cond_2

    .line 45
    .line 46
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 47
    .line 48
    :cond_2
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eq v0, v5, :cond_3

    .line 55
    .line 56
    if-ne v0, v6, :cond_8

    .line 57
    .line 58
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 59
    .line 60
    const/4 v0, 0x0

    .line 61
    iput-object v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$0:Ljava/lang/Object;

    .line 62
    .line 63
    iput-object p1, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$1:Ljava/lang/Object;

    .line 64
    .line 65
    iput-object p2, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$2:Ljava/lang/Object;

    .line 66
    .line 67
    iput v6, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 68
    .line 69
    invoke-virtual {v1, p0, p2, v3}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->remove(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    if-ne v0, v2, :cond_5

    .line 74
    .line 75
    return-object v2

    .line 76
    :cond_3
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 77
    .line 78
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {v1, p0, v0}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_4
    iget-object p2, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$2:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 87
    .line 88
    iget-object p1, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$1:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast p1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 91
    .line 92
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :cond_5
    :goto_1
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 96
    .line 97
    const/4 v0, 0x0

    .line 98
    iput-object v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$0:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v0, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->L$2:Ljava/lang/Object;

    .line 103
    .line 104
    iput v4, v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 105
    .line 106
    invoke-virtual {p1, v1, v3}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    if-ne v0, v2, :cond_0

    .line 111
    .line 112
    return-object v2

    .line 113
    :cond_6
    new-instance v3, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;

    .line 114
    .line 115
    invoke-direct {v3, p3}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;-><init>(LX/2M4;)V

    .line 116
    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    throw v0

    .line 124
    :cond_8
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0
.end method

.method public static final rescheduleReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    move-object v0, p1

    .line 3
    instance-of v1, v4, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    move-object p1, v4

    .line 8
    check-cast p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;

    .line 9
    .line 10
    iget v3, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 11
    .line 12
    const/high16 v2, -0x80000000

    .line 13
    .line 14
    and-int v1, v3, v2

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    sub-int/2addr v3, v2

    .line 19
    iput v3, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 20
    .line 21
    :goto_0
    iget-object v3, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->result:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 24
    .line 25
    iget v1, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 26
    .line 27
    const/4 v8, 0x4

    .line 28
    const/4 v9, 0x3

    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v5, 0x2

    .line 31
    const/4 v6, 0x1

    .line 32
    const/4 v7, 0x0

    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    if-eq v1, v6, :cond_3

    .line 36
    .line 37
    if-eq v1, v5, :cond_8

    .line 38
    .line 39
    if-eq v1, v9, :cond_6

    .line 40
    .line 41
    if-eq v1, v8, :cond_8

    .line 42
    .line 43
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    throw v0

    .line 48
    :cond_0
    new-instance p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;

    .line 49
    .line 50
    invoke-direct {p1, v4}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;-><init>(LX/2M4;)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    move-object v11, p2

    .line 58
    iget-object v3, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 59
    .line 60
    if-nez v3, :cond_2

    .line 61
    .line 62
    sget-object v3, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 63
    .line 64
    :cond_2
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 65
    .line 66
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    move-object v10, p0

    .line 71
    if-eq v1, v7, :cond_b

    .line 72
    .line 73
    if-ne v1, v6, :cond_a

    .line 74
    .line 75
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 76
    .line 77
    if-nez v1, :cond_5

    .line 78
    .line 79
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->calendarId:Ljava/lang/Long;

    .line 80
    .line 81
    if-eqz v1, :cond_c

    .line 82
    .line 83
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 84
    .line 85
    .line 86
    move-result-wide v12

    .line 87
    sget-object v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 88
    .line 89
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$0:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v0, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$2:Ljava/lang/Object;

    .line 94
    .line 95
    iput-wide v12, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->J$0:J

    .line 96
    .line 97
    iput v6, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 98
    .line 99
    invoke-virtual/range {v9 .. v14}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->add(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;JLX/2M4;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    if-ne v3, v4, :cond_4

    .line 104
    .line 105
    return-object v4

    .line 106
    :cond_3
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 109
    .line 110
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_4
    move-object v1, v3

    .line 114
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 115
    .line 116
    if-eqz v1, :cond_c

    .line 117
    .line 118
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$0:Ljava/lang/Object;

    .line 119
    .line 120
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 121
    .line 122
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$2:Ljava/lang/Object;

    .line 123
    .line 124
    iput-object v1, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$3:Ljava/lang/Object;

    .line 125
    .line 126
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$4:Ljava/lang/Object;

    .line 127
    .line 128
    iput v5, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_5
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 132
    .line 133
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$0:Ljava/lang/Object;

    .line 134
    .line 135
    iput-object v0, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$2:Ljava/lang/Object;

    .line 138
    .line 139
    iput v9, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 140
    .line 141
    invoke-virtual {v1, p0, p2, p1}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->replace(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    if-ne v3, v4, :cond_7

    .line 146
    .line 147
    return-object v4

    .line 148
    :cond_6
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 151
    .line 152
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    :cond_7
    move-object v1, v3

    .line 156
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 157
    .line 158
    if-eqz v1, :cond_c

    .line 159
    .line 160
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$0:Ljava/lang/Object;

    .line 161
    .line 162
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$1:Ljava/lang/Object;

    .line 163
    .line 164
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$2:Ljava/lang/Object;

    .line 165
    .line 166
    iput-object v1, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$3:Ljava/lang/Object;

    .line 167
    .line 168
    iput-object v2, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$4:Ljava/lang/Object;

    .line 169
    .line 170
    iput v8, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->label:I

    .line 171
    .line 172
    :goto_1
    invoke-virtual {v0, v1, p1}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    if-ne v0, v4, :cond_9

    .line 177
    .line 178
    return-object v4

    .line 179
    :cond_8
    iget-object v1, p1, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$rescheduleReminder$1;->L$3:Ljava/lang/Object;

    .line 180
    .line 181
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    :cond_9
    return-object v1

    .line 185
    :cond_a
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    throw v0

    .line 190
    :cond_b
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 191
    .line 192
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 193
    .line 194
    invoke-virtual {v1, p0, v0}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v1, p0, p2}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Z

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_c

    .line 202
    .line 203
    return-object p2

    .line 204
    :cond_c
    return-object v2
.end method

.method public static final resolveReminderUpdate(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lcom/facebook/aura/commands/alarm/ShadowReminder;
    .locals 31

    .line 0
    const-string v0, "hour"

    .line 1
    .line 2
    move-object/from16 v9, p1

    .line 3
    .line 4
    invoke-virtual {v9, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 9
    .line 10
    move-object/from16 v15, p2

    .line 11
    .line 12
    if-eqz v0, :cond_6

    .line 13
    .line 14
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 15
    .line 16
    if-eqz v1, :cond_6

    .line 17
    .line 18
    invoke-static {v1}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_6

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    :goto_0
    const-string v0, "minutes"

    .line 29
    .line 30
    invoke-virtual {v9, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 35
    .line 36
    if-eqz v0, :cond_5

    .line 37
    .line 38
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 39
    .line 40
    if-eqz v1, :cond_5

    .line 41
    .line 42
    invoke-static {v1}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eqz v0, :cond_5

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    :goto_1
    move-object/from16 v0, p0

    .line 53
    .line 54
    if-ltz v6, :cond_14

    .line 55
    .line 56
    const/16 v1, 0x18

    .line 57
    .line 58
    if-ge v6, v1, :cond_14

    .line 59
    .line 60
    if-ltz v5, :cond_13

    .line 61
    .line 62
    const/16 v1, 0x3c

    .line 63
    .line 64
    if-ge v5, v1, :cond_13

    .line 65
    .line 66
    const-string v1, "message"

    .line 67
    .line 68
    invoke-virtual {v9, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 73
    .line 74
    if-eqz v1, :cond_0

    .line 75
    .line 76
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 77
    .line 78
    if-eqz v2, :cond_0

    .line 79
    .line 80
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v8

    .line 84
    if-nez v8, :cond_1

    .line 85
    .line 86
    :cond_0
    iget-object v8, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->label:Ljava/lang/String;

    .line 87
    .line 88
    :cond_1
    const-string v11, "frequency"

    .line 89
    .line 90
    invoke-virtual {v9, v11}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    const-string v12, "date"

    .line 95
    .line 96
    const-string v3, "days"

    .line 97
    .line 98
    const/4 v10, 0x1

    .line 99
    if-nez v1, :cond_2

    .line 100
    .line 101
    invoke-virtual {v9, v3}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    if-nez v1, :cond_2

    .line 106
    .line 107
    invoke-virtual {v9, v12}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    const/4 v4, 0x0

    .line 112
    if-eqz v1, :cond_3

    .line 113
    .line 114
    :cond_2
    const/4 v4, 0x1

    .line 115
    :cond_3
    const-string v1, "timezone"

    .line 116
    .line 117
    invoke-virtual {v9, v1}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    if-eqz v1, :cond_4

    .line 122
    .line 123
    invoke-static {v0, v9}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseTimeZone(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    :goto_2
    if-eqz v7, :cond_8

    .line 128
    .line 129
    goto :goto_3

    .line 130
    :cond_4
    iget-object v7, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->timezone:Ljava/lang/String;

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_5
    iget v5, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->minute:I

    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_6
    iget v6, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->hour:I

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :goto_3
    :try_start_0
    invoke-static {v7}, Ljava/time/ZoneId;->of(Ljava/lang/String;)Ljava/time/ZoneId;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    goto :goto_4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 144
    :catchall_0
    move-exception v1

    .line 145
    invoke-static {v1}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    :goto_4
    instance-of v1, v2, LX/2PH;

    .line 150
    .line 151
    if-eqz v1, :cond_7

    .line 152
    .line 153
    const/4 v2, 0x0

    .line 154
    :cond_7
    check-cast v2, Ljava/time/ZoneId;

    .line 155
    .line 156
    if-nez v2, :cond_9

    .line 157
    .line 158
    :cond_8
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    :cond_9
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 163
    .line 164
    .line 165
    move-result-wide v21

    .line 166
    const-string v1, " failed to compute trigger time"

    .line 167
    .line 168
    const-wide/16 v13, -0x1

    .line 169
    .line 170
    if-eqz v4, :cond_10

    .line 171
    .line 172
    invoke-virtual {v9, v3}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v4

    .line 176
    instance-of v3, v4, Lkotlinx/serialization/json/JsonPrimitive;

    .line 177
    .line 178
    if-eqz v3, :cond_d

    .line 179
    .line 180
    check-cast v4, Lkotlinx/serialization/json/JsonPrimitive;

    .line 181
    .line 182
    if-eqz v4, :cond_d

    .line 183
    .line 184
    invoke-static {v4}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v3

    .line 188
    :goto_5
    const-string v4, ""

    .line 189
    .line 190
    if-nez v3, :cond_a

    .line 191
    .line 192
    move-object v3, v4

    .line 193
    :cond_a
    invoke-static {v12, v9}, LX/8ml;->A0M(Ljava/lang/Object;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v20

    .line 197
    invoke-virtual {v9, v11}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v11

    .line 201
    instance-of v4, v11, Lkotlinx/serialization/json/JsonPrimitive;

    .line 202
    .line 203
    if-eqz v4, :cond_c

    .line 204
    .line 205
    check-cast v11, Lkotlinx/serialization/json/JsonPrimitive;

    .line 206
    .line 207
    if-eqz v11, :cond_c

    .line 208
    .line 209
    invoke-static {v11}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v4

    .line 213
    if-eqz v4, :cond_c

    .line 214
    .line 215
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 216
    .line 217
    .line 218
    move-result v4

    .line 219
    xor-int/lit8 v4, v4, 0x1

    .line 220
    .line 221
    if-ne v4, v10, :cond_c

    .line 222
    .line 223
    :cond_b
    invoke-static {v0, v9, v3}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseRecurrence(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 224
    .line 225
    .line 226
    move-result-object v25

    .line 227
    sget-object v16, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 228
    .line 229
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    move-object/from16 v26, v16

    .line 233
    .line 234
    move/from16 v27, v6

    .line 235
    .line 236
    move/from16 v28, v5

    .line 237
    .line 238
    move-object/from16 v29, v25

    .line 239
    .line 240
    move-object/from16 v30, v20

    .line 241
    .line 242
    move-object/from16 p0, v2

    .line 243
    .line 244
    invoke-virtual/range {v26 .. v31}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->anchorMsFor$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;Ljava/time/ZoneId;)Ljava/lang/Long;

    .line 245
    .line 246
    .line 247
    move-result-object v4

    .line 248
    if-eqz v4, :cond_f

    .line 249
    .line 250
    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    .line 251
    .line 252
    .line 253
    move-result-wide v26

    .line 254
    move/from16 v17, v6

    .line 255
    .line 256
    move/from16 v18, v5

    .line 257
    .line 258
    move-object/from16 v19, v25

    .line 259
    .line 260
    move-object/from16 v23, v2

    .line 261
    .line 262
    invoke-virtual/range {v16 .. v23}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeFirstTriggerTimeMs$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;JLjava/time/ZoneId;)J

    .line 263
    .line 264
    .line 265
    move-result-wide v21

    .line 266
    cmp-long v2, v21, v13

    .line 267
    .line 268
    if-eqz v2, :cond_e

    .line 269
    .line 270
    sget-object v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->$childSerializers:[Lkotlin/Lazy;

    .line 271
    .line 272
    iget-object v9, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 273
    .line 274
    iget-object v4, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 275
    .line 276
    iget-object v2, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->calendarId:Ljava/lang/Long;

    .line 277
    .line 278
    const/16 v28, 0x0

    .line 279
    .line 280
    iget-boolean v1, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->pendingSnooze:Z

    .line 281
    .line 282
    iget-object v0, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 283
    .line 284
    move-object/from16 v23, v4

    .line 285
    .line 286
    move-object/from16 v24, v2

    .line 287
    .line 288
    move/from16 v29, v1

    .line 289
    .line 290
    move-object/from16 v30, v7

    .line 291
    .line 292
    move-object/from16 p0, v0

    .line 293
    .line 294
    move/from16 v19, v5

    .line 295
    .line 296
    move-object/from16 v20, v3

    .line 297
    .line 298
    move/from16 v18, v6

    .line 299
    .line 300
    move-object/from16 v17, v8

    .line 301
    .line 302
    move-object/from16 v16, v9

    .line 303
    .line 304
    invoke-virtual/range {v15 .. v31}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy(Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 305
    .line 306
    .line 307
    move-result-object v0

    .line 308
    return-object v0

    .line 309
    :cond_c
    invoke-virtual/range {v20 .. v20}, Ljava/lang/String;->length()I

    .line 310
    .line 311
    .line 312
    move-result v4

    .line 313
    if-lez v4, :cond_b

    .line 314
    .line 315
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 316
    .line 317
    .line 318
    move-result v4

    .line 319
    if-lez v4, :cond_b

    .line 320
    .line 321
    const-string v1, " cannot combine \'date\' (one-time) with \'days\' (recurring). Pick one, or set \'frequency\'."

    .line 322
    .line 323
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    throw v0

    .line 328
    :cond_d
    const/4 v3, 0x0

    .line 329
    goto/16 :goto_5

    .line 330
    .line 331
    :cond_e
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    throw v0

    .line 336
    :cond_f
    const-string v1, ".date must be a valid YYYY-MM-DD date"

    .line 337
    .line 338
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    throw v0

    .line 343
    :cond_10
    invoke-virtual {v15}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 344
    .line 345
    .line 346
    move-result-object v3

    .line 347
    if-eqz v3, :cond_12

    .line 348
    .line 349
    invoke-static {v0, v3, v9}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->mergeRecurrenceBounds(Ljava/lang/String;Lcom/facebook/aura/commands/alarm/Recurrence;Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 350
    .line 351
    .line 352
    move-result-object v20

    .line 353
    if-eqz v20, :cond_12

    .line 354
    .line 355
    sget-object v17, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 356
    .line 357
    iget-wide v3, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->anchorMs:J

    .line 358
    .line 359
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    move-object/from16 v23, v17

    .line 363
    .line 364
    move-wide/from16 v24, v3

    .line 365
    .line 366
    move/from16 v26, v6

    .line 367
    .line 368
    move/from16 v27, v5

    .line 369
    .line 370
    move-object/from16 v28, v2

    .line 371
    .line 372
    invoke-virtual/range {v23 .. v28}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->reanchor(JIILjava/time/ZoneId;)J

    .line 373
    .line 374
    .line 375
    move-result-wide v26

    .line 376
    move/from16 v18, v6

    .line 377
    .line 378
    move/from16 v19, v5

    .line 379
    .line 380
    move-wide/from16 v23, v26

    .line 381
    .line 382
    move-object/from16 v25, v2

    .line 383
    .line 384
    invoke-virtual/range {v17 .. v25}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 385
    .line 386
    .line 387
    move-result-wide v21

    .line 388
    cmp-long v2, v21, v13

    .line 389
    .line 390
    if-eqz v2, :cond_11

    .line 391
    .line 392
    const/16 p1, 0x29d1    # 1.5001E-41f

    .line 393
    .line 394
    const/16 v16, 0x0

    .line 395
    .line 396
    const/16 v28, 0x0

    .line 397
    .line 398
    move-object/from16 v20, v16

    .line 399
    .line 400
    move-object/from16 v23, v16

    .line 401
    .line 402
    move-object/from16 v24, v16

    .line 403
    .line 404
    move-object/from16 v25, v16

    .line 405
    .line 406
    move/from16 v29, v28

    .line 407
    .line 408
    move-object/from16 v30, v7

    .line 409
    .line 410
    move-object/from16 p0, v16

    .line 411
    .line 412
    move-object/from16 p2, v16

    .line 413
    .line 414
    move-object/from16 v17, v8

    .line 415
    .line 416
    invoke-static/range {v15 .. v33}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 417
    .line 418
    .line 419
    move-result-object v0

    .line 420
    return-object v0

    .line 421
    :cond_11
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    throw v0

    .line 426
    :cond_12
    sget-object v23, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 427
    .line 428
    iget-wide v0, v15, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 429
    .line 430
    invoke-static {v2}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 431
    .line 432
    .line 433
    move/from16 v24, v6

    .line 434
    .line 435
    move/from16 v25, v5

    .line 436
    .line 437
    move-wide/from16 v26, v0

    .line 438
    .line 439
    move-wide/from16 v28, v21

    .line 440
    .line 441
    move-object/from16 v30, v2

    .line 442
    .line 443
    invoke-virtual/range {v23 .. v30}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeOneTimeReschedule(IIJJLjava/time/ZoneId;)J

    .line 444
    .line 445
    .line 446
    move-result-wide v21

    .line 447
    const/16 p1, 0x2bd1

    .line 448
    .line 449
    const/16 v16, 0x0

    .line 450
    .line 451
    const-wide/16 v26, 0x0

    .line 452
    .line 453
    const/16 v28, 0x0

    .line 454
    .line 455
    move-object/from16 v20, v16

    .line 456
    .line 457
    move-object/from16 v23, v16

    .line 458
    .line 459
    move-object/from16 v24, v16

    .line 460
    .line 461
    move-object/from16 v25, v16

    .line 462
    .line 463
    move/from16 v29, v28

    .line 464
    .line 465
    move-object/from16 v30, v7

    .line 466
    .line 467
    move-object/from16 p0, v16

    .line 468
    .line 469
    move-object/from16 p2, v16

    .line 470
    .line 471
    move/from16 v19, v5

    .line 472
    .line 473
    move/from16 v18, v6

    .line 474
    .line 475
    move-object/from16 v17, v8

    .line 476
    .line 477
    invoke-static/range {v15 .. v33}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 478
    .line 479
    .line 480
    move-result-object v0

    .line 481
    return-object v0

    .line 482
    :cond_13
    const-string v1, ".minutes must be an integer from 0 to 59"

    .line 483
    .line 484
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 485
    .line 486
    .line 487
    move-result-object v0

    .line 488
    throw v0

    .line 489
    :cond_14
    const-string v1, ".hour must be an integer from 0 to 23"

    .line 490
    .line 491
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 492
    .line 493
    .line 494
    move-result-object v0

    .line 495
    throw v0
.end method

.method public static final toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowReminder;)Lkotlinx/serialization/json/JsonObject;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v2, LX/BcB;

    .line 5
    .line 6
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 7
    .line 8
    .line 9
    const-string v1, "id"

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 14
    .line 15
    .line 16
    const-string v1, "label"

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->label:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 21
    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->hour:I

    .line 24
    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const-string v0, "hour"

    .line 30
    .line 31
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 32
    .line 33
    .line 34
    iget v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->minute:I

    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v0, "minute"

    .line 41
    .line 42
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 43
    .line 44
    .line 45
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 46
    .line 47
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const-string v0, "trigger_time_ms"

    .line 52
    .line 53
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 54
    .line 55
    .line 56
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 57
    .line 58
    invoke-static {v0, v1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-virtual {v1, v0}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    sget-object v0, Ljava/time/format/DateTimeFormatter;->ISO_OFFSET_DATE_TIME:Ljava/time/format/DateTimeFormatter;

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Ljava/time/ZonedDateTime;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    const-string v0, "trigger_time_iso"

    .line 77
    .line 78
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 79
    .line 80
    .line 81
    const-string v1, "days"

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->days:Ljava/lang/String;

    .line 84
    .line 85
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 86
    .line 87
    .line 88
    new-instance v3, LX/Bcq;

    .line 89
    .line 90
    invoke-direct {v3}, LX/Bcq;-><init>()V

    .line 91
    .line 92
    .line 93
    sget-object v1, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 94
    .line 95
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->days:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->weekdayNames(Ljava/lang/String;)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_0

    .line 110
    .line 111
    invoke-static {v1}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-static {v0, v3}, LX/BgH;->A06(Ljava/lang/String;LX/Bcq;)V

    .line 116
    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_0
    invoke-virtual {v3}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    const-string v0, "days_weekdays"

    .line 124
    .line 125
    invoke-virtual {v2, v0, v1}, LX/BcB;->A07(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    if-eqz v3, :cond_2

    .line 133
    .line 134
    iget-object v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->frequency:Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;

    .line 135
    .line 136
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    const-string v0, "frequency"

    .line 141
    .line 142
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 143
    .line 144
    .line 145
    iget v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->interval:I

    .line 146
    .line 147
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    const-string v0, "interval"

    .line 152
    .line 153
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 154
    .line 155
    .line 156
    iget-object v1, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 157
    .line 158
    if-eqz v1, :cond_1

    .line 159
    .line 160
    const-string v0, "count"

    .line 161
    .line 162
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 163
    .line 164
    .line 165
    :cond_1
    iget-object v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->until:Ljava/lang/Long;

    .line 166
    .line 167
    if-eqz v0, :cond_2

    .line 168
    .line 169
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 170
    .line 171
    .line 172
    move-result-wide v0

    .line 173
    invoke-static {v0, v1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v1

    .line 181
    const-string v0, "until"

    .line 182
    .line 183
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 184
    .line 185
    .line 186
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->timezone:Ljava/lang/String;

    .line 187
    .line 188
    if-eqz v1, :cond_3

    .line 189
    .line 190
    const-string v0, "timezone"

    .line 191
    .line 192
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 193
    .line 194
    .line 195
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 196
    .line 197
    if-nez v0, :cond_4

    .line 198
    .line 199
    sget-object v0, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 200
    .line 201
    :cond_4
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->getWireName()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    const-string v0, "delivery"

    .line 206
    .line 207
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 208
    .line 209
    .line 210
    const-string v1, "type"

    .line 211
    .line 212
    const-string v0, "REMINDER"

    .line 213
    .line 214
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    return-object v0
.end method
