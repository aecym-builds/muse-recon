.class public final Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final fromJson(Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/NodeAlarm;
    .locals 11

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v0, "id"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v0, :cond_9

    .line 14
    .line 15
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 16
    .line 17
    if-eqz v1, :cond_9

    .line 18
    .line 19
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    :goto_0
    const-string v2, ""

    .line 24
    .line 25
    if-nez v4, :cond_0

    .line 26
    .line 27
    move-object v4, v2

    .line 28
    :cond_0
    const-string v0, "label"

    .line 29
    .line 30
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 35
    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 39
    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v5

    .line 46
    if-nez v5, :cond_2

    .line 47
    .line 48
    :cond_1
    move-object v5, v2

    .line 49
    :cond_2
    const-string v0, "hour"

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 56
    .line 57
    if-eqz v0, :cond_8

    .line 58
    .line 59
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 60
    .line 61
    :goto_1
    const/4 v7, 0x0

    .line 62
    if-eqz v1, :cond_7

    .line 63
    .line 64
    invoke-static {v1}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-eqz v0, :cond_7

    .line 69
    .line 70
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 71
    .line 72
    .line 73
    move-result v6

    .line 74
    :goto_2
    const-string v0, "minute"

    .line 75
    .line 76
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 81
    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 85
    .line 86
    if-eqz v1, :cond_3

    .line 87
    .line 88
    invoke-static {v1}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-eqz v0, :cond_3

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 95
    .line 96
    .line 97
    move-result v7

    .line 98
    :cond_3
    const-string v0, "trigger_time_ms"

    .line 99
    .line 100
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 105
    .line 106
    if-eqz v0, :cond_6

    .line 107
    .line 108
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 109
    .line 110
    if-eqz v1, :cond_6

    .line 111
    .line 112
    invoke-static {v1}, LX/Dcc;->A03(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Long;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    if-eqz v0, :cond_6

    .line 117
    .line 118
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 119
    .line 120
    .line 121
    move-result-wide v8

    .line 122
    :goto_3
    const-string v0, "days"

    .line 123
    .line 124
    invoke-static {v0, p1}, LX/8ml;->A0M(Ljava/lang/Object;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v10

    .line 128
    const-string v0, "vibrate"

    .line 129
    .line 130
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 135
    .line 136
    if-eqz v0, :cond_5

    .line 137
    .line 138
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 139
    .line 140
    if-eqz v1, :cond_5

    .line 141
    .line 142
    invoke-static {v1}, LX/Dcc;->A01(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Boolean;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    if-eqz v0, :cond_5

    .line 147
    .line 148
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 149
    .line 150
    .line 151
    move-result p0

    .line 152
    :goto_4
    sget-object v2, Lcom/facebook/aura/commands/alarm/AlarmType;->Companion:Lcom/facebook/aura/commands/alarm/AlarmType$Companion;

    .line 153
    .line 154
    const-string v0, "type"

    .line 155
    .line 156
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 161
    .line 162
    if-eqz v0, :cond_4

    .line 163
    .line 164
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 165
    .line 166
    if-eqz v1, :cond_4

    .line 167
    .line 168
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v3

    .line 172
    :cond_4
    invoke-virtual {v2, v3}, Lcom/facebook/aura/commands/alarm/AlarmType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    new-instance v3, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 177
    .line 178
    invoke-direct/range {v3 .. v12}, Lcom/facebook/aura/commands/alarm/NodeAlarm;-><init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)V

    .line 179
    .line 180
    .line 181
    return-object v3

    .line 182
    :cond_5
    const/4 p0, 0x1

    .line 183
    goto :goto_4

    .line 184
    :cond_6
    const-wide/16 v8, 0x0

    .line 185
    .line 186
    goto :goto_3

    .line 187
    :cond_7
    const/4 v6, 0x0

    .line 188
    goto :goto_2

    .line 189
    :cond_8
    move-object v1, v3

    .line 190
    goto/16 :goto_1

    .line 191
    .line 192
    :cond_9
    move-object v4, v3

    .line 193
    goto/16 :goto_0
.end method
