.class public final Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.AlarmFireReceiver$onReceive$1"
    f = "AlarmFireReceiver.kt"
    l = {
        0x2b,
        0x45,
        0x48
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $alarmId:Ljava/lang/String;

.field public final synthetic $appContext:Landroid/content/Context;

.field public final synthetic $pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

.field public I$0:I

.field public I$1:I

.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Landroid/content/BroadcastReceiver$PendingResult;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 27

    .line 0
    move-object/from16 v6, p1

    .line 1
    .line 2
    const-string v2, "Alarm "

    .line 3
    .line 4
    const-string v10, "Failed to handle alarm fire "

    .line 5
    .line 6
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 7
    .line 8
    move-object/from16 v7, p0

    .line 9
    .line 10
    iget v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->label:I

    .line 11
    .line 12
    const-string v9, "AlarmFireReceiver"

    .line 13
    .line 14
    const/4 v11, 0x3

    .line 15
    const/4 v8, 0x2

    .line 16
    const/4 v4, 0x1

    .line 17
    if-eqz v0, :cond_3

    .line 18
    .line 19
    if-eq v0, v4, :cond_2

    .line 20
    .line 21
    if-eq v0, v8, :cond_1

    .line 22
    .line 23
    if-ne v0, v11, :cond_0

    .line 24
    .line 25
    :try_start_0
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    goto/16 :goto_5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    .line 30
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    throw v0

    .line 35
    :cond_1
    iget-object v12, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$3:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 38
    .line 39
    goto/16 :goto_4

    .line 40
    .line 41
    :cond_2
    iget-object v3, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v3, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_3
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :try_start_1
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 50
    .line 51
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 52
    .line 53
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 61
    .line 62
    iput-object v3, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 63
    .line 64
    iput v4, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->label:I

    .line 65
    .line 66
    invoke-virtual {v3, v0, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v6

    .line 70
    if-ne v6, v5, :cond_4

    .line 71
    .line 72
    return-object v5

    .line 73
    :goto_0
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_4
    check-cast v6, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 77
    .line 78
    if-nez v6, :cond_5

    .line 79
    .line 80
    iget-object v1, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 81
    .line 82
    const-string v0, " fired but not found in store"

    .line 83
    .line 84
    invoke-static {v2, v1, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v9, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 92
    .line 93
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 94
    .line 95
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 96
    .line 97
    .line 98
    return-object v5

    .line 99
    :cond_5
    :try_start_2
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;

    .line 100
    .line 101
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 102
    .line 103
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v1, v0, v6}, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->show$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v6}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    iget v1, v6, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->firedCount:I

    .line 114
    .line 115
    add-int/lit8 v2, v1, 0x1

    .line 116
    .line 117
    if-eqz v0, :cond_6

    .line 118
    .line 119
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_6
    const/4 v1, 0x0

    .line 123
    :goto_1
    if-eqz v1, :cond_7

    .line 124
    .line 125
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 126
    .line 127
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    if-lt v2, v1, :cond_7

    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_7
    const/4 v4, 0x0

    .line 135
    :goto_2
    const-wide/16 v15, -0x1

    .line 136
    .line 137
    if-eqz v0, :cond_8

    .line 138
    .line 139
    if-nez v4, :cond_8

    .line 140
    .line 141
    sget-object v17, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 142
    .line 143
    iget v14, v6, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->hour:I

    .line 144
    .line 145
    iget v1, v6, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->minute:I

    .line 146
    .line 147
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 148
    .line 149
    .line 150
    move-result-wide v21

    .line 151
    iget-wide v12, v6, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->anchorMs:J

    .line 152
    .line 153
    invoke-virtual {v6}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->zoneId()Ljava/time/ZoneId;

    .line 154
    .line 155
    .line 156
    move-result-object v25

    .line 157
    move-wide/from16 v23, v12

    .line 158
    .line 159
    move/from16 v19, v1

    .line 160
    .line 161
    move-object/from16 v20, v0

    .line 162
    .line 163
    move/from16 v18, v14

    .line 164
    .line 165
    invoke-virtual/range {v17 .. v25}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 166
    .line 167
    .line 168
    move-result-wide v0

    .line 169
    goto :goto_3

    .line 170
    :cond_8
    const-wide/16 v0, -0x1

    .line 171
    .line 172
    :goto_3
    cmp-long v12, v0, v15

    .line 173
    .line 174
    if-eqz v12, :cond_a

    .line 175
    .line 176
    const/16 p0, 0xbef

    .line 177
    .line 178
    const/4 v11, 0x0

    .line 179
    const/4 v15, 0x0

    .line 180
    const-wide/16 v23, 0x0

    .line 181
    .line 182
    move-object v14, v11

    .line 183
    move/from16 v16, v15

    .line 184
    .line 185
    move-object/from16 v19, v11

    .line 186
    .line 187
    move/from16 v20, v15

    .line 188
    .line 189
    move/from16 v21, v15

    .line 190
    .line 191
    move-object/from16 v22, v11

    .line 192
    .line 193
    move/from16 v25, v2

    .line 194
    .line 195
    move-object/from16 v26, v11

    .line 196
    .line 197
    move-object/from16 p1, v11

    .line 198
    .line 199
    move-wide/from16 v17, v0

    .line 200
    .line 201
    move-object v13, v11

    .line 202
    move-object v12, v6

    .line 203
    invoke-static/range {v12 .. v28}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowAlarm;Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZZLcom/facebook/aura/commands/alarm/Recurrence;JILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 204
    .line 205
    .line 206
    move-result-object v12

    .line 207
    iput-object v11, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 208
    .line 209
    iput-object v11, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 210
    .line 211
    iput-object v11, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 212
    .line 213
    iput-object v12, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$3:Ljava/lang/Object;

    .line 214
    .line 215
    iput v2, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->I$0:I

    .line 216
    .line 217
    iput v4, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->I$1:I

    .line 218
    .line 219
    iput-wide v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->J$0:J

    .line 220
    .line 221
    iput v8, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->label:I

    .line 222
    .line 223
    invoke-virtual {v3, v12, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowAlarm;LX/2M4;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    if-ne v0, v5, :cond_9

    .line 228
    .line 229
    return-object v5

    .line 230
    :goto_4
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    :cond_9
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 234
    .line 235
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$appContext:Landroid/content/Context;

    .line 236
    .line 237
    invoke-static {v0}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v1, v0, v12}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Z

    .line 241
    .line 242
    .line 243
    goto :goto_5

    .line 244
    :cond_a
    iget-object v8, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 245
    .line 246
    const/4 v6, 0x0

    .line 247
    iput-object v6, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$0:Ljava/lang/Object;

    .line 248
    .line 249
    iput-object v6, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$1:Ljava/lang/Object;

    .line 250
    .line 251
    iput-object v6, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->L$2:Ljava/lang/Object;

    .line 252
    .line 253
    iput v2, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->I$0:I

    .line 254
    .line 255
    iput v4, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->I$1:I

    .line 256
    .line 257
    iput-wide v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->J$0:J

    .line 258
    .line 259
    iput v11, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->label:I

    .line 260
    .line 261
    invoke-virtual {v3, v8, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    if-ne v0, v5, :cond_b

    .line 266
    .line 267
    return-object v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 268
    :catch_0
    move-exception v3

    .line 269
    :try_start_3
    iget-object v2, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$alarmId:Ljava/lang/String;

    .line 270
    .line 271
    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v1

    .line 275
    const-string v0, ": "

    .line 276
    .line 277
    invoke-static {v10, v2, v0, v1}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    invoke-static {v9, v0, v3}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 282
    .line 283
    .line 284
    :cond_b
    :goto_5
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 285
    .line 286
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 287
    .line 288
    .line 289
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 290
    .line 291
    return-object v5

    .line 292
    :catchall_0
    move-exception v1

    .line 293
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;->$pendingResult:Landroid/content/BroadcastReceiver$PendingResult;

    .line 294
    .line 295
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 296
    .line 297
    .line 298
    throw v1
.end method
