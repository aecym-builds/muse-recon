.class public final Lcom/facebook/aura/commands/alarm/NodeAlarm;
.super LX/07H;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;


# instance fields
.field public final days:Ljava/lang/String;

.field public final hour:I

.field public final id:Ljava/lang/String;

.field public final label:Ljava/lang/String;

.field public final minute:I

.field public final triggerTimeMs:J

.field public final type:Lcom/facebook/aura/commands/alarm/AlarmType;

.field public final vibrate:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->Companion:Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    const/4 v0, 0x5

    .line 268435460
    invoke-static {p7, v0, p9}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 268435461
    .line 268435462
    .line 268435463
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435464
    .line 268435465
    .line 268435466
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 268435467
    .line 268435468
    iput-object p2, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 268435469
    .line 268435470
    iput p3, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 268435471
    .line 268435472
    iput p4, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 268435473
    .line 268435474
    iput-wide p5, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 268435475
    .line 268435476
    iput-object p7, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 268435477
    .line 268435478
    iput-boolean p8, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 268435479
    .line 268435480
    iput-object p9, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 268435481
    .line 268435482
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;ILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x20

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const-string p7, ""

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x40

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    const/4 p8, 0x1

    .line 11
    :cond_1
    and-int/lit16 v0, p10, 0x80

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sget-object p9, Lcom/facebook/aura/commands/alarm/AlarmType;->ALARM:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 16
    .line 17
    :cond_2
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/commands/alarm/NodeAlarm;-><init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/commands/alarm/NodeAlarm;Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/NodeAlarm;
    .locals 1

    .line 0
    and-int/lit8 v0, p10, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p10, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p10, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget p3, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p10, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget p4, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p10, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-wide p5, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p10, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p7, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p10, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-boolean p8, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p10, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p9, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 47
    .line 48
    :cond_7
    invoke-virtual/range {p0 .. p9}, Lcom/facebook/aura/commands/alarm/NodeAlarm;->copy(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 1
    .line 2
    return p0
.end method

.method public final component4()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 1
    .line 2
    return p0
.end method

.method public final component5()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component8()Lcom/facebook/aura/commands/alarm/AlarmType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)Lcom/facebook/aura/commands/alarm/NodeAlarm;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 p0, 0x5

    .line 4
    invoke-static {p7, p0, p9}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    new-instance p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 8
    .line 9
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/commands/alarm/NodeAlarm;-><init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZLcom/facebook/aura/commands/alarm/AlarmType;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 31
    .line 32
    iget v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 37
    .line 38
    iget v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 39
    .line 40
    if-ne v1, v0, :cond_0

    .line 41
    .line 42
    iget-wide v3, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 43
    .line 44
    iget-wide v1, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 45
    .line 46
    cmp-long v0, v3, v1

    .line 47
    .line 48
    if-nez v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-boolean v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 61
    .line 62
    iget-boolean v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 63
    .line 64
    if-ne v1, v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 69
    .line 70
    if-eq v1, v0, :cond_1

    .line 71
    .line 72
    :cond_0
    return v5

    .line 73
    :cond_1
    return v6
.end method

.method public final getDays()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHour()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 1
    .line 2
    return p0
.end method

.method public final getId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMinute()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 1
    .line 2
    return p0
.end method

.method public final getTriggerTimeMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getType()Lcom/facebook/aura/commands/alarm/AlarmType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVibrate()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 13
    .line 14
    add-int/2addr v1, v0

    .line 15
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    .line 17
    iget v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 18
    .line 19
    add-int/2addr v1, v0

    .line 20
    mul-int/lit8 v2, v1, 0x1f

    .line 21
    .line 22
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, LX/604;->A03(JI)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    iget-boolean v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 41
    .line 42
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    return v0
.end method

.method public final isRecurring()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    invoke-static {p0}, LX/003;->A1F(I)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final toJson()Lkotlinx/serialization/json/JsonObject;
    .locals 3

    .line 0
    new-instance v2, LX/BcB;

    .line 1
    .line 2
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 3
    .line 4
    .line 5
    const-string v1, "id"

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 10
    .line 11
    .line 12
    const-string v1, "label"

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 17
    .line 18
    .line 19
    iget v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->hour:I

    .line 20
    .line 21
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v0, "hour"

    .line 26
    .line 27
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 28
    .line 29
    .line 30
    iget v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->minute:I

    .line 31
    .line 32
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const-string v0, "minute"

    .line 37
    .line 38
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 39
    .line 40
    .line 41
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->triggerTimeMs:J

    .line 42
    .line 43
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    const-string v0, "trigger_time_ms"

    .line 48
    .line 49
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 50
    .line 51
    .line 52
    const-string v1, "days"

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->days:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 57
    .line 58
    .line 59
    iget-boolean v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->vibrate:Z

    .line 60
    .line 61
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const-string v0, "vibrate"

    .line 66
    .line 67
    invoke-static {v1, v0, v2}, LX/BgH;->A01(Ljava/lang/Boolean;Ljava/lang/String;LX/BcB;)V

    .line 68
    .line 69
    .line 70
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->type:Lcom/facebook/aura/commands/alarm/AlarmType;

    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    const-string v0, "type"

    .line 77
    .line 78
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
