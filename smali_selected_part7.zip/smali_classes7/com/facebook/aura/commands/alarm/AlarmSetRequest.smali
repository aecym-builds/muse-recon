.class public final Lcom/facebook/aura/commands/alarm/AlarmSetRequest;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final anchorMs:J

.field public final days:Ljava/lang/String;

.field public final hasExplicitDate:Z

.field public final hour:I

.field public final label:Ljava/lang/String;

.field public final minute:I

.field public final recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

.field public final timezone:Ljava/lang/String;

.field public final triggerTimeMs:J

.field public final vibrate:Z


# direct methods
.method public constructor <init>(IILjava/lang/String;Ljava/lang/String;ZJLcom/facebook/aura/commands/alarm/Recurrence;JZLjava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p3, v0, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->days:Ljava/lang/String;

    .line 14
    .line 15
    iput-boolean p5, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->vibrate:Z

    .line 16
    .line 17
    iput-wide p6, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->triggerTimeMs:J

    .line 18
    .line 19
    iput-object p8, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 20
    .line 21
    iput-wide p9, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->anchorMs:J

    .line 22
    .line 23
    iput-boolean p11, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hasExplicitDate:Z

    .line 24
    .line 25
    iput-object p12, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->timezone:Ljava/lang/String;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final getAnchorMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->anchorMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getDays()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->days:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHasExplicitDate()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hasExplicitDate:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getHour()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 1
    .line 2
    return p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMinute()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 1
    .line 2
    return p0
.end method

.method public final getRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTimezone()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->timezone:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTriggerTimeMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->triggerTimeMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getVibrate()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->vibrate:Z

    .line 1
    .line 2
    return p0
.end method
