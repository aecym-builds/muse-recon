.class public final Lcom/facebook/aura/commands/alarm/AlarmStore;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/commands/alarm/AlarmStore$Companion;

.field public static final KEY_ALARMS:Ljava/lang/String; = "alarms"

.field public static final PREFS_NAME:Ljava/lang/String; = "hatch_alarms"

.field public static volatile instance:Lcom/facebook/aura/commands/alarm/AlarmStore;


# instance fields
.field public final prefs:Landroid/content/SharedPreferences;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmStore$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/AlarmStore;->Companion:Lcom/facebook/aura/commands/alarm/AlarmStore$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 268435460
    .line 268435461
    .line 268435462
    move-result-object v2

    .line 268435463
    const-string v1, "hatch_alarms"

    .line 268435464
    .line 268435465
    const/4 v0, 0x0

    .line 268435466
    invoke-virtual {v2, v1, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 268435471
    .line 268435472
    .line 268435473
    iput-object v0, p0, Lcom/facebook/aura/commands/alarm/AlarmStore;->prefs:Landroid/content/SharedPreferences;

    .line 268435474
    .line 268435475
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/commands/alarm/AlarmStore;-><init>(Landroid/content/Context;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getInstance$cp()Lcom/facebook/aura/commands/alarm/AlarmStore;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/commands/alarm/AlarmStore;->instance:Lcom/facebook/aura/commands/alarm/AlarmStore;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$setInstance$cp(Lcom/facebook/aura/commands/alarm/AlarmStore;)V
    .locals 0

    .line 0
    sput-object p0, Lcom/facebook/aura/commands/alarm/AlarmStore;->instance:Lcom/facebook/aura/commands/alarm/AlarmStore;

    .line 1
    .line 2
    return-void
.end method

.method private final getAllMutable()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/NodeAlarm;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/AlarmStore;->prefs:Landroid/content/SharedPreferences;

    .line 1
    .line 2
    const-string v0, "alarms"

    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    invoke-interface {v1, v0, p0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0

    .line 16
    :cond_0
    :try_start_0
    sget-object v0, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 17
    .line 18
    invoke-virtual {v0, v1}, LX/Dcb;->A04(Ljava/lang/String;)Lkotlinx/serialization/json/JsonElement;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    sget-object v0, LX/Dcc;->A00:LX/Da5;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 26
    .line 27
    .line 28
    instance-of v0, v1, Lkotlinx/serialization/json/JsonArray;

    .line 29
    .line 30
    if-eqz v0, :cond_5

    .line 31
    .line 32
    move-object v0, v1

    .line 33
    check-cast v0, Lkotlinx/serialization/json/JsonArray;

    .line 34
    .line 35
    if-eqz v0, :cond_5

    .line 36
    .line 37
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    invoke-virtual {v0}, Lkotlinx/serialization/json/JsonArray;->iterator()Ljava/util/Iterator;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_4

    .line 50
    .line 51
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    check-cast v1, Lkotlinx/serialization/json/JsonElement;

    .line 56
    .line 57
    instance-of v0, v1, Lkotlinx/serialization/json/JsonObject;

    .line 58
    .line 59
    if-eqz v0, :cond_2

    .line 60
    .line 61
    check-cast v1, Lkotlinx/serialization/json/JsonObject;

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    move-object v1, p0

    .line 65
    :goto_1
    if-eqz v1, :cond_3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 66
    .line 67
    :try_start_1
    sget-object v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->Companion:Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;

    .line 68
    .line 69
    invoke-virtual {v0, v1}, Lcom/facebook/aura/commands/alarm/NodeAlarm$Companion;->fromJson(Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    goto :goto_2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 74
    :catch_0
    :cond_3
    move-object v0, p0

    .line 75
    :goto_2
    if-eqz v0, :cond_1

    .line 76
    .line 77
    :try_start_2
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_4
    invoke-static {v3}, LX/001;->A13(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    return-object v0

    .line 86
    :cond_5
    const/16 v0, 0x10

    .line 87
    .line 88
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-static {v0, v1}, LX/Dcc;->A0A(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;)V

    .line 93
    .line 94
    .line 95
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    throw v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 100
    :catch_1
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    return-object v0
.end method

.method private final persist(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/NodeAlarm;",
            ">;)V"
        }
    .end annotation

    .line 0
    new-instance v2, LX/Bcq;

    .line 1
    .line 2
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/NodeAlarm;->toJson()Lkotlinx/serialization/json/JsonObject;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/AlarmStore;->prefs:Landroid/content/SharedPreferences;

    .line 34
    .line 35
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    const-string v1, "alarms"

    .line 40
    .line 41
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-interface {v2, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 50
    .line 51
    .line 52
    return-void
.end method


# virtual methods
.method public final clear()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/AlarmStore;->prefs:Landroid/content/SharedPreferences;

    .line 1
    .line 2
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    const-string v0, "alarms"

    .line 7
    .line 8
    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final findById(Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/NodeAlarm;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAllMutable()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v0, v1

    .line 23
    check-cast v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->id:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    :goto_0
    check-cast v1, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 34
    .line 35
    return-object v1

    .line 36
    :cond_1
    const/4 v1, 0x0

    .line 37
    goto :goto_0
.end method

.method public final findByLabel(Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/NodeAlarm;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAllMutable()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v0, v1

    .line 23
    check-cast v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/NodeAlarm;->label:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    :goto_0
    check-cast v1, Lcom/facebook/aura/commands/alarm/NodeAlarm;

    .line 36
    .line 37
    return-object v1

    .line 38
    :cond_1
    const/4 v1, 0x0

    .line 39
    goto :goto_0
.end method

.method public final getAll()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/NodeAlarm;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAllMutable()Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public final remove(Ljava/lang/String;)Z
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAllMutable()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmStore$remove$removed$1;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/facebook/aura/commands/alarm/AlarmStore$remove$removed$1;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-static {v1, v0}, LX/12R;->A0D(Ljava/util/List;LX/JDM;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-direct {p0, v1}, Lcom/facebook/aura/commands/alarm/AlarmStore;->persist(Ljava/util/List;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return v0
.end method

.method public final save(Lcom/facebook/aura/commands/alarm/NodeAlarm;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AlarmStore;->getAllMutable()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmStore$save$1;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/facebook/aura/commands/alarm/AlarmStore$save$1;-><init>(Lcom/facebook/aura/commands/alarm/NodeAlarm;)V

    .line 11
    .line 12
    .line 13
    invoke-static {v1, v0}, LX/12R;->A0D(Ljava/util/List;LX/JDM;)Z

    .line 14
    .line 15
    .line 16
    invoke-interface {v1, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    invoke-direct {p0, v1}, Lcom/facebook/aura/commands/alarm/AlarmStore;->persist(Ljava/util/List;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
