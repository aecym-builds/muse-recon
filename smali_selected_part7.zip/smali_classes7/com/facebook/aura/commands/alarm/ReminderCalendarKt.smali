.class public abstract Lcom/facebook/aura/commands/alarm/ReminderCalendarKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final EVENT_MIME_TYPE:Ljava/lang/String; = "vnd.android.cursor.item/event"

.field public static final TAG:Ljava/lang/String; = "ReminderCalendar"


# direct methods
.method public static final nextOccurrence(Lcom/facebook/aura/commands/alarm/ShadowReminder;J)J
    .locals 17

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    iget-wide v10, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 7
    .line 8
    cmp-long v1, v10, p1

    .line 9
    .line 10
    if-gez v1, :cond_2

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 13
    .line 14
    .line 15
    move-result-object v9

    .line 16
    const-wide/16 v4, -0x1

    .line 17
    .line 18
    if-eqz v9, :cond_1

    .line 19
    .line 20
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 21
    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    iget-wide v10, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 29
    .line 30
    const/4 v2, 0x1

    .line 31
    :goto_0
    cmp-long v1, v10, p1

    .line 32
    .line 33
    if-gez v1, :cond_2

    .line 34
    .line 35
    if-ge v2, v3, :cond_1

    .line 36
    .line 37
    sget-object v6, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 38
    .line 39
    iget v7, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->hour:I

    .line 40
    .line 41
    iget v8, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->minute:I

    .line 42
    .line 43
    iget-wide v12, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->anchorMs:J

    .line 44
    .line 45
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->zoneId()Ljava/time/ZoneId;

    .line 46
    .line 47
    .line 48
    move-result-object v14

    .line 49
    invoke-virtual/range {v6 .. v14}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 50
    .line 51
    .line 52
    move-result-wide v10

    .line 53
    cmp-long v1, v10, v4

    .line 54
    .line 55
    if-eqz v1, :cond_2

    .line 56
    .line 57
    add-int/lit8 v2, v2, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    sget-object v11, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 61
    .line 62
    iget v12, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->hour:I

    .line 63
    .line 64
    iget v13, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->minute:I

    .line 65
    .line 66
    const-wide/16 v1, 0x1

    .line 67
    .line 68
    sub-long v15, p1, v1

    .line 69
    .line 70
    iget-wide v1, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->anchorMs:J

    .line 71
    .line 72
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->zoneId()Ljava/time/ZoneId;

    .line 73
    .line 74
    .line 75
    move-result-object p2

    .line 76
    move-object v14, v9

    .line 77
    move-wide/from16 p0, v1

    .line 78
    .line 79
    invoke-virtual/range {v11 .. v19}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 80
    .line 81
    .line 82
    move-result-wide v10

    .line 83
    return-wide v10

    .line 84
    :cond_1
    return-wide v4

    .line 85
    :cond_2
    return-wide v10
.end method
