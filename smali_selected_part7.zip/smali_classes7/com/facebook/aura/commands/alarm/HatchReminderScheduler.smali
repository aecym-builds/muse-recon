.class public final Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;
    .locals 2

    .line 0
    const-class v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver;

    .line 1
    .line 2
    new-instance p0, Landroid/content/Intent;

    .line 3
    .line 4
    invoke-direct {p0, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 5
    .line 6
    .line 7
    const-string v0, "com.facebook.aura.REMINDER_FIRE"

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 10
    .line 11
    .line 12
    const-string v0, "reminder_id"

    .line 13
    .line 14
    invoke-virtual {p0, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 15
    .line 16
    .line 17
    const/high16 v1, 0x24000000

    .line 18
    .line 19
    if-eqz p3, :cond_0

    .line 20
    .line 21
    const/high16 v1, 0xc000000

    .line 22
    .line 23
    :cond_0
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {p1, v0, p0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method


# virtual methods
.method public final cancel(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    const-string v0, "alarm"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    instance-of v0, v1, Landroid/app/AlarmManager;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    check-cast v1, Landroid/app/AlarmManager;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    invoke-direct {p0, p1, p2, v2}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/app/PendingIntent;->cancel()V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method public final reregisterAll(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    move-object/from16 v3, p1

    .line 3
    .line 4
    instance-of v0, v4, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;

    .line 5
    .line 6
    move-object/from16 v8, p0

    .line 7
    .line 8
    if-eqz v0, :cond_8

    .line 9
    .line 10
    move-object v7, v4

    .line 11
    check-cast v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;

    .line 12
    .line 13
    iget v2, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v2, v1

    .line 18
    .line 19
    if-eqz v0, :cond_8

    .line 20
    .line 21
    sub-int/2addr v2, v1

    .line 22
    iput v2, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v2, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 29
    .line 30
    const/4 v5, 0x3

    .line 31
    const/4 v4, 0x2

    .line 32
    const/4 v1, 0x1

    .line 33
    if-eqz v0, :cond_5

    .line 34
    .line 35
    if-eq v0, v1, :cond_6

    .line 36
    .line 37
    if-eq v0, v4, :cond_3

    .line 38
    .line 39
    if-ne v0, v5, :cond_a

    .line 40
    .line 41
    iget-object v12, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$4:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 44
    .line 45
    iget-object v9, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$2:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v9, Ljava/util/Iterator;

    .line 48
    .line 49
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 52
    .line 53
    iget-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v3, Landroid/content/Context;

    .line 56
    .line 57
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_0
    invoke-virtual {v8, v3, v12}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Z

    .line 61
    .line 62
    .line 63
    :cond_1
    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_9

    .line 68
    .line 69
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v12

    .line 73
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 74
    .line 75
    iget-object v2, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 76
    .line 77
    if-nez v2, :cond_2

    .line 78
    .line 79
    sget-object v2, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 80
    .line 81
    :cond_2
    sget-object v1, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->IN_APP:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 82
    .line 83
    if-ne v2, v1, :cond_1

    .line 84
    .line 85
    iget-object v1, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 86
    .line 87
    if-nez v1, :cond_0

    .line 88
    .line 89
    iget-object v1, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 90
    .line 91
    if-eqz v1, :cond_0

    .line 92
    .line 93
    sget-object v11, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;

    .line 94
    .line 95
    iget-object v1, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 96
    .line 97
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 98
    .line 99
    .line 100
    move-result-wide v1

    .line 101
    iput-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 102
    .line 103
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 104
    .line 105
    iput-object v9, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$2:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v12, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$3:Ljava/lang/Object;

    .line 108
    .line 109
    const/4 v10, 0x0

    .line 110
    iput-object v10, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$4:Ljava/lang/Object;

    .line 111
    .line 112
    iput-object v10, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$5:Ljava/lang/Object;

    .line 113
    .line 114
    iput v4, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 115
    .line 116
    invoke-virtual {v11, v3, v1, v2, v7}, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;->deleteEvent(Landroid/content/Context;JLX/2M4;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    if-ne v1, v6, :cond_4

    .line 121
    .line 122
    return-object v6

    .line 123
    :cond_3
    iget-object v12, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$3:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 126
    .line 127
    iget-object v9, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$2:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast v9, Ljava/util/Iterator;

    .line 130
    .line 131
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 134
    .line 135
    iget-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v3, Landroid/content/Context;

    .line 138
    .line 139
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    :cond_4
    const/16 p1, 0x3f3f

    .line 143
    .line 144
    const/4 v13, 0x0

    .line 145
    const/4 v15, 0x0

    .line 146
    const-wide/16 v18, 0x0

    .line 147
    .line 148
    move-object v14, v13

    .line 149
    move/from16 v16, v15

    .line 150
    .line 151
    move-object/from16 v17, v13

    .line 152
    .line 153
    move-object/from16 v20, v13

    .line 154
    .line 155
    move-object/from16 v21, v13

    .line 156
    .line 157
    move-object/from16 v22, v13

    .line 158
    .line 159
    move-wide/from16 v23, v18

    .line 160
    .line 161
    move/from16 v25, v15

    .line 162
    .line 163
    move/from16 v26, v15

    .line 164
    .line 165
    move-object/from16 v27, v13

    .line 166
    .line 167
    move-object/from16 p0, v13

    .line 168
    .line 169
    move-object/from16 p2, v13

    .line 170
    .line 171
    invoke-static/range {v12 .. v30}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 172
    .line 173
    .line 174
    move-result-object v12

    .line 175
    iput-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 176
    .line 177
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 178
    .line 179
    iput-object v9, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$2:Ljava/lang/Object;

    .line 180
    .line 181
    iput-object v13, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$3:Ljava/lang/Object;

    .line 182
    .line 183
    iput-object v12, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$4:Ljava/lang/Object;

    .line 184
    .line 185
    iput-object v13, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$5:Ljava/lang/Object;

    .line 186
    .line 187
    iput v5, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 188
    .line 189
    invoke-virtual {v0, v12, v7}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    if-ne v1, v6, :cond_0

    .line 194
    .line 195
    return-object v6

    .line 196
    :cond_5
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 197
    .line 198
    .line 199
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 200
    .line 201
    invoke-virtual {v0, v3}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    iput-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 206
    .line 207
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 208
    .line 209
    iput v1, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->label:I

    .line 210
    .line 211
    invoke-virtual {v0, v7}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    if-ne v2, v6, :cond_7

    .line 216
    .line 217
    return-object v6

    .line 218
    :cond_6
    iget-object v0, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 221
    .line 222
    iget-object v3, v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast v3, Landroid/content/Context;

    .line 225
    .line 226
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :cond_7
    check-cast v2, Ljava/util/List;

    .line 230
    .line 231
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 232
    .line 233
    .line 234
    move-result-object v9

    .line 235
    goto/16 :goto_1

    .line 236
    .line 237
    :cond_8
    new-instance v7, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;

    .line 238
    .line 239
    invoke-direct {v7, v8, v4}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler$reregisterAll$1;-><init>(Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;LX/2M4;)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_0

    .line 243
    .line 244
    :cond_9
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 245
    .line 246
    return-object v6

    .line 247
    :cond_a
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    throw v0
.end method

.method public final schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;)Z
    .locals 13

    .line 0
    const-string v5, " at "

    .line 1
    .line 2
    const-string v4, "Scheduled inexact reminder "

    .line 3
    .line 4
    const-string v10, "Scheduled exact reminder "

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {p1, p2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v9

    .line 11
    const-string v0, "alarm"

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    instance-of v0, v2, Landroid/app/AlarmManager;

    .line 18
    .line 19
    const/4 v11, 0x0

    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    check-cast v2, Landroid/app/AlarmManager;

    .line 23
    .line 24
    :goto_0
    const/4 v12, 0x0

    .line 25
    const-string v3, "HatchReminderScheduler"

    .line 26
    .line 27
    if-nez v2, :cond_1

    .line 28
    .line 29
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 30
    .line 31
    const-string v0, "AlarmManager unavailable; cannot schedule reminder "

    .line 32
    .line 33
    invoke-static {v0, v1, v3}, LX/602;->A1J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    return v6

    .line 37
    :cond_1
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 38
    .line 39
    invoke-direct {p0, p1, v0, v9}, Lcom/facebook/aura/commands/alarm/HatchReminderScheduler;->broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    if-eqz v7, :cond_0

    .line 44
    .line 45
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 54
    .line 55
    .line 56
    move-result-object v8

    .line 57
    if-eqz v8, :cond_3

    .line 58
    .line 59
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    const/high16 v0, 0xc000000

    .line 66
    .line 67
    invoke-static {p1, v1, v8, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 68
    .line 69
    .line 70
    move-result-object v11

    .line 71
    goto :goto_1

    .line 72
    :cond_2
    move-object v2, v11

    .line 73
    goto :goto_0

    .line 74
    :cond_3
    :goto_1
    :try_start_0
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 75
    .line 76
    new-instance v8, Landroid/app/AlarmManager$AlarmClockInfo;

    .line 77
    .line 78
    invoke-direct {v8, v0, v1, v11}, Landroid/app/AlarmManager$AlarmClockInfo;-><init>(JLandroid/app/PendingIntent;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2, v8, v7}, Landroid/app/AlarmManager;->setAlarmClock(Landroid/app/AlarmManager$AlarmClockInfo;Landroid/app/PendingIntent;)V

    .line 82
    .line 83
    .line 84
    iget-object v8, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 85
    .line 86
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 87
    .line 88
    invoke-static {v10, v8, v5, v0, v1}, LX/Gi8;->A0s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-static {v3, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    return v9
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 96
    :catch_0
    move-exception v9

    .line 97
    iget-object v8, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 98
    .line 99
    const-string v1, "setAlarmClock rejected for reminder "

    .line 100
    .line 101
    const-string v0, "; falling back to inexact set()"

    .line 102
    .line 103
    invoke-static {v1, v8, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-static {v3, v0, v9}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 108
    .line 109
    .line 110
    :try_start_1
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 111
    .line 112
    invoke-virtual {v2, v6, v0, v1, v7}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    .line 113
    .line 114
    .line 115
    iget-object v2, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 116
    .line 117
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 118
    .line 119
    invoke-static {v4, v2, v5, v0, v1}, LX/Gi8;->A0s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-static {v3, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    const/4 v12, 0x1

    .line 127
    return v12
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .line 128
    :catch_1
    move-exception v2

    .line 129
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 130
    .line 131
    const-string v0, "Failed to schedule reminder "

    .line 132
    .line 133
    invoke-static {v0, v1, v3, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 134
    .line 135
    .line 136
    return v12
.end method
