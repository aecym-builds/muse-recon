.class public final Lcom/facebook/aura/commands/alarm/ReminderCalendar;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final add(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;JLX/2M4;)Ljava/lang/Object;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p5

    .line 1
    .line 2
    move-wide/from16 v13, p3

    .line 3
    .line 4
    move-object/from16 v10, p2

    .line 5
    .line 6
    instance-of v0, v4, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;

    .line 7
    .line 8
    if-eqz v0, :cond_9

    .line 9
    .line 10
    move-object v3, v4

    .line 11
    check-cast v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;

    .line 12
    .line 13
    iget v2, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v2, v1

    .line 18
    .line 19
    if-eqz v0, :cond_9

    .line 20
    .line 21
    sub-int/2addr v2, v1

    .line 22
    iput v2, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v7, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v0, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 29
    .line 30
    const/4 v6, 0x3

    .line 31
    const/4 v4, 0x2

    .line 32
    const/4 v5, 0x1

    .line 33
    const/4 v11, 0x0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    if-eq v0, v5, :cond_4

    .line 37
    .line 38
    if-eq v0, v4, :cond_7

    .line 39
    .line 40
    if-ne v0, v6, :cond_a

    .line 41
    .line 42
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_0
    return-object v11

    .line 46
    :cond_1
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    sget-object v0, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 50
    .line 51
    move-object/from16 v1, p1

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 54
    .line 55
    .line 56
    move-result-object v12

    .line 57
    invoke-virtual {v10}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 58
    .line 59
    .line 60
    move-result-object v8

    .line 61
    iget-object v15, v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;->label:Ljava/lang/String;

    .line 62
    .line 63
    iget-wide v0, v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;->triggerTimeMs:J

    .line 64
    .line 65
    if-nez v8, :cond_3

    .line 66
    .line 67
    invoke-static {v0, v1}, LX/602;->A0W(J)Ljava/lang/Long;

    .line 68
    .line 69
    .line 70
    move-result-object v18

    .line 71
    :goto_1
    invoke-virtual {v10}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->zoneId()Ljava/time/ZoneId;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    invoke-virtual {v7}, Ljava/time/ZoneId;->getId()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v22

    .line 79
    if-eqz v8, :cond_2

    .line 80
    .line 81
    invoke-virtual {v8}, Lcom/facebook/aura/commands/alarm/Recurrence;->toRrule()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    const-string p1, "PT0S"

    .line 86
    .line 87
    :goto_2
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$0:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v10, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$1:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v12, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$2:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$3:Ljava/lang/Object;

    .line 94
    .line 95
    iput-wide v13, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$0:J

    .line 96
    .line 97
    iput v5, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 98
    .line 99
    const/16 v19, 0x0

    .line 100
    .line 101
    move-object/from16 v20, v11

    .line 102
    .line 103
    move-object/from16 v21, v11

    .line 104
    .line 105
    move-object/from16 p2, v3

    .line 106
    .line 107
    move-wide/from16 v16, v0

    .line 108
    .line 109
    invoke-virtual/range {v12 .. v25}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->createEvent(JLjava/lang/String;JLjava/lang/Long;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    if-ne v7, v2, :cond_5

    .line 114
    .line 115
    return-object v2

    .line 116
    :cond_2
    move-object/from16 p0, v11

    .line 117
    .line 118
    move-object/from16 p1, v11

    .line 119
    .line 120
    goto :goto_2

    .line 121
    :cond_3
    move-object/from16 v18, v11

    .line 122
    .line 123
    goto :goto_1

    .line 124
    :cond_4
    iget-wide v13, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$0:J

    .line 125
    .line 126
    iget-object v12, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$2:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v12, Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 129
    .line 130
    iget-object v10, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$1:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 133
    .line 134
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :cond_5
    invoke-static {v7}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 138
    .line 139
    .line 140
    move-result-wide v0

    .line 141
    const-wide/16 v8, 0x0

    .line 142
    .line 143
    cmp-long v7, v0, v8

    .line 144
    .line 145
    if-gez v7, :cond_6

    .line 146
    .line 147
    return-object v11

    .line 148
    :cond_6
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$0:Ljava/lang/Object;

    .line 149
    .line 150
    iput-object v10, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$1:Ljava/lang/Object;

    .line 151
    .line 152
    iput-object v12, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$2:Ljava/lang/Object;

    .line 153
    .line 154
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$3:Ljava/lang/Object;

    .line 155
    .line 156
    iput-wide v13, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$0:J

    .line 157
    .line 158
    iput-wide v0, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$1:J

    .line 159
    .line 160
    iput v4, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 161
    .line 162
    const/16 v18, 0x0

    .line 163
    .line 164
    sget-object v4, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 165
    .line 166
    move-object v15, v12

    .line 167
    move-wide/from16 v16, v0

    .line 168
    .line 169
    move/from16 v19, v5

    .line 170
    .line 171
    move/from16 v20, v5

    .line 172
    .line 173
    move-object/from16 v21, v3

    .line 174
    .line 175
    invoke-virtual/range {v15 .. v21}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->setReminder(JIIZLX/2M4;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v7

    .line 179
    if-ne v7, v2, :cond_8

    .line 180
    .line 181
    return-object v2

    .line 182
    :cond_7
    iget-wide v0, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$1:J

    .line 183
    .line 184
    iget-wide v13, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$0:J

    .line 185
    .line 186
    iget-object v12, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$2:Ljava/lang/Object;

    .line 187
    .line 188
    check-cast v12, Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 189
    .line 190
    iget-object v10, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$1:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 193
    .line 194
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    :cond_8
    if-nez v7, :cond_b

    .line 198
    .line 199
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$0:Ljava/lang/Object;

    .line 200
    .line 201
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$1:Ljava/lang/Object;

    .line 202
    .line 203
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$2:Ljava/lang/Object;

    .line 204
    .line 205
    iput-object v11, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->L$3:Ljava/lang/Object;

    .line 206
    .line 207
    iput-wide v13, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$0:J

    .line 208
    .line 209
    iput-wide v0, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->J$1:J

    .line 210
    .line 211
    iput v6, v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 212
    .line 213
    invoke-virtual {v12, v0, v1, v3}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->deleteEvent(JLX/2M4;)Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    if-ne v0, v2, :cond_0

    .line 218
    .line 219
    return-object v2

    .line 220
    :cond_9
    new-instance v3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;

    .line 221
    .line 222
    move-object/from16 v0, p0

    .line 223
    .line 224
    invoke-direct {v3, v0, v4}, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;-><init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V

    .line 225
    .line 226
    .line 227
    goto/16 :goto_0

    .line 228
    .line 229
    :cond_a
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    throw v0

    .line 234
    :cond_b
    iget-object v4, v10, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 235
    .line 236
    const-string v3, "Reminder "

    .line 237
    .line 238
    const-string v2, " saved as calendar event "

    .line 239
    .line 240
    invoke-static {v3, v4, v2, v0, v1}, LX/Gi8;->A0s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v3

    .line 244
    const-string v2, "ReminderCalendar"

    .line 245
    .line 246
    invoke-static {v2, v3}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    sget-object p3, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->CALENDAR:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 250
    .line 251
    invoke-static {v0, v1}, LX/602;->A0W(J)Ljava/lang/Long;

    .line 252
    .line 253
    .line 254
    move-result-object v18

    .line 255
    invoke-static {v13, v14}, LX/602;->A0W(J)Ljava/lang/Long;

    .line 256
    .line 257
    .line 258
    move-result-object v19

    .line 259
    const/16 p4, 0x1f3f

    .line 260
    .line 261
    const/4 v13, 0x0

    .line 262
    const-wide/16 v16, 0x0

    .line 263
    .line 264
    move-object v12, v11

    .line 265
    move v14, v13

    .line 266
    move-object v15, v11

    .line 267
    move-object/from16 v20, v11

    .line 268
    .line 269
    move-wide/from16 v21, v16

    .line 270
    .line 271
    move/from16 p0, v13

    .line 272
    .line 273
    move/from16 p1, v13

    .line 274
    .line 275
    move-object/from16 p2, v11

    .line 276
    .line 277
    move-object/from16 p5, v11

    .line 278
    .line 279
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/commands/alarm/ShadowReminder;->copy$default(Lcom/facebook/aura/commands/alarm/ShadowReminder;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;JLjava/lang/Long;Ljava/lang/Long;Lcom/facebook/aura/commands/alarm/Recurrence;JIZLjava/lang/String;Lcom/facebook/aura/commands/alarm/ReminderDelivery;ILjava/lang/Object;)Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    return-object v0
.end method

.method public final hasAccess(Landroid/content/Context;)Z
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {p1, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    const/4 p0, 0x1

    .line 27
    :cond_0
    return p0
.end method

.method public final hasCalendarApp(Landroid/content/Context;)Z
    .locals 5

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    new-instance v3, Landroid/content/Intent;

    .line 14
    .line 15
    invoke-direct {v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    sget-object v2, Landroid/provider/CalendarContract$Events;->CONTENT_URI:Landroid/net/Uri;

    .line 19
    .line 20
    const-wide/16 v0, 0x0

    .line 21
    .line 22
    invoke-static {v2, v0, v1}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const-string v0, "vnd.android.cursor.item/event"

    .line 27
    .line 28
    invoke-virtual {v3, v1, v0}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v4, v0, p0}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    xor-int/lit8 v0, v0, 0x1

    .line 44
    .line 45
    return v0
.end method

.method public final pruneFinished(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    move-object v0, p2

    .line 3
    instance-of v1, v4, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;

    .line 4
    .line 5
    if-eqz v1, :cond_a

    .line 6
    .line 7
    move-object v9, v4

    .line 8
    check-cast v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;

    .line 9
    .line 10
    iget v3, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 11
    .line 12
    const/high16 v2, -0x80000000

    .line 13
    .line 14
    and-int v1, v3, v2

    .line 15
    .line 16
    if-eqz v1, :cond_a

    .line 17
    .line 18
    sub-int/2addr v3, v2

    .line 19
    iput v3, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 20
    .line 21
    :goto_0
    iget-object v10, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->result:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 24
    .line 25
    iget v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    const/4 v7, 0x2

    .line 29
    const/4 v6, 0x1

    .line 30
    if-eqz v2, :cond_7

    .line 31
    .line 32
    if-eq v2, v6, :cond_8

    .line 33
    .line 34
    if-eq v2, v7, :cond_1

    .line 35
    .line 36
    if-ne v2, v1, :cond_c

    .line 37
    .line 38
    iget-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 39
    .line 40
    iget-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 41
    .line 42
    iget-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$3:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v11, Ljava/util/Iterator;

    .line 45
    .line 46
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v1, Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 49
    .line 50
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 53
    .line 54
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_0
    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    if-eqz v5, :cond_b

    .line 62
    .line 63
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v12

    .line 67
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 68
    .line 69
    iget-object v6, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->delivery:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 70
    .line 71
    sget-object v5, Lcom/facebook/aura/commands/alarm/ReminderDelivery;->CALENDAR:Lcom/facebook/aura/commands/alarm/ReminderDelivery;

    .line 72
    .line 73
    if-ne v6, v5, :cond_0

    .line 74
    .line 75
    invoke-static {v12, v2, v3}, Lcom/facebook/aura/commands/alarm/ReminderCalendarKt;->nextOccurrence(Lcom/facebook/aura/commands/alarm/ShadowReminder;J)J

    .line 76
    .line 77
    .line 78
    move-result-wide p2

    .line 79
    const-wide/16 p0, -0x1

    .line 80
    .line 81
    cmp-long v5, p2, p0

    .line 82
    .line 83
    if-eqz v5, :cond_5

    .line 84
    .line 85
    if-eqz v4, :cond_6

    .line 86
    .line 87
    :try_start_0
    iget-object v5, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 88
    .line 89
    if-eqz v5, :cond_2

    .line 90
    .line 91
    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    .line 92
    .line 93
    .line 94
    move-result-wide v5

    .line 95
    const/4 v10, 0x0

    .line 96
    iput-object v10, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$0:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$3:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v12, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$4:Ljava/lang/Object;

    .line 105
    .line 106
    iput-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 107
    .line 108
    iput-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 109
    .line 110
    iput-wide v5, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$1:J

    .line 111
    .line 112
    iput v7, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 113
    .line 114
    invoke-virtual {v1, v5, v6, v9}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->getEventById(JLX/2M4;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    if-ne v10, v8, :cond_3

    .line 119
    .line 120
    goto/16 :goto_4
    :try_end_0
    .catch Ljava/lang/NoSuchMethodError; {:try_start_0 .. :try_end_0} :catch_0

    .line 121
    .line 122
    :cond_1
    iget-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 123
    .line 124
    iget-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 125
    .line 126
    iget-object v12, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$4:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 129
    .line 130
    iget-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$3:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v11, Ljava/util/Iterator;

    .line 133
    .line 134
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v1, Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 137
    .line 138
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 141
    .line 142
    :try_start_1
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    goto :goto_2

    .line 146
    :cond_2
    const/4 v10, 0x0

    .line 147
    :cond_3
    :goto_2
    const/4 v5, 0x1

    .line 148
    if-eqz v10, :cond_4
    :try_end_1
    .catch Ljava/lang/NoSuchMethodError; {:try_start_1 .. :try_end_1} :catch_0

    .line 149
    .line 150
    :catch_0
    const/4 v5, 0x0

    .line 151
    :cond_4
    if-eqz v5, :cond_6

    .line 152
    .line 153
    :cond_5
    const/4 v10, 0x1

    .line 154
    :goto_3
    if-eqz v10, :cond_0

    .line 155
    .line 156
    iget-object v6, v12, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 157
    .line 158
    const/4 v5, 0x0

    .line 159
    iput-object v5, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$0:Ljava/lang/Object;

    .line 160
    .line 161
    iput-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 162
    .line 163
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 164
    .line 165
    iput-object v11, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$3:Ljava/lang/Object;

    .line 166
    .line 167
    iput-object v5, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$4:Ljava/lang/Object;

    .line 168
    .line 169
    iput-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 170
    .line 171
    iput-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 172
    .line 173
    iput v10, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->I$0:I

    .line 174
    .line 175
    const/4 v5, 0x3

    .line 176
    iput v5, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 177
    .line 178
    invoke-virtual {v0, v6, v9}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v5

    .line 182
    if-ne v5, v8, :cond_0

    .line 183
    .line 184
    return-object v8

    .line 185
    :cond_6
    const/4 v10, 0x0

    .line 186
    goto :goto_3

    .line 187
    :cond_7
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 191
    .line 192
    .line 193
    move-result-wide v2

    .line 194
    invoke-virtual {p0, p1}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->hasAccess(Landroid/content/Context;)Z

    .line 195
    .line 196
    .line 197
    move-result v4

    .line 198
    sget-object v1, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 199
    .line 200
    invoke-virtual {v1, p1}, Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    const/4 v5, 0x0

    .line 205
    iput-object v5, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$0:Ljava/lang/Object;

    .line 206
    .line 207
    iput-object p2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 208
    .line 209
    iput-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 210
    .line 211
    iput-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 212
    .line 213
    iput-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 214
    .line 215
    iput v6, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->label:I

    .line 216
    .line 217
    invoke-virtual {p2, v9}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v10

    .line 221
    if-ne v10, v8, :cond_9

    .line 222
    .line 223
    return-object v8

    .line 224
    :cond_8
    iget-boolean v4, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->Z$0:Z

    .line 225
    .line 226
    iget-wide v2, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->J$0:J

    .line 227
    .line 228
    iget-object v1, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$2:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v1, Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 231
    .line 232
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;->L$1:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 235
    .line 236
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    :cond_9
    check-cast v10, Ljava/util/List;

    .line 240
    .line 241
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 242
    .line 243
    .line 244
    move-result-object v11

    .line 245
    goto/16 :goto_1

    .line 246
    .line 247
    :cond_a
    new-instance v9, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;

    .line 248
    .line 249
    invoke-direct {v9, p0, v4}, Lcom/facebook/aura/commands/alarm/ReminderCalendar$pruneFinished$1;-><init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V

    .line 250
    .line 251
    .line 252
    goto/16 :goto_0

    .line 253
    .line 254
    :goto_4
    return-object v8

    .line 255
    :cond_b
    sget-object v8, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 256
    .line 257
    return-object v8

    .line 258
    :cond_c
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    throw v0
.end method

.method public final remove(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v6, p3

    .line 5
    check-cast v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v4, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v5

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 43
    .line 44
    .line 45
    move-result-wide v2

    .line 46
    sget-object v0, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 47
    .line 48
    invoke-virtual {v0, p1}, Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const/4 v0, 0x0

    .line 53
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->L$0:Ljava/lang/Object;

    .line 54
    .line 55
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->L$1:Ljava/lang/Object;

    .line 56
    .line 57
    iput-wide v2, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->J$0:J

    .line 58
    .line 59
    iput v4, v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;->label:I

    .line 60
    .line 61
    invoke-virtual {v1, v2, v3, v6}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->deleteEvent(JLX/2M4;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    if-ne v0, v5, :cond_0

    .line 66
    .line 67
    return-object v5

    .line 68
    :cond_2
    new-instance v6, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;

    .line 69
    .line 70
    invoke-direct {v6, p0, p3}, Lcom/facebook/aura/commands/alarm/ReminderCalendar$remove$1;-><init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V

    .line 71
    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    throw v0
.end method

.method public final replace(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v8, p1

    .line 1
    move-object v3, p3

    .line 2
    move-object v9, p2

    .line 3
    instance-of v0, p3, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;

    .line 4
    .line 5
    move-object v7, p0

    .line 6
    if-eqz v0, :cond_5

    .line 7
    .line 8
    move-object p2, v3

    .line 9
    check-cast p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;

    .line 10
    .line 11
    iget v2, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_5

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v6, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->label:I

    .line 27
    .line 28
    const/4 v4, 0x0

    .line 29
    const/4 v3, 0x2

    .line 30
    const/4 v1, 0x1

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    if-eq v0, v1, :cond_3

    .line 34
    .line 35
    if-ne v0, v3, :cond_6

    .line 36
    .line 37
    iget-object v4, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$2:Ljava/lang/Object;

    .line 38
    .line 39
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_0
    return-object v4

    .line 43
    :cond_1
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ShadowReminder;->calendarId:Ljava/lang/Long;

    .line 47
    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 51
    .line 52
    .line 53
    move-result-wide p0

    .line 54
    iput-object v8, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$0:Ljava/lang/Object;

    .line 55
    .line 56
    iput-object v9, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$1:Ljava/lang/Object;

    .line 57
    .line 58
    iput-wide p0, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->J$0:J

    .line 59
    .line 60
    iput v1, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->label:I

    .line 61
    .line 62
    invoke-virtual/range {v7 .. v12}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->add(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;JLX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    if-ne v6, v5, :cond_4

    .line 67
    .line 68
    :cond_2
    return-object v5

    .line 69
    :cond_3
    iget-wide p0, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->J$0:J

    .line 70
    .line 71
    iget-object v9, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$1:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v9, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 74
    .line 75
    iget-object v8, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$0:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v8, Landroid/content/Context;

    .line 78
    .line 79
    invoke-static {v6}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_4
    if-eqz v6, :cond_0

    .line 83
    .line 84
    iget-object v0, v9, Lcom/facebook/aura/commands/alarm/ShadowReminder;->eventId:Ljava/lang/Long;

    .line 85
    .line 86
    if-eqz v0, :cond_7

    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 89
    .line 90
    .line 91
    move-result-wide v1

    .line 92
    sget-object v0, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 93
    .line 94
    invoke-virtual {v0, v8}, Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    iput-object v4, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$0:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v4, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v6, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->L$2:Ljava/lang/Object;

    .line 103
    .line 104
    iput-wide p0, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->J$0:J

    .line 105
    .line 106
    iput-wide v1, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->J$1:J

    .line 107
    .line 108
    iput v3, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;->label:I

    .line 109
    .line 110
    invoke-virtual {v0, v1, v2, p2}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->deleteEvent(JLX/2M4;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    if-eq v0, v5, :cond_2

    .line 115
    .line 116
    return-object v6

    .line 117
    :cond_5
    new-instance p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;

    .line 118
    .line 119
    invoke-direct {p2, p0, p3}, Lcom/facebook/aura/commands/alarm/ReminderCalendar$replace$1;-><init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V

    .line 120
    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    throw v0

    .line 128
    :cond_7
    return-object v6
.end method

.method public final targetCalendarId(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_4

    .line 29
    .line 30
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    check-cast v4, Lcom/facebook/aura/commands/calendar/CalendarRepository$CalendarInfo;

    .line 34
    .line 35
    if-eqz v4, :cond_1

    .line 36
    .line 37
    iget-wide v0, v4, Lcom/facebook/aura/commands/calendar/CalendarRepository$CalendarInfo;->id:J

    .line 38
    .line 39
    invoke-static {v0, v1}, LX/602;->A0W(J)Ljava/lang/Long;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    :cond_1
    return-object v2

    .line 44
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, p1}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->hasAccess(Landroid/content/Context;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    sget-object v0, Lcom/facebook/aura/commands/calendar/CalendarRepository;->Companion:Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;

    .line 54
    .line 55
    invoke-virtual {v0, p1}, Lcom/facebook/aura/commands/calendar/CalendarRepository$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/calendar/CalendarRepository;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->L$0:Ljava/lang/Object;

    .line 60
    .line 61
    iput v1, v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;->label:I

    .line 62
    .line 63
    invoke-virtual {v0, v5}, Lcom/facebook/aura/commands/calendar/CalendarRepository;->getDefaultWritableCalendar(LX/2M4;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    if-ne v4, v3, :cond_0

    .line 68
    .line 69
    return-object v3

    .line 70
    :cond_3
    new-instance v5, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;

    .line 71
    .line 72
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/commands/alarm/ReminderCalendar$targetCalendarId$1;-><init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    throw v0
.end method
