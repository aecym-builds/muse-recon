.class public final Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.ReminderHandlersKt"
    f = "ReminderHandlers.kt"
    l = {
        0x1be,
        0x1c0
    }
    m = "removeReminder"
    v = 0x2
.end annotation


# instance fields
.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1}, LX/Btl;-><init>(LX/2M4;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt$removeReminder$1;->label:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-static {v0, v0, v0, p0}, Lcom/facebook/aura/commands/alarm/ReminderHandlersKt;->removeReminder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method
