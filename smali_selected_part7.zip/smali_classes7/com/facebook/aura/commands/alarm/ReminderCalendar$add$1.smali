.class public final Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.ReminderCalendar"
    f = "ReminderCalendar.kt"
    l = {
        0x30,
        0x3a,
        0x3b
    }
    m = "add"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public J$1:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/commands/alarm/ReminderCalendar;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/commands/alarm/ReminderCalendar;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/commands/alarm/ReminderCalendar;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->this$0:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ReminderCalendar$add$1;->this$0:Lcom/facebook/aura/commands/alarm/ReminderCalendar;

    .line 10
    .line 11
    const-wide/16 v3, 0x0

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    move-object v2, v1

    .line 15
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/commands/alarm/ReminderCalendar;->add(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowReminder;JLX/2M4;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
