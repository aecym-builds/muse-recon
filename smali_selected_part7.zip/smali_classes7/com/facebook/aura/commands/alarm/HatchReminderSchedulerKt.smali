.class public abstract Lcom/facebook/aura/commands/alarm/HatchReminderSchedulerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchReminderScheduler"
