.class public final Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->instance:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 5
    .line 6
    if-nez v1, :cond_1

    .line 7
    .line 8
    monitor-enter p0

    .line 9
    :try_start_0
    sget-object v1, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->instance:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const-string v0, "aura_alarm_shadow"

    .line 18
    .line 19
    invoke-virtual {v1, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    new-instance v1, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 27
    .line 28
    invoke-direct {v1, v0}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;-><init>(Landroid/content/SharedPreferences;)V

    .line 29
    .line 30
    .line 31
    sput-object v1, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->instance:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 32
    .line 33
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    :catchall_0
    move-exception v0

    .line 35
    monitor-exit p0

    .line 36
    throw v0

    .line 37
    :cond_0
    :goto_0
    monitor-exit p0

    .line 38
    :cond_1
    return-object v1
.end method
