.class public final Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;
    .locals 2

    .line 0
    const-class v0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver;

    .line 1
    .line 2
    new-instance p0, Landroid/content/Intent;

    .line 3
    .line 4
    invoke-direct {p0, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 5
    .line 6
    .line 7
    const-string v0, "com.facebook.aura.ALARM_FIRE"

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 10
    .line 11
    .line 12
    const-string v0, "alarm_id"

    .line 13
    .line 14
    invoke-virtual {p0, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 15
    .line 16
    .line 17
    const/high16 v1, 0x24000000

    .line 18
    .line 19
    if-eqz p3, :cond_0

    .line 20
    .line 21
    const/high16 v1, 0xc000000

    .line 22
    .line 23
    :cond_0
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {p1, v0, p0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method


# virtual methods
.method public final cancel(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    const-string v0, "alarm"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    instance-of v0, v1, Landroid/app/AlarmManager;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    check-cast v1, Landroid/app/AlarmManager;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    invoke-direct {p0, p1, p2, v2}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/app/PendingIntent;->cancel()V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method public final reregisterAll(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v2, :cond_5

    .line 28
    .line 29
    iget-object p1, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Landroid/content/Context;

    .line 32
    .line 33
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v1, Ljava/util/List;

    .line 37
    .line 38
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    :cond_1
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_4

    .line 47
    .line 48
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 53
    .line 54
    iget-boolean v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 55
    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    invoke-virtual {p0, p1, v1}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Z

    .line 59
    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 66
    .line 67
    invoke-virtual {v0, p1}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    iput-object p1, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->L$0:Ljava/lang/Object;

    .line 72
    .line 73
    const/4 v0, 0x0

    .line 74
    iput-object v0, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->L$1:Ljava/lang/Object;

    .line 75
    .line 76
    iput v2, v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;->label:I

    .line 77
    .line 78
    invoke-virtual {v1, v4}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    if-ne v1, v3, :cond_0

    .line 83
    .line 84
    return-object v3

    .line 85
    :cond_3
    new-instance v4, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;

    .line 86
    .line 87
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler$reregisterAll$1;-><init>(Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;LX/2M4;)V

    .line 88
    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_4
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 92
    .line 93
    return-object v3

    .line 94
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    throw v0
.end method

.method public final schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Z
    .locals 13

    .line 0
    const-string v5, " at "

    .line 1
    .line 2
    const-string v4, "Scheduled inexact alarm "

    .line 3
    .line 4
    const-string v10, "Scheduled exact alarm "

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    invoke-static {p1, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const-string v0, "alarm"

    .line 11
    .line 12
    const/4 v9, 0x1

    .line 13
    invoke-static {p2, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    instance-of v0, v2, Landroid/app/AlarmManager;

    .line 21
    .line 22
    const/4 v11, 0x0

    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    check-cast v2, Landroid/app/AlarmManager;

    .line 26
    .line 27
    :goto_0
    const/4 v12, 0x0

    .line 28
    const-string v3, "HatchAlarmScheduler"

    .line 29
    .line 30
    if-nez v2, :cond_1

    .line 31
    .line 32
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 33
    .line 34
    const-string v0, "AlarmManager unavailable; cannot schedule alarm "

    .line 35
    .line 36
    invoke-static {v0, v1, v3}, LX/602;->A1J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    return v6

    .line 40
    :cond_1
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 41
    .line 42
    invoke-direct {p0, p1, v0, v9}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->broadcastIntent(Landroid/content/Context;Ljava/lang/String;Z)Landroid/app/PendingIntent;

    .line 43
    .line 44
    .line 45
    move-result-object v7

    .line 46
    if-eqz v7, :cond_0

    .line 47
    .line 48
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    if-eqz v8, :cond_3

    .line 61
    .line 62
    iget-object v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    const/high16 v0, 0xc000000

    .line 69
    .line 70
    invoke-static {p1, v1, v8, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 71
    .line 72
    .line 73
    move-result-object v11

    .line 74
    goto :goto_1

    .line 75
    :cond_2
    move-object v2, v11

    .line 76
    goto :goto_0

    .line 77
    :cond_3
    :goto_1
    :try_start_0
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 78
    .line 79
    new-instance v8, Landroid/app/AlarmManager$AlarmClockInfo;

    .line 80
    .line 81
    invoke-direct {v8, v0, v1, v11}, Landroid/app/AlarmManager$AlarmClockInfo;-><init>(JLandroid/app/PendingIntent;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v2, v8, v7}, Landroid/app/AlarmManager;->setAlarmClock(Landroid/app/AlarmManager$AlarmClockInfo;Landroid/app/PendingIntent;)V

    .line 85
    .line 86
    .line 87
    iget-object v8, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 88
    .line 89
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 90
    .line 91
    invoke-static {v10, v8, v5, v0, v1}, LX/Gi8;->A0s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {v3, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    return v9
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 99
    :catch_0
    move-exception v9

    .line 100
    iget-object v8, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 101
    .line 102
    const-string v1, "setAlarmClock rejected for alarm "

    .line 103
    .line 104
    const-string v0, "; falling back to inexact set()"

    .line 105
    .line 106
    invoke-static {v1, v8, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v3, v0, v9}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 111
    .line 112
    .line 113
    :try_start_1
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 114
    .line 115
    invoke-virtual {v2, v6, v0, v1, v7}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    .line 116
    .line 117
    .line 118
    iget-object v2, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 119
    .line 120
    iget-wide v0, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 121
    .line 122
    invoke-static {v4, v2, v5, v0, v1}, LX/Gi8;->A0s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-static {v3, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    const/4 v12, 0x1

    .line 130
    return v12
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .line 131
    :catch_1
    move-exception v2

    .line 132
    iget-object v1, p2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 133
    .line 134
    const-string v0, "Failed to schedule alarm "

    .line 135
    .line 136
    invoke-static {v0, v1, v3, v2}, LX/8mk;->A1M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 137
    .line 138
    .line 139
    return v12
.end method
