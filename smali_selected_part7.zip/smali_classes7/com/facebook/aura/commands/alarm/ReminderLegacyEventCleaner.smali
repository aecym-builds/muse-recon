.class public final Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;->INSTANCE:Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final deleteEvent(Landroid/content/Context;JLX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "J",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const/4 v1, 0x0

    .line 5
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner$deleteEvent$2;

    .line 6
    .line 7
    invoke-direct {v0, p2, p3, p1, v1}, Lcom/facebook/aura/commands/alarm/ReminderLegacyEventCleaner$deleteEvent$2;-><init>(JLandroid/content/Context;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    invoke-static {p4, p0, v0}, LX/8ml;->A0J(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method
