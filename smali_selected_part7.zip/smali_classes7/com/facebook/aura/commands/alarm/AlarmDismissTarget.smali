.class public final Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final alarmId:Ljava/lang/String;

.field public final messageLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->alarmId:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->messageLabel:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getAlarmId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->alarmId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMessageLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->messageLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
