.class public final Lcom/facebook/aura/commands/alarm/AlarmFireReceiver;
.super Landroid/content/BroadcastReceiver;
.source ""


# static fields
.field public static final ACTION_ALARM_DISMISS:Ljava/lang/String; = "com.facebook.aura.ALARM_DISMISS"

.field public static final ACTION_ALARM_FIRE:Ljava/lang/String; = "com.facebook.aura.ALARM_FIRE"

.field public static final Companion:Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$Companion;

.field public static final EXTRA_ALARM_ID:Ljava/lang/String; = "alarm_id"

.field public static final TAG:Ljava/lang/String; = "AlarmFireReceiver"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver;->Companion:Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v2

    .line 7
    const-string v0, "com.facebook.aura.ALARM_FIRE"

    .line 8
    .line 9
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const-string v1, "com.facebook.aura.ALARM_DISMISS"

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    const-string v0, "alarm_id"

    .line 25
    .line 26
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    if-eqz p2, :cond_2

    .line 31
    .line 32
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    sget-object v0, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;

    .line 49
    .line 50
    invoke-static {p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0, p1, p2}, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->cancel$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_1
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    const/4 v2, 0x0

    .line 66
    invoke-static {v0, v2}, LX/8mk;->A14(LX/BqD;LX/Cbu;)LX/EQC;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;

    .line 71
    .line 72
    invoke-direct {v0, p1, p2, p0, v2}, Lcom/facebook/aura/commands/alarm/AlarmFireReceiver$onReceive$1;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;LX/2M4;)V

    .line 73
    .line 74
    .line 75
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_2
    const-string v1, "Alarm "

    .line 80
    .line 81
    const-string v0, " with no id"

    .line 82
    .line 83
    invoke-static {v1, v2, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    const-string v0, "AlarmFireReceiver"

    .line 88
    .line 89
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    return-void
.end method
