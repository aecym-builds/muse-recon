.class public abstract Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CLOCK_HANDOFF_IN_BACKGROUND_MESSAGE:Ljava/lang/String; = "No alarm was set: the app is in the background, and Android only lets it open the Clock app while it\'s on screen. Ask the user to open the app on this device and ask again."

.field public static final CLOCK_INTENT_HANDOFF_DELAY_MS:J = 0x3e8L

.field public static final CLOCK_ONLY_ALARMS_MESSAGE:Ljava/lang/String; = "This device can only set alarms in its Clock app: a time, optionally repeating on chosen weekdays (all seven for every day). It can\'t set a date, an interval such as every three days, or an end to the repeat."

.field public static final CLOCK_RETURN_TIMEOUT_MS:J = 0xbb8L

.field public static final MAX_ALARMS:I = 0x64

.field public static final PARAM_ALARMS:Ljava/lang/String; = "alarms"

.field public static final PARAM_ALARMS_JSON:Ljava/lang/String; = "alarms_json"

.field public static final PARAM_TARGETS:Ljava/lang/String; = "targets"

.field public static final PARAM_TARGETS_JSON:Ljava/lang/String; = "targets_json"

.field public static final PARAM_UPDATES:Ljava/lang/String; = "updates"

.field public static final PARAM_UPDATES_JSON:Ljava/lang/String; = "updates_json"

.field public static final TAG:Ljava/lang/String; = "AlarmHandlers"


# direct methods
.method public static final synthetic access$awaitClockHandoff(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->awaitClockHandoff(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeAlarmDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->computeAlarmDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeAlarmDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->computeAlarmDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeAlarmList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->computeAlarmList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeAlarmSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;JLX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->computeAlarmSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;JLX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$computeAlarmUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->computeAlarmUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$describeAlarm(Lcom/facebook/aura/commands/alarm/AlarmSetRequest;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->describeAlarm(Lcom/facebook/aura/commands/alarm/AlarmSetRequest;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$deviceHasClockApp(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->deviceHasClockApp(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$setAlarmsInOrder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;Ljava/util/List;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->setAlarmsInOrder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;Ljava/util/List;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final awaitClockHandoff(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLX/2M4;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/MuseActivityTracker;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ClockHandoffStop;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;

    .line 1
    .line 2
    if-eqz v0, :cond_4

    .line 3
    .line 4
    move-object v6, p4

    .line 5
    check-cast v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_4

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-eq v1, v0, :cond_2

    .line 29
    .line 30
    if-ne v1, v5, :cond_6

    .line 31
    .line 32
    iget-wide p2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->J$0:J

    .line 33
    .line 34
    iget-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p0, Landroid/content/Context;

    .line 37
    .line 38
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    invoke-static {v2}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    const/4 v3, 0x0

    .line 46
    if-nez v0, :cond_5

    .line 47
    .line 48
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 49
    .line 50
    .line 51
    move-result-wide v1

    .line 52
    cmp-long v0, v1, p2

    .line 53
    .line 54
    if-gez v0, :cond_7

    .line 55
    .line 56
    sget-object v0, Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;->INSTANCE:Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;

    .line 57
    .line 58
    invoke-virtual {v0, p0}, Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;->isDefaultAssistant(Landroid/content/Context;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-nez v0, :cond_5

    .line 63
    .line 64
    sget-object v0, Lcom/facebook/aura/commands/alarm/ClockHandoffStop;->LEFT_SCREEN:Lcom/facebook/aura/commands/alarm/ClockHandoffStop;

    .line 65
    .line 66
    return-object v0

    .line 67
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iput-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$0:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object p1, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$1:Ljava/lang/Object;

    .line 73
    .line 74
    iput-wide p2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->J$0:J

    .line 75
    .line 76
    iput v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 77
    .line 78
    const-wide/16 v0, 0x3e8

    .line 79
    .line 80
    invoke-static {v0, v1, v6}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    if-ne v0, v7, :cond_3

    .line 85
    .line 86
    return-object v7

    .line 87
    :cond_2
    iget-wide p2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->J$0:J

    .line 88
    .line 89
    iget-object p1, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$1:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast p1, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;

    .line 92
    .line 93
    iget-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$0:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast p0, Landroid/content/Context;

    .line 96
    .line 97
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 101
    .line 102
    .line 103
    move-result-wide v0

    .line 104
    sub-long v2, p2, v0

    .line 105
    .line 106
    const-wide/16 v8, 0x0

    .line 107
    .line 108
    cmp-long v0, v2, v8

    .line 109
    .line 110
    if-lez v0, :cond_7

    .line 111
    .line 112
    const-wide/16 v0, 0xbb8

    .line 113
    .line 114
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    .line 115
    .line 116
    .line 117
    move-result-wide v0

    .line 118
    iput-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$0:Ljava/lang/Object;

    .line 119
    .line 120
    const/4 v4, 0x0

    .line 121
    iput-object v4, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->L$1:Ljava/lang/Object;

    .line 122
    .line 123
    iput-wide p2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->J$0:J

    .line 124
    .line 125
    iput-wide v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->J$1:J

    .line 126
    .line 127
    iput v5, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 128
    .line 129
    invoke-virtual {p1, v0, v1, v6}, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;->awaitReturn(JLX/2M4;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    if-ne v2, v7, :cond_0

    .line 134
    .line 135
    return-object v7

    .line 136
    :cond_4
    new-instance v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;

    .line 137
    .line 138
    invoke-direct {v6, p4}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;-><init>(LX/2M4;)V

    .line 139
    .line 140
    .line 141
    goto :goto_0

    .line 142
    :cond_5
    return-object v3

    .line 143
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    throw v0

    .line 148
    :cond_7
    sget-object v0, Lcom/facebook/aura/commands/alarm/ClockHandoffStop;->OUT_OF_TIME:Lcom/facebook/aura/commands/alarm/ClockHandoffStop;

    .line 149
    .line 150
    return-object v0
.end method

.method public static final canHandOffToClock(Lcom/facebook/aura/commands/alarm/Recurrence;Z)Z
    .locals 3

    .line 0
    if-nez p1, :cond_1

    .line 1
    .line 2
    const/4 v2, 0x1

    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/Recurrence;->frequency:Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;->WEEKLY:Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;

    .line 8
    .line 9
    if-ne v1, v0, :cond_1

    .line 10
    .line 11
    iget v0, p0, Lcom/facebook/aura/commands/alarm/Recurrence;->interval:I

    .line 12
    .line 13
    if-ne v0, v2, :cond_1

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 16
    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/Recurrence;->until:Ljava/lang/Long;

    .line 20
    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    :cond_0
    return v2

    .line 24
    :cond_1
    const/4 v2, 0x0

    .line 25
    return v2
.end method

.method public static final clockAlarmDismissalDescription(I)Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->inAppAlarmDismissalDescription(I)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v0, " Alarms in the Clock app were not dismissed; a card is shown and the user needs to open the Clock app to dismiss them there."

    .line 5
    .line 6
    invoke-static {p0, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public static final clockHandoffInterruptedMessage(Ljava/util/List;ILcom/facebook/aura/commands/alarm/ClockHandoffStop;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/AlarmSetRequest;",
            ">;I",
            "Lcom/facebook/aura/commands/alarm/ClockHandoffStop;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1}, LX/B89;->A0m(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    sget-object v0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$clockHandoffInterruptedMessage$1;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$clockHandoffInterruptedMessage$1;

    .line 5
    .line 6
    const-string v6, ", "

    .line 7
    .line 8
    const-string v2, ""

    .line 9
    .line 10
    invoke-static {v6, v2, v2, v1, v0}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    invoke-static {p0, p1}, LX/B89;->A0l(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    sget-object v0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$clockHandoffInterruptedMessage$2;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$clockHandoffInterruptedMessage$2;

    .line 19
    .line 20
    invoke-static {v6, v2, v2, v1, v0}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    invoke-virtual {p2}, Lcom/facebook/aura/commands/alarm/ClockHandoffStop;->getReason()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    const-string v2, "Only some alarms were set. Set: "

    .line 29
    .line 30
    const-string v4, ". Not set: "

    .line 31
    .line 32
    invoke-static/range {v2 .. v7}, LX/Gi8;->A11(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method

.method public static final computeAlarmDismiss(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;

    .line 3
    .line 4
    if-eqz v0, :cond_b

    .line 5
    .line 6
    move-object v6, v3

    .line 7
    check-cast v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;

    .line 8
    .line 9
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_b

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v11, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->label:I

    .line 25
    .line 26
    const/4 v5, 0x2

    .line 27
    const/4 v12, 0x1

    .line 28
    if-eqz v0, :cond_8

    .line 29
    .line 30
    if-eq v0, v12, :cond_7

    .line 31
    .line 32
    if-ne v0, v5, :cond_f

    .line 33
    .line 34
    iget-object v10, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$9:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;

    .line 37
    .line 38
    iget-object v4, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$8:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v4, Ljava/util/Iterator;

    .line 41
    .line 42
    iget-object v8, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$7:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v8, LX/2aa;

    .line 45
    .line 46
    iget-object v9, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$6:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v9, Ljava/util/List;

    .line 49
    .line 50
    iget-object v7, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$5:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v7, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 53
    .line 54
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$4:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v3, Landroid/content/Context;

    .line 57
    .line 58
    iget-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 61
    .line 62
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_0
    check-cast v1, Ljava/util/List;

    .line 66
    .line 67
    invoke-static {v1}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    :cond_1
    :goto_1
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 72
    .line 73
    if-eqz v1, :cond_4

    .line 74
    .line 75
    iget-boolean v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 76
    .line 77
    if-ne v0, v12, :cond_5

    .line 78
    .line 79
    sget-object v2, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 80
    .line 81
    iget-object v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v2, v3, v0}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    sget-object v2, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;

    .line 87
    .line 88
    iget-object v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 89
    .line 90
    invoke-virtual {v2, v3, v0}, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->cancel$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    iget v0, v8, LX/2aa;->element:I

    .line 94
    .line 95
    add-int/lit8 v0, v0, 0x1

    .line 96
    .line 97
    iput v0, v8, LX/2aa;->element:I

    .line 98
    .line 99
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_c

    .line 104
    .line 105
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v10

    .line 109
    check-cast v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;

    .line 110
    .line 111
    iget-object v0, v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->alarmId:Ljava/lang/String;

    .line 112
    .line 113
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-lez v0, :cond_2

    .line 118
    .line 119
    iget-object v1, v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->alarmId:Ljava/lang/String;

    .line 120
    .line 121
    iput-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$0:Ljava/lang/Object;

    .line 122
    .line 123
    const/4 v0, 0x0

    .line 124
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$1:Ljava/lang/Object;

    .line 125
    .line 126
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$2:Ljava/lang/Object;

    .line 127
    .line 128
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$3:Ljava/lang/Object;

    .line 129
    .line 130
    iput-object v3, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$4:Ljava/lang/Object;

    .line 131
    .line 132
    iput-object v7, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$5:Ljava/lang/Object;

    .line 133
    .line 134
    iput-object v9, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$6:Ljava/lang/Object;

    .line 135
    .line 136
    iput-object v8, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$7:Ljava/lang/Object;

    .line 137
    .line 138
    iput-object v4, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$8:Ljava/lang/Object;

    .line 139
    .line 140
    iput-object v10, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$9:Ljava/lang/Object;

    .line 141
    .line 142
    iput v12, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->label:I

    .line 143
    .line 144
    invoke-virtual {v7, v1, v6}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    if-ne v1, v11, :cond_1

    .line 149
    .line 150
    return-object v11

    .line 151
    :cond_2
    iget-object v0, v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->messageLabel:Ljava/lang/String;

    .line 152
    .line 153
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    if-lez v0, :cond_3

    .line 158
    .line 159
    iget-object v1, v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->messageLabel:Ljava/lang/String;

    .line 160
    .line 161
    iput-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$0:Ljava/lang/Object;

    .line 162
    .line 163
    const/4 v0, 0x0

    .line 164
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$1:Ljava/lang/Object;

    .line 165
    .line 166
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$2:Ljava/lang/Object;

    .line 167
    .line 168
    iput-object v0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$3:Ljava/lang/Object;

    .line 169
    .line 170
    iput-object v3, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$4:Ljava/lang/Object;

    .line 171
    .line 172
    iput-object v7, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$5:Ljava/lang/Object;

    .line 173
    .line 174
    iput-object v9, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$6:Ljava/lang/Object;

    .line 175
    .line 176
    iput-object v8, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$7:Ljava/lang/Object;

    .line 177
    .line 178
    iput-object v4, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$8:Ljava/lang/Object;

    .line 179
    .line 180
    iput-object v10, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$9:Ljava/lang/Object;

    .line 181
    .line 182
    iput v5, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->label:I

    .line 183
    .line 184
    invoke-virtual {v7, v1, v6}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->removeByLabel(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    if-ne v1, v11, :cond_0

    .line 189
    .line 190
    return-object v11

    .line 191
    :cond_3
    const/4 v1, 0x0

    .line 192
    :cond_4
    iget-object v2, v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;->messageLabel:Ljava/lang/String;

    .line 193
    .line 194
    if-nez v1, :cond_6

    .line 195
    .line 196
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 197
    .line 198
    .line 199
    move-result v0

    .line 200
    if-lez v0, :cond_e

    .line 201
    .line 202
    const/4 v0, 0x0

    .line 203
    new-instance v1, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;

    .line 204
    .line 205
    invoke-direct {v1, v0, v0, v2}, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    :goto_3
    invoke-interface {v9, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    goto :goto_2

    .line 212
    :cond_5
    iget-object v2, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->label:Ljava/lang/String;

    .line 213
    .line 214
    if-eqz v2, :cond_4

    .line 215
    .line 216
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    if-lez v0, :cond_4

    .line 221
    .line 222
    :cond_6
    iget v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->hour:I

    .line 223
    .line 224
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 225
    .line 226
    .line 227
    move-result-object v10

    .line 228
    iget v0, v1, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->minute:I

    .line 229
    .line 230
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    new-instance v1, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;

    .line 235
    .line 236
    invoke-direct {v1, v10, v0, v2}, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    goto :goto_3

    .line 240
    :cond_7
    iget-object v10, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$9:Ljava/lang/Object;

    .line 241
    .line 242
    check-cast v10, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;

    .line 243
    .line 244
    iget-object v4, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$8:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v4, Ljava/util/Iterator;

    .line 247
    .line 248
    iget-object v8, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$7:Ljava/lang/Object;

    .line 249
    .line 250
    check-cast v8, LX/2aa;

    .line 251
    .line 252
    iget-object v9, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$6:Ljava/lang/Object;

    .line 253
    .line 254
    check-cast v9, Ljava/util/List;

    .line 255
    .line 256
    iget-object v7, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$5:Ljava/lang/Object;

    .line 257
    .line 258
    check-cast v7, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 259
    .line 260
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$4:Ljava/lang/Object;

    .line 261
    .line 262
    check-cast v3, Landroid/content/Context;

    .line 263
    .line 264
    iget-object p0, v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;->L$0:Ljava/lang/Object;

    .line 265
    .line 266
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 267
    .line 268
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    goto/16 :goto_1

    .line 272
    .line 273
    :cond_8
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 274
    .line 275
    .line 276
    invoke-static {p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    :try_start_0
    const-string v1, "targets_json"

    .line 281
    .line 282
    const-string v0, "targets"

    .line 283
    .line 284
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 285
    .line 286
    .line 287
    move-result-object v1

    .line 288
    if-eqz v1, :cond_11

    .line 289
    .line 290
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 291
    .line 292
    .line 293
    move-result v0

    .line 294
    if-nez v0, :cond_10

    .line 295
    .line 296
    invoke-static {v1}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 297
    .line 298
    .line 299
    move-result-object v4

    .line 300
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    const/4 v2, 0x0

    .line 305
    :goto_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 306
    .line 307
    .line 308
    move-result v0

    .line 309
    if-eqz v0, :cond_a

    .line 310
    .line 311
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    add-int/lit8 v1, v2, 0x1

    .line 316
    .line 317
    if-gez v2, :cond_9

    .line 318
    .line 319
    invoke-static {}, LX/B8B;->A1A()V

    .line 320
    .line 321
    .line 322
    goto/16 :goto_5

    .line 323
    .line 324
    :cond_9
    check-cast v0, Lkotlinx/serialization/json/JsonObject;

    .line 325
    .line 326
    invoke-static {v2, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseAlarmDismissTarget(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;

    .line 327
    .line 328
    .line 329
    move-result-object v0

    .line 330
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move v2, v1

    .line 334
    goto :goto_4
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 335
    :cond_a
    iget-object v3, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 336
    .line 337
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 338
    .line 339
    invoke-virtual {v0, v3}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 340
    .line 341
    .line 342
    move-result-object v7

    .line 343
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 344
    .line 345
    .line 346
    move-result-object v9

    .line 347
    new-instance v8, LX/2aa;

    .line 348
    .line 349
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 350
    .line 351
    .line 352
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 353
    .line 354
    .line 355
    move-result-object v4

    .line 356
    goto/16 :goto_2

    .line 357
    .line 358
    :cond_b
    new-instance v6, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;

    .line 359
    .line 360
    invoke-direct {v6, v3}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismiss$1;-><init>(LX/2M4;)V

    .line 361
    .line 362
    .line 363
    goto/16 :goto_0

    .line 364
    .line 365
    :cond_c
    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    .line 366
    .line 367
    .line 368
    move-result v0

    .line 369
    if-nez v0, :cond_d

    .line 370
    .line 371
    invoke-static {v3}, Lcom/facebook/aura/nodes/core/DeviceDisplayNameKt;->localDeviceDisplayName(Landroid/content/Context;)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v2

    .line 375
    iget-object v1, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->cardSourceClientId:Ljava/lang/String;

    .line 376
    .line 377
    const-string v0, "dismiss"

    .line 378
    .line 379
    invoke-static {v0, v9, v2, v1}, Lcom/facebook/aura/commands/alarm/ClockCardInstructionKt;->clockCardEnvelope(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object p1

    .line 383
    iget v0, v8, LX/2aa;->element:I

    .line 384
    .line 385
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->clockAlarmDismissalDescription(I)Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    move-result-object p2

    .line 389
    const/4 v13, 0x0

    .line 390
    new-instance v11, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 391
    .line 392
    move-object p0, v13

    .line 393
    invoke-direct/range {v11 .. v16}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 394
    .line 395
    .line 396
    return-object v11

    .line 397
    :cond_d
    new-instance v2, LX/BcB;

    .line 398
    .line 399
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 400
    .line 401
    .line 402
    const-string v1, "status"

    .line 403
    .line 404
    const-string v0, "success"

    .line 405
    .line 406
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 407
    .line 408
    .line 409
    iget v0, v8, LX/2aa;->element:I

    .line 410
    .line 411
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    const-string v0, "dismissed_count"

    .line 416
    .line 417
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 418
    .line 419
    .line 420
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 421
    .line 422
    .line 423
    move-result-object v13

    .line 424
    const/4 p0, 0x0

    .line 425
    const-string p2, "The alarm was dismissed on the device."

    .line 426
    .line 427
    new-instance v11, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 428
    .line 429
    move-object p1, p0

    .line 430
    invoke-direct/range {v11 .. v16}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    return-object v11

    .line 434
    :cond_e
    iget v0, v8, LX/2aa;->element:I

    .line 435
    .line 436
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->inAppAlarmDismissalDescription(I)Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    const-string v0, " No alarm found matching the given ID or label"

    .line 441
    .line 442
    invoke-static {v1, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    goto :goto_7

    .line 447
    :cond_f
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    throw v0

    .line 452
    :goto_5
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 453
    .line 454
    .line 455
    move-result-object v0

    .line 456
    goto :goto_6

    .line 457
    :cond_10
    :try_start_1
    const/16 v0, 0xc

    .line 458
    .line 459
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 460
    .line 461
    .line 462
    move-result-object v0

    .line 463
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 464
    .line 465
    .line 466
    move-result-object v0

    .line 467
    goto :goto_6

    .line 468
    :cond_11
    const/16 v0, 0x1a

    .line 469
    .line 470
    invoke-static {v0}, LX/8mj;->A00(I)Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    :goto_6
    throw v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 479
    :catch_0
    move-exception v0

    .line 480
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 481
    .line 482
    .line 483
    move-result-object v0

    .line 484
    if-nez v0, :cond_12

    .line 485
    .line 486
    const-string v0, "Invalid alarm dismiss parameters"

    .line 487
    .line 488
    :cond_12
    :goto_7
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 489
    .line 490
    .line 491
    move-result-object v11

    .line 492
    return-object v11
.end method

.method public static final computeAlarmDismissAll(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;

    .line 1
    .line 2
    if-eqz v0, :cond_7

    .line 3
    .line 4
    move-object v7, p1

    .line 5
    check-cast v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;

    .line 6
    .line 7
    iget v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_7

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v10, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->label:I

    .line 23
    .line 24
    const/4 v8, 0x2

    .line 25
    const/4 v9, 0x1

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    if-eq v0, v9, :cond_2

    .line 29
    .line 30
    if-ne v0, v8, :cond_9

    .line 31
    .line 32
    iget-object v6, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$4:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v6, Ljava/util/List;

    .line 35
    .line 36
    iget-object v1, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$3:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v1, Ljava/util/List;

    .line 39
    .line 40
    iget-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$1:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v5, Landroid/content/Context;

    .line 43
    .line 44
    iget-object p0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 47
    .line 48
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    :goto_1
    invoke-static {v4}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_8

    .line 56
    .line 57
    sget-object v3, LX/0wV;->A00:LX/0wV;

    .line 58
    .line 59
    invoke-static {v5}, Lcom/facebook/aura/nodes/core/DeviceDisplayNameKt;->localDeviceDisplayName(Landroid/content/Context;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    iget-object v1, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->cardSourceClientId:Ljava/lang/String;

    .line 64
    .line 65
    const-string v0, "dismiss_all"

    .line 66
    .line 67
    invoke-static {v0, v3, v2, v1}, Lcom/facebook/aura/commands/alarm/ClockCardInstructionKt;->clockCardEnvelope(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v12

    .line 71
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->clockAlarmDismissalDescription(I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v13

    .line 79
    const/4 v10, 0x0

    .line 80
    new-instance v8, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 81
    .line 82
    move-object v11, v10

    .line 83
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    return-object v8

    .line 87
    :cond_0
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    iget-object v5, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 91
    .line 92
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 93
    .line 94
    invoke-virtual {v0, v5}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    iput-object p0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$0:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    const/4 v0, 0x0

    .line 103
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$2:Ljava/lang/Object;

    .line 104
    .line 105
    iput v9, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->label:I

    .line 106
    .line 107
    invoke-virtual {v1, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->clear(LX/2M4;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v4

    .line 111
    if-ne v4, v10, :cond_3

    .line 112
    .line 113
    :cond_1
    return-object v10

    .line 114
    :cond_2
    iget-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$1:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v5, Landroid/content/Context;

    .line 117
    .line 118
    iget-object p0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$0:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 121
    .line 122
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    :cond_3
    check-cast v4, Ljava/util/List;

    .line 126
    .line 127
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 128
    .line 129
    .line 130
    move-result-object v6

    .line 131
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    :cond_4
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    if-eqz v0, :cond_5

    .line 140
    .line 141
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    move-object v0, v1

    .line 146
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 147
    .line 148
    iget-boolean v0, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 149
    .line 150
    if-eqz v0, :cond_4

    .line 151
    .line 152
    invoke-virtual {v6, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_5
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 157
    .line 158
    .line 159
    move-result-object v3

    .line 160
    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 161
    .line 162
    .line 163
    move-result v0

    .line 164
    if-eqz v0, :cond_6

    .line 165
    .line 166
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v2

    .line 170
    check-cast v2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 171
    .line 172
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 173
    .line 174
    iget-object v0, v2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 175
    .line 176
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;

    .line 180
    .line 181
    iget-object v0, v2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 182
    .line 183
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/commands/alarm/HatchAlarmNotifier;->cancel$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    goto :goto_3

    .line 187
    :cond_6
    iput-object p0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$0:Ljava/lang/Object;

    .line 188
    .line 189
    iput-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$1:Ljava/lang/Object;

    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$2:Ljava/lang/Object;

    .line 193
    .line 194
    iput-object v4, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$3:Ljava/lang/Object;

    .line 195
    .line 196
    iput-object v6, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->L$4:Ljava/lang/Object;

    .line 197
    .line 198
    iput v8, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;->label:I

    .line 199
    .line 200
    invoke-static {v5, v7}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->deviceHasClockApp(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    if-eq v0, v10, :cond_1

    .line 205
    .line 206
    move-object v1, v4

    .line 207
    move-object v4, v0

    .line 208
    goto/16 :goto_1

    .line 209
    .line 210
    :cond_7
    new-instance v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;

    .line 211
    .line 212
    invoke-direct {v7, p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmDismissAll$1;-><init>(LX/2M4;)V

    .line 213
    .line 214
    .line 215
    goto/16 :goto_0

    .line 216
    .line 217
    :cond_8
    new-instance v2, LX/BcB;

    .line 218
    .line 219
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 220
    .line 221
    .line 222
    invoke-static {v1, v2}, LX/IEb;->A0D(Ljava/util/List;LX/BcB;)Ljava/lang/Integer;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    const-string v0, "dismissed_count"

    .line 227
    .line 228
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 232
    .line 233
    .line 234
    move-result-object v12

    .line 235
    const/4 v13, 0x0

    .line 236
    const-string p1, "All in-app alarms were dismissed on the device."

    .line 237
    .line 238
    new-instance v10, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 239
    .line 240
    move v11, v9

    .line 241
    move-object p0, v13

    .line 242
    invoke-direct/range {v10 .. v15}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 243
    .line 244
    .line 245
    return-object v10

    .line 246
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    throw v0
.end method

.method public static final computeAlarmList(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_4

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v1, Ljava/lang/Iterable;

    .line 33
    .line 34
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$$inlined$sortedBy$1;

    .line 35
    .line 36
    invoke-direct {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$$inlined$sortedBy$1;-><init>()V

    .line 37
    .line 38
    .line 39
    invoke-static {v1, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    new-instance v3, LX/BcB;

    .line 44
    .line 45
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 46
    .line 47
    .line 48
    new-instance v2, LX/Bcq;

    .line 49
    .line 50
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 51
    .line 52
    .line 53
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_3

    .line 62
    .line 63
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 68
    .line 69
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lkotlinx/serialization/json/JsonObject;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    iget-object v2, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 81
    .line 82
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 83
    .line 84
    invoke-virtual {v0, v2}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    const/4 v0, 0x0

    .line 89
    iput-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->L$0:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v2, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->L$1:Ljava/lang/Object;

    .line 92
    .line 93
    iput v3, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;->label:I

    .line 94
    .line 95
    invoke-virtual {v1, v5}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    if-ne v1, v4, :cond_0

    .line 100
    .line 101
    return-object v4

    .line 102
    :cond_2
    new-instance v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;

    .line 103
    .line 104
    invoke-direct {v5, p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmList$1;-><init>(LX/2M4;)V

    .line 105
    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_3
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    const-string v0, "alarms"

    .line 113
    .line 114
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    return-object v4

    .line 119
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    throw v0
.end method

.method public static final computeAlarmSet(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;JLX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "J",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-wide/from16 v9, p2

    .line 1
    .line 2
    move-object/from16 v3, p4

    .line 3
    .line 4
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    move-object v12, v3

    .line 9
    check-cast v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;

    .line 10
    .line 11
    iget v2, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v13, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v1, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->label:I

    .line 27
    .line 28
    const/4 v3, 0x2

    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-eq v1, v2, :cond_5

    .line 33
    .line 34
    if-ne v1, v3, :cond_1

    .line 35
    .line 36
    iget-object v8, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$7:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v8, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;

    .line 39
    .line 40
    iget-object v1, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$6:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, Landroid/app/Application;

    .line 43
    .line 44
    goto/16 :goto_5

    .line 45
    .line 46
    :cond_0
    new-instance v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;

    .line 47
    .line 48
    invoke-direct {v12, v3}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;-><init>(LX/2M4;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    throw v0

    .line 57
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    invoke-static {p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    :try_start_0
    const-string v1, "alarms_json"

    .line 65
    .line 66
    const-string v0, "alarms"

    .line 67
    .line 68
    invoke-static {v4, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    if-eqz v1, :cond_10

    .line 73
    .line 74
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_f

    .line 79
    .line 80
    invoke-static {v1}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    const/4 v4, 0x0

    .line 89
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_4

    .line 94
    .line 95
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    add-int/lit8 v1, v4, 0x1

    .line 100
    .line 101
    if-gez v4, :cond_3

    .line 102
    .line 103
    invoke-static {}, LX/B8B;->A1A()V

    .line 104
    .line 105
    .line 106
    goto :goto_2

    .line 107
    :cond_3
    check-cast v0, Lkotlinx/serialization/json/JsonObject;

    .line 108
    .line 109
    invoke-static {v4, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseAlarmSetRequest(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move v4, v1

    .line 117
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 118
    :goto_2
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    goto/16 :goto_6

    .line 123
    .line 124
    :cond_4
    iget-object v5, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 125
    .line 126
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 127
    .line 128
    invoke-virtual {v0, v5}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 129
    .line 130
    .line 131
    move-result-object v6

    .line 132
    iput-object p0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$0:Ljava/lang/Object;

    .line 133
    .line 134
    const/4 v0, 0x0

    .line 135
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$1:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$2:Ljava/lang/Object;

    .line 138
    .line 139
    iput-object v7, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$3:Ljava/lang/Object;

    .line 140
    .line 141
    iput-object v5, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$4:Ljava/lang/Object;

    .line 142
    .line 143
    iput-object v6, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$5:Ljava/lang/Object;

    .line 144
    .line 145
    iput-wide v9, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->J$0:J

    .line 146
    .line 147
    iput v2, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->label:I

    .line 148
    .line 149
    invoke-virtual {v6, v12}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->snapshot(LX/2M4;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    if-ne v0, v13, :cond_6

    .line 154
    .line 155
    return-object v13

    .line 156
    :cond_5
    iget-wide v9, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->J$0:J

    .line 157
    .line 158
    iget-object v6, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$5:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 161
    .line 162
    iget-object v5, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$4:Ljava/lang/Object;

    .line 163
    .line 164
    check-cast v5, Landroid/content/Context;

    .line 165
    .line 166
    iget-object v7, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$3:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v7, Ljava/util/List;

    .line 169
    .line 170
    iget-object p0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$0:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;

    .line 173
    .line 174
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_6
    check-cast v0, Ljava/util/List;

    .line 178
    .line 179
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 180
    .line 181
    .line 182
    move-result v2

    .line 183
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    add-int/2addr v1, v2

    .line 188
    const/16 v0, 0x64

    .line 189
    .line 190
    if-le v1, v0, :cond_7

    .line 191
    .line 192
    const/4 p1, 0x0

    .line 193
    const-string p2, "You can have at most 100 alarms. Dismiss some before adding more."

    .line 194
    .line 195
    :goto_3
    const/4 p0, 0x0

    .line 196
    new-instance v13, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 197
    .line 198
    move-object/from16 p3, p1

    .line 199
    .line 200
    move-object/from16 p4, p1

    .line 201
    .line 202
    invoke-direct/range {v13 .. v18}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    return-object v13

    .line 206
    :cond_7
    sget-object v0, Lcom/facebook/aura/nodes/api/HatchClientCapabilities;->INSTANCE:Lcom/facebook/aura/nodes/api/HatchClientCapabilities;

    .line 207
    .line 208
    invoke-virtual {v0}, Lcom/facebook/aura/nodes/api/HatchClientCapabilities;->getSupportsInAppAlarms()Z

    .line 209
    .line 210
    .line 211
    move-result v0

    .line 212
    if-nez v0, :cond_8

    .line 213
    .line 214
    instance-of v0, v7, Ljava/util/Collection;

    .line 215
    .line 216
    if-eqz v0, :cond_c

    .line 217
    .line 218
    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    .line 219
    .line 220
    .line 221
    move-result v0

    .line 222
    if-eqz v0, :cond_c

    .line 223
    .line 224
    :cond_8
    instance-of v0, v7, Ljava/util/Collection;

    .line 225
    .line 226
    if-eqz v0, :cond_a

    .line 227
    .line 228
    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    .line 229
    .line 230
    .line 231
    move-result v0

    .line 232
    if-eqz v0, :cond_a

    .line 233
    .line 234
    :cond_9
    invoke-static {}, LX/9Fw;->A00()Landroid/app/Application;

    .line 235
    .line 236
    .line 237
    move-result-object v1

    .line 238
    new-instance v8, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;

    .line 239
    .line 240
    invoke-direct {v8}, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;-><init>()V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v1, v8}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 244
    .line 245
    .line 246
    goto :goto_4

    .line 247
    :cond_a
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 248
    .line 249
    .line 250
    move-result-object v4

    .line 251
    :cond_b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 252
    .line 253
    .line 254
    move-result v0

    .line 255
    if-eqz v0, :cond_9

    .line 256
    .line 257
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v0

    .line 261
    check-cast v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 262
    .line 263
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 264
    .line 265
    iget-boolean v0, v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hasExplicitDate:Z

    .line 266
    .line 267
    invoke-static {v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->canHandOffToClock(Lcom/facebook/aura/commands/alarm/Recurrence;Z)Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_b

    .line 272
    .line 273
    sget-object v0, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->INSTANCE:Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;

    .line 274
    .line 275
    invoke-virtual {v0}, Lcom/facebook/aura/lifecycle/AuraAppLifecycleManager;->canPresentInteractiveUi()Z

    .line 276
    .line 277
    .line 278
    move-result v0

    .line 279
    if-nez v0, :cond_9

    .line 280
    .line 281
    sget-object v0, Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;->INSTANCE:Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;

    .line 282
    .line 283
    invoke-virtual {v0, v5}, Lcom/facebook/aura/assist/status/HatchDefaultAssistantStatus;->isDefaultAssistant(Landroid/content/Context;)Z

    .line 284
    .line 285
    .line 286
    move-result v0

    .line 287
    if-nez v0, :cond_9

    .line 288
    .line 289
    const/4 p1, 0x0

    .line 290
    const-string p2, "No alarm was set: the app is in the background, and Android only lets it open the Clock app while it\'s on screen. Ask the user to open the app on this device and ask again."

    .line 291
    .line 292
    goto :goto_3

    .line 293
    :cond_c
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 294
    .line 295
    .line 296
    move-result-object v4

    .line 297
    :cond_d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 298
    .line 299
    .line 300
    move-result v0

    .line 301
    if-eqz v0, :cond_8

    .line 302
    .line 303
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    check-cast v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 308
    .line 309
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 310
    .line 311
    iget-boolean v0, v0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hasExplicitDate:Z

    .line 312
    .line 313
    invoke-static {v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->canHandOffToClock(Lcom/facebook/aura/commands/alarm/Recurrence;Z)Z

    .line 314
    .line 315
    .line 316
    move-result v0

    .line 317
    if-nez v0, :cond_d

    .line 318
    .line 319
    const/4 p1, 0x0

    .line 320
    const-string p2, "This device can only set alarms in its Clock app: a time, optionally repeating on chosen weekdays (all seven for every day). It can\'t set a date, an interval such as every three days, or an end to the repeat."

    .line 321
    .line 322
    goto :goto_3

    .line 323
    :goto_4
    :try_start_1
    iget-object v11, p0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->cardSourceClientId:Ljava/lang/String;

    .line 324
    .line 325
    const/4 v0, 0x0

    .line 326
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$0:Ljava/lang/Object;

    .line 327
    .line 328
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$1:Ljava/lang/Object;

    .line 329
    .line 330
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$2:Ljava/lang/Object;

    .line 331
    .line 332
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$3:Ljava/lang/Object;

    .line 333
    .line 334
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$4:Ljava/lang/Object;

    .line 335
    .line 336
    iput-object v0, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$5:Ljava/lang/Object;

    .line 337
    .line 338
    iput-object v1, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$6:Ljava/lang/Object;

    .line 339
    .line 340
    iput-object v8, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->L$7:Ljava/lang/Object;

    .line 341
    .line 342
    iput-wide v9, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->J$0:J

    .line 343
    .line 344
    iput v2, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->I$0:I

    .line 345
    .line 346
    iput v3, v12, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmSet$1;->label:I

    .line 347
    .line 348
    invoke-static/range {v5 .. v12}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->setAlarmsInOrder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;Ljava/util/List;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    if-ne v0, v13, :cond_e

    .line 353
    .line 354
    return-object v13

    .line 355
    :goto_5
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    :cond_e
    check-cast v0, Lcom/facebook/aura/nodes/core/NodeCommandResponse;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 359
    .line 360
    invoke-virtual {v1, v8}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 361
    .line 362
    .line 363
    return-object v0

    .line 364
    :catchall_0
    move-exception v0

    .line 365
    invoke-virtual {v1, v8}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 366
    .line 367
    .line 368
    throw v0

    .line 369
    :cond_f
    :try_start_2
    const-string v0, "alarms_json must contain at least one alarm"

    .line 370
    .line 371
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    goto :goto_6

    .line 376
    :cond_10
    const-string v0, "alarms_json is required"

    .line 377
    .line 378
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    :goto_6
    throw v0
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_0

    .line 383
    :catch_0
    move-exception v0

    .line 384
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v0

    .line 388
    if-nez v0, :cond_11

    .line 389
    .line 390
    const-string v0, "Invalid alarm parameters"

    .line 391
    .line 392
    :cond_11
    invoke-static {v0}, LX/8mk;->A0G(Ljava/lang/String;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 393
    .line 394
    .line 395
    move-result-object v13

    .line 396
    return-object v13
.end method

.method public static final computeAlarmUpdate(Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;

    .line 3
    .line 4
    if-eqz v0, :cond_e

    .line 5
    .line 6
    move-object v7, v3

    .line 7
    check-cast v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;

    .line 8
    .line 9
    iget v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_e

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v9, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v15, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->label:I

    .line 25
    .line 26
    const-string v14, "Invalid alarm update parameters"

    .line 27
    .line 28
    const/4 v6, 0x2

    .line 29
    const/4 v11, 0x1

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    if-eq v0, v11, :cond_3

    .line 33
    .line 34
    if-ne v0, v6, :cond_10

    .line 35
    .line 36
    iget-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$6:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v5, Ljava/util/List;

    .line 39
    .line 40
    invoke-static {v9}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    new-instance v3, LX/BcB;

    .line 44
    .line 45
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 46
    .line 47
    .line 48
    invoke-static {v5, v3}, LX/IEb;->A0D(Ljava/util/List;LX/BcB;)Ljava/lang/Integer;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const-string v0, "updated_count"

    .line 53
    .line 54
    invoke-static {v1, v0, v3}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 55
    .line 56
    .line 57
    new-instance v2, LX/Bcq;

    .line 58
    .line 59
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_f

    .line 71
    .line 72
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 77
    .line 78
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lkotlinx/serialization/json/JsonObject;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 83
    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_1
    invoke-static {v9}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    invoke-static/range {p1 .. p1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    :try_start_0
    const-string v1, "updates_json"

    .line 94
    .line 95
    const-string v0, "updates"

    .line 96
    .line 97
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/json/JsonObjectParamsKt;->objectListParam(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    if-eqz v1, :cond_2

    .line 102
    .line 103
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-nez v0, :cond_2

    .line 108
    .line 109
    goto :goto_6

    .line 110
    :cond_2
    const-string v0, "updates_json must contain at least one update"

    .line 111
    .line 112
    invoke-static {v0}, LX/001;->A0p(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    throw v0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 117
    :catch_0
    move-exception v0

    .line 118
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    if-nez p0, :cond_4

    .line 123
    .line 124
    move-object/from16 p0, v14

    .line 125
    .line 126
    goto :goto_4

    .line 127
    :cond_3
    iget v3, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->I$0:I

    .line 128
    .line 129
    iget-object v12, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$10:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast v12, Ljava/lang/String;

    .line 132
    .line 133
    iget-object v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$9:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v2, Ljava/lang/String;

    .line 136
    .line 137
    iget-object v1, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$8:Ljava/lang/Object;

    .line 138
    .line 139
    check-cast v1, Lkotlinx/serialization/json/JsonObject;

    .line 140
    .line 141
    iget-object v10, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$7:Ljava/lang/Object;

    .line 142
    .line 143
    check-cast v10, Ljava/util/Iterator;

    .line 144
    .line 145
    iget-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$6:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v5, Ljava/util/List;

    .line 148
    .line 149
    iget-object v4, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$5:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast v4, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 152
    .line 153
    iget-object v8, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$4:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v8, Landroid/content/Context;

    .line 156
    .line 157
    invoke-static {v9}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    :goto_2
    check-cast v9, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 161
    .line 162
    if-nez v9, :cond_6

    .line 163
    .line 164
    const-string v0, "No alarm found with id "

    .line 165
    .line 166
    invoke-static {v0, v12}, LX/002;->A18(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    :goto_3
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p0

    .line 174
    :cond_4
    :goto_4
    const/16 v17, 0x0

    .line 175
    .line 176
    :goto_5
    const/16 v16, 0x0

    .line 177
    .line 178
    new-instance v15, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 179
    .line 180
    move-object/from16 p1, v17

    .line 181
    .line 182
    move-object/from16 p2, v17

    .line 183
    .line 184
    invoke-direct/range {v15 .. v20}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    :cond_5
    return-object v15

    .line 188
    :cond_6
    iget-boolean v0, v9, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 189
    .line 190
    if-nez v0, :cond_7

    .line 191
    .line 192
    const/16 v17, 0x0

    .line 193
    .line 194
    const-string p0, "This alarm is managed by the system Clock app and cannot be edited here; change it in the Clock app, or dismiss it and set a new one."

    .line 195
    .line 196
    goto :goto_5

    .line 197
    :cond_7
    :try_start_1
    invoke-static {v2, v1, v9}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->resolveAlarmUpdate(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 198
    .line 199
    .line 200
    move-result-object v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 201
    invoke-interface {v5, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 202
    .line 203
    .line 204
    goto :goto_7

    .line 205
    :goto_6
    move-object/from16 v0, p0

    .line 206
    .line 207
    iget-object v8, v0, Lcom/facebook/aura/nodes/registry/HatchNodeCommandContext;->context:Landroid/content/Context;

    .line 208
    .line 209
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;

    .line 210
    .line 211
    invoke-virtual {v0, v8}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore$Companion;->getInstance(Landroid/content/Context;)Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 212
    .line 213
    .line 214
    move-result-object v4

    .line 215
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 220
    .line 221
    .line 222
    move-result-object v10

    .line 223
    const/4 v3, 0x0

    .line 224
    :goto_7
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    if-eqz v0, :cond_b

    .line 229
    .line 230
    add-int/lit8 v13, v3, 0x1

    .line 231
    .line 232
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    check-cast v1, Lkotlinx/serialization/json/JsonObject;

    .line 237
    .line 238
    const-string v2, "updates_json["

    .line 239
    .line 240
    const-string v0, "]"

    .line 241
    .line 242
    invoke-static {v2, v3, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    const-string v0, "alarm_id"

    .line 247
    .line 248
    invoke-virtual {v1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v9

    .line 252
    instance-of v0, v9, Lkotlinx/serialization/json/JsonPrimitive;

    .line 253
    .line 254
    if-eqz v0, :cond_8

    .line 255
    .line 256
    check-cast v9, Lkotlinx/serialization/json/JsonPrimitive;

    .line 257
    .line 258
    if-eqz v9, :cond_8

    .line 259
    .line 260
    invoke-static {v9}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v12

    .line 264
    if-nez v12, :cond_9

    .line 265
    .line 266
    :cond_8
    const-string v12, ""

    .line 267
    .line 268
    :cond_9
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 269
    .line 270
    .line 271
    move-result v0

    .line 272
    if-nez v0, :cond_a

    .line 273
    .line 274
    invoke-static {v2}, LX/002;->A15(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 275
    .line 276
    .line 277
    move-result-object v1

    .line 278
    const-string v0, ".alarm_id is required"

    .line 279
    .line 280
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 281
    .line 282
    .line 283
    goto :goto_3

    .line 284
    :cond_a
    const/4 v0, 0x0

    .line 285
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$0:Ljava/lang/Object;

    .line 286
    .line 287
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$1:Ljava/lang/Object;

    .line 288
    .line 289
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$2:Ljava/lang/Object;

    .line 290
    .line 291
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$3:Ljava/lang/Object;

    .line 292
    .line 293
    iput-object v8, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$4:Ljava/lang/Object;

    .line 294
    .line 295
    iput-object v4, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$5:Ljava/lang/Object;

    .line 296
    .line 297
    iput-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$6:Ljava/lang/Object;

    .line 298
    .line 299
    iput-object v10, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$7:Ljava/lang/Object;

    .line 300
    .line 301
    iput-object v1, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$8:Ljava/lang/Object;

    .line 302
    .line 303
    iput-object v2, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$9:Ljava/lang/Object;

    .line 304
    .line 305
    iput-object v12, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$10:Ljava/lang/Object;

    .line 306
    .line 307
    iput v13, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->I$0:I

    .line 308
    .line 309
    iput v3, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->I$1:I

    .line 310
    .line 311
    iput v11, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->label:I

    .line 312
    .line 313
    invoke-virtual {v4, v12, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v9

    .line 317
    if-eq v9, v15, :cond_5

    .line 318
    .line 319
    move v3, v13

    .line 320
    goto/16 :goto_2

    .line 321
    .line 322
    :cond_b
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 323
    .line 324
    .line 325
    move-result-object v3

    .line 326
    :cond_c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 327
    .line 328
    .line 329
    move-result v0

    .line 330
    if-eqz v0, :cond_d

    .line 331
    .line 332
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    move-result-object v2

    .line 336
    check-cast v2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 337
    .line 338
    sget-object v1, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 339
    .line 340
    iget-object v0, v2, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 341
    .line 342
    invoke-virtual {v1, v8, v0}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->cancel(Landroid/content/Context;Ljava/lang/String;)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {v1, v8, v2}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Z

    .line 346
    .line 347
    .line 348
    move-result v0

    .line 349
    if-nez v0, :cond_c

    .line 350
    .line 351
    const/16 v17, 0x0

    .line 352
    .line 353
    const-string p0, "Failed to set alarm."

    .line 354
    .line 355
    goto/16 :goto_5

    .line 356
    .line 357
    :cond_d
    const/4 v0, 0x0

    .line 358
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$0:Ljava/lang/Object;

    .line 359
    .line 360
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$1:Ljava/lang/Object;

    .line 361
    .line 362
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$2:Ljava/lang/Object;

    .line 363
    .line 364
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$3:Ljava/lang/Object;

    .line 365
    .line 366
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$4:Ljava/lang/Object;

    .line 367
    .line 368
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$5:Ljava/lang/Object;

    .line 369
    .line 370
    iput-object v5, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$6:Ljava/lang/Object;

    .line 371
    .line 372
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$7:Ljava/lang/Object;

    .line 373
    .line 374
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$8:Ljava/lang/Object;

    .line 375
    .line 376
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$9:Ljava/lang/Object;

    .line 377
    .line 378
    iput-object v0, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->L$10:Ljava/lang/Object;

    .line 379
    .line 380
    iput v6, v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;->label:I

    .line 381
    .line 382
    invoke-virtual {v4, v5, v7}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->addAll(Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 383
    .line 384
    .line 385
    move-result-object v0

    .line 386
    if-ne v0, v15, :cond_0

    .line 387
    .line 388
    return-object v15

    .line 389
    :cond_e
    new-instance v7, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;

    .line 390
    .line 391
    invoke-direct {v7, v3}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$computeAlarmUpdate$1;-><init>(LX/2M4;)V

    .line 392
    .line 393
    .line 394
    goto/16 :goto_0

    .line 395
    .line 396
    :cond_f
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    const-string v0, "alarms"

    .line 401
    .line 402
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 403
    .line 404
    .line 405
    move-result-object v15

    .line 406
    return-object v15

    .line 407
    :cond_10
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 408
    .line 409
    .line 410
    move-result-object v0

    .line 411
    throw v0
.end method

.method public static final describeAlarm(Lcom/facebook/aura/commands/alarm/AlarmSetRequest;)Ljava/lang/String;
    .locals 4

    .line 0
    iget v0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 1
    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    iget v0, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x2

    .line 13
    filled-new-array {v2, v0}, [Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v0, "%02d:%02d"

    .line 22
    .line 23
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    iget-object v2, p0, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    const-string v0, ""

    .line 36
    .line 37
    :goto_0
    invoke-static {v3, v0}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    return-object v0

    .line 42
    :cond_0
    const-string v1, " \""

    .line 43
    .line 44
    const-string v0, "\""

    .line 45
    .line 46
    invoke-static {v1, v2, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    goto :goto_0
.end method

.method public static final deviceHasClockApp(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const/4 v1, 0x0

    .line 5
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$deviceHasClockApp$2;

    .line 6
    .line 7
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$deviceHasClockApp$2;-><init>(Landroid/content/Context;LX/2M4;)V

    .line 8
    .line 9
    .line 10
    invoke-static {p1, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public static final inAppAlarmDismissalDescription(I)Ljava/lang/String;
    .locals 2

    .line 0
    const-string v1, "In-app alarms dismissed on the device: "

    .line 1
    .line 2
    const-string v0, "."

    .line 3
    .line 4
    invoke-static {v1, p0, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public static final mergeRecurrenceBounds(Ljava/lang/String;Lcom/facebook/aura/commands/alarm/Recurrence;Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/Recurrence;
    .locals 10

    .line 0
    move-object v4, p1

    .line 1
    invoke-static {p0, p1, p2}, LX/3Rs;->A1R(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    const-string v0, "interval"

    .line 6
    .line 7
    invoke-virtual {p2, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 12
    .line 13
    const/4 v9, 0x0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 17
    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    invoke-static {v1}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    :goto_0
    if-lt v6, v3, :cond_9

    .line 31
    .line 32
    const-string v1, "count"

    .line 33
    .line 34
    invoke-virtual {p2, v1}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    invoke-virtual {p2, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    instance-of v0, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 45
    .line 46
    if-eqz v0, :cond_0

    .line 47
    .line 48
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 49
    .line 50
    :goto_1
    const/16 v0, 0x11

    .line 51
    .line 52
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    if-eqz v2, :cond_2

    .line 57
    .line 58
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 59
    .line 60
    .line 61
    move-result-object v8

    .line 62
    if-eqz v8, :cond_2

    .line 63
    .line 64
    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-ge v0, v3, :cond_4

    .line 69
    .line 70
    invoke-static {p0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    throw v0

    .line 75
    :cond_0
    move-object v2, v9

    .line 76
    goto :goto_1

    .line 77
    :cond_1
    iget v6, p1, Lcom/facebook/aura/commands/alarm/Recurrence;->interval:I

    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_2
    invoke-static {p0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    throw v0

    .line 85
    :cond_3
    iget-object v8, p1, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 86
    .line 87
    :cond_4
    const-string v1, "until"

    .line 88
    .line 89
    invoke-virtual {p2, v1}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_7

    .line 94
    .line 95
    invoke-virtual {p2, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 100
    .line 101
    if-eqz v0, :cond_5

    .line 102
    .line 103
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 104
    .line 105
    if-eqz v1, :cond_5

    .line 106
    .line 107
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    if-eqz v0, :cond_5

    .line 112
    .line 113
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    if-nez v2, :cond_6

    .line 118
    .line 119
    :cond_5
    const-string v2, ""

    .line 120
    .line 121
    :cond_6
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-eqz v0, :cond_8

    .line 126
    .line 127
    sget-object v1, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 128
    .line 129
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->parseUntilMs(Ljava/lang/String;Ljava/time/ZoneId;)Ljava/lang/Long;

    .line 137
    .line 138
    .line 139
    move-result-object v9

    .line 140
    if-nez v9, :cond_8

    .line 141
    .line 142
    const/16 v0, 0x13

    .line 143
    .line 144
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    invoke-static {p0, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    throw v0

    .line 153
    :cond_7
    iget-object v9, p1, Lcom/facebook/aura/commands/alarm/Recurrence;->until:Ljava/lang/Long;

    .line 154
    .line 155
    :cond_8
    sget-object v0, Lcom/facebook/aura/commands/alarm/Recurrence;->$childSerializers:[Lkotlin/Lazy;

    .line 156
    .line 157
    iget-object v5, p1, Lcom/facebook/aura/commands/alarm/Recurrence;->frequency:Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;

    .line 158
    .line 159
    iget-object v7, p1, Lcom/facebook/aura/commands/alarm/Recurrence;->byWeekdays:Ljava/util/List;

    .line 160
    .line 161
    invoke-virtual/range {v4 .. v9}, Lcom/facebook/aura/commands/alarm/Recurrence;->copy(Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;ILjava/util/List;Ljava/lang/Integer;Ljava/lang/Long;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    return-object v0

    .line 166
    :cond_9
    const/16 v0, 0x12

    .line 167
    .line 168
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-static {p0, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    throw v0
.end method

.method public static final parseAlarmDismissTarget(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;
    .locals 3

    .line 0
    const-string v1, "targets_json["

    .line 1
    .line 2
    const-string v0, "]"

    .line 3
    .line 4
    invoke-static {v1, p0, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const-string v0, "alarm_id"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    instance-of v0, v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    check-cast v1, Lkotlinx/serialization/json/JsonPrimitive;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    invoke-static {v1}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    :cond_0
    const-string v0, ""

    .line 28
    .line 29
    if-nez v2, :cond_1

    .line 30
    .line 31
    move-object v2, v0

    .line 32
    :cond_1
    const-string v0, "message"

    .line 33
    .line 34
    invoke-static {v0, p1}, LX/8ml;->A0M(Ljava/lang/Object;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_2

    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_2

    .line 49
    .line 50
    const-string v0, " must include either \'alarm_id\' or \'message\'."

    .line 51
    .line 52
    invoke-static {p0, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    throw v0

    .line 57
    :cond_2
    new-instance v0, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;

    .line 58
    .line 59
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/commands/alarm/AlarmDismissTarget;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    return-object v0
.end method

.method public static final parseAlarmSetRequest(ILkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/AlarmSetRequest;
    .locals 24

    .line 0
    const-string v1, "alarms_json["

    .line 1
    .line 2
    const-string v0, "]"

    .line 3
    .line 4
    move/from16 v2, p0

    .line 5
    .line 6
    invoke-static {v1, v2, v0}, LX/Gi8;->A0Y(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const-string v1, "hour"

    .line 11
    .line 12
    move-object/from16 v3, p1

    .line 13
    .line 14
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 19
    .line 20
    const/4 v5, 0x0

    .line 21
    if-eqz v1, :cond_d

    .line 22
    .line 23
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 24
    .line 25
    if-eqz v2, :cond_d

    .line 26
    .line 27
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-eqz v1, :cond_d

    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 34
    .line 35
    .line 36
    move-result v6

    .line 37
    :goto_0
    const-string v1, "minutes"

    .line 38
    .line 39
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 44
    .line 45
    if-eqz v1, :cond_c

    .line 46
    .line 47
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 48
    .line 49
    if-eqz v2, :cond_c

    .line 50
    .line 51
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    if-eqz v1, :cond_c

    .line 56
    .line 57
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result v7

    .line 61
    :goto_1
    if-ltz v6, :cond_12

    .line 62
    .line 63
    const/16 v1, 0x18

    .line 64
    .line 65
    if-ge v6, v1, :cond_12

    .line 66
    .line 67
    if-ltz v7, :cond_11

    .line 68
    .line 69
    const/16 v1, 0x3c

    .line 70
    .line 71
    if-ge v7, v1, :cond_11

    .line 72
    .line 73
    const-string v1, "message"

    .line 74
    .line 75
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 80
    .line 81
    if-eqz v1, :cond_b

    .line 82
    .line 83
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 84
    .line 85
    if-eqz v2, :cond_b

    .line 86
    .line 87
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v8

    .line 91
    :goto_2
    const-string v4, ""

    .line 92
    .line 93
    if-nez v8, :cond_0

    .line 94
    .line 95
    move-object v8, v4

    .line 96
    :cond_0
    const-string v1, "days"

    .line 97
    .line 98
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 103
    .line 104
    if-eqz v1, :cond_1

    .line 105
    .line 106
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 107
    .line 108
    if-eqz v2, :cond_1

    .line 109
    .line 110
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v9

    .line 114
    if-nez v9, :cond_2

    .line 115
    .line 116
    :cond_1
    move-object v9, v4

    .line 117
    :cond_2
    const-string v1, "date"

    .line 118
    .line 119
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 124
    .line 125
    if-eqz v1, :cond_3

    .line 126
    .line 127
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 128
    .line 129
    if-eqz v2, :cond_3

    .line 130
    .line 131
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v22

    .line 135
    if-nez v22, :cond_4

    .line 136
    .line 137
    :cond_3
    move-object/from16 v22, v4

    .line 138
    .line 139
    :cond_4
    const-string v1, "vibrate"

    .line 140
    .line 141
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 146
    .line 147
    if-eqz v1, :cond_a

    .line 148
    .line 149
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 150
    .line 151
    :goto_3
    const/4 v4, 0x1

    .line 152
    if-eqz v2, :cond_9

    .line 153
    .line 154
    invoke-static {v2}, LX/Dcc;->A01(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Boolean;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    if-eqz v1, :cond_9

    .line 159
    .line 160
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 161
    .line 162
    .line 163
    move-result v10

    .line 164
    :goto_4
    const-string v1, "frequency"

    .line 165
    .line 166
    invoke-virtual {v3, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v2

    .line 170
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 171
    .line 172
    if-eqz v1, :cond_8

    .line 173
    .line 174
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 175
    .line 176
    if-eqz v2, :cond_8

    .line 177
    .line 178
    invoke-static {v2}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    if-eqz v1, :cond_8

    .line 183
    .line 184
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    xor-int/lit8 v1, v1, 0x1

    .line 189
    .line 190
    if-ne v1, v4, :cond_8

    .line 191
    .line 192
    :cond_5
    invoke-static {v0, v3}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseTimeZone(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object v17

    .line 196
    if-eqz v17, :cond_6

    .line 197
    .line 198
    invoke-static/range {v17 .. v17}, Ljava/time/ZoneId;->of(Ljava/lang/String;)Ljava/time/ZoneId;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    if-nez p1, :cond_7

    .line 203
    .line 204
    :cond_6
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    :cond_7
    invoke-static {v0, v3, v9}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseRecurrence(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 209
    .line 210
    .line 211
    move-result-object v13

    .line 212
    sget-object v18, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 213
    .line 214
    invoke-static/range {p1 .. p1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    move/from16 v19, v6

    .line 218
    .line 219
    move/from16 v20, v7

    .line 220
    .line 221
    move-object/from16 v21, v13

    .line 222
    .line 223
    move-object/from16 v23, p1

    .line 224
    .line 225
    invoke-virtual/range {v18 .. v23}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->anchorMsFor$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;Ljava/time/ZoneId;)Ljava/lang/Long;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    if-eqz v1, :cond_f

    .line 230
    .line 231
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 232
    .line 233
    .line 234
    move-result-wide v14

    .line 235
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 236
    .line 237
    .line 238
    move-result-wide v23

    .line 239
    invoke-virtual/range {v18 .. v25}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeFirstTriggerTimeMs$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;JLjava/time/ZoneId;)J

    .line 240
    .line 241
    .line 242
    move-result-wide v11

    .line 243
    const-wide/16 v2, -0x1

    .line 244
    .line 245
    cmp-long v1, v11, v2

    .line 246
    .line 247
    if-eqz v1, :cond_e

    .line 248
    .line 249
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->length()I

    .line 250
    .line 251
    .line 252
    move-result v0

    .line 253
    invoke-static {v0}, LX/003;->A1F(I)Z

    .line 254
    .line 255
    .line 256
    move-result v16

    .line 257
    new-instance v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 258
    .line 259
    invoke-direct/range {v5 .. v17}, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;-><init>(IILjava/lang/String;Ljava/lang/String;ZJLcom/facebook/aura/commands/alarm/Recurrence;JZLjava/lang/String;)V

    .line 260
    .line 261
    .line 262
    return-object v5

    .line 263
    :cond_8
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->length()I

    .line 264
    .line 265
    .line 266
    move-result v1

    .line 267
    if-lez v1, :cond_5

    .line 268
    .line 269
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 270
    .line 271
    .line 272
    move-result v1

    .line 273
    if-gtz v1, :cond_10

    .line 274
    .line 275
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 276
    .line 277
    .line 278
    move-result-object v2

    .line 279
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    const/4 v1, 0x2

    .line 284
    filled-new-array {v2, v0}, [Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    const-string v0, "%02d:%02d"

    .line 293
    .line 294
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v2

    .line 298
    const-string v1, "Future-dated alarms are not supported by the system Clock app. Omit \'date\' and the alarm will fire at the next "

    .line 299
    .line 300
    const-string v0, ", or use \'days\' for a recurring weekday alarm."

    .line 301
    .line 302
    invoke-static {v1, v2, v0}, LX/Gi8;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 303
    .line 304
    .line 305
    move-result-object v0

    .line 306
    throw v0

    .line 307
    :cond_9
    const/4 v10, 0x1

    .line 308
    goto/16 :goto_4

    .line 309
    .line 310
    :cond_a
    move-object v2, v5

    .line 311
    goto/16 :goto_3

    .line 312
    .line 313
    :cond_b
    move-object v8, v5

    .line 314
    goto/16 :goto_2

    .line 315
    .line 316
    :cond_c
    const/4 v7, -0x1

    .line 317
    goto/16 :goto_1

    .line 318
    .line 319
    :cond_d
    const/4 v6, -0x1

    .line 320
    goto/16 :goto_0

    .line 321
    .line 322
    :cond_e
    const-string v1, " failed to compute trigger time"

    .line 323
    .line 324
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    throw v0

    .line 329
    :cond_f
    const-string v1, ".date must be a valid YYYY-MM-DD date"

    .line 330
    .line 331
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    throw v0

    .line 336
    :cond_10
    const-string v1, " cannot combine \'date\' (one-time) with \'days\' (recurring). Pick one, or set \'frequency\'."

    .line 337
    .line 338
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    throw v0

    .line 343
    :cond_11
    const-string v1, ".minutes is missing or invalid; it must be an integer from 0 to 59"

    .line 344
    .line 345
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    throw v0

    .line 350
    :cond_12
    const-string v1, ".hour is missing or invalid; it must be an integer from 0 to 23"

    .line 351
    .line 352
    invoke-static {v0, v1}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 353
    .line 354
    .line 355
    move-result-object v0

    .line 356
    throw v0
.end method

.method public static final parseDays(Ljava/lang/String;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    sget-object v4, LX/0wV;->A00:LX/0wV;

    .line 11
    .line 12
    :cond_0
    return-object v4

    .line 13
    :cond_1
    const/4 v5, 0x1

    .line 14
    const-string v0, ","

    .line 15
    .line 16
    invoke-static {p0, v0}, LX/AdT;->A0h(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_3

    .line 33
    .line 34
    invoke-static {v1}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {v0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {v0}, LX/0wP;->A00(Ljava/lang/String;)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_3
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    :cond_4
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    invoke-static {v2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    if-gt v5, v1, :cond_4

    .line 75
    .line 76
    const/16 v0, 0x8

    .line 77
    .line 78
    if-ge v1, v0, :cond_4

    .line 79
    .line 80
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    goto :goto_1
.end method

.method public static final parseParams(Ljava/lang/String;)Lkotlinx/serialization/json/JsonObject;
    .locals 1

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 3
    .line 4
    invoke-virtual {v0, p0}, LX/Dcb;->A04(Ljava/lang/String;)Lkotlinx/serialization/json/JsonElement;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, Lcom/facebook/aura/json/JsonObjectExtensionsKt;->asJsonObjectOrNull(Lkotlinx/serialization/json/JsonElement;)Lkotlinx/serialization/json/JsonObject;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    if-nez p0, :cond_1

    .line 13
    .line 14
    :cond_0
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    new-instance p0, Lkotlinx/serialization/json/JsonObject;

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lkotlinx/serialization/json/JsonObject;-><init>(Ljava/util/Map;)V

    .line 21
    .line 22
    .line 23
    :cond_1
    return-object p0
.end method

.method public static final resolveAlarmUpdate(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lcom/facebook/aura/commands/alarm/ShadowAlarm;
    .locals 30

    .line 0
    const-string v0, "hour"

    .line 1
    .line 2
    move-object/from16 v12, p1

    .line 3
    .line 4
    invoke-virtual {v12, v0}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 9
    .line 10
    move-object/from16 v0, p2

    .line 11
    .line 12
    if-eqz v1, :cond_7

    .line 13
    .line 14
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 15
    .line 16
    if-eqz v2, :cond_7

    .line 17
    .line 18
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-eqz v1, :cond_7

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 25
    .line 26
    .line 27
    move-result v7

    .line 28
    :goto_0
    const-string v1, "minutes"

    .line 29
    .line 30
    invoke-virtual {v12, v1}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    instance-of v1, v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 35
    .line 36
    if-eqz v1, :cond_6

    .line 37
    .line 38
    check-cast v2, Lkotlinx/serialization/json/JsonPrimitive;

    .line 39
    .line 40
    if-eqz v2, :cond_6

    .line 41
    .line 42
    invoke-static {v2}, LX/Dcc;->A02(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    if-eqz v1, :cond_6

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    :goto_1
    move-object/from16 v1, p0

    .line 53
    .line 54
    if-ltz v7, :cond_15

    .line 55
    .line 56
    const/16 v2, 0x18

    .line 57
    .line 58
    if-ge v7, v2, :cond_15

    .line 59
    .line 60
    if-ltz v5, :cond_14

    .line 61
    .line 62
    const/16 v2, 0x3c

    .line 63
    .line 64
    if-ge v5, v2, :cond_14

    .line 65
    .line 66
    const-string v2, "message"

    .line 67
    .line 68
    invoke-virtual {v12, v2}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    instance-of v2, v3, Lkotlinx/serialization/json/JsonPrimitive;

    .line 73
    .line 74
    if-eqz v2, :cond_0

    .line 75
    .line 76
    check-cast v3, Lkotlinx/serialization/json/JsonPrimitive;

    .line 77
    .line 78
    if-eqz v3, :cond_0

    .line 79
    .line 80
    invoke-static {v3}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    if-nez v6, :cond_1

    .line 85
    .line 86
    :cond_0
    iget-object v6, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->label:Ljava/lang/String;

    .line 87
    .line 88
    :cond_1
    const-string v2, "vibrate"

    .line 89
    .line 90
    invoke-virtual {v12, v2}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    instance-of v2, v3, Lkotlinx/serialization/json/JsonPrimitive;

    .line 95
    .line 96
    if-eqz v2, :cond_5

    .line 97
    .line 98
    check-cast v3, Lkotlinx/serialization/json/JsonPrimitive;

    .line 99
    .line 100
    if-eqz v3, :cond_5

    .line 101
    .line 102
    invoke-static {v3}, LX/Dcc;->A01(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/Boolean;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    if-eqz v2, :cond_5

    .line 107
    .line 108
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 109
    .line 110
    .line 111
    move-result v14

    .line 112
    :goto_2
    const-string v8, "frequency"

    .line 113
    .line 114
    invoke-virtual {v12, v8}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v3

    .line 118
    const-string v9, "date"

    .line 119
    .line 120
    const-string v2, "days"

    .line 121
    .line 122
    const/4 v11, 0x1

    .line 123
    if-nez v3, :cond_2

    .line 124
    .line 125
    invoke-virtual {v12, v2}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    if-nez v3, :cond_2

    .line 130
    .line 131
    invoke-virtual {v12, v9}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v3

    .line 135
    const/4 v13, 0x0

    .line 136
    if-eqz v3, :cond_3

    .line 137
    .line 138
    :cond_2
    const/4 v13, 0x1

    .line 139
    :cond_3
    const-string v3, "timezone"

    .line 140
    .line 141
    invoke-virtual {v12, v3}, Lkotlinx/serialization/json/JsonObject;->containsKey(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v3

    .line 145
    if-eqz v3, :cond_4

    .line 146
    .line 147
    invoke-static {v1, v12}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseTimeZone(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v10

    .line 151
    :goto_3
    if-eqz v10, :cond_9

    .line 152
    .line 153
    goto :goto_4

    .line 154
    :cond_4
    iget-object v10, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->timezone:Ljava/lang/String;

    .line 155
    .line 156
    goto :goto_3

    .line 157
    :cond_5
    iget-boolean v14, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->vibrate:Z

    .line 158
    .line 159
    goto :goto_2

    .line 160
    :cond_6
    iget v5, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->minute:I

    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_7
    iget v7, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->hour:I

    .line 164
    .line 165
    goto/16 :goto_0

    .line 166
    .line 167
    :goto_4
    :try_start_0
    invoke-static {v10}, Ljava/time/ZoneId;->of(Ljava/lang/String;)Ljava/time/ZoneId;

    .line 168
    .line 169
    .line 170
    move-result-object v3

    .line 171
    goto :goto_5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 172
    :catchall_0
    move-exception v3

    .line 173
    invoke-static {v3}, LX/3Rp;->A11(Ljava/lang/Throwable;)LX/2PH;

    .line 174
    .line 175
    .line 176
    move-result-object v3

    .line 177
    :goto_5
    instance-of v4, v3, LX/2PH;

    .line 178
    .line 179
    if-eqz v4, :cond_8

    .line 180
    .line 181
    const/4 v3, 0x0

    .line 182
    :cond_8
    check-cast v3, Ljava/time/ZoneId;

    .line 183
    .line 184
    if-nez v3, :cond_a

    .line 185
    .line 186
    :cond_9
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    :cond_a
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 191
    .line 192
    .line 193
    move-result-wide p0

    .line 194
    const-string v4, " failed to compute trigger time"

    .line 195
    .line 196
    const-wide/16 v15, -0x1

    .line 197
    .line 198
    if-eqz v13, :cond_11

    .line 199
    .line 200
    invoke-virtual {v12, v2}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v13

    .line 204
    instance-of v2, v13, Lkotlinx/serialization/json/JsonPrimitive;

    .line 205
    .line 206
    if-eqz v2, :cond_e

    .line 207
    .line 208
    check-cast v13, Lkotlinx/serialization/json/JsonPrimitive;

    .line 209
    .line 210
    if-eqz v13, :cond_e

    .line 211
    .line 212
    invoke-static {v13}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v2

    .line 216
    :goto_6
    const-string v13, ""

    .line 217
    .line 218
    if-nez v2, :cond_b

    .line 219
    .line 220
    move-object v2, v13

    .line 221
    :cond_b
    invoke-static {v9, v12}, LX/8ml;->A0M(Ljava/lang/Object;Lkotlinx/serialization/json/JsonObject;)Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v29

    .line 225
    invoke-virtual {v12, v8}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v9

    .line 229
    instance-of v8, v9, Lkotlinx/serialization/json/JsonPrimitive;

    .line 230
    .line 231
    if-eqz v8, :cond_d

    .line 232
    .line 233
    check-cast v9, Lkotlinx/serialization/json/JsonPrimitive;

    .line 234
    .line 235
    if-eqz v9, :cond_d

    .line 236
    .line 237
    invoke-static {v9}, LX/Dcc;->A04(Lkotlinx/serialization/json/JsonPrimitive;)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v8

    .line 241
    if-eqz v8, :cond_d

    .line 242
    .line 243
    invoke-static {v8}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 244
    .line 245
    .line 246
    move-result v8

    .line 247
    xor-int/lit8 v8, v8, 0x1

    .line 248
    .line 249
    if-ne v8, v11, :cond_d

    .line 250
    .line 251
    :cond_c
    invoke-static {v1, v12, v2}, Lcom/facebook/aura/commands/alarm/RecurrenceKt;->parseRecurrence(Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 252
    .line 253
    .line 254
    move-result-object v22

    .line 255
    sget-object v25, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 256
    .line 257
    invoke-static {v3}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    move-object/from16 v19, v25

    .line 261
    .line 262
    move/from16 v20, v7

    .line 263
    .line 264
    move/from16 v21, v5

    .line 265
    .line 266
    move-object/from16 v23, v29

    .line 267
    .line 268
    move-object/from16 v24, v3

    .line 269
    .line 270
    invoke-virtual/range {v19 .. v24}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->anchorMsFor$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;Ljava/time/ZoneId;)Ljava/lang/Long;

    .line 271
    .line 272
    .line 273
    move-result-object v8

    .line 274
    if-eqz v8, :cond_10

    .line 275
    .line 276
    invoke-virtual {v8}, Ljava/lang/Number;->longValue()J

    .line 277
    .line 278
    .line 279
    move-result-wide v23

    .line 280
    move/from16 v26, v7

    .line 281
    .line 282
    move/from16 v27, v5

    .line 283
    .line 284
    move-object/from16 v28, v22

    .line 285
    .line 286
    move-object/from16 p2, v3

    .line 287
    .line 288
    invoke-virtual/range {v25 .. v32}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeFirstTriggerTimeMs$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;Ljava/lang/String;JLjava/time/ZoneId;)J

    .line 289
    .line 290
    .line 291
    move-result-wide v17

    .line 292
    cmp-long v3, v17, v15

    .line 293
    .line 294
    if-eqz v3, :cond_f

    .line 295
    .line 296
    iget-object v13, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 297
    .line 298
    iget-boolean v0, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 299
    .line 300
    const/16 v25, 0x0

    .line 301
    .line 302
    invoke-static {v13, v6}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 303
    .line 304
    .line 305
    new-instance v12, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 306
    .line 307
    move/from16 v21, v0

    .line 308
    .line 309
    move-object/from16 v26, v10

    .line 310
    .line 311
    move-object/from16 v19, v2

    .line 312
    .line 313
    move/from16 v20, v14

    .line 314
    .line 315
    move/from16 v16, v5

    .line 316
    .line 317
    move v15, v7

    .line 318
    move-object v14, v6

    .line 319
    invoke-direct/range {v12 .. v26}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;-><init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZZLcom/facebook/aura/commands/alarm/Recurrence;JILjava/lang/String;)V

    .line 320
    .line 321
    .line 322
    return-object v12

    .line 323
    :cond_d
    invoke-virtual/range {v29 .. v29}, Ljava/lang/String;->length()I

    .line 324
    .line 325
    .line 326
    move-result v8

    .line 327
    if-lez v8, :cond_c

    .line 328
    .line 329
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 330
    .line 331
    .line 332
    move-result v8

    .line 333
    if-lez v8, :cond_c

    .line 334
    .line 335
    const-string v0, " cannot combine \'date\' (one-time) with \'days\' (recurring). Pick one, or set \'frequency\'."

    .line 336
    .line 337
    invoke-static {v1, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    throw v0

    .line 342
    :cond_e
    const/4 v2, 0x0

    .line 343
    goto :goto_6

    .line 344
    :cond_f
    invoke-static {v1, v4}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 345
    .line 346
    .line 347
    move-result-object v0

    .line 348
    throw v0

    .line 349
    :cond_10
    const-string v0, ".date must be a valid YYYY-MM-DD date"

    .line 350
    .line 351
    invoke-static {v1, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    throw v0

    .line 356
    :cond_11
    invoke-virtual {v0}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 357
    .line 358
    .line 359
    move-result-object v2

    .line 360
    if-eqz v2, :cond_12

    .line 361
    .line 362
    invoke-static {v1, v2, v12}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->mergeRecurrenceBounds(Ljava/lang/String;Lcom/facebook/aura/commands/alarm/Recurrence;Lkotlinx/serialization/json/JsonObject;)Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 363
    .line 364
    .line 365
    move-result-object v20

    .line 366
    if-eqz v20, :cond_12

    .line 367
    .line 368
    sget-object v17, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 369
    .line 370
    iget-wide v8, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->anchorMs:J

    .line 371
    .line 372
    invoke-static {v3}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    move-object/from16 v21, v17

    .line 376
    .line 377
    move-wide/from16 v22, v8

    .line 378
    .line 379
    move/from16 v24, v7

    .line 380
    .line 381
    move/from16 v25, v5

    .line 382
    .line 383
    move-object/from16 v26, v3

    .line 384
    .line 385
    invoke-virtual/range {v21 .. v26}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->reanchor(JIILjava/time/ZoneId;)J

    .line 386
    .line 387
    .line 388
    move-result-wide v26

    .line 389
    move/from16 v18, v7

    .line 390
    .line 391
    move/from16 v19, v5

    .line 392
    .line 393
    move-wide/from16 v23, v26

    .line 394
    .line 395
    move-object/from16 v25, v3

    .line 396
    .line 397
    move-wide/from16 v21, p0

    .line 398
    .line 399
    invoke-virtual/range {v17 .. v25}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeNextAfter$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(IILcom/facebook/aura/commands/alarm/Recurrence;JJLjava/time/ZoneId;)J

    .line 400
    .line 401
    .line 402
    move-result-wide v20

    .line 403
    cmp-long v2, v20, v15

    .line 404
    .line 405
    if-eqz v2, :cond_13

    .line 406
    .line 407
    iget-object v4, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 408
    .line 409
    iget-object v3, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->days:Ljava/lang/String;

    .line 410
    .line 411
    iget-boolean v2, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 412
    .line 413
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 414
    .line 415
    const/16 v28, 0x0

    .line 416
    .line 417
    move-object v15, v0

    .line 418
    move-object/from16 v16, v4

    .line 419
    .line 420
    move-object/from16 v17, v6

    .line 421
    .line 422
    move-object/from16 v22, v3

    .line 423
    .line 424
    move/from16 v23, v14

    .line 425
    .line 426
    move/from16 v24, v2

    .line 427
    .line 428
    move-object/from16 v25, v1

    .line 429
    .line 430
    :goto_7
    move-object/from16 v29, v10

    .line 431
    .line 432
    invoke-virtual/range {v15 .. v29}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->copy(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZZLcom/facebook/aura/commands/alarm/Recurrence;JILjava/lang/String;)Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 433
    .line 434
    .line 435
    move-result-object v12

    .line 436
    return-object v12

    .line 437
    :cond_12
    sget-object v15, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 438
    .line 439
    iget-wide v1, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 440
    .line 441
    invoke-static {v3}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 442
    .line 443
    .line 444
    move/from16 v16, v7

    .line 445
    .line 446
    move/from16 v17, v5

    .line 447
    .line 448
    move-wide/from16 v18, v1

    .line 449
    .line 450
    move-wide/from16 v20, p0

    .line 451
    .line 452
    move-object/from16 v22, v3

    .line 453
    .line 454
    invoke-virtual/range {v15 .. v22}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->computeOneTimeReschedule(IIJJLjava/time/ZoneId;)J

    .line 455
    .line 456
    .line 457
    move-result-wide v20

    .line 458
    iget-object v9, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 459
    .line 460
    iget-object v8, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->days:Ljava/lang/String;

    .line 461
    .line 462
    iget-boolean v4, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->inApp:Z

    .line 463
    .line 464
    iget-object v3, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 465
    .line 466
    iget-wide v1, v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->anchorMs:J

    .line 467
    .line 468
    const/16 v28, 0x0

    .line 469
    .line 470
    move-object v15, v0

    .line 471
    move-object/from16 v16, v9

    .line 472
    .line 473
    move-object/from16 v17, v6

    .line 474
    .line 475
    move/from16 v18, v7

    .line 476
    .line 477
    move/from16 v19, v5

    .line 478
    .line 479
    move-object/from16 v22, v8

    .line 480
    .line 481
    move/from16 v23, v14

    .line 482
    .line 483
    move/from16 v24, v4

    .line 484
    .line 485
    move-object/from16 v25, v3

    .line 486
    .line 487
    move-wide/from16 v26, v1

    .line 488
    .line 489
    goto :goto_7

    .line 490
    :cond_13
    invoke-static {v1, v4}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 491
    .line 492
    .line 493
    move-result-object v0

    .line 494
    throw v0

    .line 495
    :cond_14
    const-string v0, ".minutes must be an integer from 0 to 59"

    .line 496
    .line 497
    invoke-static {v1, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 498
    .line 499
    .line 500
    move-result-object v0

    .line 501
    throw v0

    .line 502
    :cond_15
    const-string v0, ".hour must be an integer from 0 to 23"

    .line 503
    .line 504
    invoke-static {v1, v0}, LX/003;->A0f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    .line 505
    .line 506
    .line 507
    move-result-object v0

    .line 508
    throw v0
.end method

.method public static final setAlarmsInOrder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;Ljava/util/List;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 42
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/AlarmSetRequest;",
            ">;",
            "Lcom/facebook/aura/commands/alarm/MuseActivityTracker;",
            "J",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/nodes/core/NodeCommandResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p7

    .line 1
    .line 2
    move-wide/from16 v40, p4

    .line 3
    .line 4
    move-object/from16 v14, p6

    .line 5
    .line 6
    move-object/from16 v13, p2

    .line 7
    .line 8
    move-object/from16 v12, p1

    .line 9
    .line 10
    move-object/from16 v9, p3

    .line 11
    .line 12
    move-object/from16 v2, p0

    .line 13
    .line 14
    instance-of v0, v5, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;

    .line 15
    .line 16
    if-eqz v0, :cond_b

    .line 17
    .line 18
    move-object v4, v5

    .line 19
    check-cast v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;

    .line 20
    .line 21
    iget v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 22
    .line 23
    const/high16 v1, -0x80000000

    .line 24
    .line 25
    and-int v0, v3, v1

    .line 26
    .line 27
    if-eqz v0, :cond_b

    .line 28
    .line 29
    sub-int/2addr v3, v1

    .line 30
    iput v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 31
    .line 32
    :goto_0
    iget-object v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->result:Ljava/lang/Object;

    .line 33
    .line 34
    sget-object v15, LX/2PB;->A02:LX/2PB;

    .line 35
    .line 36
    iget v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 37
    .line 38
    const/16 v20, 0x2

    .line 39
    .line 40
    const/16 v19, 0x1

    .line 41
    .line 42
    if-eqz v3, :cond_a

    .line 43
    .line 44
    move/from16 v1, v19

    .line 45
    .line 46
    if-eq v3, v1, :cond_9

    .line 47
    .line 48
    move/from16 v1, v20

    .line 49
    .line 50
    if-ne v3, v1, :cond_f

    .line 51
    .line 52
    iget v7, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$3:I

    .line 53
    .line 54
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$1:I

    .line 55
    .line 56
    move/from16 v18, v1

    .line 57
    .line 58
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$0:I

    .line 59
    .line 60
    move/from16 v17, v1

    .line 61
    .line 62
    iget-wide v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->J$0:J

    .line 63
    .line 64
    move-wide/from16 v40, v1

    .line 65
    .line 66
    iget-object v10, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$9:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v10, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 69
    .line 70
    iget-object v5, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$8:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 73
    .line 74
    iget-object v11, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$7:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v11, Ljava/util/Iterator;

    .line 77
    .line 78
    iget-object v6, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$6:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v6, Ljava/util/List;

    .line 81
    .line 82
    const/16 v34, 0x0

    .line 83
    .line 84
    iget-object v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$5:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v3, Ljava/util/List;

    .line 87
    .line 88
    iget-object v14, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$4:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v14, Ljava/lang/String;

    .line 91
    .line 92
    iget-object v9, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$3:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v9, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;

    .line 95
    .line 96
    iget-object v13, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$2:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v13, Ljava/util/List;

    .line 99
    .line 100
    iget-object v12, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v12, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 103
    .line 104
    iget-object v2, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$0:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v2, Landroid/content/Context;

    .line 107
    .line 108
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :cond_0
    invoke-interface {v6, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    if-eqz v7, :cond_8

    .line 115
    .line 116
    iget v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 117
    .line 118
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 119
    .line 120
    .line 121
    move-result-object v16

    .line 122
    iget v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 123
    .line 124
    invoke-static {v0}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object v8

    .line 128
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 131
    .line 132
    .line 133
    move-result v1

    .line 134
    const/4 v7, 0x0

    .line 135
    if-lez v1, :cond_1

    .line 136
    .line 137
    move-object v7, v0

    .line 138
    :cond_1
    new-instance v1, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;

    .line 139
    .line 140
    move-object/from16 v0, v16

    .line 141
    .line 142
    invoke-direct {v1, v0, v8, v7}, Lcom/facebook/aura/commands/alarm/ClockCardAlarm;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    invoke-interface {v3, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    const-string v22, "clock"

    .line 149
    .line 150
    :goto_1
    iget-object v0, v10, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 151
    .line 152
    iget v1, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 153
    .line 154
    invoke-static {v1}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 155
    .line 156
    .line 157
    move-result-object v7

    .line 158
    iget v1, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 159
    .line 160
    invoke-static {v1}, LX/3Rp;->A0s(I)Ljava/lang/Integer;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    filled-new-array {v7, v1}, [Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v5

    .line 168
    move/from16 v1, v20

    .line 169
    .line 170
    invoke-static {v5, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v5

    .line 174
    const-string v1, "%02d:%02d"

    .line 175
    .line 176
    invoke-static {v1, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v26

    .line 180
    const-string v21, "Alarm set ("

    .line 181
    .line 182
    const-string v23, "): id="

    .line 183
    .line 184
    const-string v25, " time="

    .line 185
    .line 186
    move-object/from16 v24, v0

    .line 187
    .line 188
    invoke-static/range {v21 .. v26}, LX/Gi8;->A11(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    const-string v0, "AlarmHandlers"

    .line 193
    .line 194
    invoke-static {v0, v1}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_c

    .line 202
    .line 203
    add-int/lit8 v7, v18, 0x1

    .line 204
    .line 205
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v5

    .line 209
    check-cast v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 210
    .line 211
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 212
    .line 213
    iget-boolean v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hasExplicitDate:Z

    .line 214
    .line 215
    invoke-static {v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->canHandOffToClock(Lcom/facebook/aura/commands/alarm/Recurrence;Z)Z

    .line 216
    .line 217
    .line 218
    move-result v8

    .line 219
    if-eqz v8, :cond_3

    .line 220
    .line 221
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 222
    .line 223
    .line 224
    move-result v0

    .line 225
    if-nez v0, :cond_3

    .line 226
    .line 227
    iput-object v2, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$0:Ljava/lang/Object;

    .line 228
    .line 229
    iput-object v12, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$1:Ljava/lang/Object;

    .line 230
    .line 231
    iput-object v13, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$2:Ljava/lang/Object;

    .line 232
    .line 233
    iput-object v9, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$3:Ljava/lang/Object;

    .line 234
    .line 235
    iput-object v14, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$4:Ljava/lang/Object;

    .line 236
    .line 237
    iput-object v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$5:Ljava/lang/Object;

    .line 238
    .line 239
    iput-object v6, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$6:Ljava/lang/Object;

    .line 240
    .line 241
    iput-object v11, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$7:Ljava/lang/Object;

    .line 242
    .line 243
    iput-object v5, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$8:Ljava/lang/Object;

    .line 244
    .line 245
    const/4 v0, 0x0

    .line 246
    iput-object v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$9:Ljava/lang/Object;

    .line 247
    .line 248
    move-wide/from16 v0, v40

    .line 249
    .line 250
    iput-wide v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->J$0:J

    .line 251
    .line 252
    move/from16 v0, v17

    .line 253
    .line 254
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$0:I

    .line 255
    .line 256
    iput v7, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$1:I

    .line 257
    .line 258
    move/from16 v0, v18

    .line 259
    .line 260
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$2:I

    .line 261
    .line 262
    iput-boolean v8, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->Z$0:Z

    .line 263
    .line 264
    move/from16 v0, v19

    .line 265
    .line 266
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 267
    .line 268
    move-wide/from16 v0, v40

    .line 269
    .line 270
    invoke-static {v2, v9, v0, v1, v4}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->awaitClockHandoff(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLX/2M4;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    if-eq v0, v15, :cond_2

    .line 275
    .line 276
    const/4 v8, 0x1

    .line 277
    :goto_3
    check-cast v0, Lcom/facebook/aura/commands/alarm/ClockHandoffStop;

    .line 278
    .line 279
    if-eqz v0, :cond_3

    .line 280
    .line 281
    move/from16 v1, v18

    .line 282
    .line 283
    invoke-static {v13, v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->clockHandoffInterruptedMessage(Ljava/util/List;ILcom/facebook/aura/commands/alarm/ClockHandoffStop;)Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v36

    .line 287
    const/16 v35, 0x0

    .line 288
    .line 289
    new-instance v15, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 290
    .line 291
    move-object/from16 v33, v15

    .line 292
    .line 293
    move-object/from16 v37, v35

    .line 294
    .line 295
    move-object/from16 v38, v35

    .line 296
    .line 297
    invoke-direct/range {v33 .. v38}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 298
    .line 299
    .line 300
    :cond_2
    return-object v15

    .line 301
    :cond_3
    move/from16 v39, v18

    .line 302
    .line 303
    move/from16 v18, v7

    .line 304
    .line 305
    if-eqz v8, :cond_4

    .line 306
    .line 307
    invoke-static {v2, v5}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->tryHandOffToClockApp(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AlarmSetRequest;)Z

    .line 308
    .line 309
    .line 310
    move-result v0

    .line 311
    const/4 v7, 0x1

    .line 312
    if-nez v0, :cond_5

    .line 313
    .line 314
    :cond_4
    const/4 v7, 0x0

    .line 315
    :cond_5
    invoke-static {}, LX/007;->A0z()Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object v22

    .line 319
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 320
    .line 321
    move-object/from16 v38, v0

    .line 322
    .line 323
    iget v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 324
    .line 325
    move/from16 v24, v0

    .line 326
    .line 327
    iget v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 328
    .line 329
    move/from16 v25, v0

    .line 330
    .line 331
    iget-wide v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->triggerTimeMs:J

    .line 332
    .line 333
    move-wide/from16 v28, v0

    .line 334
    .line 335
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->days:Ljava/lang/String;

    .line 336
    .line 337
    move-object/from16 v23, v0

    .line 338
    .line 339
    iget-boolean v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->vibrate:Z

    .line 340
    .line 341
    move/from16 v21, v0

    .line 342
    .line 343
    xor-int/lit8 v30, v7, 0x1

    .line 344
    .line 345
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->recurrence:Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 346
    .line 347
    move-object/from16 v16, v0

    .line 348
    .line 349
    iget-wide v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->anchorMs:J

    .line 350
    .line 351
    move-wide/from16 v35, v0

    .line 352
    .line 353
    iget-object v0, v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->timezone:Ljava/lang/String;

    .line 354
    .line 355
    const/16 v37, 0x0

    .line 356
    .line 357
    new-instance v10, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 358
    .line 359
    move-wide/from16 v26, v28

    .line 360
    .line 361
    move-object/from16 v28, v23

    .line 362
    .line 363
    move/from16 v29, v21

    .line 364
    .line 365
    move-object/from16 v31, v16

    .line 366
    .line 367
    move-wide/from16 v32, v35

    .line 368
    .line 369
    move-object/from16 v35, v0

    .line 370
    .line 371
    move-object/from16 v21, v10

    .line 372
    .line 373
    move-object/from16 v23, v38

    .line 374
    .line 375
    invoke-direct/range {v21 .. v35}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;-><init>(Ljava/lang/String;Ljava/lang/String;IIJLjava/lang/String;ZZLcom/facebook/aura/commands/alarm/Recurrence;JILjava/lang/String;)V

    .line 376
    .line 377
    .line 378
    if-nez v7, :cond_7

    .line 379
    .line 380
    sget-object v0, Lcom/facebook/aura/nodes/api/HatchClientCapabilities;->INSTANCE:Lcom/facebook/aura/nodes/api/HatchClientCapabilities;

    .line 381
    .line 382
    invoke-virtual {v0}, Lcom/facebook/aura/nodes/api/HatchClientCapabilities;->getSupportsInAppAlarms()Z

    .line 383
    .line 384
    .line 385
    move-result v0

    .line 386
    if-nez v0, :cond_6

    .line 387
    .line 388
    const-string v38, "This device can only set alarms in its Clock app: a time, optionally repeating on chosen weekdays (all seven for every day). It can\'t set a date, an interval such as every three days, or an end to the repeat."

    .line 389
    .line 390
    :goto_4
    new-instance v15, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 391
    .line 392
    move-object/from16 v35, v15

    .line 393
    .line 394
    move-object/from16 v39, v37

    .line 395
    .line 396
    move-object/from16 v40, v37

    .line 397
    .line 398
    move/from16 v36, v34

    .line 399
    .line 400
    invoke-direct/range {v35 .. v40}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 401
    .line 402
    .line 403
    return-object v15

    .line 404
    :cond_6
    sget-object v0, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->INSTANCE:Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;

    .line 405
    .line 406
    invoke-virtual {v0, v2, v10}, Lcom/facebook/aura/commands/alarm/HatchAlarmScheduler;->schedule$fbandroid_express_aura_java_com_facebook_aura_commands_alarm_alarm(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Z

    .line 407
    .line 408
    .line 409
    move-result v0

    .line 410
    if-nez v0, :cond_7

    .line 411
    .line 412
    const-string v38, "Failed to set alarm."

    .line 413
    .line 414
    goto :goto_4

    .line 415
    :cond_7
    iput-object v2, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$0:Ljava/lang/Object;

    .line 416
    .line 417
    iput-object v12, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$1:Ljava/lang/Object;

    .line 418
    .line 419
    iput-object v13, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$2:Ljava/lang/Object;

    .line 420
    .line 421
    iput-object v9, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$3:Ljava/lang/Object;

    .line 422
    .line 423
    iput-object v14, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$4:Ljava/lang/Object;

    .line 424
    .line 425
    iput-object v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$5:Ljava/lang/Object;

    .line 426
    .line 427
    iput-object v6, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$6:Ljava/lang/Object;

    .line 428
    .line 429
    iput-object v11, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$7:Ljava/lang/Object;

    .line 430
    .line 431
    iput-object v5, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$8:Ljava/lang/Object;

    .line 432
    .line 433
    iput-object v10, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$9:Ljava/lang/Object;

    .line 434
    .line 435
    move-wide/from16 v0, v40

    .line 436
    .line 437
    iput-wide v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->J$0:J

    .line 438
    .line 439
    move/from16 v0, v17

    .line 440
    .line 441
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$0:I

    .line 442
    .line 443
    move/from16 v0, v18

    .line 444
    .line 445
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$1:I

    .line 446
    .line 447
    move/from16 v0, v39

    .line 448
    .line 449
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$2:I

    .line 450
    .line 451
    iput-boolean v8, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->Z$0:Z

    .line 452
    .line 453
    iput v7, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$3:I

    .line 454
    .line 455
    move/from16 v0, v20

    .line 456
    .line 457
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 458
    .line 459
    invoke-virtual {v12, v10, v4}, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;->add(Lcom/facebook/aura/commands/alarm/ShadowAlarm;LX/2M4;)Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object v0

    .line 463
    if-ne v0, v15, :cond_0

    .line 464
    .line 465
    return-object v15

    .line 466
    :cond_8
    const/16 v17, 0x1

    .line 467
    .line 468
    const-string v22, "in-app"

    .line 469
    .line 470
    goto/16 :goto_1

    .line 471
    .line 472
    :cond_9
    const/16 v34, 0x0

    .line 473
    .line 474
    iget-boolean v8, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->Z$0:Z

    .line 475
    .line 476
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$2:I

    .line 477
    .line 478
    move/from16 v18, v1

    .line 479
    .line 480
    iget v7, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$1:I

    .line 481
    .line 482
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->I$0:I

    .line 483
    .line 484
    move/from16 v17, v1

    .line 485
    .line 486
    iget-wide v1, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->J$0:J

    .line 487
    .line 488
    move-wide/from16 v40, v1

    .line 489
    .line 490
    iget-object v5, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$8:Ljava/lang/Object;

    .line 491
    .line 492
    check-cast v5, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;

    .line 493
    .line 494
    iget-object v11, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$7:Ljava/lang/Object;

    .line 495
    .line 496
    check-cast v11, Ljava/util/Iterator;

    .line 497
    .line 498
    iget-object v6, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$6:Ljava/lang/Object;

    .line 499
    .line 500
    check-cast v6, Ljava/util/List;

    .line 501
    .line 502
    iget-object v3, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$5:Ljava/lang/Object;

    .line 503
    .line 504
    check-cast v3, Ljava/util/List;

    .line 505
    .line 506
    iget-object v14, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$4:Ljava/lang/Object;

    .line 507
    .line 508
    check-cast v14, Ljava/lang/String;

    .line 509
    .line 510
    iget-object v9, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$3:Ljava/lang/Object;

    .line 511
    .line 512
    check-cast v9, Lcom/facebook/aura/commands/alarm/MuseActivityTracker;

    .line 513
    .line 514
    iget-object v13, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$2:Ljava/lang/Object;

    .line 515
    .line 516
    check-cast v13, Ljava/util/List;

    .line 517
    .line 518
    iget-object v12, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$1:Ljava/lang/Object;

    .line 519
    .line 520
    check-cast v12, Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;

    .line 521
    .line 522
    iget-object v2, v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->L$0:Ljava/lang/Object;

    .line 523
    .line 524
    check-cast v2, Landroid/content/Context;

    .line 525
    .line 526
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 527
    .line 528
    .line 529
    goto/16 :goto_3

    .line 530
    .line 531
    :cond_a
    const/16 v34, 0x0

    .line 532
    .line 533
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 534
    .line 535
    .line 536
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 537
    .line 538
    .line 539
    move-result-object v3

    .line 540
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 541
    .line 542
    .line 543
    move-result-object v6

    .line 544
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 545
    .line 546
    .line 547
    move-result-object v11

    .line 548
    const/16 v18, 0x0

    .line 549
    .line 550
    const/16 v17, 0x0

    .line 551
    .line 552
    goto/16 :goto_2

    .line 553
    .line 554
    :cond_b
    new-instance v4, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;

    .line 555
    .line 556
    invoke-direct {v4, v5}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;-><init>(LX/2M4;)V

    .line 557
    .line 558
    .line 559
    goto/16 :goto_0

    .line 560
    .line 561
    :cond_c
    if-eqz v17, :cond_e

    .line 562
    .line 563
    new-instance v3, LX/BcB;

    .line 564
    .line 565
    invoke-direct {v3}, LX/BcB;-><init>()V

    .line 566
    .line 567
    .line 568
    const-string v1, "status"

    .line 569
    .line 570
    const-string v0, "success"

    .line 571
    .line 572
    invoke-static {v1, v0, v3}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 573
    .line 574
    .line 575
    const-string v1, "scheduled_in_app"

    .line 576
    .line 577
    invoke-static/range {v19 .. v19}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    invoke-static {v0, v1, v3}, LX/BgH;->A01(Ljava/lang/Boolean;Ljava/lang/String;LX/BcB;)V

    .line 582
    .line 583
    .line 584
    new-instance v2, LX/Bcq;

    .line 585
    .line 586
    invoke-direct {v2}, LX/Bcq;-><init>()V

    .line 587
    .line 588
    .line 589
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 590
    .line 591
    .line 592
    move-result-object v1

    .line 593
    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 594
    .line 595
    .line 596
    move-result v0

    .line 597
    if-eqz v0, :cond_d

    .line 598
    .line 599
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 600
    .line 601
    .line 602
    move-result-object v0

    .line 603
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;

    .line 604
    .line 605
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lkotlinx/serialization/json/JsonObject;

    .line 606
    .line 607
    .line 608
    move-result-object v0

    .line 609
    invoke-virtual {v2, v0}, LX/Bcq;->A03(Lkotlinx/serialization/json/JsonElement;)V

    .line 610
    .line 611
    .line 612
    goto :goto_5

    .line 613
    :cond_d
    invoke-virtual {v2}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 614
    .line 615
    .line 616
    move-result-object v1

    .line 617
    const-string v0, "alarms"

    .line 618
    .line 619
    invoke-static {v0, v1, v3}, LX/IEb;->A04(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;LX/BcB;)Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 620
    .line 621
    .line 622
    move-result-object v15

    .line 623
    return-object v15

    .line 624
    :cond_e
    const-string v1, "set"

    .line 625
    .line 626
    invoke-static {v2}, Lcom/facebook/aura/nodes/core/DeviceDisplayNameKt;->localDeviceDisplayName(Landroid/content/Context;)Ljava/lang/String;

    .line 627
    .line 628
    .line 629
    move-result-object v0

    .line 630
    invoke-static {v1, v3, v0, v14}, Lcom/facebook/aura/commands/alarm/ClockCardInstructionKt;->clockCardEnvelope(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 631
    .line 632
    .line 633
    move-result-object v4

    .line 634
    const/4 v2, 0x0

    .line 635
    new-instance v15, Lcom/facebook/aura/nodes/core/NodeCommandResponse;

    .line 636
    .line 637
    move-object v0, v15

    .line 638
    move/from16 v1, v19

    .line 639
    .line 640
    move-object v3, v2

    .line 641
    move-object v5, v2

    .line 642
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/nodes/core/NodeCommandResponse;-><init>(ZLkotlinx/serialization/json/JsonElement;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 643
    .line 644
    .line 645
    return-object v15

    .line 646
    :cond_f
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 647
    .line 648
    .line 649
    move-result-object v0

    .line 650
    throw v0
.end method

.method public static final toListEntryJson(Lcom/facebook/aura/commands/alarm/ShadowAlarm;)Lkotlinx/serialization/json/JsonObject;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v2, LX/BcB;

    .line 5
    .line 6
    invoke-direct {v2}, LX/BcB;-><init>()V

    .line 7
    .line 8
    .line 9
    const-string v1, "id"

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->id:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 14
    .line 15
    .line 16
    const-string v1, "label"

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->label:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 21
    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->hour:I

    .line 24
    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const-string v0, "hour"

    .line 30
    .line 31
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 32
    .line 33
    .line 34
    iget v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->minute:I

    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v0, "minute"

    .line 41
    .line 42
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 43
    .line 44
    .line 45
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 46
    .line 47
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const-string v0, "trigger_time_ms"

    .line 52
    .line 53
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 54
    .line 55
    .line 56
    iget-wide v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->triggerTimeMs:J

    .line 57
    .line 58
    invoke-static {v0, v1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-virtual {v1, v0}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    sget-object v0, Ljava/time/format/DateTimeFormatter;->ISO_OFFSET_DATE_TIME:Ljava/time/format/DateTimeFormatter;

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Ljava/time/ZonedDateTime;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    const-string v0, "trigger_time_iso"

    .line 77
    .line 78
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 79
    .line 80
    .line 81
    const-string v1, "days"

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->days:Ljava/lang/String;

    .line 84
    .line 85
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 86
    .line 87
    .line 88
    new-instance v3, LX/Bcq;

    .line 89
    .line 90
    invoke-direct {v3}, LX/Bcq;-><init>()V

    .line 91
    .line 92
    .line 93
    sget-object v1, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->INSTANCE:Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;

    .line 94
    .line 95
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->days:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {v1, v0}, Lcom/facebook/aura/commands/alarm/AlarmTimeUtil;->weekdayNames(Ljava/lang/String;)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_0

    .line 110
    .line 111
    invoke-static {v1}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-static {v0, v3}, LX/BgH;->A06(Ljava/lang/String;LX/Bcq;)V

    .line 116
    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_0
    invoke-virtual {v3}, LX/Bcq;->A02()Lkotlinx/serialization/json/JsonArray;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    const-string v0, "days_weekdays"

    .line 124
    .line 125
    invoke-virtual {v2, v0, v1}, LX/BcB;->A07(Ljava/lang/String;Lkotlinx/serialization/json/JsonElement;)V

    .line 126
    .line 127
    .line 128
    iget-boolean v0, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->vibrate:Z

    .line 129
    .line 130
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    const-string v0, "vibrate"

    .line 135
    .line 136
    invoke-static {v1, v0, v2}, LX/BgH;->A01(Ljava/lang/Boolean;Ljava/lang/String;LX/BcB;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {p0}, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->effectiveRecurrence()Lcom/facebook/aura/commands/alarm/Recurrence;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    if-eqz v3, :cond_2

    .line 144
    .line 145
    iget-object v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->frequency:Lcom/facebook/aura/commands/alarm/RecurrenceFrequency;

    .line 146
    .line 147
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    const-string v0, "frequency"

    .line 152
    .line 153
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 154
    .line 155
    .line 156
    iget v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->interval:I

    .line 157
    .line 158
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    const-string v0, "interval"

    .line 163
    .line 164
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 165
    .line 166
    .line 167
    iget-object v1, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->count:Ljava/lang/Integer;

    .line 168
    .line 169
    if-eqz v1, :cond_1

    .line 170
    .line 171
    const-string v0, "count"

    .line 172
    .line 173
    invoke-static {v1, v0, v2}, LX/BgH;->A02(Ljava/lang/Number;Ljava/lang/String;LX/BcB;)V

    .line 174
    .line 175
    .line 176
    :cond_1
    iget-object v0, v3, Lcom/facebook/aura/commands/alarm/Recurrence;->until:Ljava/lang/Long;

    .line 177
    .line 178
    if-eqz v0, :cond_2

    .line 179
    .line 180
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 181
    .line 182
    .line 183
    move-result-wide v0

    .line 184
    invoke-static {v0, v1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    const-string v0, "until"

    .line 193
    .line 194
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 195
    .line 196
    .line 197
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/ShadowAlarm;->timezone:Ljava/lang/String;

    .line 198
    .line 199
    if-eqz v1, :cond_3

    .line 200
    .line 201
    const-string v0, "timezone"

    .line 202
    .line 203
    invoke-static {v0, v1, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 204
    .line 205
    .line 206
    :cond_3
    const-string v1, "type"

    .line 207
    .line 208
    const-string v0, "ALARM"

    .line 209
    .line 210
    invoke-static {v1, v0, v2}, LX/BgH;->A03(Ljava/lang/String;Ljava/lang/String;LX/BcB;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v2}, LX/BcB;->A06()Lkotlinx/serialization/json/JsonObject;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    return-object v0
.end method

.method public static final tryHandOffToClockApp(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AlarmSetRequest;)Z
    .locals 3

    .line 0
    const-string v0, "android.intent.action.SET_ALARM"

    .line 1
    .line 2
    new-instance v2, Landroid/content/Intent;

    .line 3
    .line 4
    invoke-direct {v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    const/16 v0, 0x1f

    .line 8
    .line 9
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget v0, p1, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->hour:I

    .line 14
    .line 15
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 16
    .line 17
    .line 18
    const/16 v0, 0x21

    .line 19
    .line 20
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget v0, p1, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->minute:I

    .line 25
    .line 26
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 27
    .line 28
    .line 29
    iget-object v1, p1, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->label:Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-lez v0, :cond_0

    .line 36
    .line 37
    const/16 v0, 0x20

    .line 38
    .line 39
    invoke-static {v0}, LX/601;->A00(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 44
    .line 45
    .line 46
    :cond_0
    const-string v1, "android.intent.extra.alarm.VIBRATE"

    .line 47
    .line 48
    iget-boolean v0, p1, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->vibrate:Z

    .line 49
    .line 50
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 51
    .line 52
    .line 53
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/AlarmSetRequest;->days:Ljava/lang/String;

    .line 54
    .line 55
    invoke-static {v0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->parseDays(Ljava/lang/String;)Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_1

    .line 64
    .line 65
    invoke-static {v1}, LX/001;->A13(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const-string v0, "android.intent.extra.alarm.DAYS"

    .line 70
    .line 71
    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putIntegerArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    .line 72
    .line 73
    .line 74
    :cond_1
    const-string v0, "android.intent.extra.alarm.SKIP_UI"

    .line 75
    .line 76
    const/4 v1, 0x1

    .line 77
    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 78
    .line 79
    .line 80
    const/high16 v0, 0x10000000

    .line 81
    .line 82
    invoke-virtual {v2, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 83
    .line 84
    .line 85
    :try_start_0
    invoke-virtual {p0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 86
    .line 87
    .line 88
    return v1
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 89
    :catch_0
    move-exception v2

    .line 90
    const-string v1, "No Clock app handles ACTION_SET_ALARM; falling back to in-app alarm"

    .line 91
    .line 92
    const-string v0, "AlarmHandlers"

    .line 93
    .line 94
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 95
    .line 96
    .line 97
    const/4 v0, 0x0

    .line 98
    return v0
.end method
