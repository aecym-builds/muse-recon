.class public final Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

.field public static final KEY_REMINDERS:Ljava/lang/String; = "reminders"

.field public static final PREFS_NAME:Ljava/lang/String; = "aura_reminder_shadow"

.field public static final SERIALIZER:LX/DZ7;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DZ7<",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final TAG:Ljava/lang/String; = "AuraReminderShadowStore"

.field public static volatile instance:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;


# instance fields
.field public final mutex:LX/3Hh;

.field public final prefs:Landroid/content/SharedPreferences;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->Companion:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$Companion;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->$childSerializers:[Lkotlin/Lazy;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/commands/alarm/ShadowReminder$$serializer;->INSTANCE:Lcom/facebook/aura/commands/alarm/ShadowReminder$$serializer;

    .line 10
    .line 11
    invoke-static {v0}, LX/DZ8;->A01(LX/DZ7;)LX/Dbs;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->SERIALIZER:LX/DZ7;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(Landroid/content/SharedPreferences;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->prefs:Landroid/content/SharedPreferences;

    .line 268435460
    .line 268435461
    new-instance v0, LX/DSP;

    .line 268435462
    .line 268435463
    invoke-direct {v0}, LX/DSP;-><init>()V

    .line 268435464
    .line 268435465
    .line 268435466
    iput-object v0, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 268435467
    .line 268435468
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/SharedPreferences;LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;-><init>(Landroid/content/SharedPreferences;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getInstance$cp()Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->instance:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$setInstance$cp(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;)V
    .locals 0

    .line 0
    sput-object p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->instance:Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;

    .line 1
    .line 2
    return-void
.end method

.method private final readUnlocked()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->prefs:Landroid/content/SharedPreferences;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    const-string v3, "reminders"

    .line 4
    .line 5
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-nez v2, :cond_0

    .line 10
    .line 11
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_0
    :try_start_0
    sget-object v1, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->SERIALIZER:LX/DZ7;

    .line 17
    .line 18
    invoke-virtual {v1, v2, v0}, LX/Dcb;->A00(Ljava/lang/String;LX/Dci;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Ljava/util/List;

    .line 23
    .line 24
    return-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :catch_0
    move-exception v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const-string v0, "Corrupt shadow reminders, resetting: "

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const-string v0, "AuraReminderShadowStore"

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->prefs:Landroid/content/SharedPreferences;

    .line 42
    .line 43
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-interface {v0, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 52
    .line 53
    .line 54
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 55
    .line 56
    return-object v0
.end method

.method private final writeUnlocked(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->prefs:Landroid/content/SharedPreferences;

    .line 1
    .line 2
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    sget-object v1, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->SERIALIZER:LX/DZ7;

    .line 9
    .line 10
    invoke-virtual {v1, p1, v0}, LX/Dcb;->A02(Ljava/lang/Object;LX/DZE;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v0, "reminders"

    .line 15
    .line 16
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final add(Lcom/facebook/aura/commands/alarm/ShadowReminder;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->label:I

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v5, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v5, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 37
    .line 38
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    new-instance v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;

    .line 43
    .line 44
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iget-object v5, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 57
    .line 58
    iput-object p1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object v5, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->L$1:Ljava/lang/Object;

    .line 61
    .line 62
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$add$1;->label:I

    .line 63
    .line 64
    invoke-interface {v5, v6, v4}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-ne v0, v2, :cond_3

    .line 69
    .line 70
    return-object v2

    .line 71
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_4

    .line 88
    .line 89
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    move-object v0, v2

    .line 94
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 95
    .line 96
    iget-object v1, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 97
    .line 98
    iget-object v0, p1, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 99
    .line 100
    invoke-static {v1, v0, v2, v4}, LX/3Rs;->A17(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 101
    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_4
    invoke-static {p1, v4}, LX/B89;->A0d(Ljava/lang/Object;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-direct {p0, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->writeUnlocked(Ljava/util/List;)V

    .line 109
    .line 110
    .line 111
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 112
    .line 113
    invoke-interface {v5, v6}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    return-object v2

    .line 117
    :catchall_0
    move-exception v0

    .line 118
    invoke-interface {v5, v6}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    throw v0
.end method

.method public final addAll(Ljava/util/List;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x0

    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_1

    .line 29
    .line 30
    iget-object v4, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v4, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Ljava/util/List;

    .line 37
    .line 38
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    new-instance v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;

    .line 43
    .line 44
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 63
    .line 64
    return-object v2

    .line 65
    :cond_3
    iget-object v4, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 66
    .line 67
    iput-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput-object v4, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    iput v1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$addAll$1;->label:I

    .line 72
    .line 73
    invoke-interface {v4, v5, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-ne v0, v2, :cond_4

    .line 78
    .line 79
    return-object v2

    .line 80
    :cond_4
    :goto_1
    :try_start_0
    invoke-static {}, LX/001;->A15()Ljava/util/HashSet;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-eqz v0, :cond_5

    .line 93
    .line 94
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 99
    .line 100
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 101
    .line 102
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    goto :goto_2

    .line 106
    :cond_5
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    :cond_6
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_7

    .line 123
    .line 124
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    move-object v0, v1

    .line 129
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 130
    .line 131
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 132
    .line 133
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-nez v0, :cond_6

    .line 138
    .line 139
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    goto :goto_3

    .line 143
    :cond_7
    invoke-static {p1, v3}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-direct {p0, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->writeUnlocked(Ljava/util/List;)V

    .line 148
    .line 149
    .line 150
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 151
    .line 152
    invoke-interface {v4, v5}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    return-object v2

    .line 156
    :catchall_0
    move-exception v0

    .line 157
    invoke-interface {v4, v5}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    throw v0
.end method

.method public final clear(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->L$0:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, LX/3Hh;

    .line 33
    .line 34
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    new-instance v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;

    .line 39
    .line 40
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0

    .line 49
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 53
    .line 54
    iput-object v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->L$0:Ljava/lang/Object;

    .line 55
    .line 56
    iput v0, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$clear$1;->label:I

    .line 57
    .line 58
    invoke-interface {v1, v2, v5}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-ne v0, v3, :cond_3

    .line 63
    .line 64
    return-object v3

    .line 65
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 70
    .line 71
    invoke-direct {p0, v0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->writeUnlocked(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 72
    .line 73
    .line 74
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    return-object v3

    .line 78
    :catchall_0
    move-exception v0

    .line 79
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    throw v0
.end method

.method public final findById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v4, 0x0

    .line 26
    if-eqz v2, :cond_2

    .line 27
    .line 28
    if-ne v2, v0, :cond_1

    .line 29
    .line 30
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v3, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;

    .line 41
    .line 42
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    throw v0

    .line 51
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iget-object v3, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 55
    .line 56
    iput-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v3, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v0, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findById$1;->label:I

    .line 61
    .line 62
    invoke-interface {v3, v4, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-ne v0, v1, :cond_3

    .line 67
    .line 68
    return-object v1

    .line 69
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    :cond_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_5

    .line 82
    .line 83
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    move-object v0, v1

    .line 88
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 89
    .line 90
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    :goto_2
    check-cast v1, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_5
    move-object v1, v4

    .line 102
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 103
    :goto_3
    invoke-interface {v3, v4}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    return-object v1

    .line 107
    :catchall_0
    move-exception v0

    .line 108
    invoke-interface {v3, v4}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    throw v0
.end method

.method public final findByLabel(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v3, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v3, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;

    .line 41
    .line 42
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    throw v0

    .line 51
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iget-object v3, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 55
    .line 56
    iput-object p1, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v3, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v0, v6, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$findByLabel$1;->label:I

    .line 61
    .line 62
    invoke-interface {v3, v4, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-ne v0, v5, :cond_3

    .line 67
    .line 68
    return-object v5

    .line 69
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    :cond_4
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_5

    .line 86
    .line 87
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    move-object v0, v1

    .line 92
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 93
    .line 94
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->label:Ljava/lang/String;

    .line 95
    .line 96
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    if-eqz v0, :cond_4

    .line 101
    .line 102
    invoke-virtual {v5, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    goto :goto_2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 106
    :cond_5
    invoke-interface {v3, v4}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    return-object v5

    .line 110
    :catchall_0
    move-exception v0

    .line 111
    invoke-interface {v3, v4}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    throw v0
.end method

.method public final removeById(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v6, 0x0

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v5, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v5, LX/3Hh;

    .line 33
    .line 34
    iget-object p1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    new-instance v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;

    .line 41
    .line 42
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    throw v0

    .line 51
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iget-object v5, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 55
    .line 56
    iput-object p1, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v5, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v0, v4, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$removeById$1;->label:I

    .line 61
    .line 62
    invoke-interface {v5, v6, v4}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-ne v0, v2, :cond_3

    .line 67
    .line 68
    return-object v2

    .line 69
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    :cond_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_5

    .line 82
    .line 83
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    move-object v0, v4

    .line 88
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 89
    .line 90
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    :goto_2
    check-cast v4, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 99
    .line 100
    if-nez v4, :cond_6

    .line 101
    .line 102
    goto :goto_4

    .line 103
    :cond_5
    move-object v4, v6

    .line 104
    goto :goto_2

    .line 105
    :cond_6
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_7

    .line 118
    .line 119
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    move-object v0, v1

    .line 124
    check-cast v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;

    .line 125
    .line 126
    iget-object v0, v0, Lcom/facebook/aura/commands/alarm/ShadowReminder;->id:Ljava/lang/String;

    .line 127
    .line 128
    invoke-static {v0, p1, v1, v3}, LX/3Rs;->A17(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 129
    .line 130
    .line 131
    goto :goto_3

    .line 132
    :cond_7
    invoke-direct {p0, v3}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->writeUnlocked(Ljava/util/List;)V

    .line 133
    .line 134
    .line 135
    goto :goto_5

    .line 136
    :goto_4
    move-object v4, v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 137
    :goto_5
    invoke-interface {v5, v6}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    return-object v4

    .line 141
    :catchall_0
    move-exception v0

    .line 142
    invoke-interface {v5, v6}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    throw v0
.end method

.method public final snapshot(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "Lcom/facebook/aura/commands/alarm/ShadowReminder;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    if-ne v1, v0, :cond_1

    .line 29
    .line 30
    iget-object v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->L$0:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, LX/3Hh;

    .line 33
    .line 34
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    new-instance v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;

    .line 39
    .line 40
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;-><init>(Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;LX/2M4;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0

    .line 49
    :cond_2
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->mutex:LX/3Hh;

    .line 53
    .line 54
    iput-object v1, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->L$0:Ljava/lang/Object;

    .line 55
    .line 56
    iput v0, v5, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore$snapshot$1;->label:I

    .line 57
    .line 58
    invoke-interface {v1, v2, v5}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-ne v0, v3, :cond_3

    .line 63
    .line 64
    return-object v3

    .line 65
    :cond_3
    :goto_1
    :try_start_0
    invoke-direct {p0}, Lcom/facebook/aura/commands/alarm/AuraReminderShadowStore;->readUnlocked()Ljava/util/List;

    .line 66
    .line 67
    .line 68
    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 69
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    return-object v3

    .line 73
    :catchall_0
    move-exception v0

    .line 74
    invoke-interface {v1, v2}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    throw v0
.end method
