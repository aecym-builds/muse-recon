.class public abstract Lcom/facebook/aura/commands/alarm/HatchAlarmSchedulerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchAlarmScheduler"
