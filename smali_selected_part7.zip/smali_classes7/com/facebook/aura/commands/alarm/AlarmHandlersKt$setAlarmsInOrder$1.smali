.class public final Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.AlarmHandlersKt"
    f = "AlarmHandlers.kt"
    l = {
        0x12a,
        0x149
    }
    m = "setAlarmsInOrder"
    v = 0x2
.end annotation


# instance fields
.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public L$8:Ljava/lang/Object;

.field public L$9:Ljava/lang/Object;

.field public Z$0:Z

.field public label:I

.field public synthetic result:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1}, LX/Btl;-><init>(LX/2M4;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$setAlarmsInOrder$1;->label:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    const-wide/16 v4, 0x0

    .line 11
    .line 12
    move-object v1, v0

    .line 13
    move-object v2, v0

    .line 14
    move-object v3, v0

    .line 15
    move-object v6, v0

    .line 16
    invoke-static/range {v0 .. v7}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->setAlarmsInOrder(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/AuraAlarmShadowStore;Ljava/util/List;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLjava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method
