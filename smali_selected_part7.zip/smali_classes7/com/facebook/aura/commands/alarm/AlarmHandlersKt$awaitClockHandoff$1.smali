.class public final Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.commands.alarm.AlarmHandlersKt"
    f = "AlarmHandlers.kt"
    l = {
        0x19f,
        0x1a3
    }
    m = "awaitClockHandoff"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public J$1:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1}, LX/Btl;-><init>(LX/2M4;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt$awaitClockHandoff$1;->label:I

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    const-wide/16 v0, 0x0

    .line 11
    .line 12
    invoke-static {v2, v2, v0, v1, p0}, Lcom/facebook/aura/commands/alarm/AlarmHandlersKt;->awaitClockHandoff(Landroid/content/Context;Lcom/facebook/aura/commands/alarm/MuseActivityTracker;JLX/2M4;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method
