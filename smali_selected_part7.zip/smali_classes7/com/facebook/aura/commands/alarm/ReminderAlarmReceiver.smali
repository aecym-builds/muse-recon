.class public final Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver;
.super Landroid/content/BroadcastReceiver;
.source ""


# static fields
.field public static final ACTION_REMINDER_FIRE:Ljava/lang/String; = "com.facebook.aura.REMINDER_FIRE"

.field public static final ACTION_REMINDER_SNOOZE:Ljava/lang/String; = "com.facebook.aura.REMINDER_SNOOZE"

.field public static final Companion:Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$Companion;

.field public static final EXTRA_REMINDER_ID:Ljava/lang/String; = "reminder_id"

.field public static final EXTRA_REMINDER_LABEL:Ljava/lang/String; = "reminder_label"

.field public static final TAG:Ljava/lang/String; = "ReminderAlarmReceiver"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver;->Companion:Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    .line 0
    move-object v6, p2

    .line 1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    const-string v0, "com.facebook.aura.REMINDER_FIRE"

    .line 9
    .line 10
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    const-string v0, "com.facebook.aura.REMINDER_SNOOZE"

    .line 17
    .line 18
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    const-string v0, "reminder_id"

    .line 26
    .line 27
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    if-eqz v4, :cond_1

    .line 32
    .line 33
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    const/4 p0, 0x0

    .line 52
    invoke-static {v0, p0}, LX/8mk;->A14(LX/BqD;LX/Cbu;)LX/EQC;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    new-instance v1, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;

    .line 57
    .line 58
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/commands/alarm/ReminderAlarmReceiver$onReceive$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/BroadcastReceiver$PendingResult;Landroid/content/Intent;LX/2M4;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_1
    const-string v1, "Reminder "

    .line 66
    .line 67
    const-string v0, " with no id"

    .line 68
    .line 69
    invoke-static {v1, v3, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    const-string v0, "ReminderAlarmReceiver"

    .line 74
    .line 75
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    return-void
.end method
