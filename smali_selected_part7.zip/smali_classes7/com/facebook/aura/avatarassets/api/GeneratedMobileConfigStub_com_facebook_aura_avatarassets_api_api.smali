.class public interface abstract Lcom/facebook/aura/avatarassets/api/GeneratedMobileConfigStub_com_facebook_aura_avatarassets_api_api;
.super Ljava/lang/Object;
.source ""
