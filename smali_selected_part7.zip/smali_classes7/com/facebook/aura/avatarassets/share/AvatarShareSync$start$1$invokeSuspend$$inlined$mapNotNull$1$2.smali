.class public final Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $this_unsafeFlow:LX/39x;

.field public final synthetic this$0:Lcom/facebook/aura/avatarassets/share/AvatarShareSync;


# direct methods
.method public constructor <init>(LX/39x;Lcom/facebook/aura/avatarassets/share/AvatarShareSync;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;->$this_unsafeFlow:LX/39x;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;->this$0:Lcom/facebook/aura/avatarassets/share/AvatarShareSync;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 6

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v3, :cond_3

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v2, p0, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;->$this_unsafeFlow:LX/39x;

    .line 39
    .line 40
    check-cast p1, Lcom/facebook/aura/model/AvatarMedia;

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;->this$0:Lcom/facebook/aura/avatarassets/share/AvatarShareSync;

    .line 43
    .line 44
    invoke-static {v0, p1}, Lcom/facebook/aura/avatarassets/share/AvatarShareSync;->access$syncKey(Lcom/facebook/aura/avatarassets/share/AvatarShareSync;Lcom/facebook/aura/model/AvatarMedia;)Lcom/facebook/aura/avatarassets/share/AvatarShareSync$SyncKey;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    if-eqz v1, :cond_0

    .line 49
    .line 50
    const/4 v0, 0x0

    .line 51
    iput-object v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$0:Ljava/lang/Object;

    .line 52
    .line 53
    iput-object v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$1:Ljava/lang/Object;

    .line 54
    .line 55
    iput-object v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$2:Ljava/lang/Object;

    .line 56
    .line 57
    iput-object v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$3:Ljava/lang/Object;

    .line 58
    .line 59
    iput-object v0, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->L$4:Ljava/lang/Object;

    .line 60
    .line 61
    iput v3, v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;->label:I

    .line 62
    .line 63
    invoke-interface {v2, v1, v5}, LX/39x;->emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    if-ne v0, v4, :cond_0

    .line 68
    .line 69
    return-object v4

    .line 70
    :cond_2
    new-instance v5, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;

    .line 71
    .line 72
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2$1;-><init>(Lcom/facebook/aura/avatarassets/share/AvatarShareSync$start$1$invokeSuspend$$inlined$mapNotNull$1$2;LX/2M4;)V

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    throw v0
.end method
