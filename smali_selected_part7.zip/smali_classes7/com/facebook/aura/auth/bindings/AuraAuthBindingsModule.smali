.class public final Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule;->INSTANCE:Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final provideFlipperLiveDataProvider()Lcom/facebook/reactivesocket/flipper/common/FlipperLiveDataProvider;
    .locals 1

    .line 0
    const-string v0, "FlipperLiveDataProvider not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideLoggedInMcUserId()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getCurrentSession()LX/AHE;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast v0, LX/AHu;

    .line 9
    .line 10
    iget-object v0, v0, LX/AHu;->A01:Ljava/lang/String;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    return-object v0
.end method

.method public static final provideLoggedInUserId()Ljava/lang/String;
    .locals 1

    .line 0
    const-string v0, "LoggedInUserId not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final provideViewerContextFactory()Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule$provideViewerContextFactory$1;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule$provideViewerContextFactory$1;->INSTANCE:Lcom/facebook/aura/auth/bindings/AuraAuthBindingsModule$provideViewerContextFactory$1;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final provideViewerContextUserIdProvider()LX/IXn;
    .locals 1

    .line 0
    const-string v0, "ViewerContextUserIdProvider not available in Aura"

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    throw v0
.end method

.method public static final providerViewerContext()Lcom/facebook/auth/viewercontext/ViewerContext;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/auth/viewercontext/ViewerContext;->A0D:Lcom/facebook/auth/viewercontext/ViewerContext;

    .line 1
    .line 2
    invoke-static {v0}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method
