.class public interface abstract Lcom/facebook/aura/auth/deviceid/usdid/GeneratedMobileConfigStub_com_facebook_aura_auth_deviceid_usdid_usdid;
.super Ljava/lang/Object;
.source ""
