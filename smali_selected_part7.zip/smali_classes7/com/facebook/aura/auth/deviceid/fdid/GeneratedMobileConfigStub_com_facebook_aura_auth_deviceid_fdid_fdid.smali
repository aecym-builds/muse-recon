.class public interface abstract Lcom/facebook/aura/auth/deviceid/fdid/GeneratedMobileConfigStub_com_facebook_aura_auth_deviceid_fdid_fdid;
.super Ljava/lang/Object;
.source ""
