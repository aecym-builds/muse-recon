.class public interface abstract Lcom/facebook/aura/auth/deviceid/datr/GeneratedMobileConfigStub_com_facebook_aura_auth_deviceid_datr_datr;
.super Ljava/lang/Object;
.source ""
