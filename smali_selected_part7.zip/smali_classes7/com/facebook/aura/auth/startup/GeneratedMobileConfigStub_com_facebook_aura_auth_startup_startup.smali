.class public interface abstract Lcom/facebook/aura/auth/startup/GeneratedMobileConfigStub_com_facebook_aura_auth_startup_startup;
.super Ljava/lang/Object;
.source ""
