.class public final Lcom/facebook/aura/auth/recovery/AccountRecoveryFlow$TaggedEffect;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final attemptId:I

.field public final effect:Lcom/facebook/aura/auth/recovery/AccountRecoveryEffect;


# direct methods
.method public constructor <init>(ILcom/facebook/aura/auth/recovery/AccountRecoveryEffect;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/auth/recovery/AccountRecoveryFlow$TaggedEffect;->attemptId:I

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/auth/recovery/AccountRecoveryFlow$TaggedEffect;->effect:Lcom/facebook/aura/auth/recovery/AccountRecoveryEffect;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getAttemptId()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/auth/recovery/AccountRecoveryFlow$TaggedEffect;->attemptId:I

    .line 1
    .line 2
    return p0
.end method

.method public final getEffect()Lcom/facebook/aura/auth/recovery/AccountRecoveryEffect;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/auth/recovery/AccountRecoveryFlow$TaggedEffect;->effect:Lcom/facebook/aura/auth/recovery/AccountRecoveryEffect;

    .line 1
    .line 2
    return-object p0
.end method
