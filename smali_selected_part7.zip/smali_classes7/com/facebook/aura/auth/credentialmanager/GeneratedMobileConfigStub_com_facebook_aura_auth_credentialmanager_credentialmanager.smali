.class public interface abstract Lcom/facebook/aura/auth/credentialmanager/GeneratedMobileConfigStub_com_facebook_aura_auth_credentialmanager_credentialmanager;
.super Ljava/lang/Object;
.source ""
