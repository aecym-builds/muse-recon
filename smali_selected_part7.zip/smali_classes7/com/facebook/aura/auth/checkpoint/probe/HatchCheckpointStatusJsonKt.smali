.class public abstract Lcom/facebook/aura/auth/checkpoint/probe/HatchCheckpointStatusJsonKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEFAULT_RECHECK_SECONDS:I = 0x12c
