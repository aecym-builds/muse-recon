.class public interface abstract Lcom/facebook/aura/auth/login/nativeflow/GeneratedMobileConfigStub_com_facebook_aura_auth_login_nativeflow_api;
.super Ljava/lang/Object;
.source ""
