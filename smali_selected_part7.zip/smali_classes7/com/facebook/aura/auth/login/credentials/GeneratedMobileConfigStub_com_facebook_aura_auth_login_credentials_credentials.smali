.class public interface abstract Lcom/facebook/aura/auth/login/credentials/GeneratedMobileConfigStub_com_facebook_aura_auth_login_credentials_credentials;
.super Ljava/lang/Object;
.source ""
