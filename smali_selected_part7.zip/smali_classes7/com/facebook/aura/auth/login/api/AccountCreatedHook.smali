.class public interface abstract Lcom/facebook/aura/auth/login/api/AccountCreatedHook;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onAccountCreated()V
.end method
