.class public interface abstract Lcom/facebook/aura/attribution/GeneratedMobileConfigStub_com_facebook_aura_attribution_attribution;
.super Ljava/lang/Object;
.source ""
