.class public abstract Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmRvKeyKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final RV_KEY_SIZE_BYTES:I = 0x20
