.class public abstract Lcom/facebook/aura/confidentialvm/repository/ConfidentialVmOperatorSshJsonKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final SSH_OPERATOR_STATUS_DISABLED:I = 0x1

.field public static final SSH_OPERATOR_STATUS_ENABLED:I = 0x2
