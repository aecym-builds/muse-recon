.class public interface abstract Lcom/facebook/aura/confidentialvm/model/GeneratedMobileConfigStub_com_facebook_aura_confidentialvm_model_model;
.super Ljava/lang/Object;
.source ""
