.class public interface abstract Lcom/facebook/aura/avatarsize/GeneratedMobileConfigStub_com_facebook_aura_avatarsize_avatarsize;
.super Ljava/lang/Object;
.source ""
