.class public final Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitch;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitch;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitch;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitch;->INSTANCE:Lcom/facebook/aura/analytics/plugins/implementations/AnalyticsImplementationsKillSwitch;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final isEnabled()Z
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    return v0
.end method
