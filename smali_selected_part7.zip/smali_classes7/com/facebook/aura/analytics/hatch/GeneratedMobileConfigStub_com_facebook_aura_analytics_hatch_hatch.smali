.class public interface abstract Lcom/facebook/aura/analytics/hatch/GeneratedMobileConfigStub_com_facebook_aura_analytics_hatch_hatch;
.super Ljava/lang/Object;
.source ""
