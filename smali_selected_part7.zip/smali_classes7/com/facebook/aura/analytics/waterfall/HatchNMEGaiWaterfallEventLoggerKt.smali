.class public abstract Lcom/facebook/aura/analytics/waterfall/HatchNMEGaiWaterfallEventLoggerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchNMEGaiWaterfallEventLogger"
