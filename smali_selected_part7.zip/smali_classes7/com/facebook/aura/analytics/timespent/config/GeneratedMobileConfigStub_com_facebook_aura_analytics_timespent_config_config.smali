.class public interface abstract Lcom/facebook/aura/analytics/timespent/config/GeneratedMobileConfigStub_com_facebook_aura_analytics_timespent_config_config;
.super Ljava/lang/Object;
.source ""
