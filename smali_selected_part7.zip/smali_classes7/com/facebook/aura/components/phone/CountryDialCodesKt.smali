.class public abstract Lcom/facebook/aura/components/phone/CountryDialCodesKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final COUNTRY_DIAL_CODES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/phone/CountryDialCode;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_COUNTRY_DIAL_CODE:Lcom/facebook/aura/components/phone/CountryDialCode;

.field public static final MAX_PHONE_NUMBER_DIGITS:I = 0xf


# direct methods
.method public static constructor <clinit>()V
    .locals 34

    .line 0
    const-string v2, "US"

    .line 1
    .line 2
    const/4 v1, 0x1

    .line 3
    invoke-static {v2, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lcom/facebook/aura/components/phone/CountryDialCodesKt;->DEFAULT_COUNTRY_DIAL_CODE:Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 8
    .line 9
    const/16 v4, 0xe5

    .line 10
    .line 11
    new-array v5, v4, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 12
    .line 13
    const-string v0, "CA"

    .line 14
    .line 15
    invoke-static {v0, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 16
    .line 17
    .line 18
    move-result-object v6

    .line 19
    invoke-static {v2, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 20
    .line 21
    .line 22
    move-result-object v7

    .line 23
    const-string v0, "KZ"

    .line 24
    .line 25
    const/4 v1, 0x7

    .line 26
    invoke-static {v0, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 27
    .line 28
    .line 29
    move-result-object v8

    .line 30
    const-string v0, "RU"

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 33
    .line 34
    .line 35
    move-result-object v9

    .line 36
    const-string v1, "EG"

    .line 37
    .line 38
    const/16 v0, 0x14

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 41
    .line 42
    .line 43
    move-result-object v10

    .line 44
    const-string v0, "ZA"

    .line 45
    .line 46
    const/16 v2, 0x1b

    .line 47
    .line 48
    invoke-static {v0, v2}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 49
    .line 50
    .line 51
    move-result-object v11

    .line 52
    const-string v1, "GR"

    .line 53
    .line 54
    const/16 v0, 0x1e

    .line 55
    .line 56
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 57
    .line 58
    .line 59
    move-result-object v12

    .line 60
    const-string v1, "NL"

    .line 61
    .line 62
    const/16 v0, 0x1f

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 65
    .line 66
    .line 67
    move-result-object v13

    .line 68
    const-string v1, "BE"

    .line 69
    .line 70
    const/16 v0, 0x20

    .line 71
    .line 72
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 73
    .line 74
    .line 75
    move-result-object v14

    .line 76
    const-string v1, "FR"

    .line 77
    .line 78
    const/16 v0, 0x21

    .line 79
    .line 80
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 81
    .line 82
    .line 83
    move-result-object v15

    .line 84
    const-string v1, "ES"

    .line 85
    .line 86
    const/16 v0, 0x22

    .line 87
    .line 88
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 89
    .line 90
    .line 91
    move-result-object v16

    .line 92
    const-string v1, "HU"

    .line 93
    .line 94
    const/16 v0, 0x24

    .line 95
    .line 96
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 97
    .line 98
    .line 99
    move-result-object v17

    .line 100
    const-string v1, "IT"

    .line 101
    .line 102
    const/16 v0, 0x27

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 105
    .line 106
    .line 107
    move-result-object v18

    .line 108
    const-string v1, "RO"

    .line 109
    .line 110
    const/16 v0, 0x28

    .line 111
    .line 112
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 113
    .line 114
    .line 115
    move-result-object v19

    .line 116
    const-string v1, "CH"

    .line 117
    .line 118
    const/16 v0, 0x29

    .line 119
    .line 120
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 121
    .line 122
    .line 123
    move-result-object v20

    .line 124
    const-string v1, "AT"

    .line 125
    .line 126
    const/16 v0, 0x2b

    .line 127
    .line 128
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 129
    .line 130
    .line 131
    move-result-object v21

    .line 132
    const-string v1, "GB"

    .line 133
    .line 134
    const/16 v0, 0x2c

    .line 135
    .line 136
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 137
    .line 138
    .line 139
    move-result-object v22

    .line 140
    const-string v1, "DK"

    .line 141
    .line 142
    const/16 v0, 0x2d

    .line 143
    .line 144
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 145
    .line 146
    .line 147
    move-result-object v23

    .line 148
    const-string v1, "SE"

    .line 149
    .line 150
    const/16 v0, 0x2e

    .line 151
    .line 152
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 153
    .line 154
    .line 155
    move-result-object v24

    .line 156
    const-string v1, "NO"

    .line 157
    .line 158
    const/16 v0, 0x2f

    .line 159
    .line 160
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 161
    .line 162
    .line 163
    move-result-object v25

    .line 164
    const-string v1, "PL"

    .line 165
    .line 166
    const/16 v0, 0x30

    .line 167
    .line 168
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 169
    .line 170
    .line 171
    move-result-object v26

    .line 172
    const-string v1, "DE"

    .line 173
    .line 174
    const/16 v0, 0x31

    .line 175
    .line 176
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 177
    .line 178
    .line 179
    move-result-object v27

    .line 180
    const-string v1, "PE"

    .line 181
    .line 182
    const/16 v0, 0x33

    .line 183
    .line 184
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 185
    .line 186
    .line 187
    move-result-object v28

    .line 188
    const-string v1, "MX"

    .line 189
    .line 190
    const/16 v0, 0x34

    .line 191
    .line 192
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 193
    .line 194
    .line 195
    move-result-object v29

    .line 196
    const-string v1, "CU"

    .line 197
    .line 198
    const/16 v0, 0x35

    .line 199
    .line 200
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 201
    .line 202
    .line 203
    move-result-object v30

    .line 204
    const-string v1, "AR"

    .line 205
    .line 206
    const/16 v0, 0x36

    .line 207
    .line 208
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 209
    .line 210
    .line 211
    move-result-object v31

    .line 212
    const-string v1, "BR"

    .line 213
    .line 214
    const/16 v0, 0x37

    .line 215
    .line 216
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 217
    .line 218
    .line 219
    move-result-object v32

    .line 220
    filled-new-array/range {v6 .. v32}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    const/4 v3, 0x0

    .line 225
    invoke-static {v0, v3, v5, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 226
    .line 227
    .line 228
    const-string v1, "CL"

    .line 229
    .line 230
    const/16 v0, 0x38

    .line 231
    .line 232
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 233
    .line 234
    .line 235
    move-result-object v7

    .line 236
    const-string v1, "CO"

    .line 237
    .line 238
    const/16 v0, 0x39

    .line 239
    .line 240
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 241
    .line 242
    .line 243
    move-result-object v8

    .line 244
    const-string v1, "VE"

    .line 245
    .line 246
    const/16 v0, 0x3a

    .line 247
    .line 248
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 249
    .line 250
    .line 251
    move-result-object v9

    .line 252
    const-string v1, "MY"

    .line 253
    .line 254
    const/16 v0, 0x3c

    .line 255
    .line 256
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 257
    .line 258
    .line 259
    move-result-object v10

    .line 260
    const-string v1, "AU"

    .line 261
    .line 262
    const/16 v0, 0x3d

    .line 263
    .line 264
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 265
    .line 266
    .line 267
    move-result-object v11

    .line 268
    const-string v1, "ID"

    .line 269
    .line 270
    const/16 v0, 0x3e

    .line 271
    .line 272
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 273
    .line 274
    .line 275
    move-result-object v12

    .line 276
    const-string v1, "PH"

    .line 277
    .line 278
    const/16 v0, 0x3f

    .line 279
    .line 280
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 281
    .line 282
    .line 283
    move-result-object v13

    .line 284
    const-string v1, "NZ"

    .line 285
    .line 286
    const/16 v0, 0x40

    .line 287
    .line 288
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 289
    .line 290
    .line 291
    move-result-object v14

    .line 292
    const-string v1, "SG"

    .line 293
    .line 294
    const/16 v0, 0x41

    .line 295
    .line 296
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 297
    .line 298
    .line 299
    move-result-object v15

    .line 300
    const-string v1, "TH"

    .line 301
    .line 302
    const/16 v0, 0x42

    .line 303
    .line 304
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 305
    .line 306
    .line 307
    move-result-object v16

    .line 308
    const-string v1, "JP"

    .line 309
    .line 310
    const/16 v0, 0x51

    .line 311
    .line 312
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 313
    .line 314
    .line 315
    move-result-object v17

    .line 316
    const-string v1, "KR"

    .line 317
    .line 318
    const/16 v0, 0x52

    .line 319
    .line 320
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 321
    .line 322
    .line 323
    move-result-object v18

    .line 324
    const-string v1, "VN"

    .line 325
    .line 326
    const/16 v0, 0x54

    .line 327
    .line 328
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 329
    .line 330
    .line 331
    move-result-object v19

    .line 332
    const-string v1, "CN"

    .line 333
    .line 334
    const/16 v0, 0x56

    .line 335
    .line 336
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 337
    .line 338
    .line 339
    move-result-object v20

    .line 340
    const-string v1, "TR"

    .line 341
    .line 342
    const/16 v0, 0x5a

    .line 343
    .line 344
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 345
    .line 346
    .line 347
    move-result-object v21

    .line 348
    const-string v1, "IN"

    .line 349
    .line 350
    const/16 v0, 0x5b

    .line 351
    .line 352
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 353
    .line 354
    .line 355
    move-result-object v22

    .line 356
    const-string v1, "PK"

    .line 357
    .line 358
    const/16 v0, 0x5c

    .line 359
    .line 360
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 361
    .line 362
    .line 363
    move-result-object v23

    .line 364
    const-string v1, "AF"

    .line 365
    .line 366
    const/16 v0, 0x5d

    .line 367
    .line 368
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 369
    .line 370
    .line 371
    move-result-object v24

    .line 372
    const-string v1, "LK"

    .line 373
    .line 374
    const/16 v0, 0x5e

    .line 375
    .line 376
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 377
    .line 378
    .line 379
    move-result-object v25

    .line 380
    const-string v1, "MM"

    .line 381
    .line 382
    const/16 v0, 0x5f

    .line 383
    .line 384
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 385
    .line 386
    .line 387
    move-result-object v26

    .line 388
    const-string v1, "IR"

    .line 389
    .line 390
    const/16 v0, 0x62

    .line 391
    .line 392
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 393
    .line 394
    .line 395
    move-result-object v27

    .line 396
    const-string v1, "SS"

    .line 397
    .line 398
    const/16 v0, 0xd3

    .line 399
    .line 400
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 401
    .line 402
    .line 403
    move-result-object v28

    .line 404
    const-string v1, "MA"

    .line 405
    .line 406
    const/16 v0, 0xd4

    .line 407
    .line 408
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 409
    .line 410
    .line 411
    move-result-object v29

    .line 412
    const-string v1, "DZ"

    .line 413
    .line 414
    const/16 v0, 0xd5

    .line 415
    .line 416
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 417
    .line 418
    .line 419
    move-result-object v30

    .line 420
    const-string v1, "TN"

    .line 421
    .line 422
    const/16 v0, 0xd8

    .line 423
    .line 424
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 425
    .line 426
    .line 427
    move-result-object v31

    .line 428
    const-string v1, "LY"

    .line 429
    .line 430
    const/16 v0, 0xda

    .line 431
    .line 432
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 433
    .line 434
    .line 435
    move-result-object v32

    .line 436
    const-string v1, "GM"

    .line 437
    .line 438
    const/16 v0, 0xdc

    .line 439
    .line 440
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 441
    .line 442
    .line 443
    move-result-object v33

    .line 444
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 445
    .line 446
    .line 447
    move-result-object v0

    .line 448
    invoke-static {v0, v3, v5, v2, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 449
    .line 450
    .line 451
    const-string v1, "SN"

    .line 452
    .line 453
    const/16 v0, 0xdd

    .line 454
    .line 455
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 456
    .line 457
    .line 458
    move-result-object v7

    .line 459
    const-string v1, "MR"

    .line 460
    .line 461
    const/16 v0, 0xde

    .line 462
    .line 463
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 464
    .line 465
    .line 466
    move-result-object v8

    .line 467
    const-string v1, "ML"

    .line 468
    .line 469
    const/16 v0, 0xdf

    .line 470
    .line 471
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 472
    .line 473
    .line 474
    move-result-object v9

    .line 475
    const-string v1, "GN"

    .line 476
    .line 477
    const/16 v0, 0xe0

    .line 478
    .line 479
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 480
    .line 481
    .line 482
    move-result-object v10

    .line 483
    const-string v1, "CI"

    .line 484
    .line 485
    const/16 v0, 0xe1

    .line 486
    .line 487
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 488
    .line 489
    .line 490
    move-result-object v11

    .line 491
    const-string v1, "BF"

    .line 492
    .line 493
    const/16 v0, 0xe2

    .line 494
    .line 495
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 496
    .line 497
    .line 498
    move-result-object v12

    .line 499
    const-string v1, "NE"

    .line 500
    .line 501
    const/16 v0, 0xe3

    .line 502
    .line 503
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 504
    .line 505
    .line 506
    move-result-object v13

    .line 507
    const-string v1, "TG"

    .line 508
    .line 509
    const/16 v0, 0xe4

    .line 510
    .line 511
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 512
    .line 513
    .line 514
    move-result-object v14

    .line 515
    const-string v0, "BJ"

    .line 516
    .line 517
    invoke-static {v0, v4}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 518
    .line 519
    .line 520
    move-result-object v15

    .line 521
    const-string v1, "MU"

    .line 522
    .line 523
    const/16 v0, 0xe6

    .line 524
    .line 525
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 526
    .line 527
    .line 528
    move-result-object v16

    .line 529
    const-string v1, "LR"

    .line 530
    .line 531
    const/16 v0, 0xe7

    .line 532
    .line 533
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 534
    .line 535
    .line 536
    move-result-object v17

    .line 537
    const-string v1, "SL"

    .line 538
    .line 539
    const/16 v0, 0xe8

    .line 540
    .line 541
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 542
    .line 543
    .line 544
    move-result-object v18

    .line 545
    const-string v1, "GH"

    .line 546
    .line 547
    const/16 v0, 0xe9

    .line 548
    .line 549
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 550
    .line 551
    .line 552
    move-result-object v19

    .line 553
    const-string v1, "NG"

    .line 554
    .line 555
    const/16 v0, 0xea

    .line 556
    .line 557
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 558
    .line 559
    .line 560
    move-result-object v20

    .line 561
    const-string v1, "TD"

    .line 562
    .line 563
    const/16 v0, 0xeb

    .line 564
    .line 565
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 566
    .line 567
    .line 568
    move-result-object v21

    .line 569
    const-string v1, "CF"

    .line 570
    .line 571
    const/16 v0, 0xec

    .line 572
    .line 573
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 574
    .line 575
    .line 576
    move-result-object v22

    .line 577
    const-string v1, "CM"

    .line 578
    .line 579
    const/16 v0, 0xed

    .line 580
    .line 581
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 582
    .line 583
    .line 584
    move-result-object v23

    .line 585
    const-string v1, "CV"

    .line 586
    .line 587
    const/16 v0, 0xee

    .line 588
    .line 589
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 590
    .line 591
    .line 592
    move-result-object v24

    .line 593
    const-string v1, "ST"

    .line 594
    .line 595
    const/16 v0, 0xef

    .line 596
    .line 597
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 598
    .line 599
    .line 600
    move-result-object v25

    .line 601
    const-string v1, "GQ"

    .line 602
    .line 603
    const/16 v0, 0xf0

    .line 604
    .line 605
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 606
    .line 607
    .line 608
    move-result-object v26

    .line 609
    const-string v1, "GA"

    .line 610
    .line 611
    const/16 v0, 0xf1

    .line 612
    .line 613
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 614
    .line 615
    .line 616
    move-result-object v27

    .line 617
    const-string v1, "CG"

    .line 618
    .line 619
    const/16 v0, 0xf2

    .line 620
    .line 621
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 622
    .line 623
    .line 624
    move-result-object v28

    .line 625
    const-string v1, "CD"

    .line 626
    .line 627
    const/16 v0, 0xf3

    .line 628
    .line 629
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 630
    .line 631
    .line 632
    move-result-object v29

    .line 633
    const-string v1, "AO"

    .line 634
    .line 635
    const/16 v0, 0xf4

    .line 636
    .line 637
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 638
    .line 639
    .line 640
    move-result-object v30

    .line 641
    const-string v1, "GW"

    .line 642
    .line 643
    const/16 v0, 0xf5

    .line 644
    .line 645
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 646
    .line 647
    .line 648
    move-result-object v31

    .line 649
    const-string v1, "SC"

    .line 650
    .line 651
    const/16 v0, 0xf8

    .line 652
    .line 653
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 654
    .line 655
    .line 656
    move-result-object v32

    .line 657
    const-string v1, "SD"

    .line 658
    .line 659
    const/16 v0, 0xf9

    .line 660
    .line 661
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 662
    .line 663
    .line 664
    move-result-object v33

    .line 665
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 666
    .line 667
    .line 668
    move-result-object v1

    .line 669
    const/16 v0, 0x36

    .line 670
    .line 671
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 672
    .line 673
    .line 674
    const-string v1, "RW"

    .line 675
    .line 676
    const/16 v0, 0xfa

    .line 677
    .line 678
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 679
    .line 680
    .line 681
    move-result-object v7

    .line 682
    const-string v1, "ET"

    .line 683
    .line 684
    const/16 v0, 0xfb

    .line 685
    .line 686
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 687
    .line 688
    .line 689
    move-result-object v8

    .line 690
    const-string v1, "SO"

    .line 691
    .line 692
    const/16 v0, 0xfc

    .line 693
    .line 694
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 695
    .line 696
    .line 697
    move-result-object v9

    .line 698
    const-string v1, "DJ"

    .line 699
    .line 700
    const/16 v0, 0xfd

    .line 701
    .line 702
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 703
    .line 704
    .line 705
    move-result-object v10

    .line 706
    const-string v1, "KE"

    .line 707
    .line 708
    const/16 v0, 0xfe

    .line 709
    .line 710
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 711
    .line 712
    .line 713
    move-result-object v11

    .line 714
    const-string v1, "TZ"

    .line 715
    .line 716
    const/16 v0, 0xff

    .line 717
    .line 718
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 719
    .line 720
    .line 721
    move-result-object v12

    .line 722
    const-string v1, "UG"

    .line 723
    .line 724
    const/16 v0, 0x100

    .line 725
    .line 726
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 727
    .line 728
    .line 729
    move-result-object v13

    .line 730
    const-string v1, "BI"

    .line 731
    .line 732
    const/16 v0, 0x101

    .line 733
    .line 734
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 735
    .line 736
    .line 737
    move-result-object v14

    .line 738
    const-string v1, "MZ"

    .line 739
    .line 740
    const/16 v0, 0x102

    .line 741
    .line 742
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 743
    .line 744
    .line 745
    move-result-object v15

    .line 746
    const-string v1, "ZM"

    .line 747
    .line 748
    const/16 v0, 0x104

    .line 749
    .line 750
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 751
    .line 752
    .line 753
    move-result-object v16

    .line 754
    const-string v1, "MG"

    .line 755
    .line 756
    const/16 v0, 0x105

    .line 757
    .line 758
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 759
    .line 760
    .line 761
    move-result-object v17

    .line 762
    const-string v0, "RE"

    .line 763
    .line 764
    const/16 v1, 0x106

    .line 765
    .line 766
    invoke-static {v0, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 767
    .line 768
    .line 769
    move-result-object v18

    .line 770
    const-string v0, "YT"

    .line 771
    .line 772
    invoke-static {v0, v1}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 773
    .line 774
    .line 775
    move-result-object v19

    .line 776
    const-string v1, "ZW"

    .line 777
    .line 778
    const/16 v0, 0x107

    .line 779
    .line 780
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 781
    .line 782
    .line 783
    move-result-object v20

    .line 784
    const-string v1, "NA"

    .line 785
    .line 786
    const/16 v0, 0x108

    .line 787
    .line 788
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 789
    .line 790
    .line 791
    move-result-object v21

    .line 792
    const-string v1, "MW"

    .line 793
    .line 794
    const/16 v0, 0x109

    .line 795
    .line 796
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 797
    .line 798
    .line 799
    move-result-object v22

    .line 800
    const-string v1, "LS"

    .line 801
    .line 802
    const/16 v0, 0x10a

    .line 803
    .line 804
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 805
    .line 806
    .line 807
    move-result-object v23

    .line 808
    const-string v1, "BW"

    .line 809
    .line 810
    const/16 v0, 0x10b

    .line 811
    .line 812
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 813
    .line 814
    .line 815
    move-result-object v24

    .line 816
    const-string v1, "SZ"

    .line 817
    .line 818
    const/16 v0, 0x10c

    .line 819
    .line 820
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 821
    .line 822
    .line 823
    move-result-object v25

    .line 824
    const-string v1, "KM"

    .line 825
    .line 826
    const/16 v0, 0x10d

    .line 827
    .line 828
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 829
    .line 830
    .line 831
    move-result-object v26

    .line 832
    const-string v1, "SH"

    .line 833
    .line 834
    const/16 v0, 0x122

    .line 835
    .line 836
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 837
    .line 838
    .line 839
    move-result-object v27

    .line 840
    const-string v1, "ER"

    .line 841
    .line 842
    const/16 v0, 0x123

    .line 843
    .line 844
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 845
    .line 846
    .line 847
    move-result-object v28

    .line 848
    const-string v1, "AW"

    .line 849
    .line 850
    const/16 v0, 0x129

    .line 851
    .line 852
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 853
    .line 854
    .line 855
    move-result-object v29

    .line 856
    const-string v1, "FO"

    .line 857
    .line 858
    const/16 v0, 0x12a

    .line 859
    .line 860
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 861
    .line 862
    .line 863
    move-result-object v30

    .line 864
    const-string v1, "GL"

    .line 865
    .line 866
    const/16 v0, 0x12b

    .line 867
    .line 868
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 869
    .line 870
    .line 871
    move-result-object v31

    .line 872
    const-string v1, "GI"

    .line 873
    .line 874
    const/16 v0, 0x15e

    .line 875
    .line 876
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 877
    .line 878
    .line 879
    move-result-object v32

    .line 880
    const-string v1, "PT"

    .line 881
    .line 882
    const/16 v0, 0x15f

    .line 883
    .line 884
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 885
    .line 886
    .line 887
    move-result-object v33

    .line 888
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 889
    .line 890
    .line 891
    move-result-object v1

    .line 892
    const/16 v0, 0x51

    .line 893
    .line 894
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 895
    .line 896
    .line 897
    const-string v1, "LU"

    .line 898
    .line 899
    const/16 v0, 0x160

    .line 900
    .line 901
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 902
    .line 903
    .line 904
    move-result-object v7

    .line 905
    const-string v1, "IE"

    .line 906
    .line 907
    const/16 v0, 0x161

    .line 908
    .line 909
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 910
    .line 911
    .line 912
    move-result-object v8

    .line 913
    const-string v1, "IS"

    .line 914
    .line 915
    const/16 v0, 0x162

    .line 916
    .line 917
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 918
    .line 919
    .line 920
    move-result-object v9

    .line 921
    const-string v1, "AL"

    .line 922
    .line 923
    const/16 v0, 0x163

    .line 924
    .line 925
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 926
    .line 927
    .line 928
    move-result-object v10

    .line 929
    const-string v1, "MT"

    .line 930
    .line 931
    const/16 v0, 0x164

    .line 932
    .line 933
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 934
    .line 935
    .line 936
    move-result-object v11

    .line 937
    const-string v1, "CY"

    .line 938
    .line 939
    const/16 v0, 0x165

    .line 940
    .line 941
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 942
    .line 943
    .line 944
    move-result-object v12

    .line 945
    const-string v1, "FI"

    .line 946
    .line 947
    const/16 v0, 0x166

    .line 948
    .line 949
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 950
    .line 951
    .line 952
    move-result-object v13

    .line 953
    const-string v1, "BG"

    .line 954
    .line 955
    const/16 v0, 0x167

    .line 956
    .line 957
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 958
    .line 959
    .line 960
    move-result-object v14

    .line 961
    const-string v1, "LT"

    .line 962
    .line 963
    const/16 v0, 0x172

    .line 964
    .line 965
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 966
    .line 967
    .line 968
    move-result-object v15

    .line 969
    const-string v1, "LV"

    .line 970
    .line 971
    const/16 v0, 0x173

    .line 972
    .line 973
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 974
    .line 975
    .line 976
    move-result-object v16

    .line 977
    const-string v1, "EE"

    .line 978
    .line 979
    const/16 v0, 0x174

    .line 980
    .line 981
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 982
    .line 983
    .line 984
    move-result-object v17

    .line 985
    const-string v1, "MD"

    .line 986
    .line 987
    const/16 v0, 0x175

    .line 988
    .line 989
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 990
    .line 991
    .line 992
    move-result-object v18

    .line 993
    const-string v1, "AM"

    .line 994
    .line 995
    const/16 v0, 0x176

    .line 996
    .line 997
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 998
    .line 999
    .line 1000
    move-result-object v19

    .line 1001
    const-string v1, "BY"

    .line 1002
    .line 1003
    const/16 v0, 0x177

    .line 1004
    .line 1005
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v20

    .line 1009
    const-string v1, "AD"

    .line 1010
    .line 1011
    const/16 v0, 0x178

    .line 1012
    .line 1013
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v21

    .line 1017
    const-string v1, "MC"

    .line 1018
    .line 1019
    const/16 v0, 0x179

    .line 1020
    .line 1021
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1022
    .line 1023
    .line 1024
    move-result-object v22

    .line 1025
    const-string v1, "SM"

    .line 1026
    .line 1027
    const/16 v0, 0x17a

    .line 1028
    .line 1029
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1030
    .line 1031
    .line 1032
    move-result-object v23

    .line 1033
    const-string v1, "UA"

    .line 1034
    .line 1035
    const/16 v0, 0x17c

    .line 1036
    .line 1037
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v24

    .line 1041
    const-string v1, "RS"

    .line 1042
    .line 1043
    const/16 v0, 0x17d

    .line 1044
    .line 1045
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1046
    .line 1047
    .line 1048
    move-result-object v25

    .line 1049
    const-string v1, "ME"

    .line 1050
    .line 1051
    const/16 v0, 0x17e

    .line 1052
    .line 1053
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v26

    .line 1057
    const-string v1, "XK"

    .line 1058
    .line 1059
    const/16 v0, 0x17f

    .line 1060
    .line 1061
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v27

    .line 1065
    const-string v1, "HR"

    .line 1066
    .line 1067
    const/16 v0, 0x181

    .line 1068
    .line 1069
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1070
    .line 1071
    .line 1072
    move-result-object v28

    .line 1073
    const-string v1, "SI"

    .line 1074
    .line 1075
    const/16 v0, 0x182

    .line 1076
    .line 1077
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v29

    .line 1081
    const-string v1, "BA"

    .line 1082
    .line 1083
    const/16 v0, 0x183

    .line 1084
    .line 1085
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v30

    .line 1089
    const-string v1, "MK"

    .line 1090
    .line 1091
    const/16 v0, 0x185

    .line 1092
    .line 1093
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v31

    .line 1097
    const-string v1, "CZ"

    .line 1098
    .line 1099
    const/16 v0, 0x1a4

    .line 1100
    .line 1101
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1102
    .line 1103
    .line 1104
    move-result-object v32

    .line 1105
    const-string v1, "SK"

    .line 1106
    .line 1107
    const/16 v0, 0x1a5

    .line 1108
    .line 1109
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1110
    .line 1111
    .line 1112
    move-result-object v33

    .line 1113
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1114
    .line 1115
    .line 1116
    move-result-object v1

    .line 1117
    const/16 v0, 0x6c

    .line 1118
    .line 1119
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1120
    .line 1121
    .line 1122
    const-string v1, "LI"

    .line 1123
    .line 1124
    const/16 v0, 0x1a7

    .line 1125
    .line 1126
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v7

    .line 1130
    const-string v1, "FK"

    .line 1131
    .line 1132
    const/16 v0, 0x1f4

    .line 1133
    .line 1134
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v8

    .line 1138
    const-string v1, "BZ"

    .line 1139
    .line 1140
    const/16 v0, 0x1f5

    .line 1141
    .line 1142
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1143
    .line 1144
    .line 1145
    move-result-object v9

    .line 1146
    const-string v1, "GT"

    .line 1147
    .line 1148
    const/16 v0, 0x1f6

    .line 1149
    .line 1150
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v10

    .line 1154
    const-string v1, "SV"

    .line 1155
    .line 1156
    const/16 v0, 0x1f7

    .line 1157
    .line 1158
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1159
    .line 1160
    .line 1161
    move-result-object v11

    .line 1162
    const-string v1, "HN"

    .line 1163
    .line 1164
    const/16 v0, 0x1f8

    .line 1165
    .line 1166
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1167
    .line 1168
    .line 1169
    move-result-object v12

    .line 1170
    const-string v1, "NI"

    .line 1171
    .line 1172
    const/16 v0, 0x1f9

    .line 1173
    .line 1174
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v13

    .line 1178
    const-string v1, "CR"

    .line 1179
    .line 1180
    const/16 v0, 0x1fa

    .line 1181
    .line 1182
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1183
    .line 1184
    .line 1185
    move-result-object v14

    .line 1186
    const-string v1, "PA"

    .line 1187
    .line 1188
    const/16 v0, 0x1fb

    .line 1189
    .line 1190
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1191
    .line 1192
    .line 1193
    move-result-object v15

    .line 1194
    const-string v1, "PM"

    .line 1195
    .line 1196
    const/16 v0, 0x1fc

    .line 1197
    .line 1198
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1199
    .line 1200
    .line 1201
    move-result-object v16

    .line 1202
    const-string v1, "HT"

    .line 1203
    .line 1204
    const/16 v0, 0x1fd

    .line 1205
    .line 1206
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1207
    .line 1208
    .line 1209
    move-result-object v17

    .line 1210
    const-string v1, "GP"

    .line 1211
    .line 1212
    const/16 v0, 0x24e

    .line 1213
    .line 1214
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1215
    .line 1216
    .line 1217
    move-result-object v18

    .line 1218
    const-string v1, "BO"

    .line 1219
    .line 1220
    const/16 v0, 0x24f

    .line 1221
    .line 1222
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1223
    .line 1224
    .line 1225
    move-result-object v19

    .line 1226
    const-string v1, "GY"

    .line 1227
    .line 1228
    const/16 v0, 0x250

    .line 1229
    .line 1230
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1231
    .line 1232
    .line 1233
    move-result-object v20

    .line 1234
    const-string v1, "EC"

    .line 1235
    .line 1236
    const/16 v0, 0x251

    .line 1237
    .line 1238
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1239
    .line 1240
    .line 1241
    move-result-object v21

    .line 1242
    const-string v1, "GF"

    .line 1243
    .line 1244
    const/16 v0, 0x252

    .line 1245
    .line 1246
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v22

    .line 1250
    const-string v1, "PY"

    .line 1251
    .line 1252
    const/16 v0, 0x253

    .line 1253
    .line 1254
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1255
    .line 1256
    .line 1257
    move-result-object v23

    .line 1258
    const-string v1, "MQ"

    .line 1259
    .line 1260
    const/16 v0, 0x254

    .line 1261
    .line 1262
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1263
    .line 1264
    .line 1265
    move-result-object v24

    .line 1266
    const-string v1, "SR"

    .line 1267
    .line 1268
    const/16 v0, 0x255

    .line 1269
    .line 1270
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1271
    .line 1272
    .line 1273
    move-result-object v25

    .line 1274
    const-string v1, "UY"

    .line 1275
    .line 1276
    const/16 v0, 0x256

    .line 1277
    .line 1278
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1279
    .line 1280
    .line 1281
    move-result-object v26

    .line 1282
    const-string v1, "CW"

    .line 1283
    .line 1284
    const/16 v0, 0x257

    .line 1285
    .line 1286
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1287
    .line 1288
    .line 1289
    move-result-object v27

    .line 1290
    const-string v1, "TL"

    .line 1291
    .line 1292
    const/16 v0, 0x29e

    .line 1293
    .line 1294
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v28

    .line 1298
    const-string v1, "BN"

    .line 1299
    .line 1300
    const/16 v0, 0x2a1

    .line 1301
    .line 1302
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1303
    .line 1304
    .line 1305
    move-result-object v29

    .line 1306
    const-string v1, "NR"

    .line 1307
    .line 1308
    const/16 v0, 0x2a2

    .line 1309
    .line 1310
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1311
    .line 1312
    .line 1313
    move-result-object v30

    .line 1314
    const-string v1, "PG"

    .line 1315
    .line 1316
    const/16 v0, 0x2a3

    .line 1317
    .line 1318
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1319
    .line 1320
    .line 1321
    move-result-object v31

    .line 1322
    const-string v1, "TO"

    .line 1323
    .line 1324
    const/16 v0, 0x2a4

    .line 1325
    .line 1326
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1327
    .line 1328
    .line 1329
    move-result-object v32

    .line 1330
    const-string v1, "SB"

    .line 1331
    .line 1332
    const/16 v0, 0x2a5

    .line 1333
    .line 1334
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1335
    .line 1336
    .line 1337
    move-result-object v33

    .line 1338
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1339
    .line 1340
    .line 1341
    move-result-object v1

    .line 1342
    const/16 v0, 0x87

    .line 1343
    .line 1344
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1345
    .line 1346
    .line 1347
    const-string v1, "VU"

    .line 1348
    .line 1349
    const/16 v0, 0x2a6

    .line 1350
    .line 1351
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1352
    .line 1353
    .line 1354
    move-result-object v7

    .line 1355
    const-string v1, "FJ"

    .line 1356
    .line 1357
    const/16 v0, 0x2a7

    .line 1358
    .line 1359
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1360
    .line 1361
    .line 1362
    move-result-object v8

    .line 1363
    const-string v1, "PW"

    .line 1364
    .line 1365
    const/16 v0, 0x2a8

    .line 1366
    .line 1367
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1368
    .line 1369
    .line 1370
    move-result-object v9

    .line 1371
    const-string v1, "WF"

    .line 1372
    .line 1373
    const/16 v0, 0x2a9

    .line 1374
    .line 1375
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1376
    .line 1377
    .line 1378
    move-result-object v10

    .line 1379
    const-string v1, "CK"

    .line 1380
    .line 1381
    const/16 v0, 0x2aa

    .line 1382
    .line 1383
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1384
    .line 1385
    .line 1386
    move-result-object v11

    .line 1387
    const-string v1, "NU"

    .line 1388
    .line 1389
    const/16 v0, 0x2ab

    .line 1390
    .line 1391
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1392
    .line 1393
    .line 1394
    move-result-object v12

    .line 1395
    const-string v1, "WS"

    .line 1396
    .line 1397
    const/16 v0, 0x2ad

    .line 1398
    .line 1399
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1400
    .line 1401
    .line 1402
    move-result-object v13

    .line 1403
    const-string v1, "KI"

    .line 1404
    .line 1405
    const/16 v0, 0x2ae

    .line 1406
    .line 1407
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1408
    .line 1409
    .line 1410
    move-result-object v14

    .line 1411
    const-string v1, "NC"

    .line 1412
    .line 1413
    const/16 v0, 0x2af

    .line 1414
    .line 1415
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v15

    .line 1419
    const-string v1, "TV"

    .line 1420
    .line 1421
    const/16 v0, 0x2b0

    .line 1422
    .line 1423
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1424
    .line 1425
    .line 1426
    move-result-object v16

    .line 1427
    const-string v1, "PF"

    .line 1428
    .line 1429
    const/16 v0, 0x2b1

    .line 1430
    .line 1431
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1432
    .line 1433
    .line 1434
    move-result-object v17

    .line 1435
    const-string v1, "TK"

    .line 1436
    .line 1437
    const/16 v0, 0x2b2

    .line 1438
    .line 1439
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1440
    .line 1441
    .line 1442
    move-result-object v18

    .line 1443
    const-string v1, "FM"

    .line 1444
    .line 1445
    const/16 v0, 0x2b3

    .line 1446
    .line 1447
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v19

    .line 1451
    const-string v1, "MH"

    .line 1452
    .line 1453
    const/16 v0, 0x2b4

    .line 1454
    .line 1455
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v20

    .line 1459
    const-string v1, "KP"

    .line 1460
    .line 1461
    const/16 v0, 0x352

    .line 1462
    .line 1463
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1464
    .line 1465
    .line 1466
    move-result-object v21

    .line 1467
    const-string v1, "HK"

    .line 1468
    .line 1469
    const/16 v0, 0x354

    .line 1470
    .line 1471
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1472
    .line 1473
    .line 1474
    move-result-object v22

    .line 1475
    const-string v1, "MO"

    .line 1476
    .line 1477
    const/16 v0, 0x355

    .line 1478
    .line 1479
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1480
    .line 1481
    .line 1482
    move-result-object v23

    .line 1483
    const-string v1, "KH"

    .line 1484
    .line 1485
    const/16 v0, 0x357

    .line 1486
    .line 1487
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1488
    .line 1489
    .line 1490
    move-result-object v24

    .line 1491
    const-string v1, "LA"

    .line 1492
    .line 1493
    const/16 v0, 0x358

    .line 1494
    .line 1495
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1496
    .line 1497
    .line 1498
    move-result-object v25

    .line 1499
    const-string v1, "BD"

    .line 1500
    .line 1501
    const/16 v0, 0x370

    .line 1502
    .line 1503
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1504
    .line 1505
    .line 1506
    move-result-object v26

    .line 1507
    const-string v1, "TW"

    .line 1508
    .line 1509
    const/16 v0, 0x376

    .line 1510
    .line 1511
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1512
    .line 1513
    .line 1514
    move-result-object v27

    .line 1515
    const-string v1, "MV"

    .line 1516
    .line 1517
    const/16 v0, 0x3c0

    .line 1518
    .line 1519
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1520
    .line 1521
    .line 1522
    move-result-object v28

    .line 1523
    const-string v1, "LB"

    .line 1524
    .line 1525
    const/16 v0, 0x3c1

    .line 1526
    .line 1527
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1528
    .line 1529
    .line 1530
    move-result-object v29

    .line 1531
    const-string v1, "JO"

    .line 1532
    .line 1533
    const/16 v0, 0x3c2

    .line 1534
    .line 1535
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1536
    .line 1537
    .line 1538
    move-result-object v30

    .line 1539
    const-string v1, "SY"

    .line 1540
    .line 1541
    const/16 v0, 0x3c3

    .line 1542
    .line 1543
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1544
    .line 1545
    .line 1546
    move-result-object v31

    .line 1547
    const-string v1, "IQ"

    .line 1548
    .line 1549
    const/16 v0, 0x3c4

    .line 1550
    .line 1551
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1552
    .line 1553
    .line 1554
    move-result-object v32

    .line 1555
    const-string v1, "KW"

    .line 1556
    .line 1557
    const/16 v0, 0x3c5

    .line 1558
    .line 1559
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1560
    .line 1561
    .line 1562
    move-result-object v33

    .line 1563
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1564
    .line 1565
    .line 1566
    move-result-object v1

    .line 1567
    const/16 v0, 0xa2

    .line 1568
    .line 1569
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1570
    .line 1571
    .line 1572
    const-string v1, "SA"

    .line 1573
    .line 1574
    const/16 v0, 0x3c6

    .line 1575
    .line 1576
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1577
    .line 1578
    .line 1579
    move-result-object v7

    .line 1580
    const-string v1, "YE"

    .line 1581
    .line 1582
    const/16 v0, 0x3c7

    .line 1583
    .line 1584
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v8

    .line 1588
    const-string v1, "OM"

    .line 1589
    .line 1590
    const/16 v0, 0x3c8

    .line 1591
    .line 1592
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1593
    .line 1594
    .line 1595
    move-result-object v9

    .line 1596
    const-string v1, "PS"

    .line 1597
    .line 1598
    const/16 v0, 0x3ca

    .line 1599
    .line 1600
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1601
    .line 1602
    .line 1603
    move-result-object v10

    .line 1604
    const-string v1, "AE"

    .line 1605
    .line 1606
    const/16 v0, 0x3cb

    .line 1607
    .line 1608
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1609
    .line 1610
    .line 1611
    move-result-object v11

    .line 1612
    const-string v1, "IL"

    .line 1613
    .line 1614
    const/16 v0, 0x3cc

    .line 1615
    .line 1616
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1617
    .line 1618
    .line 1619
    move-result-object v12

    .line 1620
    const-string v1, "BH"

    .line 1621
    .line 1622
    const/16 v0, 0x3cd

    .line 1623
    .line 1624
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1625
    .line 1626
    .line 1627
    move-result-object v13

    .line 1628
    const-string v1, "QA"

    .line 1629
    .line 1630
    const/16 v0, 0x3ce

    .line 1631
    .line 1632
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1633
    .line 1634
    .line 1635
    move-result-object v14

    .line 1636
    const-string v1, "BT"

    .line 1637
    .line 1638
    const/16 v0, 0x3cf

    .line 1639
    .line 1640
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1641
    .line 1642
    .line 1643
    move-result-object v15

    .line 1644
    const-string v1, "MN"

    .line 1645
    .line 1646
    const/16 v0, 0x3d0

    .line 1647
    .line 1648
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1649
    .line 1650
    .line 1651
    move-result-object v16

    .line 1652
    const-string v1, "NP"

    .line 1653
    .line 1654
    const/16 v0, 0x3d1

    .line 1655
    .line 1656
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1657
    .line 1658
    .line 1659
    move-result-object v17

    .line 1660
    const-string v1, "TJ"

    .line 1661
    .line 1662
    const/16 v0, 0x3e0

    .line 1663
    .line 1664
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1665
    .line 1666
    .line 1667
    move-result-object v18

    .line 1668
    const-string v1, "TM"

    .line 1669
    .line 1670
    const/16 v0, 0x3e1

    .line 1671
    .line 1672
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1673
    .line 1674
    .line 1675
    move-result-object v19

    .line 1676
    const-string v1, "AZ"

    .line 1677
    .line 1678
    const/16 v0, 0x3e2

    .line 1679
    .line 1680
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1681
    .line 1682
    .line 1683
    move-result-object v20

    .line 1684
    const-string v1, "GE"

    .line 1685
    .line 1686
    const/16 v0, 0x3e3

    .line 1687
    .line 1688
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1689
    .line 1690
    .line 1691
    move-result-object v21

    .line 1692
    const-string v1, "KG"

    .line 1693
    .line 1694
    const/16 v0, 0x3e4

    .line 1695
    .line 1696
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1697
    .line 1698
    .line 1699
    move-result-object v22

    .line 1700
    const-string v1, "UZ"

    .line 1701
    .line 1702
    const/16 v0, 0x3e6

    .line 1703
    .line 1704
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1705
    .line 1706
    .line 1707
    move-result-object v23

    .line 1708
    const-string v1, "BS"

    .line 1709
    .line 1710
    const/16 v0, 0x4da

    .line 1711
    .line 1712
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1713
    .line 1714
    .line 1715
    move-result-object v24

    .line 1716
    const-string v1, "BB"

    .line 1717
    .line 1718
    const/16 v0, 0x4de

    .line 1719
    .line 1720
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1721
    .line 1722
    .line 1723
    move-result-object v25

    .line 1724
    const-string v1, "AI"

    .line 1725
    .line 1726
    const/16 v0, 0x4f0

    .line 1727
    .line 1728
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1729
    .line 1730
    .line 1731
    move-result-object v26

    .line 1732
    const-string v1, "AG"

    .line 1733
    .line 1734
    const/16 v0, 0x4f4

    .line 1735
    .line 1736
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1737
    .line 1738
    .line 1739
    move-result-object v27

    .line 1740
    const-string v1, "VG"

    .line 1741
    .line 1742
    const/16 v0, 0x504

    .line 1743
    .line 1744
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1745
    .line 1746
    .line 1747
    move-result-object v28

    .line 1748
    const-string v1, "VI"

    .line 1749
    .line 1750
    const/16 v0, 0x53c

    .line 1751
    .line 1752
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1753
    .line 1754
    .line 1755
    move-result-object v29

    .line 1756
    const-string v1, "KY"

    .line 1757
    .line 1758
    const/16 v0, 0x541

    .line 1759
    .line 1760
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1761
    .line 1762
    .line 1763
    move-result-object v30

    .line 1764
    const-string v1, "BM"

    .line 1765
    .line 1766
    const/16 v0, 0x5a1

    .line 1767
    .line 1768
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1769
    .line 1770
    .line 1771
    move-result-object v31

    .line 1772
    const-string v1, "GD"

    .line 1773
    .line 1774
    const/16 v0, 0x5c1

    .line 1775
    .line 1776
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1777
    .line 1778
    .line 1779
    move-result-object v32

    .line 1780
    const-string v1, "TC"

    .line 1781
    .line 1782
    const/16 v0, 0x671

    .line 1783
    .line 1784
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1785
    .line 1786
    .line 1787
    move-result-object v33

    .line 1788
    filled-new-array/range {v7 .. v33}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1789
    .line 1790
    .line 1791
    move-result-object v1

    .line 1792
    const/16 v0, 0xbd

    .line 1793
    .line 1794
    invoke-static {v1, v3, v5, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1795
    .line 1796
    .line 1797
    const-string v1, "MS"

    .line 1798
    .line 1799
    const/16 v0, 0x680

    .line 1800
    .line 1801
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1802
    .line 1803
    .line 1804
    move-result-object v6

    .line 1805
    const-string v1, "MP"

    .line 1806
    .line 1807
    const/16 v0, 0x686

    .line 1808
    .line 1809
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1810
    .line 1811
    .line 1812
    move-result-object v7

    .line 1813
    const-string v1, "GU"

    .line 1814
    .line 1815
    const/16 v0, 0x687

    .line 1816
    .line 1817
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1818
    .line 1819
    .line 1820
    move-result-object v8

    .line 1821
    const-string v1, "AS"

    .line 1822
    .line 1823
    const/16 v0, 0x694

    .line 1824
    .line 1825
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1826
    .line 1827
    .line 1828
    move-result-object v9

    .line 1829
    const-string v1, "SX"

    .line 1830
    .line 1831
    const/16 v0, 0x6b9

    .line 1832
    .line 1833
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1834
    .line 1835
    .line 1836
    move-result-object v10

    .line 1837
    const-string v1, "LC"

    .line 1838
    .line 1839
    const/16 v0, 0x6de

    .line 1840
    .line 1841
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1842
    .line 1843
    .line 1844
    move-result-object v11

    .line 1845
    const-string v1, "DM"

    .line 1846
    .line 1847
    const/16 v0, 0x6e7

    .line 1848
    .line 1849
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1850
    .line 1851
    .line 1852
    move-result-object v12

    .line 1853
    const-string v1, "VC"

    .line 1854
    .line 1855
    const/16 v0, 0x6f8

    .line 1856
    .line 1857
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1858
    .line 1859
    .line 1860
    move-result-object v13

    .line 1861
    const-string v1, "PR"

    .line 1862
    .line 1863
    const/16 v0, 0x6fb

    .line 1864
    .line 1865
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1866
    .line 1867
    .line 1868
    move-result-object v14

    .line 1869
    const-string v1, "DO"

    .line 1870
    .line 1871
    const/16 v0, 0x711

    .line 1872
    .line 1873
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1874
    .line 1875
    .line 1876
    move-result-object v15

    .line 1877
    const-string v1, "TT"

    .line 1878
    .line 1879
    const/16 v0, 0x74c

    .line 1880
    .line 1881
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1882
    .line 1883
    .line 1884
    move-result-object v16

    .line 1885
    const-string v1, "KN"

    .line 1886
    .line 1887
    const/16 v0, 0x74d

    .line 1888
    .line 1889
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1890
    .line 1891
    .line 1892
    move-result-object v17

    .line 1893
    const-string v1, "JM"

    .line 1894
    .line 1895
    const/16 v0, 0x754

    .line 1896
    .line 1897
    invoke-static {v1, v0}, LX/IEa;->A0H(Ljava/lang/String;I)Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1898
    .line 1899
    .line 1900
    move-result-object v18

    .line 1901
    filled-new-array/range {v6 .. v18}, [Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v2

    .line 1905
    const/16 v1, 0xd8

    .line 1906
    .line 1907
    const/16 v0, 0xd

    .line 1908
    .line 1909
    invoke-static {v2, v3, v5, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1910
    .line 1911
    .line 1912
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1913
    .line 1914
    .line 1915
    move-result-object v0

    .line 1916
    sput-object v0, Lcom/facebook/aura/components/phone/CountryDialCodesKt;->COUNTRY_DIAL_CODES:Ljava/util/List;

    .line 1917
    .line 1918
    return-void
.end method

.method public static final countryFlagEmoji(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, LX/001;->A12(I)Ljava/util/ArrayList;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    const/4 v2, 0x0

    .line 19
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ge v2, v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    const v0, 0x1f1a5

    .line 30
    .line 31
    .line 32
    add-int/2addr v1, v0

    .line 33
    invoke-static {v1}, Ljava/lang/Character;->toChars(I)[C

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    new-instance v0, Ljava/lang/String;

    .line 41
    .line 42
    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    add-int/lit8 v2, v2, 0x1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    const-string v1, ""

    .line 52
    .line 53
    const/4 v0, 0x0

    .line 54
    invoke-static {v1, v1, v1, v3, v0}, LX/B89;->A0Z(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Iterable;LX/JDM;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0
.end method

.method public static final getCOUNTRY_DIAL_CODES()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/phone/CountryDialCode;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/components/phone/CountryDialCodesKt;->COUNTRY_DIAL_CODES:Ljava/util/List;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final getDEFAULT_COUNTRY_DIAL_CODE()Lcom/facebook/aura/components/phone/CountryDialCode;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/components/phone/CountryDialCodesKt;->DEFAULT_COUNTRY_DIAL_CODE:Lcom/facebook/aura/components/phone/CountryDialCode;

    .line 1
    .line 2
    return-object v0
.end method
