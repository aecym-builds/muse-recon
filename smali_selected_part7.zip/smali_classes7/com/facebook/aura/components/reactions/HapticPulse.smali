.class public final Lcom/facebook/aura/components/reactions/HapticPulse;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final primitive:I

.field public final scale:F

.field public final timeMs:I


# direct methods
.method public constructor <init>(IIF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->timeMs:I

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->primitive:I

    .line 6
    .line 7
    iput p3, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->scale:F

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getPrimitive()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->primitive:I

    .line 1
    .line 2
    return p0
.end method

.method public final getScale()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->scale:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTimeMs()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticPulse;->timeMs:I

    .line 1
    .line 2
    return p0
.end method
