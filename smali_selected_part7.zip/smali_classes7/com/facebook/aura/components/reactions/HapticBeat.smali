.class public final Lcom/facebook/aura/components/reactions/HapticBeat;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final durationMs:I

.field public final intensity:F

.field public final sharpness:F

.field public final timeMs:I


# direct methods
.method public constructor <init>(IFFI)V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    iput p1, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 268435460
    .line 268435461
    iput p2, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->intensity:F

    .line 268435462
    .line 268435463
    iput p3, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->sharpness:F

    .line 268435464
    .line 268435465
    iput p4, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 268435466
    .line 268435467
    return-void
.end method

.method public synthetic constructor <init>(IFFIILX/04f;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p4, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final getDurationMs()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 1
    .line 2
    return p0
.end method

.method public final getIntensity()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->intensity:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSharpness()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->sharpness:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTimeMs()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 1
    .line 2
    return p0
.end method
