.class public final synthetic Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# instance fields
.field public final synthetic f$0:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$$ExternalSyntheticLambda0;->f$0:Ljava/util/List;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$$ExternalSyntheticLambda0;->f$0:Ljava/util/List;

    .line 1
    .line 2
    check-cast p1, Landroid/os/Vibrator;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    invoke-static {p1, p0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->buildEffect(Landroid/os/Vibrator;Ljava/util/List;)Landroid/os/VibrationEffect;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
