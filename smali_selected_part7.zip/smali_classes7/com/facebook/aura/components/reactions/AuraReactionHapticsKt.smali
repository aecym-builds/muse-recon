.class public abstract Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CLICK_SHARPNESS:F = 0.5f

.field public static final HUM_TICK_INTERVAL_MS:I = 0x28

.field public static final HUM_TICK_SCALE:F = 0.6f

.field public static final MAX_AMPLITUDE:I = 0xff

.field public static final MIN_PRIMITIVE_SCALE:F = 0.05f

.field public static final TRANSIENT_PULSE_MS:I = 0xa

.field public static final WAVEFORM_STEP_MS:I = 0xa


# direct methods
.method public static final buildComposition(Ljava/util/List;)Landroid/os/VibrationEffect;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/reactions/HapticBeat;",
            ">;)",
            "Landroid/os/VibrationEffect;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v5

    .line 4
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_2

    .line 13
    .line 14
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v7

    .line 18
    check-cast v7, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 19
    .line 20
    iget v6, v7, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 21
    .line 22
    iget v4, v7, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 23
    .line 24
    if-gtz v6, :cond_1

    .line 25
    .line 26
    iget v0, v7, Lcom/facebook/aura/components/reactions/HapticBeat;->sharpness:F

    .line 27
    .line 28
    invoke-static {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->primitiveFor(F)I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    iget v1, v7, Lcom/facebook/aura/components/reactions/HapticBeat;->intensity:F

    .line 33
    .line 34
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticPulse;

    .line 35
    .line 36
    invoke-direct {v0, v4, v2, v1}, Lcom/facebook/aura/components/reactions/HapticPulse;-><init>(IIF)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    move v3, v4

    .line 44
    :goto_1
    add-int v0, v4, v6

    .line 45
    .line 46
    if-ge v3, v0, :cond_0

    .line 47
    .line 48
    iget v2, v7, Lcom/facebook/aura/components/reactions/HapticBeat;->intensity:F

    .line 49
    .line 50
    const v0, 0x3f19999a    # 0.6f

    .line 51
    .line 52
    .line 53
    mul-float/2addr v2, v0

    .line 54
    const/4 v1, 0x7

    .line 55
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticPulse;

    .line 56
    .line 57
    invoke-direct {v0, v3, v1, v2}, Lcom/facebook/aura/components/reactions/HapticPulse;-><init>(IIF)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    add-int/lit8 v3, v3, 0x28

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_2
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->size()I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    const/4 v0, 0x1

    .line 71
    if-le v1, v0, :cond_3

    .line 72
    .line 73
    new-instance v0, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$buildComposition$$inlined$sortBy$1;

    .line 74
    .line 75
    invoke-direct {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$buildComposition$$inlined$sortBy$1;-><init>()V

    .line 76
    .line 77
    .line 78
    invoke-static {v5, v0}, LX/0MT;->A06(Ljava/util/List;Ljava/util/Comparator;)V

    .line 79
    .line 80
    .line 81
    :cond_3
    invoke-static {}, Landroid/os/VibrationEffect;->startComposition()Landroid/os/VibrationEffect$Composition;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 89
    .line 90
    .line 91
    move-result-object v7

    .line 92
    invoke-static {v7}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    const/4 v6, 0x0

    .line 96
    const/4 v0, 0x0

    .line 97
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    if-eqz v1, :cond_4

    .line 102
    .line 103
    invoke-static {v7}, LX/I1c;->A0K(Ljava/util/Iterator;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    check-cast v5, Lcom/facebook/aura/components/reactions/HapticPulse;

    .line 108
    .line 109
    iget v4, v5, Lcom/facebook/aura/components/reactions/HapticPulse;->primitive:I

    .line 110
    .line 111
    iget v3, v5, Lcom/facebook/aura/components/reactions/HapticPulse;->scale:F

    .line 112
    .line 113
    const v2, 0x3d4ccccd    # 0.05f

    .line 114
    .line 115
    .line 116
    const/high16 v1, 0x3f800000    # 1.0f

    .line 117
    .line 118
    invoke-static {v3, v2, v1}, LX/34j;->A04(FFF)F

    .line 119
    .line 120
    .line 121
    move-result v2

    .line 122
    iget v1, v5, Lcom/facebook/aura/components/reactions/HapticPulse;->timeMs:I

    .line 123
    .line 124
    sub-int/2addr v1, v0

    .line 125
    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    invoke-virtual {p0, v4, v2, v0}, Landroid/os/VibrationEffect$Composition;->addPrimitive(IFI)Landroid/os/VibrationEffect$Composition;

    .line 130
    .line 131
    .line 132
    iget v0, v5, Lcom/facebook/aura/components/reactions/HapticPulse;->timeMs:I

    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_4
    invoke-virtual {p0}, Landroid/os/VibrationEffect$Composition;->compose()Landroid/os/VibrationEffect;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    return-object v0
.end method

.method public static final buildEffect(Landroid/os/Vibrator;Ljava/util/List;)Landroid/os/VibrationEffect;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Vibrator;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/reactions/HapticBeat;",
            ">;)",
            "Landroid/os/VibrationEffect;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->supportsPrimitives(Landroid/os/Vibrator;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    if-eqz p0, :cond_0

    .line 5
    .line 6
    invoke-static {p1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->buildComposition(Ljava/util/List;)Landroid/os/VibrationEffect;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :cond_0
    invoke-static {p1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->buildWaveform(Ljava/util/List;)Landroid/os/VibrationEffect;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method

.method public static final buildWaveform(Ljava/util/List;)Landroid/os/VibrationEffect;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/reactions/HapticBeat;",
            ">;)",
            "Landroid/os/VibrationEffect;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->endMs(Ljava/util/List;)I

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/16 v5, 0xa

    .line 5
    .line 6
    div-int/2addr v0, v5

    .line 7
    add-int/lit8 v9, v0, 0x1

    .line 8
    .line 9
    new-array v8, v9, [I

    .line 10
    .line 11
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object v6

    .line 15
    :cond_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_3

    .line 20
    .line 21
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    check-cast v4, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 26
    .line 27
    iget v1, v4, Lcom/facebook/aura/components/reactions/HapticBeat;->intensity:F

    .line 28
    .line 29
    const/high16 v0, 0x437f0000    # 255.0f

    .line 30
    .line 31
    mul-float/2addr v1, v0

    .line 32
    invoke-static {v1}, LX/0sc;->A01(F)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    const/4 v1, 0x1

    .line 37
    const/16 v0, 0xff

    .line 38
    .line 39
    if-ge v3, v1, :cond_2

    .line 40
    .line 41
    const/4 v3, 0x1

    .line 42
    :cond_1
    :goto_0
    iget v2, v4, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 43
    .line 44
    iget v0, v4, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 45
    .line 46
    invoke-static {v0, v5}, Ljava/lang/Math;->max(II)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    add-int v1, v2, v0

    .line 51
    .line 52
    div-int/2addr v2, v5

    .line 53
    :goto_1
    if-ge v2, v9, :cond_0

    .line 54
    .line 55
    mul-int/lit8 v0, v2, 0xa

    .line 56
    .line 57
    if-ge v0, v1, :cond_0

    .line 58
    .line 59
    aget v0, v8, v2

    .line 60
    .line 61
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    aput v0, v8, v2

    .line 66
    .line 67
    add-int/lit8 v2, v2, 0x1

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_2
    if-le v3, v0, :cond_1

    .line 71
    .line 72
    const/16 v3, 0xff

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 76
    .line 77
    .line 78
    move-result-object v7

    .line 79
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    const/4 v5, 0x0

    .line 84
    :goto_2
    if-ge v5, v9, :cond_5

    .line 85
    .line 86
    aget v2, v8, v5

    .line 87
    .line 88
    invoke-virtual {v6}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-nez v0, :cond_4

    .line 93
    .line 94
    invoke-static {v6}, LX/B89;->A0V(Ljava/util/List;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-ne v0, v2, :cond_4

    .line 103
    .line 104
    invoke-static {v7}, LX/001;->A0E(Ljava/util/AbstractCollection;)I

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    invoke-static {v7}, LX/B89;->A0V(Ljava/util/List;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    invoke-static {v0}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 113
    .line 114
    .line 115
    move-result-wide v2

    .line 116
    const-wide/16 v0, 0xa

    .line 117
    .line 118
    add-long/2addr v2, v0

    .line 119
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-virtual {v7, v4, v0}, Ljava/util/AbstractList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    :goto_3
    add-int/lit8 v5, v5, 0x1

    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_4
    const-wide/16 v0, 0xa

    .line 130
    .line 131
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    invoke-static {v6, v2}, LX/006;->A1U(Ljava/util/AbstractCollection;I)V

    .line 139
    .line 140
    .line 141
    goto :goto_3

    .line 142
    :cond_5
    invoke-static {v7}, LX/B89;->A11(Ljava/util/Collection;)[J

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    invoke-static {v6}, LX/B89;->A10(Ljava/util/Collection;)[I

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    const/4 v0, -0x1

    .line 151
    invoke-static {v2, v1, v0}, Landroid/os/VibrationEffect;->createWaveform([J[II)Landroid/os/VibrationEffect;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    return-object v0
.end method

.method public static final endMs(Ljava/util/List;)I
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/reactions/HapticBeat;",
            ">;)I"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    return v0

    .line 12
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 17
    .line 18
    iget v1, v0, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 19
    .line 20
    iget v0, v0, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 21
    .line 22
    const/16 v3, 0xa

    .line 23
    .line 24
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    add-int/2addr v1, v0

    .line 29
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    :cond_1
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    check-cast v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 44
    .line 45
    iget v1, v0, Lcom/facebook/aura/components/reactions/HapticBeat;->timeMs:I

    .line 46
    .line 47
    iget v0, v0, Lcom/facebook/aura/components/reactions/HapticBeat;->durationMs:I

    .line 48
    .line 49
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    add-int/2addr v1, v0

    .line 54
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-virtual {v2, v1}, Ljava/lang/Integer;->compareTo(Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-gez v0, :cond_1

    .line 63
    .line 64
    move-object v2, v1

    .line 65
    goto :goto_0

    .line 66
    :cond_2
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    return v0
.end method

.method public static final getAURA_REACTION_HAPTIC_MAX_MS()J
    .locals 3

    .line 0
    invoke-static {}, Lcom/facebook/aura/components/reactions/AuraReactionAnimation;->getEntries()LX/0vk;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_4

    .line 13
    .line 14
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/facebook/aura/components/reactions/AuraReactionAnimation;

    .line 19
    .line 20
    invoke-static {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->scoreFor(Lcom/facebook/aura/components/reactions/AuraReactionAnimation;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    invoke-static {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->endMs(Ljava/util/List;)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_3

    .line 35
    .line 36
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    check-cast v0, Lcom/facebook/aura/components/reactions/AuraReactionAnimation;

    .line 41
    .line 42
    invoke-static {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->scoreFor(Lcom/facebook/aura/components/reactions/AuraReactionAnimation;)Ljava/util/List;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    invoke-static {v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->endMs(Ljava/util/List;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    :goto_1
    if-ge v1, v0, :cond_0

    .line 53
    .line 54
    move v1, v0

    .line 55
    goto :goto_0

    .line 56
    :cond_1
    const/4 v0, 0x0

    .line 57
    goto :goto_1

    .line 58
    :cond_2
    const/4 v1, 0x0

    .line 59
    goto :goto_0

    .line 60
    :cond_3
    int-to-long v0, v1

    .line 61
    return-wide v0

    .line 62
    :cond_4
    invoke-static {}, LX/EYt;->A13()Ljava/util/NoSuchElementException;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    throw v0
.end method

.method public static final hum(IIFF)Lcom/facebook/aura/components/reactions/HapticBeat;
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1
    .line 2
    invoke-direct {v0, p0, p2, p3, p1}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 3
    .line 4
    .line 5
    return-object v0
.end method

.method public static final playAuraReactionHaptic(Landroid/content/Context;Lcom/facebook/aura/components/reactions/AuraReactionAnimation;)V
    .locals 2

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->scoreFor(Lcom/facebook/aura/components/reactions/AuraReactionAnimation;)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    new-instance v0, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$$ExternalSyntheticLambda0;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt$$ExternalSyntheticLambda0;-><init>(Ljava/util/List;)V

    .line 12
    .line 13
    .line 14
    invoke-static {p0, v0}, Lcom/facebook/aura/vds/compose/accessibility/AuraTouchVibrationKt;->vibrateAsTouchFeedback(Landroid/content/Context;LX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public static final playAuraReactionHaptic$lambda$0(Ljava/util/List;Landroid/os/Vibrator;)Landroid/os/VibrationEffect;
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1, p0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->buildEffect(Landroid/os/Vibrator;Ljava/util/List;)Landroid/os/VibrationEffect;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method

.method public static final primitiveFor(F)I
    .locals 1

    .line 0
    const/high16 v0, 0x3f000000    # 0.5f

    .line 1
    .line 2
    cmpl-float p0, p0, v0

    .line 3
    .line 4
    const/4 v0, 0x7

    .line 5
    if-ltz p0, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    :cond_0
    return v0
.end method

.method public static final scoreFor(Lcom/facebook/aura/components/reactions/AuraReactionAnimation;)Ljava/util/List;
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/components/reactions/AuraReactionAnimation;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/aura/components/reactions/HapticBeat;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    const p0, 0x3f6147ae    # 0.88f

    .line 5
    .line 6
    .line 7
    const v13, 0x3f51eb85    # 0.82f

    .line 8
    .line 9
    .line 10
    const v6, 0x3f75c28f    # 0.96f

    .line 11
    .line 12
    .line 13
    const v16, 0x3f666666    # 0.9f

    .line 14
    .line 15
    .line 16
    const v11, 0x3f6b851f    # 0.92f

    .line 17
    .line 18
    .line 19
    const v10, 0x3ed70a3d    # 0.42f

    .line 20
    .line 21
    .line 22
    const v12, 0x3f147ae1    # 0.58f

    .line 23
    .line 24
    .line 25
    const v0, 0x3f3851ec    # 0.72f

    .line 26
    .line 27
    .line 28
    const v15, 0x3eae147b    # 0.34f

    .line 29
    .line 30
    .line 31
    const/high16 v1, 0x3f800000    # 1.0f

    .line 32
    .line 33
    const v7, 0x3e8f5c29    # 0.28f

    .line 34
    .line 35
    .line 36
    const v5, 0x3e4ccccd    # 0.2f

    .line 37
    .line 38
    .line 39
    const/4 v14, 0x4

    .line 40
    const/4 v3, 0x3

    .line 41
    const/4 v8, 0x1

    .line 42
    const/4 v4, 0x2

    .line 43
    const/4 v9, 0x0

    .line 44
    packed-switch v2, :pswitch_data_0

    .line 45
    .line 46
    .line 47
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0

    .line 52
    :pswitch_0
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 53
    .line 54
    const/16 v7, 0x32

    .line 55
    .line 56
    const/16 v6, 0x3c0

    .line 57
    .line 58
    const v3, 0x3ea3d70a    # 0.32f

    .line 59
    .line 60
    .line 61
    const/4 v1, 0x0

    .line 62
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 63
    .line 64
    invoke-direct {v0, v7, v3, v1, v6}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 65
    .line 66
    .line 67
    aput-object v0, v2, v9

    .line 68
    .line 69
    const/16 v1, 0x1b8

    .line 70
    .line 71
    const v0, 0x3da3d70a    # 0.08f

    .line 72
    .line 73
    .line 74
    invoke-static {v2, v10, v0, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 75
    .line 76
    .line 77
    const/16 v1, 0x398

    .line 78
    .line 79
    const v0, 0x3d4ccccd    # 0.05f

    .line 80
    .line 81
    .line 82
    invoke-static {v1, v5, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    goto/16 :goto_0

    .line 87
    .line 88
    :pswitch_1
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 89
    .line 90
    invoke-static {v9, v12, v10}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    aput-object v0, v2, v9

    .line 95
    .line 96
    const v6, 0x3f47ae14    # 0.78f

    .line 97
    .line 98
    .line 99
    const v1, 0x3f70a3d7    # 0.94f

    .line 100
    .line 101
    .line 102
    const/16 v0, 0xb4

    .line 103
    .line 104
    invoke-static {v2, v6, v1, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 105
    .line 106
    .line 107
    const/16 v0, 0x122

    .line 108
    .line 109
    invoke-static {v2, v7, v11, v0, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 110
    .line 111
    .line 112
    const/16 v1, 0x1a4

    .line 113
    .line 114
    const v0, 0x3f5c28f6    # 0.86f

    .line 115
    .line 116
    .line 117
    invoke-static {v1, v5, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    goto/16 :goto_2

    .line 122
    .line 123
    :pswitch_2
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 124
    .line 125
    const/16 v0, 0x32

    .line 126
    .line 127
    invoke-static {v2, v10, v6, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 128
    .line 129
    .line 130
    const/16 v7, 0xb4

    .line 131
    .line 132
    const v6, 0x3eb851ec    # 0.36f

    .line 133
    .line 134
    .line 135
    move/from16 v0, v16

    .line 136
    .line 137
    invoke-static {v2, v6, v0, v7, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 138
    .line 139
    .line 140
    const/16 v0, 0x1c2

    .line 141
    .line 142
    invoke-static {v2, v12, v1, v0, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 143
    .line 144
    .line 145
    const/16 v1, 0x26c

    .line 146
    .line 147
    const v0, 0x3f5c28f6    # 0.86f

    .line 148
    .line 149
    .line 150
    invoke-static {v1, v5, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    goto/16 :goto_2

    .line 155
    .line 156
    :pswitch_3
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 157
    .line 158
    const/16 v1, 0x5a

    .line 159
    .line 160
    const v0, 0x3ef5c28f    # 0.48f

    .line 161
    .line 162
    .line 163
    invoke-static {v2, v0, v10, v1, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 164
    .line 165
    .line 166
    const v7, 0x3eb851ec    # 0.36f

    .line 167
    .line 168
    .line 169
    const v1, 0x3f051eb8    # 0.52f

    .line 170
    .line 171
    .line 172
    const/16 v0, 0xf0

    .line 173
    .line 174
    invoke-static {v2, v7, v1, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 175
    .line 176
    .line 177
    const v7, 0x3f28f5c3    # 0.66f

    .line 178
    .line 179
    .line 180
    const v1, 0x3f0f5c29    # 0.56f

    .line 181
    .line 182
    .line 183
    const/16 v0, 0x1f4

    .line 184
    .line 185
    invoke-static {v2, v7, v1, v0, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 186
    .line 187
    .line 188
    const/16 v0, 0x294

    .line 189
    .line 190
    invoke-static {v0, v5, v6}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    goto/16 :goto_2

    .line 195
    .line 196
    :pswitch_4
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 197
    .line 198
    const/16 v5, 0x3c

    .line 199
    .line 200
    const v1, 0x3ecccccd    # 0.4f

    .line 201
    .line 202
    .line 203
    move/from16 v0, p0

    .line 204
    .line 205
    invoke-static {v2, v1, v0, v5, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 206
    .line 207
    .line 208
    const/16 v1, 0xe6

    .line 209
    .line 210
    const v0, 0x3f051eb8    # 0.52f

    .line 211
    .line 212
    .line 213
    invoke-static {v2, v0, v13, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 214
    .line 215
    .line 216
    const/16 v1, 0x190

    .line 217
    .line 218
    const v0, 0x3eeb851f    # 0.46f

    .line 219
    .line 220
    .line 221
    invoke-static {v2, v0, v11, v1, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 222
    .line 223
    .line 224
    const/16 v1, 0x244

    .line 225
    .line 226
    const v0, 0x3f5c28f6    # 0.86f

    .line 227
    .line 228
    .line 229
    invoke-static {v1, v12, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    goto/16 :goto_2

    .line 234
    .line 235
    :pswitch_5
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 236
    .line 237
    const/16 v3, 0x46

    .line 238
    .line 239
    const v0, 0x3f2e147b    # 0.68f

    .line 240
    .line 241
    .line 242
    invoke-static {v2, v0, v15, v3, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 243
    .line 244
    .line 245
    const/16 v5, 0x104

    .line 246
    .line 247
    const v3, 0x3e6147ae    # 0.22f

    .line 248
    .line 249
    .line 250
    move/from16 v0, v16

    .line 251
    .line 252
    invoke-static {v2, v3, v0, v5, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 253
    .line 254
    .line 255
    const/16 v3, 0x190

    .line 256
    .line 257
    const v0, 0x3ea3d70a    # 0.32f

    .line 258
    .line 259
    .line 260
    invoke-static {v3, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    goto/16 :goto_0

    .line 265
    .line 266
    :pswitch_6
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 267
    .line 268
    const/16 v3, 0x122

    .line 269
    .line 270
    const v1, 0x3e99999a    # 0.3f

    .line 271
    .line 272
    .line 273
    invoke-static {v2, v0, v1, v3, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 274
    .line 275
    .line 276
    const/16 v0, 0x190

    .line 277
    .line 278
    invoke-static {v2, v15, v10, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 279
    .line 280
    .line 281
    const/16 v1, 0x21c

    .line 282
    .line 283
    const v0, 0x3f47ae14    # 0.78f

    .line 284
    .line 285
    .line 286
    invoke-static {v1, v5, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    goto/16 :goto_0

    .line 291
    .line 292
    :pswitch_7
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 293
    .line 294
    const/16 v10, 0x1e0

    .line 295
    .line 296
    const v7, 0x3e6147ae    # 0.22f

    .line 297
    .line 298
    .line 299
    const v5, 0x3f3d70a4    # 0.74f

    .line 300
    .line 301
    .line 302
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 303
    .line 304
    invoke-direct {v0, v9, v7, v5, v10}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 305
    .line 306
    .line 307
    aput-object v0, v2, v9

    .line 308
    .line 309
    const/16 v5, 0xa0

    .line 310
    .line 311
    const v0, 0x3e3851ec    # 0.18f

    .line 312
    .line 313
    .line 314
    invoke-static {v2, v0, v11, v5, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 315
    .line 316
    .line 317
    const/16 v5, 0x140

    .line 318
    .line 319
    const v0, 0x3e75c28f    # 0.24f

    .line 320
    .line 321
    .line 322
    invoke-static {v2, v0, v6, v5, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 323
    .line 324
    .line 325
    const/16 v0, 0x208

    .line 326
    .line 327
    invoke-static {v0, v12, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    goto/16 :goto_2

    .line 332
    .line 333
    :pswitch_8
    const/16 v10, 0x208

    .line 334
    .line 335
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 336
    .line 337
    const/16 v7, 0x28

    .line 338
    .line 339
    const v1, 0x3f19999a    # 0.6f

    .line 340
    .line 341
    .line 342
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 343
    .line 344
    invoke-direct {v0, v7, v5, v1, v10}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 345
    .line 346
    .line 347
    aput-object v0, v2, v9

    .line 348
    .line 349
    const/16 v7, 0xa0

    .line 350
    .line 351
    const v1, 0x3e23d70a    # 0.16f

    .line 352
    .line 353
    .line 354
    move/from16 v0, p0

    .line 355
    .line 356
    invoke-static {v2, v1, v0, v7, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 357
    .line 358
    .line 359
    const/16 v0, 0x154

    .line 360
    .line 361
    invoke-static {v2, v5, v11, v0, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 362
    .line 363
    .line 364
    const v0, 0x3e851eb8    # 0.26f

    .line 365
    .line 366
    .line 367
    invoke-static {v10, v0, v6}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 368
    .line 369
    .line 370
    move-result-object v0

    .line 371
    goto/16 :goto_2

    .line 372
    .line 373
    :pswitch_9
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 374
    .line 375
    const/16 v3, 0x8c

    .line 376
    .line 377
    const v1, 0x3ee147ae    # 0.44f

    .line 378
    .line 379
    .line 380
    const v0, 0x3e75c28f    # 0.24f

    .line 381
    .line 382
    .line 383
    invoke-static {v2, v0, v1, v3, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 384
    .line 385
    .line 386
    const/16 v1, 0x10e

    .line 387
    .line 388
    const v0, 0x3ecccccd    # 0.4f

    .line 389
    .line 390
    .line 391
    invoke-static {v2, v7, v0, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 392
    .line 393
    .line 394
    const/16 v1, 0x1a4

    .line 395
    .line 396
    const v0, 0x3e23d70a    # 0.16f

    .line 397
    .line 398
    .line 399
    invoke-static {v1, v12, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 400
    .line 401
    .line 402
    move-result-object v0

    .line 403
    goto/16 :goto_0

    .line 404
    .line 405
    :pswitch_a
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 406
    .line 407
    const/16 v5, 0x28

    .line 408
    .line 409
    const/16 v3, 0x1f4

    .line 410
    .line 411
    const v1, 0x3da3d70a    # 0.08f

    .line 412
    .line 413
    .line 414
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 415
    .line 416
    invoke-direct {v0, v5, v7, v1, v3}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 417
    .line 418
    .line 419
    aput-object v0, v2, v9

    .line 420
    .line 421
    const/16 v1, 0x230

    .line 422
    .line 423
    const v0, 0x3e851eb8    # 0.26f

    .line 424
    .line 425
    .line 426
    invoke-static {v2, v7, v0, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 427
    .line 428
    .line 429
    const/16 v1, 0x2b2

    .line 430
    .line 431
    const v0, 0x3f051eb8    # 0.52f

    .line 432
    .line 433
    .line 434
    invoke-static {v1, v0, v15}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 435
    .line 436
    .line 437
    move-result-object v0

    .line 438
    goto/16 :goto_0

    .line 439
    .line 440
    :pswitch_b
    const/16 v2, 0x6e

    .line 441
    .line 442
    const v0, 0x3d4ccccd    # 0.05f

    .line 443
    .line 444
    .line 445
    new-instance v8, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 446
    .line 447
    invoke-direct {v8, v9, v7, v0, v2}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 448
    .line 449
    .line 450
    const/16 v0, 0x73

    .line 451
    .line 452
    invoke-static {v0, v1, v12}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 453
    .line 454
    .line 455
    move-result-object v9

    .line 456
    const/16 v0, 0xb9

    .line 457
    .line 458
    invoke-static {v0, v7, v6}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 459
    .line 460
    .line 461
    move-result-object v10

    .line 462
    const/16 v1, 0xf5

    .line 463
    .line 464
    move/from16 v0, v16

    .line 465
    .line 466
    invoke-static {v1, v5, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 467
    .line 468
    .line 469
    move-result-object v11

    .line 470
    const v2, 0x3e051eb8    # 0.13f

    .line 471
    .line 472
    .line 473
    const v1, 0x3f570a3d    # 0.84f

    .line 474
    .line 475
    .line 476
    const/16 v0, 0x145

    .line 477
    .line 478
    invoke-static {v0, v2, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 479
    .line 480
    .line 481
    move-result-object v12

    .line 482
    const/16 v2, 0x1cc

    .line 483
    .line 484
    const v1, 0x3e3851ec    # 0.18f

    .line 485
    .line 486
    .line 487
    const v0, 0x3e23d70a    # 0.16f

    .line 488
    .line 489
    .line 490
    invoke-static {v2, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 491
    .line 492
    .line 493
    move-result-object v13

    .line 494
    filled-new-array/range {v8 .. v13}, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 495
    .line 496
    .line 497
    move-result-object v2

    .line 498
    goto/16 :goto_3

    .line 499
    .line 500
    :pswitch_c
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 501
    .line 502
    const v3, 0x3e851eb8    # 0.26f

    .line 503
    .line 504
    .line 505
    const v1, 0x3f3d70a4    # 0.74f

    .line 506
    .line 507
    .line 508
    const/16 v0, 0x50

    .line 509
    .line 510
    invoke-static {v2, v3, v1, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 511
    .line 512
    .line 513
    const/16 v5, 0x64

    .line 514
    .line 515
    const/16 v3, 0x154

    .line 516
    .line 517
    const v1, 0x3f2e147b    # 0.68f

    .line 518
    .line 519
    .line 520
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 521
    .line 522
    invoke-direct {v0, v5, v7, v1, v3}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 523
    .line 524
    .line 525
    aput-object v0, v2, v8

    .line 526
    .line 527
    const/16 v1, 0x21c

    .line 528
    .line 529
    const v0, 0x3f051eb8    # 0.52f

    .line 530
    .line 531
    .line 532
    invoke-static {v1, v0, v10}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 533
    .line 534
    .line 535
    move-result-object v0

    .line 536
    goto/16 :goto_0

    .line 537
    .line 538
    :pswitch_d
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 539
    .line 540
    const/16 v3, 0x28

    .line 541
    .line 542
    const v0, 0x3e75c28f    # 0.24f

    .line 543
    .line 544
    .line 545
    invoke-static {v2, v0, v1, v3, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 546
    .line 547
    .line 548
    const/16 v1, 0x8c

    .line 549
    .line 550
    const v0, 0x3f7ae148    # 0.98f

    .line 551
    .line 552
    .line 553
    invoke-static {v2, v13, v0, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 554
    .line 555
    .line 556
    const/16 v3, 0xdc

    .line 557
    .line 558
    const v1, 0x3f70a3d7    # 0.94f

    .line 559
    .line 560
    .line 561
    const v0, 0x3e3851ec    # 0.18f

    .line 562
    .line 563
    .line 564
    invoke-static {v3, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 565
    .line 566
    .line 567
    move-result-object v0

    .line 568
    goto/16 :goto_0

    .line 569
    .line 570
    :pswitch_e
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 571
    .line 572
    const v3, 0x3f19999a    # 0.6f

    .line 573
    .line 574
    .line 575
    const v1, 0x3e851eb8    # 0.26f

    .line 576
    .line 577
    .line 578
    const/16 v0, 0x50

    .line 579
    .line 580
    invoke-static {v2, v3, v1, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 581
    .line 582
    .line 583
    const/16 v5, 0x78

    .line 584
    .line 585
    const/16 v3, 0xc8

    .line 586
    .line 587
    const v1, 0x3e3851ec    # 0.18f

    .line 588
    .line 589
    .line 590
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 591
    .line 592
    invoke-direct {v0, v5, v1, v1, v3}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 593
    .line 594
    .line 595
    aput-object v0, v2, v8

    .line 596
    .line 597
    const v3, 0x3eeb851f    # 0.46f

    .line 598
    .line 599
    .line 600
    const v1, 0x3eb851ec    # 0.36f

    .line 601
    .line 602
    .line 603
    const/16 v0, 0x190

    .line 604
    .line 605
    invoke-static {v0, v3, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 606
    .line 607
    .line 608
    move-result-object v0

    .line 609
    goto/16 :goto_0

    .line 610
    .line 611
    :pswitch_f
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 612
    .line 613
    const/16 v5, 0x82

    .line 614
    .line 615
    const v1, 0x3e75c28f    # 0.24f

    .line 616
    .line 617
    .line 618
    invoke-static {v2, v1, v0, v5, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 619
    .line 620
    .line 621
    const/16 v5, 0x122

    .line 622
    .line 623
    const v1, 0x3e99999a    # 0.3f

    .line 624
    .line 625
    .line 626
    invoke-static {v2, v1, v0, v5, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 627
    .line 628
    .line 629
    const/16 v5, 0x1c2

    .line 630
    .line 631
    const v1, 0x3eb851ec    # 0.36f

    .line 632
    .line 633
    .line 634
    invoke-static {v2, v1, v0, v5, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 635
    .line 636
    .line 637
    const/16 v4, 0x26c

    .line 638
    .line 639
    const v1, 0x3ec28f5c    # 0.38f

    .line 640
    .line 641
    .line 642
    const v0, 0x3e3851ec    # 0.18f

    .line 643
    .line 644
    .line 645
    invoke-static {v4, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 646
    .line 647
    .line 648
    move-result-object v0

    .line 649
    goto/16 :goto_2

    .line 650
    .line 651
    :pswitch_10
    const/16 v2, 0xdc

    .line 652
    .line 653
    const v0, 0x3ef5c28f    # 0.48f

    .line 654
    .line 655
    .line 656
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 657
    .line 658
    .line 659
    move-result-object v0

    .line 660
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 661
    .line 662
    .line 663
    move-result-object v0

    .line 664
    return-object v0

    .line 665
    :pswitch_11
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 666
    .line 667
    const v10, 0x3ee147ae    # 0.44f

    .line 668
    .line 669
    .line 670
    const v6, 0x3ec28f5c    # 0.38f

    .line 671
    .line 672
    .line 673
    const/16 v0, 0x3c

    .line 674
    .line 675
    invoke-static {v2, v10, v6, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 676
    .line 677
    .line 678
    const/16 v10, 0xa0

    .line 679
    .line 680
    const/16 v9, 0x1a4

    .line 681
    .line 682
    const/high16 v6, 0x3f000000    # 0.5f

    .line 683
    .line 684
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 685
    .line 686
    invoke-direct {v0, v10, v5, v6, v9}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 687
    .line 688
    .line 689
    aput-object v0, v2, v8

    .line 690
    .line 691
    move/from16 v0, p0

    .line 692
    .line 693
    invoke-static {v2, v7, v0, v9, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 694
    .line 695
    .line 696
    const/16 v0, 0x26c

    .line 697
    .line 698
    invoke-static {v0, v15, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 699
    .line 700
    .line 701
    move-result-object v0

    .line 702
    goto/16 :goto_2

    .line 703
    .line 704
    :pswitch_12
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 705
    .line 706
    const v5, 0x3e851eb8    # 0.26f

    .line 707
    .line 708
    .line 709
    const v3, 0x3ea3d70a    # 0.32f

    .line 710
    .line 711
    .line 712
    const/16 v0, 0x64

    .line 713
    .line 714
    invoke-static {v2, v5, v3, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 715
    .line 716
    .line 717
    const/16 v7, 0xb4

    .line 718
    .line 719
    const/16 v6, 0x104

    .line 720
    .line 721
    const v5, 0x3dcccccd    # 0.1f

    .line 722
    .line 723
    .line 724
    const/high16 v3, 0x3f000000    # 0.5f

    .line 725
    .line 726
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 727
    .line 728
    invoke-direct {v0, v7, v5, v3, v6}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 729
    .line 730
    .line 731
    aput-object v0, v2, v8

    .line 732
    .line 733
    const v3, 0x3e75c28f    # 0.24f

    .line 734
    .line 735
    .line 736
    const/16 v0, 0x208

    .line 737
    .line 738
    invoke-static {v0, v3, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    goto/16 :goto_0

    .line 743
    .line 744
    :pswitch_13
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 745
    .line 746
    const/16 v0, 0x64

    .line 747
    .line 748
    invoke-static {v2, v10, v5, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 749
    .line 750
    .line 751
    const/16 v3, 0x136

    .line 752
    .line 753
    const v1, 0x3f0f5c29    # 0.56f

    .line 754
    .line 755
    .line 756
    const v0, 0x3e23d70a    # 0.16f

    .line 757
    .line 758
    .line 759
    invoke-static {v2, v1, v0, v3, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 760
    .line 761
    .line 762
    const/16 v3, 0x23a

    .line 763
    .line 764
    const v1, 0x3f428f5c    # 0.76f

    .line 765
    .line 766
    .line 767
    const v0, 0x3e75c28f    # 0.24f

    .line 768
    .line 769
    .line 770
    invoke-static {v3, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 771
    .line 772
    .line 773
    move-result-object v0

    .line 774
    goto :goto_0

    .line 775
    :pswitch_14
    const v1, 0x3e75c28f    # 0.24f

    .line 776
    .line 777
    .line 778
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 779
    .line 780
    const/16 v0, 0x1e0

    .line 781
    .line 782
    invoke-static {v2, v7, v1, v0, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 783
    .line 784
    .line 785
    const/16 v0, 0x258

    .line 786
    .line 787
    invoke-static {v2, v15, v7, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 788
    .line 789
    .line 790
    const/16 v1, 0x2a8

    .line 791
    .line 792
    const v0, 0x3e6147ae    # 0.22f

    .line 793
    .line 794
    .line 795
    invoke-static {v1, v0, v13}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 796
    .line 797
    .line 798
    move-result-object v0

    .line 799
    goto :goto_0

    .line 800
    :pswitch_15
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 801
    .line 802
    const/16 v3, 0x78

    .line 803
    .line 804
    const v0, 0x3e99999a    # 0.3f

    .line 805
    .line 806
    .line 807
    invoke-static {v2, v5, v0, v3, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 808
    .line 809
    .line 810
    const/16 v0, 0x21c

    .line 811
    .line 812
    const v3, 0x3e75c28f    # 0.24f

    .line 813
    .line 814
    .line 815
    invoke-static {v2, v15, v3, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 816
    .line 817
    .line 818
    const/16 v0, 0x294

    .line 819
    .line 820
    invoke-static {v0, v3, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 821
    .line 822
    .line 823
    move-result-object v0

    .line 824
    goto :goto_0

    .line 825
    :pswitch_16
    const v4, 0x3e75c28f    # 0.24f

    .line 826
    .line 827
    .line 828
    const v3, 0x3ecccccd    # 0.4f

    .line 829
    .line 830
    .line 831
    const v2, 0x3f051eb8    # 0.52f

    .line 832
    .line 833
    .line 834
    const/16 v0, 0x50

    .line 835
    .line 836
    invoke-static {v0, v3, v2}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 837
    .line 838
    .line 839
    move-result-object v2

    .line 840
    const/16 v0, 0x10e

    .line 841
    .line 842
    invoke-static {v0, v4, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 843
    .line 844
    .line 845
    move-result-object v0

    .line 846
    filled-new-array {v2, v0}, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 847
    .line 848
    .line 849
    move-result-object v2

    .line 850
    goto/16 :goto_3

    .line 851
    .line 852
    :pswitch_17
    new-array v2, v3, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 853
    .line 854
    const v1, 0x3eeb851f    # 0.46f

    .line 855
    .line 856
    .line 857
    invoke-static {v9, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 858
    .line 859
    .line 860
    move-result-object v0

    .line 861
    aput-object v0, v2, v9

    .line 862
    .line 863
    const/16 v5, 0xa0

    .line 864
    .line 865
    const v3, 0x3e19999a    # 0.15f

    .line 866
    .line 867
    .line 868
    const v1, 0x3f570a3d    # 0.84f

    .line 869
    .line 870
    .line 871
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 872
    .line 873
    invoke-direct {v0, v5, v3, v1, v5}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 874
    .line 875
    .line 876
    aput-object v0, v2, v8

    .line 877
    .line 878
    const/16 v3, 0x140

    .line 879
    .line 880
    const v1, 0x3e75c28f    # 0.24f

    .line 881
    .line 882
    .line 883
    move/from16 v0, v16

    .line 884
    .line 885
    invoke-static {v3, v1, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 886
    .line 887
    .line 888
    move-result-object v0

    .line 889
    :goto_0
    aput-object v0, v2, v4

    .line 890
    .line 891
    goto/16 :goto_3

    .line 892
    .line 893
    :pswitch_18
    const/4 v2, 0x5

    .line 894
    new-array v2, v2, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 895
    .line 896
    const/16 v10, 0x17c

    .line 897
    .line 898
    const v7, 0x3e23d70a    # 0.16f

    .line 899
    .line 900
    .line 901
    new-instance v5, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 902
    .line 903
    invoke-direct {v5, v9, v7, v0, v10}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 904
    .line 905
    .line 906
    aput-object v5, v2, v9

    .line 907
    .line 908
    const/16 v5, 0x69

    .line 909
    .line 910
    const v0, 0x3e99999a    # 0.3f

    .line 911
    .line 912
    .line 913
    invoke-static {v2, v0, v6, v5, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 914
    .line 915
    .line 916
    const/16 v6, 0xd2

    .line 917
    .line 918
    const v5, 0x3ec28f5c    # 0.38f

    .line 919
    .line 920
    .line 921
    move/from16 v0, p0

    .line 922
    .line 923
    invoke-static {v2, v5, v0, v6, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 924
    .line 925
    .line 926
    const/16 v4, 0x13b

    .line 927
    .line 928
    const v0, 0x3e75c28f    # 0.24f

    .line 929
    .line 930
    .line 931
    invoke-static {v2, v0, v1, v4, v3}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 932
    .line 933
    .line 934
    const v3, 0x3dcccccd    # 0.1f

    .line 935
    .line 936
    .line 937
    const v1, 0x3ee66666    # 0.45f

    .line 938
    .line 939
    .line 940
    const/16 v0, 0x1a4

    .line 941
    .line 942
    invoke-static {v0, v3, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 943
    .line 944
    .line 945
    move-result-object v0

    .line 946
    goto :goto_1

    .line 947
    :pswitch_19
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 948
    .line 949
    const/16 v1, 0x32

    .line 950
    .line 951
    invoke-static {v2, v15, v0, v1, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 952
    .line 953
    .line 954
    const v6, 0x3ee147ae    # 0.44f

    .line 955
    .line 956
    .line 957
    const v5, 0x3f28f5c3    # 0.66f

    .line 958
    .line 959
    .line 960
    const/16 v1, 0x8c

    .line 961
    .line 962
    invoke-static {v2, v6, v5, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 963
    .line 964
    .line 965
    const/16 v5, 0xf0

    .line 966
    .line 967
    const v1, 0x3eb33333    # 0.35f

    .line 968
    .line 969
    .line 970
    invoke-static {v2, v1, v0, v5, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 971
    .line 972
    .line 973
    const/16 v4, 0x17c

    .line 974
    .line 975
    const v1, 0x3e3851ec    # 0.18f

    .line 976
    .line 977
    .line 978
    move/from16 v0, v16

    .line 979
    .line 980
    invoke-static {v4, v1, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 981
    .line 982
    .line 983
    move-result-object v0

    .line 984
    goto/16 :goto_2

    .line 985
    .line 986
    :pswitch_1a
    const/4 v1, 0x5

    .line 987
    new-array v2, v1, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 988
    .line 989
    const v1, 0x3df5c28f    # 0.12f

    .line 990
    .line 991
    .line 992
    invoke-static {v9, v15, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 993
    .line 994
    .line 995
    move-result-object v1

    .line 996
    aput-object v1, v2, v9

    .line 997
    .line 998
    const/16 v9, 0x50

    .line 999
    .line 1000
    const/16 v7, 0x208

    .line 1001
    .line 1002
    const v6, 0x3edc28f6    # 0.43f

    .line 1003
    .line 1004
    .line 1005
    const v5, 0x3e0f5c29    # 0.14f

    .line 1006
    .line 1007
    .line 1008
    new-instance v1, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1009
    .line 1010
    invoke-direct {v1, v9, v6, v5, v7}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 1011
    .line 1012
    .line 1013
    aput-object v1, v2, v8

    .line 1014
    .line 1015
    const/16 v1, 0x6e

    .line 1016
    .line 1017
    invoke-static {v2, v11, v0, v1, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1018
    .line 1019
    .line 1020
    const/16 v4, 0x104

    .line 1021
    .line 1022
    const v1, 0x3ee66666    # 0.45f

    .line 1023
    .line 1024
    .line 1025
    move/from16 v0, v16

    .line 1026
    .line 1027
    invoke-static {v2, v1, v0, v4, v3}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1028
    .line 1029
    .line 1030
    const/16 v1, 0x18b

    .line 1031
    .line 1032
    const v0, 0x3eb851ec    # 0.36f

    .line 1033
    .line 1034
    .line 1035
    invoke-static {v1, v0, v13}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1036
    .line 1037
    .line 1038
    move-result-object v0

    .line 1039
    :goto_1
    aput-object v0, v2, v14

    .line 1040
    .line 1041
    goto/16 :goto_3

    .line 1042
    .line 1043
    :pswitch_1b
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1044
    .line 1045
    const/16 v1, 0x46

    .line 1046
    .line 1047
    const v0, 0x3f23d70a    # 0.64f

    .line 1048
    .line 1049
    .line 1050
    invoke-static {v2, v0, v7, v1, v9}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1051
    .line 1052
    .line 1053
    const v5, 0x3f0a3d71    # 0.54f

    .line 1054
    .line 1055
    .line 1056
    const v1, 0x3f28f5c3    # 0.66f

    .line 1057
    .line 1058
    .line 1059
    const/16 v0, 0xb4

    .line 1060
    .line 1061
    invoke-static {v2, v5, v1, v0, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1062
    .line 1063
    .line 1064
    const/16 v1, 0x136

    .line 1065
    .line 1066
    const/high16 v0, 0x3e800000    # 0.25f

    .line 1067
    .line 1068
    invoke-static {v2, v0, v11, v1, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1069
    .line 1070
    .line 1071
    const/16 v4, 0x1c2

    .line 1072
    .line 1073
    const v1, 0x3e2e147b    # 0.17f

    .line 1074
    .line 1075
    .line 1076
    move/from16 v0, p0

    .line 1077
    .line 1078
    invoke-static {v4, v1, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1079
    .line 1080
    .line 1081
    move-result-object v0

    .line 1082
    goto :goto_2

    .line 1083
    :pswitch_1c
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1084
    .line 1085
    const/16 v7, 0x50

    .line 1086
    .line 1087
    const/16 v6, 0x154

    .line 1088
    .line 1089
    const v1, 0x3dcccccd    # 0.1f

    .line 1090
    .line 1091
    .line 1092
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1093
    .line 1094
    invoke-direct {v0, v7, v5, v1, v6}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 1095
    .line 1096
    .line 1097
    aput-object v0, v2, v9

    .line 1098
    .line 1099
    const/16 v5, 0xaa

    .line 1100
    .line 1101
    const v1, 0x3f3d70a4    # 0.74f

    .line 1102
    .line 1103
    .line 1104
    const v0, 0x3e75c28f    # 0.24f

    .line 1105
    .line 1106
    .line 1107
    invoke-static {v2, v1, v0, v5, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1108
    .line 1109
    .line 1110
    const/16 v1, 0xd2

    .line 1111
    .line 1112
    const/high16 v0, 0x3f000000    # 0.5f

    .line 1113
    .line 1114
    invoke-static {v2, v15, v0, v1, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1115
    .line 1116
    .line 1117
    const v4, 0x3e6147ae    # 0.22f

    .line 1118
    .line 1119
    .line 1120
    const v1, 0x3f2e147b    # 0.68f

    .line 1121
    .line 1122
    .line 1123
    const/16 v0, 0x10e

    .line 1124
    .line 1125
    invoke-static {v0, v4, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1126
    .line 1127
    .line 1128
    move-result-object v0

    .line 1129
    goto :goto_2

    .line 1130
    :pswitch_1d
    new-array v2, v14, [Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1131
    .line 1132
    const v1, 0x3ea3d70a    # 0.32f

    .line 1133
    .line 1134
    .line 1135
    const v0, 0x3df5c28f    # 0.12f

    .line 1136
    .line 1137
    .line 1138
    invoke-static {v9, v1, v0}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1139
    .line 1140
    .line 1141
    move-result-object v0

    .line 1142
    aput-object v0, v2, v9

    .line 1143
    .line 1144
    const/16 v1, 0xaa

    .line 1145
    .line 1146
    const v0, 0x3e75c28f    # 0.24f

    .line 1147
    .line 1148
    .line 1149
    invoke-static {v2, v0, v13, v1, v8}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1150
    .line 1151
    .line 1152
    const/16 v1, 0x113

    .line 1153
    .line 1154
    const v0, 0x3eeb851f    # 0.46f

    .line 1155
    .line 1156
    .line 1157
    invoke-static {v2, v12, v0, v1, v4}, LX/IEa;->A1N([Ljava/lang/Object;FFII)V

    .line 1158
    .line 1159
    .line 1160
    const/16 v4, 0x14f

    .line 1161
    .line 1162
    const v1, 0x3f570a3d    # 0.84f

    .line 1163
    .line 1164
    .line 1165
    const v0, 0x3e23d70a    # 0.16f

    .line 1166
    .line 1167
    .line 1168
    invoke-static {v4, v0, v1}, Lcom/facebook/aura/components/reactions/AuraReactionHapticsKt;->tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 1169
    .line 1170
    .line 1171
    move-result-object v0

    .line 1172
    :goto_2
    aput-object v0, v2, v3

    .line 1173
    .line 1174
    :goto_3
    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v0

    .line 1178
    return-object v0

    .line 1179
    :pswitch_1e
    const/4 v0, 0x0

    .line 1180
    return-object v0

    .line 1181
    nop

    .line 1182
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_1e
        :pswitch_1e
        :pswitch_14
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static final supportsPrimitives(Landroid/os/Vibrator;)Z
    .locals 2

    .line 0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1
    .line 2
    const/16 v0, 0x1e

    .line 3
    .line 4
    if-lt v1, v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x7

    .line 7
    const/4 v1, 0x1

    .line 8
    filled-new-array {v1, v0}, [I

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p0, v0}, Landroid/os/Vibrator;->areAllPrimitivesSupported([I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    return v1

    .line 19
    :cond_0
    const/4 v1, 0x0

    .line 20
    return v1
.end method

.method public static final tap(IFF)Lcom/facebook/aura/components/reactions/HapticBeat;
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/components/reactions/HapticBeat;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1, p2, v1}, Lcom/facebook/aura/components/reactions/HapticBeat;-><init>(IFFI)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
