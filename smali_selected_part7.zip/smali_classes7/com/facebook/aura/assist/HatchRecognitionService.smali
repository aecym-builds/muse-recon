.class public final Lcom/facebook/aura/assist/HatchRecognitionService;
.super Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;
.source ""


# static fields
.field public static final $stable:I = 0x8


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/speech/RecognitionService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
