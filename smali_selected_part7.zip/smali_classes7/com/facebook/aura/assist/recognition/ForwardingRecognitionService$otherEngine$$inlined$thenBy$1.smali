.class public final Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$thenBy$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation


# instance fields
.field public final synthetic $this_thenBy:Ljava/util/Comparator;


# direct methods
.method public constructor <init>(Ljava/util/Comparator;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$thenBy$1;->$this_thenBy:Ljava/util/Comparator;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$thenBy$1;->$this_thenBy:Ljava/util/Comparator;

    .line 1
    .line 2
    invoke-interface {p0, p1, p2}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-nez p0, :cond_0

    .line 7
    .line 8
    check-cast p1, Landroid/content/pm/PackageItemInfo;

    .line 9
    .line 10
    iget-object p1, p1, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 11
    .line 12
    check-cast p2, Landroid/content/pm/PackageItemInfo;

    .line 13
    .line 14
    iget-object p0, p2, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {p1, p0}, LX/34d;->A00(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    :cond_0
    return p0
.end method
