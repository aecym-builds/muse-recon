.class public final Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/speech/RecognitionListener;


# instance fields
.field public final caller:Landroid/speech/RecognitionService$Callback;


# direct methods
.method public constructor <init>(Landroid/speech/RecognitionService$Callback;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 8
    .line 9
    return-void
.end method

.method private final relay(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    :try_start_0
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    :catch_0
    move-exception p0

    .line 5
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public onBeginningOfSpeech()V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroid/speech/RecognitionService$Callback;->beginningOfSpeech()V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onBufferReceived([B)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->bufferReceived([B)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onEndOfSegmentedSession()V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroid/speech/RecognitionService$Callback;->endOfSegmentedSession()V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onEndOfSpeech()V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroid/speech/RecognitionService$Callback;->endOfSpeech()V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onError(I)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->error(I)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onEvent(ILandroid/os/Bundle;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onLanguageDetection(Landroid/os/Bundle;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Landroid/speech/RecognitionService$Callback;->languageDetection(Landroid/os/Bundle;)V

    .line 7
    .line 8
    .line 9
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    :catch_0
    move-exception v0

    .line 11
    invoke-static {v0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public onPartialResults(Landroid/os/Bundle;)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->partialResults(Landroid/os/Bundle;)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onReadyForSpeech(Landroid/os/Bundle;)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->readyForSpeech(Landroid/os/Bundle;)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onResults(Landroid/os/Bundle;)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->results(Landroid/os/Bundle;)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 0

    .line 0
    :try_start_0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 1
    .line 2
    invoke-virtual {p0, p1}, Landroid/speech/RecognitionService$Callback;->rmsChanged(F)V

    .line 3
    .line 4
    .line 5
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    :catch_0
    move-exception p0

    .line 7
    invoke-static {p0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onSegmentResults(Landroid/os/Bundle;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;->caller:Landroid/speech/RecognitionService$Callback;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Landroid/speech/RecognitionService$Callback;->segmentResults(Landroid/os/Bundle;)V

    .line 7
    .line 8
    .line 9
    return-void
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    :catch_0
    move-exception v0

    .line 11
    invoke-static {v0}, LX/IEa;->A1J(Ljava/lang/Throwable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
