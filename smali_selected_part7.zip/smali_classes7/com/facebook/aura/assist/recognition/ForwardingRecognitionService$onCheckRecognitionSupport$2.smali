.class public final Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/speech/RecognitionSupportCallback;


# instance fields
.field public final synthetic $recognizer:Landroid/speech/SpeechRecognizer;

.field public final synthetic $supportCallback:Landroid/speech/RecognitionService$SupportCallback;

.field public final synthetic this$0:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;Landroid/speech/SpeechRecognizer;Landroid/speech/RecognitionService$SupportCallback;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->this$0:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$recognizer:Landroid/speech/SpeechRecognizer;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$supportCallback:Landroid/speech/RecognitionService$SupportCallback;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public onError(I)V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->this$0:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$recognizer:Landroid/speech/SpeechRecognizer;

    .line 3
    .line 4
    invoke-static {v1, v0}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->access$releaseChecker(Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;Landroid/speech/SpeechRecognizer;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$supportCallback:Landroid/speech/RecognitionService$SupportCallback;

    .line 8
    .line 9
    :try_start_0
    invoke-virtual {v0, p1}, Landroid/speech/RecognitionService$SupportCallback;->onError(I)V

    .line 10
    .line 11
    .line 12
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    :catch_0
    move-exception p0

    .line 14
    const-string v1, "Recognition support caller is gone"

    .line 15
    .line 16
    const-string v0, "ForwardingRecognition"

    .line 17
    .line 18
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public onSupportResult(Landroid/speech/RecognitionSupport;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->this$0:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$recognizer:Landroid/speech/SpeechRecognizer;

    .line 7
    .line 8
    invoke-static {v1, v0}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->access$releaseChecker(Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;Landroid/speech/SpeechRecognizer;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;->$supportCallback:Landroid/speech/RecognitionService$SupportCallback;

    .line 12
    .line 13
    :try_start_0
    invoke-virtual {v0, p1}, Landroid/speech/RecognitionService$SupportCallback;->onSupportResult(Landroid/speech/RecognitionSupport;)V

    .line 14
    .line 15
    .line 16
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    move-exception p0

    .line 18
    const-string v1, "Recognition support caller is gone"

    .line 19
    .line 20
    const-string v0, "ForwardingRecognition"

    .line 21
    .line 22
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method
