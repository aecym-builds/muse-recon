.class public Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;
.super Landroid/speech/RecognitionService;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Companion;

.field public static final TAG:Ljava/lang/String; = "ForwardingRecognition"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final canDestroyDuringSupportCheck:Z


# instance fields
.field public checker:Landroid/speech/SpeechRecognizer;

.field public download:Landroid/speech/SpeechRecognizer;

.field public session:Landroid/speech/SpeechRecognizer;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->Companion:Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Companion;

    .line 6
    .line 7
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    .line 9
    const/16 v0, 0x21

    .line 10
    .line 11
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    sput-boolean v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->canDestroyDuringSupportCheck:Z

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/speech/RecognitionService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getCanDestroyDuringSupportCheck$cp()Z
    .locals 1

    .line 0
    sget-boolean v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->canDestroyDuringSupportCheck:Z

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$releaseChecker(Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;Landroid/speech/SpeechRecognizer;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->releaseChecker(Landroid/speech/SpeechRecognizer;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final otherEngine()Landroid/speech/SpeechRecognizer;
    .locals 5

    .line 0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const-string v0, "android.speech.RecognitionService"

    .line 5
    .line 6
    new-instance v1, Landroid/content/Intent;

    .line 7
    .line 8
    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-virtual {v2, v1, v0}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Landroid/content/pm/ResolveInfo;

    .line 38
    .line 39
    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    .line 40
    .line 41
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    :cond_1
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_2

    .line 58
    .line 59
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    move-object v0, v2

    .line 64
    check-cast v0, Landroid/content/pm/PackageItemInfo;

    .line 65
    .line 66
    iget-object v1, v0, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 67
    .line 68
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-nez v0, :cond_1

    .line 77
    .line 78
    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_2
    new-instance v1, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$compareByDescending$1;

    .line 83
    .line 84
    invoke-direct {v1}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$compareByDescending$1;-><init>()V

    .line 85
    .line 86
    .line 87
    new-instance v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$thenBy$1;

    .line 88
    .line 89
    invoke-direct {v0, v1}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$otherEngine$$inlined$thenBy$1;-><init>(Ljava/util/Comparator;)V

    .line 90
    .line 91
    .line 92
    invoke-static {v4, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-static {v0}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    check-cast v0, Landroid/content/pm/PackageItemInfo;

    .line 101
    .line 102
    if-eqz v0, :cond_3

    .line 103
    .line 104
    iget-object v2, v0, Landroid/content/pm/PackageItemInfo;->packageName:Ljava/lang/String;

    .line 105
    .line 106
    iget-object v1, v0, Landroid/content/pm/PackageItemInfo;->name:Ljava/lang/String;

    .line 107
    .line 108
    new-instance v0, Landroid/content/ComponentName;

    .line 109
    .line 110
    invoke-direct {v0, v2, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    invoke-static {p0, v0}, Landroid/speech/SpeechRecognizer;->createSpeechRecognizer(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/speech/SpeechRecognizer;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    return-object v0

    .line 118
    :cond_3
    const/4 v0, 0x0

    .line 119
    return-object v0
.end method

.method private final relaySupport(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    :try_start_0
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    :catch_0
    move-exception p1

    .line 5
    const-string p0, "Recognition support caller is gone"

    .line 6
    .line 7
    const-string v0, "ForwardingRecognition"

    .line 8
    .line 9
    invoke-static {v0, p0, p1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private final releaseChecker(Landroid/speech/SpeechRecognizer;)V
    .locals 1

    .line 0
    invoke-virtual {p1}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->checker:Landroid/speech/SpeechRecognizer;

    .line 4
    .line 5
    if-ne v0, p1, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->checker:Landroid/speech/SpeechRecognizer;

    .line 9
    .line 10
    :cond_0
    return-void
.end method


# virtual methods
.method public onCancel(Landroid/speech/RecognitionService$Callback;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->session:Landroid/speech/SpeechRecognizer;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/speech/SpeechRecognizer;->cancel()V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method public onCheckRecognitionSupport(Landroid/content/Intent;Landroid/speech/RecognitionService$SupportCallback;)V
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->checker:Landroid/speech/SpeechRecognizer;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->otherEngine()Landroid/speech/SpeechRecognizer;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    sget-boolean v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->canDestroyDuringSupportCheck:Z

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    iput-object v2, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->checker:Landroid/speech/SpeechRecognizer;

    .line 19
    .line 20
    :cond_1
    if-nez v2, :cond_2

    .line 21
    .line 22
    const/16 v0, 0xe

    .line 23
    .line 24
    :try_start_0
    invoke-virtual {p2, v0}, Landroid/speech/RecognitionService$SupportCallback;->onError(I)V

    .line 25
    .line 26
    .line 27
    return-void
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 28
    :catch_0
    move-exception v2

    .line 29
    const-string v1, "Recognition support caller is gone"

    .line 30
    .line 31
    const-string v0, "ForwardingRecognition"

    .line 32
    .line 33
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    new-instance v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;

    .line 42
    .line 43
    invoke-direct {v0, p0, v2, p2}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$onCheckRecognitionSupport$2;-><init>(Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;Landroid/speech/SpeechRecognizer;Landroid/speech/RecognitionService$SupportCallback;)V

    .line 44
    .line 45
    .line 46
    check-cast v0, Landroid/speech/RecognitionSupportCallback;

    .line 47
    .line 48
    invoke-virtual {v2, p1, v1, v0}, Landroid/speech/SpeechRecognizer;->checkRecognitionSupport(Landroid/content/Intent;Ljava/util/concurrent/Executor;Landroid/speech/RecognitionSupportCallback;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->session:Landroid/speech/SpeechRecognizer;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 5
    .line 6
    .line 7
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->download:Landroid/speech/SpeechRecognizer;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 12
    .line 13
    .line 14
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->checker:Landroid/speech/SpeechRecognizer;

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 19
    .line 20
    .line 21
    :cond_2
    invoke-super {p0}, Landroid/speech/RecognitionService;->onDestroy()V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public onStartListening(Landroid/content/Intent;Landroid/speech/RecognitionService$Callback;)V
    .locals 2

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->session:Landroid/speech/SpeechRecognizer;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->otherEngine()Landroid/speech/SpeechRecognizer;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iput-object v1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->session:Landroid/speech/SpeechRecognizer;

    .line 15
    .line 16
    if-nez v1, :cond_1

    .line 17
    .line 18
    const/4 v0, 0x5

    .line 19
    invoke-virtual {p2, v0}, Landroid/speech/RecognitionService$Callback;->error(I)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_1
    new-instance v0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;

    .line 24
    .line 25
    invoke-direct {v0, p2}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService$Relay;-><init>(Landroid/speech/RecognitionService$Callback;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, v0}, Landroid/speech/SpeechRecognizer;->setRecognitionListener(Landroid/speech/RecognitionListener;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, p1}, Landroid/speech/SpeechRecognizer;->startListening(Landroid/content/Intent;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public onStopListening(Landroid/speech/RecognitionService$Callback;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->session:Landroid/speech/SpeechRecognizer;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/speech/SpeechRecognizer;->stopListening()V

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method public onTriggerModelDownload(Landroid/content/Intent;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->otherEngine()Landroid/speech/SpeechRecognizer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->download:Landroid/speech/SpeechRecognizer;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 15
    .line 16
    .line 17
    :cond_0
    iput-object v1, p0, Lcom/facebook/aura/assist/recognition/ForwardingRecognitionService;->download:Landroid/speech/SpeechRecognizer;

    .line 18
    .line 19
    invoke-virtual {v1, p1}, Landroid/speech/SpeechRecognizer;->triggerModelDownload(Landroid/content/Intent;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    return-void
.end method
