.class public final Lcom/facebook/aura/assist/HatchVoiceInteractionService;
.super Landroid/service/voice/VoiceInteractionService;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionService$Companion;

.field public static final TAG:Ljava/lang/String; = "HatchVoiceInteractionSvc"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/assist/HatchVoiceInteractionService$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/assist/HatchVoiceInteractionService;->Companion:Lcom/facebook/aura/assist/HatchVoiceInteractionService$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroid/service/voice/VoiceInteractionService;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public onReady()V
    .locals 1

    .line 0
    invoke-super {p0}, Landroid/service/voice/VoiceInteractionService;->onReady()V

    .line 1
    .line 2
    .line 3
    const-string p0, "HatchVoiceInteractionSvc"

    .line 4
    .line 5
    const-string v0, "onReady"

    .line 6
    .line 7
    invoke-static {p0, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
