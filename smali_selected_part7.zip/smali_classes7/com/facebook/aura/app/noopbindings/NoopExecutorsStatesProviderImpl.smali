.class public final Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getCurrentState()LX/IIX;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl$getCurrentState$1;

    .line 1
    .line 2
    invoke-direct {p0}, Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl$getCurrentState$1;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public onAfterExecution(LX/IIX;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onBeforeExecution(LX/IIX;)V
    .locals 0

    .line 0
    return-void
.end method
