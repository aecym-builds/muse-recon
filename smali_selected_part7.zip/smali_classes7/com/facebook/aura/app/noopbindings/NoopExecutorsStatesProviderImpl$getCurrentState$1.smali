.class public final Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl$getCurrentState$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/IIX;


# instance fields
.field public final state:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-string v1, "ViewerContext"

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl$getCurrentState$1;->state:Ljava/util/Map;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public getState()Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/app/noopbindings/NoopExecutorsStatesProviderImpl$getCurrentState$1;->state:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method
