.class public interface abstract Lcom/facebook/aura/accountcenter/GeneratedMobileConfigStub_com_facebook_aura_accountcenter_accountcenter;
.super Ljava/lang/Object;
.source ""
