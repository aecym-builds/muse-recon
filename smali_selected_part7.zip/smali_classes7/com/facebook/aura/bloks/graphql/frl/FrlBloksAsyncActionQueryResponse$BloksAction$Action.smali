.class public final Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$BloksAction$Action;
.super LX/IUd;
.source ""


# direct methods
.method public constructor <init>(LX/IUc;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getActionBundle()Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$BloksAction$Action$ActionBundle;
    .locals 2

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, 0x3ed566ab

    .line 3
    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-interface {p0, v0}, LX/IUc;->AIR(I)LX/IUc;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v1, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$BloksAction$Action$ActionBundle;

    .line 13
    .line 14
    invoke-direct {v1, v0}, LX/IUd;-><init>(LX/IUc;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-object v1
.end method
