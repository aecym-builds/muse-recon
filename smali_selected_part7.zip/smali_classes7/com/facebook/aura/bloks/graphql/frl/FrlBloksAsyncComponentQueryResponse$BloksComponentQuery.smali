.class public final Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse$BloksComponentQuery;
.super LX/IUd;
.source ""


# direct methods
.method public constructor <init>(LX/IUc;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final asFrlBloksComponentQueryFragment()Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;
    .locals 1

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, 0xb30ba08

    .line 3
    .line 4
    .line 5
    invoke-interface {p0, v0}, LX/IUc;->AaV(I)LX/IUc;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    new-instance v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;

    .line 10
    .line 11
    invoke-direct {v0, p0}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;-><init>(LX/IUc;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method
