.class public final Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;
.super LX/IUd;
.source ""


# static fields
.field public static final BUILD_CONFIG_NAME:Ljava/lang/String; = "frl-android"

.field public static final Companion:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment$Companion;

.field public static final FRAGMENT_NAME_HASH:I = 0xb30ba08


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;->Companion:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/IUc;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final synthetic access$getBUILD_CONFIG_NAME$cp()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;->BUILD_CONFIG_NAME:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getFRAGMENT_NAME_HASH$cp()I
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksComponentQueryFragment;->FRAGMENT_NAME_HASH:I

    .line 1
    .line 2
    return v0
.end method


# virtual methods
.method public final getBloksBundleComponentQuery()Ljava/lang/String;
    .locals 1

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, -0x5e806bc5

    .line 3
    .line 4
    .line 5
    invoke-interface {p0, v0}, LX/JmF;->AIQ(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
