.class public final synthetic Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;
.super LX/DVE;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DVE;",
        "LX/JDM<",
        "LX/IUc;",
        "Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;->INSTANCE:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryImpl$Builder$build$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 6

    .line 0
    const-class v2, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse;

    .line 1
    .line 2
    const-string v4, "<init>(Lcom/facebook/graphql/modelutil/GraphQLData;)V"

    .line 3
    .line 4
    const/4 v5, 0x0

    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v3, "<init>"

    .line 7
    .line 8
    move-object v0, p0

    .line 9
    invoke-direct/range {v0 .. v5}, LX/DVE;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(LX/IUc;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse;

    .line 5
    .line 6
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-static {p1}, LX/IEa;->A0Q(Ljava/lang/Object;)LX/IUc;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    new-instance p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncComponentQueryResponse;

    .line 268435461
    .line 268435462
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 268435463
    .line 268435464
    .line 268435465
    return-object p0
.end method
