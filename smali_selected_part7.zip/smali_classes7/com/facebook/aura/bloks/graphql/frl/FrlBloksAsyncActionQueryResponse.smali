.class public final Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse;
.super LX/IUd;
.source ""


# static fields
.field public static final BUILD_CONFIG_NAME:Ljava/lang/String; = "frl-android"

.field public static final Companion:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$Companion;

.field public static final FRAGMENT_NAME_HASH:I = -0x26bab95d


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse;->Companion:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/IUc;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static final synthetic access$getBUILD_CONFIG_NAME$cp()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse;->BUILD_CONFIG_NAME:Ljava/lang/String;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getFRAGMENT_NAME_HASH$cp()I
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse;->FRAGMENT_NAME_HASH:I

    .line 1
    .line 2
    return v0
.end method


# virtual methods
.method public final getBloksAction()Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$BloksAction;
    .locals 2

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, -0x624a32d8

    .line 3
    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-interface {p0, v0}, LX/IUc;->AIR(I)LX/IUc;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v1, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAsyncActionQueryResponse$BloksAction;

    .line 13
    .line 14
    invoke-direct {v1, v0}, LX/IUd;-><init>(LX/IUc;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-object v1
.end method
