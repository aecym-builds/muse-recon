.class public final Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQuery$Builder;


# instance fields
.field public isBkContextSet:Z

.field public isParamsSet:Z

.field public final params:LX/ISf;

.field public final transientParams:LX/ISf;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, LX/ISf;

    .line 4
    .line 5
    invoke-direct {v0}, LX/ISf;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->params:LX/ISf;

    .line 9
    .line 10
    new-instance v0, LX/ISf;

    .line 11
    .line 12
    invoke-direct {v0}, LX/ISf;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->transientParams:LX/ISf;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public bridge synthetic build()LX/0Eb;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->build()Lcom/facebook/pando/PandoGraphQLRequest;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public build()Lcom/facebook/pando/PandoGraphQLRequest;
    .locals 10

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->isParamsSet:Z

    .line 1
    .line 2
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 3
    .line 4
    .line 5
    iget-boolean v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->isBkContextSet:Z

    .line 6
    .line 7
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 8
    .line 9
    .line 10
    invoke-static {}, LX/IUL;->A00()LX/IVB;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->params:LX/ISf;

    .line 15
    .line 16
    invoke-static {v0}, LX/ISf;->A00(LX/ISf;)Ljava/util/TreeMap;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->transientParams:LX/ISf;

    .line 21
    .line 22
    invoke-static {v0}, LX/ISf;->A00(LX/ISf;)Ljava/util/TreeMap;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    sget-object v8, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder$build$1;->INSTANCE:Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder$build$1;

    .line 27
    .line 28
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    const/4 v3, 0x0

    .line 33
    const-string v2, "FrlBloksAppRootQuery"

    .line 34
    .line 35
    const-string v4, "bloks_app"

    .line 36
    .line 37
    const/4 v9, 0x0

    .line 38
    move p0, v9

    .line 39
    invoke-static/range {v1 .. v10}, LX/IUg;->A00(LX/IVB;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/Map;Ljava/util/Map;LX/JDM;IZ)Lcom/facebook/pando/PandoGraphQLRequest;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    return-object v0
.end method

.method public bridge synthetic setBkContext(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQuery$Builder;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->setBkContext(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;

    .line 268435457
    .line 268435458
    .line 268435459
    return-object p0
.end method

.method public setBkContext(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->params:LX/ISf;

    .line 5
    .line 6
    const-string v0, "bk_context"

    .line 7
    .line 8
    invoke-virtual {v1, p1, v0}, LX/ISf;->A01(Lcom/facebook/graphql/calls/GraphQlCallInput;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->isBkContextSet:Z

    .line 13
    .line 14
    return-object p0
.end method

.method public bridge synthetic setParams(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQuery$Builder;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->setParams(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;

    .line 268435457
    .line 268435458
    .line 268435459
    return-object p0
.end method

.method public bridge synthetic setParams(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQuery$BuilderForBkContext;
    .locals 0

    .line 536870912
    invoke-virtual {p0, p1}, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->setParams(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;

    .line 536870913
    .line 536870914
    .line 536870915
    return-object p0
.end method

.method public setParams(LX/Jgm;)Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->params:LX/ISf;

    .line 5
    .line 6
    const-string v0, "params"

    .line 7
    .line 8
    invoke-virtual {v1, p1, v0}, LX/ISf;->A01(Lcom/facebook/graphql/calls/GraphQlCallInput;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Lcom/facebook/aura/bloks/graphql/frl/FrlBloksAppRootQueryImpl$Builder;->isParamsSet:Z

    .line 13
    .line 14
    return-object p0
.end method
