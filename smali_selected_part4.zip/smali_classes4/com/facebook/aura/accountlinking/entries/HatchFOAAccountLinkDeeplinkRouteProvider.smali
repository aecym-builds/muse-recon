.class public final Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/deeplink/AuraDeeplinkRouteProvider;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public routeSpecs()Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/deeplink/AuraDeeplinkRouteSpec;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v8, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkDeeplinkRouteProvider$routeSpecs$1;

    .line 1
    .line 2
    const/16 v9, 0x7e

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    const-string v1, "foa_ac_link"

    .line 6
    .line 7
    const/4 v7, 0x0

    .line 8
    new-instance v0, Lcom/facebook/aura/deeplink/AuraDeeplinkRouteSpec;

    .line 9
    .line 10
    move-object v3, v2

    .line 11
    move-object v4, v2

    .line 12
    move-object v5, v2

    .line 13
    move-object v6, v2

    .line 14
    move-object p0, v2

    .line 15
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/deeplink/AuraDeeplinkRouteSpec;-><init>(Ljava/lang/String;Ljava/util/List;LX/Fky;LX/I1e;Ljava/util/List;LX/JDM;ZLX/JDN;ILX/04f;)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method
