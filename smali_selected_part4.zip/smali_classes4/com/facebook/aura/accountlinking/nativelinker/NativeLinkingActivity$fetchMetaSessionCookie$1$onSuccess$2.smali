.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.accountlinking.nativelinker.NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2"
    f = "NativeLinkingActivity.kt"
    l = {
        0xef
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $callback:LX/AYT;

.field public final synthetic $cookie:Ljava/lang/String;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/AYT;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;",
            "Ljava/lang/String;",
            "LX/AYT;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$cookie:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$callback:LX/AYT;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$cookie:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$callback:LX/AYT;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/AYT;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v4

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$cookie:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->$callback:LX/AYT;

    .line 23
    .line 24
    iput v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;->label:I

    .line 25
    .line 26
    invoke-static {v2, v1, v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->access$loadInitialPage(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/AYT;LX/2M4;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-ne v0, v4, :cond_0

    .line 31
    .line 32
    return-object v4

    .line 33
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    throw v0
.end method
