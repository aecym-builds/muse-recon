.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson$Companion;


# instance fields
.field public final blob:Ljava/lang/String;

.field public final is_one_tap:Ljava/lang/Boolean;

.field public final purpose:Ljava/lang/String;

.field public final target:Ljava/lang/String;

.field public final token:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p1, 0x1

    .line 1
    .line 2
    const/4 v1, 0x1

    .line 3
    if-eq v1, v0, :cond_0

    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson$$serializer;->descriptor:LX/Da5;

    .line 6
    .line 7
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 8
    .line 9
    .line 10
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    throw v0

    .line 15
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 19
    .line 20
    and-int/lit8 v0, p1, 0x2

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    if-nez v0, :cond_3

    .line 24
    .line 25
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 26
    .line 27
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 28
    .line 29
    if-nez v0, :cond_2

    .line 30
    .line 31
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 32
    .line 33
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 34
    .line 35
    if-nez v0, :cond_1

    .line 36
    .line 37
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 38
    .line 39
    :goto_2
    and-int/lit8 v0, p1, 0x10

    .line 40
    .line 41
    if-nez v0, :cond_4

    .line 42
    .line 43
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 44
    .line 45
    return-void

    .line 46
    :cond_1
    iput-object p5, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 47
    .line 48
    goto :goto_2

    .line 49
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_3
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_4
    iput-object p6, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 56
    .line 57
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V
    .locals 1

    .line 536870912
    const/4 v0, 0x0

    .line 536870913
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 536870914
    .line 536870915
    .line 536870916
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870917
    .line 536870918
    .line 536870919
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 536870920
    .line 536870921
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 536870922
    .line 536870923
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 536870924
    .line 536870925
    iput-object p4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 536870926
    .line 536870927
    iput-object p5, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 536870928
    .line 536870929
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p6, 0x2

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p2, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p6, 0x4

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p3, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p6, 0x8

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p4, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p6, 0x10

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    move-object p5, v1

    .line 268435477
    :cond_3
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 268435478
    .line 268435479
    .line 268435480
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_accountlinking_nativelinker_nativelinker(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-nez v3, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    const/4 v2, 0x2

    .line 25
    if-nez v3, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz v0, :cond_3

    .line 30
    .line 31
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    const/4 v2, 0x3

    .line 39
    if-nez v3, :cond_4

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 42
    .line 43
    if-eqz v0, :cond_5

    .line 44
    .line 45
    :cond_4
    sget-object v1, LX/DYz;->A00:LX/DYz;

    .line 46
    .line 47
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 48
    .line 49
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 50
    .line 51
    .line 52
    :cond_5
    const/4 v2, 0x4

    .line 53
    if-nez v3, :cond_6

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 56
    .line 57
    if-eqz v0, :cond_7

    .line 58
    .line 59
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 62
    .line 63
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 64
    .line 65
    .line 66
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getBlob()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPurpose()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTarget()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getToken()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    mul-int/lit8 v1, v1, 0x1f

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 25
    .line 26
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v1, v0

    .line 31
    mul-int/lit8 v1, v1, 0x1f

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    add-int/2addr v1, v0

    .line 40
    return v1
.end method

.method public final is_one_tap()Ljava/lang/Boolean;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 1
    .line 2
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
