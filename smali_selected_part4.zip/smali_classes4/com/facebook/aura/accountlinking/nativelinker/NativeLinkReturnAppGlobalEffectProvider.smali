.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffectProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/globaleffects/api/AppGlobalEffectProvider;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffectProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffectProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffectProvider;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffectProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public effect()Lcom/facebook/aura/globaleffects/api/AppGlobalEffect;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;

    .line 1
    .line 2
    return-object p0
.end method
