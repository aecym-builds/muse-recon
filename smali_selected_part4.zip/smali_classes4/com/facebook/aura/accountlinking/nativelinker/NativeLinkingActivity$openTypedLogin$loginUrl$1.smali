.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/lang/String;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.accountlinking.nativelinker.NativeLinkingActivity$openTypedLogin$loginUrl$1"
    f = "NativeLinkingActivity.kt"
    l = {
        0x190
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $request:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->$request:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->$request:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->$request:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-object p1

    .line 13
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->$request:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 19
    .line 20
    check-cast v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 21
    .line 22
    iget-object v0, v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 23
    .line 24
    iput v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;->label:I

    .line 25
    .line 26
    invoke-virtual {v1, v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->loginUrl(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;LX/2M4;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    if-ne p1, v3, :cond_0

    .line 31
    .line 32
    return-object v3

    .line 33
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    throw v0
.end method
