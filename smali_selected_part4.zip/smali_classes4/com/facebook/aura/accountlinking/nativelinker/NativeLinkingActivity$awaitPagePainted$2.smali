.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.accountlinking.nativelinker.NativeLinkingActivity$awaitPagePainted$2"
    f = "NativeLinkingActivity.kt"
    l = {
        0x168,
        0x169,
        0x32a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $readyJs:Ljava/lang/String;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->$readyJs:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->$readyJs:Ljava/lang/String;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->label:I

    .line 3
    .line 4
    const/4 v6, 0x3

    .line 5
    const/4 v7, 0x2

    .line 6
    const/4 v4, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    if-eq v0, v4, :cond_3

    .line 10
    .line 11
    if-eq v0, v7, :cond_1

    .line 12
    .line 13
    if-ne v0, v6, :cond_6

    .line 14
    .line 15
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    return-object v5

    .line 21
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_2
    iget-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->$readyJs:Ljava/lang/String;

    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    new-instance v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2$1;

    .line 30
    .line 31
    invoke-direct {v2, v3, v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)V

    .line 32
    .line 33
    .line 34
    iput v4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->label:I

    .line 35
    .line 36
    const-wide/16 v0, 0x1f4

    .line 37
    .line 38
    invoke-static {p0, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-ne p1, v5, :cond_4

    .line 43
    .line 44
    return-object v5

    .line 45
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_4
    invoke-static {p1, v4}, LX/002;->A1b(Ljava/lang/Object;Z)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_5

    .line 53
    .line 54
    iput v7, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->label:I

    .line 55
    .line 56
    const-wide/16 v0, 0x32

    .line 57
    .line 58
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-ne v0, v5, :cond_2

    .line 63
    .line 64
    return-object v5

    .line 65
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 66
    .line 67
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput v6, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;->label:I

    .line 70
    .line 71
    invoke-static {p0}, LX/008;->A1I(LX/2M4;)LX/DSD;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    invoke-virtual {v0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    new-instance v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2$2$1;

    .line 80
    .line 81
    invoke-direct {v2, v4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2$2$1;-><init>(LX/DT0;)V

    .line 82
    .line 83
    .line 84
    const-wide/16 v0, 0x0

    .line 85
    .line 86
    invoke-virtual {v3, v0, v1, v2}, Landroid/webkit/WebView;->postVisualStateCallback(JLandroid/webkit/WebView$VisualStateCallback;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v4}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    if-ne v0, v5, :cond_0

    .line 94
    .line 95
    return-object v5

    .line 96
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    throw v0
.end method
