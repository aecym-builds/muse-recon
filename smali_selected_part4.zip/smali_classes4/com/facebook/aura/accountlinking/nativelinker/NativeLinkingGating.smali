.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

.field public static final isEnabled$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const-string v2, "isEnabled"

    .line 1
    .line 2
    const-string v1, "isEnabled()Z"

    .line 3
    .line 4
    const-class v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

    .line 5
    .line 6
    invoke-static {v0, v2, v1}, LX/603;->A1Z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)[LX/Dqa;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->$$delegatedProperties:[LX/Dqa;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/MC$hatch_android_account_linking;->native_linking_enabled:LX/0d8;

    .line 20
    .line 21
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigBoolean(LX/0d8;)LX/1zE;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->isEnabled$delegate:LX/1zE;

    .line 26
    .line 27
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final isEnabled()Z
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->isEnabled$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    invoke-static {p0, v1, v0}, LX/8mk;->A1X(Ljava/lang/Object;LX/1zE;[LX/Dqa;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method
