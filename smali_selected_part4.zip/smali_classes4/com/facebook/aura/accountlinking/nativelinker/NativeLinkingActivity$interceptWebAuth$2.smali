.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.accountlinking.nativelinker.NativeLinkingActivity$interceptWebAuth$2"
    f = "NativeLinkingActivity.kt"
    l = {
        0xb9,
        0xb9
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->label:I

    .line 3
    .line 4
    const/4 v3, 0x2

    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    if-eq v0, v2, :cond_2

    .line 9
    .line 10
    if-eq v0, v3, :cond_2

    .line 11
    .line 12
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    throw v0

    .line 17
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 21
    .line 22
    iget-object v0, v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    iput v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->label:I

    .line 27
    .line 28
    invoke-static {v1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->access$switchOneTapAccount(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    :goto_0
    if-ne v0, v4, :cond_3

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_1
    iput v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->label:I

    .line 36
    .line 37
    invoke-static {v1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->access$openTypedLogin(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    goto :goto_0

    .line 42
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_3
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 46
    .line 47
    const/4 v1, 0x0

    .line 48
    sget v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->$stable:I

    .line 49
    .line 50
    iput-boolean v1, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchingAccount:Z

    .line 51
    .line 52
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 53
    .line 54
    return-object v0
.end method
