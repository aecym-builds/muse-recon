.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getOneTapFlow(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->getOneTapFlow(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$isAccountLinkAuthCallback(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountLinkAuthCallback(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$isAccountsCenterHome(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountsCenterHome(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$isAccountsCenterWebAuthReturn(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountsCenterWebAuthReturn(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$isNotYouRedirect(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isNotYouRedirect(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$linkDoneResult(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Ljava/lang/Boolean;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->linkDoneResult(Landroid/net/Uri;)Ljava/lang/Boolean;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$toNativeLinkRequest(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/content/Intent;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->toNativeLinkRequest(Landroid/content/Intent;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final getOneTapFlow(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;
    .locals 3

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 1
    .line 2
    const/4 p0, 0x1

    .line 3
    const/4 v2, 0x0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eq v1, v2, :cond_1

    .line 15
    .line 16
    if-eq v1, p0, :cond_1

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    if-eq v1, v0, :cond_0

    .line 20
    .line 21
    const/4 v0, 0x3

    .line 22
    if-ne v1, v0, :cond_4

    .line 23
    .line 24
    const-string v2, "HATCH_ACCOUNT_LINK_TH_UPSELL"

    .line 25
    .line 26
    sget-object v1, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->THREADS:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 27
    .line 28
    :goto_0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 29
    .line 30
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;-><init>(Ljava/lang/String;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;)V

    .line 31
    .line 32
    .line 33
    return-object v0

    .line 34
    :cond_0
    const-string v2, "HATCH_ACCOUNT_LINK_IG_UPSELL"

    .line 35
    .line 36
    sget-object v1, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->INSTAGRAM:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const-string v2, "HATCH_ACCOUNT_LINK_FB_UPSELL"

    .line 40
    .line 41
    sget-object v1, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->FACEBOOK:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 45
    .line 46
    if-eqz v0, :cond_6

    .line 47
    .line 48
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 49
    .line 50
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eq v0, v2, :cond_3

    .line 57
    .line 58
    if-ne v0, p0, :cond_5

    .line 59
    .line 60
    const-string v2, "HATCH_AGE_VERIFICATION_IG_UPSELL"

    .line 61
    .line 62
    sget-object v1, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->INSTAGRAM:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    const-string v2, "HATCH_AGE_VERIFICATION_FB_UPSELL"

    .line 66
    .line 67
    sget-object v1, Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;->FACEBOOK:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_4
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 71
    .line 72
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 73
    .line 74
    .line 75
    throw v0

    .line 76
    :cond_5
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 77
    .line 78
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :cond_6
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 83
    .line 84
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 85
    .line 86
    .line 87
    throw v0
.end method

.method private final isAccountLinkAuthCallback(Landroid/net/Uri;)Z
    .locals 3

    .line 0
    invoke-static {p1}, LX/8mk;->A1S(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 p0, 0x1

    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNT_LINK_AUTH_HOSTS:Ljava/util/Set;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v1, v0}, LX/B89;->A0x(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    invoke-static {v0}, LX/AdT;->A0R(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    :goto_0
    const-string v0, "/account_link_auth"

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    :cond_0
    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const-string v0, "hatch"

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_3

    .line 49
    .line 50
    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    const-string v0, "account_link_auth"

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    :cond_1
    return p0

    .line 63
    :cond_2
    const/4 v1, 0x0

    .line 64
    goto :goto_0

    .line 65
    :cond_3
    return v2
.end method

.method private final isAccountsCenterHome(Landroid/net/Uri;)Z
    .locals 4

    .line 0
    invoke-static {p1}, LX/8mk;->A1S(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 v3, 0x0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountsCenterHost(Landroid/net/Uri;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v2, 0x1

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-static {v0}, LX/AdT;->A0R(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    :goto_0
    const-string v0, "/home"

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    return v2

    .line 33
    :cond_0
    const/4 v1, 0x0

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    return v3
.end method

.method private final isAccountsCenterHost(Landroid/net/Uri;)Z
    .locals 3

    .line 0
    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    const/4 p1, 0x0

    .line 5
    const/4 p0, 0x1

    .line 6
    if-eqz v2, :cond_0

    .line 7
    .line 8
    new-array v1, p0, [C

    .line 9
    .line 10
    const/16 v0, 0x2e

    .line 11
    .line 12
    aput-char v0, v1, p1

    .line 13
    .line 14
    invoke-static {v2, v1}, LX/AdT;->A0j(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    if-nez v1, :cond_1

    .line 19
    .line 20
    :cond_0
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 21
    .line 22
    :cond_1
    const-string v0, "accountscenter"

    .line 23
    .line 24
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    sget-object v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNTS_CENTER_ROOT_DOMAINS:Ljava/util/Set;

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    invoke-static {v1, v0}, LX/B89;->A0r(Ljava/util/List;I)Ljava/util/List;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v0, "."

    .line 38
    .line 39
    invoke-static {v0, v1}, LX/602;->A0e(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-interface {v2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_2

    .line 48
    .line 49
    return p0

    .line 50
    :cond_2
    return p1
.end method

.method private final isAccountsCenterWebAuthReturn(Landroid/net/Uri;)Z
    .locals 2

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountsCenterHost(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-static {v0}, LX/AdT;->A0R(Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    :cond_0
    const-string v0, "/add"

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    :try_start_0
    const-string v0, "background_page"

    .line 27
    .line 28
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    new-instance v1, LX/2PH;

    .line 35
    .line 36
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 37
    .line 38
    .line 39
    :goto_0
    instance-of v0, v1, LX/2PH;

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    if-eqz v1, :cond_1

    .line 44
    .line 45
    const/4 p0, 0x1

    .line 46
    :cond_1
    return p0
.end method

.method private final isNotYouRedirect(Landroid/net/Uri;)Z
    .locals 3

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->isAccountsCenterHost(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {p0, p1, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->returnsToAccountsCenterAdd(Landroid/net/Uri;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    return v1

    .line 15
    :cond_0
    return v2
.end method

.method private final linkDoneResult(Landroid/net/Uri;)Ljava/lang/Boolean;
    .locals 4

    .line 0
    invoke-static {p1}, LX/8mk;->A1S(Landroid/net/Uri;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v0, "agent.meta.ai"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    new-array v2, v0, [C

    .line 27
    .line 28
    const/16 v1, 0x2f

    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    aput-char v1, v2, v0

    .line 32
    .line 33
    invoke-static {v3, v2}, LX/AdT;->A0d(Ljava/lang/String;[C)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    :goto_0
    const-string v0, "/account_link_done"

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_1

    .line 44
    .line 45
    const-string v0, "result"

    .line 46
    .line 47
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const-string v0, "linked"

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    return-object v0

    .line 62
    :cond_0
    move-object v1, p0

    .line 63
    goto :goto_0

    .line 64
    :cond_1
    return-object p0
.end method

.method private final returnsToAccountsCenterAdd(Landroid/net/Uri;I)Z
    .locals 5

    .line 0
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->WEB_AUTH_RETURN_PARAMS:Ljava/util/List;

    .line 1
    .line 2
    instance-of v0, v1, Ljava/util/Collection;

    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    return p0

    .line 14
    :cond_1
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-static {v4}, LX/006;->A18(Ljava/util/Iterator;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    :try_start_0
    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    new-instance v1, LX/2PH;

    .line 35
    .line 36
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 37
    .line 38
    .line 39
    :goto_0
    instance-of v0, v1, LX/2PH;

    .line 40
    .line 41
    const/4 v3, 0x0

    .line 42
    if-eqz v0, :cond_3

    .line 43
    .line 44
    move-object v1, v3

    .line 45
    :cond_3
    check-cast v1, Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v1, :cond_2

    .line 48
    .line 49
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v2}, Landroid/net/Uri;->isOpaque()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-nez v0, :cond_2

    .line 58
    .line 59
    invoke-virtual {v2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    const/4 v1, 0x1

    .line 64
    if-eqz v0, :cond_4

    .line 65
    .line 66
    invoke-static {v0}, LX/AdT;->A0R(Ljava/lang/String;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    :cond_4
    const-string v0, "/add"

    .line 71
    .line 72
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-nez v0, :cond_5

    .line 77
    .line 78
    if-nez p2, :cond_2

    .line 79
    .line 80
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 81
    .line 82
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->returnsToAccountsCenterAdd(Landroid/net/Uri;I)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_2

    .line 87
    .line 88
    :cond_5
    const/4 p0, 0x1

    .line 89
    return p0
.end method

.method public static synthetic returnsToAccountsCenterAdd$default(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;IILjava/lang/Object;)Z
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->returnsToAccountsCenterAdd(Landroid/net/Uri;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method private final toNativeLinkRequest(Landroid/content/Intent;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
    .locals 4

    .line 0
    const-string v0, "native_link_age_account"

    .line 1
    .line 2
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const-string p0, "Required value was null."

    .line 7
    .line 8
    if-nez v0, :cond_3

    .line 9
    .line 10
    const-string v0, "native_link_target"

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    invoke-static {v0}, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->valueOf(Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    const-string v0, "native_link_auth_trace"

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-static {v0}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->valueOf(Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    const-string v0, "native_link_origin"

    .line 35
    .line 36
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    invoke-static {v0}, Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;->valueOf(Ljava/lang/String;)Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    :goto_0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 47
    .line 48
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;)V

    .line 49
    .line 50
    .line 51
    return-object v0

    .line 52
    :cond_0
    const/4 v1, 0x0

    .line 53
    goto :goto_0

    .line 54
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 55
    .line 56
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw v0

    .line 60
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 61
    .line 62
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    throw v0

    .line 66
    :cond_3
    invoke-static {v0}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->valueOf(Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    const-string v0, "native_link_age_url"

    .line 71
    .line 72
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    if-eqz v1, :cond_4

    .line 77
    .line 78
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 79
    .line 80
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-object v0

    .line 84
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 85
    .line 86
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    throw v0
.end method


# virtual methods
.method public final newIntent(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Landroid/content/Intent;
    .locals 3

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const-class v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 4
    .line 5
    new-instance p0, Landroid/content/Intent;

    .line 6
    .line 7
    invoke-direct {p0, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    .line 9
    .line 10
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    check-cast p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 15
    .line 16
    iget-object v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v0, "native_link_target"

    .line 23
    .line 24
    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    iget-object v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v0, "native_link_auth_trace"

    .line 35
    .line 36
    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    iget-object v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->origin:Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

    .line 41
    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    :goto_0
    const-string v1, "native_link_origin"

    .line 49
    .line 50
    :goto_1
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 51
    .line 52
    .line 53
    return-object p0

    .line 54
    :cond_0
    const/4 v0, 0x0

    .line 55
    goto :goto_0

    .line 56
    :cond_1
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 57
    .line 58
    if-eqz v0, :cond_2

    .line 59
    .line 60
    check-cast p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 61
    .line 62
    iget-object v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const-string v0, "native_link_age_account"

    .line 69
    .line 70
    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    const-string v1, "native_link_age_url"

    .line 75
    .line 76
    iget-object v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->url:Ljava/lang/String;

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_2
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 80
    .line 81
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 82
    .line 83
    .line 84
    throw v0
.end method
