.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.accountlinking.nativelinker.NativeLinkingUrls$dialogUrl$3"
    f = "NativeLinkingUrls.kt"
    l = {
        0x5d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $body:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->$body:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->$body:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->$body:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    move-object/from16 v2, p0

    .line 3
    .line 4
    iget v0, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->label:I

    .line 5
    .line 6
    const/4 v13, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    if-ne v0, v13, :cond_2

    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, LX/3Rp;->A0t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    :cond_0
    new-instance v1, LX/2PJ;

    .line 16
    .line 17
    invoke-direct {v1, v0}, LX/2PJ;-><init>(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-object v1

    .line 21
    :cond_1
    invoke-static/range {p1 .. p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 25
    .line 26
    sget-object v7, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogPath;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogPath;

    .line 27
    .line 28
    iget-object v8, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->$body:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 29
    .line 30
    sget-object v9, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 31
    .line 32
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 33
    .line 34
    .line 35
    move-result-object v10

    .line 36
    sget-object v17, LX/0wX;->A00:LX/0wX;

    .line 37
    .line 38
    sget-object v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 39
    .line 40
    sget-object v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3$invokeSuspend$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 41
    .line 42
    const/4 v6, 0x0

    .line 43
    const/4 v12, 0x0

    .line 44
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$1:Ljava/lang/Object;

    .line 47
    .line 48
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$2:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$3:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$4:Ljava/lang/Object;

    .line 53
    .line 54
    iput-object v12, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->L$5:Ljava/lang/Object;

    .line 55
    .line 56
    iput v6, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->I$0:I

    .line 57
    .line 58
    iput v13, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->I$1:I

    .line 59
    .line 60
    iput v13, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->I$2:I

    .line 61
    .line 62
    iput v6, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->I$3:I

    .line 63
    .line 64
    iput v13, v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;->label:I

    .line 65
    .line 66
    move v11, v6

    .line 67
    move-object v14, v12

    .line 68
    move-object v15, v12

    .line 69
    move/from16 v16, v13

    .line 70
    .line 71
    move/from16 p0, v6

    .line 72
    .line 73
    move-object/from16 p1, v2

    .line 74
    .line 75
    invoke-virtual/range {v3 .. v19}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    if-ne v0, v1, :cond_0

    .line 80
    .line 81
    return-object v1

    .line 82
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    throw v0
.end method
