.class public final Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;


# instance fields
.field public final account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

.field public final url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->url:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getAccount()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
