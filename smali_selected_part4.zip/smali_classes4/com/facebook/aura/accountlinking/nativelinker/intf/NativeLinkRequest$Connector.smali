.class public final Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;


# instance fields
.field public final authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

.field public final origin:Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

.field public final target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->origin:Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getAuthTrace()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrigin()Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->origin:Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTarget()Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 1
    .line 2
    return-object p0
.end method
