.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;
.super Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final ACCOUNTS_CENTER_ADD_PATH:Ljava/lang/String; = "/add"

.field public static final ACCOUNTS_CENTER_HOME_PATH:Ljava/lang/String; = "/home"

.field public static final ACCOUNTS_CENTER_LABEL:Ljava/lang/String; = "accountscenter"

.field public static final ACCOUNTS_CENTER_ROOT_DOMAINS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final ACCOUNT_LINK_AUTH_HOSTS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final AUTH_FLOW_TYPE_NATIVE:Ljava/lang/String; = "native"

.field public static final BACKGROUND_PAGE:Ljava/lang/String; = "background_page"

.field public static final BLOB:Ljava/lang/String; = "blob"

.field public static final CONSENT_RENDERED_JS:Ljava/lang/String; = "document.body !== null && document.body.innerText.trim().length > 0 && document.querySelector(\'[role=\"button\"]\') !== null"

.field public static final Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

.field public static final EXTRA_AGE_ACCOUNT:Ljava/lang/String; = "native_link_age_account"

.field public static final EXTRA_AGE_URL:Ljava/lang/String; = "native_link_age_url"

.field public static final EXTRA_AUTH_TRACE:Ljava/lang/String; = "native_link_auth_trace"

.field public static final EXTRA_ONE_TAP_STORED:Ljava/lang/String; = "native_link_one_tap_stored"

.field public static final EXTRA_ORIGIN:Ljava/lang/String; = "native_link_origin"

.field public static final EXTRA_TARGET:Ljava/lang/String; = "native_link_target"

.field public static final KEY_ONE_TAP_STORE_ATTEMPTED:Ljava/lang/String; = "native_link_one_tap_store_attempted"

.field public static final LINK_DONE_PATH:Ljava/lang/String; = "/account_link_done"

.field public static final LOGIN_PAGE_INTERACTIVE_JS:Ljava/lang/String; = "document.readyState !== \'loading\'"

.field public static final PAGE_CHECK_REPLY_MS:J = 0x1f4L

.field public static final PAINT_POLL_MS:J = 0x32L

.field public static final PAINT_WAIT_MS:J = 0xbb8L

.field public static final RESULT_DIALOG_UNAVAILABLE:I = 0x1

.field public static final THREADS_DOMAINS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final TOKEN:Ljava/lang/String; = "token"

.field public static final WEB_AUTH_RETURN_PARAMS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public authTraceId:Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

.field public awaitingConsentPaint:Z

.field public clearHistoryAfterLoad:Z

.field public closedByPage:Z

.field public consentPaint:LX/Cbu;

.field public gatedOff:Z

.field public final keepOverlayWhilePainting:Landroid/view/ViewTreeObserver$OnPreDrawListener;

.field public linkResultCode:I

.field public linkingFailed:Z

.field public loginPageCover:LX/Cbu;

.field public loginPageUrl:Ljava/lang/String;

.field public final metaToken:Ljava/lang/String;

.field public final museMetaToken:Ljava/lang/String;

.field public oneTapCandidates:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/api/AuraLinkingCandidate;",
            ">;"
        }
    .end annotation
.end field

.field public oneTapDialogUrl:Ljava/lang/String;

.field public oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

.field public oneTapStoreAttempted:Z

.field public final request$delegate:Lkotlin/Lazy;

.field public sawAccountsCenterWebAuthReturn:Z

.field public volatile sessionCookie:Ljava/lang/String;

.field public final shouldInterceptURL:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

.field public switchingAccount:Z

.field public webViewProviderMissing:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 6
    .line 7
    const-string v3, "threads.com"

    .line 8
    .line 9
    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->THREADS_DOMAINS:Ljava/util/List;

    .line 14
    .line 15
    const-string v2, "agent.meta.ai"

    .line 16
    .line 17
    const-string v1, "muse.ai"

    .line 18
    .line 19
    const-string v0, "www.muse.ai"

    .line 20
    .line 21
    invoke-static {v2, v1, v0}, LX/B82;->A0E(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Set;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNT_LINK_AUTH_HOSTS:Ljava/util/Set;

    .line 26
    .line 27
    const-string v2, "facebook.com"

    .line 28
    .line 29
    const-string v1, "instagram.com"

    .line 30
    .line 31
    const-string v0, "meta.com"

    .line 32
    .line 33
    filled-new-array {v2, v1, v0, v3}, [Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {v0}, LX/B82;->A0F([Ljava/lang/Object;)Ljava/util/Set;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNTS_CENTER_ROOT_DOMAINS:Ljava/util/Set;

    .line 42
    .line 43
    const-string v2, "next"

    .line 44
    .line 45
    const-string v1, "destination_url"

    .line 46
    .line 47
    const-string v0, "extra_data"

    .line 48
    .line 49
    filled-new-array {v2, v1, v0}, [Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->WEB_AUTH_RETURN_PARAMS:Ljava/util/List;

    .line 58
    .line 59
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 6
    .line 7
    .line 8
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->request$delegate:Lkotlin/Lazy;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->metaToken:Ljava/lang/String;

    .line 15
    .line 16
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->museMetaToken:Ljava/lang/String;

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    const-string v0, ""

    .line 21
    .line 22
    :cond_0
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->metaToken:Ljava/lang/String;

    .line 23
    .line 24
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$keepOverlayWhilePainting$1;

    .line 25
    .line 26
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$keepOverlayWhilePainting$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 27
    .line 28
    .line 29
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->keepOverlayWhilePainting:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    .line 30
    .line 31
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 32
    .line 33
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapCandidates:Ljava/util/List;

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 36
    .line 37
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 38
    .line 39
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;

    .line 40
    .line 41
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 42
    .line 43
    .line 44
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->shouldInterceptURL:LX/JDM;

    .line 45
    .line 46
    return-void
.end method

.method public static final synthetic access$awaitConsentPaint(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitConsentPaint(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$awaitPagePainted(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitPagePainted(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$chooseAccount(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;Ljava/util/List;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->chooseAccount(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$failClosed(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->failClosed()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getACCOUNTS_CENTER_ROOT_DOMAINS$cp()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNTS_CENTER_ROOT_DOMAINS:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getACCOUNT_LINK_AUTH_HOSTS$cp()Ljava/util/Set;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->ACCOUNT_LINK_AUTH_HOSTS:Ljava/util/Set;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getOneTapSelected$p(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)Lcom/facebook/aura/auth/api/AuraLinkingCandidate;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRequest(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getSessionCookie$p(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sessionCookie:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getWEB_AUTH_RETURN_PARAMS$cp()Ljava/util/List;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->WEB_AUTH_RETURN_PARAMS:Ljava/util/List;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$holdOverlayUntilConsentPainted(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->holdOverlayUntilConsentPainted()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$interceptWebAuth(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->interceptWebAuth(Ljava/lang/String;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$loadInitialPage(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/AYT;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loadInitialPage(Ljava/lang/String;LX/AYT;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$oneTapDialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$openTypedLogin(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->openTypedLogin(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$pageMatches(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->pageMatches(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$readInstalledAccounts(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->readInstalledAccounts(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$setClosedByPage$p(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->closedByPage:Z

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setLinkingDialogCookie(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->setLinkingDialogCookie(Ljava/lang/String;Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$setSessionCookie$p(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sessionCookie:Ljava/lang/String;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setSwitchingAccount$p(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchingAccount:Z

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$showLoadingOverlay(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->showLoadingOverlay()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$storeOneTap(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->storeOneTap(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$switchOneTapAccount(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchOneTapAccount(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$uncoverLoginPage(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->uncoverLoginPage(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final awaitConsentPaint(LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v4, p1

    .line 5
    check-cast v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    if-ne v1, v0, :cond_3

    .line 28
    .line 29
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->releaseConsentHold()V

    .line 33
    .line 34
    .line 35
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->hideLoadingOverlay()V

    .line 36
    .line 37
    .line 38
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 39
    .line 40
    return-object v0

    .line 41
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    iput v0, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;->label:I

    .line 45
    .line 46
    const-string v0, "document.body !== null && document.body.innerText.trim().length > 0 && document.querySelector(\'[role=\"button\"]\') !== null"

    .line 47
    .line 48
    invoke-direct {p0, v0, v4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitPagePainted(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    if-ne v0, v2, :cond_0

    .line 53
    .line 54
    return-object v2

    .line 55
    :cond_2
    new-instance v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;

    .line 56
    .line 57
    invoke-direct {v4, p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitConsentPaint$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    throw v0
.end method

.method private final awaitPagePainted(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    if-ne v0, v1, :cond_3

    .line 28
    .line 29
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    .line 34
    return-object v3

    .line 35
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    new-instance v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;

    .line 40
    .line 41
    invoke-direct {v2, p0, p1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/2M4;)V

    .line 42
    .line 43
    .line 44
    iput-object v0, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    iput v1, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;->label:I

    .line 47
    .line 48
    const-wide/16 v0, 0xbb8

    .line 49
    .line 50
    invoke-static {v4, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    if-ne v0, v3, :cond_0

    .line 55
    .line 56
    return-object v3

    .line 57
    :cond_2
    new-instance v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;

    .line 58
    .line 59
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$awaitPagePainted$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0
.end method

.method private final chooseAccount(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;Ljava/util/List;LX/2M4;)Ljava/lang/Object;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/auth/api/AuraLinkingCandidate;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v3, p3

    .line 5
    check-cast v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->label:I

    .line 23
    .line 24
    const/4 v6, 0x1

    .line 25
    const/4 v8, 0x0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v6, :cond_1

    .line 29
    .line 30
    iget-object v9, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$4:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v9, LX/0F1;

    .line 33
    .line 34
    iget-object v8, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$3:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v8, Landroid/view/ViewGroup;

    .line 37
    .line 38
    goto/16 :goto_4

    .line 39
    .line 40
    :cond_0
    new-instance v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;

    .line 41
    .line 42
    invoke-direct {v3, p0, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    throw v1

    .line 51
    :cond_2
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    const/4 v0, 0x2

    .line 59
    if-eq v4, v8, :cond_6

    .line 60
    .line 61
    if-eq v4, v6, :cond_5

    .line 62
    .line 63
    if-ne v4, v0, :cond_9

    .line 64
    .line 65
    const v0, 0x7f120533

    .line 66
    .line 67
    .line 68
    new-instance v2, Ljava/lang/Integer;

    .line 69
    .line 70
    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 71
    .line 72
    .line 73
    const v1, 0x7f0800b5

    .line 74
    .line 75
    .line 76
    :goto_1
    new-instance v0, Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-direct {v0, v1}, Ljava/lang/Integer;-><init>(I)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 82
    .line 83
    .line 84
    move-result v11

    .line 85
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 86
    .line 87
    .line 88
    move-result v10

    .line 89
    invoke-static {p2}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 90
    .line 91
    .line 92
    move-result-object v7

    .line 93
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    :goto_2
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_7

    .line 102
    .line 103
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    check-cast v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 108
    .line 109
    if-eq v4, v8, :cond_4

    .line 110
    .line 111
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->username:Ljava/lang/String;

    .line 112
    .line 113
    if-nez v2, :cond_3

    .line 114
    .line 115
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->displayName:Ljava/lang/String;

    .line 116
    .line 117
    :cond_3
    :goto_3
    iget-object v1, v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->profilePictureUrl:Ljava/lang/String;

    .line 118
    .line 119
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;

    .line 120
    .line 121
    invoke-direct {v0, v2, v11, v1, v10}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_4
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->displayName:Ljava/lang/String;

    .line 129
    .line 130
    if-nez v2, :cond_3

    .line 131
    .line 132
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->username:Ljava/lang/String;

    .line 133
    .line 134
    goto :goto_3

    .line 135
    :cond_5
    const v0, 0x7f120532

    .line 136
    .line 137
    .line 138
    new-instance v2, Ljava/lang/Integer;

    .line 139
    .line 140
    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 141
    .line 142
    .line 143
    const v1, 0x7f08021d

    .line 144
    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_6
    const v0, 0x7f120531

    .line 148
    .line 149
    .line 150
    new-instance v2, Ljava/lang/Integer;

    .line 151
    .line 152
    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 153
    .line 154
    .line 155
    const v1, 0x7f080130

    .line 156
    .line 157
    .line 158
    goto :goto_1

    .line 159
    :cond_7
    const v0, 0x1020002

    .line 160
    .line 161
    .line 162
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 163
    .line 164
    .line 165
    move-result-object v8

    .line 166
    check-cast v8, Landroid/view/ViewGroup;

    .line 167
    .line 168
    new-instance v9, LX/0F1;

    .line 169
    .line 170
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 171
    .line 172
    .line 173
    const/4 v4, 0x0

    .line 174
    :try_start_0
    iput-object v4, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$0:Ljava/lang/Object;

    .line 175
    .line 176
    iput-object v4, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$1:Ljava/lang/Object;

    .line 177
    .line 178
    iput-object v7, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$2:Ljava/lang/Object;

    .line 179
    .line 180
    iput-object v8, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$3:Ljava/lang/Object;

    .line 181
    .line 182
    iput-object v9, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->L$4:Ljava/lang/Object;

    .line 183
    .line 184
    iput v11, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->I$0:I

    .line 185
    .line 186
    iput v10, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->I$1:I

    .line 187
    .line 188
    iput v6, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$1;->label:I

    .line 189
    .line 190
    invoke-static {v3}, LX/008;->A1I(LX/2M4;)LX/DSD;

    .line 191
    .line 192
    .line 193
    move-result-object v3

    .line 194
    sget-object v2, LX/1AY;->A00:LX/1AY;

    .line 195
    .line 196
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;

    .line 197
    .line 198
    invoke-direct {v1, v7, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;-><init>(Ljava/util/List;LX/DT0;)V

    .line 199
    .line 200
    .line 201
    const v0, 0x3bd49d17

    .line 202
    .line 203
    .line 204
    invoke-static {v1, v0, v6}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 205
    .line 206
    .line 207
    move-result-object v1

    .line 208
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;->DEFAULT:Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 209
    .line 210
    invoke-static {p0, v0, v2, v4, v1}, Lcom/facebook/aura/vds/compose/ext/ViewExtKt;->auraComposeView(Landroid/content/Context;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/0i3;Ljava/lang/String;LX/JDN;)Landroidx/compose/ui/platform/ComposeView;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    iput-object v0, v9, LX/0F1;->element:Ljava/lang/Object;

    .line 215
    .line 216
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {v3}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    if-ne v1, v5, :cond_8

    .line 224
    .line 225
    return-object v5

    .line 226
    :goto_4
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :cond_8
    check-cast v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 230
    .line 231
    iget-object v0, v9, LX/0F1;->element:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v0, Landroid/view/View;

    .line 234
    .line 235
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 236
    .line 237
    .line 238
    return-object v1

    .line 239
    :catchall_0
    move-exception v1

    .line 240
    iget-object v0, v9, LX/0F1;->element:Ljava/lang/Object;

    .line 241
    .line 242
    check-cast v0, Landroid/view/View;

    .line 243
    .line 244
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 245
    .line 246
    .line 247
    throw v1

    .line 248
    :cond_9
    new-instance v1, Lkotlin/NoWhenBranchMatchedException;

    .line 249
    .line 250
    invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V

    .line 251
    .line 252
    .line 253
    throw v1
.end method

.method private final endAuthFailed()V
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    instance-of v0, v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    check-cast v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkingFailed:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-object v0, v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->origin:Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->logLinkingFailed(Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    const/4 v0, 0x1

    .line 24
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkingFailed:Z

    .line 25
    .line 26
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->authTraceId:Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 27
    .line 28
    if-eqz p0, :cond_1

    .line 29
    .line 30
    sget-object v2, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    const-string v0, "linking_failure"

    .line 34
    .line 35
    invoke-virtual {v2, p0, v0, v1, v1}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->endAuthFail(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    return-void
.end method

.method private final failClosed()V
    .locals 2

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v0, v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    iput v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkResultCode:I

    .line 16
    .line 17
    :goto_0
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finish()V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void

    .line 21
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->endAuthFailed()V

    .line 22
    .line 23
    .line 24
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 25
    .line 26
    const v0, 0x7f1201e5

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 30
    .line 31
    .line 32
    goto :goto_0
.end method

.method private final finishLinking(Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    const/4 v0, -0x1

    .line 4
    :cond_0
    iput v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkResultCode:I

    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finish()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private final getOwnsAuthTrace()Z
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    instance-of v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 10
    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 14
    .line 15
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->OWNED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 16
    .line 17
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    return v0
.end method

.method private final getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->request$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 7
    .line 8
    return-object p0
.end method

.method private final hideLoadingOverlay()V
    .locals 2

    .line 0
    const v0, 0x7f0a01cc

    .line 1
    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 12
    .line 13
    .line 14
    :cond_0
    const v0, 0x7f0a0216

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 24
    .line 25
    .line 26
    :cond_1
    return-void
.end method

.method private final holdOverlayUntilConsentPainted()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->consentPaint:LX/Cbu;

    .line 1
    .line 2
    const/4 v2, 0x1

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 7
    .line 8
    .line 9
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loginPageCover:LX/Cbu;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 14
    .line 15
    .line 16
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->releaseConsentHold()V

    .line 17
    .line 18
    .line 19
    iput-boolean v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitingConsentPaint:Z

    .line 20
    .line 21
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->keepOverlayWhilePainting:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    .line 30
    .line 31
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 32
    .line 33
    .line 34
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->showLoadingOverlay()V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method private final interceptWebAuth(Ljava/lang/String;)Z
    .locals 8

    .line 0
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 1
    .line 2
    .line 3
    move-result-object v6

    .line 4
    invoke-virtual {v6}, Landroid/net/Uri;->isOpaque()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v7, 0x0

    .line 9
    if-nez v0, :cond_6

    .line 10
    .line 11
    sget-object v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 12
    .line 13
    invoke-static {v5, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$linkDoneResult(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Ljava/lang/Boolean;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v3, 0x1

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-direct {p0, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finishLinking(Z)V

    .line 25
    .line 26
    .line 27
    :cond_0
    return v3

    .line 28
    :cond_1
    invoke-static {v5, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$isAccountsCenterWebAuthReturn(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    iput-boolean v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sawAccountsCenterWebAuthReturn:Z

    .line 35
    .line 36
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 37
    .line 38
    sget-object v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->CONSENT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 39
    .line 40
    if-ne v0, v4, :cond_5

    .line 41
    .line 42
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sawAccountsCenterWebAuthReturn:Z

    .line 43
    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    invoke-static {v5, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$isAccountsCenterHome(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    invoke-direct {p0, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finishLinking(Z)V

    .line 53
    .line 54
    .line 55
    return v3

    .line 56
    :cond_3
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchingAccount:Z

    .line 57
    .line 58
    if-nez v0, :cond_4

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 61
    .line 62
    if-nez v0, :cond_4

    .line 63
    .line 64
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    instance-of v0, v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 69
    .line 70
    if-eqz v0, :cond_5

    .line 71
    .line 72
    :cond_4
    invoke-static {v5, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$isNotYouRedirect(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_5

    .line 77
    .line 78
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchingAccount:Z

    .line 79
    .line 80
    if-nez v0, :cond_0

    .line 81
    .line 82
    iput-boolean v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->switchingAccount:Z

    .line 83
    .line 84
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    const/4 v1, 0x0

    .line 93
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;

    .line 94
    .line 95
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$interceptWebAuth$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 96
    .line 97
    .line 98
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 99
    .line 100
    .line 101
    return v3

    .line 102
    :cond_5
    const-string v0, "token"

    .line 103
    .line 104
    invoke-virtual {v6, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    const-string v0, "blob"

    .line 109
    .line 110
    invoke-virtual {v6, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    invoke-static {v5, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$isAccountLinkAuthCallback(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/net/Uri;)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    if-eqz v0, :cond_6

    .line 119
    .line 120
    if-eqz v2, :cond_6

    .line 121
    .line 122
    if-eqz v1, :cond_6

    .line 123
    .line 124
    iput-object v4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 125
    .line 126
    invoke-direct {p0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->openLinkingDialog(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    return v3

    .line 130
    :cond_6
    return v7
.end method

.method private final loadInitialPage(Ljava/lang/String;LX/AYT;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/AYT;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v5, p3

    .line 5
    check-cast v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v4, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x2

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    if-eq v2, v0, :cond_2

    .line 29
    .line 30
    if-ne v2, v1, :cond_6

    .line 31
    .line 32
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    :goto_1
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 36
    .line 37
    return-object v3

    .line 38
    :cond_1
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iput-object p1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$0:Ljava/lang/Object;

    .line 42
    .line 43
    iput-object p2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$1:Ljava/lang/Object;

    .line 44
    .line 45
    iput v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->label:I

    .line 46
    .line 47
    invoke-direct {p0, v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl(LX/2M4;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    if-ne v4, v3, :cond_3

    .line 52
    .line 53
    return-object v3

    .line 54
    :cond_2
    iget-object p2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$1:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast p2, LX/AYT;

    .line 57
    .line 58
    iget-object p1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p1, Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v4}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_3
    check-cast v4, Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-nez v0, :cond_0

    .line 72
    .line 73
    if-eqz v4, :cond_4

    .line 74
    .line 75
    iput-object v4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl:Ljava/lang/String;

    .line 76
    .line 77
    invoke-direct {p0, v4, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->setLinkingDialogCookie(Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->holdOverlayUntilConsentPainted()V

    .line 81
    .line 82
    .line 83
    invoke-interface {p2, p1}, LX/AYT;->onSuccess(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_4
    const/4 v0, 0x0

    .line 88
    iput-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$0:Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$1:Ljava/lang/Object;

    .line 91
    .line 92
    iput-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->L$2:Ljava/lang/Object;

    .line 93
    .line 94
    iput v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;->label:I

    .line 95
    .line 96
    invoke-direct {p0, v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->openTypedLogin(LX/2M4;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-ne v0, v3, :cond_0

    .line 101
    .line 102
    return-object v3

    .line 103
    :cond_5
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;

    .line 104
    .line 105
    invoke-direct {v5, p0, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$loadInitialPage$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 106
    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    throw v0
.end method

.method private final logLinkerCancel()V
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getOwnsAuthTrace()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkResultCode:I

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->closedByPage:Z

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkingFailed:Z

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->authTraceId:Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 19
    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    sget-object v1, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->getCancelPoint()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->endAuthCancel(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method

.method private final logLinkingFailed(Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;)V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchComponent;->SKILL_AUTH_FAILED:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->AUTH_FLOW_TYPE:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "native"

    .line 11
    .line 12
    new-instance v2, LX/IBK;

    .line 13
    .line 14
    invoke-direct {v2, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->FAILURE_REASON:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v0, "linking_failure"

    .line 24
    .line 25
    invoke-static {v1, v0, v2}, LX/1H9;->A04(Ljava/lang/Object;Ljava/lang/Object;LX/IBK;)Ljava/util/Map;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p0, p1, v3, v0}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logSkillOAuthResult(Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method private final logWebViewUnavailable()V
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    if-eqz v2, :cond_0

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 7
    .line 8
    const-string v0, "no_webview"

    .line 9
    .line 10
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->annotateNativeIneligible(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->endAuthFailed()V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method private final oneTapDialogUrl(LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 1
    .line 2
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$getOneTapFlow(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p0, v1, v0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->storeOneTap(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method private final oneTapFallback(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;)Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 1
    .line 2
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz p0, :cond_0

    .line 10
    .line 11
    sget-object v1, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->getWireValue()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v1, p0, v0, v2}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->annotateOneTap(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;Ljava/lang/Long;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-object v2
.end method

.method private final oneTapTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;
    .locals 4

    .line 0
    sget-object v0, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->activeAuthTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    instance-of v0, v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    check-cast v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    iget-object v1, v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->authTrace:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->NONE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 24
    .line 25
    if-eq v1, v0, :cond_0

    .line 26
    .line 27
    return-object v3

    .line 28
    :cond_0
    return-object v2
.end method

.method private final openLinkingDialog(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 0
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openLinkingDialog$1;

    .line 10
    .line 11
    invoke-direct {v0, p0, p1, p2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openLinkingDialog$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;Ljava/lang/String;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final openTypedLogin(LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;

    .line 1
    .line 2
    if-eqz v0, :cond_6

    .line 3
    .line 4
    move-object v6, p1

    .line 5
    check-cast v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_6

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_3

    .line 26
    .line 27
    if-ne v0, v4, :cond_7

    .line 28
    .line 29
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v1, Ljava/lang/String;

    .line 33
    .line 34
    :goto_1
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    if-nez v1, :cond_2

    .line 41
    .line 42
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->failClosed()V

    .line 43
    .line 44
    .line 45
    :cond_1
    :goto_2
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 46
    .line 47
    return-object v5

    .line 48
    :cond_2
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loginPageUrl:Ljava/lang/String;

    .line 49
    .line 50
    iput-boolean v4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->clearHistoryAfterLoad:Z

    .line 51
    .line 52
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    goto :goto_2

    .line 60
    :cond_3
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 64
    .line 65
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 66
    .line 67
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->consentPaint:LX/Cbu;

    .line 68
    .line 69
    invoke-static {v0}, LX/603;->A0z(LX/Cbu;)LX/2M4;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->releaseConsentHold()V

    .line 74
    .line 75
    .line 76
    const v0, 0x7f0a01cc

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    if-eqz v1, :cond_4

    .line 84
    .line 85
    const/4 v0, 0x0

    .line 86
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 87
    .line 88
    .line 89
    :cond_4
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    instance-of v0, v2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 94
    .line 95
    if-eqz v0, :cond_5

    .line 96
    .line 97
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;

    .line 102
    .line 103
    invoke-direct {v0, v2, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$loginUrl$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/2M4;)V

    .line 104
    .line 105
    .line 106
    iput-object v3, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->L$0:Ljava/lang/Object;

    .line 107
    .line 108
    iput v4, v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;->label:I

    .line 109
    .line 110
    invoke-static {v6, v1, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    if-ne v1, v5, :cond_0

    .line 115
    .line 116
    return-object v5

    .line 117
    :cond_5
    instance-of v0, v2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 118
    .line 119
    if-eqz v0, :cond_8

    .line 120
    .line 121
    check-cast v2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 122
    .line 123
    iget-object v1, v2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->url:Ljava/lang/String;

    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_6
    new-instance v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;

    .line 127
    .line 128
    invoke-direct {v6, p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$openTypedLogin$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    throw v0

    .line 137
    :cond_8
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 138
    .line 139
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 140
    .line 141
    .line 142
    throw v0
.end method

.method private final pageMatches(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p2}, LX/8ml;->A0P(LX/2M4;)LX/DSD;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$pageMatches$2$1;

    .line 9
    .line 10
    invoke-direct {v0, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$pageMatches$2$1;-><init>(LX/DT0;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, p1, v0}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v2}, LX/DSD;->A0F()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method

.method private final readInstalledAccounts(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/auth/api/InstalledAccountsRead;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->label:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    const/4 v2, 0x0

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-ne v1, v3, :cond_3

    .line 29
    .line 30
    iget-object v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->L$1:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, LX/Cbu;

    .line 33
    .line 34
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-interface {v1, v2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 38
    .line 39
    .line 40
    return-object v0

    .line 41
    :cond_1
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$2;

    .line 53
    .line 54
    invoke-direct {v0, p0, p1, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)V

    .line 55
    .line 56
    .line 57
    invoke-static {v0, v1}, LX/3Rp;->A14(LX/JDN;LX/1EL;)LX/ERe;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$3$1;

    .line 62
    .line 63
    invoke-direct {v0, v1, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$3$1;-><init>(LX/EQR;LX/2M4;)V

    .line 64
    .line 65
    .line 66
    iput-object v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->L$0:Ljava/lang/Object;

    .line 67
    .line 68
    iput-object v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->L$1:Ljava/lang/Object;

    .line 69
    .line 70
    iput v3, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;->label:I

    .line 71
    .line 72
    invoke-static {v0, v5}, LX/8mk;->A0c(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    if-ne v0, v4, :cond_0

    .line 77
    .line 78
    return-object v4

    .line 79
    :cond_2
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;

    .line 80
    .line 81
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$readInstalledAccounts$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 82
    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    throw v0
.end method

.method private final releaseConsentHold()V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->consentPaint:LX/Cbu;

    .line 2
    .line 3
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitingConsentPaint:Z

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitingConsentPaint:Z

    .line 9
    .line 10
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->keepOverlayWhilePainting:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    .line 19
    .line 20
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method private final setLinkingDialogCookie(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    const/4 v0, 0x4

    .line 17
    new-instance v2, Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 20
    .line 21
    .line 22
    const-string v0, "https"

    .line 23
    .line 24
    filled-new-array {v0}, [Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    new-instance v0, LX/AXt;

    .line 39
    .line 40
    invoke-direct {v0, v1}, LX/AXt;-><init>(Ljava/util/Collection;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    const-string v0, "meta.com"

    .line 47
    .line 48
    filled-new-array {v0}, [Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v0, LX/AXw;

    .line 53
    .line 54
    invoke-direct {v0, v1}, LX/AXw;-><init>([Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    invoke-static {v2}, LX/AXr;->A00(Ljava/util/List;)LX/ABh;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-virtual {p0, p1, v1, v0}, LX/AR7;->setCookieStringsSecure(Ljava/lang/String;LX/ABh;Ljava/util/Collection;)V

    .line 69
    .line 70
    .line 71
    :cond_0
    return-void

    .line 72
    :cond_1
    const-string v1, "Cannot set 0 schemes"

    .line 73
    .line 74
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 75
    .line 76
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    throw v0
.end method

.method private final showLoadingOverlay()V
    .locals 2

    .line 0
    const v0, 0x7f0a01cc

    .line 1
    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 11
    .line 12
    .line 13
    :cond_0
    const v0, 0x7f0a0216

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 23
    .line 24
    .line 25
    :cond_1
    return-void
.end method

.method private final storeOneTap(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;

    .line 1
    .line 2
    if-eqz v0, :cond_e

    .line 3
    .line 4
    move-object v8, p3

    .line 5
    check-cast v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;

    .line 6
    .line 7
    iget v2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_e

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v11, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v9, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 23
    .line 24
    const/4 v7, 0x3

    .line 25
    const/4 v1, 0x2

    .line 26
    const/4 v6, 0x0

    .line 27
    const/4 v3, 0x1

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    if-eq v0, v3, :cond_3

    .line 31
    .line 32
    if-eq v0, v1, :cond_8

    .line 33
    .line 34
    if-ne v0, v7, :cond_f

    .line 35
    .line 36
    iget-object v10, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$4:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v10, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 39
    .line 40
    invoke-static {v11}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    if-eqz v11, :cond_11

    .line 44
    .line 45
    iput-object v10, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->CONSENT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 48
    .line 49
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 50
    .line 51
    return-object v11

    .line 52
    :cond_1
    invoke-static {v11}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->ONE_TAP:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 56
    .line 57
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 58
    .line 59
    const v0, 0x7f0a01cc

    .line 60
    .line 61
    .line 62
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    if-eqz v2, :cond_2

    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 70
    .line 71
    .line 72
    :cond_2
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;->app:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 73
    .line 74
    iput-object p1, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$0:Ljava/lang/Object;

    .line 75
    .line 76
    iput-object p2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$1:Ljava/lang/Object;

    .line 77
    .line 78
    iput v3, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 79
    .line 80
    invoke-direct {p0, v0, v8}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->readInstalledAccounts(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;LX/2M4;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v11

    .line 84
    if-ne v11, v9, :cond_4

    .line 85
    .line 86
    return-object v9

    .line 87
    :cond_3
    iget-object p2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$1:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast p2, Ljava/lang/String;

    .line 90
    .line 91
    iget-object p1, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$0:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 94
    .line 95
    invoke-static {v11}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_4
    check-cast v11, Lcom/facebook/aura/auth/api/InstalledAccountsRead;

    .line 99
    .line 100
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_5

    .line 105
    .line 106
    return-object v6

    .line 107
    :cond_5
    if-nez v11, :cond_6

    .line 108
    .line 109
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ACCOUNT_TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 110
    .line 111
    goto/16 :goto_1

    .line 112
    .line 113
    :cond_6
    invoke-interface {v11, p2}, Lcom/facebook/aura/auth/api/InstalledAccountsRead;->has(Ljava/lang/String;)Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-nez v0, :cond_7

    .line 118
    .line 119
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->NO_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 120
    .line 121
    goto/16 :goto_1

    .line 122
    .line 123
    :cond_7
    iput-boolean v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapStoreAttempted:Z

    .line 124
    .line 125
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 126
    .line 127
    .line 128
    move-result-wide v3

    .line 129
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;->flow:Ljava/lang/String;

    .line 130
    .line 131
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$0:Ljava/lang/Object;

    .line 132
    .line 133
    iput-object p2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$1:Ljava/lang/Object;

    .line 134
    .line 135
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$2:Ljava/lang/Object;

    .line 136
    .line 137
    iput-wide v3, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->J$0:J

    .line 138
    .line 139
    iput v1, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 140
    .line 141
    invoke-interface {v11, v0, p2, v8}, Lcom/facebook/aura/auth/api/InstalledAccountsRead;->store(Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v11

    .line 145
    if-ne v11, v9, :cond_9

    .line 146
    .line 147
    return-object v9

    .line 148
    :cond_8
    iget-wide v3, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->J$0:J

    .line 149
    .line 150
    iget-object p2, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$1:Ljava/lang/Object;

    .line 151
    .line 152
    invoke-static {v11}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    :cond_9
    check-cast v11, Lcom/facebook/aura/auth/api/AuraLinkingStore;

    .line 156
    .line 157
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 158
    .line 159
    .line 160
    move-result-wide v1

    .line 161
    sub-long/2addr v1, v3

    .line 162
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 163
    .line 164
    .line 165
    move-result-object v10

    .line 166
    if-eqz v10, :cond_a

    .line 167
    .line 168
    sget-object v5, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 169
    .line 170
    new-instance v0, Ljava/lang/Long;

    .line 171
    .line 172
    invoke-direct {v0, v1, v2}, Ljava/lang/Long;-><init>(J)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v5, v10, v6, v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->annotateOneTap(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;Ljava/lang/Long;)V

    .line 176
    .line 177
    .line 178
    :cond_a
    if-nez v11, :cond_b

    .line 179
    .line 180
    const-wide/16 v3, 0x3a98

    .line 181
    .line 182
    cmp-long v0, v1, v3

    .line 183
    .line 184
    if-ltz v0, :cond_10

    .line 185
    .line 186
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 187
    .line 188
    goto :goto_1

    .line 189
    :cond_b
    iget-object v10, v11, Lcom/facebook/aura/auth/api/AuraLinkingStore;->selected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 190
    .line 191
    if-nez v10, :cond_c

    .line 192
    .line 193
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->NONE_ELIGIBLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 194
    .line 195
    goto :goto_1

    .line 196
    :cond_c
    if-nez p2, :cond_d

    .line 197
    .line 198
    iget-object v0, v11, Lcom/facebook/aura/auth/api/AuraLinkingStore;->candidates:Ljava/util/List;

    .line 199
    .line 200
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapCandidates:Ljava/util/List;

    .line 201
    .line 202
    :cond_d
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 203
    .line 204
    .line 205
    move-result-object v5

    .line 206
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$3;

    .line 207
    .line 208
    invoke-direct {v0, p0, v6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$3;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 209
    .line 210
    .line 211
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$0:Ljava/lang/Object;

    .line 212
    .line 213
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$1:Ljava/lang/Object;

    .line 214
    .line 215
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$2:Ljava/lang/Object;

    .line 216
    .line 217
    iput-object v6, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$3:Ljava/lang/Object;

    .line 218
    .line 219
    iput-object v10, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->L$4:Ljava/lang/Object;

    .line 220
    .line 221
    iput-wide v3, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->J$0:J

    .line 222
    .line 223
    iput-wide v1, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->J$1:J

    .line 224
    .line 225
    iput v7, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;->label:I

    .line 226
    .line 227
    invoke-static {v8, v5, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v11

    .line 231
    if-ne v11, v9, :cond_0

    .line 232
    .line 233
    return-object v9

    .line 234
    :cond_e
    new-instance v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;

    .line 235
    .line 236
    invoke-direct {v8, p0, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$storeOneTap$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 237
    .line 238
    .line 239
    goto/16 :goto_0

    .line 240
    .line 241
    :cond_f
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    throw v0

    .line 246
    :cond_10
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ERROR:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 247
    .line 248
    goto :goto_1

    .line 249
    :cond_11
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->DIALOG_UNAVAILABLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 250
    .line 251
    :goto_1
    invoke-direct {p0, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapFallback(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;)Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v11

    .line 255
    return-object v11
.end method

.method private final switchOneTapAccount(LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;

    .line 1
    .line 2
    if-eqz v0, :cond_c

    .line 3
    .line 4
    move-object v3, p1

    .line 5
    check-cast v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_c

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v8, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x3

    .line 25
    const/4 v6, 0x2

    .line 26
    const/4 v10, 0x1

    .line 27
    const/4 v1, 0x0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    if-eq v0, v10, :cond_4

    .line 31
    .line 32
    if-eq v0, v6, :cond_8

    .line 33
    .line 34
    if-ne v0, v4, :cond_d

    .line 35
    .line 36
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    :goto_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 40
    .line 41
    return-object v2

    .line 42
    :cond_1
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object v7, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 46
    .line 47
    if-eqz v7, :cond_0

    .line 48
    .line 49
    sget-object v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 50
    .line 51
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v5, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$getOneTapFlow(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 56
    .line 57
    .line 58
    move-result-object v5

    .line 59
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapSelected:Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 60
    .line 61
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 66
    .line 67
    .line 68
    move-result-object v11

    .line 69
    sget-object v9, LX/FkO;->A0K:Ljava/lang/Integer;

    .line 70
    .line 71
    new-instance v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$2;

    .line 72
    .line 73
    invoke-direct {v8, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$2;-><init>(LX/2M4;)V

    .line 74
    .line 75
    .line 76
    sget-object v0, LX/39s;->A00:LX/39s;

    .line 77
    .line 78
    invoke-static {v9, v0, v8, v11}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 79
    .line 80
    .line 81
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapCandidates:Ljava/util/List;

    .line 82
    .line 83
    new-instance v9, Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 86
    .line 87
    .line 88
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 89
    .line 90
    .line 91
    move-result-object v12

    .line 92
    :cond_2
    :goto_2
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_3

    .line 97
    .line 98
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v11

    .line 102
    move-object v8, v11

    .line 103
    check-cast v8, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 104
    .line 105
    iget-boolean v0, v8, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->eligible:Z

    .line 106
    .line 107
    if-eqz v0, :cond_2

    .line 108
    .line 109
    iget-object v8, v8, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->ref:Ljava/lang/String;

    .line 110
    .line 111
    if-eqz v8, :cond_2

    .line 112
    .line 113
    iget-object v0, v7, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->ref:Ljava/lang/String;

    .line 114
    .line 115
    invoke-static {v0, v11, v8, v9}, LX/3Rs;->A19(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/util/AbstractCollection;)V

    .line 116
    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_3
    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    if-nez v0, :cond_6

    .line 124
    .line 125
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-nez v0, :cond_0

    .line 130
    .line 131
    iget-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;->app:Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;

    .line 132
    .line 133
    iput-object v7, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$0:Ljava/lang/Object;

    .line 134
    .line 135
    iput-object v5, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$1:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v9, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$2:Ljava/lang/Object;

    .line 138
    .line 139
    iput v10, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 140
    .line 141
    invoke-direct {p0, v0, v9, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->chooseAccount(Lcom/facebook/aura/auth/api/AuraInstalledAccountApp;Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v8

    .line 145
    if-ne v8, v2, :cond_5

    .line 146
    .line 147
    return-object v2

    .line 148
    :cond_4
    iget-object v9, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$2:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v9, Ljava/util/List;

    .line 151
    .line 152
    iget-object v5, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$1:Ljava/lang/Object;

    .line 153
    .line 154
    check-cast v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;

    .line 155
    .line 156
    iget-object v7, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$0:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast v7, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 159
    .line 160
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :cond_5
    check-cast v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;

    .line 164
    .line 165
    instance-of v0, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;

    .line 166
    .line 167
    if-eqz v0, :cond_7

    .line 168
    .line 169
    check-cast v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;

    .line 170
    .line 171
    iget v0, v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;->index:I

    .line 172
    .line 173
    invoke-interface {v9, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    check-cast v1, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;

    .line 178
    .line 179
    :cond_6
    :goto_3
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    if-nez v0, :cond_0

    .line 184
    .line 185
    if-eqz v1, :cond_a

    .line 186
    .line 187
    iget-object v1, v1, Lcom/facebook/aura/auth/api/AuraLinkingCandidate;->ref:Ljava/lang/String;

    .line 188
    .line 189
    if-eqz v1, :cond_a

    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$0:Ljava/lang/Object;

    .line 193
    .line 194
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$1:Ljava/lang/Object;

    .line 195
    .line 196
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$2:Ljava/lang/Object;

    .line 197
    .line 198
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$3:Ljava/lang/Object;

    .line 199
    .line 200
    iput v6, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 201
    .line 202
    invoke-direct {p0, v5, v1, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->storeOneTap(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeOneTapFlow;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v8

    .line 206
    if-ne v8, v2, :cond_9

    .line 207
    .line 208
    return-object v2

    .line 209
    :cond_7
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$UseAnotherAccount;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$UseAnotherAccount;

    .line 210
    .line 211
    invoke-static {v8, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    if-nez v0, :cond_6

    .line 216
    .line 217
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Dismissed;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Dismissed;

    .line 218
    .line 219
    invoke-static {v8, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    if-eqz v0, :cond_e

    .line 224
    .line 225
    move-object v1, v7

    .line 226
    goto :goto_3

    .line 227
    :cond_8
    invoke-static {v8}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    :cond_9
    check-cast v8, Ljava/lang/String;

    .line 231
    .line 232
    goto :goto_4

    .line 233
    :cond_a
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ANOTHER_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 234
    .line 235
    invoke-direct {p0, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapFallback(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v8

    .line 239
    :goto_4
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    if-nez v0, :cond_0

    .line 244
    .line 245
    iput-object v8, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl:Ljava/lang/String;

    .line 246
    .line 247
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sessionCookie:Ljava/lang/String;

    .line 248
    .line 249
    if-eqz v8, :cond_b

    .line 250
    .line 251
    if-eqz v0, :cond_b

    .line 252
    .line 253
    invoke-direct {p0, v8, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->setLinkingDialogCookie(Ljava/lang/String;Ljava/lang/String;)V

    .line 254
    .line 255
    .line 256
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->holdOverlayUntilConsentPainted()V

    .line 257
    .line 258
    .line 259
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    invoke-virtual {v0, v8}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    goto/16 :goto_1

    .line 267
    .line 268
    :cond_b
    const/4 v0, 0x0

    .line 269
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$0:Ljava/lang/Object;

    .line 270
    .line 271
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$1:Ljava/lang/Object;

    .line 272
    .line 273
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$2:Ljava/lang/Object;

    .line 274
    .line 275
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$3:Ljava/lang/Object;

    .line 276
    .line 277
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$4:Ljava/lang/Object;

    .line 278
    .line 279
    iput-object v0, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->L$5:Ljava/lang/Object;

    .line 280
    .line 281
    iput v4, v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;->label:I

    .line 282
    .line 283
    invoke-direct {p0, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->openTypedLogin(LX/2M4;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    if-ne v0, v2, :cond_0

    .line 288
    .line 289
    return-object v2

    .line 290
    :cond_c
    new-instance v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;

    .line 291
    .line 292
    invoke-direct {v3, p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$switchOneTapAccount$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 293
    .line 294
    .line 295
    goto/16 :goto_0

    .line 296
    .line 297
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    throw v0

    .line 302
    :cond_e
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 303
    .line 304
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 305
    .line 306
    .line 307
    throw v0
.end method

.method private final uncoverLoginPage(LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v4, p1

    .line 5
    check-cast v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    if-ne v1, v0, :cond_4

    .line 28
    .line 29
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 35
    .line 36
    if-ne v1, v0, :cond_1

    .line 37
    .line 38
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->hideLoadingOverlay()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->refreshToolbar()V

    .line 42
    .line 43
    .line 44
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->clearHistoryAfterLoad:Z

    .line 45
    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->clearHistoryAfterLoad:Z

    .line 50
    .line 51
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v0}, Landroid/webkit/WebView;->clearHistory()V

    .line 56
    .line 57
    .line 58
    :cond_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 59
    .line 60
    return-object v2

    .line 61
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    iput v0, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;->label:I

    .line 65
    .line 66
    const-string v0, "document.readyState !== \'loading\'"

    .line 67
    .line 68
    invoke-direct {p0, v0, v4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitPagePainted(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    if-ne v0, v2, :cond_0

    .line 73
    .line 74
    return-object v2

    .line 75
    :cond_3
    new-instance v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;

    .line 76
    .line 77
    invoke-direct {v4, p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$uncoverLoginPage$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    throw v0
.end method


# virtual methods
.method public additionalWebViewSetup(LX/AR7;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->additionalWebViewSetup(LX/AR7;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/webkit/WebView;->getWebChromeClient()Landroid/webkit/WebChromeClient;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;

    .line 12
    .line 13
    invoke-direct {v0, v1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;-><init>(Landroid/webkit/WebChromeClient;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, v0}, LX/AR7;->setWebChromeClient(LX/ARA;)LX/AR7;

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public fetchMetaSessionCookie(ZLX/AYT;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->gatedOff:Z

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->museMetaToken:Ljava/lang/String;

    .line 9
    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->failClosed()V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void

    .line 16
    :cond_1
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;

    .line 17
    .line 18
    invoke-direct {v0, p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;ZLX/AYT;)V

    .line 19
    .line 20
    .line 21
    invoke-super {p0, p1, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->fetchMetaSessionCookie(ZLX/AYT;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public finish()V
    .locals 5

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->webViewProviderMissing:Z

    .line 1
    .line 2
    const/4 v4, 0x1

    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    instance-of v0, v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 10
    .line 11
    if-eqz v0, :cond_2

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    :goto_0
    new-instance v2, Landroid/content/Intent;

    .line 15
    .line 16
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 17
    .line 18
    .line 19
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapStoreAttempted:Z

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl:Ljava/lang/String;

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    iget v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkResultCode:I

    .line 28
    .line 29
    const/4 v0, -0x1

    .line 30
    if-eq v1, v0, :cond_1

    .line 31
    .line 32
    :cond_0
    :goto_1
    const-string v0, "native_link_one_tap_stored"

    .line 33
    .line 34
    invoke-virtual {v2, v0, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {p0, v3, v0}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 39
    .line 40
    .line 41
    invoke-super {p0}, Landroid/app/Activity;->finish()V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_1
    const/4 v4, 0x0

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    iget v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->linkResultCode:I

    .line 48
    .line 49
    goto :goto_0
.end method

.method public getAuthUrls()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method

.method public getExternalDomains()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    instance-of v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 10
    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 14
    .line 15
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->THREADS:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 16
    .line 17
    if-ne v1, v0, :cond_1

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->THREADS_DOMAINS:Ljava/util/List;

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 23
    .line 24
    return-object v0
.end method

.method public getMetaToken()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->metaToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getShouldInterceptURL()LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDM<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->shouldInterceptURL:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public getToolbarSubtitle()Ljava/lang/String;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 3
    .line 4
    if-ne v1, v0, :cond_1

    .line 5
    .line 6
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    const-string v0, ""

    .line 17
    .line 18
    :cond_0
    invoke-static {v0}, LX/8mk;->A0j(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0

    .line 23
    :cond_1
    const/4 v0, 0x0

    .line 24
    return-object v0
.end method

.method public getUserAgent(LX/AR7;)Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-object p0
.end method

.method public getWebViewEndpoint()Ljava/lang/String;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapDialogUrl:Ljava/lang/String;

    .line 1
    .line 2
    if-nez v0, :cond_1

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loginPageUrl:Ljava/lang/String;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getRequest()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    instance-of v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    check-cast p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 17
    .line 18
    if-eqz p0, :cond_0

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->url:Ljava/lang/String;

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    :cond_0
    const-string v0, ""

    .line 25
    .line 26
    :cond_1
    return-object v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->getOwnsAuthTrace()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->activeAuthTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->authTraceId:Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 15
    .line 16
    :cond_0
    const/4 v2, 0x1

    .line 17
    if-eqz p1, :cond_1

    .line 18
    .line 19
    const-string v0, "native_link_one_tap_store_attempted"

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eq v1, v2, :cond_2

    .line 27
    .line 28
    :cond_1
    const/4 v0, 0x0

    .line 29
    :cond_2
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapStoreAttempted:Z

    .line 30
    .line 31
    if-eqz p1, :cond_3

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

    .line 34
    .line 35
    invoke-virtual {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->isEnabled()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_3

    .line 40
    .line 41
    :goto_0
    iput-boolean v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->gatedOff:Z

    .line 42
    .line 43
    invoke-super {p0, p1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onCreate(Landroid/os/Bundle;)V

    .line 44
    .line 45
    .line 46
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->gatedOff:Z

    .line 47
    .line 48
    if-nez v0, :cond_6

    .line 49
    .line 50
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_5

    .line 55
    .line 56
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->webViewProviderMissing:Z

    .line 57
    .line 58
    if-eqz v0, :cond_4

    .line 59
    .line 60
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->logWebViewUnavailable()V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :cond_3
    const/4 v2, 0x0

    .line 65
    goto :goto_0

    .line 66
    :cond_4
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->endAuthFailed()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :cond_5
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 71
    .line 72
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getCurrentSession()LX/AHE;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    if-eqz v3, :cond_6

    .line 77
    .line 78
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    const/4 v1, 0x0

    .line 87
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onCreate$1;

    .line 88
    .line 89
    invoke-direct {v0, p0, v3, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onCreate$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/AHE;LX/2M4;)V

    .line 90
    .line 91
    .line 92
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 93
    .line 94
    .line 95
    return-void

    .line 96
    :cond_6
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finish()V

    .line 97
    .line 98
    .line 99
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->logLinkerCancel()V

    .line 7
    .line 8
    .line 9
    :cond_0
    invoke-super {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onDestroy()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public onPause()V
    .locals 1

    .line 0
    invoke-super {p0}, Landroidx/fragment/app/FragmentActivity;->onPause()V

    .line 1
    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->logLinkerCancel()V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 5
    .line 6
    .line 7
    const-string v1, "native_link_one_tap_store_attempted"

    .line 8
    .line 9
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->oneTapStoreAttempted:Z

    .line 10
    .line 11
    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public onWebViewPageFinished()V
    .locals 3

    .line 0
    invoke-super {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onWebViewPageFinished()V

    .line 1
    .line 2
    .line 3
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->awaitingConsentPaint:Z

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->consentPaint:LX/Cbu;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const/4 v1, 0x0

    .line 20
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onWebViewPageFinished$1;

    .line 21
    .line 22
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onWebViewPageFinished$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v0, v2}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->consentPaint:LX/Cbu;

    .line 30
    .line 31
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->CONSENT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 34
    .line 35
    if-eq v1, v0, :cond_1

    .line 36
    .line 37
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->clearHistoryAfterLoad:Z

    .line 38
    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    :cond_1
    const/4 v0, 0x0

    .line 42
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->clearHistoryAfterLoad:Z

    .line 43
    .line 44
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-virtual {v0}, Landroid/webkit/WebView;->clearHistory()V

    .line 49
    .line 50
    .line 51
    :cond_2
    return-void
.end method

.method public onWebViewPageStarted()V
    .locals 3

    .line 0
    invoke-super {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onWebViewPageStarted()V

    .line 1
    .line 2
    .line 3
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loginPageCover:LX/Cbu;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    invoke-interface {v1, v0}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->step:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 12
    .line 13
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;->LOGIN:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$NativeLinkStep;

    .line 14
    .line 15
    if-ne v2, v1, :cond_1

    .line 16
    .line 17
    const v1, 0x7f0a01cc

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v1}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    if-eqz v1, :cond_1

    .line 25
    .line 26
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_1

    .line 31
    .line 32
    invoke-interface {p0}, LX/07p;->getLifecycle()LX/AaB;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-static {v1}, LX/AaA;->A00(LX/AaB;)LX/9rK;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onWebViewPageStarted$1;

    .line 41
    .line 42
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$onWebViewPageStarted$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    invoke-static {v1, v2}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    :cond_1
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->loginPageCover:LX/Cbu;

    .line 50
    .line 51
    return-void
.end method

.method public onWebViewUnavailable()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->webViewProviderMissing:Z

    .line 2
    .line 3
    invoke-super {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onWebViewUnavailable()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setExternalDomains(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method
