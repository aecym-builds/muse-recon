.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/AYT;


# instance fields
.field public final synthetic $callback:LX/AYT;

.field public final synthetic $isInitialLoad:Z

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;ZLX/AYT;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->$isInitialLoad:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->$callback:LX/AYT;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onFail$1;

    .line 3
    .line 4
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onFail$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onSuccess(Ljava/lang/String;)V
    .locals 5

    .line 0
    if-eqz p1, :cond_1

    .line 1
    .line 2
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 9
    .line 10
    sget v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->$stable:I

    .line 11
    .line 12
    iput-object p1, v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->sessionCookie:Ljava/lang/String;

    .line 13
    .line 14
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->$isInitialLoad:Z

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 19
    .line 20
    invoke-static {v0}, LX/AYw;->A00(LX/07p;)LX/9rK;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    iget-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 25
    .line 26
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->$callback:LX/AYT;

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;

    .line 30
    .line 31
    invoke-direct {v0, v3, p1, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;LX/AYT;LX/2M4;)V

    .line 32
    .line 33
    .line 34
    invoke-static {v0, v4}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->$callback:LX/AYT;

    .line 39
    .line 40
    invoke-interface {v0, p1}, LX/AYT;->onSuccess(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_1
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 45
    .line 46
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$1;

    .line 47
    .line 48
    invoke-direct {v0, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method
