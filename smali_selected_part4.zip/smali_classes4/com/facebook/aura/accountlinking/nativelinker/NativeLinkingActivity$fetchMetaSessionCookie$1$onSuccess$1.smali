.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$fetchMetaSessionCookie$1$onSuccess$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    invoke-static {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->access$failClosed(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
