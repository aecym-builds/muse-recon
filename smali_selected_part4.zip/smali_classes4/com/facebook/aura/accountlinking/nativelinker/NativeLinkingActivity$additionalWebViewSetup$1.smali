.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;
.super LX/ARA;
.source ""


# instance fields
.field public final synthetic $baseChromeClient:Landroid/webkit/WebChromeClient;

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Landroid/webkit/WebChromeClient;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;->$baseChromeClient:Landroid/webkit/WebChromeClient;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 3
    .line 4
    invoke-direct {p0}, LX/ARA;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public onCloseWindow(Landroid/webkit/WebView;)V
    .locals 1

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    const/4 p0, 0x1

    .line 3
    sget v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->$stable:I

    .line 4
    .line 5
    iput-boolean p0, p1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->closedByPage:Z

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->finish()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$additionalWebViewSetup$1;->$baseChromeClient:Landroid/webkit/WebChromeClient;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/webkit/WebChromeClient;->onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v0, 0x1

    .line 13
    if-ne v1, v0, :cond_0

    .line 14
    .line 15
    return v0

    .line 16
    :cond_0
    return v2
.end method
