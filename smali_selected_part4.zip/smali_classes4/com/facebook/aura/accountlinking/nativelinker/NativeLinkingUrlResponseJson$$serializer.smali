.class public final synthetic Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;

    .line 6
    .line 7
    const-string v0, "com.facebook.aura.accountlinking.nativelinker.NativeLinkingUrlResponseJson"

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    new-instance v1, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v1, v0, v3, v2}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "url"

    .line 16
    .line 17
    invoke-virtual {v1, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 18
    .line 19
    .line 20
    sput-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->descriptor:LX/Da5;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    invoke-static {}, LX/3Rs;->A1a()[LX/DZ7;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;
    .locals 7

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->descriptor:LX/Da5;

    .line 5
    .line 6
    invoke-interface {p1, v6}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 7
    .line 8
    .line 9
    move-result-object v5

    .line 10
    const/4 v4, 0x0

    .line 11
    move-object v3, v4

    .line 12
    const/4 v2, 0x0

    .line 13
    :goto_0
    invoke-interface {v5, v6}, LX/Da7;->A8S(LX/Da5;)I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v0, -0x1

    .line 18
    if-eq v1, v0, :cond_1

    .line 19
    .line 20
    if-nez v1, :cond_0

    .line 21
    .line 22
    invoke-static {v6, v5, p0}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    const/4 v2, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    new-instance v0, Lkotlinx/serialization/UnknownFieldException;

    .line 29
    .line 30
    invoke-direct {v0, v1}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 31
    .line 32
    .line 33
    throw v0

    .line 34
    :cond_1
    invoke-interface {v5, v6}, LX/Da7;->AAi(LX/Da5;)V

    .line 35
    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;

    .line 38
    .line 39
    invoke-direct {v0, v2, v3, v4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;-><init>(ILjava/lang/String;LX/5Xm;)V

    .line 40
    .line 41
    .line 42
    return-object v0
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->descriptor:LX/Da5;

    .line 268435460
    .line 268435461
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 268435462
    .line 268435463
    .line 268435464
    move-result-object v0

    .line 268435465
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_accountlinking_nativelinker_nativelinker(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;LX/Da8;LX/Da5;)V

    .line 268435466
    .line 268435467
    .line 268435468
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
