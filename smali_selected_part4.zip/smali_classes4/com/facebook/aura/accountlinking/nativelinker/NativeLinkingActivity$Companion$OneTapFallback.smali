.class public final enum Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum ACCOUNT_TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum ANOTHER_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum DIALOG_UNAVAILABLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum ERROR:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum NONE_ELIGIBLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum NO_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

.field public static final enum TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;


# instance fields
.field public final wireValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "timeout"

    .line 2
    .line 3
    const-string v0, "TIMEOUT"

    .line 4
    .line 5
    new-instance v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 6
    .line 7
    invoke-direct {v3, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "error"

    .line 14
    .line 15
    const-string v0, "ERROR"

    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 18
    .line 19
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ERROR:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "no_account"

    .line 26
    .line 27
    const-string v0, "NO_ACCOUNT"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->NO_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "account_timeout"

    .line 38
    .line 39
    const-string v0, "ACCOUNT_TIMEOUT"

    .line 40
    .line 41
    new-instance v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 42
    .line 43
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ACCOUNT_TIMEOUT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    const-string v1, "another_account"

    .line 50
    .line 51
    const-string v0, "ANOTHER_ACCOUNT"

    .line 52
    .line 53
    new-instance v7, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 54
    .line 55
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->ANOTHER_ACCOUNT:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 59
    .line 60
    const/4 v2, 0x5

    .line 61
    const-string v1, "dialog_unavailable"

    .line 62
    .line 63
    const-string v0, "DIALOG_UNAVAILABLE"

    .line 64
    .line 65
    new-instance v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 66
    .line 67
    invoke-direct {v8, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    sput-object v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->DIALOG_UNAVAILABLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 71
    .line 72
    const/4 v2, 0x6

    .line 73
    const-string v1, "none_eligible"

    .line 74
    .line 75
    const-string v0, "NONE_ELIGIBLE"

    .line 76
    .line 77
    new-instance v9, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 78
    .line 79
    invoke-direct {v9, v0, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    sput-object v9, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->NONE_ELIGIBLE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 83
    .line 84
    filled-new-array/range {v3 .. v9}, [Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    sput-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->$VALUES:[Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 89
    .line 90
    new-instance v0, LX/DvM;

    .line 91
    .line 92
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 93
    .line 94
    .line 95
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->$ENTRIES:LX/0vk;

    .line 96
    .line 97
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->wireValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->$VALUES:[Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getWireValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion$OneTapFallback;->wireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
