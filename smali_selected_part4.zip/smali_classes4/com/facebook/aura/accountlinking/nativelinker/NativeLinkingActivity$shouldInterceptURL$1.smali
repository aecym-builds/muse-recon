.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 5
    .line 6
    invoke-static {v0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->access$interceptWebAuth(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$shouldInterceptURL$1;->invoke(Ljava/lang/String;)Ljava/lang/Boolean;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
