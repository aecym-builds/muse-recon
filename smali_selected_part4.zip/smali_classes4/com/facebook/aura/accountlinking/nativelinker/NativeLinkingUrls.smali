.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final AGE_VERIFICATION_PURPOSE:Ljava/lang/String; = "age_verification"

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;

.field public static final REQUEST_TIMEOUT_MS:J = 0x4e20L


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getNativeWireValue(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p1}, LX/8mk;->A0i(Ljava/lang/Enum;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final dialogRequest(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;
    .locals 4

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 5
    .line 6
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;->target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 7
    .line 8
    invoke-static {v0}, LX/8mk;->A0i(Ljava/lang/Enum;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/4 v2, 0x0

    .line 13
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 14
    .line 15
    move-object v3, v2

    .line 16
    move-object p0, v2

    .line 17
    move-object p1, v2

    .line 18
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;->account:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 29
    .line 30
    invoke-static {v0}, LX/8mk;->A0i(Ljava/lang/Enum;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const/4 v2, 0x0

    .line 35
    const-string p1, "age_verification"

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 38
    .line 39
    move-object v3, v2

    .line 40
    move-object p0, v2

    .line 41
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :cond_1
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 46
    .line 47
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 48
    .line 49
    .line 50
    throw v0
.end method

.method private final dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_5

    .line 29
    .line 30
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    check-cast v2, LX/2PJ;

    .line 34
    .line 35
    if-eqz v2, :cond_4

    .line 36
    .line 37
    iget-object v1, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 38
    .line 39
    instance-of v0, v1, LX/2PH;

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    move-object v1, v3

    .line 44
    :cond_1
    check-cast v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;

    .line 45
    .line 46
    if-eqz v1, :cond_4

    .line 47
    .line 48
    iget-object v4, v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;->url:Ljava/lang/String;

    .line 49
    .line 50
    if-eqz v4, :cond_4

    .line 51
    .line 52
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_4

    .line 57
    .line 58
    return-object v4

    .line 59
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    new-instance v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;

    .line 63
    .line 64
    invoke-direct {v2, p1, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$3;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)V

    .line 65
    .line 66
    .line 67
    const/4 v0, 0x0

    .line 68
    iput-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->L$0:Ljava/lang/Object;

    .line 69
    .line 70
    iput v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;->label:I

    .line 71
    .line 72
    const-wide/16 v0, 0x4e20

    .line 73
    .line 74
    invoke-static {v5, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    if-ne v2, v4, :cond_0

    .line 79
    .line 80
    return-object v4

    .line 81
    :cond_3
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;

    .line 82
    .line 83
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$dialogUrl$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;LX/2M4;)V

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_4
    return-object v3

    .line 88
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    throw v0
.end method

.method private final getNativeWireValue(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p1}, LX/8mk;->A0i(Ljava/lang/Enum;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method


# virtual methods
.method public final dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->dialogRequest(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object v0

    .line 268435460
    iget-object v1, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 268435461
    .line 268435462
    iget-object v4, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->is_one_tap:Ljava/lang/Boolean;

    .line 268435463
    .line 268435464
    iget-object v5, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 268435465
    .line 268435466
    move-object v2, p2

    .line 268435467
    move-object v3, p3

    .line 268435468
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 268435469
    .line 268435470
    .line 268435471
    move-result-object v0

    .line 268435472
    invoke-direct {p0, v0, p4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)Ljava/lang/Object;

    .line 268435473
    .line 268435474
    .line 268435475
    move-result-object v0

    .line 268435476
    return-object v0
.end method

.method public final loginUrl(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_5

    .line 29
    .line 30
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    check-cast v2, LX/2PJ;

    .line 34
    .line 35
    if-eqz v2, :cond_4

    .line 36
    .line 37
    iget-object v1, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 38
    .line 39
    instance-of v0, v1, LX/2PH;

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    move-object v1, v3

    .line 44
    :cond_1
    check-cast v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;

    .line 45
    .line 46
    if-eqz v1, :cond_4

    .line 47
    .line 48
    iget-object v4, v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrlResponseJson;->url:Ljava/lang/String;

    .line 49
    .line 50
    if-eqz v4, :cond_4

    .line 51
    .line 52
    invoke-static {v4}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_4

    .line 57
    .line 58
    return-object v4

    .line 59
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    new-instance v2, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$2;

    .line 63
    .line 64
    invoke-direct {v2, p1, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;LX/2M4;)V

    .line 65
    .line 66
    .line 67
    const/4 v0, 0x0

    .line 68
    iput-object v0, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->L$0:Ljava/lang/Object;

    .line 69
    .line 70
    iput v1, v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;->label:I

    .line 71
    .line 72
    const-wide/16 v0, 0x4e20

    .line 73
    .line 74
    invoke-static {v5, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    if-ne v2, v4, :cond_0

    .line 79
    .line 80
    return-object v4

    .line 81
    :cond_3
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;

    .line 82
    .line 83
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls$loginUrl$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;LX/2M4;)V

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_4
    return-object v3

    .line 88
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    throw v0
.end method

.method public final oneTapDialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->dialogRequest(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {}, LX/002;->A0j()Ljava/lang/Boolean;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    iget-object v1, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->target:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v2, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->token:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v3, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->blob:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v5, v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->purpose:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-direct {p0, v0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingUrls;->dialogUrl(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingDialogRequestJson;LX/2M4;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method
