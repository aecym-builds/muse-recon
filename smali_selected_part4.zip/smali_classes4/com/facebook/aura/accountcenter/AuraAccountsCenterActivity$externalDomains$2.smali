.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/util/List<",
        "+",
        "Ljava/lang/String;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;->invoke()Ljava/util/List;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final invoke()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getExternalDomainsRaw()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    const-string v0, ","

    .line 5
    .line 6
    invoke-static {p0, v0}, LX/AdT;->A0h(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method
