.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $callback:LX/AYT;

.field public final synthetic $isInitialLoad:Z

.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;ZLX/AYT;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->$isInitialLoad:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->$callback:LX/AYT;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    iget-boolean v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->$isInitialLoad:Z

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;->$callback:LX/AYT;

    .line 5
    .line 6
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->access$fetchMetaSessionCookie$s1204830036(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;ZLX/AYT;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
