.class public final Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0x143f6

.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;

.field public static final __CONFIG__:I = 0x193

.field public static final ac_3p_link_url_connected_apps:LX/0d8;

.field public static final ac_3p_link_url_device_settings:LX/0d8;

.field public static final ac_3p_link_url_meta_ai_threads:LX/0d8;

.field public static final android_accounts_center_3p_link_url:LX/0d8;

.field public static final android_enable_3p_link_in_app_setting:LX/0d8;

.field public static final android_enable_3p_link_in_connected_apps:LX/0d8;

.field public static final android_enable_quirks_mode:LX/0d8;

.field public static final android_external_domains:LX/0d8;

.field public static final android_extra_auth_urls:LX/0d8;

.field public static final calendar_3p_upsell_version:LX/0d8;

.field public static final enable_3p_connector_local_prompt_resend:LX/0d8;

.field public static final enable_3p_connector_oauth_prompt_resend:LX/0d8;

.field public static final ios_accept_server_https_auth_callback:LX/0d8;

.field public static final ios_enable_3p_link_in_app_setting:LX/0d8;

.field public static final ios_enable_3p_link_in_connected_apps:LX/0d8;

.field public static final ios_use_https_auth_callback:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->INSTANCE:Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;

    .line 6
    .line 7
    const-wide v1, 0x830193000b000dL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ac_3p_link_url_connected_apps:LX/0d8;

    .line 18
    .line 19
    const-wide v1, 0x830193000c000eL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    new-instance v0, LX/0d8;

    .line 25
    .line 26
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ac_3p_link_url_device_settings:LX/0d8;

    .line 30
    .line 31
    const-wide v1, 0x830193000d000fL

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    new-instance v0, LX/0d8;

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ac_3p_link_url_meta_ai_threads:LX/0d8;

    .line 42
    .line 43
    const-wide v1, 0x8301930005000bL

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    new-instance v0, LX/0d8;

    .line 49
    .line 50
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 51
    .line 52
    .line 53
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_accounts_center_3p_link_url:LX/0d8;

    .line 54
    .line 55
    const-wide v1, 0x8101930003005dL    # 3.027195058003E-306

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    new-instance v0, LX/0d8;

    .line 61
    .line 62
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 63
    .line 64
    .line 65
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_enable_3p_link_in_app_setting:LX/0d8;

    .line 66
    .line 67
    const-wide v1, 0x8101930004005eL

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    new-instance v0, LX/0d8;

    .line 73
    .line 74
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_enable_3p_link_in_connected_apps:LX/0d8;

    .line 78
    .line 79
    const-wide v1, 0x810193000e005fL

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    new-instance v0, LX/0d8;

    .line 85
    .line 86
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 87
    .line 88
    .line 89
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_enable_quirks_mode:LX/0d8;

    .line 90
    .line 91
    const-wide v1, 0x830193000f0010L

    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    new-instance v0, LX/0d8;

    .line 97
    .line 98
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 99
    .line 100
    .line 101
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_external_domains:LX/0d8;

    .line 102
    .line 103
    const-wide v1, 0x830193000a000cL

    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    new-instance v0, LX/0d8;

    .line 109
    .line 110
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 111
    .line 112
    .line 113
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_extra_auth_urls:LX/0d8;

    .line 114
    .line 115
    const-wide v1, 0x82019300130841L

    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    new-instance v0, LX/0d8;

    .line 121
    .line 122
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 123
    .line 124
    .line 125
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->calendar_3p_upsell_version:LX/0d8;

    .line 126
    .line 127
    const-wide v1, 0x81019300170061L

    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    new-instance v0, LX/0d8;

    .line 133
    .line 134
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 135
    .line 136
    .line 137
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->enable_3p_connector_local_prompt_resend:LX/0d8;

    .line 138
    .line 139
    const-wide v1, 0x81019300180062L

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    new-instance v0, LX/0d8;

    .line 145
    .line 146
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 147
    .line 148
    .line 149
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->enable_3p_connector_oauth_prompt_resend:LX/0d8;

    .line 150
    .line 151
    const-wide v1, 0x2081019300190063L    # 4.058804991640089E-152

    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    new-instance v0, LX/0d8;

    .line 157
    .line 158
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 159
    .line 160
    .line 161
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ios_accept_server_https_auth_callback:LX/0d8;

    .line 162
    .line 163
    const-wide v1, 0x8101930000005bL

    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    new-instance v0, LX/0d8;

    .line 169
    .line 170
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 171
    .line 172
    .line 173
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ios_enable_3p_link_in_app_setting:LX/0d8;

    .line 174
    .line 175
    const-wide v1, 0x8101930001005cL

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    new-instance v0, LX/0d8;

    .line 181
    .line 182
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 183
    .line 184
    .line 185
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ios_enable_3p_link_in_connected_apps:LX/0d8;

    .line 186
    .line 187
    const-wide v1, 0x2081019300140060L

    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    new-instance v0, LX/0d8;

    .line 193
    .line 194
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 195
    .line 196
    .line 197
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->ios_use_https_auth_callback:LX/0d8;

    .line 198
    .line 199
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
