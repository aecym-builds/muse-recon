.class public abstract Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final accountsCenterUrl$delegate:LX/1zE;

.field public static final authUrlsBase$delegate:LX/1zE;

.field public static final externalDomainsRaw$delegate:LX/1zE;

.field public static final extraAuthUrls$delegate:LX/1zE;

.field public static final profilesUrl$delegate:LX/1zE;

.field public static final sandboxableAccountsCenterHosts:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final ssoUrl$delegate:LX/1zE;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const-class v3, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;

    .line 1
    .line 2
    const-string v1, "ssoUrl"

    .line 3
    .line 4
    const-string v0, "getSsoUrl()Ljava/lang/String;"

    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    new-instance v4, LX/EMK;

    .line 8
    .line 9
    invoke-direct {v4, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 10
    .line 11
    .line 12
    const-string v1, "profilesUrl"

    .line 13
    .line 14
    const-string v0, "getProfilesUrl()Ljava/lang/String;"

    .line 15
    .line 16
    new-instance v5, LX/EMK;

    .line 17
    .line 18
    invoke-direct {v5, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 19
    .line 20
    .line 21
    const-string v1, "accountsCenterUrl"

    .line 22
    .line 23
    const-string v0, "getAccountsCenterUrl()Ljava/lang/String;"

    .line 24
    .line 25
    new-instance v6, LX/EMK;

    .line 26
    .line 27
    invoke-direct {v6, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 28
    .line 29
    .line 30
    const-string v1, "authUrlsBase"

    .line 31
    .line 32
    const-string v0, "getAuthUrlsBase()Ljava/lang/String;"

    .line 33
    .line 34
    new-instance v7, LX/EMK;

    .line 35
    .line 36
    invoke-direct {v7, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    const-string v1, "extraAuthUrls"

    .line 40
    .line 41
    const-string v0, "getExtraAuthUrls()Ljava/lang/String;"

    .line 42
    .line 43
    new-instance v8, LX/EMK;

    .line 44
    .line 45
    invoke-direct {v8, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    const-string v1, "externalDomainsRaw"

    .line 49
    .line 50
    const-string v0, "getExternalDomainsRaw()Ljava/lang/String;"

    .line 51
    .line 52
    new-instance v9, LX/EMK;

    .line 53
    .line 54
    invoke-direct {v9, v3, v1, v0, v2}, LX/EMK;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 55
    .line 56
    .line 57
    filled-new-array/range {v4 .. v9}, [LX/Dqa;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 62
    .line 63
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->sso_url:LX/0d8;

    .line 64
    .line 65
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->ssoUrl$delegate:LX/1zE;

    .line 70
    .line 71
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->profiles_url:LX/0d8;

    .line 72
    .line 73
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->profilesUrl$delegate:LX/1zE;

    .line 78
    .line 79
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->accountscenter_url:LX/0d8;

    .line 80
    .line 81
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->accountsCenterUrl$delegate:LX/1zE;

    .line 86
    .line 87
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->auth_urls:LX/0d8;

    .line 88
    .line 89
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->authUrlsBase$delegate:LX/1zE;

    .line 94
    .line 95
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_extra_auth_urls:LX/0d8;

    .line 96
    .line 97
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->extraAuthUrls$delegate:LX/1zE;

    .line 102
    .line 103
    sget-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_3p_link;->android_external_domains:LX/0d8;

    .line 104
    .line 105
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigString(LX/0d8;)LX/1zE;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->externalDomainsRaw$delegate:LX/1zE;

    .line 110
    .line 111
    const-string v1, "accountscenter.meta.com"

    .line 112
    .line 113
    const-string v0, "auth.meta.com"

    .line 114
    .line 115
    invoke-static {v1, v0}, LX/0wJ;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Set;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->sandboxableAccountsCenterHosts:Ljava/util/Set;

    .line 120
    .line 121
    return-void
.end method

.method public static final synthetic access$getAccountsCenterUrl()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getAccountsCenterUrl()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final synthetic access$getAuthUrlsBase()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getAuthUrlsBase()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final synthetic access$getExternalDomainsRaw()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getExternalDomainsRaw()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final synthetic access$getExtraAuthUrls()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getExtraAuthUrls()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final synthetic access$getProfilesUrl()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getProfilesUrl()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final synthetic access$getSsoUrl()Ljava/lang/String;
    .locals 1

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getSsoUrl()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    return-object v0
.end method

.method public static final getAccountsCenterUrl()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->accountsCenterUrl$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getAuthUrlsBase()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->authUrlsBase$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getExternalDomainsRaw()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->externalDomainsRaw$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x5

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getExtraAuthUrls()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->extraAuthUrls$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getProfilesUrl()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->profilesUrl$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final getSsoUrl()Ljava/lang/String;
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->ssoUrl$delegate:LX/1zE;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->$$delegatedProperties:[LX/Dqa;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-static {v2, v1, v0}, LX/8mk;->A0m(LX/1zE;[LX/Dqa;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public static final sandboxAccountsCenterUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/network/sandbox/AuraSandbox;->INSTANCE:Lcom/facebook/aura/network/sandbox/AuraSandbox;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/network/sandbox/AuraSandbox;->getGraphqlHost()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    invoke-virtual {v3}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-static {v0}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v3}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v0, "https"

    .line 35
    .line 36
    if-eqz v1, :cond_0

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    invoke-virtual {v3}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    if-nez v0, :cond_0

    .line 49
    .line 50
    invoke-virtual {v3}, Landroid/net/Uri;->getPort()I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    const/4 v0, -0x1

    .line 55
    if-ne v1, v0, :cond_0

    .line 56
    .line 57
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->sandboxableAccountsCenterHosts:Ljava/util/Set;

    .line 58
    .line 59
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_0

    .line 64
    .line 65
    invoke-virtual {v3}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const-string v0, "."

    .line 70
    .line 71
    invoke-static {v4, v0, v2}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-static {v0}, LX/006;->A15(Ljava/lang/Object;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    :cond_0
    return-object p0
.end method
