.class public final Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CONFIG_ID:I = 0xdc31

.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;

.field public static final __CONFIG__:I = 0x103

.field public static final accountscenter_url:LX/0d8;

.field public static final auth_urls:LX/0d8;

.field public static final metasettings_url:LX/0d8;

.field public static final metasettingsdeleteaccount_url:LX/0d8;

.field public static final profiles_url:LX/0d8;

.field public static final sso_url:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->INSTANCE:Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;

    .line 6
    .line 7
    const-wide v1, 0x83010300010002L

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    new-instance v0, LX/0d8;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->accountscenter_url:LX/0d8;

    .line 18
    .line 19
    const-wide v1, 0x83010300000001L

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    new-instance v0, LX/0d8;

    .line 25
    .line 26
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->auth_urls:LX/0d8;

    .line 30
    .line 31
    const-wide v1, 0x83010300020003L

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    new-instance v0, LX/0d8;

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->metasettings_url:LX/0d8;

    .line 42
    .line 43
    const-wide v1, 0x83010300040004L

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    new-instance v0, LX/0d8;

    .line 49
    .line 50
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 51
    .line 52
    .line 53
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->metasettingsdeleteaccount_url:LX/0d8;

    .line 54
    .line 55
    const-wide v1, 0x83010300060006L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    new-instance v0, LX/0d8;

    .line 61
    .line 62
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 63
    .line 64
    .line 65
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->profiles_url:LX/0d8;

    .line 66
    .line 67
    const-wide v1, 0x83010300050005L

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    new-instance v0, LX/0d8;

    .line 73
    .line 74
    invoke-direct {v0, v1, v2}, LX/0d8;-><init>(J)V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lcom/facebook/aura/accountcenter/MC$mwa_accounts_center_settings;->sso_url:LX/0d8;

    .line 78
    .line 79
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
