.class public Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;
.super Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;
.source ""


# static fields
.field public static final synthetic $$delegatedProperties:[LX/Dqa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "LX/Dqa<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;

.field public static final KEY_ACCOUNT_ID:Ljava/lang/String; = "account_id"

.field public static final KEY_MEASUREMENT_GENERATION:Ljava/lang/String; = "hatch_ac_measurement_generation"

.field public static final KEY_PAGE:Ljava/lang/String; = "page"

.field public static final LOAD_MARKER:I = 0x33210e87

.field public static final NATIVE_PAGE_FINISHED:Ljava/lang/String; = "native_page_finished"

.field public static final STATIC_RESOURCE_ORIGIN:Ljava/lang/String; = "https://static.xx.fbcdn.net"

.field public static final TAG:Ljava/lang/String; = "AuraAccountsCenterActivity"

.field public static final measurementLaunchGeneration:Ljava/util/concurrent/atomic/AtomicLong;


# instance fields
.field public final authenticatedRequestFactory:LX/GIo;

.field public final externalDomains$delegate:LX/Dqj;

.field public final frlAppId:Ljava/lang/String;

.field public final initialCredentialFingerprint:Ljava/lang/String;

.field public final initialCredentialStable:Z

.field public initialLoadObservationStopped:Z

.field public final initialLoadPhaseObserver:LX/AYW;

.field public final metaToken:Ljava/lang/String;

.field public pageConnectionWarmer:Landroid/webkit/WebView;

.field public final recordedInitialLoadPhases:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final shouldInterceptURL:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public toolbar:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    .line 0
    const-string v3, "externalDomains"

    .line 1
    .line 2
    const-string v4, "getExternalDomains()Ljava/util/List;"

    .line 3
    .line 4
    const-class v2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 5
    .line 6
    const/4 v5, 0x0

    .line 7
    sget-object v1, LX/DqR;->NO_RECEIVER:Ljava/lang/Object;

    .line 8
    .line 9
    new-instance v0, LX/DqY;

    .line 10
    .line 11
    invoke-direct/range {v0 .. v5}, LX/DqS;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    filled-new-array {v0}, [LX/Dqa;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->$$delegatedProperties:[LX/Dqa;

    .line 19
    .line 20
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 23
    .line 24
    .line 25
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->Companion:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;

    .line 26
    .line 27
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 30
    .line 31
    .line 32
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->measurementLaunchGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 33
    .line 34
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 0
    invoke-direct {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;-><init>()V

    .line 1
    .line 2
    .line 3
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordedInitialLoadPhases:Ljava/util/Set;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$initialLoadPhaseObserver$1;

    .line 11
    .line 12
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$initialLoadPhaseObserver$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialLoadPhaseObserver:LX/AYW;

    .line 16
    .line 17
    const/16 v0, 0x15

    .line 18
    .line 19
    invoke-static {v0}, LX/Bi8;->A00(I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->frlAppId:Ljava/lang/String;

    .line 24
    .line 25
    sget-object v2, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->INSTANCE:Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;

    .line 26
    .line 27
    invoke-virtual {v2}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->frlFingerprint()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iput-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialCredentialFingerprint:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v2}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->getMetaAccessToken()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->metaToken:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v2}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->frlFingerprint()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    iput-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialCredentialStable:Z

    .line 48
    .line 49
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;

    .line 50
    .line 51
    invoke-virtual {v0}, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;->getInstance()LX/GIo;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->authenticatedRequestFactory:LX/GIo;

    .line 56
    .line 57
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$externalDomains$2;

    .line 58
    .line 59
    invoke-static {v0}, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt;->auraMobileConfigVar(Lkotlin/jvm/functions/Function0;)LX/Dqj;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->externalDomains$delegate:LX/Dqj;

    .line 64
    .line 65
    return-void
.end method

.method public static final synthetic access$fetchMetaSessionCookie$s1204830036(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;ZLX/AYT;)V
    .locals 0

    .line 0
    invoke-super {p0, p1, p2}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->fetchMetaSessionCookie(ZLX/AYT;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getMeasurementLaunchGeneration$cp()Ljava/util/concurrent/atomic/AtomicLong;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->measurementLaunchGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$recordInitialLoadPhase(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;Ljava/lang/String;J)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method private final applyEdgeToEdge()V
    .locals 3

    .line 0
    invoke-static {p0}, LX/002;->A0Q(Landroid/content/Context;)Landroid/content/res/Configuration;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 5
    .line 6
    and-int/lit8 v1, v0, 0x30

    .line 7
    .line 8
    const/16 v0, 0x20

    .line 9
    .line 10
    const v2, -0xa0a0b

    .line 11
    .line 12
    .line 13
    if-ne v1, v0, :cond_0

    .line 14
    .line 15
    const/high16 v2, -0x1000000

    .line 16
    .line 17
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    .line 22
    .line 23
    invoke-direct {v0, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method private final endLoadMarker()V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 1
    .line 2
    const v3, 0x33210e87

    .line 3
    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {v4, v3, v2}, Lcom/facebook/aura/perf/HatchQplLogger;->isMarkerOn(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebView()LX/AR7;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    const-string v0, ""

    .line 23
    .line 24
    :cond_0
    invoke-static {v0}, LX/8mk;->A0j(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    if-eqz v1, :cond_2

    .line 29
    .line 30
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebViewEndpoint()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-static {v0}, LX/8mk;->A0j(Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    const/4 v0, 0x2

    .line 45
    :goto_0
    invoke-virtual {v4, v3, v0, v2}, Lcom/facebook/aura/perf/HatchQplLogger;->markerEnd(ISI)V

    .line 46
    .line 47
    .line 48
    :cond_1
    return-void

    .line 49
    :cond_2
    const-string v1, "fail_reason"

    .line 50
    .line 51
    const-string v0, "redirected_off_accounts_center"

    .line 52
    .line 53
    invoke-virtual {v4, v3, v1, v0, v2}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;Ljava/lang/String;I)V

    .line 54
    .line 55
    .line 56
    const/4 v0, 0x3

    .line 57
    goto :goto_0
.end method

.method private final getAccountsCenterUrl()Ljava/lang/String;
    .locals 3

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    const-string v0, "page"

    .line 5
    .line 6
    invoke-virtual {v1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v2, ""

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    move-object v1, v2

    .line 15
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;->META_ACCOUNT_SSO:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;

    .line 16
    .line 17
    invoke-virtual {v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;->getValue()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v0, "account_id"

    .line 32
    .line 33
    invoke-virtual {v1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    move-object v2, v0

    .line 40
    :cond_1
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getSsoUrl()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-static {v0, v2}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0

    .line 49
    :cond_2
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;->PROFILES:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;

    .line 50
    .line 51
    invoke-virtual {v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Page;->getValue()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getProfilesUrl()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    return-object v0

    .line 66
    :cond_3
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getAccountsCenterUrl()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    return-object v0
.end method

.method private final isCurrentMeasurementLaunch()Z
    .locals 5

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    const-string v0, "hatch_ac_measurement_generation"

    .line 5
    .line 6
    const-wide/16 v1, 0x0

    .line 7
    .line 8
    invoke-virtual {v3, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v4

    .line 12
    cmp-long v0, v4, v1

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->measurementLaunchGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 19
    .line 20
    .line 21
    move-result-wide v2

    .line 22
    cmp-long v1, v4, v2

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :cond_1
    return v0
.end method

.method private final recordInitialLoadPhase(Ljava/lang/String;J)Z
    .locals 6

    .line 0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const/4 v5, 0x0

    .line 5
    if-nez v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_1

    .line 12
    .line 13
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialLoadObservationStopped:Z

    .line 14
    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->isCurrentMeasurementLaunch()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordedInitialLoadPhases:Ljava/util/Set;

    .line 24
    .line 25
    const-string v0, "native_page_finished"

    .line 26
    .line 27
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    sget-object v2, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 34
    .line 35
    const v3, 0x33210e87

    .line 36
    .line 37
    .line 38
    invoke-virtual {v2, v3, v5}, Lcom/facebook/aura/perf/HatchQplLogger;->isMarkerOn(II)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialCredentialStable:Z

    .line 45
    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialCredentialFingerprint:Ljava/lang/String;

    .line 49
    .line 50
    sget-object v0, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->INSTANCE:Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;

    .line 51
    .line 52
    invoke-virtual {v0}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->frlFingerprint()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordedInitialLoadPhases:Ljava/util/Set;

    .line 63
    .line 64
    move-object v4, p1

    .line 65
    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    sget-object v0, LX/AXl;->A0B:LX/AXl;

    .line 72
    .line 73
    iget-object v0, v0, LX/AXl;->pointName:Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_0

    .line 80
    .line 81
    const-string v1, "hatch_ac_measurement_version"

    .line 82
    .line 83
    const/4 v0, 0x1

    .line 84
    invoke-virtual {v2, v3, v1, v0, v5}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;II)V

    .line 85
    .line 86
    .line 87
    const-string v1, "hatch_ac_phase_scope"

    .line 88
    .line 89
    const-string v0, "initial_controller_load"

    .line 90
    .line 91
    invoke-virtual {v2, v3, v1, v0, v5}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;Ljava/lang/String;I)V

    .line 92
    .line 93
    .line 94
    :cond_0
    move-wide p0, p2

    .line 95
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/perf/HatchQplLogger;->markerPoint(ILjava/lang/String;IJ)V

    .line 96
    .line 97
    .line 98
    const/4 v0, 0x1

    .line 99
    return v0

    .line 100
    :cond_1
    return v5
.end method

.method public static synthetic recordInitialLoadPhase$default(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;Ljava/lang/String;JILjava/lang/Object;)Z
    .locals 1

    .line 0
    if-nez p5, :cond_1

    .line 1
    .line 2
    and-int/lit8 v0, p4, 0x2

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 7
    .line 8
    .line 9
    move-result-wide p2

    .line 10
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0

    .line 15
    :cond_1
    const-string p0, "Super calls with default arguments not supported in this target, function: recordInitialLoadPhase"

    .line 16
    .line 17
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 18
    .line 19
    invoke-direct {v0, p0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw v0
.end method

.method private final releasePageConnectionWarmer()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->pageConnectionWarmer:Landroid/webkit/WebView;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 5
    .line 6
    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->pageConnectionWarmer:Landroid/webkit/WebView;

    .line 9
    .line 10
    return-void
.end method

.method private final setupToolbar()V
    .locals 9

    .line 0
    invoke-static {p0}, LX/002;->A0Q(Landroid/content/Context;)Landroid/content/res/Configuration;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 5
    .line 6
    and-int/lit8 v2, v0, 0x30

    .line 7
    .line 8
    const/16 v0, 0x20

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    const/4 v7, 0x0

    .line 12
    invoke-static {v2, v0}, LX/003;->A1I(II)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/high16 v2, -0x1000000

    .line 17
    .line 18
    const v8, -0xa0a0b

    .line 19
    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    const/high16 v8, -0x1000000

    .line 24
    .line 25
    :cond_0
    const/4 v6, -0x1

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    const/4 v2, -0x1

    .line 29
    :cond_1
    const v0, 0x1020002

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    invoke-static {v5}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    check-cast v5, Landroid/view/ViewGroup;

    .line 40
    .line 41
    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 46
    .line 47
    .line 48
    new-instance v3, Landroidx/appcompat/widget/Toolbar;

    .line 49
    .line 50
    invoke-direct {v3, p0}, Landroidx/appcompat/widget/Toolbar;-><init>(Landroid/content/Context;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v3, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 54
    .line 55
    .line 56
    const v0, 0x7f0800b6

    .line 57
    .line 58
    .line 59
    invoke-virtual {v3, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationIcon(I)V

    .line 60
    .line 61
    .line 62
    const v0, 0x7f120806

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v3, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationContentDescription(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$toolbar$1$1;

    .line 73
    .line 74
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$toolbar$1$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v3, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->getInitialTitleRes()I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-virtual {v3, v0}, Landroidx/appcompat/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v3, v2}, Landroidx/appcompat/widget/Toolbar;->setTitleTextColor(I)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {v3}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    if-eqz v0, :cond_2

    .line 99
    .line 100
    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 101
    .line 102
    .line 103
    :cond_2
    iput-object v3, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 104
    .line 105
    new-instance v2, Landroid/widget/LinearLayout;

    .line 106
    .line 107
    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 111
    .line 112
    .line 113
    const/4 v1, -0x2

    .line 114
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 115
    .line 116
    invoke-direct {v0, v6, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v2, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 120
    .line 121
    .line 122
    const/high16 v1, 0x3f800000    # 1.0f

    .line 123
    .line 124
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 125
    .line 126
    invoke-direct {v0, v6, v7, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v2, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 130
    .line 131
    .line 132
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    .line 133
    .line 134
    invoke-direct {v0, v6, v6}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v5, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 138
    .line 139
    .line 140
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;

    .line 141
    .line 142
    invoke-direct {v0, v3}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;-><init>(Landroidx/appcompat/widget/Toolbar;)V

    .line 143
    .line 144
    .line 145
    invoke-static {v2, v0}, LX/0dw;->A00(Landroid/view/View;LX/0aD;)V

    .line 146
    .line 147
    .line 148
    return-void
.end method

.method private final warmPageConnection()V
    .locals 9

    .line 0
    invoke-virtual {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->getWebViewEndpoint()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-static {v1}, LX/8mk;->A1S(Landroid/net/Uri;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {v1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-virtual {v1}, Landroid/net/Uri;->getEncodedAuthority()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const-string v0, "https://"

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0}, Landroid/text/TextUtils;->htmlEncode(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    new-instance v3, Landroid/webkit/WebView;

    .line 41
    .line 42
    invoke-direct {v3, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    const/4 v1, 0x0

    .line 50
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 65
    .line 66
    .line 67
    const-string v1, "<link rel=\"preconnect\" href=\""

    .line 68
    .line 69
    const-string v0, "\"><link rel=\"preconnect\" href=\"https://static.xx.fbcdn.net\" crossorigin>"

    .line 70
    .line 71
    invoke-static {v1, v2, v0}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    const-string v7, "utf-8"

    .line 76
    .line 77
    const/4 v4, 0x0

    .line 78
    const-string v6, "text/html"

    .line 79
    .line 80
    move-object v8, v4

    .line 81
    invoke-virtual/range {v3 .. v8}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    iput-object v3, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->pageConnectionWarmer:Landroid/webkit/WebView;

    .line 85
    .line 86
    :cond_0
    return-void
.end method


# virtual methods
.method public additionalWebViewSetup(LX/AR7;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string v2, "device_cookie_prepare_start"

    .line 5
    .line 6
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 11
    .line 12
    .line 13
    :try_start_0
    sget-object v0, Lcom/facebook/aura/auth/deviceid/datr/AuraDatrDeviceIdentityBridge;->INSTANCE:Lcom/facebook/aura/auth/deviceid/datr/AuraDatrDeviceIdentityBridge;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/facebook/aura/auth/deviceid/datr/AuraDatrDeviceIdentityBridge;->prepare()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    .line 17
    .line 18
    const-string v2, "device_cookie_prepare_end"

    .line 19
    .line 20
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 21
    .line 22
    .line 23
    move-result-wide v0

    .line 24
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 25
    .line 26
    .line 27
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->warmPageConnection()V

    .line 28
    .line 29
    .line 30
    const-string v0, "WEB_AUTHENTICATION"

    .line 31
    .line 32
    invoke-static {v0}, LX/ARm;->A00(Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    sget-object v0, LX/ARm;->A16:LX/AR1;

    .line 43
    .line 44
    invoke-virtual {v0}, LX/ARo;->A01()Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    invoke-static {v1}, LX/ARK;->A00(Landroid/webkit/WebSettings;)LX/ARC;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    const/4 v1, 0x1

    .line 55
    instance-of v0, v2, LX/ARJ;

    .line 56
    .line 57
    if-nez v0, :cond_0

    .line 58
    .line 59
    iget-object v0, v2, LX/ARC;->A00:Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 60
    .line 61
    invoke-interface {v0, v1}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setWebauthnSupport(I)V

    .line 62
    .line 63
    .line 64
    :cond_0
    return-void

    .line 65
    :cond_1
    invoke-static {}, LX/8mk;->A0p()Ljava/lang/UnsupportedOperationException;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    throw v0

    .line 70
    :catchall_0
    move-exception v3

    .line 71
    const-string v2, "device_cookie_prepare_end"

    .line 72
    .line 73
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 74
    .line 75
    .line 76
    move-result-wide v0

    .line 77
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 78
    .line 79
    .line 80
    throw v3
.end method

.method public fetchMetaSessionCookie(ZLX/AYT;)V
    .locals 10

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    const-string v2, "hatch_ac_measurement_generation"

    .line 13
    .line 14
    const-wide/16 v0, 0x0

    .line 15
    .line 16
    invoke-virtual {v3, v2, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    iget-object v7, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialCredentialFingerprint:Ljava/lang/String;

    .line 21
    .line 22
    new-instance v8, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;

    .line 23
    .line 24
    invoke-direct {v8, p0, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;LX/AYT;)V

    .line 25
    .line 26
    .line 27
    new-instance v9, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;

    .line 28
    .line 29
    invoke-direct {v9, p0, p1, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$2;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;ZLX/AYT;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual/range {v4 .. v9}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->join(JLjava/lang/String;LX/JDQ;Lkotlin/jvm/functions/Function0;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    return-void

    .line 39
    :cond_0
    invoke-super {p0, p1, p2}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->fetchMetaSessionCookie(ZLX/AYT;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public getAuthUrls()Ljava/lang/String;
    .locals 2

    .line 0
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getAuthUrlsBase()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->getExtraAuthUrls()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-string v0, ","

    .line 9
    .line 10
    invoke-static {p0, v0, v1}, LX/Gi8;->A0m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public getAuthenticatedRequestFactory()LX/GIo;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->authenticatedRequestFactory:LX/GIo;

    .line 1
    .line 2
    return-object p0
.end method

.method public getExternalDomains()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->externalDomains$delegate:LX/Dqj;

    .line 1
    .line 2
    check-cast p0, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt$auraMobileConfigVar$1;

    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/mobileconfig/AuraMobileConfigDelegatesKt$auraMobileConfigVar$1;->$compute:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Ljava/util/List;

    .line 11
    .line 12
    return-object p0
.end method

.method public getFrlAppId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->frlAppId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getInitialLoadPhaseObserver()LX/AYW;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialLoadPhaseObserver:LX/AYW;

    .line 1
    .line 2
    return-object p0
.end method

.method public getInitialTitleRes()I
    .locals 0

    .line 0
    const p0, 0x7f1201e3

    .line 1
    .line 2
    .line 3
    return p0
.end method

.method public getMetaToken()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->metaToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public getShouldInterceptURL()LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDM<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->shouldInterceptURL:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method

.method public getToolbarSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public getUserAgent(LX/AR7;)Ljava/lang/String;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/network/AuraUserAgent;->INSTANCE:Lcom/facebook/aura/network/AuraUserAgent;

    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v0}, Lcom/facebook/aura/network/AuraUserAgent;->generateWebUserAgent(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public getWebViewEndpoint()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->getAccountsCenterUrl()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivityKt;->sandboxAccountsCenterUrl(Ljava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 0
    invoke-static {p0}, LX/119;->A00(Landroidx/activity/ComponentActivity;)V

    .line 1
    .line 2
    .line 3
    :try_start_0
    invoke-super {p0, p1}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->onCreate(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->getSupportActionBar()LX/0qN;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0}, LX/0qN;->A0B()V

    .line 13
    .line 14
    .line 15
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->setupToolbar()V

    .line 16
    .line 17
    .line 18
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->applyEdgeToEdge()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :catch_0
    move-exception v2

    .line 23
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;

    .line 24
    .line 25
    invoke-static {v2, v0}, LX/B85;->A0D(Ljava/lang/Object;LX/JDM;)LX/0Xf;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v0}, LX/0Xf;->iterator()Ljava/util/Iterator;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    :cond_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    instance-of v0, v0, Landroid/util/AndroidRuntimeException;

    .line 44
    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    const-string v1, "WebView provider unavailable"

    .line 48
    .line 49
    const-string v0, "AuraAccountsCenterActivity"

    .line 50
    .line 51
    invoke-static {v0, v1, v2}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->onWebViewUnavailable()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_2
    throw v2
.end method

.method public onDestroy()V
    .locals 4

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->releasePageConnectionWarmer()V

    .line 1
    .line 2
    .line 3
    sget-object v3, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 4
    .line 5
    const v2, 0x33210e87

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v3, v2, v1}, Lcom/facebook/aura/perf/HatchQplLogger;->isMarkerOn(II)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    const/4 v0, 0x4

    .line 16
    invoke-virtual {v3, v2, v0, v1}, Lcom/facebook/aura/perf/HatchQplLogger;->markerEnd(ISI)V

    .line 17
    .line 18
    .line 19
    :cond_0
    invoke-super {p0}, Llibraries/fxmetalogin/accountscenter/WebViewAccountsCenterBaseActivity;->onDestroy()V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public onStop()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->initialLoadObservationStopped:Z

    .line 2
    .line 3
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onStop()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public onWebViewPageFinished()V
    .locals 3

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->releasePageConnectionWarmer()V

    .line 1
    .line 2
    .line 3
    const-string v2, "native_page_finished"

    .line 4
    .line 5
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 10
    .line 11
    .line 12
    invoke-direct {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->endLoadMarker()V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->refreshToolbar()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public onWebViewPageStarted()V
    .locals 3

    .line 0
    const-string v2, "navigation_committed"

    .line 1
    .line 2
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    invoke-direct {p0, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->recordInitialLoadPhase(Ljava/lang/String;J)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public onWebViewUnavailable()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 1
    .line 2
    const v0, 0x7f1201e5

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final refreshToolbar()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->resolveToolbarTitle()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v1, v0}, Landroidx/appcompat/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 12
    .line 13
    if-eqz v1, :cond_1

    .line 14
    .line 15
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->getToolbarSubtitle()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v1, v0}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    return-void
.end method

.method public resolveToolbarTitle()Ljava/lang/String;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/utils/MetaAccountEntrypoint;->INSTANCE:Lcom/facebook/aura/utils/MetaAccountEntrypoint;

    .line 1
    .line 2
    invoke-virtual {v1}, Lcom/facebook/aura/utils/MetaAccountEntrypoint;->getCanSeeNewEntrypoint()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v1}, Lcom/facebook/aura/utils/MetaAccountEntrypoint;->getTitle()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    :cond_0
    const v0, 0x7f1201e4

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    :cond_1
    return-object v1
.end method

.method public setExternalDomains(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
