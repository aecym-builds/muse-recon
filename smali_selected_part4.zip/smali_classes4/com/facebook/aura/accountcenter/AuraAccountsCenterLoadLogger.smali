.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;

.field public static final LOAD_MARKER:I = 0x33210e87


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final logSettingsEntrypointNavigate(LX/AHE;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->Companion:Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/confidentialvm/api/ConfidentialSessionGate;->isConfidentialVmForAnalyticsMode()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    check-cast p1, LX/AHu;

    .line 17
    .line 18
    iget-object v0, p1, LX/AHu;->A01:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/0wP;->A01(Ljava/lang/String;)Ljava/lang/Long;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    if-eqz p1, :cond_0

    .line 25
    .line 26
    sget-object v0, Lcom/facebook/aura/analytics/AuraLogger;->INSTANCE:Lcom/facebook/aura/analytics/AuraLogger;

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/AuraLogger;->getInstance()LX/ES4;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const-string v0, "fxcal_settings_product"

    .line 33
    .line 34
    invoke-interface {v1, v0}, LX/ES4;->acquireEvent(Ljava/lang/String;)LX/I2T;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    invoke-interface {p0}, LX/I2T;->isSampled()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    const-string v0, "viewer_account_id"

    .line 45
    .line 46
    invoke-interface {p0, v0, p1}, LX/I2T;->A3f(Ljava/lang/String;Ljava/lang/Long;)V

    .line 47
    .line 48
    .line 49
    sget-object v1, LX/9sG;->A01:LX/9sG;

    .line 50
    .line 51
    const-string v0, "event"

    .line 52
    .line 53
    invoke-interface {p0, v1, v0}, LX/I2T;->A3V(LX/DfA;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const-string v1, "app_settings"

    .line 57
    .line 58
    const-string v0, "entry_point"

    .line 59
    .line 60
    invoke-interface {p0, v0, v1}, LX/I2T;->A3z(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-interface {p0}, LX/I2T;->AQ5()V

    .line 64
    .line 65
    .line 66
    :cond_0
    return-void
.end method

.method public final startSettingsLoad()V
    .locals 4

    .line 0
    sget-object p0, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 1
    .line 2
    const v3, 0x33210e87

    .line 3
    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {p0, v3, v2}, Lcom/facebook/aura/perf/HatchQplLogger;->isMarkerOn(II)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-virtual {p0, v3, v2, v0}, Lcom/facebook/aura/perf/HatchQplLogger;->markerStart(IIZ)V

    .line 12
    .line 13
    .line 14
    const-string v0, "hatch_ac_phase_ambiguous"

    .line 15
    .line 16
    invoke-virtual {p0, v3, v0, v1, v2}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;ZI)V

    .line 17
    .line 18
    .line 19
    return-void
.end method
