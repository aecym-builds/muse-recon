.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Throwable;",
        "Ljava/lang/Throwable;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$onCreate$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/lang/Throwable;

    .line 1
    .line 2
    const/4 p0, 0x0

    .line 3
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final invoke(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    .locals 0

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method
