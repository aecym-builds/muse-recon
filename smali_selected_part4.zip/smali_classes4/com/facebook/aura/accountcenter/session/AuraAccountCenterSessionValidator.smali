.class public final Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;->INSTANCE:Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final validateSession(LX/2M4;)Ljava/lang/Object;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;

    .line 3
    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    move-object v6, v3

    .line 7
    check-cast v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;

    .line 8
    .line 9
    iget v2, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_6

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v3, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->label:I

    .line 25
    .line 26
    const/4 v4, 0x2

    .line 27
    const/4 v9, 0x1

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    if-eq v0, v9, :cond_2

    .line 31
    .line 32
    if-ne v0, v4, :cond_7

    .line 33
    .line 34
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    :goto_1
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 38
    .line 39
    return-object v5

    .line 40
    :cond_1
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    sget-object v3, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 44
    .line 45
    invoke-virtual {v3}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getCurrentSessionSnapshot()Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-eqz v0, :cond_0

    .line 50
    .line 51
    iget-object v2, v0, Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;->session:LX/AHE;

    .line 52
    .line 53
    iget-object v1, v0, Lcom/facebook/aura/auth/api/AuraSessionManager$SessionSnapshot;->accessToken:Ljava/lang/String;

    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    iput-object v0, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    iput-object v2, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$1:Ljava/lang/Object;

    .line 59
    .line 60
    iput v9, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->label:I

    .line 61
    .line 62
    invoke-virtual {v3, v2, v1, v6}, Lcom/facebook/aura/auth/api/AuraSessionManager;->refreshAbraToken(LX/AHE;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    if-ne v3, v5, :cond_3

    .line 67
    .line 68
    return-object v5

    .line 69
    :cond_2
    iget-object v2, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$1:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v2, LX/AHE;

    .line 72
    .line 73
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_3
    check-cast v3, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult;

    .line 77
    .line 78
    instance-of v0, v3, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Retry;

    .line 79
    .line 80
    if-nez v0, :cond_5

    .line 81
    .line 82
    instance-of v0, v3, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Failed;

    .line 83
    .line 84
    if-eqz v0, :cond_4

    .line 85
    .line 86
    sget-object v1, Lcom/facebook/aura/auth/logout/AuraLogoutHelper;->INSTANCE:Lcom/facebook/aura/auth/logout/AuraLogoutHelper;

    .line 87
    .line 88
    check-cast v3, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Failed;

    .line 89
    .line 90
    iget-object v0, v3, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Failed;->accessToken:Ljava/lang/String;

    .line 91
    .line 92
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/auth/logout/AuraLogoutHelper;->performLogoutIfCurrent(LX/AHE;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_4
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Unavailable;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$Unavailable;

    .line 97
    .line 98
    invoke-static {v3, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-nez v0, :cond_0

    .line 103
    .line 104
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$SessionChanged;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager$AbraTokenRefreshResult$SessionChanged;

    .line 105
    .line 106
    invoke-static {v3, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-nez v0, :cond_0

    .line 111
    .line 112
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 113
    .line 114
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 115
    .line 116
    .line 117
    throw v0

    .line 118
    :cond_5
    sget-object v7, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 119
    .line 120
    sget-object v10, Lcom/facebook/aura/network/api/StefiHatchPath$TosStatus;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$TosStatus;

    .line 121
    .line 122
    sget-object v11, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 123
    .line 124
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 125
    .line 126
    .line 127
    move-result-object v14

    .line 128
    sget-object v8, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 129
    .line 130
    const/4 v12, 0x0

    .line 131
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$0:Ljava/lang/Object;

    .line 132
    .line 133
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$1:Ljava/lang/Object;

    .line 134
    .line 135
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$2:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$3:Ljava/lang/Object;

    .line 138
    .line 139
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$4:Ljava/lang/Object;

    .line 140
    .line 141
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$5:Ljava/lang/Object;

    .line 142
    .line 143
    iput-object v12, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->L$6:Ljava/lang/Object;

    .line 144
    .line 145
    iput v4, v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;->label:I

    .line 146
    .line 147
    move-object v13, v12

    .line 148
    move-object v15, v14

    .line 149
    move-object/from16 p0, v12

    .line 150
    .line 151
    move-object/from16 p1, v6

    .line 152
    .line 153
    invoke-virtual/range {v7 .. v17}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    if-ne v0, v5, :cond_0

    .line 158
    .line 159
    return-object v5

    .line 160
    :cond_6
    new-instance v6, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;

    .line 161
    .line 162
    move-object/from16 v0, p0

    .line 163
    .line 164
    invoke-direct {v6, v0, v3}, Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator$validateSession$1;-><init>(Lcom/facebook/aura/accountcenter/session/AuraAccountCenterSessionValidator;LX/2M4;)V

    .line 165
    .line 166
    .line 167
    goto/16 :goto_0

    .line 168
    .line 169
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    throw v0
.end method
