.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$initialLoadPhaseObserver$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/AYW;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$initialLoadPhaseObserver$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final onPhase(LX/AXl;J)V
    .locals 5

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$initialLoadPhaseObserver$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 5
    .line 6
    iget-object v0, p1, LX/AXl;->pointName:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v1, v0, p2, p3}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->access$recordInitialLoadPhase(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;Ljava/lang/String;J)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/4 v0, 0x4

    .line 19
    if-eq v1, v0, :cond_3

    .line 20
    .line 21
    const/4 v0, 0x5

    .line 22
    if-eq v1, v0, :cond_2

    .line 23
    .line 24
    const/4 v0, 0x6

    .line 25
    if-eq v1, v0, :cond_1

    .line 26
    .line 27
    const/4 v0, 0x7

    .line 28
    if-ne v1, v0, :cond_0

    .line 29
    .line 30
    sget-object v3, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 31
    .line 32
    const-string v2, "hatch_ac_cookie_exchange_skipped"

    .line 33
    .line 34
    :goto_0
    const v1, 0x33210e87

    .line 35
    .line 36
    .line 37
    const/4 v0, 0x1

    .line 38
    invoke-virtual {v3, v1, v2, v0, v4}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;ZI)V

    .line 39
    .line 40
    .line 41
    const-string v0, "hatch_ac_cookie_received"

    .line 42
    .line 43
    invoke-virtual {v3, v1, v0, v4, v4}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;ZI)V

    .line 44
    .line 45
    .line 46
    :cond_0
    return-void

    .line 47
    :cond_1
    sget-object v3, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 48
    .line 49
    const-string v2, "hatch_ac_cookie_exchange_empty"

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_2
    sget-object v3, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 53
    .line 54
    const-string v2, "hatch_ac_cookie_exchange_failed"

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_3
    sget-object v3, Lcom/facebook/aura/perf/HatchQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchQplLogger;

    .line 58
    .line 59
    const-string v2, "hatch_ac_cookie_received"

    .line 60
    .line 61
    const v1, 0x33210e87

    .line 62
    .line 63
    .line 64
    const/4 v0, 0x1

    .line 65
    invoke-virtual {v3, v1, v2, v0, v4}, Lcom/facebook/aura/perf/HatchQplLogger;->markerAnnotate(ILjava/lang/String;ZI)V

    .line 66
    .line 67
    .line 68
    return-void
.end method
