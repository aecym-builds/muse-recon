.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $startedAtNs:J

.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;J)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;->$startedAtNs:J

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    const-string v2, "session_cookie_exchange_started_at_tap"

    .line 3
    .line 4
    iget-wide v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;->$startedAtNs:J

    .line 5
    .line 6
    invoke-static {v3, v2, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->access$recordInitialLoadPhase(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;Ljava/lang/String;J)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method
