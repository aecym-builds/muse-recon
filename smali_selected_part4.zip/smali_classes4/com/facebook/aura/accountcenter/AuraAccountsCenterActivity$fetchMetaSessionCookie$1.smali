.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "Ljava/lang/Long;",
        "Ljava/lang/String;",
        "Ljava/lang/Throwable;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $callback:LX/AYT;

.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;LX/AYT;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;->$callback:LX/AYT;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    check-cast p2, Ljava/lang/String;

    .line 5
    .line 6
    check-cast p3, Ljava/lang/Throwable;

    .line 7
    .line 8
    invoke-virtual {p0, v0, v1, p2, p3}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;->invoke(JLjava/lang/String;Ljava/lang/Throwable;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(JLjava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 268435457
    .line 268435458
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;

    .line 268435459
    .line 268435460
    invoke-direct {v0, v1, p1, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;J)V

    .line 268435461
    .line 268435462
    .line 268435463
    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 268435464
    .line 268435465
    .line 268435466
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$fetchMetaSessionCookie$1;->$callback:LX/AYT;

    .line 268435467
    .line 268435468
    if-eqz p4, :cond_0

    .line 268435469
    .line 268435470
    invoke-interface {v0, p4}, LX/AYT;->onFail(Ljava/lang/Throwable;)V

    .line 268435471
    .line 268435472
    .line 268435473
    return-void

    .line 268435474
    :cond_0
    invoke-interface {v0, p3}, LX/AYT;->onSuccess(Ljava/lang/String;)V

    .line 268435475
    .line 268435476
    .line 268435477
    return-void
.end method
