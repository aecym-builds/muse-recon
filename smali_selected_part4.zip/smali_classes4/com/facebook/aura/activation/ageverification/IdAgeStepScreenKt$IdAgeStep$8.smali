.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $picked:Z

.field public final synthetic $ui$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Z",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$picked:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$ui$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x4

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 7

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move-object v6, p3

    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    invoke-static {p3, p1}, LX/004;->A09(LX/2d4;F)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    or-int v1, p4, v0

    .line 10
    .line 11
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-static {p3, p2}, LX/004;->A0A(LX/2d4;F)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    or-int/2addr v1, v0

    .line 20
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0, p3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$ui$delegate:LX/16A;

    .line 31
    .line 32
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 37
    .line 38
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 39
    .line 40
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 41
    .line 42
    iget-boolean v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;->$picked:Z

    .line 43
    .line 44
    sget-object v1, LX/2sI;->A01:LX/2wD;

    .line 45
    .line 46
    const/4 v0, 0x0

    .line 47
    invoke-static {v1, v0, p1, v0, p2}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    sget v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->$stable:I

    .line 52
    .line 53
    shl-int/lit8 p0, v0, 0x3

    .line 54
    .line 55
    const/4 p1, 0x0

    .line 56
    invoke-static/range {v2 .. v8}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt;->IdAgeStepContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_1
    move v1, p4

    .line 61
    goto :goto_0

    .line 62
    :cond_2
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 63
    .line 64
    .line 65
    return-void
.end method
