.class public final Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SubmitOutcome;


# static fields
.field public static final $stable:I


# instance fields
.field public final failure:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

.field public final kind:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

.field public final result:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->kind:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->failure:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getFailure()Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->failure:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getKind()Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->kind:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getResult()Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 1
    .line 2
    return-object p0
.end method
