.class public abstract Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ID1_ASPECT_RATIO:F = 1.5857725f

.field public static final ID_FRAME_MARGIN:F = 16.0f

.field public static final PASSPORT_OPEN_ASPECT:F = 0.71022725f


# direct methods
.method public static final IdFrameOverlay(FZLX/3C1;LX/2d4;II)V
    .locals 12

    .line 0
    move-object v8, p2

    .line 1
    const v0, 0x19e0d11b

    .line 2
    .line 3
    .line 4
    move-object v3, p3

    .line 5
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v9, p4

    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    move v6, p0

    .line 13
    if-nez v0, :cond_8

    .line 14
    .line 15
    invoke-static {p3, p0}, LX/004;->A09(LX/2d4;F)I

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    or-int v4, v4, p4

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 22
    .line 23
    move v7, p1

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    invoke-static {p3, p1}, LX/004;->A0j(LX/2d4;Z)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    or-int/2addr v4, v0

    .line 31
    :cond_0
    move/from16 v10, p5

    .line 32
    .line 33
    and-int/lit8 v1, p5, 0x4

    .line 34
    .line 35
    if-eqz v1, :cond_7

    .line 36
    .line 37
    or-int/lit16 v4, v4, 0x180

    .line 38
    .line 39
    :cond_1
    :goto_1
    invoke-static {v4}, LX/005;->A1I(I)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    invoke-static {v0, p3, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_6

    .line 48
    .line 49
    if-eqz v1, :cond_2

    .line 50
    .line 51
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 52
    .line 53
    :cond_2
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 54
    .line 55
    const/4 v2, 0x6

    .line 56
    invoke-virtual {v5, p3, v2}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->surfaceOnMedia:J

    .line 61
    .line 62
    invoke-virtual {v5, p3, v2}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    iget-wide p1, v2, Lcom/facebook/aura/vds/compose/theme/AuraColors;->onMedia:J

    .line 67
    .line 68
    invoke-static {v4}, LX/008;->A1X(I)Z

    .line 69
    .line 70
    .line 71
    move-result v5

    .line 72
    invoke-interface {p3, v0, v1}, LX/2d4;->A68(J)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    or-int/2addr v5, v2

    .line 77
    invoke-interface {p3, p1, p2}, LX/2d4;->A68(J)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    or-int/2addr v5, v2

    .line 82
    invoke-static {v4}, LX/004;->A1S(I)Z

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    or-int/2addr v5, v2

    .line 87
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v11

    .line 91
    if-nez v5, :cond_3

    .line 92
    .line 93
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 94
    .line 95
    if-ne v11, v2, :cond_4

    .line 96
    .line 97
    :cond_3
    new-instance v11, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;

    .line 98
    .line 99
    move p3, v7

    .line 100
    move-wide/from16 p4, v0

    .line 101
    .line 102
    invoke-direct/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;-><init>(FJZJ)V

    .line 103
    .line 104
    .line 105
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    :cond_4
    check-cast v11, LX/JDM;

    .line 109
    .line 110
    shr-int/lit8 v0, v4, 0x6

    .line 111
    .line 112
    and-int/lit8 v0, v0, 0xe

    .line 113
    .line 114
    invoke-static {v8, v11, v3, v0}, LX/1vS;->A00(LX/3C1;LX/JDM;LX/2d4;I)V

    .line 115
    .line 116
    .line 117
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    if-eqz v0, :cond_5

    .line 122
    .line 123
    new-instance v5, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$2;

    .line 124
    .line 125
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$2;-><init>(FZLX/3C1;II)V

    .line 126
    .line 127
    .line 128
    iput-object v5, v0, LX/J7V;->A06:LX/JDN;

    .line 129
    .line 130
    :cond_5
    return-void

    .line 131
    :cond_6
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 132
    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_7
    and-int/lit16 v0, v9, 0x180

    .line 136
    .line 137
    if-nez v0, :cond_1

    .line 138
    .line 139
    invoke-static {p3, p2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    or-int/2addr v4, v0

    .line 144
    goto :goto_1

    .line 145
    :cond_8
    move v4, v9

    .line 146
    goto :goto_0
.end method

.method public static final synthetic access$drawCornerBrackets-g2O1Hgs(LX/2la;LX/36Z;FJ)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->drawCornerBrackets-g2O1Hgs(LX/2la;LX/36Z;FJ)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$drawFold-mxwnekA(LX/2la;LX/36Z;J)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->drawFold-mxwnekA(LX/2la;LX/36Z;J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final cropToFrame(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;F)Landroid/graphics/Bitmap;
    .locals 8

    .line 0
    invoke-static {p0, p1}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    iget v5, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    int-to-float v0, v0

    .line 11
    mul-float/2addr v5, v0

    .line 12
    iget v4, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    int-to-float v0, v0

    .line 19
    mul-float/2addr v4, v0

    .line 20
    iget v2, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 21
    .line 22
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    int-to-float v0, v0

    .line 27
    mul-float/2addr v2, v0

    .line 28
    iget v7, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 29
    .line 30
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    int-to-float v0, v0

    .line 35
    mul-float/2addr v7, v0

    .line 36
    sub-float v1, v2, v5

    .line 37
    .line 38
    sub-float v0, v7, v4

    .line 39
    .line 40
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    mul-float/2addr v6, p2

    .line 45
    sub-float/2addr v5, v6

    .line 46
    float-to-int v1, v5

    .line 47
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    add-int/lit8 v0, v0, -0x1

    .line 52
    .line 53
    invoke-static {v1, v3, v0}, LX/34j;->A05(III)I

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    sub-float/2addr v4, v6

    .line 58
    float-to-int v1, v4

    .line 59
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    add-int/lit8 v0, v0, -0x1

    .line 64
    .line 65
    invoke-static {v1, v3, v0}, LX/34j;->A05(III)I

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    add-float/2addr v2, v6

    .line 70
    float-to-int v2, v2

    .line 71
    add-int/lit8 v1, v5, 0x1

    .line 72
    .line 73
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-static {v2, v1, v0}, LX/34j;->A05(III)I

    .line 78
    .line 79
    .line 80
    move-result v3

    .line 81
    add-float/2addr v7, v6

    .line 82
    float-to-int v2, v7

    .line 83
    add-int/lit8 v1, v4, 0x1

    .line 84
    .line 85
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    invoke-static {v2, v1, v0}, LX/34j;->A05(III)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    sub-int/2addr v3, v5

    .line 94
    sub-int/2addr v0, v4

    .line 95
    invoke-static {p0, v5, v4, v3, v0}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    return-object v0
.end method

.method public static final drawCornerBrackets-g2O1Hgs(LX/2la;LX/36Z;FJ)V
    .locals 44

    .line 0
    const/16 v26, 0x20

    .line 1
    .line 2
    const/high16 v1, 0x42000000    # 32.0f

    .line 3
    .line 4
    move-object/from16 v27, p0

    .line 5
    .line 6
    move-object/from16 v0, v27

    .line 7
    .line 8
    invoke-interface {v0, v1}, LX/34Y;->AhZ(F)F

    .line 9
    .line 10
    .line 11
    move-result v25

    .line 12
    const/high16 v1, 0x40800000    # 4.0f

    .line 13
    .line 14
    invoke-interface {v0, v1}, LX/34Y;->AhZ(F)F

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    const/16 v24, 0x1

    .line 19
    .line 20
    const/16 v28, 0x0

    .line 21
    .line 22
    const/4 v7, 0x0

    .line 23
    new-instance v23, LX/2RO;

    .line 24
    .line 25
    move-object/from16 v2, v23

    .line 26
    .line 27
    move-object/from16 v3, v28

    .line 28
    .line 29
    move v5, v1

    .line 30
    move/from16 v6, v24

    .line 31
    .line 32
    invoke-direct/range {v2 .. v7}, LX/2RO;-><init>(LX/2RU;FFII)V

    .line 33
    .line 34
    .line 35
    const/high16 v0, 0x40000000    # 2.0f

    .line 36
    .line 37
    mul-float v0, v0, p2

    .line 38
    .line 39
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    int-to-long v2, v0

    .line 44
    shl-long v14, v2, v26

    .line 45
    .line 46
    const-wide v0, 0xffffffffL

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    and-long/2addr v2, v0

    .line 52
    or-long/2addr v14, v2

    .line 53
    move-object/from16 v12, p1

    .line 54
    .line 55
    iget v2, v12, LX/36Z;->A01:F

    .line 56
    .line 57
    move/from16 p1, v2

    .line 58
    .line 59
    iget v2, v12, LX/36Z;->A03:F

    .line 60
    .line 61
    move/from16 p0, v2

    .line 62
    .line 63
    move/from16 v3, p1

    .line 64
    .line 65
    invoke-static {v3, v2}, LX/005;->A0F(FF)J

    .line 66
    .line 67
    .line 68
    move-result-wide v2

    .line 69
    new-instance v6, LX/2qg;

    .line 70
    .line 71
    invoke-direct {v6, v2, v3}, LX/2qg;-><init>(J)V

    .line 72
    .line 73
    .line 74
    const/high16 v2, 0x43340000    # 180.0f

    .line 75
    .line 76
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 77
    .line 78
    .line 79
    move-result-object v10

    .line 80
    const/high16 v2, 0x3f800000    # 1.0f

    .line 81
    .line 82
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    int-to-long v2, v2

    .line 87
    shl-long v8, v2, v26

    .line 88
    .line 89
    and-long/2addr v2, v0

    .line 90
    or-long v4, v8, v2

    .line 91
    .line 92
    new-instance v7, LX/2qg;

    .line 93
    .line 94
    invoke-direct {v7, v4, v5}, LX/2qg;-><init>(J)V

    .line 95
    .line 96
    .line 97
    new-instance v22, LX/IAg;

    .line 98
    .line 99
    move-object/from16 v4, v22

    .line 100
    .line 101
    invoke-direct {v4, v6, v10, v7}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    iget v4, v12, LX/36Z;->A02:F

    .line 105
    .line 106
    move/from16 v21, v4

    .line 107
    .line 108
    invoke-static {v14, v15}, LX/002;->A01(J)F

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    sub-float v4, v21, v4

    .line 113
    .line 114
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 115
    .line 116
    .line 117
    move-result v4

    .line 118
    int-to-long v6, v4

    .line 119
    invoke-static/range {p0 .. p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 120
    .line 121
    .line 122
    move-result v4

    .line 123
    int-to-long v4, v4

    .line 124
    shl-long v6, v6, v26

    .line 125
    .line 126
    and-long/2addr v4, v0

    .line 127
    or-long v10, v6, v4

    .line 128
    .line 129
    new-instance v13, LX/2qg;

    .line 130
    .line 131
    invoke-direct {v13, v10, v11}, LX/2qg;-><init>(J)V

    .line 132
    .line 133
    .line 134
    const/high16 v4, 0x43870000    # 270.0f

    .line 135
    .line 136
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 137
    .line 138
    .line 139
    move-result-object v11

    .line 140
    const/high16 v4, -0x40800000    # -1.0f

    .line 141
    .line 142
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    int-to-long v4, v4

    .line 147
    shl-long v19, v4, v26

    .line 148
    .line 149
    or-long v2, v2, v19

    .line 150
    .line 151
    new-instance v10, LX/2qg;

    .line 152
    .line 153
    invoke-direct {v10, v2, v3}, LX/2qg;-><init>(J)V

    .line 154
    .line 155
    .line 156
    new-instance v18, LX/IAg;

    .line 157
    .line 158
    move-object/from16 v2, v18

    .line 159
    .line 160
    invoke-direct {v2, v13, v11, v10}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    iget v2, v12, LX/36Z;->A00:F

    .line 164
    .line 165
    move/from16 v17, v2

    .line 166
    .line 167
    invoke-static {v14, v15, v0, v1}, LX/002;->A02(JJ)F

    .line 168
    .line 169
    .line 170
    move-result v2

    .line 171
    sub-float v2, v17, v2

    .line 172
    .line 173
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    int-to-long v2, v2

    .line 178
    and-long/2addr v2, v0

    .line 179
    or-long v10, v2, v6

    .line 180
    .line 181
    new-instance v12, LX/2qg;

    .line 182
    .line 183
    invoke-direct {v12, v10, v11}, LX/2qg;-><init>(J)V

    .line 184
    .line 185
    .line 186
    const/16 v16, 0x0

    .line 187
    .line 188
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 189
    .line 190
    .line 191
    move-result-object v13

    .line 192
    and-long/2addr v4, v0

    .line 193
    or-long v6, v4, v19

    .line 194
    .line 195
    new-instance v11, LX/2qg;

    .line 196
    .line 197
    invoke-direct {v11, v6, v7}, LX/2qg;-><init>(J)V

    .line 198
    .line 199
    .line 200
    new-instance v10, LX/IAg;

    .line 201
    .line 202
    invoke-direct {v10, v12, v13, v11}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 203
    .line 204
    .line 205
    invoke-static/range {p1 .. p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 206
    .line 207
    .line 208
    move-result v6

    .line 209
    int-to-long v6, v6

    .line 210
    shl-long v6, v6, v26

    .line 211
    .line 212
    or-long/2addr v2, v6

    .line 213
    new-instance v7, LX/2qg;

    .line 214
    .line 215
    invoke-direct {v7, v2, v3}, LX/2qg;-><init>(J)V

    .line 216
    .line 217
    .line 218
    const/high16 v6, 0x42b40000    # 90.0f

    .line 219
    .line 220
    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 221
    .line 222
    .line 223
    move-result-object v3

    .line 224
    or-long/2addr v8, v4

    .line 225
    new-instance v2, LX/2qg;

    .line 226
    .line 227
    invoke-direct {v2, v8, v9}, LX/2qg;-><init>(J)V

    .line 228
    .line 229
    .line 230
    new-instance v4, LX/IAg;

    .line 231
    .line 232
    invoke-direct {v4, v7, v3, v2}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    const/16 v33, 0x3

    .line 236
    .line 237
    move-object/from16 v3, v22

    .line 238
    .line 239
    move-object/from16 v2, v18

    .line 240
    .line 241
    filled-new-array {v3, v2, v10, v4}, [LX/IAg;

    .line 242
    .line 243
    .line 244
    move-result-object v2

    .line 245
    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 246
    .line 247
    .line 248
    move-result-object v2

    .line 249
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 250
    .line 251
    .line 252
    move-result-object v11

    .line 253
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 254
    .line 255
    .line 256
    move-result v2

    .line 257
    if-eqz v2, :cond_2

    .line 258
    .line 259
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v5

    .line 263
    check-cast v5, LX/IAg;

    .line 264
    .line 265
    iget-object v2, v5, LX/IAg;->first:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast v2, LX/2qg;

    .line 268
    .line 269
    iget-wide v2, v2, LX/2qg;->A00:J

    .line 270
    .line 271
    iget-object v4, v5, LX/IAg;->second:Ljava/lang/Object;

    .line 272
    .line 273
    check-cast v4, Ljava/lang/Number;

    .line 274
    .line 275
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 276
    .line 277
    .line 278
    move-result v8

    .line 279
    iget-object v4, v5, LX/IAg;->third:Ljava/lang/Object;

    .line 280
    .line 281
    check-cast v4, LX/2qg;

    .line 282
    .line 283
    iget-wide v4, v4, LX/2qg;->A00:J

    .line 284
    .line 285
    invoke-static {}, LX/2ak;->A00()LX/2bQ;

    .line 286
    .line 287
    .line 288
    move-result-object v7

    .line 289
    invoke-static {v2, v3, v14, v15}, LX/3PU;->A01(JJ)LX/36Z;

    .line 290
    .line 291
    .line 292
    move-result-object v3

    .line 293
    move/from16 v2, v24

    .line 294
    .line 295
    invoke-virtual {v7, v3, v8, v6, v2}, LX/2bQ;->A4l(LX/36Z;FFZ)V

    .line 296
    .line 297
    .line 298
    const/high16 v31, 0x3f800000    # 1.0f

    .line 299
    .line 300
    move-wide/from16 v34, p3

    .line 301
    .line 302
    move-object/from16 v36, v27

    .line 303
    .line 304
    move-object/from16 v37, v28

    .line 305
    .line 306
    move-object/from16 v38, v7

    .line 307
    .line 308
    move-object/from16 v39, v23

    .line 309
    .line 310
    move/from16 v40, v31

    .line 311
    .line 312
    move/from16 v41, v33

    .line 313
    .line 314
    move-wide/from16 v42, v34

    .line 315
    .line 316
    invoke-interface/range {v36 .. v43}, LX/2la;->A9i(LX/2hc;LX/2lV;LX/2Qt;FIJ)V

    .line 317
    .line 318
    .line 319
    invoke-static {v4, v5}, LX/002;->A01(J)F

    .line 320
    .line 321
    .line 322
    move-result v10

    .line 323
    cmpl-float v2, v10, v16

    .line 324
    .line 325
    move/from16 v8, v21

    .line 326
    .line 327
    if-lez v2, :cond_0

    .line 328
    .line 329
    move/from16 v8, p1

    .line 330
    .line 331
    :cond_0
    invoke-static {v4, v5, v0, v1}, LX/002;->A02(JJ)F

    .line 332
    .line 333
    .line 334
    move-result v7

    .line 335
    cmpl-float v3, v7, v16

    .line 336
    .line 337
    move/from16 v2, v17

    .line 338
    .line 339
    if-lez v3, :cond_1

    .line 340
    .line 341
    move/from16 v2, p0

    .line 342
    .line 343
    :cond_1
    invoke-static {v8, v2}, LX/005;->A0H(FF)J

    .line 344
    .line 345
    .line 346
    move-result-wide v2

    .line 347
    invoke-static {v2, v3}, LX/002;->A01(J)F

    .line 348
    .line 349
    .line 350
    move-result v9

    .line 351
    invoke-static {v2, v3, v0, v1}, LX/002;->A02(JJ)F

    .line 352
    .line 353
    .line 354
    move-result v8

    .line 355
    mul-float v2, v7, p2

    .line 356
    .line 357
    add-float v4, v8, v2

    .line 358
    .line 359
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 360
    .line 361
    .line 362
    move-result v2

    .line 363
    int-to-long v2, v2

    .line 364
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 365
    .line 366
    .line 367
    move-result v4

    .line 368
    int-to-long v4, v4

    .line 369
    shl-long v2, v2, v26

    .line 370
    .line 371
    and-long/2addr v4, v0

    .line 372
    or-long v36, v2, v4

    .line 373
    .line 374
    mul-float v7, v7, v25

    .line 375
    .line 376
    add-float v4, v8, v7

    .line 377
    .line 378
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 379
    .line 380
    .line 381
    move-result v4

    .line 382
    int-to-long v4, v4

    .line 383
    and-long/2addr v4, v0

    .line 384
    or-long/2addr v2, v4

    .line 385
    move-object/from16 v4, v23

    .line 386
    .line 387
    iget v7, v4, LX/2RO;->A01:F

    .line 388
    .line 389
    move-object/from16 v29, v28

    .line 390
    .line 391
    move/from16 v30, v7

    .line 392
    .line 393
    move/from16 v32, v24

    .line 394
    .line 395
    move-wide/from16 v38, v2

    .line 396
    .line 397
    invoke-interface/range {v27 .. v39}, LX/2la;->A9c(LX/2hc;LX/2RU;FFIIJJJ)V

    .line 398
    .line 399
    .line 400
    mul-float v2, v10, p2

    .line 401
    .line 402
    add-float/2addr v2, v9

    .line 403
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 404
    .line 405
    .line 406
    move-result v2

    .line 407
    int-to-long v4, v2

    .line 408
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 409
    .line 410
    .line 411
    move-result v2

    .line 412
    int-to-long v2, v2

    .line 413
    shl-long v4, v4, v26

    .line 414
    .line 415
    and-long/2addr v2, v0

    .line 416
    or-long v36, v2, v4

    .line 417
    .line 418
    mul-float v10, v10, v25

    .line 419
    .line 420
    add-float/2addr v9, v10

    .line 421
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 422
    .line 423
    .line 424
    move-result v4

    .line 425
    int-to-long v4, v4

    .line 426
    shl-long v4, v4, v26

    .line 427
    .line 428
    or-long/2addr v2, v4

    .line 429
    move-wide/from16 v38, v2

    .line 430
    .line 431
    invoke-interface/range {v27 .. v39}, LX/2la;->A9c(LX/2hc;LX/2RU;FFIIJJJ)V

    .line 432
    .line 433
    .line 434
    goto/16 :goto_0

    .line 435
    .line 436
    :cond_2
    return-void
.end method

.method public static final drawFold-mxwnekA(LX/2la;LX/36Z;J)V
    .locals 19

    .line 0
    const/high16 v0, 0x41000000    # 8.0f

    .line 1
    .line 2
    move-object/from16 v10, p0

    .line 3
    .line 4
    invoke-interface {v10, v0}, LX/34Y;->AhZ(F)F

    .line 5
    .line 6
    .line 7
    move-result v9

    .line 8
    move-object/from16 v8, p1

    .line 9
    .line 10
    iget v3, v8, LX/36Z;->A01:F

    .line 11
    .line 12
    const/high16 v7, 0x41800000    # 16.0f

    .line 13
    .line 14
    invoke-interface {v10, v7}, LX/34Y;->AhZ(F)F

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-float/2addr v3, v0

    .line 19
    invoke-virtual {v8}, LX/36Z;->A01()J

    .line 20
    .line 21
    .line 22
    move-result-wide v0

    .line 23
    const-wide v5, 0xffffffffL

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    invoke-static {v0, v1, v5, v6}, LX/002;->A02(JJ)F

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    int-to-long v0, v0

    .line 37
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    int-to-long v2, v2

    .line 42
    const/16 v4, 0x20

    .line 43
    .line 44
    shl-long/2addr v0, v4

    .line 45
    and-long/2addr v2, v5

    .line 46
    or-long p0, v2, v0

    .line 47
    .line 48
    iget v1, v8, LX/36Z;->A02:F

    .line 49
    .line 50
    invoke-interface {v10, v7}, LX/34Y;->AhZ(F)F

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    sub-float/2addr v1, v0

    .line 55
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    int-to-long v0, v0

    .line 60
    shl-long/2addr v0, v4

    .line 61
    or-long/2addr v0, v2

    .line 62
    const/4 v3, 0x2

    .line 63
    const/high16 v2, 0x40000000    # 2.0f

    .line 64
    .line 65
    invoke-interface {v10, v2}, LX/34Y;->AhZ(F)F

    .line 66
    .line 67
    .line 68
    move-result v13

    .line 69
    const/4 v15, 0x1

    .line 70
    new-array v4, v3, [F

    .line 71
    .line 72
    const/4 v2, 0x0

    .line 73
    aput v9, v4, v2

    .line 74
    .line 75
    aput v9, v4, v15

    .line 76
    .line 77
    const/4 v11, 0x0

    .line 78
    const/4 v3, 0x0

    .line 79
    new-instance v2, Landroid/graphics/DashPathEffect;

    .line 80
    .line 81
    invoke-direct {v2, v4, v3}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    .line 82
    .line 83
    .line 84
    new-instance v12, LX/2RT;

    .line 85
    .line 86
    invoke-direct {v12, v2}, LX/2RT;-><init>(Landroid/graphics/PathEffect;)V

    .line 87
    .line 88
    .line 89
    const/high16 v14, 0x3f800000    # 1.0f

    .line 90
    .line 91
    const/16 v16, 0x3

    .line 92
    .line 93
    move-wide/from16 v17, p2

    .line 94
    .line 95
    move-wide/from16 p2, v0

    .line 96
    .line 97
    invoke-interface/range {v10 .. v22}, LX/2la;->A9c(LX/2hc;LX/2RU;FFIIJJJ)V

    .line 98
    .line 99
    .line 100
    return-void
.end method

.method public static final getID_FRAME_MARGIN()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->ID_FRAME_MARGIN:F

    .line 1
    .line 2
    return v0
.end method

.method public static final idFrameRect-Pq9zytI(JFF)LX/36Z;
    .locals 6

    .line 0
    invoke-static {p0, p1}, LX/004;->A03(J)F

    .line 1
    .line 2
    .line 3
    move-result v5

    .line 4
    const/high16 v4, 0x40000000    # 2.0f

    .line 5
    .line 6
    mul-float v0, v4, p2

    .line 7
    .line 8
    sub-float v1, v5, v0

    .line 9
    .line 10
    invoke-static {p0, p1}, LX/004;->A02(J)F

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    const/high16 v0, 0x40c00000    # 6.0f

    .line 15
    .line 16
    mul-float/2addr v0, p2

    .line 17
    sub-float v0, v3, v0

    .line 18
    .line 19
    mul-float/2addr v0, p3

    .line 20
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    div-float v1, v2, p3

    .line 25
    .line 26
    sub-float/2addr v5, v2

    .line 27
    div-float/2addr v5, v4

    .line 28
    sub-float/2addr v3, v1

    .line 29
    div-float/2addr v3, v4

    .line 30
    add-float/2addr v2, v5

    .line 31
    add-float/2addr v1, v3

    .line 32
    new-instance v0, LX/36Z;

    .line 33
    .line 34
    invoke-direct {v0, v5, v3, v2, v1}, LX/36Z;-><init>(FFFF)V

    .line 35
    .line 36
    .line 37
    return-object v0
.end method

.method public static final normalizedIn-d16Qtg0(LX/36Z;J)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget v4, p0, LX/36Z;->A01:F

    .line 5
    .line 6
    invoke-static {p1, p2}, LX/004;->A03(J)F

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    div-float/2addr v4, v1

    .line 11
    iget v3, p0, LX/36Z;->A03:F

    .line 12
    .line 13
    invoke-static {p1, p2}, LX/004;->A02(J)F

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    div-float/2addr v3, v0

    .line 18
    iget v2, p0, LX/36Z;->A02:F

    .line 19
    .line 20
    div-float/2addr v2, v1

    .line 21
    iget v1, p0, LX/36Z;->A00:F

    .line 22
    .line 23
    div-float/2addr v1, v0

    .line 24
    new-instance v0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 25
    .line 26
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/NormalizedRect;-><init>(FFFF)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method

.method public static final normalizedInSquare-d16Qtg0(LX/36Z;J)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1, p2}, LX/004;->A03(J)F

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    invoke-static {p1, p2}, LX/004;->A02(J)F

    .line 9
    .line 10
    .line 11
    move-result v6

    .line 12
    invoke-static {v1, v6}, Ljava/lang/Math;->min(FF)F

    .line 13
    .line 14
    .line 15
    move-result v5

    .line 16
    sub-float/2addr v1, v5

    .line 17
    const/high16 v0, 0x40000000    # 2.0f

    .line 18
    .line 19
    div-float/2addr v1, v0

    .line 20
    sub-float/2addr v6, v5

    .line 21
    div-float/2addr v6, v0

    .line 22
    iget v4, p0, LX/36Z;->A01:F

    .line 23
    .line 24
    sub-float/2addr v4, v1

    .line 25
    div-float/2addr v4, v5

    .line 26
    iget v3, p0, LX/36Z;->A03:F

    .line 27
    .line 28
    sub-float/2addr v3, v6

    .line 29
    div-float/2addr v3, v5

    .line 30
    iget v2, p0, LX/36Z;->A02:F

    .line 31
    .line 32
    sub-float/2addr v2, v1

    .line 33
    div-float/2addr v2, v5

    .line 34
    iget v1, p0, LX/36Z;->A00:F

    .line 35
    .line 36
    sub-float/2addr v1, v6

    .line 37
    div-float/2addr v1, v5

    .line 38
    new-instance v0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 39
    .line 40
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/NormalizedRect;-><init>(FFFF)V

    .line 41
    .line 42
    .line 43
    return-object v0
.end method
