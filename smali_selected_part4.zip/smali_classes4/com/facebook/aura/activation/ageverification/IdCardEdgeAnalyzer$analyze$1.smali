.class public final Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $edges:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;->$edges:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->onFrame:LX/JDM;

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;->$edges:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 5
    .line 6
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method
