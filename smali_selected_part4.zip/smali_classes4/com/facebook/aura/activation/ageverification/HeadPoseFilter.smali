.class public final Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public pitch:Ljava/lang/Float;

.field public yaw:Ljava/lang/Float;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final correct(FF)F
    .locals 1

    .line 0
    add-float/2addr p1, p2

    .line 1
    const/high16 p0, -0x41000000    # -0.5f

    .line 2
    .line 3
    const/high16 v0, 0x3f000000    # 0.5f

    .line 4
    .line 5
    invoke-static {p1, p0, v0}, LX/34j;->A04(FFF)F

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    const v0, 0x3c9f49f5

    .line 14
    .line 15
    .line 16
    cmpg-float v0, p0, v0

    .line 17
    .line 18
    if-gtz v0, :cond_0

    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    :cond_0
    return p1
.end method

.method private final normalize(F)F
    .locals 1

    .line 0
    const/high16 p0, -0x3d4c0000    # -90.0f

    .line 1
    .line 2
    const/high16 v0, 0x42b40000    # 90.0f

    .line 3
    .line 4
    invoke-static {p1, p0, v0}, LX/34j;->A04(FFF)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    const/high16 v0, 0x43340000    # 180.0f

    .line 9
    .line 10
    div-float/2addr p0, v0

    .line 11
    return p0
.end method

.method private final smooth(Ljava/lang/Float;F)F
    .locals 1

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    return p2

    .line 3
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    sub-float/2addr p2, p1

    .line 8
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    const v0, 0x3d23d70a    # 0.04f

    .line 13
    .line 14
    .line 15
    cmpl-float p0, p0, v0

    .line 16
    .line 17
    const v0, 0x3eb33333    # 0.35f

    .line 18
    .line 19
    .line 20
    if-ltz p0, :cond_1

    .line 21
    .line 22
    const v0, 0x3f4ccccd    # 0.8f

    .line 23
    .line 24
    .line 25
    :cond_1
    mul-float/2addr v0, p2

    .line 26
    add-float/2addr p1, v0

    .line 27
    return p1
.end method


# virtual methods
.method public final filter(Lcom/facebook/aura/activation/ageverification/NormalizedFace;)Lcom/facebook/aura/activation/ageverification/HeadPose;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->yaw:Ljava/lang/Float;

    .line 5
    .line 6
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->yawDegrees:F

    .line 7
    .line 8
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->normalize(F)F

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const v0, 0x3bb60b61

    .line 13
    .line 14
    .line 15
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->correct(FF)F

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->smooth(Ljava/lang/Float;F)F

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->pitch:Ljava/lang/Float;

    .line 24
    .line 25
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->pitchDegrees:F

    .line 26
    .line 27
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->normalize(F)F

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->correct(FF)F

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->smooth(Ljava/lang/Float;F)F

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->yaw:Ljava/lang/Float;

    .line 45
    .line 46
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->pitch:Ljava/lang/Float;

    .line 51
    .line 52
    new-instance v0, Lcom/facebook/aura/activation/ageverification/HeadPose;

    .line 53
    .line 54
    invoke-direct {v0, v3, v1}, Lcom/facebook/aura/activation/ageverification/HeadPose;-><init>(FF)V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method

.method public final reset()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->yaw:Ljava/lang/Float;

    .line 2
    .line 3
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPoseFilter;->pitch:Ljava/lang/Float;

    .line 4
    .line 5
    return-void
.end method
