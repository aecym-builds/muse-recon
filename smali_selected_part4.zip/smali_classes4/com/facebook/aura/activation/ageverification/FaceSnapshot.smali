.class public final Lcom/facebook/aura/activation/ageverification/FaceSnapshot;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final face:Landroid/graphics/Rect;

.field public final height:I

.field public final nv21:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "[B>;"
        }
    .end annotation
.end field

.field public final penalty:F

.field public final rotationDegrees:I

.field public final width:I


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Future;IIILandroid/graphics/Rect;F)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "[B>;III",
            "Landroid/graphics/Rect;",
            "F)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0, p5}, LX/003;->A0z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->nv21:Ljava/util/concurrent/Future;

    .line 8
    .line 9
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->width:I

    .line 10
    .line 11
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->height:I

    .line 12
    .line 13
    iput p4, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->rotationDegrees:I

    .line 14
    .line 15
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->face:Landroid/graphics/Rect;

    .line 16
    .line 17
    iput p6, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->penalty:F

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final getPenalty()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->penalty:F

    .line 1
    .line 2
    return p0
.end method

.method public final isReady()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->nv21:Ljava/util/concurrent/Future;

    .line 1
    .line 2
    invoke-interface {p0}, Ljava/util/concurrent/Future;->isDone()Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public final writeJpeg(Ljava/io/File;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 12

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    .line 5
    .line 6
    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->nv21:Ljava/util/concurrent/Future;

    .line 10
    .line 11
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v7

    .line 15
    check-cast v7, [B

    .line 16
    .line 17
    iget v9, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->width:I

    .line 18
    .line 19
    iget v10, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->height:I

    .line 20
    .line 21
    const/4 v11, 0x0

    .line 22
    const/16 v8, 0x11

    .line 23
    .line 24
    new-instance v6, Landroid/graphics/YuvImage;

    .line 25
    .line 26
    invoke-direct/range {v6 .. v11}, Landroid/graphics/YuvImage;-><init>([BIII[I)V

    .line 27
    .line 28
    .line 29
    iget v2, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->width:I

    .line 30
    .line 31
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->height:I

    .line 32
    .line 33
    new-instance v1, Landroid/graphics/Rect;

    .line 34
    .line 35
    invoke-direct {v1, v5, v5, v2, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 36
    .line 37
    .line 38
    const/16 v0, 0x64

    .line 39
    .line 40
    invoke-virtual {v6, v1, v0, v3}, Landroid/graphics/YuvImage;->compressToJpeg(Landroid/graphics/Rect;ILjava/io/OutputStream;)Z

    .line 41
    .line 42
    .line 43
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    array-length v0, v1

    .line 48
    invoke-static {v1, v5, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    if-eqz v4, :cond_2

    .line 53
    .line 54
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    .line 59
    .line 60
    .line 61
    move-result v8

    .line 62
    new-instance v9, Landroid/graphics/Matrix;

    .line 63
    .line 64
    invoke-direct {v9}, Landroid/graphics/Matrix;-><init>()V

    .line 65
    .line 66
    .line 67
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->rotationDegrees:I

    .line 68
    .line 69
    int-to-float v0, v0

    .line 70
    invoke-virtual {v9, v0}, Landroid/graphics/Matrix;->postRotate(F)Z

    .line 71
    .line 72
    .line 73
    const/4 v10, 0x1

    .line 74
    move v6, v5

    .line 75
    invoke-static/range {v4 .. v10}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    invoke-static {v3}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    if-eq v3, v4, :cond_0

    .line 83
    .line 84
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    .line 85
    .line 86
    .line 87
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->face:Landroid/graphics/Rect;

    .line 88
    .line 89
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/SelfieSnapshotKt;->normalizedFace(Landroid/graphics/Rect;)Landroid/graphics/Rect;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    invoke-virtual {v2, v5, v5, v1, v0}, Landroid/graphics/Rect;->intersect(IIII)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-eqz v0, :cond_1

    .line 106
    .line 107
    invoke-virtual {v2}, Landroid/graphics/Rect;->isEmpty()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-nez v0, :cond_1

    .line 112
    .line 113
    invoke-static {v3, v2}, Lcom/facebook/aura/activation/ageverification/SelfieSnapshotKt;->scaledToShortSide(Landroid/graphics/Bitmap;Landroid/graphics/Rect;)Landroid/graphics/Bitmap;

    .line 114
    .line 115
    .line 116
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 117
    :try_start_1
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 118
    .line 119
    const/16 v0, 0x5f

    .line 120
    .line 121
    invoke-virtual {v1, v2, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->writeJpeg(Landroid/graphics/Bitmap;Ljava/io/File;I)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 122
    .line 123
    .line 124
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 125
    :try_start_2
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 126
    .line 127
    .line 128
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    .line 129
    .line 130
    .line 131
    return-object v0

    .line 132
    :catchall_0
    move-exception v1

    .line 133
    goto :goto_0

    .line 134
    :cond_1
    :try_start_3
    const-string v0, "The face is outside the selfie frame"

    .line 135
    .line 136
    new-instance v1, Ljava/io/IOException;

    .line 137
    .line 138
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    goto :goto_1

    .line 142
    :goto_0
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 143
    .line 144
    .line 145
    :goto_1
    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 146
    :catchall_1
    move-exception v0

    .line 147
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    .line 148
    .line 149
    .line 150
    throw v0

    .line 151
    :cond_2
    const-string v1, "Could not decode the selfie frame"

    .line 152
    .line 153
    new-instance v0, Ljava/io/IOException;

    .line 154
    .line 155
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    throw v0
.end method
