.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

.field public static final TAG:Ljava/lang/String; = "FaceDetectionModule"

.field public static final moduleLoad:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/ageverification/ModuleLoad;",
            ">;"
        }
    .end annotation
.end field

.field public static volatile source:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 6
    .line 7
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->NOT_LOADED:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 11
    .line 12
    invoke-direct {v1, v2, v0, v0}, Lcom/facebook/aura/activation/ageverification/ModuleLoad;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;IZ)V

    .line 13
    .line 14
    .line 15
    new-instance v0, LX/Ddv;

    .line 16
    .line 17
    invoke-direct {v0, v1}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;->INSTALLED:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 23
    .line 24
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->source:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 25
    .line 26
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getModuleLoad$p()LX/2J2;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$prepareEngine(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;Landroid/content/Context;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->prepareEngine(Landroid/content/Context;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$setSource$p(Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;)V
    .locals 0

    .line 0
    sput-object p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->source:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$settle(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getCanRetry(Lcom/facebook/aura/activation/ageverification/ModuleLoad;)Z
    .locals 2

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 3
    .line 4
    if-ne v1, v0, :cond_0

    .line 5
    .line 6
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->downloadFailed:Z

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->isUnsupportedApi()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    sget-object v1, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 17
    .line 18
    const-string v0, "mlkit_face_detection"

    .line 19
    .line 20
    invoke-virtual {v1, v0}, Lcom/facebook/aura/appmodules/AuraAppModules;->isObtainable(Ljava/lang/String;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/4 v0, 0x1

    .line 25
    if-nez v1, :cond_1

    .line 26
    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :cond_1
    return v0
.end method

.method private final isUnsupportedApi()Z
    .locals 1

    .line 0
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1
    .line 2
    const/16 v0, 0x1e

    .line 3
    .line 4
    if-ge p0, v0, :cond_0

    .line 5
    .line 6
    sget-object p0, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 7
    .line 8
    const-string v0, "mlkit_face_detection"

    .line 9
    .line 10
    invoke-virtual {p0, v0}, Lcom/facebook/aura/appmodules/AuraAppModules;->isDeclared(Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    const/4 v0, 0x1

    .line 15
    if-nez p0, :cond_1

    .line 16
    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :cond_1
    return v0
.end method

.method private final prepareEngine(Landroid/content/Context;I)V
    .locals 3

    .line 0
    const-string v2, "FaceDetectionModule"

    .line 1
    .line 2
    :try_start_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModelAssets;->ensureAvailable(Landroid/content/Context;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionEngine;->load(Landroid/content/Context;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    :catchall_0
    move-exception v1

    .line 20
    const-string v0, "Failed to prepare the engine"

    .line 21
    .line 22
    invoke-static {v2, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    const-string v0, "Face detection unavailable: init_failed"

    .line 26
    .line 27
    invoke-static {v2, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :goto_0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->READY:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 34
    .line 35
    :goto_1
    const/4 v0, 0x0

    .line 36
    invoke-direct {p0, p2, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method private final settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V
    .locals 3

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 1
    .line 2
    invoke-interface {p0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 7
    .line 8
    iget v0, v2, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->request:I

    .line 9
    .line 10
    if-ne v0, p1, :cond_0

    .line 11
    .line 12
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->LOADING:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 15
    .line 16
    if-ne v1, v0, :cond_0

    .line 17
    .line 18
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 19
    .line 20
    invoke-direct {v0, p2, p1, p3}, Lcom/facebook/aura/activation/ageverification/ModuleLoad;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;IZ)V

    .line 21
    .line 22
    .line 23
    invoke-static {p0, v2, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public static synthetic settle$default(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;ZILjava/lang/Object;)V
    .locals 1

    .line 0
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final startRequest()Ljava/lang/Integer;
    .locals 6

    .line 0
    :cond_0
    sget-object v5, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 7
    .line 8
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->NOT_LOADED:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 11
    .line 12
    if-eq v1, v0, :cond_1

    .line 13
    .line 14
    invoke-direct {p0, v4}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->getCanRetry(Lcom/facebook/aura/activation/ageverification/ModuleLoad;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    return-object v0

    .line 22
    :cond_1
    sget-object v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->LOADING:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 23
    .line 24
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->request:I

    .line 25
    .line 26
    add-int/lit8 v2, v0, 0x1

    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 30
    .line 31
    invoke-direct {v1, v3, v2, v0}, Lcom/facebook/aura/activation/ageverification/ModuleLoad;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;IZ)V

    .line 32
    .line 33
    .line 34
    check-cast v5, LX/Ddv;

    .line 35
    .line 36
    invoke-static {v4, v1, v5}, LX/Ddv;->A00(Ljava/lang/Object;Ljava/lang/Object;LX/Ddv;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget v0, v1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->request:I

    .line 43
    .line 44
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0
.end method


# virtual methods
.method public final awaitMode(Landroid/content/Context;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieMode;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->label:I

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-ne v0, v1, :cond_7

    .line 28
    .line 29
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 33
    .line 34
    if-nez v5, :cond_1

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 37
    .line 38
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 43
    .line 44
    :cond_1
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 45
    .line 46
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->LOADING:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 47
    .line 48
    if-ne v1, v0, :cond_4

    .line 49
    .line 50
    sget-object v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 51
    .line 52
    sget-object v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->NOT_LOADED:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 53
    .line 54
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->request:I

    .line 55
    .line 56
    iget-boolean v1, v5, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->downloadFailed:Z

    .line 57
    .line 58
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 59
    .line 60
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/ModuleLoad;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;IZ)V

    .line 61
    .line 62
    .line 63
    check-cast v4, LX/Ddv;

    .line 64
    .line 65
    invoke-static {v5, v0, v4}, LX/Ddv;->A00(Ljava/lang/Object;Ljava/lang/Object;LX/Ddv;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_4

    .line 70
    .line 71
    const-string v1, "FaceDetectionModule"

    .line 72
    .line 73
    const-string v0, "Face detection module wait timed out after 120000ms"

    .line 74
    .line 75
    invoke-static {v1, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    sget-object v3, Lcom/facebook/aura/activation/ageverification/SelfieMode;->RETRY:Lcom/facebook/aura/activation/ageverification/SelfieMode;

    .line 79
    .line 80
    return-object v3

    .line 81
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->load(Landroid/content/Context;)V

    .line 85
    .line 86
    .line 87
    const/4 v0, 0x0

    .line 88
    new-instance v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;

    .line 89
    .line 90
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;-><init>(LX/2M4;)V

    .line 91
    .line 92
    .line 93
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->L$0:Ljava/lang/Object;

    .line 94
    .line 95
    iput v1, v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;->label:I

    .line 96
    .line 97
    const-wide/32 v0, 0x1d4c0

    .line 98
    .line 99
    .line 100
    invoke-static {v4, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    if-ne v5, v3, :cond_0

    .line 105
    .line 106
    return-object v3

    .line 107
    :cond_3
    new-instance v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;

    .line 108
    .line 109
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$1;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;LX/2M4;)V

    .line 110
    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 114
    .line 115
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 120
    .line 121
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 122
    .line 123
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->READY:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 124
    .line 125
    if-ne v1, v0, :cond_5

    .line 126
    .line 127
    sget-object v3, Lcom/facebook/aura/activation/ageverification/SelfieMode;->GUIDED:Lcom/facebook/aura/activation/ageverification/SelfieMode;

    .line 128
    .line 129
    return-object v3

    .line 130
    :cond_5
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->getCanRetry(Lcom/facebook/aura/activation/ageverification/ModuleLoad;)Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-eqz v0, :cond_6

    .line 135
    .line 136
    sget-object v3, Lcom/facebook/aura/activation/ageverification/SelfieMode;->RETRY:Lcom/facebook/aura/activation/ageverification/SelfieMode;

    .line 137
    .line 138
    return-object v3

    .line 139
    :cond_6
    sget-object v3, Lcom/facebook/aura/activation/ageverification/SelfieMode;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/SelfieMode;

    .line 140
    .line 141
    return-object v3

    .line 142
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    throw v0
.end method

.method public final getSource()Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->source:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 1
    .line 2
    return-object p0
.end method

.method public final load(Landroid/content/Context;)V
    .locals 8

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->isUnsupportedApi()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const-string v7, "FaceDetectionModule"

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    const-string v0, "Face detection unavailable: api29"

    .line 13
    .line 14
    invoke-static {v7, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 18
    .line 19
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 20
    .line 21
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 22
    .line 23
    invoke-direct {v0, v1, v5, v5}, Lcom/facebook/aura/activation/ageverification/ModuleLoad;-><init>(Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;IZ)V

    .line 24
    .line 25
    .line 26
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void

    .line 30
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->startRequest()Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 41
    .line 42
    .line 43
    move-result-object v6

    .line 44
    sget-object v2, Lcom/facebook/aura/appmodules/AuraAppModules;->INSTANCE:Lcom/facebook/aura/appmodules/AuraAppModules;

    .line 45
    .line 46
    const-string v1, "mlkit_face_detection"

    .line 47
    .line 48
    invoke-virtual {v2, v1}, Lcom/facebook/aura/appmodules/AuraAppModules;->isDeclared(Ljava/lang/String;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_2

    .line 53
    .line 54
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 55
    .line 56
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;

    .line 61
    .line 62
    invoke-direct {v0, v6, v4}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;-><init>(Landroid/content/Context;I)V

    .line 63
    .line 64
    .line 65
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_2
    invoke-virtual {v2, v1}, Lcom/facebook/aura/appmodules/AuraAppModules;->isObtainable(Ljava/lang/String;)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-nez v0, :cond_3

    .line 74
    .line 75
    const-string v0, "Face detection unavailable: not_obtainable"

    .line 76
    .line 77
    invoke-static {v7, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 81
    .line 82
    invoke-direct {p0, v4, v0, v5}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :cond_3
    invoke-virtual {v2, v1}, Lcom/facebook/aura/appmodules/AuraAppModules;->isInstalled(Ljava/lang/String;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_4

    .line 91
    .line 92
    sget-object v3, LX/H0T;->A04:LX/H0T;

    .line 93
    .line 94
    goto :goto_0

    .line 95
    :cond_4
    sget-object v3, LX/H0T;->A03:LX/H0T;

    .line 96
    .line 97
    :goto_0
    :try_start_0
    invoke-virtual {v2}, Lcom/facebook/aura/appmodules/AuraAppModules;->getManager()LX/H0H;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    filled-new-array {v1}, [Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    new-instance v0, LX/I53;

    .line 106
    .line 107
    invoke-direct {v0, v3, v1}, LX/I53;-><init>(LX/H0T;[Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v2, v0}, LX/H0H;->A00(LX/I53;)LX/H0j;

    .line 111
    .line 112
    .line 113
    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 114
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 115
    .line 116
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;

    .line 121
    .line 122
    invoke-direct {v0, v3, v6, v4}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;-><init>(LX/H0T;Landroid/content/Context;I)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v2, v0, v1}, LX/H0g;->A05(LX/H10;Ljava/util/concurrent/Executor;)V

    .line 126
    .line 127
    .line 128
    return-void

    .line 129
    :catch_0
    move-exception v1

    .line 130
    const-string v0, "Face detection unavailable: request_failed "

    .line 131
    .line 132
    invoke-static {v0, v3}, LX/004;->A1E(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    invoke-static {v7, v0, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 137
    .line 138
    .line 139
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 140
    .line 141
    invoke-direct {p0, v4, v0, v5}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->settle(ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 142
    .line 143
    .line 144
    return-void
.end method
