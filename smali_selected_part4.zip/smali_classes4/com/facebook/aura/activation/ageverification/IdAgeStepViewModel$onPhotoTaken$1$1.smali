.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$onPhotoTaken$1$1"
    f = "IdAgeStepViewModel.kt"
    l = {
        0x121
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $bitmap:Landroid/graphics/Bitmap;

.field public final synthetic $capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

.field public final synthetic $frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

.field public final synthetic $launchJob:LX/Cbu;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;LX/Cbu;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Bitmap;",
            "LX/Cbu;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$launchJob:LX/Cbu;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$launchJob:LX/Cbu;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;-><init>(Landroid/graphics/Bitmap;LX/Cbu;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    throw v0

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    invoke-static {}, LX/602;->A11()LX/BqD;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 23
    .line 24
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 25
    .line 26
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 27
    .line 28
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 29
    .line 30
    const/4 v8, 0x0

    .line 31
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;

    .line 32
    .line 33
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->label:I

    .line 37
    .line 38
    invoke-static {p0, v0, v3}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-ne p1, v2, :cond_2

    .line 43
    .line 44
    return-object v2

    .line 45
    :goto_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2
    check-cast p1, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 51
    .line 52
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 53
    .line 54
    .line 55
    goto :goto_1

    .line 56
    :catch_0
    move-exception v2

    .line 57
    :try_start_1
    const-string v1, "IdAgeStepViewModel"

    .line 58
    .line 59
    const-string v0, "Could not save ID photo"

    .line 60
    .line 61
    invoke-static {v1, v0, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 62
    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 65
    .line 66
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 67
    .line 68
    .line 69
    const/4 p1, 0x0

    .line 70
    :goto_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$launchJob:LX/Cbu;

    .line 71
    .line 72
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_5

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 79
    .line 80
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 81
    .line 82
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 87
    .line 88
    if-ne v1, v0, :cond_5

    .line 89
    .line 90
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 91
    .line 92
    if-nez p1, :cond_4

    .line 93
    .line 94
    invoke-virtual {v3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onCaptureFailed()V

    .line 95
    .line 96
    .line 97
    :cond_3
    :goto_2
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 98
    .line 99
    return-object v2

    .line 100
    :cond_4
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 101
    .line 102
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 103
    .line 104
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 105
    .line 106
    invoke-static {v3, v1, v0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$with(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-interface {v2, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_5
    if-eqz p1, :cond_3

    .line 115
    .line 116
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 117
    .line 118
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 119
    .line 120
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$delete(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Ljava/io/File;)V

    .line 121
    .line 122
    .line 123
    goto :goto_2

    .line 124
    :catchall_0
    move-exception v1

    .line 125
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 126
    .line 127
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 128
    .line 129
    .line 130
    throw v1
.end method
