.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/activation/ageverification/CapturedPhoto;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$onPhotoTaken$1$1$photo$1"
    f = "IdAgeStepViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $bitmap:Landroid/graphics/Bitmap;

.field public final synthetic $capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

.field public final synthetic $frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Landroid/graphics/Bitmap;",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/CapturedPhoto;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 8
    .line 9
    iget-object v4, v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->context:Landroid/content/Context;

    .line 10
    .line 11
    iget-object v3, v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->userId:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 14
    .line 15
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1$photo$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 20
    .line 21
    invoke-static {v5, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$getFilePrefix(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdSide;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {v4, v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->saveIdPhoto(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0

    .line 30
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    throw v0
.end method
