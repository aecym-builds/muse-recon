.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onFaceTrackingUnavailable$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $it:Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onFaceTrackingUnavailable$1$1;->$it:Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onFaceTrackingUnavailable$1$1;->$it:Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;->video:Ljava/io/File;

    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    .line 5
    .line 6
    .line 7
    return-void
.end method
