.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$onPhotoTaken$1"
    f = "IdAgeStepViewModel.kt"
    l = {
        0x11e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $bitmap:Landroid/graphics/Bitmap;

.field public final synthetic $capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

.field public final synthetic $frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Bitmap;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;

    .line 9
    .line 10
    move-object p0, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;-><init>(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->L$0:Ljava/lang/Object;

    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v3, LX/1EL;

    .line 3
    .line 4
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->label:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    if-ne v0, v1, :cond_2

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    return-object v2

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    invoke-interface {v3}, LX/1EL;->AEK()LX/BqD;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v0}, LX/DDx;->A02(LX/BqD;)LX/Cbu;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    sget-object v0, LX/Cl6;->A00:LX/Cl6;

    .line 31
    .line 32
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$bitmap:Landroid/graphics/Bitmap;

    .line 33
    .line 34
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 35
    .line 36
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$capturing:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 37
    .line 38
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->$frame:Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 39
    .line 40
    const/4 v9, 0x0

    .line 41
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;

    .line 42
    .line 43
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1$1;-><init>(Landroid/graphics/Bitmap;LX/Cbu;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V

    .line 44
    .line 45
    .line 46
    iput-object v9, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->L$0:Ljava/lang/Object;

    .line 47
    .line 48
    iput-object v9, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->L$1:Ljava/lang/Object;

    .line 49
    .line 50
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;->label:I

    .line 51
    .line 52
    invoke-static {p0, v0, v3}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-ne v0, v2, :cond_0

    .line 57
    .line 58
    return-object v2

    .line 59
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    throw v0
.end method
