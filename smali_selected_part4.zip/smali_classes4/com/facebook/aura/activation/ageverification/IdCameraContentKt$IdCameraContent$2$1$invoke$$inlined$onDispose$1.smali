.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CdD;


# instance fields
.field public final synthetic $camera$inlined:Lcom/facebook/aura/activation/ageverification/IdCamera;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdCamera;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;->$camera$inlined:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;->$camera$inlined:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/IdCamera;->unbind()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
