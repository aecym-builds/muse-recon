.class public final synthetic Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;
.implements LX/1EY;


# instance fields
.field public final synthetic $tmp0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->$tmp0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->$tmp0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$logStep(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 268435457
    .line 268435458
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->$tmp0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 268435459
    .line 268435460
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$logStep(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 0
    instance-of v0, p1, LX/39x;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p1, LX/1EY;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->getFunctionDelegate()LX/1EZ;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {p1, v0}, LX/8mk;->A1W(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0

    .line 18
    :cond_0
    return v1
.end method

.method public final getFunctionDelegate()LX/1EZ;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/1EZ<",
            "*>;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->$tmp0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    const-class v3, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 3
    .line 4
    const-string v5, "logStep(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)V"

    .line 5
    .line 6
    const/4 p0, 0x4

    .line 7
    const/4 v1, 0x2

    .line 8
    const-string v4, "logStep"

    .line 9
    .line 10
    new-instance v0, LX/DRw;

    .line 11
    .line 12
    invoke-direct/range {v0 .. v6}, LX/DRw;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final hashCode()I
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$1$1;->getFunctionDelegate()LX/1EZ;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method
