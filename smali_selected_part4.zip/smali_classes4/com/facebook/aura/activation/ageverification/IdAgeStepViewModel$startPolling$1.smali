.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$startPolling$1"
    f = "IdAgeStepViewModel.kt"
    l = {
        0x218
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_5

    .line 6
    .line 7
    if-ne v0, v1, :cond_7

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ReviewResult;

    .line 13
    .line 14
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ReviewResult$Settled;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 19
    .line 20
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ReviewResult$Settled;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ReviewResult$Settled;->status:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 23
    .line 24
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$applyResult(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;)V

    .line 25
    .line 26
    .line 27
    :goto_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 28
    .line 29
    return-object v2

    .line 30
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$NotEligible;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$NotEligible;

    .line 31
    .line 32
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 39
    .line 40
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$resolved(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$Failed;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$Failed;

    .line 45
    .line 46
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 53
    .line 54
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 55
    .line 56
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeCheckReviewKt;->getFunnelMethod(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 61
    .line 62
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->SYSTEM_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 63
    .line 64
    const/4 v5, 0x0

    .line 65
    move-object v6, v5

    .line 66
    invoke-virtual/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 70
    .line 71
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 72
    .line 73
    sget-object v1, Lcom/facebook/aura/activation/ageverification/RetryAction;->REFRESH:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 74
    .line 75
    const/4 v0, 0x0

    .line 76
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 77
    .line 78
    invoke-direct {v3, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 79
    .line 80
    .line 81
    :goto_1
    invoke-static {v4, v3}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$TimedOut;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$TimedOut;

    .line 86
    .line 87
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_6

    .line 92
    .line 93
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 94
    .line 95
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 96
    .line 97
    if-ne v2, v0, :cond_4

    .line 98
    .line 99
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 100
    .line 101
    sget-object v3, Lcom/facebook/aura/user/provider/AgeCheckMethod;->SELFIE:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 102
    .line 103
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 104
    .line 105
    sget-object v5, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->TIMEOUT:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 106
    .line 107
    const/4 v6, 0x0

    .line 108
    move-object v7, v6

    .line 109
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 113
    .line 114
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 115
    .line 116
    sget-object v2, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECHECK:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 117
    .line 118
    const/4 v0, 0x0

    .line 119
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 120
    .line 121
    invoke-direct {v3, v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 122
    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 126
    .line 127
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 128
    .line 129
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 130
    .line 131
    invoke-direct {v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V

    .line 132
    .line 133
    .line 134
    goto :goto_1

    .line 135
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 139
    .line 140
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 141
    .line 142
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 143
    .line 144
    iget-wide v5, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 145
    .line 146
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->previousAttemptTime:Ljava/lang/Long;

    .line 147
    .line 148
    iget-boolean v8, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 149
    .line 150
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;->label:I

    .line 151
    .line 152
    invoke-virtual/range {v3 .. v9}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->awaitResult(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;JLjava/lang/Long;ZLX/2M4;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    if-ne p1, v2, :cond_0

    .line 157
    .line 158
    return-object v2

    .line 159
    :cond_6
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 160
    .line 161
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 162
    .line 163
    .line 164
    throw v0

    .line 165
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    throw v0
.end method
