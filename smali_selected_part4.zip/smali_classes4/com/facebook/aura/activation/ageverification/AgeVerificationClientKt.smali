.class public abstract Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ATTEMPT_ALREADY_SUBMITTED:Ljava/lang/String; = "attempt_already_submitted"

.field public static final ATTEMPT_IN_PROGRESS:Ljava/lang/String; = "attempt_in_progress"

.field public static final EVIDENCE_REJECTED:Ljava/lang/String; = "evidence_rejected"

.field public static final HTTP_NONE:I = -0x1

.field public static final HTTP_OK:I = 0xc8

.field public static final HTTP_SERVER_ERROR:I = 0x1f4

.field public static final INVALID_ATTEMPT:Ljava/lang/String; = "invalid_attempt"

.field public static final INVALID_FILE:Ljava/lang/String; = "invalid_file"

.field public static final INVALID_FILE_HANDLE:Ljava/lang/String; = "invalid_file_handle"

.field public static final INVALID_RESPONSE:Ljava/lang/String; = "invalid_response"

.field public static final METHOD_NOT_ALLOWED:Ljava/lang/String; = "method_not_allowed"

.field public static final MISSING_CAPTURE:Ljava/lang/String; = "missing_capture"

.field public static final NOT_ELIGIBLE:Ljava/lang/String; = "not_eligible"

.field public static final NOT_SUPPORTED:Ljava/lang/String; = "not_supported"

.field public static final RATE_LIMITED:Ljava/lang/String; = "rate_limited"

.field public static final RETRIES_EXHAUSTED:Ljava/lang/String; = "retries_exhausted"

.field public static final SUBMIT_FAILED:Ljava/lang/String; = "submit_failed"

.field public static final TAG:Ljava/lang/String; = "AgeVerificationClient"

.field public static final UNKNOWN_UPLOAD_KIND:Ljava/lang/String; = "unknown_upload_kind"

.field public static final UPLOAD_FAILED:Ljava/lang/String; = "upload_failed"


# direct methods
.method public static final getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    instance-of v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 10
    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->problemType:Ljava/lang/String;

    .line 14
    .line 15
    :cond_0
    return-object v0
.end method
