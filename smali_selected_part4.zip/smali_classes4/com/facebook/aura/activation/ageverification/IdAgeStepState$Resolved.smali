.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final afterFinalFailure:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;->afterFinalFailure:Z

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final getAfterFinalFailure()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;->afterFinalFailure:Z

    .line 1
    .line 2
    return p0
.end method
