.class public final Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.AgeCheckReview"
    f = "AgeCheckReview.kt"
    l = {
        0x7a,
        0x8e
    }
    m = "awaitResult"
    v = 0x2
.end annotation


# instance fields
.field public J$0:J

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public Z$0:Z

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeCheckReview;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeCheckReview;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->this$0:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->this$0:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v1, 0x0

    .line 13
    const-wide/16 v2, 0x0

    .line 14
    .line 15
    move-object v4, v1

    .line 16
    invoke-virtual/range {v0 .. v6}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->awaitResult(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;JLjava/lang/Long;ZLX/2M4;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method
