.class public abstract Lcom/facebook/aura/activation/ageverification/IdCameraKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CROP_PADDING_RATIO:F = 0.2f

.field public static final MAX_CAPTURE_SIZE:Landroid/util/Size;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/16 v2, 0x780

    .line 1
    .line 2
    const/16 v1, 0x5a0

    .line 3
    .line 4
    new-instance v0, Landroid/util/Size;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1}, Landroid/util/Size;-><init>(II)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->MAX_CAPTURE_SIZE:Landroid/util/Size;

    .line 10
    .line 11
    return-void
.end method

.method public static final synthetic access$getMAX_CAPTURE_SIZE$p()Landroid/util/Size;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->MAX_CAPTURE_SIZE:Landroid/util/Size;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$toUprightVisibleBitmap(LX/FBz;)Landroid/graphics/Bitmap;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/IdCameraKt;->toUprightVisibleBitmap(LX/FBz;)Landroid/graphics/Bitmap;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final saveIdPhoto(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 7

    .line 0
    move-object v4, p0

    .line 1
    move-object v5, p1

    .line 2
    invoke-static {p0, p1, p2, p3}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x4

    .line 6
    move-object p0, p4

    .line 7
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const v0, 0x3e4ccccd    # 0.2f

    .line 11
    .line 12
    .line 13
    invoke-static {p2, p3, v0}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->cropToFrame(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;F)Landroid/graphics/Bitmap;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    :try_start_0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 18
    .line 19
    sget-object v6, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 20
    .line 21
    const-string p1, ".jpg"

    .line 22
    .line 23
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->create(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 24
    .line 25
    .line 26
    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    :try_start_1
    const/16 v0, 0x5a

    .line 28
    .line 29
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->writeJpeg(Landroid/graphics/Bitmap;Ljava/io/File;I)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-eq v2, p2, :cond_0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 34
    .line 35
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-object v0

    .line 39
    :catch_0
    move-exception v0

    .line 40
    :try_start_2
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 41
    .line 42
    .line 43
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 44
    :catchall_0
    move-exception v0

    .line 45
    if-eq v2, p2, :cond_1

    .line 46
    .line 47
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 48
    .line 49
    .line 50
    :cond_1
    throw v0
.end method

.method public static final toUprightVisibleBitmap(LX/FBz;)Landroid/graphics/Bitmap;
    .locals 8

    .line 0
    invoke-static {p0}, LX/FBd;->A00(LX/FBz;)Landroid/graphics/Bitmap;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    invoke-interface {p0}, LX/FBz;->AEM()Landroid/graphics/Rect;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-static {v1}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance v7, Landroid/graphics/Matrix;

    .line 12
    .line 13
    invoke-direct {v7}, Landroid/graphics/Matrix;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-interface {p0}, LX/FBz;->AGR()LX/FC9;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-interface {v0}, LX/FC9;->AJx()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    int-to-float v0, v0

    .line 25
    invoke-virtual {v7, v0}, Landroid/graphics/Matrix;->postRotate(F)Z

    .line 26
    .line 27
    .line 28
    iget v3, v1, Landroid/graphics/Rect;->left:I

    .line 29
    .line 30
    iget v4, v1, Landroid/graphics/Rect;->top:I

    .line 31
    .line 32
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    const/4 p0, 0x1

    .line 41
    invoke-static/range {v2 .. v8}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-eq v0, v2, :cond_0

    .line 46
    .line 47
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 48
    .line 49
    .line 50
    :cond_0
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-object v0
.end method
