.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I = 0x8

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$Companion;


# instance fields
.field public final attempt_id:Ljava/lang/String;

.field public final file_handles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v2, v0}, [Lkotlin/Lazy;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->$childSerializers:[Lkotlin/Lazy;

    .line 21
    .line 22
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;LX/5Xm;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p1, 0x3

    .line 268435457
    .line 268435458
    const/4 v1, 0x3

    .line 268435459
    if-eq v1, v0, :cond_0

    .line 268435460
    .line 268435461
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 268435462
    .line 268435463
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 268435464
    .line 268435465
    .line 268435466
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    throw v0

    .line 268435471
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435472
    .line 268435473
    .line 268435474
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 268435475
    .line 268435476
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 268435477
    .line 268435478
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 9
    .line 10
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;Ljava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;

    .line 16
    .line 17
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 4
    .line 5
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 6
    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getAttempt_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFile_handles()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;->file_handles:Ljava/util/List;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
