.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationSignOutCleanup;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/auth/signout/SignOutCleanupHandler;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationSignOutCleanup;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSignOutCleanup;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSignOutCleanup;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationSignOutCleanup;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public cleanup()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->clearAll(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
