.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentIdFrame$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;->$currentIdFrame$delegate:LX/16A;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;->$currentIdFrame$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 7
    .line 8
    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;->$currentIdFrame$delegate:LX/16A;

    .line 268435457
    .line 268435458
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
