.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $captureKey:I

.field public final synthetic $headMovements:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $recapture:Z

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;IZLX/Ddn;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;",
            "IZ",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$captureKey:I

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$recapture:Z

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$headMovements:LX/Ddn;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$captureKey:I

    .line 3
    .line 4
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$recapture:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->$headMovements:LX/Ddn;

    .line 7
    .line 8
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->beginTake(IZLjava/util/List;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1$invoke$$inlined$onDispose$1;

    .line 12
    .line 13
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt$SelfieCapture$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
