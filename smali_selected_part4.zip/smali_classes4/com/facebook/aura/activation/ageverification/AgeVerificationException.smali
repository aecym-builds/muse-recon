.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationException;
.super Ljava/lang/Exception;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final httpResponseCode:I

.field public final problemType:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 3

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    const-string v2, ""

    .line 3
    .line 4
    :goto_0
    const-string v1, "Age verification request failed: HTTP "

    .line 5
    .line 6
    const-string v0, " "

    .line 7
    .line 8
    invoke-static {v1, v0, v2, p2}, LX/Gi8;->A0o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->problemType:Ljava/lang/String;

    .line 16
    .line 17
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->httpResponseCode:I

    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    move-object v2, p1

    .line 21
    goto :goto_0
.end method


# virtual methods
.method public final getHttpResponseCode()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->httpResponseCode:I

    .line 1
    .line 2
    return p0
.end method

.method public final getProblemType()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->problemType:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
