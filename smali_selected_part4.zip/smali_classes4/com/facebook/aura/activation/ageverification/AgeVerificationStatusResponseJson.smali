.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$Companion;


# instance fields
.field public final attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

.field public final methods:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final retries_left:Ljava/lang/Integer;

.field public final selfie_head_movements:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final state:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v2, v0, v2, v2, v2}, [Lkotlin/Lazy;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 5

    .line 805306368
    const/4 v3, 0x0

    .line 805306369
    const-string v1, ""

    .line 805306370
    .line 805306371
    sget-object v2, LX/0wV;->A00:LX/0wV;

    .line 805306372
    .line 805306373
    move-object v0, p0

    .line 805306374
    move-object v4, v3

    .line 805306375
    move-object p0, v3

    .line 805306376
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)V

    .line 805306377
    .line 805306378
    .line 805306379
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;LX/5Xm;)V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    and-int/lit8 v0, p1, 0x1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const-string p2, ""

    .line 8
    .line 9
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 10
    .line 11
    and-int/lit8 v0, p1, 0x2

    .line 12
    .line 13
    if-nez v0, :cond_3

    .line 14
    .line 15
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 18
    .line 19
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    if-nez v0, :cond_2

    .line 23
    .line 24
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 25
    .line 26
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 27
    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 31
    .line 32
    :goto_2
    and-int/lit8 v0, p1, 0x10

    .line 33
    .line 34
    if-nez v0, :cond_4

    .line 35
    .line 36
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_3
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_4
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 49
    .line 50
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 536870912
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536870913
    .line 536870914
    .line 536870915
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870916
    .line 536870917
    .line 536870918
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 536870919
    .line 536870920
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 536870921
    .line 536870922
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 536870923
    .line 536870924
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 536870925
    .line 536870926
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 536870927
    .line 536870928
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;ILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p6, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    and-int/lit8 v0, p6, 0x2

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    sget-object p2, LX/0wV;->A00:LX/0wV;

    .line 268435465
    .line 268435466
    :cond_0
    and-int/lit8 v0, p6, 0x4

    .line 268435467
    .line 268435468
    const/4 v1, 0x0

    .line 268435469
    if-eqz v0, :cond_1

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_1
    and-int/lit8 v0, p6, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_2

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_2
    and-int/lit8 v0, p6, 0x10

    .line 268435478
    .line 268435479
    if-eqz v0, :cond_3

    .line 268435480
    .line 268435481
    move-object p5, v1

    .line 268435482
    :cond_3
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)V

    .line 268435483
    .line 268435484
    .line 268435485
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->copy(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static synthetic getSelfie_head_movements$annotations()V
    .locals 0
    .annotation runtime Lkotlinx/serialization/Serializable;
        with = Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;
    .end annotation

    .line 0
    return-void
.end method

.method private final headMovements()LX/Ddn;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 5
    .line 6
    :cond_0
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v4, 0x0

    .line 19
    if-eqz v0, :cond_3

    .line 20
    .line 21
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/HeadMovement;->getEntries()LX/0vk;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    move-object v0, v1

    .line 44
    check-cast v0, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_1

    .line 55
    .line 56
    move-object v4, v1

    .line 57
    :cond_2
    invoke-virtual {p0, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_3
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-nez v0, :cond_4

    .line 66
    .line 67
    invoke-interface {p0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-nez v0, :cond_4

    .line 72
    .line 73
    invoke-static {p0}, LX/B89;->A0g(Ljava/lang/Iterable;)Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    return-object v0

    .line 82
    :cond_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModelKt;->DEFAULT_HEAD_MOVEMENTS:LX/Ddn;

    .line 83
    .line 84
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v2, 0x1

    .line 23
    if-nez v3, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 26
    .line 27
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    invoke-static {v4, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 38
    .line 39
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 40
    .line 41
    .line 42
    :cond_3
    const/4 v2, 0x2

    .line 43
    if-nez v3, :cond_4

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 46
    .line 47
    if-eqz v0, :cond_5

    .line 48
    .line 49
    :cond_4
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 52
    .line 53
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 54
    .line 55
    .line 56
    :cond_5
    const/4 v2, 0x3

    .line 57
    if-nez v3, :cond_6

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 60
    .line 61
    if-eqz v0, :cond_7

    .line 62
    .line 63
    :cond_6
    sget-object v1, LX/DYo;->A00:LX/DYo;

    .line 64
    .line 65
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 66
    .line 67
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 68
    .line 69
    .line 70
    :cond_7
    const/4 v2, 0x4

    .line 71
    if-nez v3, :cond_8

    .line 72
    .line 73
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 74
    .line 75
    if-eqz v0, :cond_9

    .line 76
    .line 77
    :cond_8
    sget-object v1, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

    .line 78
    .line 79
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 80
    .line 81
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 82
    .line 83
    .line 84
    :cond_9
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getAttempt()Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMethods()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRetries_left()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSelfie_head_movements()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getState()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v1, v0

    .line 28
    mul-int/lit8 v1, v1, 0x1f

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->selfie_head_movements:Ljava/util/List;

    .line 31
    .line 32
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    return v1
.end method

.method public final toDomain()Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;
    .locals 10

    .line 0
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->getEntries()LX/0vk;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v4, 0x0

    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v6

    .line 19
    move-object v0, v6

    .line 20
    check-cast v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->state:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    :goto_0
    check-cast v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->methods:Ljava/util/List;

    .line 37
    .line 38
    new-instance v7, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    :cond_1
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_4

    .line 52
    .line 53
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->getEntries()LX/0vk;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    move-object v0, v1

    .line 76
    check-cast v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_2

    .line 87
    .line 88
    if-eqz v1, :cond_1

    .line 89
    .line 90
    invoke-virtual {v7, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_3
    move-object v6, v4

    .line 95
    goto :goto_0

    .line 96
    :cond_4
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->retries_left:Ljava/lang/Integer;

    .line 97
    .line 98
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 99
    .line 100
    if-eqz v5, :cond_8

    .line 101
    .line 102
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->getEntries()LX/0vk;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    :cond_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    if-eqz v0, :cond_7

    .line 115
    .line 116
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    move-object v0, v2

    .line 121
    check-cast v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 122
    .line 123
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 128
    .line 129
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v0

    .line 133
    if-eqz v0, :cond_5

    .line 134
    .line 135
    :goto_2
    check-cast v2, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 136
    .line 137
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 138
    .line 139
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-nez v0, :cond_6

    .line 144
    .line 145
    move-object v4, v1

    .line 146
    :cond_6
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 147
    .line 148
    new-instance v9, Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 149
    .line 150
    invoke-direct {v9, v2, v4, v0}, Lcom/facebook/aura/activation/ageverification/AttemptView;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Ljava/lang/String;Ljava/lang/Long;)V

    .line 151
    .line 152
    .line 153
    :goto_3
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->headMovements()LX/Ddn;

    .line 154
    .line 155
    .line 156
    move-result-object p0

    .line 157
    new-instance v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 158
    .line 159
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationState;Ljava/util/List;Ljava/lang/Integer;Lcom/facebook/aura/activation/ageverification/AttemptView;LX/Ddn;)V

    .line 160
    .line 161
    .line 162
    return-object v5

    .line 163
    :cond_7
    move-object v2, v4

    .line 164
    goto :goto_2

    .line 165
    :cond_8
    move-object v9, v4

    .line 166
    goto :goto_3
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
