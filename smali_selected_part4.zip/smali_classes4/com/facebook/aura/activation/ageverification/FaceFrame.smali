.class public final Lcom/facebook/aura/activation/ageverification/FaceFrame;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final faces:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedFace;",
            ">;"
        }
    .end annotation
.end field

.field public final luma:F

.field public final snapshot:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/Float;",
            "Lcom/facebook/aura/activation/ageverification/FaceSnapshot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;FLX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedFace;",
            ">;F",
            "LX/JDM<",
            "-",
            "Ljava/lang/Float;",
            "Lcom/facebook/aura/activation/ageverification/FaceSnapshot;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->faces:Ljava/util/List;

    .line 7
    .line 8
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->luma:F

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->snapshot:LX/JDM;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getFaces()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedFace;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->faces:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLuma()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->luma:F

    .line 1
    .line 2
    return p0
.end method

.method public final getSnapshot()LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDM<",
            "Ljava/lang/Float;",
            "Lcom/facebook/aura/activation/ageverification/FaceSnapshot;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceFrame;->snapshot:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method
