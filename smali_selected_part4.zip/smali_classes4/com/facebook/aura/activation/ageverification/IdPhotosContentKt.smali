.class public abstract Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final IdPhotoLabel(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 21

    .line 0
    move-object/from16 v8, p1

    .line 1
    .line 2
    const v0, -0x16c2aa7a

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v3, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    or-int v5, p3, v0

    .line 23
    .line 24
    :goto_0
    move/from16 v1, p4

    .line 25
    .line 26
    and-int/lit8 v4, p4, 0x2

    .line 27
    .line 28
    if-eqz v4, :cond_4

    .line 29
    .line 30
    or-int/lit8 v5, v5, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    invoke-static {v5}, LX/005;->A1G(I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0, v3, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_3

    .line 41
    .line 42
    if-eqz v4, :cond_1

    .line 43
    .line 44
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 45
    .line 46
    :cond_1
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 47
    .line 48
    const/4 v4, 0x6

    .line 49
    invoke-virtual {v6, v3, v4}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    iget-object v11, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->bodyMedium:LX/2hg;

    .line 54
    .line 55
    invoke-static {v3, v6}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 56
    .line 57
    .line 58
    move-result-wide v9

    .line 59
    const/4 v0, 0x3

    .line 60
    const/16 v17, 0x2

    .line 61
    .line 62
    new-instance v14, LX/2wS;

    .line 63
    .line 64
    invoke-direct {v14, v0}, LX/2wS;-><init>(I)V

    .line 65
    .line 66
    .line 67
    and-int/lit8 p2, v5, 0xe

    .line 68
    .line 69
    const/high16 v0, 0x30000000

    .line 70
    .line 71
    or-int p2, p2, v0

    .line 72
    .line 73
    and-int/lit8 v0, v5, 0x70

    .line 74
    .line 75
    or-int p2, p2, v0

    .line 76
    .line 77
    const/16 p4, 0x39b0

    .line 78
    .line 79
    const/4 v12, 0x0

    .line 80
    const/4 v15, 0x0

    .line 81
    move-object v13, v12

    .line 82
    move/from16 v16, v15

    .line 83
    .line 84
    move/from16 v18, v17

    .line 85
    .line 86
    move-object/from16 v19, v12

    .line 87
    .line 88
    move-object/from16 v20, v12

    .line 89
    .line 90
    move-object/from16 p0, v12

    .line 91
    .line 92
    move-object/from16 p1, v3

    .line 93
    .line 94
    move/from16 p3, v4

    .line 95
    .line 96
    invoke-static/range {v7 .. v25}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 97
    .line 98
    .line 99
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    if-eqz v3, :cond_2

    .line 104
    .line 105
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoLabel$1;

    .line 106
    .line 107
    invoke-direct {v0, v7, v8, v2, v1}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoLabel$1;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 108
    .line 109
    .line 110
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 111
    .line 112
    :cond_2
    return-void

    .line 113
    :cond_3
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 114
    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_4
    and-int/lit8 v0, p3, 0x30

    .line 118
    .line 119
    if-nez v0, :cond_0

    .line 120
    .line 121
    invoke-static {v3, v8}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    or-int/2addr v5, v0

    .line 126
    goto :goto_1

    .line 127
    :cond_5
    move v5, v2

    .line 128
    goto :goto_0
.end method

.method public static final IdPhotoRemove(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p2

    .line 1
    .line 2
    const v0, -0xe1568c4

    .line 3
    .line 4
    .line 5
    move-object/from16 v9, p3

    .line 6
    .line 7
    invoke-interface {v9, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v9, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v10

    .line 22
    or-int v10, v10, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v6, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v9, v6}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v10, v0

    .line 35
    :cond_0
    and-int/lit8 v2, p5, 0x4

    .line 36
    .line 37
    if-eqz v2, :cond_5

    .line 38
    .line 39
    or-int/lit16 v10, v10, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v1, v10, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v8, 0x1

    .line 46
    const/4 v3, 0x0

    .line 47
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0, v9, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_7

    .line 56
    .line 57
    if-eqz v2, :cond_2

    .line 58
    .line 59
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 60
    .line 61
    :cond_2
    const v0, 0x7f120060

    .line 62
    .line 63
    .line 64
    invoke-static {v9, v7, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v10

    .line 68
    const/high16 v0, 0x42400000    # 48.0f

    .line 69
    .line 70
    invoke-static {v5, v0, v0}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    new-instance v0, LX/1Y9;

    .line 75
    .line 76
    invoke-direct {v0, v3}, LX/1Y9;-><init>(I)V

    .line 77
    .line 78
    .line 79
    const/4 v14, 0x0

    .line 80
    invoke-static {v1, v0, v14, v6, v8}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    invoke-interface {v9, v10}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    invoke-interface {v9}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-nez v1, :cond_3

    .line 93
    .line 94
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 95
    .line 96
    if-ne v0, v1, :cond_4

    .line 97
    .line 98
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoRemove$1$1;

    .line 99
    .line 100
    invoke-direct {v0, v10}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoRemove$1$1;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-interface {v9, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    :cond_4
    invoke-static {v2, v0, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    sget-object v0, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 111
    .line 112
    invoke-static {v0, v3}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 113
    .line 114
    .line 115
    move-result-object v13

    .line 116
    move-object v2, v9

    .line 117
    check-cast v2, LX/J7I;

    .line 118
    .line 119
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 120
    .line 121
    .line 122
    move-result v12

    .line 123
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 124
    .line 125
    .line 126
    move-result-object v11

    .line 127
    invoke-static {v9, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 128
    .line 129
    .line 130
    move-result-object v10

    .line 131
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 132
    .line 133
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 134
    .line 135
    if-nez v0, :cond_8

    .line 136
    .line 137
    invoke-static {}, LX/1VY;->A00()V

    .line 138
    .line 139
    .line 140
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    throw v0

    .line 145
    :cond_5
    and-int/lit16 v0, v4, 0x180

    .line 146
    .line 147
    if-nez v0, :cond_1

    .line 148
    .line 149
    invoke-static {v9, v5}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    or-int/2addr v10, v0

    .line 154
    goto :goto_1

    .line 155
    :cond_6
    move v10, v4

    .line 156
    goto/16 :goto_0

    .line 157
    .line 158
    :cond_7
    invoke-interface {v9}, LX/2d4;->AgJ()V

    .line 159
    .line 160
    .line 161
    goto :goto_2

    .line 162
    :cond_8
    invoke-static {v9, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 163
    .line 164
    .line 165
    invoke-static {v9, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 166
    .line 167
    .line 168
    const v0, 0x7f12005f

    .line 169
    .line 170
    .line 171
    invoke-static {v9, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v13

    .line 175
    sget-object v11, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 176
    .line 177
    const/4 v10, 0x6

    .line 178
    invoke-virtual {v11, v9, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    iget-object v1, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->footnoteRegular:LX/2hg;

    .line 183
    .line 184
    invoke-virtual {v11, v9, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    iget-wide v15, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->destructiveText:J

    .line 189
    .line 190
    const/4 v10, 0x3

    .line 191
    new-instance v0, LX/2wS;

    .line 192
    .line 193
    invoke-direct {v0, v10}, LX/2wS;-><init>(I)V

    .line 194
    .line 195
    .line 196
    const/16 p4, 0x3fb2

    .line 197
    .line 198
    move-object/from16 v18, v14

    .line 199
    .line 200
    move-object/from16 v19, v14

    .line 201
    .line 202
    move/from16 v22, v3

    .line 203
    .line 204
    move/from16 v23, v3

    .line 205
    .line 206
    move/from16 v24, v3

    .line 207
    .line 208
    move-object/from16 v25, v14

    .line 209
    .line 210
    move-object/from16 v26, v14

    .line 211
    .line 212
    move-object/from16 p0, v14

    .line 213
    .line 214
    move-object/from16 p1, v9

    .line 215
    .line 216
    move/from16 p2, v3

    .line 217
    .line 218
    move/from16 p3, v3

    .line 219
    .line 220
    move-object/from16 v17, v1

    .line 221
    .line 222
    move-object/from16 v20, v0

    .line 223
    .line 224
    move/from16 v21, v3

    .line 225
    .line 226
    invoke-static/range {v13 .. v31}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 227
    .line 228
    .line 229
    invoke-static {v2, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 230
    .line 231
    .line 232
    :goto_2
    invoke-interface {v9}, LX/2d4;->AAg()LX/J7V;

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    if-eqz v1, :cond_9

    .line 237
    .line 238
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoRemove$3;

    .line 239
    .line 240
    move-object/from16 p1, v7

    .line 241
    .line 242
    move-object/from16 p2, v6

    .line 243
    .line 244
    move-object/from16 p3, v5

    .line 245
    .line 246
    move/from16 p4, v4

    .line 247
    .line 248
    move-object/from16 p0, v0

    .line 249
    .line 250
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoRemove$3;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 251
    .line 252
    .line 253
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 254
    .line 255
    :cond_9
    return-void
.end method

.method public static final IdPhotoTile(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 39
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/facebook/aura/activation/ageverification/CapturedPhoto;",
            "F",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v21, p5

    .line 1
    .line 2
    const v0, -0x6dff323a

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p6

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p7

    .line 11
    .line 12
    and-int/lit8 v0, p7, 0x6

    .line 13
    .line 14
    const/16 v20, 0x2

    .line 15
    .line 16
    move/from16 p7, p0

    .line 17
    .line 18
    if-nez v0, :cond_9

    .line 19
    .line 20
    move/from16 v0, p7

    .line 21
    .line 22
    invoke-static {v2, v0}, LX/004;->A0E(LX/2d4;I)I

    .line 23
    .line 24
    .line 25
    move-result v7

    .line 26
    or-int/2addr v7, v1

    .line 27
    :goto_0
    and-int/lit8 v0, v1, 0x30

    .line 28
    .line 29
    move-object/from16 v6, p1

    .line 30
    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    invoke-static {v6, v2, v1}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    invoke-static {v0}, LX/003;->A07(I)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    or-int/2addr v7, v0

    .line 42
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 43
    .line 44
    move/from16 p6, p2

    .line 45
    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    move/from16 v0, p6

    .line 49
    .line 50
    invoke-static {v2, v0}, LX/004;->A0B(LX/2d4;F)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v7, v0

    .line 55
    :cond_1
    and-int/lit16 v0, v1, 0xc00

    .line 56
    .line 57
    move-object/from16 p5, p3

    .line 58
    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    move-object/from16 v0, p5

    .line 62
    .line 63
    invoke-static {v2, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    or-int/2addr v7, v0

    .line 68
    :cond_2
    and-int/lit16 v0, v1, 0x6000

    .line 69
    .line 70
    if-nez v0, :cond_3

    .line 71
    .line 72
    move-object/from16 v0, p4

    .line 73
    .line 74
    invoke-static {v2, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    or-int/2addr v7, v0

    .line 79
    :cond_3
    move/from16 p3, p8

    .line 80
    .line 81
    and-int/lit8 v5, p8, 0x20

    .line 82
    .line 83
    const/high16 v0, 0x30000

    .line 84
    .line 85
    if-nez v5, :cond_4

    .line 86
    .line 87
    and-int/2addr v0, v1

    .line 88
    if-nez v0, :cond_5

    .line 89
    .line 90
    move-object/from16 v0, v21

    .line 91
    .line 92
    invoke-static {v2, v0}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    :cond_4
    or-int/2addr v7, v0

    .line 97
    :cond_5
    const v4, 0x12493

    .line 98
    .line 99
    .line 100
    and-int/2addr v4, v7

    .line 101
    const v0, 0x12492

    .line 102
    .line 103
    .line 104
    const/4 v3, 0x0

    .line 105
    invoke-static {v4, v0}, LX/003;->A1H(II)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    invoke-static {v0, v2, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_a

    .line 114
    .line 115
    if-eqz v5, :cond_6

    .line 116
    .line 117
    sget-object v21, LX/3C1;->A00:LX/3Cb;

    .line 118
    .line 119
    :cond_6
    move/from16 v0, p7

    .line 120
    .line 121
    invoke-static {v2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v19

    .line 125
    const/4 v10, 0x0

    .line 126
    const/high16 v4, 0x43270000    # 167.0f

    .line 127
    .line 128
    move-object/from16 v0, v21

    .line 129
    .line 130
    invoke-static {v0, v4}, LX/002;->A0a(LX/3C1;F)LX/3C1;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-static {v0, v2, v3}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->outlined(LX/3C1;LX/2d4;I)LX/3C1;

    .line 135
    .line 136
    .line 137
    move-result-object v9

    .line 138
    if-nez p1, :cond_8

    .line 139
    .line 140
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 141
    .line 142
    new-instance v8, LX/1Y9;

    .line 143
    .line 144
    invoke-direct {v8, v3}, LX/1Y9;-><init>(I)V

    .line 145
    .line 146
    .line 147
    const/4 v5, 0x1

    .line 148
    move-object/from16 v4, v18

    .line 149
    .line 150
    move-object/from16 v0, p5

    .line 151
    .line 152
    invoke-static {v4, v8, v10, v0, v5}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    :goto_1
    invoke-interface {v9, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    sget v4, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 161
    .line 162
    invoke-static {v0, v4}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 163
    .line 164
    .line 165
    move-result-object v8

    .line 166
    if-eqz p1, :cond_7

    .line 167
    .line 168
    sget v4, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 169
    .line 170
    :cond_7
    sget-object v0, LX/2Id;->A04:LX/2rU;

    .line 171
    .line 172
    invoke-static {v0, v4}, LX/Dn6;->A02(LX/2rU;F)LX/CP5;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    sget-object v15, LX/2Id;->A00:LX/2sS;

    .line 177
    .line 178
    const/16 v14, 0x30

    .line 179
    .line 180
    invoke-static {v0, v2, v15, v14}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 181
    .line 182
    .line 183
    move-result-object v13

    .line 184
    move-object v0, v2

    .line 185
    check-cast v0, LX/J7I;

    .line 186
    .line 187
    iget-wide v4, v0, LX/J7I;->A06:J

    .line 188
    .line 189
    const/16 v9, 0x20

    .line 190
    .line 191
    ushr-long v11, v4, v9

    .line 192
    .line 193
    xor-long/2addr v4, v11

    .line 194
    long-to-int v12, v4

    .line 195
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 196
    .line 197
    .line 198
    move-result-object v4

    .line 199
    invoke-static {v2, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 200
    .line 201
    .line 202
    move-result-object v11

    .line 203
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 204
    .line 205
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 206
    .line 207
    if-nez v5, :cond_b

    .line 208
    .line 209
    invoke-static {}, LX/1VY;->A00()V

    .line 210
    .line 211
    .line 212
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    throw v0

    .line 217
    :cond_8
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 218
    .line 219
    move-object/from16 v18, v0

    .line 220
    .line 221
    goto :goto_1

    .line 222
    :cond_9
    move v7, v1

    .line 223
    goto/16 :goto_0

    .line 224
    .line 225
    :cond_a
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 226
    .line 227
    .line 228
    goto :goto_3

    .line 229
    :cond_b
    invoke-static {v2, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 230
    .line 231
    .line 232
    sget-object v8, LX/3Cl;->A04:LX/JDN;

    .line 233
    .line 234
    invoke-static {v2, v13, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 235
    .line 236
    .line 237
    sget-object v5, LX/3Cl;->A06:LX/JDN;

    .line 238
    .line 239
    invoke-static {v2, v4, v5, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 240
    .line 241
    .line 242
    move-result-object v17

    .line 243
    sget-object v4, LX/3Cl;->A02:LX/JDM;

    .line 244
    .line 245
    invoke-static {v2, v11, v4}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 246
    .line 247
    .line 248
    move-result-object v16

    .line 249
    const/4 v11, 0x6

    .line 250
    if-nez p1, :cond_d

    .line 251
    .line 252
    const v4, 0x4e14958d    # 6.2320723E8f

    .line 253
    .line 254
    .line 255
    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    .line 256
    .line 257
    .line 258
    const v4, 0x7f0800db

    .line 259
    .line 260
    .line 261
    invoke-static {v2, v4, v3}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 262
    .line 263
    .line 264
    move-result-object v23

    .line 265
    sget-object v24, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->MEDIUM:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 266
    .line 267
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 268
    .line 269
    invoke-virtual {v4, v2, v11}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 270
    .line 271
    .line 272
    move-result-object v4

    .line 273
    iget-object v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 274
    .line 275
    iget-wide v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 276
    .line 277
    sget v7, LX/2l9;->$stable:I

    .line 278
    .line 279
    shl-int/lit8 v7, v7, 0x3

    .line 280
    .line 281
    or-int/lit16 v7, v7, 0x180

    .line 282
    .line 283
    const/16 v31, 0x29

    .line 284
    .line 285
    move-object/from16 v22, v10

    .line 286
    .line 287
    move-object/from16 v25, v10

    .line 288
    .line 289
    move-wide/from16 v26, v4

    .line 290
    .line 291
    move-object/from16 v28, v10

    .line 292
    .line 293
    move-object/from16 v29, v2

    .line 294
    .line 295
    move/from16 v30, v7

    .line 296
    .line 297
    invoke-static/range {v22 .. v31}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 298
    .line 299
    .line 300
    move-object/from16 v5, v19

    .line 301
    .line 302
    move/from16 v4, v20

    .line 303
    .line 304
    invoke-static {v5, v10, v2, v3, v4}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoLabel(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 305
    .line 306
    .line 307
    :goto_2
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 308
    .line 309
    .line 310
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 311
    .line 312
    .line 313
    move-result-object v2

    .line 314
    if-eqz v2, :cond_c

    .line 315
    .line 316
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoTile$2;

    .line 317
    .line 318
    move-object/from16 v34, v0

    .line 319
    .line 320
    move/from16 v35, p7

    .line 321
    .line 322
    move-object/from16 v36, v6

    .line 323
    .line 324
    move/from16 v37, p6

    .line 325
    .line 326
    move-object/from16 v38, p5

    .line 327
    .line 328
    move-object/from16 p0, p4

    .line 329
    .line 330
    move-object/from16 p1, v21

    .line 331
    .line 332
    move/from16 p2, v1

    .line 333
    .line 334
    invoke-direct/range {v34 .. v42}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotoTile$2;-><init>(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 335
    .line 336
    .line 337
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 338
    .line 339
    :cond_c
    return-void

    .line 340
    :cond_d
    const v12, 0x4e18397d    # 6.384761E8f

    .line 341
    .line 342
    .line 343
    invoke-interface {v2, v12}, LX/2d4;->Agj(I)V

    .line 344
    .line 345
    .line 346
    iget-object v12, v6, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 347
    .line 348
    invoke-static {v12}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 349
    .line 350
    .line 351
    move-result-object v12

    .line 352
    invoke-static {v12}, LX/006;->A15(Ljava/lang/Object;)Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object v22

    .line 356
    sget-object v13, LX/2sI;->A02:LX/2wD;

    .line 357
    .line 358
    move/from16 v12, p6

    .line 359
    .line 360
    invoke-static {v13, v12, v3}, LX/7b5;->A00(LX/3C1;FZ)LX/3C1;

    .line 361
    .line 362
    .line 363
    move-result-object v13

    .line 364
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 365
    .line 366
    invoke-virtual {v12, v2, v11}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getShapes(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 367
    .line 368
    .line 369
    move-result-object v11

    .line 370
    iget-object v11, v11, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->card:LX/2bW;

    .line 371
    .line 372
    invoke-static {v13, v11}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 373
    .line 374
    .line 375
    move-result-object v23

    .line 376
    sget-object v24, LX/32Y;->A00:LX/2vq;

    .line 377
    .line 378
    const/high16 v11, 0x43200000    # 160.0f

    .line 379
    .line 380
    new-instance v12, LX/1Ot;

    .line 381
    .line 382
    invoke-direct {v12, v11}, LX/1Ot;-><init>(F)V

    .line 383
    .line 384
    .line 385
    const/16 p2, 0x7fb8

    .line 386
    .line 387
    const-wide/16 v29, 0x0

    .line 388
    .line 389
    const p0, 0x180180

    .line 390
    .line 391
    .line 392
    move-object/from16 v25, v10

    .line 393
    .line 394
    move-object/from16 v26, v10

    .line 395
    .line 396
    move/from16 v27, v3

    .line 397
    .line 398
    move-object/from16 v28, v12

    .line 399
    .line 400
    move/from16 v31, v3

    .line 401
    .line 402
    move/from16 v32, v3

    .line 403
    .line 404
    move/from16 v33, v3

    .line 405
    .line 406
    move-object/from16 v34, v10

    .line 407
    .line 408
    move-object/from16 v35, v10

    .line 409
    .line 410
    move-object/from16 v36, v10

    .line 411
    .line 412
    move-object/from16 v37, v10

    .line 413
    .line 414
    move-object/from16 v38, v2

    .line 415
    .line 416
    move/from16 p1, v3

    .line 417
    .line 418
    invoke-static/range {v22 .. v41}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage-XRP3Ue8(Ljava/lang/String;LX/3C1;LX/2vq;Ljava/lang/String;Lcom/facebook/common/callercontext/ContextChain;ZLX/1Ot;JZZZLX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;III)V

    .line 419
    .line 420
    .line 421
    sget-object v11, LX/Dn6;->A06:LX/Dps;

    .line 422
    .line 423
    invoke-static {v11, v2, v15, v14}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 424
    .line 425
    .line 426
    move-result-object v14

    .line 427
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 428
    .line 429
    .line 430
    move-result v13

    .line 431
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 432
    .line 433
    .line 434
    move-result-object v12

    .line 435
    move-object/from16 v11, v18

    .line 436
    .line 437
    invoke-static {v2, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 438
    .line 439
    .line 440
    move-result-object v11

    .line 441
    invoke-static {v2, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 442
    .line 443
    .line 444
    invoke-static {v2, v14, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 445
    .line 446
    .line 447
    invoke-static {v2, v12, v5}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 448
    .line 449
    .line 450
    move-object/from16 v5, v17

    .line 451
    .line 452
    invoke-static {v4, v5, v2, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 453
    .line 454
    .line 455
    move-object/from16 v4, v16

    .line 456
    .line 457
    invoke-static {v2, v11, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 458
    .line 459
    .line 460
    move-object/from16 v5, v19

    .line 461
    .line 462
    move/from16 v4, v20

    .line 463
    .line 464
    invoke-static {v5, v10, v2, v3, v4}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoLabel(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 465
    .line 466
    .line 467
    shr-int/lit8 v3, v7, 0x9

    .line 468
    .line 469
    and-int/lit8 v11, v3, 0x70

    .line 470
    .line 471
    const/4 v12, 0x4

    .line 472
    move-object v7, v5

    .line 473
    move-object/from16 v8, p4

    .line 474
    .line 475
    move-object v9, v10

    .line 476
    move-object v10, v2

    .line 477
    invoke-static/range {v7 .. v12}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoRemove(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 478
    .line 479
    .line 480
    const/4 v3, 0x1

    .line 481
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 482
    .line 483
    .line 484
    goto/16 :goto_2
.end method

.method public static final IdPhotosContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V
    .locals 14

    .line 0
    move-object/from16 v9, p2

    .line 1
    .line 2
    invoke-static {p0, p1}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v13

    .line 6
    const v0, -0x52283f32

    .line 7
    .line 8
    .line 9
    move-object/from16 v11, p3

    .line 10
    .line 11
    invoke-interface {v11, v0}, LX/2d4;->Agl(I)V

    .line 12
    .line 13
    .line 14
    move/from16 v1, p4

    .line 15
    .line 16
    and-int/lit8 v0, p4, 0x6

    .line 17
    .line 18
    const/4 v4, 0x2

    .line 19
    if-nez v0, :cond_a

    .line 20
    .line 21
    invoke-static {p0, v11, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-static {v0}, LX/003;->A06(I)I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    or-int v3, v3, p4

    .line 30
    .line 31
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 32
    .line 33
    const/16 v2, 0x20

    .line 34
    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    invoke-static {p1, v11, v1}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0}, LX/003;->A07(I)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v3, v0

    .line 46
    :cond_0
    move/from16 p4, p5

    .line 47
    .line 48
    and-int/lit8 v7, p5, 0x4

    .line 49
    .line 50
    if-eqz v7, :cond_9

    .line 51
    .line 52
    or-int/lit16 v3, v3, 0x180

    .line 53
    .line 54
    :cond_1
    :goto_1
    and-int/lit16 v5, v3, 0x93

    .line 55
    .line 56
    const/16 v0, 0x92

    .line 57
    .line 58
    const/4 v6, 0x0

    .line 59
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-static {v0, v11, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_8

    .line 68
    .line 69
    if-eqz v7, :cond_2

    .line 70
    .line 71
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 72
    .line 73
    :cond_2
    invoke-static {v11}, LX/3Rp;->A07(LX/2d4;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 78
    .line 79
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdDocument;->getSides()I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    invoke-static {v0, v4}, LX/003;->A1I(II)Z

    .line 84
    .line 85
    .line 86
    move-result v4

    .line 87
    iget-boolean v7, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->canContinue:Z

    .line 88
    .line 89
    and-int/lit8 v0, v3, 0x70

    .line 90
    .line 91
    if-eq v0, v2, :cond_3

    .line 92
    .line 93
    and-int/lit8 v0, v3, 0x40

    .line 94
    .line 95
    if-eqz v0, :cond_4

    .line 96
    .line 97
    invoke-interface {v11, p1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_4

    .line 102
    .line 103
    :cond_3
    const/4 v6, 0x1

    .line 104
    :cond_4
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    if-nez v6, :cond_5

    .line 109
    .line 110
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 111
    .line 112
    if-ne v8, v0, :cond_6

    .line 113
    .line 114
    :cond_5
    new-instance v8, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$1$1;

    .line 115
    .line 116
    invoke-direct {v8, p1}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$1$1;-><init>(Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {v11, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :cond_6
    check-cast v8, LX/DqV;

    .line 123
    .line 124
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 125
    .line 126
    new-instance v2, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;

    .line 127
    .line 128
    invoke-direct {v2, p0, p1, v5, v4}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/navigation/AuraNavigator;Z)V

    .line 129
    .line 130
    .line 131
    const v0, 0x5ceccd61

    .line 132
    .line 133
    .line 134
    invoke-static {v11, v2, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 135
    .line 136
    .line 137
    move-result-object v10

    .line 138
    and-int/lit16 v0, v3, 0x380

    .line 139
    .line 140
    or-int/lit16 v12, v0, 0xc00

    .line 141
    .line 142
    invoke-static/range {v7 .. v13}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepColumn(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/JDN;LX/2d4;II)V

    .line 143
    .line 144
    .line 145
    :goto_2
    invoke-interface {v11}, LX/2d4;->AAg()LX/J7V;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    if-eqz v0, :cond_7

    .line 150
    .line 151
    new-instance v13, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$3;

    .line 152
    .line 153
    move-object/from16 p2, v9

    .line 154
    .line 155
    move/from16 p3, v1

    .line 156
    .line 157
    invoke-direct/range {v13 .. v18}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$3;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;II)V

    .line 158
    .line 159
    .line 160
    iput-object v13, v0, LX/J7V;->A06:LX/JDN;

    .line 161
    .line 162
    :cond_7
    return-void

    .line 163
    :cond_8
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 164
    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_9
    and-int/lit16 v0, v1, 0x180

    .line 168
    .line 169
    if-nez v0, :cond_1

    .line 170
    .line 171
    invoke-static {v11, v9}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    or-int/2addr v3, v0

    .line 176
    goto :goto_1

    .line 177
    :cond_a
    move v3, v1

    .line 178
    goto/16 :goto_0
.end method

.method public static final synthetic access$IdPhotoLabel(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoLabel(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$IdPhotoRemove(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoRemove(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$IdPhotoTile(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoTile(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getPhotosTitleRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->getPhotosTitleRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final getPhotosTitleRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_3

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_2

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_1

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-ne p0, v0, :cond_0

    .line 15
    .line 16
    const v0, 0x7f120066

    .line 17
    .line 18
    .line 19
    return v0

    .line 20
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 23
    .line 24
    .line 25
    throw v0

    .line 26
    :cond_1
    const v0, 0x7f120064

    .line 27
    .line 28
    .line 29
    return v0

    .line 30
    :cond_2
    const v0, 0x7f120063

    .line 31
    .line 32
    .line 33
    return v0

    .line 34
    :cond_3
    const v0, 0x7f120062

    .line 35
    .line 36
    .line 37
    return v0
.end method
