.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.SelfieCaptureViewModel$onRecordingStarted$1"
    f = "SelfieCaptureViewModel.kt"
    l = {
        0xfd
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->label:I

    .line 3
    .line 4
    const/4 v8, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-ne v0, v8, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 13
    .line 14
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->_state:LX/2J2;

    .line 15
    .line 16
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    move-object v0, v1

    .line 21
    check-cast v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;

    .line 22
    .line 23
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 24
    .line 25
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->guidance:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 26
    .line 27
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->movement:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 28
    .line 29
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->completed:LX/Ddn;

    .line 30
    .line 31
    iget-boolean v9, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->outOfCircle:Z

    .line 32
    .line 33
    iget-boolean p0, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->recaptureNotice:Z

    .line 34
    .line 35
    iget-object p1, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->camera:Lcom/facebook/aura/activation/ageverification/CameraAccess;

    .line 36
    .line 37
    invoke-static {v4, v5, v7}, LX/3Rq;->A1S(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    new-instance v3, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;

    .line 41
    .line 42
    invoke-direct/range {v3 .. v11}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieStep;Lcom/facebook/aura/activation/ageverification/FaceGuidance;Lcom/facebook/aura/activation/ageverification/HeadMovement;LX/Ddn;ZZZLcom/facebook/aura/activation/ageverification/CameraAccess;)V

    .line 43
    .line 44
    .line 45
    invoke-interface {v2, v1, v3}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 52
    .line 53
    return-object v2

    .line 54
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iput v8, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onRecordingStarted$1;->label:I

    .line 58
    .line 59
    const-wide/16 v0, 0xc8

    .line 60
    .line 61
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    if-ne v0, v2, :cond_0

    .line 66
    .line 67
    return-object v2

    .line 68
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    throw v0
.end method
