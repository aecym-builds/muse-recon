.class public final Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;->$activity:Landroid/app/Activity;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;->$activity:Landroid/app/Activity;

    .line 1
    .line 2
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget p0, v0, Landroid/view/WindowManager$LayoutParams;->screenBrightness:F

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const/high16 v0, 0x3f800000    # 1.0f

    .line 17
    .line 18
    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->screenBrightness:F

    .line 19
    .line 20
    invoke-virtual {p1, v1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 21
    .line 22
    .line 23
    new-instance v0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1$invoke$$inlined$onDispose$1;

    .line 24
    .line 25
    invoke-direct {v0, p1, p0}, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1$invoke$$inlined$onDispose$1;-><init>(Landroid/view/Window;F)V

    .line 26
    .line 27
    .line 28
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
