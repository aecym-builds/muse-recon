.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $camera:Lcom/facebook/aura/activation/ageverification/IdCamera;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdCamera;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;

    .line 3
    .line 4
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 268435457
    .line 268435458
    new-instance p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;

    .line 268435459
    .line 268435460
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1$invoke$$inlined$onDispose$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object p0
.end method
