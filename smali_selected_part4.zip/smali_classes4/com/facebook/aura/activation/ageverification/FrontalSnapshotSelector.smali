.class public final Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public best:Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

.field public lastTakenMs:J


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    const-wide/16 v0, -0x1

    .line 4
    .line 5
    iput-wide v0, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->lastTakenMs:J

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getBest()Lcom/facebook/aura/activation/ageverification/FaceSnapshot;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->best:Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 1
    .line 2
    return-object p0
.end method

.method public final offer(Lcom/facebook/aura/activation/ageverification/FaceFrame;J)V
    .locals 6

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/FaceFrame;->faces:Ljava/util/List;

    .line 5
    .line 6
    invoke-static {v0}, LX/B89;->A0Y(Ljava/util/List;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v5

    .line 10
    check-cast v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 11
    .line 12
    if-eqz v5, :cond_0

    .line 13
    .line 14
    iget-wide v1, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->lastTakenMs:J

    .line 15
    .line 16
    const-wide/16 v3, -0x1

    .line 17
    .line 18
    cmp-long v0, v1, v3

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    sub-long v3, p2, v1

    .line 23
    .line 24
    const-wide/16 v1, 0x1f4

    .line 25
    .line 26
    cmp-long v0, v3, v1

    .line 27
    .line 28
    if-gez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return-void

    .line 31
    :cond_1
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->yawDegrees:F

    .line 32
    .line 33
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->pitchDegrees:F

    .line 38
    .line 39
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    add-float/2addr v2, v0

    .line 44
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->best:Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 45
    .line 46
    if-eqz v1, :cond_2

    .line 47
    .line 48
    iget v0, v1, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->penalty:F

    .line 49
    .line 50
    cmpl-float v0, v2, v0

    .line 51
    .line 52
    if-gez v0, :cond_0

    .line 53
    .line 54
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;->nv21:Ljava/util/concurrent/Future;

    .line 55
    .line 56
    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-nez v0, :cond_2

    .line 61
    .line 62
    return-void

    .line 63
    :cond_2
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/FaceFrame;->snapshot:LX/JDM;

    .line 64
    .line 65
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    check-cast v0, Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 74
    .line 75
    if-eqz v0, :cond_0

    .line 76
    .line 77
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->best:Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 78
    .line 79
    iput-wide p2, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->lastTakenMs:J

    .line 80
    .line 81
    return-void
.end method

.method public final reset()V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->best:Lcom/facebook/aura/activation/ageverification/FaceSnapshot;

    .line 2
    .line 3
    const-wide/16 v0, -0x1

    .line 4
    .line 5
    iput-wide v0, p0, Lcom/facebook/aura/activation/ageverification/FrontalSnapshotSelector;->lastTakenMs:J

    .line 6
    .line 7
    return-void
.end method
