.class public final enum Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

.field public static final enum LOADING:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

.field public static final enum NOT_LOADED:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

.field public static final enum READY:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

.field public static final enum UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    .line 0
    const-string v1, "NOT_LOADED"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v5, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 4
    .line 5
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v5, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->NOT_LOADED:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 9
    .line 10
    const-string v1, "LOADING"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 14
    .line 15
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->LOADING:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 19
    .line 20
    const-string v1, "READY"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 24
    .line 25
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v3, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->READY:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 29
    .line 30
    const-string v2, "UNAVAILABLE"

    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 34
    .line 35
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 39
    .line 40
    filled-new-array {v5, v4, v3, v0}, [Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    sput-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->$VALUES:[Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 45
    .line 46
    new-instance v0, LX/DvM;

    .line 47
    .line 48
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 49
    .line 50
    .line 51
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->$ENTRIES:LX/0vk;

    .line 52
    .line 53
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->$VALUES:[Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 7
    .line 8
    return-object v0
.end method
