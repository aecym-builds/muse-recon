.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CcV;


# instance fields
.field public final synthetic $viewModel$inlined:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

.field public final synthetic this$0:LX/CcW;


# direct methods
.method public constructor <init>(LX/CcW;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;->this$0:LX/CcW;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;->$viewModel$inlined:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public runPauseOrOnDisposeEffect()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;->$viewModel$inlined:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onPause()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
