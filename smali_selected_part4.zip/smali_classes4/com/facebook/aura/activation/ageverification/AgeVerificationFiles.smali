.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final directory(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    .locals 0

    .line 268435456
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->root(Landroid/content/Context;)Ljava/io/File;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    new-instance p0, Ljava/io/File;

    .line 268435461
    .line 268435462
    invoke-direct {p0, p1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 268435463
    .line 268435464
    .line 268435465
    return-object p0
.end method

.method private final directory(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Ljava/io/File;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->directory(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    .line 1
    .line 2
    .line 3
    move-result-object p2

    .line 4
    invoke-static {p3}, LX/8mk;->A0i(Ljava/lang/Enum;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    new-instance p0, Ljava/io/File;

    .line 9
    .line 10
    invoke-direct {p0, p2, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-object p0
.end method

.method private final root(Landroid/content/Context;)Ljava/io/File;
    .locals 1

    .line 0
    invoke-virtual {p1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    const-string p0, "age_verification"

    .line 5
    .line 6
    new-instance v0, Ljava/io/File;

    .line 7
    .line 8
    invoke-direct {v0, p1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public static synthetic writeJpeg$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;Landroid/graphics/Bitmap;Ljava/io/File;IILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/16 p3, 0x5a

    .line 5
    .line 6
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->writeJpeg(Landroid/graphics/Bitmap;Ljava/io/File;I)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method


# virtual methods
.method public final clear(Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->directory(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    .line 268435460
    .line 268435461
    .line 268435462
    move-result-object p0

    .line 268435463
    invoke-static {p0}, LX/9zA;->A04(Ljava/io/File;)Z

    .line 268435464
    .line 268435465
    .line 268435466
    return-void
.end method

.method public final clear(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->directory(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Ljava/io/File;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p0}, LX/9zA;->A04(Ljava/io/File;)Z

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final clearAll(Landroid/content/Context;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->root(Landroid/content/Context;)Ljava/io/File;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, LX/9zA;->A04(Ljava/io/File;)Z

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final create(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 1

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x4

    .line 4
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->directory(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Ljava/io/File;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {p0}, Ljava/io/File;->isDirectory()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    const-string p0, "Could not create capture directory"

    .line 24
    .line 25
    new-instance v0, Ljava/io/IOException;

    .line 26
    .line 27
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw v0

    .line 31
    :cond_0
    invoke-static {p4, p5, p0}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    return-object v0
.end method

.method public final readVideo(Ljava/io/File;)Lcom/facebook/aura/activation/ageverification/CapturedVideo;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Landroid/media/MediaMetadataRetriever;

    .line 5
    .line 6
    invoke-direct {p0}, Landroid/media/MediaMetadataRetriever;-><init>()V

    .line 7
    .line 8
    .line 9
    :try_start_0
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p0, v0}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CapturedVideo;

    .line 17
    .line 18
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/CapturedVideo;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 22
    .line 23
    .line 24
    return-object v0

    .line 25
    :catchall_0
    move-exception v0

    .line 26
    invoke-virtual {p0}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 27
    .line 28
    .line 29
    throw v0
.end method

.method public final writeJpeg(Landroid/graphics/Bitmap;Ljava/io/File;I)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 2

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Ljava/io/FileOutputStream;

    .line 4
    .line 5
    invoke-direct {p0, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 6
    .line 7
    .line 8
    :try_start_0
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    .line 9
    .line 10
    invoke-virtual {p1, v0, p3, p0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 20
    .line 21
    invoke-direct {v0, p2}, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;-><init>(Ljava/io/File;)V

    .line 22
    .line 23
    .line 24
    return-object v0

    .line 25
    :cond_0
    :try_start_1
    const-string v1, "Could not encode capture"

    .line 26
    .line 27
    new-instance v0, Ljava/io/IOException;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 33
    :catchall_0
    move-exception v1

    .line 34
    :try_start_2
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 35
    :catchall_1
    move-exception v0

    .line 36
    invoke-static {p0, v1}, LX/1Iw;->A00(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 37
    .line 38
    .line 39
    throw v0
.end method
