.class public final Lcom/facebook/aura/activation/ageverification/NormalizedRect;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final bottom:F

.field public final left:F

.field public final right:F

.field public final top:F


# direct methods
.method public constructor <init>(FFFF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 6
    .line 7
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 8
    .line 9
    iput p4, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getBottom()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 1
    .line 2
    return p0
.end method

.method public final getLeft()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 1
    .line 2
    return p0
.end method

.method public final getRight()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 1
    .line 2
    return p0
.end method

.method public final getTop()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 1
    .line 2
    return p0
.end method
