.class public abstract Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final IdAgeStep(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 64
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v20, p7

    .line 1
    .line 2
    const/4 v10, 0x1

    .line 3
    move-object/from16 v63, p1

    .line 4
    .line 5
    move-object/from16 v0, v63

    .line 6
    .line 7
    invoke-static {v0, v10}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/4 v8, 0x2

    .line 11
    move-object/from16 v62, p2

    .line 12
    .line 13
    move-object/from16 v4, p3

    .line 14
    .line 15
    move-object/from16 v0, v62

    .line 16
    .line 17
    invoke-static {v0, v8, v4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    move-object/from16 v60, p5

    .line 21
    .line 22
    move-object/from16 v3, p6

    .line 23
    .line 24
    move-object/from16 v0, v60

    .line 25
    .line 26
    invoke-static {v0, v3}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    const v0, -0x4bcb0b70

    .line 30
    .line 31
    .line 32
    move-object/from16 v2, p8

    .line 33
    .line 34
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 35
    .line 36
    .line 37
    move/from16 v1, p9

    .line 38
    .line 39
    and-int/lit8 v0, p9, 0x6

    .line 40
    .line 41
    move/from16 v5, p0

    .line 42
    .line 43
    if-nez v0, :cond_18

    .line 44
    .line 45
    invoke-static {v2, v5}, LX/004;->A0i(LX/2d4;Z)I

    .line 46
    .line 47
    .line 48
    move-result v7

    .line 49
    or-int v7, v7, p9

    .line 50
    .line 51
    :goto_0
    and-int/lit8 v0, p9, 0x30

    .line 52
    .line 53
    if-nez v0, :cond_0

    .line 54
    .line 55
    move-object/from16 v0, v63

    .line 56
    .line 57
    invoke-static {v2, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    or-int/2addr v7, v0

    .line 62
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 63
    .line 64
    if-nez v0, :cond_1

    .line 65
    .line 66
    move-object/from16 v0, v62

    .line 67
    .line 68
    invoke-static {v2, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    or-int/2addr v7, v0

    .line 73
    :cond_1
    and-int/lit16 v0, v1, 0xc00

    .line 74
    .line 75
    if-nez v0, :cond_2

    .line 76
    .line 77
    invoke-static {v2, v4}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    or-int/2addr v7, v0

    .line 82
    :cond_2
    and-int/lit16 v0, v1, 0x6000

    .line 83
    .line 84
    move/from16 v61, p4

    .line 85
    .line 86
    if-nez v0, :cond_3

    .line 87
    .line 88
    move/from16 v0, v61

    .line 89
    .line 90
    invoke-static {v2, v0}, LX/004;->A0H(LX/2d4;I)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    or-int/2addr v7, v0

    .line 95
    :cond_3
    const/high16 v0, 0x30000

    .line 96
    .line 97
    and-int v0, v0, p9

    .line 98
    .line 99
    if-nez v0, :cond_4

    .line 100
    .line 101
    move-object/from16 v0, v60

    .line 102
    .line 103
    invoke-static {v2, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    or-int/2addr v7, v0

    .line 108
    :cond_4
    const/high16 v0, 0x180000

    .line 109
    .line 110
    and-int v0, v0, p9

    .line 111
    .line 112
    if-nez v0, :cond_5

    .line 113
    .line 114
    invoke-static {v2, v3}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    or-int/2addr v7, v0

    .line 119
    :cond_5
    move/from16 v59, p10

    .line 120
    .line 121
    move/from16 v0, v59

    .line 122
    .line 123
    and-int/lit16 v6, v0, 0x80

    .line 124
    .line 125
    const/high16 v0, 0xc00000

    .line 126
    .line 127
    if-nez v6, :cond_6

    .line 128
    .line 129
    and-int v0, v0, p9

    .line 130
    .line 131
    if-nez v0, :cond_7

    .line 132
    .line 133
    move-object/from16 v0, v20

    .line 134
    .line 135
    invoke-static {v2, v0}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    :cond_6
    or-int/2addr v7, v0

    .line 140
    :cond_7
    invoke-static {v7}, LX/009;->A1J(I)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    invoke-static {v0, v2, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_17

    .line 149
    .line 150
    if-eqz v6, :cond_8

    .line 151
    .line 152
    sget-object v20, LX/3C1;->A00:LX/3Cb;

    .line 153
    .line 154
    :cond_8
    invoke-static {v2}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 155
    .line 156
    .line 157
    move-result-object v9

    .line 158
    invoke-static {v2}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    check-cast v0, LX/AHu;

    .line 163
    .line 164
    iget-object v6, v0, LX/AHu;->A01:Ljava/lang/String;

    .line 165
    .line 166
    invoke-static {v9}, LX/602;->A02(Landroid/content/Context;)Landroid/content/Context;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    new-instance v13, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$Factory;

    .line 171
    .line 172
    invoke-direct {v13, v0, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$Factory;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v2}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 176
    .line 177
    .line 178
    move-result-object v12

    .line 179
    if-eqz v12, :cond_19

    .line 180
    .line 181
    invoke-static {v12}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 182
    .line 183
    .line 184
    move-result-object v11

    .line 185
    const-class v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 186
    .line 187
    new-instance v9, LX/Ddf;

    .line 188
    .line 189
    invoke-direct {v9, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 190
    .line 191
    .line 192
    const/4 v0, 0x0

    .line 193
    const/16 v19, 0x0

    .line 194
    .line 195
    move-object/from16 v6, v19

    .line 196
    .line 197
    invoke-static {v13, v12, v11, v6, v9}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 198
    .line 199
    .line 200
    move-result-object v9

    .line 201
    check-cast v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 202
    .line 203
    iget-object v6, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->ui:LX/2J3;

    .line 204
    .line 205
    invoke-static {v2, v6, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 206
    .line 207
    .line 208
    move-result-object v18

    .line 209
    move-object/from16 v6, v63

    .line 210
    .line 211
    invoke-static {v2, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 212
    .line 213
    .line 214
    move-result-object v14

    .line 215
    move-object/from16 v6, v62

    .line 216
    .line 217
    invoke-static {v2, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 218
    .line 219
    .line 220
    move-result-object v15

    .line 221
    shr-int/lit8 v17, v7, 0x9

    .line 222
    .line 223
    invoke-static {v2, v4}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 224
    .line 225
    .line 226
    move-result-object v13

    .line 227
    shr-int/lit8 v16, v7, 0x12

    .line 228
    .line 229
    invoke-static {v2, v3}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 230
    .line 231
    .line 232
    move-result-object v12

    .line 233
    invoke-interface {v2, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 234
    .line 235
    .line 236
    move-result v6

    .line 237
    invoke-static {v2, v12, v14, v15, v6}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 238
    .line 239
    .line 240
    move-result v6

    .line 241
    invoke-static {v2, v13, v6}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 242
    .line 243
    .line 244
    move-result v11

    .line 245
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    if-nez v11, :cond_9

    .line 250
    .line 251
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 252
    .line 253
    if-ne v6, v11, :cond_a

    .line 254
    .line 255
    :cond_9
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;

    .line 256
    .line 257
    move-object/from16 v26, v13

    .line 258
    .line 259
    move-object/from16 v27, v19

    .line 260
    .line 261
    move-object/from16 v21, v6

    .line 262
    .line 263
    move-object/from16 v22, v9

    .line 264
    .line 265
    move-object/from16 v23, v12

    .line 266
    .line 267
    move-object/from16 v24, v14

    .line 268
    .line 269
    move-object/from16 v25, v15

    .line 270
    .line 271
    invoke-direct/range {v21 .. v27}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;LX/2M4;)V

    .line 272
    .line 273
    .line 274
    invoke-interface {v2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    :cond_a
    check-cast v6, LX/JDN;

    .line 278
    .line 279
    sget v25, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->$stable:I

    .line 280
    .line 281
    invoke-static {v2, v9, v6}, LX/CdB;->A06(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 282
    .line 283
    .line 284
    sget-object v6, LX/3J2;->A00:LX/Ip3;

    .line 285
    .line 286
    invoke-interface {v2, v6}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v12

    .line 290
    check-cast v12, Landroid/app/Activity;

    .line 291
    .line 292
    invoke-static {v2, v9, v12}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    move-result v11

    .line 296
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v6

    .line 300
    if-nez v11, :cond_b

    .line 301
    .line 302
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 303
    .line 304
    if-ne v6, v11, :cond_c

    .line 305
    .line 306
    :cond_b
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$2$1;

    .line 307
    .line 308
    invoke-direct {v6, v9, v12}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Landroid/app/Activity;)V

    .line 309
    .line 310
    .line 311
    invoke-interface {v2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    :cond_c
    invoke-static {v2, v6, v9}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 318
    .line 319
    .line 320
    move-result-object v12

    .line 321
    invoke-interface {v2, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 322
    .line 323
    .line 324
    move-result v13

    .line 325
    invoke-static {v7}, LX/005;->A1N(I)Z

    .line 326
    .line 327
    .line 328
    move-result v6

    .line 329
    or-int/2addr v13, v6

    .line 330
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v11

    .line 334
    if-nez v13, :cond_d

    .line 335
    .line 336
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 337
    .line 338
    if-ne v11, v6, :cond_e

    .line 339
    .line 340
    :cond_d
    new-instance v11, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$3$1;

    .line 341
    .line 342
    move/from16 v6, v61

    .line 343
    .line 344
    invoke-direct {v11, v9, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;I)V

    .line 345
    .line 346
    .line 347
    invoke-interface {v2, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    :cond_e
    invoke-static {v2, v11, v9, v12}, LX/001;->A1I(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    invoke-interface {v2, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    move-result v11

    .line 357
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v6

    .line 361
    if-nez v11, :cond_f

    .line 362
    .line 363
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 364
    .line 365
    if-ne v6, v11, :cond_10

    .line 366
    .line 367
    :cond_f
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;

    .line 368
    .line 369
    invoke-direct {v6, v9}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 370
    .line 371
    .line 372
    invoke-interface {v2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    :cond_10
    check-cast v6, LX/JDM;

    .line 376
    .line 377
    move-object/from16 v21, v2

    .line 378
    .line 379
    move-object/from16 v22, v19

    .line 380
    .line 381
    move-object/from16 v23, v9

    .line 382
    .line 383
    move-object/from16 v24, v6

    .line 384
    .line 385
    move/from16 v26, v8

    .line 386
    .line 387
    invoke-static/range {v21 .. v26}, LX/CcX;->A05(LX/2d4;LX/07p;Ljava/lang/Object;LX/JDM;II)V

    .line 388
    .line 389
    .line 390
    invoke-interface {v2, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 391
    .line 392
    .line 393
    move-result v11

    .line 394
    and-int/lit8 v8, v7, 0xe

    .line 395
    .line 396
    invoke-static {v8}, LX/004;->A1Q(I)Z

    .line 397
    .line 398
    .line 399
    move-result v6

    .line 400
    or-int/2addr v11, v6

    .line 401
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 402
    .line 403
    .line 404
    move-result-object v6

    .line 405
    if-nez v11, :cond_11

    .line 406
    .line 407
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 408
    .line 409
    if-ne v6, v7, :cond_12

    .line 410
    .line 411
    :cond_11
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$5$1;

    .line 412
    .line 413
    invoke-direct {v6, v9, v5}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$5$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V

    .line 414
    .line 415
    .line 416
    invoke-interface {v2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    :cond_12
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 420
    .line 421
    invoke-static {v0, v6, v2, v0, v10}, Lcom/facebook/aura/navigation/AuraTerminalBackHandlerKt;->AuraTerminalBackHandler(ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 422
    .line 423
    .line 424
    sget-object v21, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 425
    .line 426
    invoke-interface {v2, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 427
    .line 428
    .line 429
    move-result v6

    .line 430
    invoke-static {v8}, LX/004;->A1Q(I)Z

    .line 431
    .line 432
    .line 433
    move-result v7

    .line 434
    or-int/2addr v7, v6

    .line 435
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 436
    .line 437
    .line 438
    move-result-object v6

    .line 439
    if-nez v7, :cond_13

    .line 440
    .line 441
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 442
    .line 443
    if-ne v6, v7, :cond_14

    .line 444
    .line 445
    :cond_13
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$6$1;

    .line 446
    .line 447
    invoke-direct {v6, v9, v5}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$6$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V

    .line 448
    .line 449
    .line 450
    invoke-interface {v2, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 451
    .line 452
    .line 453
    :cond_14
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 454
    .line 455
    invoke-interface/range {v18 .. v18}, LX/16A;->getValue()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v7

    .line 459
    check-cast v7, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 460
    .line 461
    iget-boolean v7, v7, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsBack:Z

    .line 462
    .line 463
    invoke-interface/range {v18 .. v18}, LX/16A;->getValue()Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v8

    .line 467
    check-cast v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 468
    .line 469
    iget-boolean v11, v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsSettings:Z

    .line 470
    .line 471
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 472
    .line 473
    .line 474
    move-result-object v10

    .line 475
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 476
    .line 477
    if-ne v10, v8, :cond_15

    .line 478
    .line 479
    sget-object v10, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$7$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$7$1;

    .line 480
    .line 481
    invoke-interface {v2, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 482
    .line 483
    .line 484
    :cond_15
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 485
    .line 486
    move/from16 v8, v17

    .line 487
    .line 488
    and-int/lit16 v8, v8, 0x380

    .line 489
    .line 490
    or-int/lit16 v8, v8, 0xc30

    .line 491
    .line 492
    move/from16 v22, v11

    .line 493
    .line 494
    move/from16 v23, v0

    .line 495
    .line 496
    move-object/from16 v24, v60

    .line 497
    .line 498
    move-object/from16 v25, v10

    .line 499
    .line 500
    move-object/from16 v26, v2

    .line 501
    .line 502
    move/from16 v27, v8

    .line 503
    .line 504
    invoke-static/range {v22 .. v27}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->rememberAgeStepHeaderActions(ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/Ddn;

    .line 505
    .line 506
    .line 507
    move-result-object v37

    .line 508
    const/16 v44, 0x0

    .line 509
    .line 510
    new-instance v10, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;

    .line 511
    .line 512
    move-object/from16 v8, v18

    .line 513
    .line 514
    invoke-direct {v10, v9, v5, v8}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$8;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/16A;)V

    .line 515
    .line 516
    .line 517
    const v8, 0x4403c355

    .line 518
    .line 519
    .line 520
    invoke-static {v2, v10, v8}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 521
    .line 522
    .line 523
    move-result-object v53

    .line 524
    and-int/lit8 v8, v16, 0x70

    .line 525
    .line 526
    or-int/lit8 v55, v8, 0x6

    .line 527
    .line 528
    const v57, 0x30000006

    .line 529
    .line 530
    .line 531
    const v58, 0x1fef7dbc

    .line 532
    .line 533
    .line 534
    const-wide/16 v24, 0x0

    .line 535
    .line 536
    move-object/from16 v26, v19

    .line 537
    .line 538
    move-object/from16 v27, v19

    .line 539
    .line 540
    move-object/from16 v29, v19

    .line 541
    .line 542
    move/from16 v30, v0

    .line 543
    .line 544
    move/from16 v31, v7

    .line 545
    .line 546
    move/from16 v32, v0

    .line 547
    .line 548
    move-object/from16 v33, v19

    .line 549
    .line 550
    move-object/from16 v34, v19

    .line 551
    .line 552
    move-object/from16 v35, v19

    .line 553
    .line 554
    move-object/from16 v36, v19

    .line 555
    .line 556
    move-object/from16 v38, v19

    .line 557
    .line 558
    move-wide/from16 v39, v24

    .line 559
    .line 560
    move-wide/from16 v41, v24

    .line 561
    .line 562
    move-object/from16 v43, v19

    .line 563
    .line 564
    move-object/from16 v45, v19

    .line 565
    .line 566
    move-object/from16 v46, v19

    .line 567
    .line 568
    move-object/from16 v47, v19

    .line 569
    .line 570
    move/from16 v48, v0

    .line 571
    .line 572
    move-object/from16 v49, v19

    .line 573
    .line 574
    move-object/from16 v50, v19

    .line 575
    .line 576
    move-object/from16 v51, v19

    .line 577
    .line 578
    move/from16 v52, v0

    .line 579
    .line 580
    move-object/from16 v54, v2

    .line 581
    .line 582
    move/from16 v56, v0

    .line 583
    .line 584
    move-object/from16 v22, v20

    .line 585
    .line 586
    move-object/from16 v23, v19

    .line 587
    .line 588
    move-object/from16 v28, v6

    .line 589
    .line 590
    invoke-static/range {v21 .. v58}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 591
    .line 592
    .line 593
    :goto_1
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 594
    .line 595
    .line 596
    move-result-object v2

    .line 597
    if-eqz v2, :cond_16

    .line 598
    .line 599
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$9;

    .line 600
    .line 601
    move-object v6, v0

    .line 602
    move v7, v5

    .line 603
    move-object/from16 v8, v63

    .line 604
    .line 605
    move-object/from16 v9, v62

    .line 606
    .line 607
    move-object v10, v4

    .line 608
    move/from16 v11, v61

    .line 609
    .line 610
    move-object/from16 v12, v60

    .line 611
    .line 612
    move-object v13, v3

    .line 613
    move-object/from16 v14, v20

    .line 614
    .line 615
    move v15, v1

    .line 616
    move/from16 v16, v59

    .line 617
    .line 618
    invoke-direct/range {v6 .. v16}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$9;-><init>(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 619
    .line 620
    .line 621
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 622
    .line 623
    :cond_16
    return-void

    .line 624
    :cond_17
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 625
    .line 626
    .line 627
    goto :goto_1

    .line 628
    :cond_18
    move v7, v1

    .line 629
    goto/16 :goto_0

    .line 630
    .line 631
    :cond_19
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 632
    .line 633
    .line 634
    move-result-object v0

    .line 635
    throw v0
.end method

.method public static final IdAgeStep$lambda$0(LX/16A;)Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final IdAgeStep$lambda$1(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final IdAgeStep$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final IdAgeStep$lambda$3(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final IdAgeStep$lambda$4(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final IdAgeStepContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 16

    .line 0
    move-object/from16 v12, p3

    .line 1
    .line 2
    const v1, 0x15c24c6b

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p5

    .line 11
    .line 12
    and-int/lit8 v1, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v1, :cond_28

    .line 17
    .line 18
    invoke-static {v3, v0, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    or-int v2, v2, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v4, p5, 0x30

    .line 29
    .line 30
    const/16 v7, 0x20

    .line 31
    .line 32
    move-object/from16 v1, p1

    .line 33
    .line 34
    if-nez v4, :cond_0

    .line 35
    .line 36
    invoke-static {v1, v0, v5}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    invoke-static {v4}, LX/003;->A07(I)I

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    or-int/2addr v2, v4

    .line 45
    :cond_0
    and-int/lit16 v4, v5, 0x180

    .line 46
    .line 47
    const/16 v9, 0x100

    .line 48
    .line 49
    move/from16 v6, p2

    .line 50
    .line 51
    if-nez v4, :cond_1

    .line 52
    .line 53
    invoke-static {v0, v6}, LX/004;->A0k(LX/2d4;Z)I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    or-int/2addr v2, v4

    .line 58
    :cond_1
    and-int/lit8 v11, p6, 0x8

    .line 59
    .line 60
    if-eqz v11, :cond_27

    .line 61
    .line 62
    or-int/lit16 v2, v2, 0xc00

    .line 63
    .line 64
    :cond_2
    :goto_1
    and-int/lit16 v10, v2, 0x493

    .line 65
    .line 66
    const/16 v8, 0x492

    .line 67
    .line 68
    const/4 v4, 0x0

    .line 69
    const/4 v15, 0x1

    .line 70
    invoke-static {v10, v8}, LX/003;->A1H(II)Z

    .line 71
    .line 72
    .line 73
    move-result v8

    .line 74
    invoke-static {v8, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 75
    .line 76
    .line 77
    move-result v8

    .line 78
    if-eqz v8, :cond_26

    .line 79
    .line 80
    if-eqz v11, :cond_3

    .line 81
    .line 82
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 83
    .line 84
    :cond_3
    sget-object v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 85
    .line 86
    invoke-static {v3, v8}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v8

    .line 90
    if-nez v8, :cond_25

    .line 91
    .line 92
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 93
    .line 94
    if-nez v8, :cond_25

    .line 95
    .line 96
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 97
    .line 98
    if-eqz v8, :cond_11

    .line 99
    .line 100
    const v8, -0x519ef8a9

    .line 101
    .line 102
    .line 103
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 104
    .line 105
    .line 106
    move-object v8, v3

    .line 107
    check-cast v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 108
    .line 109
    iget-object v13, v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;->selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 110
    .line 111
    and-int/lit8 v9, v2, 0x70

    .line 112
    .line 113
    if-eq v9, v7, :cond_4

    .line 114
    .line 115
    and-int/lit8 v8, v2, 0x40

    .line 116
    .line 117
    if-eqz v8, :cond_10

    .line 118
    .line 119
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move-result v8

    .line 123
    if-eqz v8, :cond_10

    .line 124
    .line 125
    :cond_4
    const/4 v8, 0x1

    .line 126
    :goto_2
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v14

    .line 130
    if-nez v8, :cond_5

    .line 131
    .line 132
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 133
    .line 134
    if-ne v14, v8, :cond_6

    .line 135
    .line 136
    :cond_5
    new-instance v14, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$1$1;

    .line 137
    .line 138
    invoke-direct {v14, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$1$1;-><init>(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    invoke-interface {v0, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    :cond_6
    check-cast v14, LX/DqV;

    .line 145
    .line 146
    check-cast v14, LX/JDM;

    .line 147
    .line 148
    if-eq v9, v7, :cond_7

    .line 149
    .line 150
    and-int/lit8 v8, v2, 0x40

    .line 151
    .line 152
    if-eqz v8, :cond_f

    .line 153
    .line 154
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v8

    .line 158
    if-eqz v8, :cond_f

    .line 159
    .line 160
    :cond_7
    const/4 v8, 0x1

    .line 161
    :goto_3
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v15

    .line 165
    if-nez v8, :cond_8

    .line 166
    .line 167
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 168
    .line 169
    if-ne v15, v8, :cond_9

    .line 170
    .line 171
    :cond_8
    new-instance v15, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$2$1;

    .line 172
    .line 173
    invoke-direct {v15, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$2$1;-><init>(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    invoke-interface {v0, v15}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_9
    check-cast v15, LX/DqV;

    .line 180
    .line 181
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 182
    .line 183
    if-eq v9, v7, :cond_a

    .line 184
    .line 185
    and-int/lit8 v7, v2, 0x40

    .line 186
    .line 187
    if-eqz v7, :cond_b

    .line 188
    .line 189
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 190
    .line 191
    .line 192
    move-result v7

    .line 193
    if-eqz v7, :cond_b

    .line 194
    .line 195
    :cond_a
    const/4 v4, 0x1

    .line 196
    :cond_b
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v7

    .line 200
    if-nez v4, :cond_c

    .line 201
    .line 202
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 203
    .line 204
    if-ne v7, v4, :cond_d

    .line 205
    .line 206
    :cond_c
    new-instance v7, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$3$1;

    .line 207
    .line 208
    invoke-direct {v7, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$3$1;-><init>(Ljava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_d
    check-cast v7, LX/DqV;

    .line 215
    .line 216
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 217
    .line 218
    const p3, 0xe000

    .line 219
    .line 220
    .line 221
    shl-int/lit8 v2, v2, 0x3

    .line 222
    .line 223
    and-int p3, p3, v2

    .line 224
    .line 225
    const/16 p4, 0x0

    .line 226
    .line 227
    move-object/from16 p1, v12

    .line 228
    .line 229
    move-object/from16 p0, v7

    .line 230
    .line 231
    move-object/from16 p2, v0

    .line 232
    .line 233
    invoke-static/range {v13 .. v20}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;->IdDocumentTypeContent(Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 234
    .line 235
    .line 236
    :goto_4
    invoke-static {v0}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    :goto_5
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 240
    .line 241
    .line 242
    move-result-object v2

    .line 243
    if-eqz v2, :cond_e

    .line 244
    .line 245
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$8;

    .line 246
    .line 247
    move-object/from16 p1, v3

    .line 248
    .line 249
    move-object/from16 p2, v1

    .line 250
    .line 251
    move/from16 p3, v6

    .line 252
    .line 253
    move-object/from16 p4, v12

    .line 254
    .line 255
    move/from16 p5, v5

    .line 256
    .line 257
    move-object/from16 p0, v0

    .line 258
    .line 259
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$8;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/3C1;II)V

    .line 260
    .line 261
    .line 262
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 263
    .line 264
    :cond_e
    return-void

    .line 265
    :cond_f
    const/4 v8, 0x0

    .line 266
    goto :goto_3

    .line 267
    :cond_10
    const/4 v8, 0x0

    .line 268
    goto/16 :goto_2

    .line 269
    .line 270
    :cond_11
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 271
    .line 272
    if-eqz v8, :cond_12

    .line 273
    .line 274
    const v7, -0x519edbaa

    .line 275
    .line 276
    .line 277
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 278
    .line 279
    .line 280
    move-object v10, v3

    .line 281
    check-cast v10, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 282
    .line 283
    sget v14, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->$stable:I

    .line 284
    .line 285
    and-int/lit8 v7, v2, 0xe

    .line 286
    .line 287
    or-int/2addr v14, v7

    .line 288
    sget v7, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->$stable:I

    .line 289
    .line 290
    shl-int/lit8 v7, v7, 0x3

    .line 291
    .line 292
    or-int/2addr v14, v7

    .line 293
    and-int/lit8 v7, v2, 0x70

    .line 294
    .line 295
    or-int/2addr v14, v7

    .line 296
    shr-int/lit8 v2, v2, 0x3

    .line 297
    .line 298
    and-int/lit16 v2, v2, 0x380

    .line 299
    .line 300
    or-int/2addr v14, v2

    .line 301
    move-object v11, v1

    .line 302
    move-object v13, v0

    .line 303
    move v15, v4

    .line 304
    invoke-static/range {v10 .. v15}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotosContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V

    .line 305
    .line 306
    .line 307
    goto :goto_4

    .line 308
    :cond_12
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 309
    .line 310
    if-eqz v8, :cond_13

    .line 311
    .line 312
    const v7, -0x519ed066

    .line 313
    .line 314
    .line 315
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 316
    .line 317
    .line 318
    const v11, 0x7f12004e

    .line 319
    .line 320
    .line 321
    new-instance v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;

    .line 322
    .line 323
    invoke-direct {v8, v3, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 324
    .line 325
    .line 326
    const v7, 0x7a79d141

    .line 327
    .line 328
    .line 329
    invoke-static {v0, v8, v7}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 330
    .line 331
    .line 332
    move-result-object v13

    .line 333
    shr-int/lit8 v2, v2, 0x6

    .line 334
    .line 335
    and-int/lit8 v2, v2, 0x70

    .line 336
    .line 337
    or-int/lit16 v2, v2, 0x180

    .line 338
    .line 339
    move-object v14, v0

    .line 340
    move v15, v2

    .line 341
    move/from16 p0, v4

    .line 342
    .line 343
    invoke-static/range {v11 .. v16}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->CameraPermissionGate(ILX/3C1;LX/JDQ;LX/2d4;II)V

    .line 344
    .line 345
    .line 346
    goto :goto_4

    .line 347
    :cond_13
    sget-object v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 348
    .line 349
    invoke-static {v3, v8}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 350
    .line 351
    .line 352
    move-result v8

    .line 353
    if-eqz v8, :cond_14

    .line 354
    .line 355
    const v4, -0x519ebaa1

    .line 356
    .line 357
    .line 358
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 359
    .line 360
    .line 361
    sget-object v10, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 362
    .line 363
    shr-int/lit8 v2, v2, 0x6

    .line 364
    .line 365
    and-int/lit8 v2, v2, 0x70

    .line 366
    .line 367
    or-int/lit8 p0, v2, 0x6

    .line 368
    .line 369
    const/16 p1, 0xc

    .line 370
    .line 371
    const/4 v8, 0x0

    .line 372
    const/4 v4, 0x0

    .line 373
    :goto_6
    move-object v11, v10

    .line 374
    move v13, v8

    .line 375
    move-object v14, v4

    .line 376
    move-object v15, v0

    .line 377
    invoke-static/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->AgeStepReviewing(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 378
    .line 379
    .line 380
    goto/16 :goto_4

    .line 381
    .line 382
    :cond_14
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 383
    .line 384
    if-eqz v8, :cond_1a

    .line 385
    .line 386
    const v8, -0x519eae27

    .line 387
    .line 388
    .line 389
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 390
    .line 391
    .line 392
    move-object v8, v3

    .line 393
    check-cast v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 394
    .line 395
    iget-object v10, v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 396
    .line 397
    iget-boolean v8, v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->takingLonger:Z

    .line 398
    .line 399
    and-int/lit8 v11, v2, 0x70

    .line 400
    .line 401
    if-eq v11, v7, :cond_15

    .line 402
    .line 403
    and-int/lit8 v7, v2, 0x40

    .line 404
    .line 405
    if-eqz v7, :cond_19

    .line 406
    .line 407
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result v7

    .line 411
    if-eqz v7, :cond_19

    .line 412
    .line 413
    :cond_15
    const/4 v11, 0x1

    .line 414
    :goto_7
    and-int/lit16 v7, v2, 0x380

    .line 415
    .line 416
    if-ne v7, v9, :cond_16

    .line 417
    .line 418
    const/4 v4, 0x1

    .line 419
    :cond_16
    or-int/2addr v11, v4

    .line 420
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 421
    .line 422
    .line 423
    move-result-object v4

    .line 424
    if-nez v11, :cond_17

    .line 425
    .line 426
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 427
    .line 428
    if-ne v4, v7, :cond_18

    .line 429
    .line 430
    :cond_17
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$5$1;

    .line 431
    .line 432
    invoke-direct {v4, v1, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$5$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V

    .line 433
    .line 434
    .line 435
    invoke-interface {v0, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    :cond_18
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 439
    .line 440
    shr-int/lit8 v2, v2, 0x6

    .line 441
    .line 442
    and-int/lit8 p0, v2, 0x70

    .line 443
    .line 444
    const/16 p1, 0x0

    .line 445
    .line 446
    goto :goto_6

    .line 447
    :cond_19
    const/4 v11, 0x0

    .line 448
    goto :goto_7

    .line 449
    :cond_1a
    instance-of v8, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 450
    .line 451
    if-eqz v8, :cond_29

    .line 452
    .line 453
    const v8, -0x519e928f

    .line 454
    .line 455
    .line 456
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 457
    .line 458
    .line 459
    and-int/lit8 v11, v2, 0x70

    .line 460
    .line 461
    if-eq v11, v7, :cond_1b

    .line 462
    .line 463
    and-int/lit8 v8, v2, 0x40

    .line 464
    .line 465
    if-eqz v8, :cond_24

    .line 466
    .line 467
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 468
    .line 469
    .line 470
    move-result v8

    .line 471
    if-eqz v8, :cond_24

    .line 472
    .line 473
    :cond_1b
    const/4 v10, 0x1

    .line 474
    :goto_8
    and-int/lit16 v8, v2, 0x380

    .line 475
    .line 476
    invoke-static {v8, v9}, LX/003;->A1I(II)Z

    .line 477
    .line 478
    .line 479
    move-result v9

    .line 480
    or-int/2addr v9, v10

    .line 481
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v8

    .line 485
    if-nez v9, :cond_1c

    .line 486
    .line 487
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 488
    .line 489
    if-ne v8, v9, :cond_1d

    .line 490
    .line 491
    :cond_1c
    new-instance v8, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$6$1;

    .line 492
    .line 493
    invoke-direct {v8, v1, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$6$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V

    .line 494
    .line 495
    .line 496
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 497
    .line 498
    .line 499
    :cond_1d
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 500
    .line 501
    move-object v9, v3

    .line 502
    check-cast v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 503
    .line 504
    iget-object v10, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 505
    .line 506
    if-eqz v10, :cond_23

    .line 507
    .line 508
    const v10, 0x1dce9305

    .line 509
    .line 510
    .line 511
    invoke-interface {v0, v10}, LX/2d4;->Agj(I)V

    .line 512
    .line 513
    .line 514
    if-eq v11, v7, :cond_1e

    .line 515
    .line 516
    and-int/lit8 v7, v2, 0x40

    .line 517
    .line 518
    if-eqz v7, :cond_1f

    .line 519
    .line 520
    invoke-interface {v0, v1}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 521
    .line 522
    .line 523
    move-result v7

    .line 524
    if-eqz v7, :cond_1f

    .line 525
    .line 526
    :cond_1e
    const/4 v4, 0x1

    .line 527
    :cond_1f
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v7

    .line 531
    if-nez v4, :cond_20

    .line 532
    .line 533
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 534
    .line 535
    if-ne v7, v4, :cond_21

    .line 536
    .line 537
    :cond_20
    new-instance v7, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$7$1;

    .line 538
    .line 539
    invoke-direct {v7, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$7$1;-><init>(Ljava/lang/Object;)V

    .line 540
    .line 541
    .line 542
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    :cond_21
    check-cast v7, LX/DqV;

    .line 546
    .line 547
    invoke-static {v0}, LX/002;->A1Y(Ljava/lang/Object;)Z

    .line 548
    .line 549
    .line 550
    move-result p1

    .line 551
    :goto_9
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 552
    .line 553
    iget-boolean v4, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->rateLimited:Z

    .line 554
    .line 555
    const v14, 0x7f120097

    .line 556
    .line 557
    .line 558
    if-eqz v4, :cond_22

    .line 559
    .line 560
    const v14, 0x7f12009f

    .line 561
    .line 562
    .line 563
    :cond_22
    shr-int/lit8 v2, v2, 0x6

    .line 564
    .line 565
    and-int/lit8 p0, v2, 0x70

    .line 566
    .line 567
    move-object v11, v8

    .line 568
    move-object v13, v7

    .line 569
    move-object v15, v0

    .line 570
    invoke-static/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepErrorCard(Lkotlin/jvm/functions/Function0;LX/3C1;Lkotlin/jvm/functions/Function0;ILX/2d4;II)V

    .line 571
    .line 572
    .line 573
    goto/16 :goto_4

    .line 574
    .line 575
    :cond_23
    const v7, 0x1dceee52

    .line 576
    .line 577
    .line 578
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 579
    .line 580
    .line 581
    move-object v7, v0

    .line 582
    check-cast v7, LX/J7I;

    .line 583
    .line 584
    const/16 p1, 0x0

    .line 585
    .line 586
    invoke-static {v7, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 587
    .line 588
    .line 589
    const/4 v7, 0x0

    .line 590
    goto :goto_9

    .line 591
    :cond_24
    const/4 v10, 0x0

    .line 592
    goto :goto_8

    .line 593
    :cond_25
    const v4, -0x519f05fe

    .line 594
    .line 595
    .line 596
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 597
    .line 598
    .line 599
    shr-int/lit8 v2, v2, 0x9

    .line 600
    .line 601
    and-int/lit8 v2, v2, 0xe

    .line 602
    .line 603
    or-int/lit16 v2, v2, 0xc00

    .line 604
    .line 605
    const/16 p5, 0x76

    .line 606
    .line 607
    const/4 v13, 0x0

    .line 608
    move-object v14, v13

    .line 609
    move-object/from16 p0, v13

    .line 610
    .line 611
    move-object/from16 p1, v13

    .line 612
    .line 613
    move-object/from16 p2, v13

    .line 614
    .line 615
    move-object/from16 p3, v0

    .line 616
    .line 617
    move/from16 p4, v2

    .line 618
    .line 619
    invoke-static/range {v12 .. v21}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepMessage(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;LX/2d4;II)V

    .line 620
    .line 621
    .line 622
    goto/16 :goto_4

    .line 623
    .line 624
    :cond_26
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 625
    .line 626
    .line 627
    goto/16 :goto_5

    .line 628
    .line 629
    :cond_27
    and-int/lit16 v4, v5, 0xc00

    .line 630
    .line 631
    if-nez v4, :cond_2

    .line 632
    .line 633
    invoke-static {v0, v12}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 634
    .line 635
    .line 636
    move-result v4

    .line 637
    or-int/2addr v2, v4

    .line 638
    goto/16 :goto_1

    .line 639
    .line 640
    :cond_28
    move v2, v5

    .line 641
    goto/16 :goto_0

    .line 642
    .line 643
    :cond_29
    const v1, -0x519f0aab

    .line 644
    .line 645
    .line 646
    invoke-static {v0, v1}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 647
    .line 648
    .line 649
    move-result-object v0

    .line 650
    throw v0
.end method

.method public static final synthetic access$IdAgeStep$lambda$0(LX/16A;)Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$IdAgeStep$lambda$1(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$IdAgeStep$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$IdAgeStep$lambda$3(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$IdAgeStep$lambda$4(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$IdAgeStepContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt;->IdAgeStepContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
