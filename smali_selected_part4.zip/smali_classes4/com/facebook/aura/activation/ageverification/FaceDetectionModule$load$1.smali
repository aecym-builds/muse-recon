.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $appContext:Landroid/content/Context;

.field public final synthetic $request:I


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;->$appContext:Landroid/content/Context;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;->$request:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;->$appContext:Landroid/content/Context;

    .line 3
    .line 4
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$1;->$request:I

    .line 8
    .line 9
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->access$prepareEngine(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;Landroid/content/Context;I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
