.class public final Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/F6u;


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final idFrame:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;"
        }
    .end annotation
.end field

.field public final mainExecutor:Ljava/util/concurrent/Executor;

.field public final onFrame:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->idFrame:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->onFrame:LX/JDM;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->mainExecutor:Ljava/util/concurrent/Executor;

    .line 18
    .line 19
    return-void
.end method

.method public static final synthetic access$getOnFrame$p(Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;)LX/JDM;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->onFrame:LX/JDM;

    .line 1
    .line 2
    return-object p0
.end method


# virtual methods
.method public analyze(LX/FBz;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v3, 0x0

    .line 5
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->idFrame:Lkotlin/jvm/functions/Function0;

    .line 6
    .line 7
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/ageverification/UprightLuma;

    .line 16
    .line 17
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/UprightLuma;-><init>(LX/FBz;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->cardEdges(Lcom/facebook/aura/activation/ageverification/UprightLuma;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    :catch_0
    move-exception v2

    .line 26
    :try_start_1
    const-string v1, "IdCardEdgeAnalyzer"

    .line 27
    .line 28
    const-string v0, "Could not analyze the ID frame"

    .line 29
    .line 30
    invoke-static {v1, v0, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    .line 32
    .line 33
    :cond_0
    :goto_0
    invoke-interface {p1}, LX/FBz;->close()V

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;->mainExecutor:Ljava/util/concurrent/Executor;

    .line 37
    .line 38
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;

    .line 39
    .line 40
    invoke-direct {v0, p0, v3}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer$analyze$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzer;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V

    .line 41
    .line 42
    .line 43
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :catchall_0
    move-exception v0

    .line 48
    invoke-interface {p1}, LX/FBz;->close()V

    .line 49
    .line 50
    .line 51
    throw v0
.end method

.method public synthetic getDefaultTargetResolution()Landroid/util/Size;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public synthetic getTargetCoordinateSystem()I
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public synthetic updateTransform(Landroid/graphics/Matrix;)V
    .locals 0

    .line 0
    return-void
.end method
