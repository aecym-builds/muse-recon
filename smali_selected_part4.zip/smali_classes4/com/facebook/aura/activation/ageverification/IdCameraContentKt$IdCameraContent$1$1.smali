.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdCameraContentKt$IdCameraContent$1$1"
    f = "IdCameraContent.kt"
    l = {
        0x4d,
        0x56,
        0x60
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $aspect:F

.field public final synthetic $camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

.field public final synthetic $currentBoxSize$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/2RQ;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $currentIdFrame$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $density:LX/34Y;

.field public final synthetic $owner:LX/07p;

.field public final synthetic $step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

.field public final synthetic $view:LX/FCr;

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/FCr;LX/07p;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLX/16A;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdCamera;",
            "LX/FCr;",
            "LX/07p;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;",
            "LX/34Y;",
            "F",
            "LX/16A<",
            "LX/2RQ;",
            ">;",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$view:LX/FCr;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$owner:LX/07p;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$density:LX/34Y;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$aspect:F

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentBoxSize$delegate:LX/16A;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentIdFrame$delegate:LX/16A;

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0, p10}, LX/DRu;-><init>(ILX/2M4;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$view:LX/FCr;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$owner:LX/07p;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$density:LX/34Y;

    .line 11
    .line 12
    iget v7, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$aspect:F

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentBoxSize$delegate:LX/16A;

    .line 15
    .line 16
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentIdFrame$delegate:LX/16A;

    .line 17
    .line 18
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;

    .line 19
    .line 20
    move-object p1, p2

    .line 21
    invoke-direct/range {v0 .. v10}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/FCr;LX/07p;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLX/16A;LX/16A;LX/2M4;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x3

    .line 5
    const/4 v7, 0x2

    .line 6
    const/4 v5, 0x1

    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    if-eq v0, v5, :cond_1

    .line 11
    .line 12
    if-eq v0, v7, :cond_6

    .line 13
    .line 14
    if-eq v0, v4, :cond_6

    .line 15
    .line 16
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    :cond_0
    throw v2

    .line 21
    :cond_1
    :try_start_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    :try_start_1
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$view:LX/FCr;

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$owner:LX/07p;

    .line 33
    .line 34
    iput v5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->label:I

    .line 35
    .line 36
    invoke-virtual {v2, v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/IdCamera;->bind(LX/FCr;LX/07p;LX/2M4;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-ne v0, v6, :cond_3

    .line 41
    .line 42
    goto :goto_0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 43
    :catch_0
    move-exception v2

    .line 44
    instance-of v0, v2, Ljava/util/concurrent/CancellationException;

    .line 45
    .line 46
    if-nez v0, :cond_0

    .line 47
    .line 48
    const-string v1, "Could not start the camera"

    .line 49
    .line 50
    const-string v0, "IdCameraContent"

    .line 51
    .line 52
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 53
    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 56
    .line 57
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onCaptureFailed()V

    .line 58
    .line 59
    .line 60
    goto :goto_3

    .line 61
    :goto_0
    return-object v6

    .line 62
    :cond_3
    :goto_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 63
    .line 64
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eq v0, v3, :cond_4

    .line 71
    .line 72
    if-ne v0, v5, :cond_5

    .line 73
    .line 74
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 75
    .line 76
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentIdFrame$delegate:LX/16A;

    .line 77
    .line 78
    new-instance v2, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;

    .line 79
    .line 80
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$2;-><init>(LX/16A;)V

    .line 81
    .line 82
    .line 83
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 84
    .line 85
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$3;

    .line 86
    .line 87
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$3;-><init>(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->label:I

    .line 91
    .line 92
    invoke-virtual {v3, v2, v0, p0}, Lcom/facebook/aura/activation/ageverification/IdCamera;->detectCardEdges(Lkotlin/jvm/functions/Function0;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    :goto_2
    if-ne v0, v6, :cond_7

    .line 97
    .line 98
    return-object v6

    .line 99
    :cond_4
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 100
    .line 101
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 102
    .line 103
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$density:LX/34Y;

    .line 104
    .line 105
    iget v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$aspect:F

    .line 106
    .line 107
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->$currentBoxSize$delegate:LX/16A;

    .line 108
    .line 109
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;

    .line 110
    .line 111
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/34Y;FLX/16A;)V

    .line 112
    .line 113
    .line 114
    iput v7, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;->label:I

    .line 115
    .line 116
    invoke-virtual {v5, v0, p0}, Lcom/facebook/aura/activation/ageverification/IdCamera;->detectPortrait(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    goto :goto_2

    .line 121
    :cond_5
    new-instance v2, Lkotlin/NoWhenBranchMatchedException;

    .line 122
    .line 123
    invoke-direct {v2}, Ljava/lang/RuntimeException;-><init>()V

    .line 124
    .line 125
    .line 126
    throw v2

    .line 127
    :cond_6
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_7
    :goto_3
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 131
    .line 132
    return-object v6
.end method
