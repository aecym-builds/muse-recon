.class public interface abstract Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/api/StefiHatchPath$Extension;
