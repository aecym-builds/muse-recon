.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public final takingLonger:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->takingLonger:Z

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;ZILX/04f;)V
    .locals 1

    .line 268435456
    invoke-static {p3, p2}, LX/3Rr;->A1O(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method


# virtual methods
.method public final getMethod()Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTakingLonger()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->takingLonger:Z

    .line 1
    .line 2
    return p0
.end method
