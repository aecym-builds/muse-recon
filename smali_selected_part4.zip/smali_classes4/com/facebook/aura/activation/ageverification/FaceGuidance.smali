.class public final enum Lcom/facebook/aura/activation/ageverification/FaceGuidance;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/FaceGuidance;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum ALIGNED:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum LOW_LIGHT:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum MOVE_AWAY:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum MOVE_CLOSER:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum ONLY_YOU:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

.field public static final enum POSITION:Lcom/facebook/aura/activation/ageverification/FaceGuidance;


# instance fields
.field public final hintRes:Ljava/lang/Integer;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const-string v1, "POSITION"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    const/4 v3, 0x0

    .line 4
    new-instance v4, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 5
    .line 6
    invoke-direct {v4, v1, v0, v3}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 7
    .line 8
    .line 9
    sput-object v4, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->POSITION:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 10
    .line 11
    const v0, 0x7f12008e

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    const-string v1, "ONLY_YOU"

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    new-instance v5, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 22
    .line 23
    invoke-direct {v5, v1, v0, v2}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 24
    .line 25
    .line 26
    sput-object v5, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->ONLY_YOU:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 27
    .line 28
    const v0, 0x7f12008c

    .line 29
    .line 30
    .line 31
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    const-string v1, "MOVE_CLOSER"

    .line 36
    .line 37
    const/4 v0, 0x2

    .line 38
    new-instance v6, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 39
    .line 40
    invoke-direct {v6, v1, v0, v2}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 41
    .line 42
    .line 43
    sput-object v6, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->MOVE_CLOSER:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 44
    .line 45
    const v0, 0x7f12008b

    .line 46
    .line 47
    .line 48
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    const-string v1, "MOVE_AWAY"

    .line 53
    .line 54
    const/4 v0, 0x3

    .line 55
    new-instance v7, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 56
    .line 57
    invoke-direct {v7, v1, v0, v2}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 58
    .line 59
    .line 60
    sput-object v7, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->MOVE_AWAY:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 61
    .line 62
    const v0, 0x7f12008a

    .line 63
    .line 64
    .line 65
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    const-string v1, "LOW_LIGHT"

    .line 70
    .line 71
    const/4 v0, 0x4

    .line 72
    new-instance v8, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 73
    .line 74
    invoke-direct {v8, v1, v0, v2}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 75
    .line 76
    .line 77
    sput-object v8, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->LOW_LIGHT:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 78
    .line 79
    const-string v1, "ALIGNED"

    .line 80
    .line 81
    const/4 v0, 0x5

    .line 82
    new-instance v9, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 83
    .line 84
    invoke-direct {v9, v1, v0, v3}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 85
    .line 86
    .line 87
    sput-object v9, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->ALIGNED:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 88
    .line 89
    filled-new-array/range {v4 .. v9}, [Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    sput-object v1, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->$VALUES:[Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 94
    .line 95
    new-instance v0, LX/DvM;

    .line 96
    .line 97
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 98
    .line 99
    .line 100
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->$ENTRIES:LX/0vk;

    .line 101
    .line 102
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/Integer;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Integer;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->hintRes:Ljava/lang/Integer;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/FaceGuidance;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/FaceGuidance;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/FaceGuidance;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->$VALUES:[Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getHintRes()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->hintRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method
