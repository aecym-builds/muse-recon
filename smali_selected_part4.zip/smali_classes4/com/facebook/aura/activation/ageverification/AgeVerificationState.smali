.class public final enum Lcom/facebook/aura/activation/ageverification/AgeVerificationState;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/AgeVerificationState;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum CONFIRMED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum FAILED_FINAL:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum NOT_REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum NOT_SUPPORTED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

.field public static final enum REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 0
    const-string v1, "NOT_REQUIRED"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 4
    .line 5
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->NOT_REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 9
    .line 10
    const-string v1, "REQUIRED"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 19
    .line 20
    const-string v1, "PENDING"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 24
    .line 25
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 29
    .line 30
    const-string v1, "CONFIRMED"

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    new-instance v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 34
    .line 35
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->CONFIRMED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 39
    .line 40
    const-string v1, "FAILED_RETRYABLE"

    .line 41
    .line 42
    const/4 v0, 0x4

    .line 43
    new-instance v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 44
    .line 45
    invoke-direct {v6, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    sput-object v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 49
    .line 50
    const-string v1, "FAILED_FINAL"

    .line 51
    .line 52
    const/4 v0, 0x5

    .line 53
    new-instance v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 54
    .line 55
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->FAILED_FINAL:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 59
    .line 60
    const-string v1, "NOT_SUPPORTED"

    .line 61
    .line 62
    const/4 v0, 0x6

    .line 63
    new-instance v8, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 64
    .line 65
    invoke-direct {v8, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;-><init>(Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v8, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->NOT_SUPPORTED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 69
    .line 70
    filled-new-array/range {v2 .. v8}, [Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    sput-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 75
    .line 76
    new-instance v0, LX/DvM;

    .line 77
    .line 78
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 79
    .line 80
    .line 81
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->$ENTRIES:LX/0vk;

    .line 82
    .line 83
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationState;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeVerificationState;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/AgeVerificationState;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 7
    .line 8
    return-object v0
.end method
