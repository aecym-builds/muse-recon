.class public interface abstract Lcom/facebook/aura/activation/ageverification/IdAgeStepState;
.super Ljava/lang/Object;
.source ""
