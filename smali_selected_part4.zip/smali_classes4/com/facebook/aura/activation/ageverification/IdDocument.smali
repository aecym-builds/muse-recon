.class public final enum Lcom/facebook/aura/activation/ageverification/IdDocument;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/IdDocument;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public static final enum DRIVER_LICENSE:Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public static final enum PASSPORT:Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public static final enum PERMANENT_RESIDENT:Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public static final enum STATE_ID:Lcom/facebook/aura/activation/ageverification/IdDocument;


# instance fields
.field public final sides:I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    const-string v1, "DRIVER_LICENSE"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    const/4 v6, 0x2

    .line 4
    new-instance v5, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 5
    .line 6
    invoke-direct {v5, v1, v0, v6}, Lcom/facebook/aura/activation/ageverification/IdDocument;-><init>(Ljava/lang/String;II)V

    .line 7
    .line 8
    .line 9
    sput-object v5, Lcom/facebook/aura/activation/ageverification/IdDocument;->DRIVER_LICENSE:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 10
    .line 11
    const-string v1, "PASSPORT"

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 15
    .line 16
    invoke-direct {v4, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/IdDocument;-><init>(Ljava/lang/String;II)V

    .line 17
    .line 18
    .line 19
    sput-object v4, Lcom/facebook/aura/activation/ageverification/IdDocument;->PASSPORT:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 20
    .line 21
    const-string v0, "PERMANENT_RESIDENT"

    .line 22
    .line 23
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 24
    .line 25
    invoke-direct {v3, v0, v6, v6}, Lcom/facebook/aura/activation/ageverification/IdDocument;-><init>(Ljava/lang/String;II)V

    .line 26
    .line 27
    .line 28
    sput-object v3, Lcom/facebook/aura/activation/ageverification/IdDocument;->PERMANENT_RESIDENT:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 29
    .line 30
    const-string v2, "STATE_ID"

    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 34
    .line 35
    invoke-direct {v0, v2, v1, v6}, Lcom/facebook/aura/activation/ageverification/IdDocument;-><init>(Ljava/lang/String;II)V

    .line 36
    .line 37
    .line 38
    sput-object v0, Lcom/facebook/aura/activation/ageverification/IdDocument;->STATE_ID:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 39
    .line 40
    filled-new-array {v5, v4, v3, v0}, [Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    sput-object v1, Lcom/facebook/aura/activation/ageverification/IdDocument;->$VALUES:[Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 45
    .line 46
    new-instance v0, LX/DvM;

    .line 47
    .line 48
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 49
    .line 50
    .line 51
    sput-object v0, Lcom/facebook/aura/activation/ageverification/IdDocument;->$ENTRIES:LX/0vk;

    .line 52
    .line 53
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/IdDocument;->sides:I

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdDocument;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/IdDocument;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/IdDocument;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdDocument;->$VALUES:[Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getSides()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/IdDocument;->sides:I

    .line 1
    .line 2
    return p0
.end method
