.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$captureUi(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$Companion;Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$Companion;->captureUi(Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final captureUi(Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
    .locals 5

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->camera:Lcom/facebook/aura/activation/ageverification/CameraAccess;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/CameraAccess;->BLOCKED:Lcom/facebook/aura/activation/ageverification/CameraAccess;

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-ne v1, v0, :cond_0

    .line 6
    .line 7
    const v3, 0x7f120086

    .line 8
    .line 9
    .line 10
    const v0, 0x7f120087

    .line 11
    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    const v0, 0x7f12004f

    .line 18
    .line 19
    .line 20
    :goto_0
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 25
    .line 26
    invoke-direct {v0, v3, v2, v4, v1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 27
    .line 28
    .line 29
    return-object v0

    .line 30
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/CameraAccess;->ASK_AGAIN:Lcom/facebook/aura/activation/ageverification/CameraAccess;

    .line 31
    .line 32
    if-ne v1, v0, :cond_1

    .line 33
    .line 34
    const v3, 0x7f120086

    .line 35
    .line 36
    .line 37
    const v0, 0x7f120050

    .line 38
    .line 39
    .line 40
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    const v0, 0x7f12004d

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$Companion;->stepUi(Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method private final stepUi(Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
    .locals 3

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieStep$Positioning;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieStep$Positioning;

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->recaptureNotice:Z

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->guidance:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->getHintRes()Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    const v0, 0x7f120092

    .line 23
    .line 24
    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    const/4 v2, 0x0

    .line 30
    const v1, 0x7f120091

    .line 31
    .line 32
    .line 33
    const/4 v0, 0x1

    .line 34
    :goto_0
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 35
    .line 36
    invoke-direct {p1, v1, p0, v0, v2}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 37
    .line 38
    .line 39
    return-object p1

    .line 40
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->guidance:Lcom/facebook/aura/activation/ageverification/FaceGuidance;

    .line 41
    .line 42
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/FaceGuidance;->getHintRes()Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    :goto_1
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    const/4 v2, 0x0

    .line 57
    const v1, 0x7f120091

    .line 58
    .line 59
    .line 60
    const/4 v0, 0x0

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    const v0, 0x7f120090

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_2
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;

    .line 67
    .line 68
    if-eqz v0, :cond_9

    .line 69
    .line 70
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->frontalHeld:Z

    .line 71
    .line 72
    if-nez v0, :cond_4

    .line 73
    .line 74
    const p0, 0x7f120089

    .line 75
    .line 76
    .line 77
    :goto_2
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->outOfCircle:Z

    .line 78
    .line 79
    if-eqz v0, :cond_3

    .line 80
    .line 81
    const v0, 0x7f120090

    .line 82
    .line 83
    .line 84
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    :goto_3
    const/4 v1, 0x0

    .line 89
    const/4 v0, 0x0

    .line 90
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 91
    .line 92
    invoke-direct {p1, p0, v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 93
    .line 94
    .line 95
    return-object p1

    .line 96
    :cond_3
    const/4 v2, 0x0

    .line 97
    goto :goto_3

    .line 98
    :cond_4
    invoke-virtual {p1}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->getDone()Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_5

    .line 103
    .line 104
    const p0, 0x7f12008f

    .line 105
    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_5
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureState;->movement:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 109
    .line 110
    const/4 v0, -0x1

    .line 111
    if-eqz v1, :cond_8

    .line 112
    .line 113
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 114
    .line 115
    .line 116
    move-result v1

    .line 117
    if-eq v1, v0, :cond_8

    .line 118
    .line 119
    const/4 v0, 0x1

    .line 120
    if-eq v1, v0, :cond_7

    .line 121
    .line 122
    const/4 v0, 0x2

    .line 123
    if-eq v1, v0, :cond_6

    .line 124
    .line 125
    const/4 v0, 0x0

    .line 126
    if-eq v1, v0, :cond_8

    .line 127
    .line 128
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 129
    .line 130
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 131
    .line 132
    .line 133
    throw v0

    .line 134
    :cond_6
    const p0, 0x7f120093

    .line 135
    .line 136
    .line 137
    goto :goto_2

    .line 138
    :cond_7
    const p0, 0x7f12008d

    .line 139
    .line 140
    .line 141
    goto :goto_2

    .line 142
    :cond_8
    const p0, 0x7f120094

    .line 143
    .line 144
    .line 145
    goto :goto_2

    .line 146
    :cond_9
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieStep$Finishing;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieStep$Finishing;

    .line 147
    .line 148
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-nez v0, :cond_a

    .line 153
    .line 154
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/SelfieStep$Complete;

    .line 155
    .line 156
    if-nez v0, :cond_a

    .line 157
    .line 158
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 159
    .line 160
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 161
    .line 162
    .line 163
    throw v0

    .line 164
    :cond_a
    const/4 v2, 0x0

    .line 165
    const v1, 0x7f12008f

    .line 166
    .line 167
    .line 168
    const/4 v0, 0x0

    .line 169
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 170
    .line 171
    invoke-direct {p1, v1, v2, v0, v2}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 172
    .line 173
    .line 174
    return-object p1
.end method
