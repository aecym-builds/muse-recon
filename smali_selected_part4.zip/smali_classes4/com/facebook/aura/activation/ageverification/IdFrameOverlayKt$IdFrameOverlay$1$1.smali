.class public final Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2la;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $aspect:F

.field public final synthetic $bracketColor:J

.field public final synthetic $folded:Z

.field public final synthetic $maskColor:J


# direct methods
.method public constructor <init>(FJZJ)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$aspect:F

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$bracketColor:J

    .line 3
    .line 4
    iput-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$folded:Z

    .line 5
    .line 6
    iput-wide p5, p0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$maskColor:J

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2la;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->invoke(LX/2la;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2la;)V
    .locals 18

    .line 0
    const/4 v9, 0x0

    .line 1
    move-object/from16 v11, p1

    .line 2
    .line 3
    invoke-static {v11, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    invoke-interface {v11}, LX/2la;->AKf()J

    .line 7
    .line 8
    .line 9
    move-result-wide v1

    .line 10
    sget v0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->ID_FRAME_MARGIN:F

    .line 11
    .line 12
    invoke-interface {v11, v0}, LX/34Y;->AhZ(F)F

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    move-object/from16 v4, p0

    .line 17
    .line 18
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$aspect:F

    .line 19
    .line 20
    invoke-static {v1, v2, v3, v0}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->idFrameRect-Pq9zytI(JFF)LX/36Z;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/high16 v0, 0x41800000    # 16.0f

    .line 25
    .line 26
    invoke-interface {v11, v0}, LX/34Y;->AhZ(F)F

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    invoke-static {}, LX/2ak;->A00()LX/2bQ;

    .line 31
    .line 32
    .line 33
    move-result-object v8

    .line 34
    invoke-static {v5}, LX/009;->A0J(F)J

    .line 35
    .line 36
    .line 37
    move-result-wide v0

    .line 38
    invoke-static {v2, v0, v1}, LX/2bU;->A01(LX/36Z;J)LX/2bS;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    const/4 v10, 0x0

    .line 43
    invoke-virtual {v8, v0}, LX/2bQ;->A3u(LX/2bS;)V

    .line 44
    .line 45
    .line 46
    iget-wide v14, v4, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$maskColor:J

    .line 47
    .line 48
    invoke-interface {v11}, LX/2la;->AEy()LX/2lC;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    move-object v7, v6

    .line 53
    check-cast v7, LX/2kf;

    .line 54
    .line 55
    iget-object v0, v7, LX/2kf;->A02:LX/2kc;

    .line 56
    .line 57
    iget-object v3, v0, LX/2kc;->A02:LX/2kt;

    .line 58
    .line 59
    invoke-static {v3}, LX/2kd;->A00(LX/2kt;)J

    .line 60
    .line 61
    .line 62
    move-result-wide v0

    .line 63
    :try_start_0
    iget-object v7, v7, LX/2kf;->A01:LX/2lA;

    .line 64
    .line 65
    invoke-interface {v7, v8, v9}, LX/2lA;->A6Q(LX/2lV;I)V

    .line 66
    .line 67
    .line 68
    const/16 v13, 0x7e

    .line 69
    .line 70
    const-wide/16 v16, 0x0

    .line 71
    .line 72
    const/4 v12, 0x0

    .line 73
    move-wide/from16 p0, v16

    .line 74
    .line 75
    invoke-static/range {v10 .. v19}, LX/2lb;->A01(LX/2hc;LX/2la;FIJJJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 76
    .line 77
    .line 78
    invoke-static {v3, v6, v0, v1}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 79
    .line 80
    .line 81
    iget-wide v0, v4, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$bracketColor:J

    .line 82
    .line 83
    invoke-static {v11, v2, v5, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->drawCornerBrackets-g2O1Hgs(LX/2la;LX/36Z;FJ)V

    .line 84
    .line 85
    .line 86
    iget-boolean v0, v4, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$folded:Z

    .line 87
    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    iget-wide v0, v4, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt$IdFrameOverlay$1$1;->$bracketColor:J

    .line 91
    .line 92
    invoke-static {v11, v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->drawFold-mxwnekA(LX/2la;LX/36Z;J)V

    .line 93
    .line 94
    .line 95
    :cond_0
    return-void

    .line 96
    :catchall_0
    move-exception v2

    .line 97
    invoke-static {v3, v6, v0, v1}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 98
    .line 99
    .line 100
    throw v2
.end method
