.class public final enum Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

.field public static final enum ID_BACK:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

.field public static final enum ID_FRONT:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

.field public static final enum SELFIE_PHOTO:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

.field public static final enum SELFIE_VIDEO:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;


# instance fields
.field public final filename:Ljava/lang/String;

.field public final mimeType:Ljava/lang/String;

.field public final uploadMedium:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 16

    .line 0
    const-string v4, "video/mp4"

    .line 1
    .line 2
    const-string v5, "selfie.mp4"

    .line 3
    .line 4
    const-string v1, "SELFIE_VIDEO"

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    const-string v3, "SELFIE_VIDEO_NATIVE"

    .line 8
    .line 9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 10
    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->SELFIE_VIDEO:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 15
    .line 16
    const-string v5, "image/jpeg"

    .line 17
    .line 18
    const-string v6, "selfie.jpg"

    .line 19
    .line 20
    const-string v2, "SELFIE_PHOTO"

    .line 21
    .line 22
    const/4 v3, 0x1

    .line 23
    const-string v4, "SELFIE_PHOTO_NATIVE"

    .line 24
    .line 25
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 26
    .line 27
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    sput-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->SELFIE_PHOTO:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 31
    .line 32
    const-string v11, "id_front.jpg"

    .line 33
    .line 34
    const-string v7, "ID_FRONT"

    .line 35
    .line 36
    const/4 v8, 0x2

    .line 37
    const-string v9, "CAMERA_MANUAL"

    .line 38
    .line 39
    new-instance v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 40
    .line 41
    move-object v10, v5

    .line 42
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    sput-object v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->ID_FRONT:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 46
    .line 47
    const-string v15, "id_back.jpg"

    .line 48
    .line 49
    const-string v11, "ID_BACK"

    .line 50
    .line 51
    const/4 v12, 0x3

    .line 52
    new-instance v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 53
    .line 54
    move-object v13, v9

    .line 55
    move-object v14, v5

    .line 56
    invoke-direct/range {v10 .. v15}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    sput-object v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->ID_BACK:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 60
    .line 61
    filled-new-array {v0, v1, v6, v10}, [Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    sput-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 66
    .line 67
    new-instance v0, LX/DvM;

    .line 68
    .line 69
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 70
    .line 71
    .line 72
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->$ENTRIES:LX/0vk;

    .line 73
    .line 74
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->uploadMedium:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->mimeType:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->filename:Ljava/lang/String;

    .line 8
    .line 9
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getFilename()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->filename:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMimeType()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->mimeType:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUploadMedium()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->uploadMedium:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
