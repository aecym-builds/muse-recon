.class public final Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final file:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getFile()Ljava/io/File;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 1
    .line 2
    return-object p0
.end method
