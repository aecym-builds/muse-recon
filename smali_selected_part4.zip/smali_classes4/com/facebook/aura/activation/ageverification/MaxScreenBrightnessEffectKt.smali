.class public abstract Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final MaxScreenBrightnessEffect(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, -0x26e05440

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 17
    .line 18
    invoke-interface {p0, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    check-cast v2, Landroid/app/Activity;

    .line 23
    .line 24
    if-nez v2, :cond_2

    .line 25
    .line 26
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    new-instance v0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$activity$1;

    .line 33
    .line 34
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$activity$1;-><init>(I)V

    .line 35
    .line 36
    .line 37
    :goto_0
    check-cast v0, LX/JDN;

    .line 38
    .line 39
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 40
    .line 41
    :cond_0
    return-void

    .line 42
    :cond_1
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_2
    invoke-interface {p0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    if-nez v1, :cond_3

    .line 55
    .line 56
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 57
    .line 58
    if-ne v0, v1, :cond_4

    .line 59
    .line 60
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;

    .line 61
    .line 62
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$1$1;-><init>(Landroid/app/Activity;)V

    .line 63
    .line 64
    .line 65
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    :cond_4
    invoke-static {p0, v0, v2}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :goto_1
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    if-eqz v1, :cond_0

    .line 76
    .line 77
    new-instance v0, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$2;

    .line 78
    .line 79
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/MaxScreenBrightnessEffectKt$MaxScreenBrightnessEffect$2;-><init>(I)V

    .line 80
    .line 81
    .line 82
    goto :goto_0
.end method
