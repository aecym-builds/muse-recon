.class public final Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

.field public final synthetic $twoSided:Z

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/navigation/AuraNavigator;Z)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$twoSided:Z

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 20

    .line 268435456
    move/from16 v2, p2

    .line 268435457
    .line 268435458
    and-int/lit8 v1, p2, 0x3

    .line 268435459
    .line 268435460
    const/4 v0, 0x2

    .line 268435461
    const/4 v11, 0x1

    .line 268435462
    const/4 v13, 0x0

    .line 268435463
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 268435464
    .line 268435465
    .line 268435466
    move-result v0

    .line 268435467
    move-object/from16 v1, p1

    .line 268435468
    .line 268435469
    invoke-static {v0, v1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435470
    .line 268435471
    .line 268435472
    move-result v0

    .line 268435473
    if-eqz v0, :cond_e

    .line 268435474
    .line 268435475
    const v0, 0x7f120065

    .line 268435476
    .line 268435477
    .line 268435478
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435479
    .line 268435480
    .line 268435481
    move-result-object v6

    .line 268435482
    move-object/from16 v4, p0

    .line 268435483
    .line 268435484
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 268435485
    .line 268435486
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 268435487
    .line 268435488
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->getPhotosTitleRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I

    .line 268435489
    .line 268435490
    .line 268435491
    move-result v0

    .line 268435492
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 268435493
    .line 268435494
    .line 268435495
    move-result-object v14

    .line 268435496
    const v0, 0x7f120061

    .line 268435497
    .line 268435498
    .line 268435499
    invoke-static {v1, v6, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 268435500
    .line 268435501
    .line 268435502
    move-result-object v15

    .line 268435503
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435504
    .line 268435505
    invoke-interface {v1, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435506
    .line 268435507
    .line 268435508
    move-result v2

    .line 268435509
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 268435510
    .line 268435511
    invoke-static {v1, v0, v2}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 268435512
    .line 268435513
    .line 268435514
    move-result v2

    .line 268435515
    iget-object v5, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435516
    .line 268435517
    iget-object v3, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 268435518
    .line 268435519
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435520
    .line 268435521
    .line 268435522
    move-result-object v0

    .line 268435523
    if-nez v2, :cond_0

    .line 268435524
    .line 268435525
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435526
    .line 268435527
    if-ne v0, v2, :cond_1

    .line 268435528
    .line 268435529
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$1$1;

    .line 268435530
    .line 268435531
    invoke-direct {v0, v5, v3}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 268435532
    .line 268435533
    .line 268435534
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435535
    .line 268435536
    .line 268435537
    :cond_1
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 268435538
    .line 268435539
    const/16 p1, 0x4

    .line 268435540
    .line 268435541
    const/16 v16, 0x0

    .line 268435542
    .line 268435543
    move-object/from16 v17, v6

    .line 268435544
    .line 268435545
    move-object/from16 v18, v0

    .line 268435546
    .line 268435547
    move-object/from16 v19, v1

    .line 268435548
    .line 268435549
    move/from16 p0, v13

    .line 268435550
    .line 268435551
    invoke-static/range {v14 .. v21}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 268435552
    .line 268435553
    .line 268435554
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 268435555
    .line 268435556
    iget-boolean v10, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$twoSided:Z

    .line 268435557
    .line 268435558
    const/high16 v0, 0x3f000000    # 0.5f

    .line 268435559
    .line 268435560
    if-eqz v10, :cond_2

    .line 268435561
    .line 268435562
    const/high16 v0, 0x3f800000    # 1.0f

    .line 268435563
    .line 268435564
    :cond_2
    invoke-static {v8, v0}, LX/2sI;->A03(LX/3C1;F)LX/3C1;

    .line 268435565
    .line 268435566
    .line 268435567
    move-result-object v2

    .line 268435568
    sget-object v0, LX/1Cd;->A03:LX/1Cd;

    .line 268435569
    .line 268435570
    invoke-static {v0, v2}, LX/CT0;->A00(LX/1Cd;LX/3C1;)LX/3C1;

    .line 268435571
    .line 268435572
    .line 268435573
    move-result-object v3

    .line 268435574
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 268435575
    .line 268435576
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 268435577
    .line 268435578
    .line 268435579
    move-result-object v2

    .line 268435580
    iget-object v9, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 268435581
    .line 268435582
    iget-object v7, v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435583
    .line 268435584
    sget-object v0, LX/2Id;->A05:LX/2rU;

    .line 268435585
    .line 268435586
    invoke-static {v2, v1, v0, v13}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 268435587
    .line 268435588
    .line 268435589
    move-result-object v12

    .line 268435590
    move-object v5, v1

    .line 268435591
    check-cast v5, LX/J7I;

    .line 268435592
    .line 268435593
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 268435594
    .line 268435595
    .line 268435596
    move-result v6

    .line 268435597
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 268435598
    .line 268435599
    .line 268435600
    move-result-object v4

    .line 268435601
    invoke-static {v1, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 268435602
    .line 268435603
    .line 268435604
    move-result-object v3

    .line 268435605
    sget-object v2, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 268435606
    .line 268435607
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 268435608
    .line 268435609
    if-nez v0, :cond_3

    .line 268435610
    .line 268435611
    invoke-static {}, LX/1VY;->A00()V

    .line 268435612
    .line 268435613
    .line 268435614
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435615
    .line 268435616
    .line 268435617
    move-result-object v0

    .line 268435618
    throw v0

    .line 268435619
    :cond_3
    invoke-static {v1, v5, v2}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 268435620
    .line 268435621
    .line 268435622
    invoke-static {v1, v12, v4, v3, v6}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435623
    .line 268435624
    .line 268435625
    sget-object v6, LX/CgK;->A00:LX/CgK;

    .line 268435626
    .line 268435627
    const v14, 0x7f12005e

    .line 268435628
    .line 268435629
    .line 268435630
    if-eqz v10, :cond_4

    .line 268435631
    .line 268435632
    const v14, 0x7f12005d

    .line 268435633
    .line 268435634
    .line 268435635
    :cond_4
    iget-object v15, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 268435636
    .line 268435637
    iget-object v0, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 268435638
    .line 268435639
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModelKt;->getFrameAspect(Lcom/facebook/aura/activation/ageverification/IdDocument;)F

    .line 268435640
    .line 268435641
    .line 268435642
    move-result v16

    .line 268435643
    invoke-interface {v1, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435644
    .line 268435645
    .line 268435646
    move-result v0

    .line 268435647
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435648
    .line 268435649
    .line 268435650
    move-result-object v4

    .line 268435651
    if-nez v0, :cond_5

    .line 268435652
    .line 268435653
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435654
    .line 268435655
    if-ne v4, v0, :cond_6

    .line 268435656
    .line 268435657
    :cond_5
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$1$1;

    .line 268435658
    .line 268435659
    invoke-direct {v4, v7}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 268435660
    .line 268435661
    .line 268435662
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435663
    .line 268435664
    .line 268435665
    :cond_6
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 268435666
    .line 268435667
    invoke-interface {v1, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435668
    .line 268435669
    .line 268435670
    move-result v0

    .line 268435671
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435672
    .line 268435673
    .line 268435674
    move-result-object v3

    .line 268435675
    if-nez v0, :cond_7

    .line 268435676
    .line 268435677
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435678
    .line 268435679
    if-ne v3, v0, :cond_8

    .line 268435680
    .line 268435681
    :cond_7
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$2$1;

    .line 268435682
    .line 268435683
    invoke-direct {v3, v7}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 268435684
    .line 268435685
    .line 268435686
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435687
    .line 268435688
    .line 268435689
    :cond_8
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 268435690
    .line 268435691
    const/high16 v2, 0x3f800000    # 1.0f

    .line 268435692
    .line 268435693
    invoke-virtual {v6, v8, v2, v11}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 268435694
    .line 268435695
    .line 268435696
    move-result-object v12

    .line 268435697
    sget-object v0, LX/2sI;->A00:LX/2wD;

    .line 268435698
    .line 268435699
    invoke-interface {v12, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 268435700
    .line 268435701
    .line 268435702
    move-result-object v19

    .line 268435703
    sget v12, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->$stable:I

    .line 268435704
    .line 268435705
    shl-int/lit8 p1, v12, 0x3

    .line 268435706
    .line 268435707
    move-object/from16 p0, v1

    .line 268435708
    .line 268435709
    move/from16 p2, v13

    .line 268435710
    .line 268435711
    move-object/from16 v18, v3

    .line 268435712
    .line 268435713
    move-object/from16 v17, v4

    .line 268435714
    .line 268435715
    invoke-static/range {v14 .. v22}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoTile(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435716
    .line 268435717
    .line 268435718
    if-eqz v10, :cond_d

    .line 268435719
    .line 268435720
    const v3, 0x5f25b3cb

    .line 268435721
    .line 268435722
    .line 268435723
    invoke-interface {v1, v3}, LX/2d4;->Agj(I)V

    .line 268435724
    .line 268435725
    .line 268435726
    iget-object v15, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 268435727
    .line 268435728
    iget-object v3, v9, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 268435729
    .line 268435730
    invoke-static {v3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModelKt;->getFrameAspect(Lcom/facebook/aura/activation/ageverification/IdDocument;)F

    .line 268435731
    .line 268435732
    .line 268435733
    move-result v16

    .line 268435734
    invoke-interface {v1, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435735
    .line 268435736
    .line 268435737
    move-result v3

    .line 268435738
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435739
    .line 268435740
    .line 268435741
    move-result-object v4

    .line 268435742
    if-nez v3, :cond_9

    .line 268435743
    .line 268435744
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435745
    .line 268435746
    if-ne v4, v3, :cond_a

    .line 268435747
    .line 268435748
    :cond_9
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$3$1;

    .line 268435749
    .line 268435750
    invoke-direct {v4, v7}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 268435751
    .line 268435752
    .line 268435753
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435754
    .line 268435755
    .line 268435756
    :cond_a
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 268435757
    .line 268435758
    invoke-interface {v1, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 268435759
    .line 268435760
    .line 268435761
    move-result v9

    .line 268435762
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268435763
    .line 268435764
    .line 268435765
    move-result-object v3

    .line 268435766
    if-nez v9, :cond_b

    .line 268435767
    .line 268435768
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 268435769
    .line 268435770
    if-ne v3, v9, :cond_c

    .line 268435771
    .line 268435772
    :cond_b
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$4$1;

    .line 268435773
    .line 268435774
    invoke-direct {v3, v7}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt$IdPhotosContent$2$2$4$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 268435775
    .line 268435776
    .line 268435777
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268435778
    .line 268435779
    .line 268435780
    :cond_c
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 268435781
    .line 268435782
    invoke-virtual {v6, v8, v2, v11}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 268435783
    .line 268435784
    .line 268435785
    move-result-object v2

    .line 268435786
    invoke-interface {v2, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 268435787
    .line 268435788
    .line 268435789
    move-result-object v19

    .line 268435790
    shl-int/lit8 p1, v12, 0x3

    .line 268435791
    .line 268435792
    const v14, 0x7f12005c

    .line 268435793
    .line 268435794
    .line 268435795
    move-object/from16 v18, v3

    .line 268435796
    .line 268435797
    move-object/from16 v17, v4

    .line 268435798
    .line 268435799
    invoke-static/range {v14 .. v22}, Lcom/facebook/aura/activation/ageverification/IdPhotosContentKt;->IdPhotoTile(ILcom/facebook/aura/activation/ageverification/CapturedPhoto;FLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 268435800
    .line 268435801
    .line 268435802
    :goto_0
    invoke-static {v5, v13}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435803
    .line 268435804
    .line 268435805
    invoke-static {v5, v11}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 268435806
    .line 268435807
    .line 268435808
    return-void

    .line 268435809
    :cond_d
    const v0, 0x5f2b3ec5

    .line 268435810
    .line 268435811
    .line 268435812
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 268435813
    .line 268435814
    .line 268435815
    goto :goto_0

    .line 268435816
    :cond_e
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 268435817
    .line 268435818
    .line 268435819
    return-void
.end method
