.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final kind:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

.field public final maxBytes:Ljava/lang/Long;

.field public final required:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;Ljava/lang/Long;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->kind:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->maxBytes:Ljava/lang/Long;

    .line 10
    .line 11
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->required:Z

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final getKind()Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->kind:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMaxBytes()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->maxBytes:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRequired()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->required:Z

    .line 1
    .line 2
    return p0
.end method
