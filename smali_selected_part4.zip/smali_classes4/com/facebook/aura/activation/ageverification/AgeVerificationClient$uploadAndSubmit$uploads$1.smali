.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/util/List<",
        "+",
        "LX/2PJ<",
        "+",
        "Ljava/lang/String;",
        ">;>;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.AgeVerificationClient$uploadAndSubmit$uploads$1"
    f = "AgeVerificationClient.kt"
    l = {
        0xce
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

.field public final synthetic $captured:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/IBK<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;",
            "Ljava/io/File;",
            ">;>;"
        }
    .end annotation
.end field

.field public synthetic L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "LX/IBK<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;",
            "+",
            "Ljava/io/File;",
            ">;>;",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$captured:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$captured:Ljava/util/List;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;-><init>(Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->L$0:Ljava/lang/Object;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/util/List<",
            "LX/2PJ<",
            "Ljava/lang/String;",
            ">;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v9, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v9, LX/1EL;

    .line 3
    .line 4
    sget-object v8, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->label:I

    .line 7
    .line 8
    const/4 v7, 0x1

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    if-ne v0, v7, :cond_3

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-object p1

    .line 17
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$captured:Ljava/util/List;

    .line 21
    .line 22
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 23
    .line 24
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, LX/IBK;

    .line 43
    .line 44
    iget-object v3, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 47
    .line 48
    iget-object v2, v0, LX/IBK;->second:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v2, Ljava/io/File;

    .line 51
    .line 52
    const/4 v1, 0x0

    .line 53
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;

    .line 54
    .line 55
    invoke-direct {v0, v6, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;Ljava/io/File;LX/2M4;)V

    .line 56
    .line 57
    .line 58
    invoke-static {v0, v9}, LX/3Rp;->A14(LX/JDN;LX/1EL;)LX/ERe;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_2
    const/4 v0, 0x0

    .line 67
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->L$0:Ljava/lang/Object;

    .line 68
    .line 69
    iput v7, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;->label:I

    .line 70
    .line 71
    invoke-static {v5, p0}, LX/Dvd;->A00(Ljava/util/Collection;LX/2M4;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    if-ne p1, v8, :cond_0

    .line 76
    .line 77
    return-object v8

    .line 78
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    throw v0
.end method
