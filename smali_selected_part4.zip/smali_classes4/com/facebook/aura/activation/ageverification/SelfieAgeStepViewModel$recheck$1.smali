.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.SelfieAgeStepViewModel$recheck$1"
    f = "SelfieAgeStepViewModel.kt"
    l = {
        0x19d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    if-ne v0, v4, :cond_f

    .line 8
    .line 9
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v6

    .line 13
    :cond_0
    instance-of v0, v6, LX/2PH;

    .line 14
    .line 15
    const/4 v5, 0x0

    .line 16
    move-object v2, v6

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    move-object v2, v5

    .line 20
    :cond_1
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 21
    .line 22
    if-eqz v2, :cond_d

    .line 23
    .line 24
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 25
    .line 26
    :goto_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 27
    .line 28
    if-eq v1, v0, :cond_2

    .line 29
    .line 30
    const-string v1, "not_eligible"

    .line 31
    .line 32
    if-nez v2, :cond_4

    .line 33
    .line 34
    invoke-static {v6}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    :goto_1
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_4

    .line 49
    .line 50
    :cond_2
    :goto_2
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 51
    .line 52
    return-object v1

    .line 53
    :cond_3
    move-object v0, v5

    .line 54
    goto :goto_1

    .line 55
    :cond_4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 56
    .line 57
    invoke-static {v6}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-nez v0, :cond_c

    .line 62
    .line 63
    check-cast v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 64
    .line 65
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->headMovements:LX/Ddn;

    .line 66
    .line 67
    iput-object v0, v2, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->headMovements:LX/Ddn;

    .line 68
    .line 69
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 70
    .line 71
    if-eqz v0, :cond_5

    .line 72
    .line 73
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 74
    .line 75
    if-nez v0, :cond_6

    .line 76
    .line 77
    :cond_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 78
    .line 79
    :cond_6
    iput-object v0, v2, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 80
    .line 81
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 82
    .line 83
    sget-object v1, Lcom/facebook/aura/user/provider/AgeCheckMethod;->SELFIE:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 84
    .line 85
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->retriesLeft:Ljava/lang/Integer;

    .line 86
    .line 87
    invoke-virtual {v3, v1, v6, v0}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->logResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;Ljava/lang/Integer;)V

    .line 88
    .line 89
    .line 90
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 91
    .line 92
    if-eqz v0, :cond_b

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    packed-switch v0, :pswitch_data_0

    .line 99
    .line 100
    .line 101
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 102
    .line 103
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 104
    .line 105
    .line 106
    throw v0

    .line 107
    :pswitch_0
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$confirmed(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;)V

    .line 108
    .line 109
    .line 110
    goto :goto_2

    .line 111
    :pswitch_1
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 112
    .line 113
    if-eqz v0, :cond_7

    .line 114
    .line 115
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 116
    .line 117
    if-nez v0, :cond_8

    .line 118
    .line 119
    :cond_7
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 120
    .line 121
    :cond_8
    invoke-static {v2, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$confirm(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V

    .line 122
    .line 123
    .line 124
    goto :goto_2

    .line 125
    :pswitch_2
    iget-object v1, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 126
    .line 127
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 128
    .line 129
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v0

    .line 133
    if-eqz v0, :cond_b

    .line 134
    .line 135
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 136
    .line 137
    if-eqz v0, :cond_9

    .line 138
    .line 139
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 140
    .line 141
    :cond_9
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 142
    .line 143
    if-eq v5, v0, :cond_a

    .line 144
    .line 145
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->_state:LX/2J2;

    .line 146
    .line 147
    sget-object v2, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECAPTURE:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 148
    .line 149
    const/4 v1, 0x0

    .line 150
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;

    .line 151
    .line 152
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;Z)V

    .line 153
    .line 154
    .line 155
    invoke-static {v3, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_2

    .line 159
    :pswitch_3
    iget-object v1, v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 160
    .line 161
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 162
    .line 163
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result v0

    .line 167
    if-eqz v0, :cond_b

    .line 168
    .line 169
    :cond_a
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$showIntro(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;)V

    .line 170
    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_b
    :pswitch_4
    invoke-static {v2, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$otherMethodsFallback(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Z)V

    .line 174
    .line 175
    .line 176
    goto :goto_2

    .line 177
    :cond_c
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    if-eqz v0, :cond_2

    .line 186
    .line 187
    :pswitch_5
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->access$resolved(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;)V

    .line 188
    .line 189
    .line 190
    goto/16 :goto_2

    .line 191
    .line 192
    :cond_d
    move-object v1, v5

    .line 193
    goto/16 :goto_0

    .line 194
    .line 195
    :cond_e
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 199
    .line 200
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$recheck$1;->label:I

    .line 201
    .line 202
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->status-IoAF18A(LX/2M4;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    if-ne v6, v1, :cond_0

    .line 207
    .line 208
    return-object v1

    .line 209
    :cond_f
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    throw v0

    .line 214
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_4
        :pswitch_5
        :pswitch_3
        :pswitch_1
        :pswitch_0
        :pswitch_2
        :pswitch_4
        :pswitch_4
    .end packed-switch
.end method
