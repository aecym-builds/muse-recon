.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$resolve$1"
    f = "IdAgeStepViewModel.kt"
    l = {
        0x1b8,
        0x1bd
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x2

    .line 5
    const/4 v4, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    if-eqz v0, :cond_5

    .line 8
    .line 9
    if-eq v0, v4, :cond_6

    .line 10
    .line 11
    if-ne v0, v5, :cond_10

    .line 12
    .line 13
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    :cond_0
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 18
    .line 19
    invoke-static {v5}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_a

    .line 24
    .line 25
    check-cast v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 26
    .line 27
    iget-object v4, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 28
    .line 29
    if-eqz v4, :cond_4

    .line 30
    .line 31
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/AttemptView;->updatedTime:Ljava/lang/Long;

    .line 32
    .line 33
    :goto_0
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 36
    .line 37
    if-ne v1, v0, :cond_1

    .line 38
    .line 39
    move-object v2, v3

    .line 40
    :cond_1
    iput-object v2, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->previousAttemptTime:Ljava/lang/Long;

    .line 41
    .line 42
    if-eqz v4, :cond_2

    .line 43
    .line 44
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 45
    .line 46
    if-nez v0, :cond_3

    .line 47
    .line 48
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 49
    .line 50
    :cond_3
    iput-object v0, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 51
    .line 52
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 53
    .line 54
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 55
    .line 56
    invoke-virtual {v1, v0, v5, v3}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->logResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;Ljava/lang/Integer;)V

    .line 57
    .line 58
    .line 59
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 60
    .line 61
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 62
    .line 63
    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 68
    .line 69
    if-eqz v0, :cond_e

    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    packed-switch v0, :pswitch_data_0

    .line 76
    .line 77
    .line 78
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 79
    .line 80
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 81
    .line 82
    .line 83
    throw v0

    .line 84
    :cond_4
    move-object v2, v3

    .line 85
    goto :goto_0

    .line 86
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 90
    .line 91
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 92
    .line 93
    if-nez v0, :cond_7

    .line 94
    .line 95
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 100
    .line 101
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1$1;

    .line 102
    .line 103
    invoke-direct {v0, v1, v3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 104
    .line 105
    .line 106
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->label:I

    .line 107
    .line 108
    invoke-static {p0, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    if-ne v0, v6, :cond_7

    .line 113
    .line 114
    return-object v6

    .line 115
    :cond_6
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :cond_7
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 119
    .line 120
    iput v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->label:I

    .line 121
    .line 122
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->status-IoAF18A(LX/2M4;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    if-ne v5, v6, :cond_0

    .line 127
    .line 128
    return-object v6

    .line 129
    :pswitch_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 130
    .line 131
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$resolved(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 132
    .line 133
    .line 134
    goto :goto_2

    .line 135
    :pswitch_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 136
    .line 137
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$confirmed(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 138
    .line 139
    .line 140
    goto :goto_2

    .line 141
    :pswitch_2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 142
    .line 143
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 144
    .line 145
    if-eqz v0, :cond_8

    .line 146
    .line 147
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 148
    .line 149
    if-nez v0, :cond_9

    .line 150
    .line 151
    :cond_8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 152
    .line 153
    :cond_9
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$review(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V

    .line 154
    .line 155
    .line 156
    goto :goto_2

    .line 157
    :cond_a
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    const-string v0, "not_eligible"

    .line 162
    .line 163
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result v0

    .line 167
    if-eqz v0, :cond_b

    .line 168
    .line 169
    invoke-static {v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$resolved(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 170
    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_b
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 174
    .line 175
    sget-object v2, Lcom/facebook/aura/activation/ageverification/RetryAction;->REFRESH:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 176
    .line 177
    goto :goto_1

    .line 178
    :pswitch_3
    if-eqz v1, :cond_e

    .line 179
    .line 180
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 181
    .line 182
    if-eqz v0, :cond_c

    .line 183
    .line 184
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 185
    .line 186
    :cond_c
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 187
    .line 188
    if-ne v3, v2, :cond_d

    .line 189
    .line 190
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 191
    .line 192
    sget-object v2, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECAPTURE:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 193
    .line 194
    :goto_1
    const/4 v1, 0x0

    .line 195
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 196
    .line 197
    invoke-direct {v0, v2, v1, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 198
    .line 199
    .line 200
    invoke-static {v3, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    :goto_2
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 204
    .line 205
    return-object v6

    .line 206
    :pswitch_4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 207
    .line 208
    if-eqz v1, :cond_f

    .line 209
    .line 210
    :cond_d
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$restart(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 211
    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_e
    :pswitch_5
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 215
    .line 216
    :cond_f
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$unavailable(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 217
    .line 218
    .line 219
    goto :goto_2

    .line 220
    :cond_10
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    throw v0

    .line 225
    nop

    .line 226
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_5
        :pswitch_0
        :pswitch_4
        :pswitch_2
        :pswitch_1
        :pswitch_3
        :pswitch_5
        :pswitch_5
    .end packed-switch
.end method
