.class public abstract Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CARD_STEADY_MS:J = 0x1f4L

.field public static final DOCUMENT_LOST_MS:J = 0x190L

.field public static final MAX_PORTRAIT_HEIGHT_IN_FRAME:F = 0.5f

.field public static final MIN_PORTRAIT_HEIGHT_IN_FRAME:F = 0.2f

.field public static final MIN_PORTRAIT_HEIGHT_IN_PASSPORT:F = 0.1f

.field public static final STEADY_MS:J = 0x12cL

.field public static final STEADY_TOLERANCE:F = 0.03f

.field public static final TAG:Ljava/lang/String; = "IdAgeStepViewModel"


# direct methods
.method public static final getFrameAspect(Lcom/facebook/aura/activation/ageverification/IdDocument;)F
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/activation/ageverification/IdDocument;->PASSPORT:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 5
    .line 6
    const v0, 0x3fcafa98

    .line 7
    .line 8
    .line 9
    if-ne p0, v1, :cond_0

    .line 10
    .line 11
    const v0, 0x3f35d174

    .line 12
    .line 13
    .line 14
    :cond_0
    return v0
.end method
