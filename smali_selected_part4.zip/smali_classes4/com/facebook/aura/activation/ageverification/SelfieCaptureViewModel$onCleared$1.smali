.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onCleared$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onCleared$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$onCleared$1;->this$0:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 3
    .line 4
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->context:Landroid/content/Context;

    .line 5
    .line 6
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->userId:Ljava/lang/String;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 9
    .line 10
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->clear(Landroid/content/Context;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
