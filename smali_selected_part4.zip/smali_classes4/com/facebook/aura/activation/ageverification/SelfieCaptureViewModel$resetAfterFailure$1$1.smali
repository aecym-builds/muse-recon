.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$resetAfterFailure$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $it:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$resetAfterFailure$1$1;->$it:Ljava/io/File;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel$resetAfterFailure$1$1;->$it:Ljava/io/File;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    .line 3
    .line 4
    .line 5
    return-void
.end method
