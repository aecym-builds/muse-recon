.class public final Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $request:LX/166;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $requestedAtMs$delegate:LX/2kB;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/app/Activity;LX/166;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;LX/2kB;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/app/Activity;",
            "LX/166<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2kB;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$activity:Landroid/app/Activity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$request:LX/166;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$requestedAtMs$delegate:LX/2kB;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$context:Landroid/content/Context;

    .line 11
    .line 12
    invoke-virtual {v1, v0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->openAppSettings(Landroid/content/Context;)Z

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$activity:Landroid/app/Activity;

    .line 19
    .line 20
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->showsCameraRationale(Landroid/app/Activity;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 25
    .line 26
    .line 27
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$requestedAtMs$delegate:LX/2kB;

    .line 28
    .line 29
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 30
    .line 31
    .line 32
    move-result-wide v0

    .line 33
    invoke-interface {v2, v0, v1}, LX/2kB;->AeA(J)V

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;->$request:LX/166;

    .line 37
    .line 38
    const-string v0, "android.permission.CAMERA"

    .line 39
    .line 40
    invoke-virtual {v1, v0}, LX/13y;->A02(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method
