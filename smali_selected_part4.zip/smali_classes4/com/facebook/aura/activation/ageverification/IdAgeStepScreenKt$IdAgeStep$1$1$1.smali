.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $currentOnBack$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnOtherMethods$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnResolved$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnUnavailable$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnBack$delegate:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnUnavailable$delegate:LX/16A;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v2

    .line 268435460
    const/4 v0, 0x0

    .line 268435461
    if-eq v2, v0, :cond_3

    .line 268435462
    .line 268435463
    const/4 v0, 0x1

    .line 268435464
    if-eq v2, v0, :cond_2

    .line 268435465
    .line 268435466
    const/4 v1, 0x2

    .line 268435467
    if-eq v2, v1, :cond_1

    .line 268435468
    .line 268435469
    const/4 v1, 0x3

    .line 268435470
    if-eq v2, v1, :cond_0

    .line 268435471
    .line 268435472
    const/4 v1, 0x4

    .line 268435473
    if-ne v2, v1, :cond_4

    .line 268435474
    .line 268435475
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 268435476
    .line 268435477
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435478
    .line 268435479
    .line 268435480
    move-result-object v2

    .line 268435481
    check-cast v2, LX/JDN;

    .line 268435482
    .line 268435483
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435484
    .line 268435485
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 268435486
    .line 268435487
    :goto_0
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 268435488
    .line 268435489
    .line 268435490
    move-result-object v0

    .line 268435491
    invoke-interface {v2, v1, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435492
    .line 268435493
    .line 268435494
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435495
    .line 268435496
    return-object v0

    .line 268435497
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 268435498
    .line 268435499
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435500
    .line 268435501
    .line 268435502
    move-result-object v2

    .line 268435503
    check-cast v2, LX/JDN;

    .line 268435504
    .line 268435505
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435506
    .line 268435507
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 268435508
    .line 268435509
    const/4 v0, 0x0

    .line 268435510
    goto :goto_0

    .line 268435511
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnUnavailable$delegate:LX/16A;

    .line 268435512
    .line 268435513
    invoke-static {v0}, LX/16A;->A09(LX/16A;)V

    .line 268435514
    .line 268435515
    .line 268435516
    goto :goto_1

    .line 268435517
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 268435518
    .line 268435519
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 268435520
    .line 268435521
    .line 268435522
    move-result-object v2

    .line 268435523
    check-cast v2, LX/JDN;

    .line 268435524
    .line 268435525
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 268435526
    .line 268435527
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435528
    .line 268435529
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leftReviewPending:Z

    .line 268435530
    .line 268435531
    goto :goto_0

    .line 268435532
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$currentOnBack$delegate:LX/16A;

    .line 268435533
    .line 268435534
    invoke-static {v0}, LX/16A;->A09(LX/16A;)V

    .line 268435535
    .line 268435536
    .line 268435537
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435538
    .line 268435539
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onShown()V

    .line 268435540
    .line 268435541
    .line 268435542
    goto :goto_1

    .line 268435543
    :cond_4
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 268435544
    .line 268435545
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 268435546
    .line 268435547
    .line 268435548
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;->emit(Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
