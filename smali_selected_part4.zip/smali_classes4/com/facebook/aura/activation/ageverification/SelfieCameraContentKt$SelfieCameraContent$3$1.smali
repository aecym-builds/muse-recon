.class public final Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.SelfieCameraContentKt$SelfieCameraContent$3$1"
    f = "SelfieCameraContent.kt"
    l = {
        0x66
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $camera:Lcom/facebook/aura/activation/ageverification/SelfieCamera;

.field public final synthetic $haptics:LX/1sR;

.field public final synthetic $step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieStep;LX/1sR;Lcom/facebook/aura/activation/ageverification/SelfieCamera;Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieStep;",
            "LX/1sR;",
            "Lcom/facebook/aura/activation/ageverification/SelfieCamera;",
            "Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$haptics:LX/1sR;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/SelfieCamera;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$haptics:LX/1sR;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/SelfieCamera;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieStep;LX/1sR;Lcom/facebook/aura/activation/ageverification/SelfieCamera;Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_4

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    :goto_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v4

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 19
    .line 20
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$haptics:LX/1sR;

    .line 25
    .line 26
    sget v0, Lcom/facebook/aura/vds/compose/accessibility/AuraHaptics;->SEGMENT_SWITCH:I

    .line 27
    .line 28
    invoke-interface {v1, v0}, LX/1sR;->AYC(I)V

    .line 29
    .line 30
    .line 31
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/SelfieCamera;

    .line 32
    .line 33
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/SelfieStep;

    .line 34
    .line 35
    check-cast v1, Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;

    .line 38
    .line 39
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->label:I

    .line 40
    .line 41
    invoke-static {v2, v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt;->recordSelfie(Lcom/facebook/aura/activation/ageverification/SelfieCamera;Lcom/facebook/aura/activation/ageverification/SelfieStep$Recording;Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/2M4;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-ne v0, v4, :cond_0

    .line 46
    .line 47
    return-object v4

    .line 48
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieStep$Finishing;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieStep$Finishing;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCameraContentKt$SelfieCameraContent$3$1;->$haptics:LX/1sR;

    .line 57
    .line 58
    sget v0, Lcom/facebook/aura/vds/compose/accessibility/AuraHaptics;->SUCCESS:I

    .line 59
    .line 60
    invoke-interface {v1, v0}, LX/1sR;->AYC(I)V

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieStep$Positioning;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieStep$Positioning;

    .line 65
    .line 66
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_0

    .line 71
    .line 72
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/SelfieStep$Complete;

    .line 73
    .line 74
    if-nez v0, :cond_0

    .line 75
    .line 76
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 77
    .line 78
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    throw v0
.end method
