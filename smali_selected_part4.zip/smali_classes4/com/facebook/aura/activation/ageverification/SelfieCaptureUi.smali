.class public final Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final actionRes:Ljava/lang/Integer;

.field public final bodyIsError:Z

.field public final bodyRes:Ljava/lang/Integer;

.field public final titleRes:I


# direct methods
.method public constructor <init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Integer;ZLjava/lang/Integer;ILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p5, p3}, LX/006;->A1X(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    and-int/lit8 v0, p5, 0x8

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    const/4 p4, 0x0

    .line 268435465
    :cond_0
    invoke-direct {p0, p1, p2, v1, p4}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 268435466
    .line 268435467
    .line 268435468
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;ILjava/lang/Integer;ZLjava/lang/Integer;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 23
    .line 24
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 25
    .line 26
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 1
    .line 2
    return p0
.end method

.method public final component2()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(ILjava/lang/Integer;ZLjava/lang/Integer;)Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;-><init>(ILjava/lang/Integer;ZLjava/lang/Integer;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 27
    .line 28
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 29
    .line 30
    if-ne v1, v0, :cond_0

    .line 31
    .line 32
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 33
    .line 34
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_1

    .line 41
    .line 42
    :cond_0
    return v2

    .line 43
    :cond_1
    return v3
.end method

.method public final getActionRes()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBodyIsError()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getBodyRes()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitleRes()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->titleRes:I

    .line 1
    .line 2
    mul-int/lit8 v1, v0, 0x1f

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyRes:Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    add-int/2addr v1, v0

    .line 11
    mul-int/lit8 v1, v1, 0x1f

    .line 12
    .line 13
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->bodyIsError:Z

    .line 14
    .line 15
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieCaptureUi;->actionRes:Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    add-int/2addr v1, v0

    .line 26
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
