.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3C1;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;->$state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/3C1;

    .line 1
    .line 2
    check-cast p2, LX/2d4;

    .line 3
    .line 4
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;->invoke(LX/3C1;LX/2d4;I)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke(LX/3C1;LX/2d4;I)V
    .locals 7

    .line 268435456
    const/4 v6, 0x0

    .line 268435457
    move-object v3, p1

    .line 268435458
    invoke-static {p1, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435459
    .line 268435460
    .line 268435461
    and-int/lit8 v0, p3, 0x6

    .line 268435462
    .line 268435463
    move-object v4, p2

    .line 268435464
    if-nez v0, :cond_0

    .line 268435465
    .line 268435466
    invoke-static {p2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 268435467
    .line 268435468
    .line 268435469
    move-result v0

    .line 268435470
    or-int/2addr p3, v0

    .line 268435471
    :cond_0
    invoke-static {p3}, LX/005;->A1G(I)Z

    .line 268435472
    .line 268435473
    .line 268435474
    move-result v0

    .line 268435475
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 268435476
    .line 268435477
    .line 268435478
    move-result v0

    .line 268435479
    if-eqz v0, :cond_1

    .line 268435480
    .line 268435481
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;->$state:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 268435482
    .line 268435483
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 268435484
    .line 268435485
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStepContent$4;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 268435486
    .line 268435487
    sget v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->$stable:I

    .line 268435488
    .line 268435489
    sget v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->$stable:I

    .line 268435490
    .line 268435491
    shl-int/lit8 v0, v0, 0x3

    .line 268435492
    .line 268435493
    or-int/2addr v5, v0

    .line 268435494
    shl-int/lit8 v0, p3, 0x6

    .line 268435495
    .line 268435496
    and-int/lit16 v0, v0, 0x380

    .line 268435497
    .line 268435498
    or-int/2addr v5, v0

    .line 268435499
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V

    .line 268435500
    .line 268435501
    .line 268435502
    return-void

    .line 268435503
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 268435504
    .line 268435505
    .line 268435506
    return-void
.end method
