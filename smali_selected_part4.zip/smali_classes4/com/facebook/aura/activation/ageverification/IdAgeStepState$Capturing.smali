.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final busy:Z

.field public final photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

.field public final side:Lcom/facebook/aura/activation/ageverification/IdSide;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->$stable:I

    .line 1
    .line 2
    or-int/2addr v0, v0

    .line 3
    sput v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->$stable:I

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 9
    .line 10
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getBusy()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getPhotos()Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSide()Lcom/facebook/aura/activation/ageverification/IdSide;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 1
    .line 2
    return-object p0
.end method
