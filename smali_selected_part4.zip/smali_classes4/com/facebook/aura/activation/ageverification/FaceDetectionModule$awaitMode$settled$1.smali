.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/activation/ageverification/ModuleLoad;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.FaceDetectionModule$awaitMode$settled$1"
    f = "FaceDetectionModule.kt"
    l = {
        0x87
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ModuleLoad;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;

    .line 268435457
    .line 268435458
    invoke-direct {p1, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435464
    .line 268435465
    .line 268435466
    move-result-object p0

    .line 268435467
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-object p1

    .line 13
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->moduleLoad:LX/2J2;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    new-instance v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;

    .line 20
    .line 21
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;-><init>(LX/2M4;)V

    .line 22
    .line 23
    .line 24
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1;->label:I

    .line 25
    .line 26
    invoke-static {p0, v0, v2}, LX/IxD;->A00(LX/2M4;LX/JDN;LX/2Lw;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    if-ne p1, v4, :cond_0

    .line 31
    .line 32
    return-object v4

    .line 33
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    throw v0
.end method
