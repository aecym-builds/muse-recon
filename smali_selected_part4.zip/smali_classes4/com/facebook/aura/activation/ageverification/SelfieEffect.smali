.class public interface abstract Lcom/facebook/aura/activation/ageverification/SelfieEffect;
.super Ljava/lang/Object;
.source ""
