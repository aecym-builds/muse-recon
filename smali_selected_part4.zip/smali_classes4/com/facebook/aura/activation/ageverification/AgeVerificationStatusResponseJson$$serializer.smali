.class public final synthetic Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x5

    .line 8
    const-string v0, "com.facebook.aura.activation.ageverification.AgeVerificationStatusResponseJson"

    .line 9
    .line 10
    new-instance v2, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "state"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "methods"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "attempt"

    .line 27
    .line 28
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    const-string v0, "retries_left"

    .line 32
    .line 33
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 34
    .line 35
    .line 36
    const-string v0, "selfie_head_movements"

    .line 37
    .line 38
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 39
    .line 40
    .line 41
    sput-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 42
    .line 43
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    sget-object p0, LX/DYp;->A01:LX/DYp;

    .line 3
    .line 4
    invoke-static {v0}, LX/3Rq;->A1L([Lkotlin/Lazy;)LX/DZ7;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;

    .line 9
    .line 10
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    sget-object v0, LX/DYo;->A00:LX/DYo;

    .line 15
    .line 16
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    sget-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

    .line 21
    .line 22
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    filled-new-array {p0, v3, v2, v1, v0}, [LX/DZ7;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;
    .locals 15

    .line 0
    const/4 v8, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v7}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    sget-object v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 13
    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v3, 0x4

    .line 16
    const/4 v2, 0x2

    .line 17
    const/4 v1, 0x1

    .line 18
    const/4 v11, 0x0

    .line 19
    move-object v12, v11

    .line 20
    move-object v13, v11

    .line 21
    move-object v14, v11

    .line 22
    move-object p0, v11

    .line 23
    const/4 v10, 0x0

    .line 24
    :goto_0
    invoke-interface {v6, v7}, LX/Da7;->A8S(LX/Da5;)I

    .line 25
    .line 26
    .line 27
    move-result v9

    .line 28
    const/4 v0, -0x1

    .line 29
    if-eq v9, v0, :cond_5

    .line 30
    .line 31
    if-eqz v9, :cond_3

    .line 32
    .line 33
    if-eq v9, v1, :cond_2

    .line 34
    .line 35
    if-eq v9, v2, :cond_1

    .line 36
    .line 37
    if-eq v9, v4, :cond_0

    .line 38
    .line 39
    if-ne v9, v3, :cond_4

    .line 40
    .line 41
    sget-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

    .line 42
    .line 43
    invoke-interface {v6, v0, v7, v3}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    check-cast p0, Ljava/util/List;

    .line 48
    .line 49
    or-int/lit8 v10, v10, 0x10

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_0
    invoke-static {v7, v6, v4}, LX/3Rr;->A0R(LX/Da5;LX/Da7;I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object v14

    .line 56
    or-int/lit8 v10, v10, 0x8

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$$serializer;

    .line 60
    .line 61
    invoke-interface {v6, v0, v7, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v13

    .line 65
    check-cast v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 66
    .line 67
    or-int/lit8 v10, v10, 0x4

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_2
    invoke-static {v7, v6, v5, v1}, LX/3Rs;->A0j(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 71
    .line 72
    .line 73
    move-result-object v12

    .line 74
    or-int/lit8 v10, v10, 0x2

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_3
    invoke-interface {v6, v7, v8}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v11

    .line 81
    or-int/lit8 v10, v10, 0x1

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_4
    new-instance v0, Lkotlinx/serialization/UnknownFieldException;

    .line 85
    .line 86
    invoke-direct {v0, v9}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 87
    .line 88
    .line 89
    throw v0

    .line 90
    :cond_5
    invoke-interface {v6, v7}, LX/Da7;->AAi(LX/Da5;)V

    .line 91
    .line 92
    .line 93
    const/16 p1, 0x0

    .line 94
    .line 95
    new-instance v9, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 96
    .line 97
    invoke-direct/range {v9 .. v16}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;-><init>(ILjava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/Integer;Ljava/util/List;LX/5Xm;)V

    .line 98
    .line 99
    .line 100
    return-object v9
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->descriptor:LX/Da5;

    .line 268435460
    .line 268435461
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 268435462
    .line 268435463
    .line 268435464
    move-result-object v0

    .line 268435465
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;LX/Da8;LX/Da5;)V

    .line 268435466
    .line 268435467
    .line 268435468
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
