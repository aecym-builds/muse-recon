.class public final Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CcW;",
        "LX/CcV;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $granted$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;->$granted$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/CcW;)LX/CcV;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;->$granted$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 7
    .line 8
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;->$context:Landroid/content/Context;

    .line 9
    .line 10
    const-string v0, "android.permission.CAMERA"

    .line 11
    .line 12
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {v0, v3}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1$invoke$$inlined$onPauseOrDispose$1;

    .line 20
    .line 21
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1$invoke$$inlined$onPauseOrDispose$1;-><init>(LX/CcW;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CcW;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;->invoke(LX/CcW;)LX/CcV;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
