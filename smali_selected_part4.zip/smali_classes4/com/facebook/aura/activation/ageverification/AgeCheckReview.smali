.class public final Lcom/facebook/aura/activation/ageverification/AgeCheckReview;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final getHttpResponseCode(Ljava/lang/Throwable;)Ljava/lang/Integer;
    .locals 1

    .line 0
    instance-of p0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->httpResponseCode:I

    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    :cond_0
    return-object v0
.end method

.method private final isTransient(Ljava/lang/Throwable;)Z
    .locals 2

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 1
    .line 2
    if-eqz v0, :cond_2

    .line 3
    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 5
    .line 6
    :goto_0
    const/4 p0, 0x0

    .line 7
    if-eqz p1, :cond_1

    .line 8
    .line 9
    iget v1, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->httpResponseCode:I

    .line 10
    .line 11
    const/16 v0, 0x1f4

    .line 12
    .line 13
    if-ge v1, v0, :cond_0

    .line 14
    .line 15
    if-gtz v1, :cond_1

    .line 16
    .line 17
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->problemType:Ljava/lang/String;

    .line 18
    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    :cond_0
    const/4 p0, 0x1

    .line 22
    :cond_1
    return p0

    .line 23
    :cond_2
    const/4 p1, 0x0

    .line 24
    goto :goto_0
.end method


# virtual methods
.method public final awaitResult(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;JLjava/lang/Long;ZLX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "J",
            "Ljava/lang/Long;",
            "Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ReviewResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p4

    .line 1
    .line 2
    move/from16 v8, p5

    .line 3
    .line 4
    move-object/from16 v4, p6

    .line 5
    .line 6
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;

    .line 7
    .line 8
    if-eqz v0, :cond_c

    .line 9
    .line 10
    move-object v7, v4

    .line 11
    check-cast v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;

    .line 12
    .line 13
    iget v2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 14
    .line 15
    const/high16 v1, -0x80000000

    .line 16
    .line 17
    and-int v0, v2, v1

    .line 18
    .line 19
    if-eqz v0, :cond_c

    .line 20
    .line 21
    sub-int/2addr v2, v1

    .line 22
    iput v2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 23
    .line 24
    :goto_0
    iget-object v1, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->result:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 27
    .line 28
    iget v0, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 29
    .line 30
    const/4 v5, 0x2

    .line 31
    const/4 v4, 0x1

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    if-eq v0, v4, :cond_2

    .line 35
    .line 36
    if-ne v0, v5, :cond_d

    .line 37
    .line 38
    iget-boolean v8, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->Z$0:Z

    .line 39
    .line 40
    iget-wide p2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->J$0:J

    .line 41
    .line 42
    iget-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$1:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v3, Ljava/lang/Number;

    .line 45
    .line 46
    iget-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$0:Ljava/lang/Object;

    .line 47
    .line 48
    :cond_0
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 52
    .line 53
    iput-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$0:Ljava/lang/Object;

    .line 54
    .line 55
    iput-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$1:Ljava/lang/Object;

    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    iput-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$2:Ljava/lang/Object;

    .line 59
    .line 60
    iput-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$3:Ljava/lang/Object;

    .line 61
    .line 62
    iput-wide p2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->J$0:J

    .line 63
    .line 64
    iput-boolean v8, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->Z$0:Z

    .line 65
    .line 66
    iput v4, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 67
    .line 68
    invoke-virtual {v1, v7}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->status-IoAF18A(LX/2M4;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v10

    .line 72
    if-ne v10, v6, :cond_3

    .line 73
    .line 74
    return-object v6

    .line 75
    :cond_2
    iget-boolean v8, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->Z$0:Z

    .line 76
    .line 77
    iget-wide p2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->J$0:J

    .line 78
    .line 79
    iget-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$1:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v3, Ljava/lang/Number;

    .line 82
    .line 83
    iget-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$0:Ljava/lang/Object;

    .line 84
    .line 85
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v10

    .line 89
    :cond_3
    invoke-static {v10}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    if-nez v2, :cond_7

    .line 94
    .line 95
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    check-cast v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 99
    .line 100
    iget-object v9, v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 101
    .line 102
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->CONFIRMED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 103
    .line 104
    if-eq v9, v0, :cond_6

    .line 105
    .line 106
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->NOT_REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 107
    .line 108
    if-eq v9, v0, :cond_6

    .line 109
    .line 110
    if-eqz v8, :cond_4

    .line 111
    .line 112
    iget-object v0, v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 113
    .line 114
    if-eqz v0, :cond_5

    .line 115
    .line 116
    :cond_4
    if-eqz v3, :cond_6

    .line 117
    .line 118
    iget-object v0, v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 119
    .line 120
    if-eqz v0, :cond_6

    .line 121
    .line 122
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->updatedTime:Ljava/lang/Long;

    .line 123
    .line 124
    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    .line 125
    .line 126
    .line 127
    move-result-wide v11

    .line 128
    if-eqz v0, :cond_6

    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 131
    .line 132
    .line 133
    move-result-wide v1

    .line 134
    cmp-long v0, v1, v11

    .line 135
    .line 136
    if-nez v0, :cond_6

    .line 137
    .line 138
    :cond_5
    const/4 v1, 0x1

    .line 139
    :goto_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 140
    .line 141
    if-eq v9, v0, :cond_9

    .line 142
    .line 143
    if-nez v1, :cond_9

    .line 144
    .line 145
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$Settled;

    .line 146
    .line 147
    invoke-direct {v0, v10}, Lcom/facebook/aura/activation/ageverification/ReviewResult$Settled;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;)V

    .line 148
    .line 149
    .line 150
    return-object v0

    .line 151
    :cond_6
    const/4 v1, 0x0

    .line 152
    goto :goto_1

    .line 153
    :cond_7
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->getHttpResponseCode(Ljava/lang/Throwable;)Ljava/lang/Integer;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    if-eqz v0, :cond_8

    .line 158
    .line 159
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 160
    .line 161
    .line 162
    move-result v1

    .line 163
    const/16 v0, 0x1ad

    .line 164
    .line 165
    if-eq v1, v0, :cond_9

    .line 166
    .line 167
    :cond_8
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->isTransient(Ljava/lang/Throwable;)Z

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    if-nez v0, :cond_9

    .line 172
    .line 173
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    const-string v0, "not_eligible"

    .line 178
    .line 179
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    if-eqz v0, :cond_e

    .line 184
    .line 185
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$NotEligible;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$NotEligible;

    .line 186
    .line 187
    return-object v0

    .line 188
    :cond_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 189
    .line 190
    .line 191
    move-result-wide v1

    .line 192
    cmp-long v0, v1, p2

    .line 193
    .line 194
    if-ltz v0, :cond_a

    .line 195
    .line 196
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$TimedOut;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$TimedOut;

    .line 197
    .line 198
    return-object v0

    .line 199
    :cond_a
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 200
    .line 201
    if-ne p1, v0, :cond_b

    .line 202
    .line 203
    const-wide/16 v1, 0x1388

    .line 204
    .line 205
    :goto_2
    iput-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$0:Ljava/lang/Object;

    .line 206
    .line 207
    iput-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$1:Ljava/lang/Object;

    .line 208
    .line 209
    const/4 v0, 0x0

    .line 210
    iput-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$2:Ljava/lang/Object;

    .line 211
    .line 212
    iput-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->L$3:Ljava/lang/Object;

    .line 213
    .line 214
    iput-wide p2, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->J$0:J

    .line 215
    .line 216
    iput-boolean v8, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->Z$0:Z

    .line 217
    .line 218
    iput v5, v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;->label:I

    .line 219
    .line 220
    invoke-static {v1, v2, v7}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    if-ne v0, v6, :cond_1

    .line 225
    .line 226
    return-object v6

    .line 227
    :cond_b
    const-wide/16 v1, 0x7d0

    .line 228
    .line 229
    goto :goto_2

    .line 230
    :cond_c
    new-instance v7, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;

    .line 231
    .line 232
    invoke-direct {v7, p0, v4}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$awaitResult$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeCheckReview;LX/2M4;)V

    .line 233
    .line 234
    .line 235
    goto/16 :goto_0

    .line 236
    .line 237
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    throw v0

    .line 242
    :cond_e
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ReviewResult$Failed;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ReviewResult$Failed;

    .line 243
    .line 244
    return-object v0
.end method

.method public final logResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;Ljava/lang/Integer;)V
    .locals 5

    .line 0
    move-object v3, p1

    .line 1
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeCheckReviewKt;->getFunnelMethod(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    :cond_0
    iget-object v0, p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    packed-switch v0, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 30
    .line 31
    .line 32
    throw v0

    .line 33
    :pswitch_0
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->VERIFIED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :pswitch_1
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    :pswitch_2
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_FINAL:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :pswitch_3
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->BLOCKED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 43
    .line 44
    :goto_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->VERIFIED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 45
    .line 46
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 47
    .line 48
    if-ne v4, v0, :cond_2

    .line 49
    .line 50
    const/4 p0, 0x0

    .line 51
    move-object p1, p0

    .line 52
    move-object p2, p0

    .line 53
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    :pswitch_4
    return-void

    .line 57
    :cond_2
    iget-object v0, p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 58
    .line 59
    const/4 p2, 0x0

    .line 60
    if-eqz v0, :cond_5

    .line 61
    .line 62
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/AttemptView;->status:Ljava/lang/String;

    .line 63
    .line 64
    :goto_1
    const-string v0, "USABILITY_ERROR"

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_4

    .line 71
    .line 72
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->USABILITY_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 73
    .line 74
    :goto_2
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->SELFIE:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 75
    .line 76
    move-object p1, p2

    .line 77
    if-ne v3, v0, :cond_3

    .line 78
    .line 79
    move-object p1, p3

    .line 80
    :cond_3
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_4
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->SYSTEM_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 85
    .line 86
    goto :goto_2

    .line 87
    :cond_5
    move-object v1, p2

    .line 88
    goto :goto_1

    .line 89
    nop

    .line 90
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_2
        :pswitch_0
        :pswitch_4
        :pswitch_4
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method

.method public final submit(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Ljava/util/Map<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "+",
            "Ljava/io/File;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SubmitOutcome;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p4, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;

    .line 1
    .line 2
    if-eqz v0, :cond_8

    .line 3
    .line 4
    move-object v3, p4

    .line 5
    check-cast v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_8

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v1, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    if-eqz v0, :cond_7

    .line 26
    .line 27
    if-ne v0, v4, :cond_9

    .line 28
    .line 29
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    :cond_0
    invoke-static {v0}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    if-eqz v2, :cond_6

    .line 38
    .line 39
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    if-eqz v1, :cond_1

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    sparse-switch v0, :sswitch_data_0

    .line 50
    .line 51
    .line 52
    :cond_1
    :goto_1
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->getHttpResponseCode(Ljava/lang/Throwable;)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    if-eqz v3, :cond_3

    .line 57
    .line 58
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    const/16 v0, 0x1ad

    .line 63
    .line 64
    if-ne v1, v0, :cond_3

    .line 65
    .line 66
    :cond_2
    sget-object v2, Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;->RATE_LIMITED:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 67
    .line 68
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 69
    .line 70
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->RATE_LIMITED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 71
    .line 72
    :goto_2
    new-instance v3, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;

    .line 73
    .line 74
    invoke-direct {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;)V

    .line 75
    .line 76
    .line 77
    return-object v3

    .line 78
    :sswitch_0
    const-string v0, "attempt_already_submitted"

    .line 79
    .line 80
    goto :goto_6

    .line 81
    :sswitch_1
    const-string v0, "not_eligible"

    .line 82
    .line 83
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_1

    .line 88
    .line 89
    sget-object v3, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$NotEligible;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SubmitOutcome$NotEligible;

    .line 90
    .line 91
    return-object v3

    .line 92
    :sswitch_2
    const-string v0, "method_not_allowed"

    .line 93
    .line 94
    goto :goto_4

    .line 95
    :sswitch_3
    const-string v0, "rate_limited"

    .line 96
    .line 97
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-nez v0, :cond_2

    .line 102
    .line 103
    goto :goto_1

    .line 104
    :sswitch_4
    const-string v0, "missing_uploads"

    .line 105
    .line 106
    goto :goto_5

    .line 107
    :sswitch_5
    const-string v0, "upload_kind_not_allowed"

    .line 108
    .line 109
    goto :goto_4

    .line 110
    :sswitch_6
    const-string v0, "submit_failed"

    .line 111
    .line 112
    goto :goto_5

    .line 113
    :sswitch_7
    const-string v0, "not_supported"

    .line 114
    .line 115
    goto :goto_4

    .line 116
    :sswitch_8
    const-string v0, "retries_exhausted"

    .line 117
    .line 118
    goto :goto_4

    .line 119
    :sswitch_9
    const-string v0, "invalid_attempt"

    .line 120
    .line 121
    goto :goto_5

    .line 122
    :sswitch_a
    const-string v0, "invalid_file"

    .line 123
    .line 124
    goto :goto_3

    .line 125
    :sswitch_b
    const-string v0, "evidence_rejected"

    .line 126
    .line 127
    :goto_3
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    if-eqz v0, :cond_1

    .line 132
    .line 133
    sget-object v2, Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;->REJECTED:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 134
    .line 135
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 136
    .line 137
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->USABILITY_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 138
    .line 139
    goto :goto_2

    .line 140
    :sswitch_c
    const-string v0, "upload_failed"

    .line 141
    .line 142
    goto :goto_5

    .line 143
    :sswitch_d
    const-string v0, "invalid_id_sides"

    .line 144
    .line 145
    goto :goto_4

    .line 146
    :sswitch_e
    const-string v0, "upload_medium_not_allowed"

    .line 147
    .line 148
    :goto_4
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-eqz v0, :cond_1

    .line 153
    .line 154
    sget-object v2, Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;->FINAL:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 155
    .line 156
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_FINAL:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 157
    .line 158
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->SYSTEM_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 159
    .line 160
    goto :goto_2

    .line 161
    :sswitch_f
    const-string v0, "invalid_file_handle"

    .line 162
    .line 163
    :goto_5
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result v0

    .line 167
    if-nez v0, :cond_4

    .line 168
    .line 169
    goto :goto_1

    .line 170
    :cond_3
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->isTransient(Ljava/lang/Throwable;)Z

    .line 171
    .line 172
    .line 173
    move-result v0

    .line 174
    if-nez v0, :cond_4

    .line 175
    .line 176
    if-eqz v3, :cond_5

    .line 177
    .line 178
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    const/16 v0, 0x191

    .line 183
    .line 184
    if-ne v1, v0, :cond_5

    .line 185
    .line 186
    :cond_4
    sget-object v2, Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;->RESEND:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 187
    .line 188
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 189
    .line 190
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->UPLOAD_FAILED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 191
    .line 192
    goto :goto_2

    .line 193
    :cond_5
    sget-object v2, Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;->FINAL:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 194
    .line 195
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 196
    .line 197
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->SYSTEM_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 198
    .line 199
    goto :goto_2

    .line 200
    :sswitch_10
    const-string v0, "attempt_in_progress"

    .line 201
    .line 202
    :goto_6
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    if-eqz v0, :cond_1

    .line 207
    .line 208
    const/4 v4, 0x0

    .line 209
    :cond_6
    new-instance v3, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Accepted;

    .line 210
    .line 211
    invoke-direct {v3, v4}, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Accepted;-><init>(Z)V

    .line 212
    .line 213
    .line 214
    return-object v3

    .line 215
    :cond_7
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 219
    .line 220
    const/4 v0, 0x0

    .line 221
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->L$0:Ljava/lang/Object;

    .line 222
    .line 223
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->L$1:Ljava/lang/Object;

    .line 224
    .line 225
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->L$2:Ljava/lang/Object;

    .line 226
    .line 227
    iput v4, v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;->label:I

    .line 228
    .line 229
    invoke-virtual {v1, p1, p2, p3, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->startAndSubmit-BWLJW6A(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    if-ne v0, v2, :cond_0

    .line 234
    .line 235
    return-object v2

    .line 236
    :cond_8
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;

    .line 237
    .line 238
    invoke-direct {v3, p0, p4}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview$submit$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeCheckReview;LX/2M4;)V

    .line 239
    .line 240
    .line 241
    goto/16 :goto_0

    .line 242
    .line 243
    :cond_9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    throw v0

    .line 248
    :sswitch_data_0
    .sparse-switch
        -0x65d3c23d -> :sswitch_1
        -0x63004a22 -> :sswitch_2
        -0x60e696c5 -> :sswitch_3
        -0x5000eb47 -> :sswitch_4
        -0x35d05d71 -> :sswitch_5
        -0x1d0179bc -> :sswitch_6
        -0xff8b1be -> :sswitch_7
        -0x88bbc70 -> :sswitch_8
        0x14a68485 -> :sswitch_9
        0x1f665ec4 -> :sswitch_a
        0x2073d966 -> :sswitch_b
        0x26cc08e2 -> :sswitch_0
        0x32d7f03b -> :sswitch_c
        0x4dbd4320 -> :sswitch_d
        0x60044595 -> :sswitch_10
        0x6a9c8570 -> :sswitch_e
        0x712ca803 -> :sswitch_f
    .end sparse-switch
.end method
