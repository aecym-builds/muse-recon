.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final showsBack:Z

.field public final showsSettings:Z

.field public final step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;ZZ)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsBack:Z

    .line 10
    .line 11
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsSettings:Z

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final getShowsBack()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsBack:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getShowsSettings()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->showsSettings:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getStep()Lcom/facebook/aura/activation/ageverification/IdAgeStepState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;->step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 1
    .line 2
    return-object p0
.end method
