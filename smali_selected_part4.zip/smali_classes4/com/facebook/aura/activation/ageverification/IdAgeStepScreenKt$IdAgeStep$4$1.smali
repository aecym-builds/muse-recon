.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/CcW;",
        "LX/CcV;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/CcW;)LX/CcV;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onResume()V

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 10
    .line 11
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;

    .line 12
    .line 13
    invoke-direct {v0, p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1$invoke$$inlined$onPauseOrDispose$1;-><init>(LX/CcW;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/CcW;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$4$1;->invoke(LX/CcW;)LX/CcV;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
