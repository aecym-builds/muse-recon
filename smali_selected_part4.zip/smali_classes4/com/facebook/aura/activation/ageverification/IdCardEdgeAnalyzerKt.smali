.class public abstract Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final EDGE_ALIGN_RATIO:F = 0.04f

.field public static final EDGE_ALONG_STEP:I = 0x3

.field public static final EDGE_BACKGROUND_RATIO:F = 3.0f

.field public static final EDGE_INSIDE_RATIO:F = 0.3f

.field public static final EDGE_OUTSIDE_RATIO:F = 0.05f

.field public static final EDGE_SEGMENTS:I = 0x4

.field public static final EDGE_STEP:I = 0x2

.field public static final MAX_CARD_ASPECT:F = 1.75f

.field public static final MIN_CARD_ASPECT:F = 1.45f

.field public static final MIN_CARD_FILL:F = 0.6f

.field public static final MIN_EDGE_CONTRAST:F = 3.0f

.field public static final MIN_SHARPNESS:F = 60.0f

.field public static final SHARPNESS_STEP:I = 0x4

.field public static final TAG:Ljava/lang/String; = "IdCardEdgeAnalyzer"


# direct methods
.method public static final synthetic access$cardEdges(Lcom/facebook/aura/activation/ageverification/UprightLuma;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->cardEdges(Lcom/facebook/aura/activation/ageverification/UprightLuma;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final cardEdges(Lcom/facebook/aura/activation/ageverification/UprightLuma;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 21

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    iget v1, v5, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 3
    .line 4
    move-object/from16 v10, p0

    .line 5
    .line 6
    iget v0, v10, Lcom/facebook/aura/activation/ageverification/UprightLuma;->width:I

    .line 7
    .line 8
    int-to-float v3, v0

    .line 9
    mul-float/2addr v1, v3

    .line 10
    float-to-int v4, v1

    .line 11
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 12
    .line 13
    iget v0, v10, Lcom/facebook/aura/activation/ageverification/UprightLuma;->height:I

    .line 14
    .line 15
    int-to-float v1, v0

    .line 16
    mul-float/2addr v2, v1

    .line 17
    float-to-int v13, v2

    .line 18
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 19
    .line 20
    mul-float/2addr v0, v3

    .line 21
    float-to-int v3, v0

    .line 22
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 23
    .line 24
    mul-float/2addr v0, v1

    .line 25
    float-to-int v14, v0

    .line 26
    sub-int v0, v3, v4

    .line 27
    .line 28
    sub-int v5, v14, v13

    .line 29
    .line 30
    int-to-float v1, v0

    .line 31
    const v2, 0x3d4ccccd    # 0.05f

    .line 32
    .line 33
    .line 34
    mul-float v0, v1, v2

    .line 35
    .line 36
    float-to-int v9, v0

    .line 37
    int-to-float v6, v5

    .line 38
    mul-float/2addr v2, v6

    .line 39
    float-to-int v5, v2

    .line 40
    const v2, 0x3e99999a    # 0.3f

    .line 41
    .line 42
    .line 43
    mul-float v0, v1, v2

    .line 44
    .line 45
    float-to-int v8, v0

    .line 46
    mul-float/2addr v2, v6

    .line 47
    float-to-int v0, v2

    .line 48
    const v2, 0x3d23d70a    # 0.04f

    .line 49
    .line 50
    .line 51
    mul-float/2addr v6, v2

    .line 52
    float-to-int v2, v6

    .line 53
    const/4 v7, 0x1

    .line 54
    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    .line 55
    .line 56
    .line 57
    move-result v15

    .line 58
    sub-int v11, v4, v9

    .line 59
    .line 60
    add-int v12, v4, v8

    .line 61
    .line 62
    move/from16 v16, v7

    .line 63
    .line 64
    invoke-static/range {v10 .. v16}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->outermostEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    const/4 v2, 0x0

    .line 69
    if-eqz v6, :cond_0

    .line 70
    .line 71
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 72
    .line 73
    .line 74
    move-result v6

    .line 75
    add-int v11, v3, v9

    .line 76
    .line 77
    sub-int v12, v3, v8

    .line 78
    .line 79
    invoke-static/range {v10 .. v16}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->outermostEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object v7

    .line 83
    if-eqz v7, :cond_0

    .line 84
    .line 85
    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    .line 86
    .line 87
    .line 88
    move-result v7

    .line 89
    sub-int v17, v13, v5

    .line 90
    .line 91
    add-int/2addr v13, v0

    .line 92
    const/16 p1, 0x0

    .line 93
    .line 94
    move-object/from16 v16, v10

    .line 95
    .line 96
    move/from16 v18, v13

    .line 97
    .line 98
    move/from16 v19, v4

    .line 99
    .line 100
    move/from16 v20, v3

    .line 101
    .line 102
    move/from16 p0, v15

    .line 103
    .line 104
    invoke-static/range {v16 .. v22}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->outermostEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    if-eqz v8, :cond_0

    .line 109
    .line 110
    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    .line 111
    .line 112
    .line 113
    move-result v8

    .line 114
    add-int v17, v14, v5

    .line 115
    .line 116
    sub-int/2addr v14, v0

    .line 117
    move/from16 v18, v14

    .line 118
    .line 119
    invoke-static/range {v16 .. v22}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->outermostEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    if-eqz v0, :cond_0

    .line 124
    .line 125
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 126
    .line 127
    .line 128
    move-result v9

    .line 129
    sub-int v4, v7, v6

    .line 130
    .line 131
    sub-int v3, v9, v8

    .line 132
    .line 133
    int-to-float v5, v4

    .line 134
    const v0, 0x3f19999a    # 0.6f

    .line 135
    .line 136
    .line 137
    mul-float/2addr v1, v0

    .line 138
    cmpg-float v0, v5, v1

    .line 139
    .line 140
    if-ltz v0, :cond_0

    .line 141
    .line 142
    if-lez v3, :cond_0

    .line 143
    .line 144
    int-to-float v0, v3

    .line 145
    div-float/2addr v5, v0

    .line 146
    const v0, 0x3fb9999a    # 1.45f

    .line 147
    .line 148
    .line 149
    cmpg-float v0, v0, v5

    .line 150
    .line 151
    if-gtz v0, :cond_0

    .line 152
    .line 153
    const/high16 v0, 0x3fe00000    # 1.75f

    .line 154
    .line 155
    cmpg-float v0, v5, v0

    .line 156
    .line 157
    if-gtz v0, :cond_0

    .line 158
    .line 159
    div-int/lit8 v1, v4, 0xa

    .line 160
    .line 161
    div-int/lit8 v0, v3, 0xa

    .line 162
    .line 163
    add-int v4, v6, v1

    .line 164
    .line 165
    add-int v3, v8, v0

    .line 166
    .line 167
    sub-int v1, v7, v1

    .line 168
    .line 169
    sub-int v0, v9, v0

    .line 170
    .line 171
    invoke-static {v10, v4, v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->sharpness(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIII)F

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    const/high16 v0, 0x42700000    # 60.0f

    .line 176
    .line 177
    cmpg-float v0, v1, v0

    .line 178
    .line 179
    if-ltz v0, :cond_0

    .line 180
    .line 181
    int-to-float v5, v6

    .line 182
    iget v0, v10, Lcom/facebook/aura/activation/ageverification/UprightLuma;->width:I

    .line 183
    .line 184
    int-to-float v4, v0

    .line 185
    div-float/2addr v5, v4

    .line 186
    int-to-float v3, v8

    .line 187
    iget v0, v10, Lcom/facebook/aura/activation/ageverification/UprightLuma;->height:I

    .line 188
    .line 189
    int-to-float v2, v0

    .line 190
    div-float/2addr v3, v2

    .line 191
    int-to-float v1, v7

    .line 192
    div-float/2addr v1, v4

    .line 193
    int-to-float v0, v9

    .line 194
    div-float/2addr v0, v2

    .line 195
    new-instance v2, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 196
    .line 197
    invoke-direct {v2, v5, v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/NormalizedRect;-><init>(FFFF)V

    .line 198
    .line 199
    .line 200
    :cond_0
    return-object v2
.end method

.method public static final outermostEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;
    .locals 12

    .line 0
    sub-int p4, p4, p3

    .line 1
    .line 2
    div-int/lit8 v3, p4, 0xa

    .line 3
    .line 4
    mul-int/lit8 v0, v3, 0x2

    .line 5
    .line 6
    sub-int p4, p4, v0

    .line 7
    .line 8
    const/4 v0, 0x4

    .line 9
    div-int p4, p4, v0

    .line 10
    .line 11
    const/4 v8, -0x1

    .line 12
    move v6, p1

    .line 13
    move v7, p2

    .line 14
    if-lt p2, p1, :cond_0

    .line 15
    .line 16
    const/4 v8, 0x1

    .line 17
    :cond_0
    const/4 v1, 0x0

    .line 18
    const/4 v4, 0x3

    .line 19
    new-instance v0, LX/34l;

    .line 20
    .line 21
    invoke-direct {v0, v1, v4}, LX/34l;-><init>(II)V

    .line 22
    .line 23
    .line 24
    new-instance v2, Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, LX/A7z;->iterator()Ljava/util/Iterator;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    move-object v0, v1

    .line 40
    check-cast v0, LX/0Xe;

    .line 41
    .line 42
    invoke-virtual {v0}, LX/0Xe;->A01()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    add-int v9, p3, v3

    .line 47
    .line 48
    mul-int v0, v0, p4

    .line 49
    .line 50
    add-int/2addr v9, v0

    .line 51
    add-int v10, v9, p4

    .line 52
    .line 53
    move-object v5, p0

    .line 54
    move/from16 v11, p6

    .line 55
    .line 56
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/activation/ageverification/IdCardEdgeAnalyzerKt;->segmentEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_2
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    const/4 v6, 0x0

    .line 71
    if-lt v0, v4, :cond_3

    .line 72
    .line 73
    invoke-static {v2}, LX/B89;->A0i(Ljava/lang/Iterable;)Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    div-int/lit8 v0, v0, 0x2

    .line 82
    .line 83
    invoke-static {v1, v0}, LX/008;->A0b(Ljava/util/List;I)I

    .line 84
    .line 85
    .line 86
    move-result v5

    .line 87
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    instance-of v0, v2, Ljava/util/Collection;

    .line 92
    .line 93
    if-eqz v0, :cond_4

    .line 94
    .line 95
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_4

    .line 100
    .line 101
    :cond_3
    return-object v6

    .line 102
    :cond_4
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    const/4 v1, 0x0

    .line 107
    :cond_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_6

    .line 112
    .line 113
    invoke-static {v2}, LX/003;->A0L(Ljava/util/Iterator;)I

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    sub-int/2addr v0, v5

    .line 118
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    move/from16 v7, p5

    .line 123
    .line 124
    if-gt v0, v7, :cond_5

    .line 125
    .line 126
    add-int/lit8 v1, v1, 0x1

    .line 127
    .line 128
    if-gez v1, :cond_5

    .line 129
    .line 130
    invoke-static {}, LX/B8B;->A19()V

    .line 131
    .line 132
    .line 133
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    throw v0

    .line 138
    :cond_6
    if-lt v1, v4, :cond_3

    .line 139
    .line 140
    return-object v3
.end method

.method public static final segmentEdge(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIIIIZ)Ljava/lang/Integer;
    .locals 11

    .line 0
    sub-int/2addr p2, p1

    .line 1
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 2
    .line 3
    .line 4
    move-result v5

    .line 5
    new-array v4, v5, [F

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    :goto_0
    const/4 v1, 0x3

    .line 9
    const/4 v3, 0x1

    .line 10
    if-ge v6, v5, :cond_5

    .line 11
    .line 12
    mul-int v10, v6, p3

    .line 13
    .line 14
    add-int/2addr v10, p1

    .line 15
    move/from16 v0, p5

    .line 16
    .line 17
    invoke-static {p4, v0}, LX/34j;->A0D(II)LX/34l;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0, v1}, LX/34j;->A0C(LX/A7z;I)LX/A7z;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iget v8, v0, LX/A7z;->A00:I

    .line 26
    .line 27
    iget v7, v0, LX/A7z;->A01:I

    .line 28
    .line 29
    iget v3, v0, LX/A7z;->A02:I

    .line 30
    .line 31
    if-lez v3, :cond_1

    .line 32
    .line 33
    if-le v8, v7, :cond_2

    .line 34
    .line 35
    :cond_0
    const/4 v1, 0x0

    .line 36
    :goto_1
    aput v1, v4, v6

    .line 37
    .line 38
    add-int/lit8 v6, v6, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    if-gez v3, :cond_0

    .line 42
    .line 43
    if-gt v7, v8, :cond_0

    .line 44
    .line 45
    :cond_2
    const/4 v1, 0x0

    .line 46
    const/4 v2, 0x0

    .line 47
    :goto_2
    add-int/lit8 v0, v10, 0x2

    .line 48
    .line 49
    if-eqz p6, :cond_3

    .line 50
    .line 51
    invoke-virtual {p0, v0, v8}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 52
    .line 53
    .line 54
    move-result v9

    .line 55
    add-int/lit8 v0, v10, -0x2

    .line 56
    .line 57
    invoke-virtual {p0, v0, v8}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    :goto_3
    sub-int/2addr v9, v0

    .line 62
    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    add-int/2addr v1, v0

    .line 67
    add-int/lit8 v2, v2, 0x1

    .line 68
    .line 69
    if-eq v8, v7, :cond_4

    .line 70
    .line 71
    add-int/2addr v8, v3

    .line 72
    goto :goto_2

    .line 73
    :cond_3
    invoke-virtual {p0, v8, v0}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 74
    .line 75
    .line 76
    move-result v9

    .line 77
    add-int/lit8 v0, v10, -0x2

    .line 78
    .line 79
    invoke-virtual {p0, v8, v0}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    goto :goto_3

    .line 84
    :cond_4
    if-eqz v2, :cond_0

    .line 85
    .line 86
    int-to-float v1, v1

    .line 87
    int-to-float v0, v2

    .line 88
    div-float/2addr v1, v0

    .line 89
    goto :goto_1

    .line 90
    :cond_5
    const/4 v8, 0x0

    .line 91
    if-lt v5, v1, :cond_b

    .line 92
    .line 93
    div-int/lit8 v0, v5, 0x6

    .line 94
    .line 95
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    const/4 v0, 0x0

    .line 100
    invoke-static {v1, v5}, LX/AdU;->A03(II)V

    .line 101
    .line 102
    .line 103
    invoke-static {v4, v0, v1}, Ljava/util/Arrays;->copyOfRange([FII)[F

    .line 104
    .line 105
    .line 106
    move-result-object v7

    .line 107
    invoke-static {v7}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    array-length v6, v7

    .line 111
    new-array v2, v6, [Ljava/lang/Float;

    .line 112
    .line 113
    const/4 v1, 0x0

    .line 114
    :goto_4
    if-ge v1, v6, :cond_6

    .line 115
    .line 116
    aget v0, v7, v1

    .line 117
    .line 118
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    aput-object v0, v2, v1

    .line 123
    .line 124
    add-int/lit8 v1, v1, 0x1

    .line 125
    .line 126
    goto :goto_4

    .line 127
    :cond_6
    if-le v6, v3, :cond_7

    .line 128
    .line 129
    invoke-static {v2}, Ljava/util/Arrays;->sort([Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    :cond_7
    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    div-int/lit8 v0, v0, 0x2

    .line 141
    .line 142
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Ljava/lang/Number;

    .line 147
    .line 148
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    const/high16 v0, 0x40400000    # 3.0f

    .line 153
    .line 154
    mul-float/2addr v1, v0

    .line 155
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    .line 156
    .line 157
    .line 158
    move-result v2

    .line 159
    :goto_5
    add-int/lit8 v1, v5, -0x1

    .line 160
    .line 161
    if-ge v3, v1, :cond_8

    .line 162
    .line 163
    aget v0, v4, v3

    .line 164
    .line 165
    cmpg-float v0, v0, v2

    .line 166
    .line 167
    if-gez v0, :cond_8

    .line 168
    .line 169
    add-int/lit8 v3, v3, 0x1

    .line 170
    .line 171
    goto :goto_5

    .line 172
    :cond_8
    if-lt v3, v1, :cond_9

    .line 173
    .line 174
    return-object v8

    .line 175
    :cond_9
    :goto_6
    add-int/lit8 v2, v3, 0x1

    .line 176
    .line 177
    if-ge v2, v5, :cond_a

    .line 178
    .line 179
    aget v1, v4, v2

    .line 180
    .line 181
    aget v0, v4, v3

    .line 182
    .line 183
    cmpl-float v0, v1, v0

    .line 184
    .line 185
    if-lez v0, :cond_a

    .line 186
    .line 187
    move v3, v2

    .line 188
    goto :goto_6

    .line 189
    :cond_a
    mul-int/2addr v3, p3

    .line 190
    add-int/2addr p1, v3

    .line 191
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 192
    .line 193
    .line 194
    move-result-object v8

    .line 195
    :cond_b
    return-object v8
.end method

.method public static final sharpness(Lcom/facebook/aura/activation/ageverification/UprightLuma;IIII)F
    .locals 15

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    move/from16 v0, p4

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/34j;->A0D(II)LX/34l;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v13, 0x4

    .line 9
    invoke-static {v0, v13}, LX/34j;->A0C(LX/A7z;I)LX/A7z;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iget v12, v0, LX/A7z;->A00:I

    .line 14
    .line 15
    iget v11, v0, LX/A7z;->A01:I

    .line 16
    .line 17
    iget v10, v0, LX/A7z;->A02:I

    .line 18
    .line 19
    const-wide/16 v6, 0x0

    .line 20
    .line 21
    if-lez v10, :cond_1

    .line 22
    .line 23
    if-le v12, v11, :cond_2

    .line 24
    .line 25
    :cond_0
    const/4 v0, 0x0

    .line 26
    return v0

    .line 27
    :cond_1
    if-gez v10, :cond_0

    .line 28
    .line 29
    if-gt v11, v12, :cond_0

    .line 30
    .line 31
    :cond_2
    const-wide/16 v4, 0x0

    .line 32
    .line 33
    const/4 v9, 0x0

    .line 34
    :goto_0
    move/from16 v1, p1

    .line 35
    .line 36
    move/from16 v0, p3

    .line 37
    .line 38
    invoke-static {v1, v0}, LX/34j;->A0D(II)LX/34l;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {v0, v13}, LX/34j;->A0C(LX/A7z;I)LX/A7z;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    iget v8, v0, LX/A7z;->A00:I

    .line 47
    .line 48
    iget v3, v0, LX/A7z;->A01:I

    .line 49
    .line 50
    iget v2, v0, LX/A7z;->A02:I

    .line 51
    .line 52
    if-lez v2, :cond_4

    .line 53
    .line 54
    if-le v8, v3, :cond_5

    .line 55
    .line 56
    :cond_3
    if-eq v12, v11, :cond_6

    .line 57
    .line 58
    add-int/2addr v12, v10

    .line 59
    goto :goto_0

    .line 60
    :cond_4
    if-gez v2, :cond_3

    .line 61
    .line 62
    if-gt v3, v8, :cond_3

    .line 63
    .line 64
    :cond_5
    :goto_1
    invoke-virtual {p0, v8, v12}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    mul-int/lit8 v14, v0, 0x4

    .line 69
    .line 70
    add-int/lit8 v0, v8, -0x1

    .line 71
    .line 72
    invoke-virtual {p0, v0, v12}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    sub-int/2addr v14, v0

    .line 77
    add-int/lit8 v0, v8, 0x1

    .line 78
    .line 79
    invoke-virtual {p0, v0, v12}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    sub-int/2addr v14, v0

    .line 84
    add-int/lit8 v0, v12, -0x1

    .line 85
    .line 86
    invoke-virtual {p0, v8, v0}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    sub-int/2addr v14, v0

    .line 91
    add-int/lit8 v0, v12, 0x1

    .line 92
    .line 93
    invoke-virtual {p0, v8, v0}, Lcom/facebook/aura/activation/ageverification/UprightLuma;->get(II)I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    sub-int/2addr v14, v0

    .line 98
    int-to-long v0, v14

    .line 99
    add-long/2addr v6, v0

    .line 100
    mul-int/2addr v14, v14

    .line 101
    int-to-long v0, v14

    .line 102
    add-long/2addr v4, v0

    .line 103
    add-int/lit8 v9, v9, 0x1

    .line 104
    .line 105
    if-eq v8, v3, :cond_3

    .line 106
    .line 107
    add-int/2addr v8, v2

    .line 108
    goto :goto_1

    .line 109
    :cond_6
    if-eqz v9, :cond_0

    .line 110
    .line 111
    long-to-float v2, v6

    .line 112
    int-to-float v1, v9

    .line 113
    div-float/2addr v2, v1

    .line 114
    long-to-float v0, v4

    .line 115
    div-float/2addr v0, v1

    .line 116
    mul-float/2addr v2, v2

    .line 117
    sub-float/2addr v0, v2

    .line 118
    return v0
.end method
