.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "Lcom/facebook/aura/activation/ageverification/ModuleLoad;",
        "LX/2M4<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.FaceDetectionModule$awaitMode$settled$1$1"
    f = "FaceDetectionModule.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->L$0:Ljava/lang/Object;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/activation/ageverification/ModuleLoad;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ModuleLoad;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    new-instance p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;

    .line 268435457
    .line 268435458
    invoke-direct {p0, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;-><init>(LX/2M4;)V

    .line 268435459
    .line 268435460
    .line 268435461
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->L$0:Ljava/lang/Object;

    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object v0

    .line 268435469
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->invoke(Lcom/facebook/aura/activation/ageverification/ModuleLoad;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$awaitMode$settled$1$1;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_2

    .line 7
    .line 8
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p0, v1, Lcom/facebook/aura/activation/ageverification/ModuleLoad;->state:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->READY:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 14
    .line 15
    if-eq p0, v0, :cond_0

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    if-ne p0, v1, :cond_1

    .line 21
    .line 22
    :cond_0
    const/4 v0, 0x1

    .line 23
    :cond_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    return-object v0

    .line 28
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    throw v0
.end method
