.class public final Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1$invoke$$inlined$onPauseOrDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CcV;


# instance fields
.field public final synthetic this$0:LX/CcW;


# direct methods
.method public constructor <init>(LX/CcW;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1$invoke$$inlined$onPauseOrDispose$1;->this$0:LX/CcW;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public runPauseOrOnDisposeEffect()V
    .locals 0

    .line 0
    return-void
.end method
