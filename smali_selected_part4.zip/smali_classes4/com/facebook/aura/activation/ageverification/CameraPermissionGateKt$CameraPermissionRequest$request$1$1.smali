.class public final Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activity:Landroid/app/Activity;

.field public final synthetic $deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onGranted:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $requestedAtMs$delegate:LX/2kB;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Landroid/app/Activity;Landroidx/compose/runtime/MutableState;LX/2kB;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/app/Activity;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2kB;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$onGranted:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$activity:Landroid/app/Activity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$requestedAtMs$delegate:LX/2kB;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->invoke(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 4

    .line 0
    if-eqz p1, :cond_1

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$onGranted:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void

    .line 8
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$rationaleBefore$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$activity:Landroid/app/Activity;

    .line 15
    .line 16
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->showsCameraRationale(Landroid/app/Activity;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$requestedAtMs$delegate:LX/2kB;

    .line 21
    .line 22
    invoke-interface {v0}, LX/2kB;->AHO()J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    invoke-static {v3, v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->isCameraBlocked(ZZJ)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;->$deniedPermanently$delegate:Landroidx/compose/runtime/MutableState;

    .line 33
    .line 34
    const/4 v0, 0x1

    .line 35
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method
