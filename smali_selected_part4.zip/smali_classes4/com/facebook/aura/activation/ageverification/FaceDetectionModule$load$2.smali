.class public final Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/H10;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<TResult:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/H10;"
    }
.end annotation


# instance fields
.field public final synthetic $appContext:Landroid/content/Context;

.field public final synthetic $request:I

.field public final synthetic $useCase:LX/H0T;


# direct methods
.method public constructor <init>(LX/H0T;Landroid/content/Context;I)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$useCase:LX/H0T;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$appContext:Landroid/content/Context;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$request:I

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final onCompleted(LX/H0g;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/H0g<",
            "LX/9h7;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, LX/H0g;->A04()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v6

    .line 8
    check-cast v6, LX/9h7;

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    if-eqz v6, :cond_1

    .line 12
    .line 13
    iget-boolean v0, v6, LX/9h7;->A04:Z

    .line 14
    .line 15
    if-ne v0, v5, :cond_1

    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$useCase:LX/H0T;

    .line 18
    .line 19
    sget-object v0, LX/H0T;->A03:LX/H0T;

    .line 20
    .line 21
    if-ne v1, v0, :cond_0

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;->DOWNLOADED:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 24
    .line 25
    sput-object v0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->source:Lcom/facebook/aura/activation/ageverification/intf/SelfieFaceModule;

    .line 26
    .line 27
    :cond_0
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 28
    .line 29
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$appContext:Landroid/content/Context;

    .line 30
    .line 31
    invoke-static {v1}, LX/I1c;->A0e(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$request:I

    .line 35
    .line 36
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->access$prepareEngine(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;Landroid/content/Context;I)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_1
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$useCase:LX/H0T;

    .line 41
    .line 42
    const/4 v4, 0x0

    .line 43
    if-eqz v6, :cond_5

    .line 44
    .line 45
    iget v0, v6, LX/9h7;->A00:I

    .line 46
    .line 47
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    iget-object v2, v6, LX/9h7;->A01:Ljava/lang/Integer;

    .line 52
    .line 53
    iget-boolean v0, v6, LX/9h7;->A03:Z

    .line 54
    .line 55
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    :goto_0
    const-string v0, "Face detection unavailable: load_failed "

    .line 60
    .line 61
    invoke-static {v1, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const-string v0, " downloadCode="

    .line 66
    .line 67
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v0, " splitInstallErrorCode="

    .line 74
    .line 75
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    const-string v0, " canRetry="

    .line 82
    .line 83
    invoke-static {v4, v0, v1}, LX/004;->A1D(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    if-eqz v6, :cond_2

    .line 88
    .line 89
    iget-object v1, v6, LX/9h7;->A02:Ljava/lang/Throwable;

    .line 90
    .line 91
    if-nez v1, :cond_3

    .line 92
    .line 93
    :cond_2
    invoke-virtual {p1}, LX/H0g;->A03()Ljava/lang/Exception;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    :cond_3
    const-string v0, "FaceDetectionModule"

    .line 98
    .line 99
    invoke-static {v0, v2, v1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 100
    .line 101
    .line 102
    sget-object v4, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->INSTANCE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;

    .line 103
    .line 104
    iget v3, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$request:I

    .line 105
    .line 106
    sget-object v2, Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;

    .line 107
    .line 108
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule$load$2;->$useCase:LX/H0T;

    .line 109
    .line 110
    sget-object v0, LX/H0T;->A03:LX/H0T;

    .line 111
    .line 112
    if-eq v1, v0, :cond_4

    .line 113
    .line 114
    const/4 v5, 0x0

    .line 115
    :cond_4
    invoke-static {v4, v3, v2, v5}, Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;->access$settle(Lcom/facebook/aura/activation/ageverification/FaceDetectionModule;ILcom/facebook/aura/activation/ageverification/FaceDetectionModuleState;Z)V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :cond_5
    move-object v3, v4

    .line 120
    move-object v2, v4

    .line 121
    goto :goto_0
.end method
