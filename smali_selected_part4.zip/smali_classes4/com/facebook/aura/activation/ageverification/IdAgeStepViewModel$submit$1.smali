.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepViewModel$submit$1"
    f = "IdAgeStepViewModel.kt"
    l = {
        0x1e7
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $files:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Ljava/util/Map;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;",
            "Ljava/util/Map<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "+",
            "Ljava/io/File;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$files:Ljava/util/Map;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$files:Ljava/util/Map;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Ljava/util/Map;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    const/4 v4, 0x0

    .line 6
    if-eqz v0, :cond_7

    .line 7
    .line 8
    if-ne v0, v5, :cond_a

    .line 9
    .line 10
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome;

    .line 14
    .line 15
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Accepted;

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptSubmitted(Lcom/facebook/aura/user/provider/AgeCheckMethod;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 28
    .line 29
    iput-boolean v5, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submitted:Z

    .line 30
    .line 31
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$clearFiles(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 32
    .line 33
    .line 34
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Accepted;

    .line 35
    .line 36
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Accepted;->submittedNow:Z

    .line 37
    .line 38
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 39
    .line 40
    if-eqz v0, :cond_1

    .line 41
    .line 42
    iput-boolean v5, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 43
    .line 44
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 45
    .line 46
    .line 47
    move-result-wide v2

    .line 48
    const-wide/32 v0, 0x1d4c0

    .line 49
    .line 50
    .line 51
    add-long/2addr v2, v0

    .line 52
    iput-wide v2, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 53
    .line 54
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 55
    .line 56
    invoke-static {v4, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$review(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V

    .line 57
    .line 58
    .line 59
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 60
    .line 61
    return-object v0

    .line 62
    :cond_1
    invoke-static {v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$resolve(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$NotEligible;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SubmitOutcome$NotEligible;

    .line 67
    .line 68
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 75
    .line 76
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$clearFiles(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 77
    .line 78
    .line 79
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 80
    .line 81
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$resolved(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 82
    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;

    .line 86
    .line 87
    if-eqz v0, :cond_9

    .line 88
    .line 89
    sget-object v6, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 90
    .line 91
    sget-object v7, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 92
    .line 93
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;

    .line 94
    .line 95
    iget-object v8, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 96
    .line 97
    iget-object v9, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->failure:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 98
    .line 99
    const/4 v10, 0x0

    .line 100
    move-object v11, v10

    .line 101
    invoke-virtual/range {v6 .. v11}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SubmitOutcome$Failed;->kind:Lcom/facebook/aura/activation/ageverification/SubmitFailureKind;

    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    if-eq v1, v4, :cond_6

    .line 111
    .line 112
    if-eq v1, v5, :cond_5

    .line 113
    .line 114
    const/4 v0, 0x2

    .line 115
    if-eq v1, v0, :cond_4

    .line 116
    .line 117
    const/4 v0, 0x3

    .line 118
    if-ne v1, v0, :cond_8

    .line 119
    .line 120
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 121
    .line 122
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 123
    .line 124
    sget-object v1, Lcom/facebook/aura/activation/ageverification/RetryAction;->RESEND:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 125
    .line 126
    :goto_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 127
    .line 128
    invoke-direct {v0, v1, v4, v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 129
    .line 130
    .line 131
    :goto_2
    invoke-static {v2, v10, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    goto :goto_0

    .line 135
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 136
    .line 137
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$clearFiles(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 138
    .line 139
    .line 140
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 141
    .line 142
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 143
    .line 144
    sget-object v1, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECAPTURE:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 148
    .line 149
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$clearFiles(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 150
    .line 151
    .line 152
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 153
    .line 154
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 155
    .line 156
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 157
    .line 158
    invoke-direct {v0, v10, v5, v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 159
    .line 160
    .line 161
    goto :goto_2

    .line 162
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->this$0:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 163
    .line 164
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->access$finalFailure(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 165
    .line 166
    .line 167
    goto :goto_0

    .line 168
    :cond_7
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 172
    .line 173
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 174
    .line 175
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 176
    .line 177
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 178
    .line 179
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->$files:Ljava/util/Map;

    .line 180
    .line 181
    iput v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;->label:I

    .line 182
    .line 183
    invoke-virtual {v3, v2, v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->submit(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    if-ne p1, v6, :cond_0

    .line 188
    .line 189
    return-object v6

    .line 190
    :cond_8
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 191
    .line 192
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 193
    .line 194
    .line 195
    throw v0

    .line 196
    :cond_9
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 197
    .line 198
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 199
    .line 200
    .line 201
    throw v0

    .line 202
    :cond_a
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    throw v0
.end method
