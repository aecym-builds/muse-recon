.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/FaceFrame;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $aspect:F

.field public final synthetic $currentBoxSize$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/2RQ;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $density:LX/34Y;

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/34Y;FLX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/34Y;",
            "F",
            "LX/16A<",
            "LX/2RQ;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$density:LX/34Y;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$aspect:F

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$currentBoxSize$delegate:LX/16A;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/FaceFrame;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->invoke(Lcom/facebook/aura/activation/ageverification/FaceFrame;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/activation/ageverification/FaceFrame;)V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$currentBoxSize$delegate:LX/16A;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$5(LX/16A;)J

    .line 3
    .line 4
    .line 5
    move-result-wide v1

    .line 6
    const-wide/16 v3, 0x0

    .line 7
    .line 8
    cmp-long v0, v1, v3

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 13
    .line 14
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$density:LX/34Y;

    .line 15
    .line 16
    sget v0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->ID_FRAME_MARGIN:F

    .line 17
    .line 18
    invoke-interface {v3, v0}, LX/34Y;->AhZ(F)F

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1$1;->$aspect:F

    .line 23
    .line 24
    invoke-static {v1, v2, v3, v0}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->idFrameRect-Pq9zytI(JFF)LX/36Z;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0, v1, v2}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->normalizedInSquare-d16Qtg0(LX/36Z;J)Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v4, p1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onDocumentFrame(Lcom/facebook/aura/activation/ageverification/FaceFrame;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void
.end method
