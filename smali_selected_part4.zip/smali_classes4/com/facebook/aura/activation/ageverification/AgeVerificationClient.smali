.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$retryServerFailureOnce-gIAlu-s(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->retryServerFailureOnce-gIAlu-s(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$start-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->start-0E7RQCE(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$submit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Ljava/lang/String;Ljava/util/List;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->submit-0E7RQCE(Ljava/lang/String;Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$upload-BWLJW6A(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;Ljava/io/File;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->upload-BWLJW6A(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;Ljava/io/File;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final formField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;
    .locals 3

    .line 0
    sget-object v0, LX/Fbu;->A05:Ljava/nio/charset/Charset;

    .line 1
    .line 2
    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    const/4 v2, 0x0

    .line 7
    const-string v1, "text/plain"

    .line 8
    .line 9
    new-instance v0, Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 10
    .line 11
    invoke-direct {v0, p1, v2, v1, p0}, Lcom/facebook/aura/network/transport/HatchMultipartPart;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method private final mapFailure-bjn95JY(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    move-object v1, v2

    .line 5
    instance-of v0, v2, Ljava/util/concurrent/CancellationException;

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    move-object v2, p0

    .line 11
    :cond_0
    if-nez v2, :cond_5

    .line 12
    .line 13
    if-nez v1, :cond_1

    .line 14
    .line 15
    return-object p1

    .line 16
    :cond_1
    :try_start_0
    instance-of v0, v1, Lcom/facebook/aura/json/NetworkException;

    .line 17
    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    move-object v3, v1

    .line 21
    check-cast v3, Lcom/facebook/aura/json/NetworkException;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_2
    move-object v3, p0

    .line 25
    :goto_0
    if-eqz v3, :cond_4

    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, Lcom/facebook/aura/json/HatchProblemJsonKt;->hatchProblemOf(Ljava/lang/String;)Lcom/facebook/aura/json/HatchProblemJson;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-eqz v0, :cond_3

    .line 36
    .line 37
    iget-object v1, v0, Lcom/facebook/aura/json/HatchProblemJson;->type:Ljava/lang/String;

    .line 38
    .line 39
    if-eqz v1, :cond_3

    .line 40
    .line 41
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_3

    .line 46
    .line 47
    move-object p0, v1

    .line 48
    :cond_3
    const-string v2, "AgeVerificationClient"

    .line 49
    .line 50
    const-string v1, "Request failed: http=%d type=%s"

    .line 51
    .line 52
    iget v0, v3, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 53
    .line 54
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    filled-new-array {v0, p0}, [Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-static {v2, v1, v0}, LX/FnY;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    iget v0, v3, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 66
    .line 67
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 68
    .line 69
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 70
    .line 71
    .line 72
    :cond_4
    throw v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 73
    :catchall_0
    move-exception v1

    .line 74
    new-instance v0, LX/2PH;

    .line 75
    .line 76
    invoke-direct {v0, v1}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 77
    .line 78
    .line 79
    return-object v0

    .line 80
    :cond_5
    throw v2
.end method

.method private final retryServerFailureOnce-gIAlu-s(LX/JDM;LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LX/JDM<",
            "-",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "+TT;>;>;+",
            "Ljava/lang/Object;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v4, p2

    .line 5
    check-cast v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;

    .line 6
    .line 7
    iget v2, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object p0, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->label:I

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    const/4 v0, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    if-eq v1, v0, :cond_2

    .line 29
    .line 30
    if-ne v1, v5, :cond_6

    .line 31
    .line 32
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    check-cast v2, LX/2PJ;

    .line 36
    .line 37
    iget-object v0, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iput-object p1, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->L$0:Ljava/lang/Object;

    .line 44
    .line 45
    iput v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->label:I

    .line 46
    .line 47
    invoke-interface {p1, v4}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    if-ne v2, p0, :cond_3

    .line 52
    .line 53
    return-object p0

    .line 54
    :cond_2
    iget-object p1, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->L$0:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast p1, LX/JDM;

    .line 57
    .line 58
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :cond_3
    check-cast v2, LX/2PJ;

    .line 62
    .line 63
    iget-object v3, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 64
    .line 65
    invoke-static {v3}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    instance-of v0, v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 70
    .line 71
    if-eqz v0, :cond_7

    .line 72
    .line 73
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 74
    .line 75
    if-eqz v2, :cond_7

    .line 76
    .line 77
    iget v1, v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->httpResponseCode:I

    .line 78
    .line 79
    const/16 v0, 0x1f4

    .line 80
    .line 81
    if-ne v1, v0, :cond_7

    .line 82
    .line 83
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;->problemType:Ljava/lang/String;

    .line 84
    .line 85
    const-string v0, "upload_failed"

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-nez v0, :cond_4

    .line 92
    .line 93
    const-string v0, "submit_failed"

    .line 94
    .line 95
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_7

    .line 100
    .line 101
    :cond_4
    const/4 v0, 0x0

    .line 102
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->L$0:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->L$1:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->L$2:Ljava/lang/Object;

    .line 107
    .line 108
    iput v5, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;->label:I

    .line 109
    .line 110
    invoke-interface {p1, v4}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    if-ne v2, p0, :cond_0

    .line 115
    .line 116
    return-object p0

    .line 117
    :cond_5
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;

    .line 118
    .line 119
    invoke-direct {v4, p0, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$retryServerFailureOnce$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 120
    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    throw v0

    .line 128
    :cond_7
    return-object v3
.end method

.method private final start-0E7RQCE(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/2M4;)Ljava/lang/Object;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p3

    .line 1
    .line 2
    move-object/from16 v2, p0

    .line 3
    .line 4
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;

    .line 5
    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    move-object v4, v5

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;

    .line 10
    .line 11
    iget v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v3, v1

    .line 16
    .line 17
    if-eqz v0, :cond_4

    .line 18
    .line 19
    sub-int/2addr v3, v1

    .line 20
    iput v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v5, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->label:I

    .line 27
    .line 28
    const/4 v9, 0x0

    .line 29
    const/4 v3, 0x1

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    if-ne v0, v3, :cond_d

    .line 33
    .line 34
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$8:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 37
    .line 38
    invoke-static {v5}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    :cond_0
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->mapFailure-bjn95JY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    instance-of v0, v1, LX/2PH;

    .line 47
    .line 48
    xor-int/lit8 v0, v0, 0x1

    .line 49
    .line 50
    if-eqz v0, :cond_c

    .line 51
    .line 52
    goto :goto_3

    .line 53
    :cond_1
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object v10, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 57
    .line 58
    sget-object v14, Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Start;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Start;

    .line 59
    .line 60
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    if-eqz p2, :cond_3

    .line 65
    .line 66
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/activation/ageverification/IdDocument;->getSides()I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    new-instance v5, Ljava/lang/Integer;

    .line 71
    .line 72
    invoke-direct {v5, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 73
    .line 74
    .line 75
    :goto_1
    if-eqz p2, :cond_2

    .line 76
    .line 77
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    :goto_2
    new-instance v15, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;

    .line 82
    .line 83
    invoke-direct {v15, v6, v5, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    sget-object v16, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 87
    .line 88
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 89
    .line 90
    .line 91
    move-result-object v17

    .line 92
    sget-object p1, LX/0wX;->A00:LX/0wX;

    .line 93
    .line 94
    sget-object v11, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 95
    .line 96
    sget-object v12, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 97
    .line 98
    const/4 v13, 0x0

    .line 99
    const/4 v0, 0x0

    .line 100
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$0:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$1:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$2:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$3:Ljava/lang/Object;

    .line 107
    .line 108
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$4:Ljava/lang/Object;

    .line 109
    .line 110
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$5:Ljava/lang/Object;

    .line 111
    .line 112
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$6:Ljava/lang/Object;

    .line 113
    .line 114
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$7:Ljava/lang/Object;

    .line 115
    .line 116
    iput-object v2, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->L$8:Ljava/lang/Object;

    .line 117
    .line 118
    iput v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->I$0:I

    .line 119
    .line 120
    iput v13, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->I$1:I

    .line 121
    .line 122
    iput v13, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->I$2:I

    .line 123
    .line 124
    iput v13, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->I$3:I

    .line 125
    .line 126
    iput v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;->label:I

    .line 127
    .line 128
    move/from16 v18, v3

    .line 129
    .line 130
    move-object/from16 v19, v0

    .line 131
    .line 132
    move/from16 v20, v13

    .line 133
    .line 134
    move-object/from16 v21, v0

    .line 135
    .line 136
    move-object/from16 v22, v0

    .line 137
    .line 138
    move/from16 p0, v13

    .line 139
    .line 140
    move/from16 p2, v13

    .line 141
    .line 142
    move-object/from16 p3, v4

    .line 143
    .line 144
    invoke-virtual/range {v10 .. v26}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    if-ne v0, v1, :cond_0

    .line 149
    .line 150
    return-object v1

    .line 151
    :cond_2
    move-object v0, v9

    .line 152
    goto :goto_2

    .line 153
    :cond_3
    move-object v5, v9

    .line 154
    goto :goto_1

    .line 155
    :cond_4
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;

    .line 156
    .line 157
    invoke-direct {v4, v2, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$start$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 158
    .line 159
    .line 160
    goto/16 :goto_0

    .line 161
    .line 162
    :goto_3
    :try_start_0
    check-cast v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;

    .line 163
    .line 164
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->uploads:Ljava/util/List;

    .line 165
    .line 166
    new-instance v5, Ljava/util/ArrayList;

    .line 167
    .line 168
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 169
    .line 170
    .line 171
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 172
    .line 173
    .line 174
    move-result-object v8

    .line 175
    :cond_5
    :goto_4
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    const/16 v3, 0xc8

    .line 180
    .line 181
    if-eqz v0, :cond_a

    .line 182
    .line 183
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v7

    .line 187
    check-cast v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;

    .line 188
    .line 189
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->getEntries()LX/0vk;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 194
    .line 195
    .line 196
    move-result-object v6

    .line 197
    :cond_6
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_9

    .line 202
    .line 203
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v4

    .line 207
    move-object v0, v4

    .line 208
    check-cast v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 209
    .line 210
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->kind:Ljava/lang/String;

    .line 215
    .line 216
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    if-eqz v0, :cond_6

    .line 221
    .line 222
    :goto_5
    check-cast v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 223
    .line 224
    if-nez v4, :cond_7

    .line 225
    .line 226
    iget-boolean v0, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 227
    .line 228
    if-eqz v0, :cond_7

    .line 229
    .line 230
    const-string v0, "unknown_upload_kind"

    .line 231
    .line 232
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 233
    .line 234
    invoke-direct {v1, v0, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 235
    .line 236
    .line 237
    :goto_6
    throw v1

    .line 238
    :cond_7
    if-eqz v4, :cond_8

    .line 239
    .line 240
    iget-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->max_bytes:Ljava/lang/Long;

    .line 241
    .line 242
    iget-boolean v2, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadJson;->required:Z

    .line 243
    .line 244
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 245
    .line 246
    invoke-direct {v0, v4, v3, v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;Ljava/lang/Long;Z)V

    .line 247
    .line 248
    .line 249
    goto :goto_7

    .line 250
    :cond_8
    move-object v0, v9

    .line 251
    :goto_7
    if-eqz v0, :cond_5

    .line 252
    .line 253
    invoke-virtual {v5, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    goto :goto_4

    .line 257
    :cond_9
    move-object v4, v9

    .line 258
    goto :goto_5

    .line 259
    :cond_a
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 260
    .line 261
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 262
    .line 263
    .line 264
    move-result v0

    .line 265
    if-nez v0, :cond_b

    .line 266
    .line 267
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-nez v0, :cond_b

    .line 272
    .line 273
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartResponseJson;->attempt_id:Ljava/lang/String;

    .line 274
    .line 275
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 276
    .line 277
    invoke-direct {v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 278
    .line 279
    .line 280
    goto :goto_8

    .line 281
    :cond_b
    const-string v0, "invalid_response"

    .line 282
    .line 283
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 284
    .line 285
    invoke-direct {v1, v0, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 286
    .line 287
    .line 288
    goto :goto_6

    .line 289
    :goto_8
    return-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 290
    :catchall_0
    move-exception v0

    .line 291
    new-instance v1, LX/2PH;

    .line 292
    .line 293
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 294
    .line 295
    .line 296
    :cond_c
    return-object v1

    .line 297
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    throw v0
.end method

.method private final submit-0E7RQCE(Ljava/lang/String;Ljava/util/List;LX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p0

    .line 1
    .line 2
    move-object/from16 v5, p3

    .line 3
    .line 4
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;

    .line 5
    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    move-object v4, v5

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;

    .line 10
    .line 11
    iget v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->label:I

    .line 12
    .line 13
    const/high16 v2, -0x80000000

    .line 14
    .line 15
    and-int v0, v3, v2

    .line 16
    .line 17
    if-eqz v0, :cond_3

    .line 18
    .line 19
    sub-int/2addr v3, v2

    .line 20
    iput v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->label:I

    .line 27
    .line 28
    const/4 v13, 0x1

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    if-ne v0, v13, :cond_4

    .line 32
    .line 33
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$8:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 36
    .line 37
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    :cond_0
    invoke-direct {v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->mapFailure-bjn95JY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    instance-of v0, v2, LX/2PH;

    .line 46
    .line 47
    xor-int/lit8 v0, v0, 0x1

    .line 48
    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 52
    .line 53
    :cond_1
    return-object v2

    .line 54
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    sget-object v5, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 58
    .line 59
    sget-object v9, Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Submit;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Submit;

    .line 60
    .line 61
    new-instance v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;

    .line 62
    .line 63
    move-object/from16 v0, p2

    .line 64
    .line 65
    move-object/from16 v3, p1

    .line 66
    .line 67
    invoke-direct {v10, v3, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitRequestJson;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 68
    .line 69
    .line 70
    sget-object v11, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 71
    .line 72
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 73
    .line 74
    .line 75
    move-result-object v12

    .line 76
    sget-object p1, LX/0wX;->A00:LX/0wX;

    .line 77
    .line 78
    sget-object v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 79
    .line 80
    sget-object v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit-0E7RQCE$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 81
    .line 82
    const/4 v8, 0x0

    .line 83
    const/4 v14, 0x0

    .line 84
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$0:Ljava/lang/Object;

    .line 85
    .line 86
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$1:Ljava/lang/Object;

    .line 87
    .line 88
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$2:Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$3:Ljava/lang/Object;

    .line 91
    .line 92
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$4:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$5:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$6:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object v14, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$7:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v1, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->L$8:Ljava/lang/Object;

    .line 101
    .line 102
    iput v13, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->I$0:I

    .line 103
    .line 104
    iput v8, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->I$1:I

    .line 105
    .line 106
    iput v8, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->I$2:I

    .line 107
    .line 108
    iput v8, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->I$3:I

    .line 109
    .line 110
    iput v13, v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;->label:I

    .line 111
    .line 112
    move v15, v8

    .line 113
    move-object/from16 v16, v14

    .line 114
    .line 115
    move-object/from16 v17, v14

    .line 116
    .line 117
    move/from16 p0, v8

    .line 118
    .line 119
    move/from16 p2, v8

    .line 120
    .line 121
    move-object/from16 p3, v4

    .line 122
    .line 123
    invoke-virtual/range {v5 .. v21}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    if-ne v0, v2, :cond_0

    .line 128
    .line 129
    return-object v2

    .line 130
    :cond_3
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;

    .line 131
    .line 132
    invoke-direct {v4, v1, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$submit$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 133
    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    throw v0
.end method

.method private final upload-BWLJW6A(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;Ljava/io/File;LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "Ljava/io/File;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p4

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;

    .line 3
    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    move-object v13, v3

    .line 7
    check-cast v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;

    .line 8
    .line 9
    iget v2, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v1, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->label:I

    .line 25
    .line 26
    const/4 v4, 0x1

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    if-ne v0, v4, :cond_4

    .line 30
    .line 31
    iget-object p0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$7:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 34
    .line 35
    invoke-static {v1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :cond_0
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->mapFailure-bjn95JY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    instance-of v0, v1, LX/2PH;

    .line 44
    .line 45
    xor-int/lit8 v0, v0, 0x1

    .line 46
    .line 47
    if-eqz v0, :cond_3

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    sget-object v7, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 54
    .line 55
    sget-object v10, Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Upload;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Upload;

    .line 56
    .line 57
    const-string v0, "attempt_id"

    .line 58
    .line 59
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->formField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    const/4 v9, 0x0

    .line 64
    const-string v1, "kind"

    .line 65
    .line 66
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->formField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    const-string v1, "upload_medium"

    .line 75
    .line 76
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->getUploadMedium()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->formField(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    filled-new-array {v3, v2, v0}, [Lcom/facebook/aura/network/transport/HatchMultipartPart;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 89
    .line 90
    .line 91
    move-result-object v11

    .line 92
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->getFilename()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    invoke-virtual/range {p2 .. p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->getMimeType()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    const-string v1, "file"

    .line 101
    .line 102
    new-instance v0, Lcom/facebook/aura/network/transport/HatchMultipartFilePart;

    .line 103
    .line 104
    move-object/from16 v6, p3

    .line 105
    .line 106
    invoke-direct {v0, v1, v3, v2, v6}, Lcom/facebook/aura/network/transport/HatchMultipartFilePart;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 110
    .line 111
    .line 112
    move-result-object v12

    .line 113
    sget-object v8, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload-BWLJW6A$$inlined$executeStefiMultipartRequest-BWLJW6A$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload-BWLJW6A$$inlined$executeStefiMultipartRequest-BWLJW6A$1;

    .line 114
    .line 115
    const/4 v0, 0x0

    .line 116
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$0:Ljava/lang/Object;

    .line 117
    .line 118
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$1:Ljava/lang/Object;

    .line 119
    .line 120
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$2:Ljava/lang/Object;

    .line 121
    .line 122
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$3:Ljava/lang/Object;

    .line 123
    .line 124
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$4:Ljava/lang/Object;

    .line 125
    .line 126
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$5:Ljava/lang/Object;

    .line 127
    .line 128
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$6:Ljava/lang/Object;

    .line 129
    .line 130
    iput-object p0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->L$7:Ljava/lang/Object;

    .line 131
    .line 132
    iput v4, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;->label:I

    .line 133
    .line 134
    invoke-virtual/range {v7 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiMultipartRequestWith-hUnOzRk(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/util/List;Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    if-ne v0, v5, :cond_0

    .line 139
    .line 140
    return-object v5

    .line 141
    :cond_2
    new-instance v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;

    .line 142
    .line 143
    invoke-direct {v13, p0, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$upload$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 144
    .line 145
    .line 146
    goto :goto_0

    .line 147
    :goto_1
    :try_start_0
    check-cast v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadResponseJson;

    .line 148
    .line 149
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadResponseJson;->file_handle:Ljava/lang/String;

    .line 150
    .line 151
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    if-eqz v0, :cond_3

    .line 156
    .line 157
    const-string v2, "invalid_response"

    .line 158
    .line 159
    const/16 v1, 0xc8

    .line 160
    .line 161
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 162
    .line 163
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 164
    .line 165
    .line 166
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 167
    :catchall_0
    move-exception v0

    .line 168
    new-instance v1, LX/2PH;

    .line 169
    .line 170
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 171
    .line 172
    .line 173
    :cond_3
    return-object v1

    .line 174
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    throw v0
.end method

.method private final uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;",
            "Ljava/util/Map<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "+",
            "Ljava/io/File;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;

    .line 1
    .line 2
    if-eqz v0, :cond_c

    .line 3
    .line 4
    move-object v7, p3

    .line 5
    check-cast v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;

    .line 6
    .line 7
    iget v2, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_c

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 23
    .line 24
    const/4 v2, -0x1

    .line 25
    const/4 v8, 0x3

    .line 26
    const/4 v4, 0x2

    .line 27
    const/4 v9, 0x1

    .line 28
    const/4 v5, 0x0

    .line 29
    if-eqz v1, :cond_2

    .line 30
    .line 31
    if-eq v1, v9, :cond_7

    .line 32
    .line 33
    if-eq v1, v4, :cond_1

    .line 34
    .line 35
    if-ne v1, v8, :cond_d

    .line 36
    .line 37
    invoke-static {v0}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    :cond_0
    return-object v1

    .line 42
    :cond_1
    iget-boolean v4, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->Z$0:Z

    .line 43
    .line 44
    iget-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 47
    .line 48
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    goto/16 :goto_2

    .line 52
    .line 53
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;->uploads:Ljava/util/List;

    .line 57
    .line 58
    new-instance v3, Ljava/util/ArrayList;

    .line 59
    .line 60
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 61
    .line 62
    .line 63
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 64
    .line 65
    .line 66
    move-result-object v10

    .line 67
    :cond_3
    :goto_1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_5

    .line 72
    .line 73
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    check-cast v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 78
    .line 79
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->kind:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 80
    .line 81
    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    if-eqz v0, :cond_4

    .line 86
    .line 87
    invoke-static {v1, v0, v3}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_4
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;->required:Z

    .line 92
    .line 93
    if-eqz v0, :cond_3

    .line 94
    .line 95
    const-string v1, "missing_capture"

    .line 96
    .line 97
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 98
    .line 99
    invoke-direct {v0, v1, v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 100
    .line 101
    .line 102
    new-instance v1, LX/2PH;

    .line 103
    .line 104
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    return-object v1

    .line 108
    :cond_5
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$oversized$1;

    .line 113
    .line 114
    invoke-direct {v0, v3, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$oversized$1;-><init>(Ljava/util/List;LX/2M4;)V

    .line 115
    .line 116
    .line 117
    iput-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 118
    .line 119
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 120
    .line 121
    iput-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 122
    .line 123
    iput v9, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 124
    .line 125
    invoke-static {v7, v1, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    if-ne v0, v6, :cond_8

    .line 130
    .line 131
    :cond_6
    return-object v6

    .line 132
    :cond_7
    iget-object v3, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v3, Ljava/util/List;

    .line 135
    .line 136
    iget-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 139
    .line 140
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    :cond_8
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-eqz v1, :cond_a

    .line 148
    .line 149
    const-string v1, "invalid_file"

    .line 150
    .line 151
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;

    .line 152
    .line 153
    invoke-direct {v0, v1, v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationException;-><init>(Ljava/lang/String;I)V

    .line 154
    .line 155
    .line 156
    :cond_9
    new-instance v6, LX/2PH;

    .line 157
    .line 158
    invoke-direct {v6, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 159
    .line 160
    .line 161
    return-object v6

    .line 162
    :cond_a
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;

    .line 163
    .line 164
    invoke-direct {v0, v3, p1, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1;-><init>(Ljava/util/List;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;LX/2M4;)V

    .line 165
    .line 166
    .line 167
    iput-object p1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 168
    .line 169
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 170
    .line 171
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 172
    .line 173
    iput-boolean v1, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->Z$0:Z

    .line 174
    .line 175
    iput v4, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 176
    .line 177
    invoke-static {v0, v7}, LX/EPV;->A00(LX/JDN;LX/2M4;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    if-eq v0, v6, :cond_6

    .line 182
    .line 183
    const/4 v4, 0x0

    .line 184
    :goto_2
    check-cast v0, Ljava/util/List;

    .line 185
    .line 186
    invoke-static {v0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 191
    .line 192
    .line 193
    move-result-object v2

    .line 194
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 195
    .line 196
    .line 197
    move-result v0

    .line 198
    if-eqz v0, :cond_b

    .line 199
    .line 200
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    check-cast v0, LX/2PJ;

    .line 205
    .line 206
    iget-object v1, v0, LX/2PJ;->value:Ljava/lang/Object;

    .line 207
    .line 208
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    if-nez v0, :cond_9

    .line 213
    .line 214
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_b
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;

    .line 219
    .line 220
    invoke-direct {v0, p1, v3, v5}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/List;LX/2M4;)V

    .line 221
    .line 222
    .line 223
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 224
    .line 225
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 226
    .line 227
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 228
    .line 229
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 230
    .line 231
    iput-object v5, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->L$4:Ljava/lang/Object;

    .line 232
    .line 233
    iput-boolean v4, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->Z$0:Z

    .line 234
    .line 235
    iput v8, v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 236
    .line 237
    invoke-direct {p0, v0, v7}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->retryServerFailureOnce-gIAlu-s(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    if-ne v1, v6, :cond_0

    .line 242
    .line 243
    return-object v6

    .line 244
    :cond_c
    new-instance v7, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;

    .line 245
    .line 246
    invoke-direct {v7, p0, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 247
    .line 248
    .line 249
    goto/16 :goto_0

    .line 250
    .line 251
    :cond_d
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    throw v0
.end method


# virtual methods
.method public final startAndSubmit-BWLJW6A(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Ljava/util/Map<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;",
            "+",
            "Ljava/io/File;",
            ">;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v3, p4

    .line 5
    check-cast v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;

    .line 6
    .line 7
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v5, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 23
    .line 24
    const/4 v7, 0x5

    .line 25
    const/4 v6, 0x4

    .line 26
    const/4 v8, 0x3

    .line 27
    const/4 v1, 0x2

    .line 28
    const/4 v0, 0x1

    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    if-eq v2, v0, :cond_2

    .line 32
    .line 33
    if-eq v2, v1, :cond_4

    .line 34
    .line 35
    if-eq v2, v8, :cond_8

    .line 36
    .line 37
    if-eq v2, v6, :cond_a

    .line 38
    .line 39
    if-eq v2, v7, :cond_a

    .line 40
    .line 41
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0

    .line 46
    :cond_0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;

    .line 47
    .line 48
    invoke-direct {v3, p0, p4}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    iput-object p1, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 56
    .line 57
    iput-object p2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 58
    .line 59
    iput-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 60
    .line 61
    iput v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 62
    .line 63
    invoke-direct {p0, p1, p2, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->start-0E7RQCE(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/2M4;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    if-ne v2, v4, :cond_3

    .line 68
    .line 69
    return-object v4

    .line 70
    :cond_2
    iget-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast p3, Ljava/util/Map;

    .line 73
    .line 74
    iget-object p2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast p2, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 77
    .line 78
    iget-object p1, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast p1, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 81
    .line 82
    invoke-static {v5}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    :cond_3
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    if-nez v0, :cond_c

    .line 91
    .line 92
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 93
    .line 94
    iput-object p1, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 95
    .line 96
    iput-object p2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 97
    .line 98
    iput-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 101
    .line 102
    iput v1, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 103
    .line 104
    invoke-direct {p0, v2, p3, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    if-ne v5, v4, :cond_5

    .line 109
    .line 110
    return-object v4

    .line 111
    :cond_4
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 114
    .line 115
    iget-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast p3, Ljava/util/Map;

    .line 118
    .line 119
    iget-object p2, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 120
    .line 121
    check-cast p2, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 122
    .line 123
    iget-object p1, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast p1, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 126
    .line 127
    invoke-static {v5}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    :cond_5
    invoke-static {v5}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-eqz v0, :cond_6

    .line 136
    .line 137
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClientKt;->getProblemType(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    :goto_1
    const-string v0, "invalid_attempt"

    .line 142
    .line 143
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-eqz v0, :cond_7

    .line 148
    .line 149
    const/4 v0, 0x0

    .line 150
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 151
    .line 152
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 153
    .line 154
    iput-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 155
    .line 156
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 157
    .line 158
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$4:Ljava/lang/Object;

    .line 159
    .line 160
    iput v8, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 161
    .line 162
    invoke-direct {p0, p1, p2, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->start-0E7RQCE(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/2M4;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    if-ne v2, v4, :cond_9

    .line 167
    .line 168
    return-object v4

    .line 169
    :cond_6
    const/4 v1, 0x0

    .line 170
    goto :goto_1

    .line 171
    :cond_7
    const-string v0, "invalid_file_handle"

    .line 172
    .line 173
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    if-eqz v0, :cond_b

    .line 178
    .line 179
    const/4 v0, 0x0

    .line 180
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 181
    .line 182
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 183
    .line 184
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 185
    .line 186
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 187
    .line 188
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$4:Ljava/lang/Object;

    .line 189
    .line 190
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 191
    .line 192
    goto :goto_2

    .line 193
    :cond_8
    iget-object p3, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 194
    .line 195
    check-cast p3, Ljava/util/Map;

    .line 196
    .line 197
    invoke-static {v5}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    :cond_9
    invoke-static {v2}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    if-nez v0, :cond_c

    .line 206
    .line 207
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 208
    .line 209
    const/4 v0, 0x0

    .line 210
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$0:Ljava/lang/Object;

    .line 211
    .line 212
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$1:Ljava/lang/Object;

    .line 213
    .line 214
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$2:Ljava/lang/Object;

    .line 215
    .line 216
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$3:Ljava/lang/Object;

    .line 217
    .line 218
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$4:Ljava/lang/Object;

    .line 219
    .line 220
    iput-object v0, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->L$5:Ljava/lang/Object;

    .line 221
    .line 222
    iput v6, v3, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$startAndSubmit$1;->label:I

    .line 223
    .line 224
    :goto_2
    invoke-direct {p0, v2, p3, v3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v5

    .line 228
    if-ne v5, v4, :cond_b

    .line 229
    .line 230
    return-object v4

    .line 231
    :cond_a
    invoke-static {v5}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v5

    .line 235
    :cond_b
    return-object v5

    .line 236
    :cond_c
    new-instance v5, LX/2PH;

    .line 237
    .line 238
    invoke-direct {v5, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 239
    .line 240
    .line 241
    return-object v5
.end method

.method public final status-IoAF18A(LX/2M4;)Ljava/lang/Object;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;

    .line 1
    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    move-object v13, p1

    .line 5
    check-cast v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;

    .line 6
    .line 7
    iget v2, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->label:I

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    if-ne v1, v0, :cond_4

    .line 28
    .line 29
    iget-object p0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$5:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 32
    .line 33
    invoke-static {v3}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    :cond_0
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->mapFailure-bjn95JY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    instance-of v0, v2, LX/2PH;

    .line 42
    .line 43
    xor-int/lit8 v0, v0, 0x1

    .line 44
    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    check-cast v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;

    .line 48
    .line 49
    invoke-virtual {v2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatusResponseJson;->toDomain()Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    :cond_1
    return-object v2

    .line 54
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    sget-object v3, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 58
    .line 59
    sget-object v6, Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Status;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationStefiPath$Status;

    .line 60
    .line 61
    sget-object v7, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 62
    .line 63
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 64
    .line 65
    .line 66
    move-result-object v10

    .line 67
    sget-object v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status-IoAF18A$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status-IoAF18A$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 68
    .line 69
    const/4 v5, 0x0

    .line 70
    const/4 v8, 0x0

    .line 71
    iput-object v8, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$0:Ljava/lang/Object;

    .line 72
    .line 73
    iput-object v8, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$1:Ljava/lang/Object;

    .line 74
    .line 75
    iput-object v8, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$2:Ljava/lang/Object;

    .line 76
    .line 77
    iput-object v8, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$3:Ljava/lang/Object;

    .line 78
    .line 79
    iput-object v8, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$4:Ljava/lang/Object;

    .line 80
    .line 81
    iput-object p0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->L$5:Ljava/lang/Object;

    .line 82
    .line 83
    iput v0, v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;->label:I

    .line 84
    .line 85
    move-object v9, v8

    .line 86
    move-object v11, v10

    .line 87
    move-object v12, v8

    .line 88
    invoke-virtual/range {v3 .. v13}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-ne v0, v2, :cond_0

    .line 93
    .line 94
    return-object v2

    .line 95
    :cond_3
    new-instance v13, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;

    .line 96
    .line 97
    invoke-direct {v13, p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$status$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    throw v0
.end method
