.class public abstract synthetic Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/RetryAction;->values()[Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    const/4 v6, 0x1

    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECAPTURE:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 9
    .line 10
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    :catch_0
    const/4 v5, 0x2

    .line 14
    :try_start_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/RetryAction;->RESEND:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 15
    .line 16
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 17
    .line 18
    .line 19
    :catch_1
    const/4 v4, 0x3

    .line 20
    :try_start_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECHECK:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 21
    .line 22
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 23
    .line 24
    .line 25
    :catch_2
    const/4 v3, 0x4

    .line 26
    :try_start_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/RetryAction;->REDOWNLOAD:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 27
    .line 28
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 29
    .line 30
    .line 31
    :catch_3
    const/4 v2, 0x5

    .line 32
    :try_start_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/RetryAction;->REFRESH:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 33
    .line 34
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 35
    .line 36
    .line 37
    :catch_4
    sput-object v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 38
    .line 39
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->values()[Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    array-length v0, v0

    .line 44
    new-array v1, v0, [I

    .line 45
    .line 46
    :try_start_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->CONFIRMED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 47
    .line 48
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 49
    .line 50
    .line 51
    :catch_5
    :try_start_6
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->NOT_REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 52
    .line 53
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 54
    .line 55
    .line 56
    :catch_6
    :try_start_7
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 57
    .line 58
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 59
    .line 60
    .line 61
    :catch_7
    :try_start_8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->REQUIRED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 62
    .line 63
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 64
    .line 65
    .line 66
    :catch_8
    :try_start_9
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->PENDING:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 67
    .line 68
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 69
    .line 70
    .line 71
    :catch_9
    :try_start_a
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->FAILED_FINAL:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 72
    .line 73
    invoke-static {v0, v1}, LX/007;->A1L(Ljava/lang/Enum;[I)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    .line 74
    .line 75
    .line 76
    :catch_a
    :try_start_b
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationState;->NOT_SUPPORTED:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 77
    .line 78
    invoke-static {v0, v1}, LX/3Rr;->A17(Ljava/lang/Enum;[I)V
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    .line 79
    .line 80
    .line 81
    :catch_b
    sput-object v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$WhenMappings;->$EnumSwitchMapping$1:[I

    .line 82
    .line 83
    return-void
.end method
