.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final rateLimited:Z

.field public final retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

.field public final retryOnResume:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->rateLimited:Z

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retryOnResume:Z

    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p4, p2}, LX/3Rr;->A1O(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-direct {p0, p1, v1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 268435465
    .line 268435466
    .line 268435467
    return-void
.end method


# virtual methods
.method public final getRateLimited()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->rateLimited:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getRetry()Lcom/facebook/aura/activation/ageverification/RetryAction;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRetryOnResume()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retryOnResume:Z

    .line 1
    .line 2
    return p0
.end method
