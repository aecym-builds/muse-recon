.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdAgeStepScreenKt$IdAgeStep$1$1"
    f = "IdAgeStepScreen.kt"
    l = {
        0x2f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $currentOnBack$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnOtherMethods$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnResolved$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnUnavailable$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnBack$delegate:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnUnavailable$delegate:LX/16A;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnBack$delegate:LX/16A;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnUnavailable$delegate:LX/16A;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v1, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v2

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 19
    .line 20
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->effects:LX/2Lw;

    .line 21
    .line 22
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnBack$delegate:LX/16A;

    .line 23
    .line 24
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 25
    .line 26
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnUnavailable$delegate:LX/16A;

    .line 27
    .line 28
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 29
    .line 30
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;

    .line 31
    .line 32
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;)V

    .line 33
    .line 34
    .line 35
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt$IdAgeStep$1$1;->label:I

    .line 36
    .line 37
    invoke-interface {v0, v3, p0}, LX/2Lw;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-ne v0, v2, :cond_0

    .line 42
    .line 43
    return-object v2

    .line 44
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0
.end method
