.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$Companion;


# instance fields
.field public final method:Ljava/lang/String;

.field public final status:Ljava/lang/String;

.field public final updated_time:Ljava/lang/Long;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    const-string v0, ""

    .line 805306370
    .line 805306371
    invoke-direct {p0, v0, v0, v1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Long;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const-string v1, ""

    .line 268435462
    .line 268435463
    if-nez v0, :cond_1

    .line 268435464
    .line 268435465
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 268435466
    .line 268435467
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435468
    .line 268435469
    if-nez v0, :cond_0

    .line 268435470
    .line 268435471
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 268435472
    .line 268435473
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435474
    .line 268435475
    if-nez v0, :cond_2

    .line 268435476
    .line 268435477
    const/4 v0, 0x0

    .line 268435478
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 268435479
    .line 268435480
    return-void

    .line 268435481
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 268435482
    .line 268435483
    goto :goto_1

    .line 268435484
    :cond_1
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 268435485
    .line 268435486
    goto :goto_0

    .line 268435487
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 268435488
    .line 268435489
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p4, 0x1

    .line 536870913
    .line 536870914
    const-string v1, ""

    .line 536870915
    .line 536870916
    if-eqz v0, :cond_0

    .line 536870917
    .line 536870918
    move-object p1, v1

    .line 536870919
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 536870920
    .line 536870921
    if-eqz v0, :cond_1

    .line 536870922
    .line 536870923
    move-object p2, v1

    .line 536870924
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    const/4 p3, 0x0

    .line 536870929
    :cond_2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 536870930
    .line 536870931
    .line 536870932
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    const-string v2, ""

    .line 6
    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 18
    .line 19
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x1

    .line 23
    if-nez v3, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3

    .line 32
    .line 33
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    const/4 v2, 0x2

    .line 39
    if-nez v3, :cond_4

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 42
    .line 43
    if-eqz v0, :cond_5

    .line 44
    .line 45
    :cond_4
    sget-object v1, LX/DZ1;->A00:LX/DZ1;

    .line 46
    .line 47
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 48
    .line 49
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 50
    .line 51
    .line 52
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getMethod()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStatus()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUpdated_time()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->method:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttemptJson;->updated_time:Ljava/lang/Long;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
