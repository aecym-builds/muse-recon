.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $confirmLabel:Ljava/lang/String;

.field public final synthetic $isResolvingLinking:Z

.field public final synthetic $onSubmit:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$confirmLabel:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$isResolvingLinking:Z

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$onSubmit:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 10

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v2, p1

    .line 2
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$confirmLabel:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 8
    .line 9
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$isResolvingLinking:Z

    .line 18
    .line 19
    const/4 v5, 0x1

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :cond_0
    const/4 v5, 0x0

    .line 23
    :cond_1
    iget-boolean v6, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 24
    .line 25
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3$1$4$1;->$onSubmit:Lkotlin/jvm/functions/Function0;

    .line 26
    .line 27
    const/4 v4, 0x0

    .line 28
    const-string v7, "primary_button"

    .line 29
    .line 30
    const p0, 0x7fffffff

    .line 31
    .line 32
    .line 33
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 34
    .line 35
    move-object v9, v4

    .line 36
    invoke-interface/range {v2 .. v11}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(Ljava/lang/String;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ILX/3C1;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method
