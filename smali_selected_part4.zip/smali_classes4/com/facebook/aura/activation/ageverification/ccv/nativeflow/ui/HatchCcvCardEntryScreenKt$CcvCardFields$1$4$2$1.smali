.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onExpiryChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $securityCodeFocus:LX/3Bk;

.field public final synthetic $uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/3Bk;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3Bk;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$onExpiryChange:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$securityCodeFocus:LX/3Bk;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->invoke(Ljava/lang/String;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$uiState:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v2, 0x4

    .line 17
    invoke-static {v0, v2}, LX/003;->A1J(II)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$onExpiryChange:LX/JDM;

    .line 22
    .line 23
    invoke-interface {v0, p1}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    if-nez v1, :cond_0

    .line 27
    .line 28
    invoke-static {p1}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-lt v0, v2, :cond_0

    .line 37
    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;->$securityCodeFocus:LX/3Bk;

    .line 39
    .line 40
    invoke-static {v0}, LX/3Bk;->A00(LX/3Bk;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    return-void
.end method
