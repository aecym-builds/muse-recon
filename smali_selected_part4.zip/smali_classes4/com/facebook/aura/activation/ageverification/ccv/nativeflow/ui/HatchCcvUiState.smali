.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final acceptedNetworks:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;"
        }
    .end annotation
.end field

.field public final billingCountry:Ljava/lang/String;

.field public final brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

.field public final cardNumber:Ljava/lang/String;

.field public final cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public final chargeAmount:Ljava/lang/String;

.field public final chargeCurrency:Ljava/lang/String;

.field public final checkoutButtonLabel:Ljava/lang/String;

.field public final checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

.field public final countries:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation
.end field

.field public final expiry:Ljava/lang/String;

.field public final expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public final isCountrySelectable:Z

.field public final isSubmitEnabled:Z

.field public final isSubmitting:Z

.field public final linkableAccountTypes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation
.end field

.field public final postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

.field public final screenSubtitle:Ljava/lang/String;

.field public final screenTitle:Ljava/lang/String;

.field public final securityCode:Ljava/lang/String;

.field public final securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public final submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

.field public final submitServerMessage:Ljava/lang/String;

.field public final submitServerTitle:Ljava/lang/String;

.field public final supportedCardTypes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

.field public final zip:Ljava/lang/String;

.field public final zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public final zipServerError:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 31

    .line 538015649
    const v30, 0x1fffffff

    const/4 v1, 0x0

    const/16 v20, 0x0

    move-object/from16 v0, p0

    move-object v2, v1

    move-object v3, v1

    move-object v4, v1

    move-object v5, v1

    move-object v6, v1

    move-object v7, v1

    move-object v8, v1

    move-object v9, v1

    move-object v10, v1

    move-object v11, v1

    move-object v12, v1

    move-object v13, v1

    move-object v14, v1

    move-object v15, v1

    move-object/from16 v16, v1

    move-object/from16 v17, v1

    move-object/from16 v18, v1

    move-object/from16 v19, v1

    move-object/from16 v21, v1

    move/from16 v22, v20

    move/from16 v23, v20

    move-object/from16 v24, v1

    move-object/from16 v25, v1

    move-object/from16 v26, v1

    move-object/from16 v27, v1

    move-object/from16 v28, v1

    move-object/from16 v29, v1

    move-object/from16 p0, v1

    invoke-direct/range {v0 .. v31}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILX/04f;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            "LX/Ddn<",
            "Ljava/lang/String;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;Z",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;",
            "ZZ",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            ")V"
        }
    .end annotation

    .line 1145006
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1145007
    invoke-static {p5, p6}, LX/004;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1145008
    const/4 v0, 0x6

    invoke-static {p7, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0xf

    .line 1145009
    move-object/from16 v2, p16

    move-object/from16 v1, p17

    invoke-static {v2, v0, v1}, LX/003;->A16(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1145010
    const/16 v0, 0x11

    move-object/from16 v3, p18

    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x12

    move-object/from16 v4, p19

    invoke-static {v4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x17

    move-object/from16 v5, p24

    invoke-static {v5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x1b

    move-object/from16 v6, p28

    invoke-static {v6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 1145011
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1145012
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 1145013
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 1145014
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 1145015
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 1145016
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 1145017
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 1145018
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 1145019
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1145020
    move-object/from16 v0, p9

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1145021
    move-object/from16 v0, p10

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1145022
    move-object/from16 v0, p11

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1145023
    move-object/from16 v0, p12

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 1145024
    move-object/from16 v0, p13

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 1145025
    move-object/from16 v0, p14

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 1145026
    move-object/from16 v0, p15

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 1145027
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 1145028
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 1145029
    iput-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 1145030
    iput-object v4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 1145031
    move/from16 v0, p20

    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 1145032
    move-object/from16 v0, p21

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 1145033
    move/from16 v0, p22

    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 1145034
    move/from16 v0, p23

    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 1145035
    iput-object v5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 1145036
    move-object/from16 v0, p25

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 1145037
    move-object/from16 v0, p26

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 1145038
    move-object/from16 v0, p27

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 1145039
    iput-object v6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 1145040
    move-object/from16 v0, p29

    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILX/04f;)V
    .locals 32

    .line 269580497
    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v7, p5

    move-object/from16 v10, p8

    move-object/from16 v11, p9

    move-object/from16 v12, p10

    move-object/from16 v13, p11

    move-object/from16 v14, p12

    move-object/from16 v15, p13

    move-object/from16 v16, p14

    move-object/from16 v17, p15

    move-object/from16 v18, p16

    move-object/from16 v19, p17

    move-object/from16 v20, p18

    move/from16 v22, p20

    move-object/from16 v23, p21

    move-object/from16 v26, p24

    move-object/from16 v27, p25

    move-object/from16 v31, p29

    move/from16 v0, p30

    move-object/from16 v8, p6

    move-object/from16 v9, p7

    move-object/from16 v21, p19

    move-object/from16 v30, p28

    and-int/lit8 v1, p30, 0x1

    const-string v6, ""

    if-eqz v1, :cond_0

    move-object v3, v6

    :cond_0
    and-int/lit8 v1, p30, 0x2

    if-eqz v1, :cond_1

    move-object v4, v6

    :cond_1
    and-int/lit8 v1, p30, 0x4

    if-eqz v1, :cond_2

    move-object v5, v6

    :cond_2
    and-int/lit8 v1, p30, 0x8

    if-nez v1, :cond_3

    move-object/from16 v6, p4

    :cond_3
    and-int/lit8 v1, p30, 0x10

    if-eqz v1, :cond_4

    .line 269580498
    sget-object v7, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->UNKNOWN:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    :cond_4
    and-int/lit8 v1, p30, 0x20

    if-eqz v1, :cond_5

    .line 269580499
    sget-object v8, LX/Dwg;->A01:LX/Dwg;

    .line 269580500
    :cond_5
    and-int/lit8 v1, p30, 0x40

    if-eqz v1, :cond_6

    .line 269580501
    sget-object v9, LX/Dwg;->A01:LX/Dwg;

    .line 269580502
    :cond_6
    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_7

    const/4 v10, 0x0

    :cond_7
    and-int/lit16 v1, v0, 0x100

    if-eqz v1, :cond_8

    const/4 v11, 0x0

    :cond_8
    and-int/lit16 v1, v0, 0x200

    if-eqz v1, :cond_9

    const/4 v12, 0x0

    :cond_9
    and-int/lit16 v1, v0, 0x400

    if-eqz v1, :cond_a

    const/4 v13, 0x0

    :cond_a
    and-int/lit16 v1, v0, 0x800

    if-eqz v1, :cond_b

    const/4 v14, 0x0

    :cond_b
    and-int/lit16 v1, v0, 0x1000

    if-eqz v1, :cond_c

    const/4 v15, 0x0

    :cond_c
    and-int/lit16 v1, v0, 0x2000

    if-eqz v1, :cond_d

    const/16 v16, 0x0

    :cond_d
    and-int/lit16 v1, v0, 0x4000

    if-eqz v1, :cond_e

    const/16 v17, 0x0

    :cond_e
    const v1, 0x8000

    and-int v1, p30, v1

    if-eqz v1, :cond_f

    .line 269580503
    const-string v18, "1.00"

    :cond_f
    const/high16 v1, 0x10000

    and-int v1, p30, v1

    if-eqz v1, :cond_10

    .line 269580504
    const-string v19, "USD"

    :cond_10
    const/high16 v1, 0x20000

    and-int v1, p30, v1

    if-eqz v1, :cond_11

    .line 269580505
    const-string v20, "US"

    :cond_11
    const/high16 v1, 0x40000

    and-int v1, p30, v1

    if-eqz v1, :cond_12

    .line 269580506
    sget-object v21, LX/Dwg;->A01:LX/Dwg;

    .line 269580507
    :cond_12
    const/high16 v1, 0x80000

    and-int v1, p30, v1

    const/16 v25, 0x0

    if-eqz v1, :cond_13

    const/16 v22, 0x0

    :cond_13
    const/high16 v1, 0x100000

    and-int v1, p30, v1

    if-eqz v1, :cond_14

    const/16 v23, 0x0

    :cond_14
    const/high16 v1, 0x200000

    .line 269580508
    move/from16 v2, p22

    invoke-static {v0, v1, v2}, LX/3Rr;->A1N(IIZ)Z

    move-result v24

    .line 269580509
    const/high16 v1, 0x400000

    and-int v1, p30, v1

    if-nez v1, :cond_15

    move/from16 v25, p23

    :cond_15
    const/high16 v1, 0x800000

    and-int v1, p30, v1

    if-eqz v1, :cond_16

    .line 269580510
    sget-object v26, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->LOADING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    :cond_16
    const/high16 v1, 0x1000000

    and-int v1, p30, v1

    if-eqz v1, :cond_17

    const/16 v27, 0x0

    :cond_17
    const/high16 v1, 0x2000000

    .line 269580511
    move-object/from16 v2, p26

    invoke-static {v0, v1, v2}, LX/3Rr;->A0d(IILjava/lang/String;)Ljava/lang/String;

    move-result-object v28

    .line 269580512
    const/high16 v1, 0x4000000

    .line 269580513
    move-object/from16 v2, p27

    invoke-static {v0, v1, v2}, LX/3Rr;->A0d(IILjava/lang/String;)Ljava/lang/String;

    move-result-object v29

    .line 269580514
    const/high16 v1, 0x8000000

    and-int v1, p30, v1

    if-eqz v1, :cond_18

    .line 269580515
    sget-object v30, LX/Dwg;->A01:LX/Dwg;

    .line 269580516
    :cond_18
    const/high16 v1, 0x10000000

    and-int v0, p30, v1

    if-eqz v0, :cond_19

    const/16 v31, 0x0

    .line 269580517
    :cond_19
    move-object/from16 v2, p0

    invoke-direct/range {v2 .. v31}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
    .locals 45

    .line 1145067
    move-object/from16 v44, p1

    move-object/from16 v43, p2

    move-object/from16 v42, p3

    move-object/from16 v41, p4

    move-object/from16 v40, p5

    move-object/from16 v39, p6

    move-object/from16 v38, p7

    move-object/from16 v37, p8

    move-object/from16 v36, p9

    move-object/from16 v35, p10

    move-object/from16 v34, p11

    move-object/from16 v33, p12

    move-object/from16 v32, p13

    move-object/from16 v31, p14

    move-object/from16 v16, p15

    move-object/from16 v17, p16

    move/from16 v14, p20

    move/from16 v13, p22

    move/from16 v12, p23

    move-object/from16 v11, p25

    move-object/from16 v10, p26

    move-object/from16 v9, p27

    move-object/from16 v8, p28

    move/from16 v7, p30

    move-object/from16 v6, p17

    move-object/from16 v5, p18

    move-object/from16 v4, p19

    move-object/from16 v3, p21

    move-object/from16 v2, p24

    move-object/from16 v1, p29

    and-int/lit8 v0, p30, 0x1

    move-object/from16 v15, p0

    if-eqz v0, :cond_0

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    move-object/from16 v44, v0

    :cond_0
    and-int/lit8 v0, p30, 0x2

    if-eqz v0, :cond_1

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    move-object/from16 v43, v0

    :cond_1
    and-int/lit8 v0, p30, 0x4

    if-eqz v0, :cond_2

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    move-object/from16 v42, v0

    :cond_2
    and-int/lit8 v0, p30, 0x8

    if-eqz v0, :cond_3

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    move-object/from16 v41, v0

    :cond_3
    and-int/lit8 v0, p30, 0x10

    if-eqz v0, :cond_4

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    move-object/from16 v40, v0

    :cond_4
    and-int/lit8 v0, p30, 0x20

    if-eqz v0, :cond_5

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    move-object/from16 v39, v0

    :cond_5
    and-int/lit8 v0, p30, 0x40

    if-eqz v0, :cond_6

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    move-object/from16 v38, v0

    :cond_6
    and-int/lit16 v0, v7, 0x80

    if-eqz v0, :cond_7

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    move-object/from16 v37, v0

    :cond_7
    and-int/lit16 v0, v7, 0x100

    if-eqz v0, :cond_8

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    move-object/from16 v36, v0

    :cond_8
    and-int/lit16 v0, v7, 0x200

    if-eqz v0, :cond_9

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    move-object/from16 v35, v0

    :cond_9
    and-int/lit16 v0, v7, 0x400

    if-eqz v0, :cond_a

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    move-object/from16 v34, v0

    :cond_a
    and-int/lit16 v0, v7, 0x800

    if-eqz v0, :cond_b

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    move-object/from16 v33, v0

    :cond_b
    and-int/lit16 v0, v7, 0x1000

    if-eqz v0, :cond_c

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    move-object/from16 v32, v0

    :cond_c
    and-int/lit16 v0, v7, 0x2000

    if-eqz v0, :cond_d

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    move-object/from16 v31, v0

    :cond_d
    and-int/lit16 v0, v7, 0x4000

    if-eqz v0, :cond_e

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    move-object/from16 v16, v0

    :cond_e
    const v0, 0x8000

    and-int v0, p30, v0

    if-eqz v0, :cond_f

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    move-object/from16 v17, v0

    :cond_f
    const/high16 v0, 0x10000

    and-int v0, p30, v0

    if-eqz v0, :cond_10

    iget-object v6, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    :cond_10
    const/high16 v0, 0x20000

    and-int v0, p30, v0

    if-eqz v0, :cond_11

    iget-object v5, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    :cond_11
    const/high16 v0, 0x40000

    and-int v0, p30, v0

    if-eqz v0, :cond_12

    iget-object v4, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    :cond_12
    const/high16 v0, 0x80000

    and-int v0, p30, v0

    if-eqz v0, :cond_13

    iget-boolean v14, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    :cond_13
    const/high16 v0, 0x100000

    and-int v0, p30, v0

    if-eqz v0, :cond_14

    iget-object v3, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    :cond_14
    const/high16 v0, 0x200000

    and-int v0, p30, v0

    if-eqz v0, :cond_15

    iget-boolean v13, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    :cond_15
    const/high16 v0, 0x400000

    and-int v0, p30, v0

    if-eqz v0, :cond_16

    iget-boolean v12, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    :cond_16
    const/high16 v0, 0x800000

    and-int v0, p30, v0

    if-eqz v0, :cond_17

    iget-object v2, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    :cond_17
    const/high16 v0, 0x1000000

    and-int v0, p30, v0

    if-eqz v0, :cond_18

    iget-object v11, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    :cond_18
    const/high16 v0, 0x2000000

    and-int v0, p30, v0

    if-eqz v0, :cond_19

    iget-object v10, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    :cond_19
    const/high16 v0, 0x4000000

    and-int v0, p30, v0

    if-eqz v0, :cond_1a

    iget-object v9, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    :cond_1a
    const/high16 v0, 0x8000000

    and-int v0, p30, v0

    if-eqz v0, :cond_1b

    iget-object v8, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    :cond_1b
    const/high16 v0, 0x10000000

    and-int v7, p30, v0

    if-eqz v7, :cond_1c

    iget-object v1, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    :cond_1c
    move-object/from16 v18, v6

    move-object/from16 v19, v5

    move-object/from16 v20, v4

    move/from16 v21, v14

    move-object/from16 v22, v3

    move/from16 v23, v13

    move/from16 v24, v12

    move-object/from16 v25, v2

    move-object/from16 v26, v11

    move-object/from16 v27, v10

    move-object/from16 v28, v9

    move-object/from16 v29, v8

    move-object/from16 v30, v1

    move-object v1, v15

    move-object/from16 v2, v44

    move-object/from16 v3, v43

    move-object/from16 v4, v42

    move-object/from16 v5, v41

    move-object/from16 v6, v40

    move-object/from16 v7, v39

    move-object/from16 v8, v38

    move-object/from16 v9, v37

    move-object/from16 v10, v36

    move-object/from16 v11, v35

    move-object/from16 v12, v34

    move-object/from16 v13, v33

    move-object/from16 v14, v32

    move-object/from16 v15, v31

    invoke-virtual/range {v1 .. v30}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component12()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component13()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component14()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component15()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component16()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component17()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component18()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component19()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component20()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component21()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component22()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component23()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component24()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component25()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component26()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component27()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component28()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component29()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            "LX/Ddn<",
            "Ljava/lang/String;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;Z",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;",
            "ZZ",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p5, p6}, LX/004;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x6

    .line 7
    invoke-static {p7, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/16 v0, 0xf

    .line 11
    .line 12
    move-object/from16 v3, p16

    .line 13
    .line 14
    move-object/from16 v2, p17

    .line 15
    .line 16
    invoke-static {v3, v0, v2}, LX/003;->A16(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const/16 v0, 0x11

    .line 20
    .line 21
    move-object/from16 v4, p18

    .line 22
    .line 23
    invoke-static {v4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 24
    .line 25
    .line 26
    const/16 v0, 0x12

    .line 27
    .line 28
    move-object/from16 v5, p19

    .line 29
    .line 30
    invoke-static {v5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 31
    .line 32
    .line 33
    const/16 v0, 0x17

    .line 34
    .line 35
    move-object/from16 v6, p24

    .line 36
    .line 37
    invoke-static {v6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 38
    .line 39
    .line 40
    const/16 v0, 0x1b

    .line 41
    .line 42
    move-object/from16 v1, p28

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 45
    .line 46
    .line 47
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 48
    .line 49
    invoke-direct/range {p0 .. p29}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V

    .line 50
    .line 51
    .line 52
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 53
    .line 54
    if-ne v1, v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_0

    .line 75
    .line 76
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 77
    .line 78
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 79
    .line 80
    if-ne v1, v0, :cond_0

    .line 81
    .line 82
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 83
    .line 84
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 85
    .line 86
    if-ne v1, v0, :cond_0

    .line 87
    .line 88
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 89
    .line 90
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 91
    .line 92
    if-ne v1, v0, :cond_0

    .line 93
    .line 94
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 95
    .line 96
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 97
    .line 98
    if-ne v1, v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_0

    .line 109
    .line 110
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    if-eqz v0, :cond_0

    .line 119
    .line 120
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 121
    .line 122
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 123
    .line 124
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_0

    .line 129
    .line 130
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 131
    .line 132
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 133
    .line 134
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_0

    .line 139
    .line 140
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 141
    .line 142
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 143
    .line 144
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_0

    .line 149
    .line 150
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 151
    .line 152
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 153
    .line 154
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-eqz v0, :cond_0

    .line 159
    .line 160
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 161
    .line 162
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 163
    .line 164
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    if-eqz v0, :cond_0

    .line 169
    .line 170
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 171
    .line 172
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 173
    .line 174
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    if-eqz v0, :cond_0

    .line 179
    .line 180
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 181
    .line 182
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 183
    .line 184
    if-ne v1, v0, :cond_0

    .line 185
    .line 186
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 187
    .line 188
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 189
    .line 190
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 191
    .line 192
    .line 193
    move-result v0

    .line 194
    if-eqz v0, :cond_0

    .line 195
    .line 196
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 197
    .line 198
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 199
    .line 200
    if-ne v1, v0, :cond_0

    .line 201
    .line 202
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 203
    .line 204
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 205
    .line 206
    if-ne v1, v0, :cond_0

    .line 207
    .line 208
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 209
    .line 210
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 211
    .line 212
    if-ne v1, v0, :cond_0

    .line 213
    .line 214
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 215
    .line 216
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 217
    .line 218
    if-ne v1, v0, :cond_0

    .line 219
    .line 220
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 221
    .line 222
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 223
    .line 224
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    if-eqz v0, :cond_0

    .line 229
    .line 230
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 231
    .line 232
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 233
    .line 234
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    if-eqz v0, :cond_0

    .line 239
    .line 240
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 241
    .line 242
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 243
    .line 244
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 245
    .line 246
    .line 247
    move-result v0

    .line 248
    if-eqz v0, :cond_0

    .line 249
    .line 250
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 251
    .line 252
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 253
    .line 254
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 255
    .line 256
    .line 257
    move-result v0

    .line 258
    if-nez v0, :cond_1

    .line 259
    .line 260
    :cond_0
    return v2

    .line 261
    :cond_1
    return v3
.end method

.method public final getAcceptedNetworks()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBillingCountry()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBrand()Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCardNumber()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCardNumberError()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChargeAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChargeCurrency()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCheckoutButtonLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCheckoutPhase()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCountries()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExpiry()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExpiryError()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLinkableAccountTypes()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPostalField()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSecurityCode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSecurityCodeError()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubmitError()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubmitServerMessage()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubmitServerTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSupportedCardTypes()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getThreeDSChallenge()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getZip()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getZipError()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getZipServerError()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->brand:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 25
    .line 26
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->acceptedNetworks:LX/Ddn;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 43
    .line 44
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    mul-int/lit8 v1, v1, 0x1f

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 52
    .line 53
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    add-int/2addr v1, v0

    .line 58
    mul-int/lit8 v1, v1, 0x1f

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 61
    .line 62
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    add-int/2addr v1, v0

    .line 67
    mul-int/lit8 v1, v1, 0x1f

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 70
    .line 71
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    add-int/2addr v1, v0

    .line 76
    mul-int/lit8 v1, v1, 0x1f

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 79
    .line 80
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    add-int/2addr v1, v0

    .line 85
    mul-int/lit8 v1, v1, 0x1f

    .line 86
    .line 87
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    add-int/2addr v1, v0

    .line 94
    mul-int/lit8 v1, v1, 0x1f

    .line 95
    .line 96
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 97
    .line 98
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    add-int/2addr v1, v0

    .line 103
    mul-int/lit8 v1, v1, 0x1f

    .line 104
    .line 105
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutButtonLabel:Ljava/lang/String;

    .line 106
    .line 107
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    add-int/2addr v1, v0

    .line 112
    mul-int/lit8 v1, v1, 0x1f

    .line 113
    .line 114
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 115
    .line 116
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 121
    .line 122
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 127
    .line 128
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 129
    .line 130
    .line 131
    move-result v1

    .line 132
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 133
    .line 134
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 139
    .line 140
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 141
    .line 142
    .line 143
    move-result v1

    .line 144
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 145
    .line 146
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    add-int/2addr v1, v0

    .line 151
    mul-int/lit8 v1, v1, 0x1f

    .line 152
    .line 153
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 154
    .line 155
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 156
    .line 157
    .line 158
    move-result v1

    .line 159
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 160
    .line 161
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 162
    .line 163
    .line 164
    move-result v1

    .line 165
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 166
    .line 167
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 172
    .line 173
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    add-int/2addr v1, v0

    .line 178
    mul-int/lit8 v1, v1, 0x1f

    .line 179
    .line 180
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 181
    .line 182
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    add-int/2addr v1, v0

    .line 187
    mul-int/lit8 v1, v1, 0x1f

    .line 188
    .line 189
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 190
    .line 191
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    add-int/2addr v1, v0

    .line 196
    mul-int/lit8 v1, v1, 0x1f

    .line 197
    .line 198
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 199
    .line 200
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 201
    .line 202
    .line 203
    move-result v1

    .line 204
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 205
    .line 206
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 207
    .line 208
    .line 209
    move-result v0

    .line 210
    add-int/2addr v1, v0

    .line 211
    return v1
.end method

.method public final isCountrySelectable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isSubmitEnabled()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitEnabled:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isSubmitting()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
