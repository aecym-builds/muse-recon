.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final billingCountry:Ljava/lang/String;

.field public final stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

.field public final uplSessionId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getBillingCountry()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStepUpRequired()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUplSessionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
