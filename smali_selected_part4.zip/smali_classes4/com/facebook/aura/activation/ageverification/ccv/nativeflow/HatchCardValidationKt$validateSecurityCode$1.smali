.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFailure;",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFailure;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_WRONG_LENGTH:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_WRONG_LENGTH:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 268435457
    .line 268435458
    return-object p0
.end method
