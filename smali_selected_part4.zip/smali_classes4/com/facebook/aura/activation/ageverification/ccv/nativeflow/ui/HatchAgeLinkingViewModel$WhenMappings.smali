.class public abstract synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$WhenMappings;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I

.field public static final synthetic $EnumSwitchMapping$2:[I

.field public static final synthetic $EnumSwitchMapping$3:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 0
    invoke-static {}, Lcom/facebook/aura/user/provider/AgeCheckMethod;->values()[Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    array-length v0, v0

    .line 5
    new-array v1, v0, [I

    .line 6
    .line 7
    const/4 v6, 0x1

    .line 8
    :try_start_0
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->FACEBOOK:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 9
    .line 10
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    :catch_0
    const/4 v5, 0x2

    .line 14
    :try_start_1
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->INSTAGRAM:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 15
    .line 16
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 17
    .line 18
    .line 19
    :catch_1
    const/4 v4, 0x3

    .line 20
    :try_start_2
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->SELFIE:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 21
    .line 22
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 23
    .line 24
    .line 25
    :catch_2
    const/4 v3, 0x4

    .line 26
    :try_start_3
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 27
    .line 28
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 29
    .line 30
    .line 31
    :catch_3
    const/4 v2, 0x5

    .line 32
    :try_start_4
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->CREDIT_CARD:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 33
    .line 34
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 35
    .line 36
    .line 37
    :catch_4
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 38
    .line 39
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->values()[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    array-length v0, v0

    .line 44
    new-array v1, v0, [I

    .line 45
    .line 46
    :try_start_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->FACEBOOK:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 47
    .line 48
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 49
    .line 50
    .line 51
    :catch_5
    :try_start_6
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->INSTAGRAM:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 52
    .line 53
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 54
    .line 55
    .line 56
    :catch_6
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$WhenMappings;->$EnumSwitchMapping$1:[I

    .line 57
    .line 58
    invoke-static {}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->values()[Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    array-length v0, v0

    .line 63
    new-array v1, v0, [I

    .line 64
    .line 65
    :try_start_7
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->COMPLETED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 66
    .line 67
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 68
    .line 69
    .line 70
    :catch_7
    :try_start_8
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->CANCELLED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 71
    .line 72
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 73
    .line 74
    .line 75
    :catch_8
    :try_start_9
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->DIALOG_UNAVAILABLE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 76
    .line 77
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 78
    .line 79
    .line 80
    :catch_9
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$WhenMappings;->$EnumSwitchMapping$2:[I

    .line 81
    .line 82
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->values()[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    array-length v0, v0

    .line 87
    new-array v1, v0, [I

    .line 88
    .line 89
    :try_start_a
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->CONTINUE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 90
    .line 91
    invoke-static {v0, v1, v6}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    .line 92
    .line 93
    .line 94
    :catch_a
    :try_start_b
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->BLOCKED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 95
    .line 96
    invoke-static {v0, v1, v5}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    .line 97
    .line 98
    .line 99
    :catch_b
    :try_start_c
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 100
    .line 101
    invoke-static {v0, v1, v4}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_c} :catch_c

    .line 102
    .line 103
    .line 104
    :catch_c
    :try_start_d
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->RESTART_LINKING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 105
    .line 106
    invoke-static {v0, v1, v3}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_d .. :try_end_d} :catch_d

    .line 107
    .line 108
    .line 109
    :catch_d
    :try_start_e
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->USE_CREDIT_CARD:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 110
    .line 111
    invoke-static {v0, v1, v2}, LX/001;->A1L(Ljava/lang/Enum;[II)V
    :try_end_e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_e .. :try_end_e} :catch_e

    .line 112
    .line 113
    .line 114
    :catch_e
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$WhenMappings;->$EnumSwitchMapping$3:[I

    .line 115
    .line 116
    return-void
.end method
