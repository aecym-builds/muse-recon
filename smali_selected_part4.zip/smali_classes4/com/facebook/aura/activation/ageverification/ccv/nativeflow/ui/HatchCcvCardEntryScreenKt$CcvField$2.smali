.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$changed1:I

.field public final synthetic $$default:I

.field public final synthetic $capitalization:I

.field public final synthetic $contentType:LX/0PV;

.field public final synthetic $enabled:Z

.field public final synthetic $error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public final synthetic $focusRequester:LX/3Bk;

.field public final synthetic $imeAction:I

.field public final synthetic $keyboardActions:LX/3PP;

.field public final synthetic $keyboardType:I

.field public final synthetic $label:Ljava/lang/String;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onBlur:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onChange:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $placeholder:Ljava/lang/String;

.field public final synthetic $placeholderRes:I

.field public final synthetic $serverError:Ljava/lang/String;

.field public final synthetic $trailingIcon:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $value:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;III)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;I",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Ljava/lang/String;",
            "Z",
            "LX/0PV;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "III",
            "LX/3PP;",
            "LX/3Bk;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;III)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$value:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$onChange:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$onBlur:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$placeholderRes:I

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$serverError:Ljava/lang/String;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$enabled:Z

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$contentType:LX/0PV;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$modifier:LX/3C1;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$placeholder:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p11, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$label:Ljava/lang/String;

    .line 21
    .line 22
    iput p12, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$keyboardType:I

    .line 23
    .line 24
    iput p13, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$capitalization:I

    .line 25
    .line 26
    iput p14, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$imeAction:I

    .line 27
    .line 28
    move-object/from16 v0, p15

    .line 29
    .line 30
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$keyboardActions:LX/3PP;

    .line 31
    .line 32
    move-object/from16 v0, p16

    .line 33
    .line 34
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$focusRequester:LX/3Bk;

    .line 35
    .line 36
    move-object/from16 v0, p17

    .line 37
    .line 38
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$trailingIcon:LX/JDN;

    .line 39
    .line 40
    move/from16 v0, p18

    .line 41
    .line 42
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$changed:I

    .line 43
    .line 44
    move/from16 v0, p19

    .line 45
    .line 46
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$changed1:I

    .line 47
    .line 48
    move/from16 v0, p20

    .line 49
    .line 50
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$default:I

    .line 51
    .line 52
    const/4 v0, 0x2

    .line 53
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 54
    .line 55
    .line 56
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 34

    .line 268435456
    move-object/from16 v0, p0

    .line 268435457
    .line 268435458
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$value:Ljava/lang/String;

    .line 268435459
    .line 268435460
    move-object/from16 p0, v1

    .line 268435461
    .line 268435462
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$onChange:LX/JDM;

    .line 268435463
    .line 268435464
    move-object/from16 v33, v1

    .line 268435465
    .line 268435466
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$onBlur:Lkotlin/jvm/functions/Function0;

    .line 268435467
    .line 268435468
    move-object/from16 v32, v1

    .line 268435469
    .line 268435470
    iget v15, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$placeholderRes:I

    .line 268435471
    .line 268435472
    iget-object v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 268435473
    .line 268435474
    iget-object v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$serverError:Ljava/lang/String;

    .line 268435475
    .line 268435476
    iget-boolean v11, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$enabled:Z

    .line 268435477
    .line 268435478
    iget-object v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$contentType:LX/0PV;

    .line 268435479
    .line 268435480
    iget-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$modifier:LX/3C1;

    .line 268435481
    .line 268435482
    iget-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$placeholder:Ljava/lang/String;

    .line 268435483
    .line 268435484
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$label:Ljava/lang/String;

    .line 268435485
    .line 268435486
    iget v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$keyboardType:I

    .line 268435487
    .line 268435488
    iget v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$capitalization:I

    .line 268435489
    .line 268435490
    iget v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$imeAction:I

    .line 268435491
    .line 268435492
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$keyboardActions:LX/3PP;

    .line 268435493
    .line 268435494
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$focusRequester:LX/3Bk;

    .line 268435495
    .line 268435496
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$trailingIcon:LX/JDN;

    .line 268435497
    .line 268435498
    iget v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$changed:I

    .line 268435499
    .line 268435500
    invoke-static {v14}, LX/0z0;->A00(I)I

    .line 268435501
    .line 268435502
    .line 268435503
    move-result v29

    .line 268435504
    iget v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$changed1:I

    .line 268435505
    .line 268435506
    invoke-static {v14}, LX/0z0;->A01(I)I

    .line 268435507
    .line 268435508
    .line 268435509
    move-result v30

    .line 268435510
    iget v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;->$$default:I

    .line 268435511
    .line 268435512
    move-object/from16 v28, p1

    .line 268435513
    .line 268435514
    move-object/from16 v26, v2

    .line 268435515
    .line 268435516
    move-object/from16 v27, v1

    .line 268435517
    .line 268435518
    move/from16 v31, v0

    .line 268435519
    .line 268435520
    move/from16 v23, v5

    .line 268435521
    .line 268435522
    move/from16 v24, v4

    .line 268435523
    .line 268435524
    move-object/from16 v25, v3

    .line 268435525
    .line 268435526
    move-object/from16 v20, v8

    .line 268435527
    .line 268435528
    move-object/from16 v21, v7

    .line 268435529
    .line 268435530
    move/from16 v22, v6

    .line 268435531
    .line 268435532
    move/from16 v17, v11

    .line 268435533
    .line 268435534
    move-object/from16 v18, v10

    .line 268435535
    .line 268435536
    move-object/from16 v19, v9

    .line 268435537
    .line 268435538
    move v14, v15

    .line 268435539
    move-object v15, v13

    .line 268435540
    move-object/from16 v16, v12

    .line 268435541
    .line 268435542
    move-object/from16 v11, p0

    .line 268435543
    .line 268435544
    move-object/from16 v12, v33

    .line 268435545
    .line 268435546
    move-object/from16 v13, v32

    .line 268435547
    .line 268435548
    invoke-static/range {v11 .. v31}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 268435549
    .line 268435550
    .line 268435551
    return-void
.end method
