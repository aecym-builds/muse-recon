.class public interface abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult;
.super Ljava/lang/Object;
.source ""
