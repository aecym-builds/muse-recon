.class public interface abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;
.super Ljava/lang/Object;
.source ""
