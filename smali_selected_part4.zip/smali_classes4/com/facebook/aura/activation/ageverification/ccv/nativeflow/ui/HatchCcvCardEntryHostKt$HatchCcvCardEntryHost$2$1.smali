.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $hasLoggedLinkingFooter$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->$uiState$delegate:LX/16A;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->$hasLoggedLinkingFooter$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->$uiState$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->$hasLoggedLinkingFooter$delegate:Landroidx/compose/runtime/MutableState;

    .line 17
    .line 18
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->$hasLoggedLinkingFooter$delegate:Landroidx/compose/runtime/MutableState;

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    invoke-static {v0, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 28
    .line 29
    .line 30
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->LINKING_FOOTER:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    invoke-static {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvImpression(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1$invoke$$inlined$onDispose$1;

    .line 37
    .line 38
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 39
    .line 40
    .line 41
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
