.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$Companion;


# instance fields
.field public final address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

.field public final supported_cc_types:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final type:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v2, v0, v2}, [Lkotlin/Lazy;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->$childSerializers:[Lkotlin/Lazy;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    invoke-direct {p0, v1, v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const/4 v1, 0x0

    .line 268435462
    if-nez v0, :cond_1

    .line 268435463
    .line 268435464
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 268435465
    .line 268435466
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    if-nez v0, :cond_0

    .line 268435469
    .line 268435470
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 268435471
    .line 268435472
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 268435473
    .line 268435474
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435475
    .line 268435476
    if-nez v0, :cond_2

    .line 268435477
    .line 268435478
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 268435479
    .line 268435480
    return-void

    .line 268435481
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 268435482
    .line 268435483
    goto :goto_1

    .line 268435484
    :cond_1
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 268435485
    .line 268435486
    goto :goto_0

    .line 268435487
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 268435488
    .line 268435489
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;",
            ")V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p4, 0x1

    .line 536870913
    .line 536870914
    const/4 v1, 0x0

    .line 536870915
    if-eqz v0, :cond_0

    .line 536870916
    .line 536870917
    move-object p1, v1

    .line 536870918
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    sget-object p2, LX/0wV;->A00:LX/0wV;

    .line 536870923
    .line 536870924
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    move-object p3, v1

    .line 536870929
    :cond_2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)V

    .line 536870930
    .line 536870931
    .line 536870932
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->copy(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v2, 0x1

    .line 21
    if-nez v3, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 24
    .line 25
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    :cond_2
    invoke-static {v4, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 36
    .line 37
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 38
    .line 39
    .line 40
    :cond_3
    const/4 v2, 0x2

    .line 41
    if-nez v3, :cond_4

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 44
    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    :cond_4
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$$serializer;

    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 50
    .line 51
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 52
    .line 53
    .line 54
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getAddress_form_fields_config()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSupported_cc_types()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getType()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 15
    .line 16
    invoke-static {v0}, LX/006;->A0G(Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    add-int/2addr v1, v0

    .line 21
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
