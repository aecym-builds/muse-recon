.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;
    .locals 3

    .line 0
    const/4 p0, 0x0

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->getEntries()LX/0vk;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    move-object v0, v1

    .line 22
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 23
    .line 24
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->access$getWireValues$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;)Ljava/util/Set;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    move-object p0, v1

    .line 35
    :cond_1
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 36
    .line 37
    :cond_2
    return-object p0
.end method
