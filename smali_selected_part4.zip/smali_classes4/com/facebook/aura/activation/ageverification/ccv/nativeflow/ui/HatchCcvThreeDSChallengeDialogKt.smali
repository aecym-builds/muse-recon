.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final AUTH_RESULT_PARAM:Ljava/lang/String; = "auth_result"

.field public static final AUTH_RESULT_SUCCESS:Ljava/lang/String; = "Success"

.field public static final COMPLETION_HOST:Ljava/lang/String; = "www.ecpthreeds.com"

.field public static final HTTPS_SCHEME:Ljava/lang/String; = "https"


# direct methods
.method public static final HatchCcvThreeDSChallengeDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p2

    .line 1
    .line 2
    const/4 v10, 0x0

    .line 3
    move-object v4, p0

    .line 4
    move-object v3, p1

    .line 5
    invoke-static {p0, p1}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v9

    .line 9
    const v0, -0x54479107

    .line 10
    .line 11
    .line 12
    move-object/from16 v13, p3

    .line 13
    .line 14
    invoke-interface {v13, v0}, LX/2d4;->Agl(I)V

    .line 15
    .line 16
    .line 17
    move/from16 v2, p4

    .line 18
    .line 19
    and-int/lit8 v0, p4, 0x6

    .line 20
    .line 21
    if-nez v0, :cond_a

    .line 22
    .line 23
    invoke-static {v13, p0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    or-int v6, v6, p4

    .line 28
    .line 29
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 30
    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    invoke-static {v13, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    or-int/2addr v6, v0

    .line 38
    :cond_0
    and-int/lit8 v5, p5, 0x4

    .line 39
    .line 40
    if-eqz v5, :cond_9

    .line 41
    .line 42
    or-int/lit16 v6, v6, 0x180

    .line 43
    .line 44
    :cond_1
    :goto_1
    invoke-static {v6}, LX/005;->A1I(I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {v0, v13, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_8

    .line 53
    .line 54
    if-eqz v5, :cond_2

    .line 55
    .line 56
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 57
    .line 58
    :cond_2
    invoke-static {v13, p1}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    invoke-interface {v13, p0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v6

    .line 70
    if-nez v0, :cond_3

    .line 71
    .line 72
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 73
    .line 74
    if-ne v6, v0, :cond_4

    .line 75
    .line 76
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;

    .line 77
    .line 78
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;-><init>(LX/16A;)V

    .line 79
    .line 80
    .line 81
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;

    .line 82
    .line 83
    invoke-direct {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;-><init>(LX/JDM;)V

    .line 84
    .line 85
    .line 86
    invoke-interface {v13, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :cond_4
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;

    .line 90
    .line 91
    invoke-interface {v13, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-interface {v13}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    if-nez v0, :cond_5

    .line 100
    .line 101
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 102
    .line 103
    if-ne p1, v0, :cond_6

    .line 104
    .line 105
    :cond_5
    new-instance p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;

    .line 106
    .line 107
    invoke-direct {p1, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;)V

    .line 108
    .line 109
    .line 110
    invoke-interface {v13, p1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_6
    check-cast p1, Lkotlin/jvm/functions/Function0;

    .line 114
    .line 115
    sget-object v8, LX/FkO;->A01:Ljava/lang/Integer;

    .line 116
    .line 117
    new-instance v7, LX/0yv;

    .line 118
    .line 119
    move v11, v10

    .line 120
    move v12, v9

    .line 121
    invoke-direct/range {v7 .. v12}, LX/0yv;-><init>(Ljava/lang/Integer;ZZZZ)V

    .line 122
    .line 123
    .line 124
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$2;

    .line 125
    .line 126
    invoke-direct {v5, p0, v6, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;LX/3C1;)V

    .line 127
    .line 128
    .line 129
    const v0, -0x275fb530

    .line 130
    .line 131
    .line 132
    invoke-static {v13, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 133
    .line 134
    .line 135
    move-result-object p2

    .line 136
    const/16 p3, 0x180

    .line 137
    .line 138
    move-object p0, v7

    .line 139
    move/from16 p4, v10

    .line 140
    .line 141
    invoke-static/range {v13 .. v18}, LX/1VW;->A00(LX/2d4;LX/0yv;Lkotlin/jvm/functions/Function0;LX/JDN;II)V

    .line 142
    .line 143
    .line 144
    :goto_2
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 145
    .line 146
    .line 147
    move-result-object v5

    .line 148
    if-eqz v5, :cond_7

    .line 149
    .line 150
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$3;

    .line 151
    .line 152
    move-object/from16 p2, v3

    .line 153
    .line 154
    move-object/from16 p3, v1

    .line 155
    .line 156
    move/from16 p4, v2

    .line 157
    .line 158
    move-object p0, v0

    .line 159
    move-object p1, v4

    .line 160
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$3;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;II)V

    .line 161
    .line 162
    .line 163
    iput-object v0, v5, LX/J7V;->A06:LX/JDN;

    .line 164
    .line 165
    :cond_7
    return-void

    .line 166
    :cond_8
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 167
    .line 168
    .line 169
    goto :goto_2

    .line 170
    :cond_9
    and-int/lit16 v0, v2, 0x180

    .line 171
    .line 172
    if-nez v0, :cond_1

    .line 173
    .line 174
    invoke-static {v13, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    or-int/2addr v6, v0

    .line 179
    goto/16 :goto_1

    .line 180
    .line 181
    :cond_a
    move v6, v2

    .line 182
    goto/16 :goto_0
.end method

.method public static final HatchCcvThreeDSChallengeDialog$lambda$0(LX/16A;)LX/JDM;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A07(LX/16A;)LX/JDM;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final ThreeDSChallengeWebView(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    const v0, -0x482a291a

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    const/4 v9, 0x2

    .line 15
    move-object/from16 v5, p0

    .line 16
    .line 17
    if-nez v0, :cond_b

    .line 18
    .line 19
    invoke-static {v2, v5}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 20
    .line 21
    .line 22
    move-result v7

    .line 23
    or-int v7, v7, p4

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 26
    .line 27
    const/16 v6, 0x20

    .line 28
    .line 29
    move-object/from16 v4, p1

    .line 30
    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    invoke-static {v2, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    or-int/2addr v7, v0

    .line 38
    :cond_0
    and-int/lit8 v11, p5, 0x4

    .line 39
    .line 40
    if-eqz v11, :cond_a

    .line 41
    .line 42
    or-int/lit16 v7, v7, 0x180

    .line 43
    .line 44
    :cond_1
    :goto_1
    and-int/lit16 v10, v7, 0x93

    .line 45
    .line 46
    const/16 v0, 0x92

    .line 47
    .line 48
    const/4 v8, 0x0

    .line 49
    invoke-static {v10, v0}, LX/003;->A1H(II)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    invoke-static {v0, v2, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_9

    .line 58
    .line 59
    if-eqz v11, :cond_2

    .line 60
    .line 61
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 62
    .line 63
    :cond_2
    iget-object v10, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;->method:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 64
    .line 65
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;->POST:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 66
    .line 67
    const/4 v14, 0x0

    .line 68
    if-ne v10, v0, :cond_8

    .line 69
    .line 70
    const v0, 0x1dbe614b

    .line 71
    .line 72
    .line 73
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 74
    .line 75
    .line 76
    iget-object v9, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;->url:Ljava/lang/String;

    .line 77
    .line 78
    new-array v0, v8, [B

    .line 79
    .line 80
    invoke-static {v9, v0, v2, v8}, Lcom/facebook/aura/webview/HatchWebViewKt;->rememberWebViewState(Ljava/lang/String;[BLX/2d4;I)Lcom/facebook/aura/webview/WebViewState;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    move-object v0, v2

    .line 85
    check-cast v0, LX/J7I;

    .line 86
    .line 87
    const/4 v11, 0x0

    .line 88
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 89
    .line 90
    .line 91
    :goto_2
    and-int/lit8 v0, v7, 0x70

    .line 92
    .line 93
    if-ne v0, v6, :cond_3

    .line 94
    .line 95
    const/4 v8, 0x1

    .line 96
    :cond_3
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-nez v8, :cond_4

    .line 101
    .line 102
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 103
    .line 104
    if-ne v0, v6, :cond_5

    .line 105
    .line 106
    :cond_4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ThreeDSChallengeClient;

    .line 107
    .line 108
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ThreeDSChallengeClient;-><init>(LX/JDM;)V

    .line 109
    .line 110
    .line 111
    invoke-interface {v2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    :cond_5
    check-cast v0, Lcom/facebook/aura/webview/AccompanistWebViewClient;

    .line 115
    .line 116
    sget-object v6, LX/2sI;->A01:LX/2wD;

    .line 117
    .line 118
    invoke-interface {v3, v6}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 119
    .line 120
    .line 121
    move-result-object v10

    .line 122
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v15

    .line 126
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 127
    .line 128
    if-ne v15, v6, :cond_6

    .line 129
    .line 130
    sget-object v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$ThreeDSChallengeWebView$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$ThreeDSChallengeWebView$1$1;

    .line 131
    .line 132
    invoke-interface {v2, v15}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    :cond_6
    check-cast v15, LX/JDM;

    .line 136
    .line 137
    sget v6, Lcom/facebook/aura/webview/AccompanistWebViewClient;->$stable:I

    .line 138
    .line 139
    shl-int/lit8 p2, v6, 0x1b

    .line 140
    .line 141
    const v6, 0x180d80

    .line 142
    .line 143
    .line 144
    or-int p2, p2, v6

    .line 145
    .line 146
    const/16 p4, 0xdb0

    .line 147
    .line 148
    const/4 v12, 0x1

    .line 149
    move v13, v11

    .line 150
    move-object/from16 v16, v14

    .line 151
    .line 152
    move/from16 v17, v11

    .line 153
    .line 154
    move-object/from16 v19, v14

    .line 155
    .line 156
    move-object/from16 p0, v14

    .line 157
    .line 158
    move-object/from16 p1, v2

    .line 159
    .line 160
    move/from16 p3, v11

    .line 161
    .line 162
    move-object/from16 v18, v0

    .line 163
    .line 164
    invoke-static/range {v9 .. v24}, Lcom/facebook/aura/webview/HatchWebViewKt;->WebView(Lcom/facebook/aura/webview/WebViewState;LX/3C1;ZZZLcom/facebook/aura/webview/WebViewNavigator;LX/JDM;LX/JDM;ZLcom/facebook/aura/webview/AccompanistWebViewClient;Lcom/facebook/aura/webview/AccompanistWebChromeClient;LX/JDM;LX/2d4;III)V

    .line 165
    .line 166
    .line 167
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    if-eqz v2, :cond_7

    .line 172
    .line 173
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$ThreeDSChallengeWebView$2;

    .line 174
    .line 175
    move-object/from16 p0, v0

    .line 176
    .line 177
    move-object/from16 p1, v5

    .line 178
    .line 179
    move-object/from16 p2, v4

    .line 180
    .line 181
    move-object/from16 p3, v3

    .line 182
    .line 183
    move/from16 p4, v1

    .line 184
    .line 185
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$ThreeDSChallengeWebView$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;II)V

    .line 186
    .line 187
    .line 188
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 189
    .line 190
    :cond_7
    return-void

    .line 191
    :cond_8
    const v0, 0x1dbfaf64

    .line 192
    .line 193
    .line 194
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 195
    .line 196
    .line 197
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;->url:Ljava/lang/String;

    .line 198
    .line 199
    invoke-static {v0, v14, v2, v8, v9}, Lcom/facebook/aura/webview/HatchWebViewKt;->rememberWebViewState(Ljava/lang/String;LX/IZf;LX/2d4;II)Lcom/facebook/aura/webview/WebViewState;

    .line 200
    .line 201
    .line 202
    move-result-object v9

    .line 203
    move-object v0, v2

    .line 204
    check-cast v0, LX/J7I;

    .line 205
    .line 206
    const/4 v11, 0x0

    .line 207
    invoke-static {v0, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 208
    .line 209
    .line 210
    goto :goto_2

    .line 211
    :cond_9
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 212
    .line 213
    .line 214
    goto :goto_3

    .line 215
    :cond_a
    and-int/lit16 v0, v1, 0x180

    .line 216
    .line 217
    if-nez v0, :cond_1

    .line 218
    .line 219
    invoke-static {v2, v3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    or-int/2addr v7, v0

    .line 224
    goto/16 :goto_1

    .line 225
    .line 226
    :cond_b
    move v7, v1

    .line 227
    goto/16 :goto_0
.end method

.method public static final synthetic access$HatchCcvThreeDSChallengeDialog$lambda$0(LX/16A;)LX/JDM;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A07(LX/16A;)LX/JDM;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$ThreeDSChallengeWebView(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt;->ThreeDSChallengeWebView(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
