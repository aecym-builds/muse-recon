.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $currentOnDismissed$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;->$currentOnDismissed$delegate:LX/16A;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 268435457
    .line 268435458
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->uiState:LX/2J3;

    .line 268435459
    .line 268435460
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 268435465
    .line 268435466
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 268435467
    .line 268435468
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$Cancelled;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$Cancelled;

    .line 268435469
    .line 268435470
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268435471
    .line 268435472
    .line 268435473
    move-result v0

    .line 268435474
    if-eqz v0, :cond_0

    .line 268435475
    .line 268435476
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;->DISMISSED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;

    .line 268435477
    .line 268435478
    const/4 v0, 0x0

    .line 268435479
    invoke-static {v1, v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 268435480
    .line 268435481
    .line 268435482
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;->$currentOnDismissed$delegate:LX/16A;

    .line 268435483
    .line 268435484
    invoke-static {v0}, LX/16A;->A09(LX/16A;)V

    .line 268435485
    .line 268435486
    .line 268435487
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435488
    .line 268435489
    return-object v0

    .line 268435490
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;

    .line 268435491
    .line 268435492
    if-eqz v0, :cond_1

    .line 268435493
    .line 268435494
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;->CHECKOUT_UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;

    .line 268435495
    .line 268435496
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;

    .line 268435497
    .line 268435498
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;->reason:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 268435499
    .line 268435500
    invoke-static {v1, v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 268435501
    .line 268435502
    .line 268435503
    goto :goto_0

    .line 268435504
    :cond_1
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 268435505
    .line 268435506
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 268435507
    .line 268435508
    .line 268435509
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1$1;->emit(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
.end method
