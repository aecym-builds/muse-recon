.class public final enum Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;

.field public static final enum NUMBER:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

.field public static final enum UPPERCASE_TEXT:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;


# instance fields
.field public final wireValues:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    const-string v0, "NUMERICAL"

    .line 1
    .line 2
    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    const-string v2, "NUMBER"

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 10
    .line 11
    invoke-direct {v0, v2, v1, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;-><init>(Ljava/lang/String;ILjava/util/Set;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->NUMBER:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 15
    .line 16
    const-string v1, "STRING_UPPERCASE"

    .line 17
    .line 18
    const-string v0, "ALPHA_NUMERIC_UPPERCASE"

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    invoke-static {v1, v0}, LX/0wJ;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Set;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    const-string v0, "UPPERCASE_TEXT"

    .line 26
    .line 27
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 28
    .line 29
    invoke-direct {v1, v0, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;-><init>(Ljava/lang/String;ILjava/util/Set;)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->UPPERCASE_TEXT:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->NUMBER:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 35
    .line 36
    filled-new-array {v0, v1}, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 41
    .line 42
    new-instance v0, LX/DvM;

    .line 43
    .line 44
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->$ENTRIES:LX/0vk;

    .line 48
    .line 49
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;

    .line 50
    .line 51
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 52
    .line 53
    .line 54
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;

    .line 55
    .line 56
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/util/Set;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->wireValues:Ljava/util/Set;

    .line 4
    .line 5
    return-void
.end method

.method public static final synthetic access$getWireValues$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;)Ljava/util/Set;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->wireValues:Ljava/util/Set;

    .line 1
    .line 2
    return-object p0
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 7
    .line 8
    return-object v0
.end method
