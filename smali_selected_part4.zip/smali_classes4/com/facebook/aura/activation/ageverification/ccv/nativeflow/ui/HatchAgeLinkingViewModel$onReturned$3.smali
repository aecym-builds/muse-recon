.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.ui.HatchAgeLinkingViewModel$onReturned$3"
    f = "HatchAgeLinking.kt"
    l = {
        0xab
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $attemptId:Ljava/lang/String;

.field public final synthetic $current:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

.field public final synthetic $method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$attemptId:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$current:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$attemptId:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$current:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;-><init>(Ljava/lang/String;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    if-ne v0, v2, :cond_5

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 15
    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 19
    .line 20
    invoke-static {v0, v1, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->access$logLinkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)V

    .line 21
    .line 22
    .line 23
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 24
    .line 25
    invoke-static {v0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->access$linkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    if-eqz v3, :cond_2

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 32
    .line 33
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 34
    .line 35
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_returns:LX/EYl;

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 38
    .line 39
    invoke-direct {v0, v2, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;-><init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->RESTART_LINKING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 46
    .line 47
    if-ne p1, v0, :cond_3

    .line 48
    .line 49
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$current:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 52
    .line 53
    iget v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 54
    .line 55
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->access$optionsChanged(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;I)V

    .line 56
    .line 57
    .line 58
    :cond_3
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$current:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 61
    .line 62
    iget v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 63
    .line 64
    invoke-static {v2, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->access$toBloksLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->access$finish(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 69
    .line 70
    .line 71
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 72
    .line 73
    return-object v0

    .line 74
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;

    .line 78
    .line 79
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->$attemptId:Ljava/lang/String;

    .line 80
    .line 81
    iput v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;->label:I

    .line 82
    .line 83
    invoke-virtual {v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->completeWebAuth(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    if-ne p1, v3, :cond_0

    .line 88
    .line 89
    return-object v3

    .line 90
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    throw v0
.end method
