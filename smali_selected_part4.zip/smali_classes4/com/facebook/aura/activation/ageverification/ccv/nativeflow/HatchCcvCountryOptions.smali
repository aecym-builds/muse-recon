.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
.super LX/07H;
.source ""


# instance fields
.field public final countries:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation
.end field

.field public final defaultCountry:Ljava/lang/String;

.field public final onlyDefaultCountryAllowed:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/Ddn;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 9
    .line 10
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;LX/Ddn;ZILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p4, 0x2

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    sget-object p2, LX/Dwg;->A01:LX/Dwg;

    .line 268435461
    .line 268435462
    :cond_0
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 268435463
    .line 268435464
    .line 268435465
    move-result v0

    .line 268435466
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;-><init>(Ljava/lang/String;LX/Ddn;Z)V

    .line 268435467
    .line 268435468
    .line 268435469
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;LX/Ddn;ZILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->copy(Ljava/lang/String;LX/Ddn;Z)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 1
    .line 2
    return p0
.end method

.method public final configFor(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    move-object v0, v1

    .line 17
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    :goto_0
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 28
    .line 29
    return-object v1

    .line 30
    :cond_1
    const/4 v1, 0x0

    .line 31
    goto :goto_0
.end method

.method public final copy(Ljava/lang/String;LX/Ddn;Z)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;Z)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;-><init>(Ljava/lang/String;LX/Ddn;Z)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 31
    .line 32
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 33
    .line 34
    if-eq v1, v0, :cond_1

    .line 35
    .line 36
    :cond_0
    return v2

    .line 37
    :cond_1
    return v3
.end method

.method public final getCountries()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDefaultCountry()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOnlyDefaultCountryAllowed()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final isCountrySelectable()Z
    .locals 1

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->onlyDefaultCountryAllowed:Z

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 5
    .line 6
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    const/4 v0, 0x1

    .line 11
    if-le p0, v0, :cond_0

    .line 12
    .line 13
    return v0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
