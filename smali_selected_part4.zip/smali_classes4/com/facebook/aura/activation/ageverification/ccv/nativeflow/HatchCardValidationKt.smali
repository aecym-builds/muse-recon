.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final failedPostalRule(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;"
        }
    .end annotation

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p0, p1}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    invoke-static {p0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 p0, 0x0

    .line 18
    if-eqz v0, :cond_7

    .line 19
    .line 20
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 25
    .line 26
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->type:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eq v1, v3, :cond_3

    .line 33
    .line 34
    if-eq v1, v2, :cond_2

    .line 35
    .line 36
    const/4 v0, 0x2

    .line 37
    if-eq v1, v0, :cond_1

    .line 38
    .line 39
    const/4 v0, 0x3

    .line 40
    if-ne v1, v0, :cond_6

    .line 41
    .line 42
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->value:Ljava/lang/String;

    .line 43
    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    invoke-static {v0}, LX/0wP;->A00(Ljava/lang/String;)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-gt v0, v1, :cond_5

    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_1
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->value:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v0, :cond_0

    .line 66
    .line 67
    invoke-static {v0}, LX/0wP;->A00(Ljava/lang/String;)Ljava/lang/Integer;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    if-eqz v0, :cond_0

    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-lt v0, v1, :cond_5

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_2
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->value:Ljava/lang/String;

    .line 85
    .line 86
    if-eqz v0, :cond_0

    .line 87
    .line 88
    invoke-static {v0}, LX/0wP;->A00(Ljava/lang/String;)Ljava/lang/Integer;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-eqz v0, :cond_0

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-ne v0, v1, :cond_5

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_3
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->value:Ljava/lang/String;

    .line 106
    .line 107
    if-eqz v1, :cond_0

    .line 108
    .line 109
    :try_start_0
    new-instance v0, LX/BAQ;

    .line 110
    .line 111
    invoke-direct {v0, v1}, LX/BAQ;-><init>(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0, v4}, LX/BAQ;->A07(Ljava/lang/CharSequence;)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    goto :goto_1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 123
    :catchall_0
    move-exception v0

    .line 124
    new-instance v1, LX/2PH;

    .line 125
    .line 126
    invoke-direct {v1, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    :goto_1
    instance-of v0, v1, LX/2PH;

    .line 130
    .line 131
    if-nez v0, :cond_4

    .line 132
    .line 133
    move-object p0, v1

    .line 134
    :cond_4
    check-cast p0, Ljava/lang/Boolean;

    .line 135
    .line 136
    if-eqz p0, :cond_0

    .line 137
    .line 138
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-nez v0, :cond_0

    .line 143
    .line 144
    :cond_5
    return-object v5

    .line 145
    :cond_6
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 146
    .line 147
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 148
    .line 149
    .line 150
    throw v0

    .line 151
    :cond_7
    return-object p0
.end method

.method public static final isCardFormComplete(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/util/List;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    invoke-static {p1, p2, p3, v1}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x5

    .line 9
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 10
    .line 11
    .line 12
    invoke-static {p0, p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePan(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateExpiry(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    invoke-static {p2, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateSecurityCode(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->isPostalComplete(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    return v1

    .line 37
    :cond_0
    return v2
.end method

.method public static synthetic isCardFormComplete$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/util/List;ILjava/lang/Object;)Z
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x20

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p5, LX/0wV;->A00:LX/0wV;

    .line 5
    .line 6
    :cond_0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->isCardFormComplete(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/util/List;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0
.end method

.method public static final isPostalComplete(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    invoke-static {p0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    iget-boolean v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->isOptional:Z

    .line 18
    .line 19
    :cond_0
    return v1

    .line 20
    :cond_1
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->validationRules:LX/Ddn;

    .line 21
    .line 22
    invoke-static {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->failedPostalRule(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    return v2
.end method

.method public static final toFieldError(Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;LX/JDM;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;",
            "Z",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFailure;",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Valid;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Valid;

    .line 1
    .line 2
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    const/4 p3, 0x0

    .line 9
    :cond_0
    return-object p3

    .line 10
    :cond_1
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Pending;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Pending;

    .line 11
    .line 12
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    return-object p2

    .line 21
    :cond_2
    instance-of v0, p0, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Invalid;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    check-cast p0, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Invalid;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState$Invalid;->failure:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFailure;

    .line 28
    .line 29
    invoke-interface {p4, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p3

    .line 33
    check-cast p3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 34
    .line 35
    return-object p3

    .line 36
    :cond_3
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 37
    .line 38
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 39
    .line 40
    .line 41
    throw v0
.end method

.method public static final toPostalRules(Ljava/util/List;)Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/602;->A0n(Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1
    .line 2
    .line 3
    move-result-object v6

    .line 4
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;

    .line 19
    .line 20
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType$Companion;

    .line 21
    .line 22
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;->type:Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    if-eqz v3, :cond_0

    .line 29
    .line 30
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;->error_message:Ljava/lang/String;

    .line 31
    .line 32
    if-eqz v2, :cond_0

    .line 33
    .line 34
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;->value:Ljava/lang/String;

    .line 41
    .line 42
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 43
    .line 44
    invoke-direct {v0, v3, v1, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalRuleType;Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    return-object v6
.end method

.method public static final unsupportedBrandError(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->Companion:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;

    .line 4
    .line 5
    invoke-virtual {v0, p0, p1}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;->accepts(Ljava/lang/String;Ljava/util/List;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0

    .line 13
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_UNSUPPORTED_BRAND:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 14
    .line 15
    return-object v0
.end method

.method public static final validateExpiry(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;

    .line 5
    .line 6
    invoke-static {}, Ljava/time/YearMonth;->now()Ljava/time/YearMonth;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, p0, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->expiration(Ljava/lang/String;Ljava/time/YearMonth;)Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    invoke-static {p0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-static {v0}, LX/003;->A1C(I)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 30
    .line 31
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_MALFORMED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateExpiry$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateExpiry$1;

    .line 34
    .line 35
    invoke-static {v4, v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->toFieldError(Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;LX/JDM;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    return-object v0
.end method

.method public static final validatePan(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v2

    .line 7
    invoke-static {v2, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->unsupportedBrandError(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;

    .line 14
    .line 15
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 16
    .line 17
    invoke-virtual {v1, p0, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->cardNumber(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-static {v0}, LX/003;->A1C(I)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 30
    .line 31
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_INCOMPLETE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validatePan$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validatePan$2;

    .line 34
    .line 35
    invoke-static {p1, p0, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->toFieldError(Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;LX/JDM;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :cond_0
    return-object v0
.end method

.method public static final validatePostalField(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;)LX/IBK;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;",
            ")",
            "LX/IBK<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz p1, :cond_1

    .line 6
    .line 7
    invoke-static {p0}, LX/0wP;->A02(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->isOptional:Z

    .line 18
    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->ZIP_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 22
    .line 23
    new-instance v1, LX/IBK;

    .line 24
    .line 25
    invoke-direct {v1, v0, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    return-object v1

    .line 29
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->validationRules:LX/Ddn;

    .line 30
    .line 31
    invoke-static {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->failedPostalRule(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    new-instance v1, LX/IBK;

    .line 36
    .line 37
    invoke-direct {v1, v2, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    return-object v1

    .line 41
    :cond_1
    new-instance v1, LX/IBK;

    .line 42
    .line 43
    invoke-direct {v1, v2, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    return-object v1
.end method

.method public static final validateSecurityCode(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 3

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;

    .line 4
    .line 5
    invoke-virtual {v0, p0, p1}, Lcom/facebook/aura/payments/cardvalidation/HatchCardValidator;->securityCode(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-static {p0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v0}, LX/003;->A1C(I)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 22
    .line 23
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_WRONG_LENGTH:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt$validateSecurityCode$1;

    .line 26
    .line 27
    invoke-static {p1, p0, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->toFieldError(Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;LX/JDM;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method
