.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final HatchAgeLinkingLauncher(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object/from16 v8, p0

    .line 2
    .line 3
    invoke-static {v8, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    move-object/from16 v7, p2

    .line 8
    .line 9
    move-object/from16 v6, p3

    .line 10
    .line 11
    move-object/from16 v0, p1

    .line 12
    .line 13
    invoke-static {v0, v7, v6, v2}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    const v0, -0x156dcfe1

    .line 17
    .line 18
    .line 19
    move-object/from16 v10, p4

    .line 20
    .line 21
    invoke-interface {v10, v0}, LX/2d4;->Agl(I)V

    .line 22
    .line 23
    .line 24
    move/from16 v9, p5

    .line 25
    .line 26
    and-int/lit8 v0, p5, 0x6

    .line 27
    .line 28
    const/4 v5, 0x4

    .line 29
    if-nez v0, :cond_19

    .line 30
    .line 31
    invoke-static {v8, v10, v9}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0}, LX/003;->A06(I)I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    or-int v4, v4, p5

    .line 40
    .line 41
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 42
    .line 43
    if-nez v0, :cond_0

    .line 44
    .line 45
    move-object/from16 v0, p1

    .line 46
    .line 47
    invoke-static {v10, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v4, v0

    .line 52
    :cond_0
    and-int/lit16 v0, v9, 0x180

    .line 53
    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    invoke-static {v10, v7}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    or-int/2addr v4, v0

    .line 61
    :cond_1
    and-int/lit16 v0, v9, 0xc00

    .line 62
    .line 63
    if-nez v0, :cond_2

    .line 64
    .line 65
    invoke-static {v10, v6}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    or-int/2addr v4, v0

    .line 70
    :cond_2
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-static {v0, v10, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_18

    .line 79
    .line 80
    invoke-static {v10}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 85
    .line 86
    invoke-interface {v10, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    check-cast v3, Landroid/app/Activity;

    .line 91
    .line 92
    invoke-interface {v10, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    and-int/lit8 v11, v4, 0xe

    .line 97
    .line 98
    if-eq v11, v5, :cond_3

    .line 99
    .line 100
    and-int/lit8 v0, v4, 0x8

    .line 101
    .line 102
    if-eqz v0, :cond_17

    .line 103
    .line 104
    invoke-interface {v10, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_17

    .line 109
    .line 110
    :cond_3
    const/4 v0, 0x1

    .line 111
    :goto_1
    or-int/2addr v2, v0

    .line 112
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    if-nez v2, :cond_4

    .line 117
    .line 118
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 119
    .line 120
    if-ne v0, v2, :cond_5

    .line 121
    .line 122
    :cond_4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$1$1;

    .line 123
    .line 124
    invoke-direct {v0, v3, v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$1$1;-><init>(Landroid/app/Activity;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;)V

    .line 125
    .line 126
    .line 127
    invoke-interface {v10, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_5
    invoke-static {v10, v0, v8}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    move-object/from16 v0, p1

    .line 134
    .line 135
    invoke-static {v10, v0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 136
    .line 137
    .line 138
    move-result-object v18

    .line 139
    invoke-static {v10, v7}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    invoke-static {v10, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    if-eq v11, v5, :cond_6

    .line 148
    .line 149
    and-int/lit8 v0, v4, 0x8

    .line 150
    .line 151
    if-eqz v0, :cond_16

    .line 152
    .line 153
    invoke-interface {v10, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    if-eqz v0, :cond_16

    .line 158
    .line 159
    :cond_6
    const/4 v0, 0x1

    .line 160
    :goto_2
    invoke-static {v10, v3, v0}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 161
    .line 162
    .line 163
    move-result v12

    .line 164
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    const/4 v13, 0x0

    .line 169
    if-nez v12, :cond_7

    .line 170
    .line 171
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 172
    .line 173
    if-ne v0, v12, :cond_8

    .line 174
    .line 175
    :cond_7
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$2$1;

    .line 176
    .line 177
    invoke-direct {v0, v8, v3, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;LX/16A;LX/2M4;)V

    .line 178
    .line 179
    .line 180
    invoke-interface {v10, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    :cond_8
    invoke-static {v10, v0, v8}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    iget-object v0, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->state:LX/2J3;

    .line 187
    .line 188
    invoke-static {v10, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 189
    .line 190
    .line 191
    move-result-object v17

    .line 192
    invoke-interface/range {v17 .. v17}, LX/16A;->getValue()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 197
    .line 198
    iget v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 199
    .line 200
    new-array v0, v1, [Ljava/lang/Object;

    .line 201
    .line 202
    move-object v15, v0

    .line 203
    invoke-interface {v10, v12}, LX/2d4;->A67(I)Z

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v14

    .line 211
    if-nez v0, :cond_9

    .line 212
    .line 213
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 214
    .line 215
    if-ne v14, v0, :cond_a

    .line 216
    .line 217
    :cond_9
    new-instance v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$consumedOptionsVersion$2$1;

    .line 218
    .line 219
    invoke-direct {v14, v12}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$consumedOptionsVersion$2$1;-><init>(I)V

    .line 220
    .line 221
    .line 222
    invoke-interface {v10, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    :cond_a
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 226
    .line 227
    invoke-static {v10, v14, v15}, LX/39E;->A05(LX/2d4;Lkotlin/jvm/functions/Function0;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v15

    .line 231
    check-cast v15, LX/CR1;

    .line 232
    .line 233
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 234
    .line 235
    .line 236
    move-result-object v16

    .line 237
    invoke-interface {v10, v12}, LX/2d4;->A67(I)Z

    .line 238
    .line 239
    .line 240
    move-result v0

    .line 241
    invoke-static {v10, v15, v2, v0}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 242
    .line 243
    .line 244
    move-result v0

    .line 245
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v14

    .line 249
    if-nez v0, :cond_b

    .line 250
    .line 251
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 252
    .line 253
    if-ne v14, v0, :cond_c

    .line 254
    .line 255
    :cond_b
    new-instance v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$3$1;

    .line 256
    .line 257
    invoke-direct {v14, v12, v15, v2, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$3$1;-><init>(ILX/CR1;LX/16A;LX/2M4;)V

    .line 258
    .line 259
    .line 260
    invoke-interface {v10, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    :cond_c
    move-object/from16 v0, v16

    .line 264
    .line 265
    invoke-static {v10, v14, v0}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    invoke-interface/range {v17 .. v17}, LX/16A;->getValue()Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 273
    .line 274
    iget v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 275
    .line 276
    new-array v12, v1, [Ljava/lang/Object;

    .line 277
    .line 278
    invoke-interface {v10, v13}, LX/2d4;->A67(I)Z

    .line 279
    .line 280
    .line 281
    move-result v1

    .line 282
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v0

    .line 286
    if-nez v1, :cond_d

    .line 287
    .line 288
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 289
    .line 290
    if-ne v0, v1, :cond_e

    .line 291
    .line 292
    :cond_d
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$consumedActivationVersion$2$1;

    .line 293
    .line 294
    invoke-direct {v0, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$consumedActivationVersion$2$1;-><init>(I)V

    .line 295
    .line 296
    .line 297
    invoke-interface {v10, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    :cond_e
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 301
    .line 302
    invoke-static {v10, v0, v12}, LX/39E;->A05(LX/2d4;Lkotlin/jvm/functions/Function0;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v14

    .line 306
    check-cast v14, LX/CR1;

    .line 307
    .line 308
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 309
    .line 310
    .line 311
    move-result-object v12

    .line 312
    invoke-interface {v10, v13}, LX/2d4;->A67(I)Z

    .line 313
    .line 314
    .line 315
    move-result v0

    .line 316
    invoke-static {v10, v14, v3, v0}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 317
    .line 318
    .line 319
    move-result v0

    .line 320
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    if-nez v0, :cond_f

    .line 325
    .line 326
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 327
    .line 328
    if-ne v1, v0, :cond_10

    .line 329
    .line 330
    :cond_f
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;

    .line 331
    .line 332
    invoke-direct {v1, v13, v14, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;-><init>(ILX/CR1;LX/16A;)V

    .line 333
    .line 334
    .line 335
    invoke-interface {v10, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    :cond_10
    move-object/from16 v0, v17

    .line 339
    .line 340
    invoke-static {v10, v0, v1, v12}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 345
    .line 346
    iget-object v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->launch:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 347
    .line 348
    invoke-interface {v10, v12}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 349
    .line 350
    .line 351
    move-result v13

    .line 352
    move-object/from16 v1, v18

    .line 353
    .line 354
    move-object/from16 v0, p0

    .line 355
    .line 356
    invoke-static {v10, v1, v0, v13}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    if-eq v11, v5, :cond_11

    .line 361
    .line 362
    and-int/lit8 v0, v4, 0x8

    .line 363
    .line 364
    if-eqz v0, :cond_15

    .line 365
    .line 366
    invoke-interface {v10, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 367
    .line 368
    .line 369
    move-result v0

    .line 370
    if-eqz v0, :cond_15

    .line 371
    .line 372
    :cond_11
    const/4 v0, 0x1

    .line 373
    :goto_3
    or-int/2addr v1, v0

    .line 374
    invoke-static {v10, v3, v2, v1}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 375
    .line 376
    .line 377
    move-result v1

    .line 378
    invoke-interface {v10}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    if-nez v1, :cond_12

    .line 383
    .line 384
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 385
    .line 386
    if-ne v0, v1, :cond_13

    .line 387
    .line 388
    :cond_12
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$5$1;

    .line 389
    .line 390
    move-object/from16 v13, p0

    .line 391
    .line 392
    move-object v14, v8

    .line 393
    move-object/from16 v15, v18

    .line 394
    .line 395
    move-object/from16 v16, v3

    .line 396
    .line 397
    move-object/from16 v17, v2

    .line 398
    .line 399
    move-object v11, v0

    .line 400
    invoke-direct/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$5$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;LX/16A;LX/16A;LX/16A;)V

    .line 401
    .line 402
    .line 403
    invoke-interface {v10, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    :cond_13
    invoke-static {v10, v0, v12}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 407
    .line 408
    .line 409
    :goto_4
    invoke-interface {v10}, LX/2d4;->AAg()LX/J7V;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    if-eqz v0, :cond_14

    .line 414
    .line 415
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$6;

    .line 416
    .line 417
    move-object v2, v8

    .line 418
    move-object/from16 v3, p1

    .line 419
    .line 420
    move-object v4, v7

    .line 421
    move-object v5, v6

    .line 422
    move v6, v9

    .line 423
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$6;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;I)V

    .line 424
    .line 425
    .line 426
    iput-object v1, v0, LX/J7V;->A06:LX/JDN;

    .line 427
    .line 428
    :cond_14
    return-void

    .line 429
    :cond_15
    const/4 v0, 0x0

    .line 430
    goto :goto_3

    .line 431
    :cond_16
    const/4 v0, 0x0

    .line 432
    goto/16 :goto_2

    .line 433
    .line 434
    :cond_17
    const/4 v0, 0x0

    .line 435
    goto/16 :goto_1

    .line 436
    .line 437
    :cond_18
    invoke-interface {v10}, LX/2d4;->AgJ()V

    .line 438
    .line 439
    .line 440
    goto :goto_4

    .line 441
    :cond_19
    move v4, v9

    .line 442
    goto/16 :goto_0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$11(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$12(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchAgeLinkingLauncher$lambda$2(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$3(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$5(LX/16A;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$7(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchAgeLinkingLauncher$lambda$8(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchCcvCardEntryHost(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 61
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v24, p8

    .line 1
    .line 2
    const/16 v26, 0x0

    .line 3
    .line 4
    move-object/from16 v1, p0

    .line 5
    .line 6
    move/from16 v0, v26

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 9
    .line 10
    .line 11
    const/4 v3, 0x1

    .line 12
    move-object/from16 v60, p1

    .line 13
    .line 14
    move-object/from16 v48, p2

    .line 15
    .line 16
    move-object/from16 v59, p3

    .line 17
    .line 18
    move-object/from16 v2, v60

    .line 19
    .line 20
    move-object/from16 v1, v48

    .line 21
    .line 22
    move-object/from16 v0, v59

    .line 23
    .line 24
    invoke-static {v2, v1, v0, v3}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    const/4 v2, 0x5

    .line 28
    move-object/from16 v58, p5

    .line 29
    .line 30
    move-object/from16 v57, p7

    .line 31
    .line 32
    move-object/from16 v1, v58

    .line 33
    .line 34
    move-object/from16 v0, v57

    .line 35
    .line 36
    invoke-static {v1, v2, v0}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    const v0, 0x56855788

    .line 40
    .line 41
    .line 42
    move-object/from16 v3, p9

    .line 43
    .line 44
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 45
    .line 46
    .line 47
    move/from16 v15, p10

    .line 48
    .line 49
    and-int/lit8 v0, p10, 0x6

    .line 50
    .line 51
    if-nez v0, :cond_45

    .line 52
    .line 53
    move-object/from16 v0, p0

    .line 54
    .line 55
    invoke-static {v3, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    or-int v5, v5, p10

    .line 60
    .line 61
    :goto_0
    and-int/lit8 v0, p10, 0x30

    .line 62
    .line 63
    if-nez v0, :cond_0

    .line 64
    .line 65
    move-object/from16 v0, v60

    .line 66
    .line 67
    invoke-static {v3, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    or-int/2addr v5, v0

    .line 72
    :cond_0
    and-int/lit16 v0, v15, 0x180

    .line 73
    .line 74
    if-nez v0, :cond_1

    .line 75
    .line 76
    move-object/from16 v0, v48

    .line 77
    .line 78
    invoke-static {v3, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    or-int/2addr v5, v0

    .line 83
    :cond_1
    and-int/lit16 v0, v15, 0xc00

    .line 84
    .line 85
    if-nez v0, :cond_2

    .line 86
    .line 87
    move-object/from16 v0, v59

    .line 88
    .line 89
    invoke-static {v3, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    or-int/2addr v5, v0

    .line 94
    :cond_2
    and-int/lit16 v0, v15, 0x6000

    .line 95
    .line 96
    move/from16 v28, p4

    .line 97
    .line 98
    if-nez v0, :cond_3

    .line 99
    .line 100
    move/from16 v0, v28

    .line 101
    .line 102
    invoke-static {v3, v0}, LX/004;->A0m(LX/2d4;Z)I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    or-int/2addr v5, v0

    .line 107
    :cond_3
    const/high16 v0, 0x30000

    .line 108
    .line 109
    and-int v0, v0, p10

    .line 110
    .line 111
    if-nez v0, :cond_4

    .line 112
    .line 113
    invoke-static {v3, v1}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    or-int/2addr v5, v0

    .line 118
    :cond_4
    const/high16 v0, 0x180000

    .line 119
    .line 120
    and-int v0, v0, p10

    .line 121
    .line 122
    move/from16 v27, p6

    .line 123
    .line 124
    if-nez v0, :cond_5

    .line 125
    .line 126
    move/from16 v0, v27

    .line 127
    .line 128
    invoke-static {v3, v0}, LX/004;->A0o(LX/2d4;Z)I

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    or-int/2addr v5, v0

    .line 133
    :cond_5
    const/high16 v0, 0xc00000

    .line 134
    .line 135
    and-int v0, v0, p10

    .line 136
    .line 137
    if-nez v0, :cond_6

    .line 138
    .line 139
    move-object/from16 v0, v57

    .line 140
    .line 141
    invoke-static {v3, v0}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    or-int/2addr v5, v0

    .line 146
    :cond_6
    move/from16 v56, p11

    .line 147
    .line 148
    move/from16 v0, v56

    .line 149
    .line 150
    and-int/lit16 v2, v0, 0x100

    .line 151
    .line 152
    const/high16 v0, 0x6000000

    .line 153
    .line 154
    if-nez v2, :cond_7

    .line 155
    .line 156
    and-int v0, p10, v0

    .line 157
    .line 158
    if-nez v0, :cond_8

    .line 159
    .line 160
    move-object/from16 v0, v24

    .line 161
    .line 162
    invoke-static {v3, v0}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    :cond_7
    or-int/2addr v5, v0

    .line 167
    :cond_8
    const v0, 0x2492493

    .line 168
    .line 169
    .line 170
    and-int v1, v5, v0

    .line 171
    .line 172
    const v0, 0x2492492

    .line 173
    .line 174
    .line 175
    const/16 v25, 0x1

    .line 176
    .line 177
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    invoke-static {v0, v3, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    if-eqz v0, :cond_44

    .line 186
    .line 187
    if-eqz v2, :cond_9

    .line 188
    .line 189
    sget-object v24, LX/3C1;->A00:LX/3Cb;

    .line 190
    .line 191
    :cond_9
    invoke-static {v3}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    invoke-static {v0}, LX/602;->A02(Landroid/content/Context;)Landroid/content/Context;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    const/16 v23, 0x0

    .line 200
    .line 201
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$Factory;

    .line 202
    .line 203
    move-object/from16 v1, v23

    .line 204
    .line 205
    move/from16 v0, v26

    .line 206
    .line 207
    invoke-direct {v7, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$Factory;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 208
    .line 209
    .line 210
    invoke-static {v3}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 211
    .line 212
    .line 213
    move-result-object v4

    .line 214
    const/16 v0, 0x8

    .line 215
    .line 216
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v6

    .line 220
    if-eqz v4, :cond_47

    .line 221
    .line 222
    invoke-static {v4}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    const-class v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 227
    .line 228
    move-object/from16 v0, v23

    .line 229
    .line 230
    invoke-static {v7, v4, v2, v1, v0}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 231
    .line 232
    .line 233
    move-result-object v4

    .line 234
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 235
    .line 236
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->uiState:LX/2J3;

    .line 237
    .line 238
    move/from16 v0, v26

    .line 239
    .line 240
    invoke-static {v3, v1, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 241
    .line 242
    .line 243
    move-result-object v22

    .line 244
    move-object/from16 v0, p0

    .line 245
    .line 246
    invoke-static {v3, v0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 247
    .line 248
    .line 249
    move-result-object v8

    .line 250
    shr-int/lit8 v1, v5, 0x3

    .line 251
    .line 252
    move-object/from16 v0, v60

    .line 253
    .line 254
    invoke-static {v3, v0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 255
    .line 256
    .line 257
    move-result-object v7

    .line 258
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v9

    .line 262
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 263
    .line 264
    move/from16 v0, v26

    .line 265
    .line 266
    invoke-static {v3, v9, v2, v0}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v11

    .line 270
    check-cast v11, Landroidx/compose/runtime/MutableState;

    .line 271
    .line 272
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v9

    .line 276
    invoke-static {v3, v9, v2, v0}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v10

    .line 280
    check-cast v10, Landroidx/compose/runtime/MutableState;

    .line 281
    .line 282
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 283
    .line 284
    invoke-interface {v3, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object v13

    .line 288
    check-cast v13, Landroid/app/Activity;

    .line 289
    .line 290
    sget-object v12, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 291
    .line 292
    invoke-static {v3, v13, v4}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    move-result v0

    .line 296
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v9

    .line 300
    if-nez v0, :cond_a

    .line 301
    .line 302
    if-ne v9, v2, :cond_b

    .line 303
    .line 304
    :cond_a
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$1$1;

    .line 305
    .line 306
    invoke-direct {v9, v13, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$1$1;-><init>(Landroid/app/Activity;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 307
    .line 308
    .line 309
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    :cond_b
    move-object/from16 v0, v22

    .line 313
    .line 314
    invoke-static {v3, v0, v9, v12}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 319
    .line 320
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->linkableAccountTypes:LX/Ddn;

    .line 321
    .line 322
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 323
    .line 324
    .line 325
    move-result v0

    .line 326
    invoke-static {v0}, LX/001;->A0n(Z)Ljava/lang/Boolean;

    .line 327
    .line 328
    .line 329
    move-result-object v12

    .line 330
    move-object/from16 v0, v22

    .line 331
    .line 332
    invoke-interface {v3, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 333
    .line 334
    .line 335
    move-result v0

    .line 336
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v9

    .line 340
    if-nez v0, :cond_c

    .line 341
    .line 342
    if-ne v9, v2, :cond_d

    .line 343
    .line 344
    :cond_c
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;

    .line 345
    .line 346
    move-object/from16 v0, v22

    .line 347
    .line 348
    invoke-direct {v9, v0, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$2$1;-><init>(LX/16A;Landroidx/compose/runtime/MutableState;)V

    .line 349
    .line 350
    .line 351
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 352
    .line 353
    .line 354
    :cond_d
    move-object/from16 v0, v22

    .line 355
    .line 356
    invoke-static {v3, v0, v9, v12}, LX/3Rr;->A0Y(LX/2d4;LX/16A;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 357
    .line 358
    .line 359
    move-result-object v0

    .line 360
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 361
    .line 362
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 363
    .line 364
    if-eqz v0, :cond_e

    .line 365
    .line 366
    invoke-interface/range {v22 .. v22}, LX/16A;->getValue()Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    move-result-object v0

    .line 370
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 371
    .line 372
    iget-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 373
    .line 374
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->READY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 375
    .line 376
    const/4 v12, 0x1

    .line 377
    if-eq v9, v0, :cond_f

    .line 378
    .line 379
    :cond_e
    const/4 v12, 0x0

    .line 380
    :cond_f
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 381
    .line 382
    .line 383
    move-result-object v11

    .line 384
    invoke-interface {v3, v12}, LX/2d4;->A6A(Z)Z

    .line 385
    .line 386
    .line 387
    move-result v9

    .line 388
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    if-nez v9, :cond_10

    .line 393
    .line 394
    if-ne v0, v2, :cond_11

    .line 395
    .line 396
    :cond_10
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;

    .line 397
    .line 398
    invoke-direct {v0, v12, v10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;-><init>(ZLandroidx/compose/runtime/MutableState;)V

    .line 399
    .line 400
    .line 401
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 402
    .line 403
    .line 404
    :cond_11
    invoke-static {v3, v0, v11}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    sget-object v10, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 408
    .line 409
    invoke-static {v3, v4, v8}, LX/004;->A1U(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 410
    .line 411
    .line 412
    move-result v0

    .line 413
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    move-result-object v9

    .line 417
    if-nez v0, :cond_12

    .line 418
    .line 419
    if-ne v9, v2, :cond_13

    .line 420
    .line 421
    :cond_12
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$4$1;

    .line 422
    .line 423
    move-object/from16 v0, v23

    .line 424
    .line 425
    invoke-direct {v9, v4, v8, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$4$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/16A;LX/2M4;)V

    .line 426
    .line 427
    .line 428
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 429
    .line 430
    .line 431
    :cond_13
    invoke-static {v3, v9, v10}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 432
    .line 433
    .line 434
    invoke-static {v3, v4, v7}, LX/004;->A1U(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 439
    .line 440
    .line 441
    move-result-object v8

    .line 442
    if-nez v0, :cond_14

    .line 443
    .line 444
    if-ne v8, v2, :cond_15

    .line 445
    .line 446
    :cond_14
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1;

    .line 447
    .line 448
    move-object/from16 v0, v23

    .line 449
    .line 450
    invoke-direct {v8, v4, v7, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$5$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/16A;LX/2M4;)V

    .line 451
    .line 452
    .line 453
    invoke-interface {v3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 454
    .line 455
    .line 456
    :cond_15
    invoke-static {v3, v8, v10}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 457
    .line 458
    .line 459
    invoke-static {v3}, LX/3Rp;->A09(LX/2d4;)LX/AHE;

    .line 460
    .line 461
    .line 462
    move-result-object v0

    .line 463
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$Factory;

    .line 464
    .line 465
    invoke-direct {v9, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$Factory;-><init>(LX/AHE;)V

    .line 466
    .line 467
    .line 468
    invoke-static {v3}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 469
    .line 470
    .line 471
    move-result-object v8

    .line 472
    if-eqz v8, :cond_46

    .line 473
    .line 474
    invoke-static {v8}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 475
    .line 476
    .line 477
    move-result-object v7

    .line 478
    const-class v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 479
    .line 480
    new-instance v6, LX/Ddf;

    .line 481
    .line 482
    invoke-direct {v6, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 483
    .line 484
    .line 485
    const-string v0, "age_linking_card"

    .line 486
    .line 487
    invoke-static {v9, v8, v7, v0, v6}, LX/15E;->A01(LX/15L;LX/13Z;LX/13i;Ljava/lang/String;LX/DVF;)LX/1EJ;

    .line 488
    .line 489
    .line 490
    move-result-object v11

    .line 491
    check-cast v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 492
    .line 493
    iget-object v6, v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->state:LX/2J3;

    .line 494
    .line 495
    move/from16 v0, v26

    .line 496
    .line 497
    invoke-static {v3, v6, v0}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 498
    .line 499
    .line 500
    move-result-object v12

    .line 501
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 502
    .line 503
    .line 504
    move-result v0

    .line 505
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v7

    .line 509
    if-nez v0, :cond_16

    .line 510
    .line 511
    if-ne v7, v2, :cond_17

    .line 512
    .line 513
    :cond_16
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$6$1;

    .line 514
    .line 515
    invoke-direct {v7, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$6$1;-><init>(Ljava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 519
    .line 520
    .line 521
    :cond_17
    check-cast v7, LX/DqV;

    .line 522
    .line 523
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 524
    .line 525
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 526
    .line 527
    .line 528
    move-result v0

    .line 529
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 530
    .line 531
    .line 532
    move-result-object v6

    .line 533
    if-nez v0, :cond_18

    .line 534
    .line 535
    if-ne v6, v2, :cond_19

    .line 536
    .line 537
    :cond_18
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$7$1;

    .line 538
    .line 539
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$7$1;-><init>(Ljava/lang/Object;)V

    .line 540
    .line 541
    .line 542
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    :cond_19
    check-cast v6, LX/DqV;

    .line 546
    .line 547
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 548
    .line 549
    sget v21, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->$stable:I

    .line 550
    .line 551
    and-int/lit16 v0, v1, 0x380

    .line 552
    .line 553
    or-int v21, v21, v0

    .line 554
    .line 555
    move-object/from16 v16, v11

    .line 556
    .line 557
    move-object/from16 v17, v7

    .line 558
    .line 559
    move-object/from16 v18, v59

    .line 560
    .line 561
    move-object/from16 v19, v6

    .line 562
    .line 563
    move-object/from16 v20, v3

    .line 564
    .line 565
    invoke-static/range {v16 .. v21}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->HatchAgeLinkingLauncher(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 566
    .line 567
    .line 568
    invoke-interface/range {v22 .. v22}, LX/16A;->getValue()Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v29

    .line 572
    check-cast v29, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 573
    .line 574
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 575
    .line 576
    .line 577
    move-result v0

    .line 578
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v14

    .line 582
    if-nez v0, :cond_1a

    .line 583
    .line 584
    if-ne v14, v2, :cond_1b

    .line 585
    .line 586
    :cond_1a
    new-instance v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$8$1;

    .line 587
    .line 588
    invoke-direct {v14, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$8$1;-><init>(Ljava/lang/Object;)V

    .line 589
    .line 590
    .line 591
    invoke-interface {v3, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 592
    .line 593
    .line 594
    :cond_1b
    check-cast v14, LX/DqV;

    .line 595
    .line 596
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 597
    .line 598
    .line 599
    move-result v0

    .line 600
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    move-result-object v13

    .line 604
    if-nez v0, :cond_1c

    .line 605
    .line 606
    if-ne v13, v2, :cond_1d

    .line 607
    .line 608
    :cond_1c
    new-instance v13, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$9$1;

    .line 609
    .line 610
    invoke-direct {v13, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$9$1;-><init>(Ljava/lang/Object;)V

    .line 611
    .line 612
    .line 613
    invoke-interface {v3, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 614
    .line 615
    .line 616
    :cond_1d
    check-cast v13, LX/DqV;

    .line 617
    .line 618
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 619
    .line 620
    .line 621
    move-result v0

    .line 622
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 623
    .line 624
    .line 625
    move-result-object v10

    .line 626
    if-nez v0, :cond_1e

    .line 627
    .line 628
    if-ne v10, v2, :cond_1f

    .line 629
    .line 630
    :cond_1e
    new-instance v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$10$1;

    .line 631
    .line 632
    invoke-direct {v10, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$10$1;-><init>(Ljava/lang/Object;)V

    .line 633
    .line 634
    .line 635
    invoke-interface {v3, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 636
    .line 637
    .line 638
    :cond_1f
    check-cast v10, LX/DqV;

    .line 639
    .line 640
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 641
    .line 642
    .line 643
    move-result v0

    .line 644
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 645
    .line 646
    .line 647
    move-result-object v9

    .line 648
    if-nez v0, :cond_20

    .line 649
    .line 650
    if-ne v9, v2, :cond_21

    .line 651
    .line 652
    :cond_20
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$11$1;

    .line 653
    .line 654
    invoke-direct {v9, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$11$1;-><init>(Ljava/lang/Object;)V

    .line 655
    .line 656
    .line 657
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 658
    .line 659
    .line 660
    :cond_21
    check-cast v9, LX/DqV;

    .line 661
    .line 662
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 663
    .line 664
    .line 665
    move-result v0

    .line 666
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v8

    .line 670
    if-nez v0, :cond_22

    .line 671
    .line 672
    if-ne v8, v2, :cond_23

    .line 673
    .line 674
    :cond_22
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$12$1;

    .line 675
    .line 676
    invoke-direct {v8, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$12$1;-><init>(Ljava/lang/Object;)V

    .line 677
    .line 678
    .line 679
    invoke-interface {v3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 680
    .line 681
    .line 682
    :cond_23
    check-cast v8, LX/DqV;

    .line 683
    .line 684
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 685
    .line 686
    .line 687
    move-result v0

    .line 688
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 689
    .line 690
    .line 691
    move-result-object v7

    .line 692
    if-nez v0, :cond_24

    .line 693
    .line 694
    if-ne v7, v2, :cond_25

    .line 695
    .line 696
    :cond_24
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$13$1;

    .line 697
    .line 698
    invoke-direct {v7, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$13$1;-><init>(Ljava/lang/Object;)V

    .line 699
    .line 700
    .line 701
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 702
    .line 703
    .line 704
    :cond_25
    check-cast v7, LX/DqV;

    .line 705
    .line 706
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 707
    .line 708
    .line 709
    move-result v0

    .line 710
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 711
    .line 712
    .line 713
    move-result-object v6

    .line 714
    if-nez v0, :cond_26

    .line 715
    .line 716
    if-ne v6, v2, :cond_27

    .line 717
    .line 718
    :cond_26
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$14$1;

    .line 719
    .line 720
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$14$1;-><init>(Ljava/lang/Object;)V

    .line 721
    .line 722
    .line 723
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 724
    .line 725
    .line 726
    :cond_27
    check-cast v6, LX/DqV;

    .line 727
    .line 728
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 729
    .line 730
    .line 731
    move-result v0

    .line 732
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 733
    .line 734
    .line 735
    move-result-object v1

    .line 736
    if-nez v0, :cond_28

    .line 737
    .line 738
    if-ne v1, v2, :cond_29

    .line 739
    .line 740
    :cond_28
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$15$1;

    .line 741
    .line 742
    invoke-direct {v1, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$15$1;-><init>(Ljava/lang/Object;)V

    .line 743
    .line 744
    .line 745
    invoke-interface {v3, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 746
    .line 747
    .line 748
    :cond_29
    check-cast v1, LX/DqV;

    .line 749
    .line 750
    invoke-interface {v12}, LX/16A;->getValue()Ljava/lang/Object;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 755
    .line 756
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->isResolving:Z

    .line 757
    .line 758
    if-nez v0, :cond_2a

    .line 759
    .line 760
    const/16 v43, 0x0

    .line 761
    .line 762
    if-eqz p4, :cond_2b

    .line 763
    .line 764
    :cond_2a
    const/16 v43, 0x1

    .line 765
    .line 766
    :cond_2b
    invoke-interface {v12}, LX/16A;->getValue()Ljava/lang/Object;

    .line 767
    .line 768
    .line 769
    move-result-object v0

    .line 770
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 771
    .line 772
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 773
    .line 774
    invoke-static {v0}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 775
    .line 776
    .line 777
    move-result v44

    .line 778
    invoke-interface {v12}, LX/16A;->getValue()Ljava/lang/Object;

    .line 779
    .line 780
    .line 781
    move-result-object v0

    .line 782
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 783
    .line 784
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 785
    .line 786
    move-object/from16 v30, v0

    .line 787
    .line 788
    invoke-interface {v3, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 789
    .line 790
    .line 791
    move-result v12

    .line 792
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 793
    .line 794
    .line 795
    move-result-object v0

    .line 796
    if-nez v12, :cond_2c

    .line 797
    .line 798
    if-ne v0, v2, :cond_2d

    .line 799
    .line 800
    :cond_2c
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$16$1;

    .line 801
    .line 802
    invoke-direct {v0, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$16$1;-><init>(Ljava/lang/Object;)V

    .line 803
    .line 804
    .line 805
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 806
    .line 807
    .line 808
    :cond_2d
    check-cast v0, LX/DqV;

    .line 809
    .line 810
    check-cast v14, LX/JDM;

    .line 811
    .line 812
    check-cast v13, LX/JDM;

    .line 813
    .line 814
    check-cast v10, LX/JDM;

    .line 815
    .line 816
    check-cast v9, LX/JDM;

    .line 817
    .line 818
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 819
    .line 820
    .line 821
    move-result v12

    .line 822
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v21

    .line 826
    if-nez v12, :cond_2e

    .line 827
    .line 828
    move-object/from16 v12, v21

    .line 829
    .line 830
    if-ne v12, v2, :cond_2f

    .line 831
    .line 832
    :cond_2e
    new-instance v21, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$17$1;

    .line 833
    .line 834
    move-object/from16 v12, v21

    .line 835
    .line 836
    invoke-direct {v12, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$17$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 837
    .line 838
    .line 839
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 840
    .line 841
    .line 842
    :cond_2f
    check-cast v21, LX/JDM;

    .line 843
    .line 844
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 845
    .line 846
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 847
    .line 848
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 849
    .line 850
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 851
    .line 852
    invoke-static {v3, v11, v4}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 853
    .line 854
    .line 855
    move-result v12

    .line 856
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 857
    .line 858
    .line 859
    move-result-object v20

    .line 860
    if-nez v12, :cond_30

    .line 861
    .line 862
    move-object/from16 v12, v20

    .line 863
    .line 864
    if-ne v12, v2, :cond_31

    .line 865
    .line 866
    :cond_30
    new-instance v20, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$18$1;

    .line 867
    .line 868
    move-object/from16 v12, v20

    .line 869
    .line 870
    invoke-direct {v12, v11, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$18$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 871
    .line 872
    .line 873
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 874
    .line 875
    .line 876
    :cond_31
    check-cast v20, Lkotlin/jvm/functions/Function0;

    .line 877
    .line 878
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 879
    .line 880
    .line 881
    move-result v12

    .line 882
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 883
    .line 884
    .line 885
    move-result-object v19

    .line 886
    if-nez v12, :cond_32

    .line 887
    .line 888
    move-object/from16 v12, v19

    .line 889
    .line 890
    if-ne v12, v2, :cond_33

    .line 891
    .line 892
    :cond_32
    new-instance v19, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$19$1;

    .line 893
    .line 894
    move-object/from16 v12, v19

    .line 895
    .line 896
    invoke-direct {v12, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$19$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 897
    .line 898
    .line 899
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 900
    .line 901
    .line 902
    :cond_33
    check-cast v19, Lkotlin/jvm/functions/Function0;

    .line 903
    .line 904
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 905
    .line 906
    .line 907
    move-result v12

    .line 908
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 909
    .line 910
    .line 911
    move-result-object v18

    .line 912
    if-nez v12, :cond_34

    .line 913
    .line 914
    move-object/from16 v12, v18

    .line 915
    .line 916
    if-ne v12, v2, :cond_35

    .line 917
    .line 918
    :cond_34
    new-instance v18, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$20$1;

    .line 919
    .line 920
    move-object/from16 v12, v18

    .line 921
    .line 922
    invoke-direct {v12, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$20$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 923
    .line 924
    .line 925
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 926
    .line 927
    .line 928
    :cond_35
    check-cast v18, Lkotlin/jvm/functions/Function0;

    .line 929
    .line 930
    invoke-interface {v3, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 931
    .line 932
    .line 933
    move-result v12

    .line 934
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 935
    .line 936
    .line 937
    move-result-object v17

    .line 938
    if-nez v12, :cond_36

    .line 939
    .line 940
    move-object/from16 v12, v17

    .line 941
    .line 942
    if-ne v12, v2, :cond_37

    .line 943
    .line 944
    :cond_36
    new-instance v17, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$21$1;

    .line 945
    .line 946
    move-object/from16 v12, v17

    .line 947
    .line 948
    invoke-direct {v12, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$21$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;)V

    .line 949
    .line 950
    .line 951
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 952
    .line 953
    .line 954
    :cond_37
    check-cast v17, LX/JDM;

    .line 955
    .line 956
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 957
    .line 958
    invoke-static {v5}, LX/603;->A1Q(I)Z

    .line 959
    .line 960
    .line 961
    move-result v11

    .line 962
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 963
    .line 964
    .line 965
    move-result-object v12

    .line 966
    if-nez v11, :cond_38

    .line 967
    .line 968
    if-ne v12, v2, :cond_39

    .line 969
    .line 970
    :cond_38
    new-instance v12, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$22$1;

    .line 971
    .line 972
    move-object/from16 v11, v58

    .line 973
    .line 974
    invoke-direct {v12, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$22$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 975
    .line 976
    .line 977
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 978
    .line 979
    .line 980
    :cond_39
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 981
    .line 982
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 983
    .line 984
    .line 985
    move-result v16

    .line 986
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 987
    .line 988
    .line 989
    move-result-object v11

    .line 990
    if-nez v16, :cond_3a

    .line 991
    .line 992
    if-ne v11, v2, :cond_3b

    .line 993
    .line 994
    :cond_3a
    new-instance v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$23$1;

    .line 995
    .line 996
    invoke-direct {v11, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$23$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 997
    .line 998
    .line 999
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1000
    .line 1001
    .line 1002
    :cond_3b
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 1003
    .line 1004
    sget v52, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->$stable:I

    .line 1005
    .line 1006
    shl-int/lit8 v53, v5, 0x15

    .line 1007
    .line 1008
    const/high16 v16, 0x70000000

    .line 1009
    .line 1010
    and-int v53, v53, v16

    .line 1011
    .line 1012
    shr-int/lit8 v16, v5, 0x15

    .line 1013
    .line 1014
    and-int/lit8 v54, v16, 0x70

    .line 1015
    .line 1016
    move-object/from16 v31, v13

    .line 1017
    .line 1018
    move-object/from16 v32, v10

    .line 1019
    .line 1020
    move-object/from16 v33, v9

    .line 1021
    .line 1022
    move-object/from16 v34, v21

    .line 1023
    .line 1024
    move-object/from16 v35, v8

    .line 1025
    .line 1026
    move-object/from16 v36, v7

    .line 1027
    .line 1028
    move-object/from16 v37, v6

    .line 1029
    .line 1030
    move-object/from16 v38, v1

    .line 1031
    .line 1032
    move-object/from16 v39, v20

    .line 1033
    .line 1034
    move-object/from16 v40, v19

    .line 1035
    .line 1036
    move-object/from16 v41, v18

    .line 1037
    .line 1038
    move-object/from16 v42, v17

    .line 1039
    .line 1040
    move-object/from16 v45, v30

    .line 1041
    .line 1042
    move-object/from16 v46, v0

    .line 1043
    .line 1044
    move-object/from16 v47, v12

    .line 1045
    .line 1046
    move-object/from16 v49, v11

    .line 1047
    .line 1048
    move-object/from16 v50, v24

    .line 1049
    .line 1050
    move-object/from16 v51, v3

    .line 1051
    .line 1052
    move/from16 v55, v26

    .line 1053
    .line 1054
    move-object/from16 v30, v14

    .line 1055
    .line 1056
    invoke-static/range {v29 .. v55}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->HatchCcvCardEntryScreen(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;IIII)V

    .line 1057
    .line 1058
    .line 1059
    invoke-interface/range {v22 .. v22}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1060
    .line 1061
    .line 1062
    move-result-object v0

    .line 1063
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 1064
    .line 1065
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->threeDSChallenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 1066
    .line 1067
    if-nez v6, :cond_41

    .line 1068
    .line 1069
    const v0, -0x788db3b9

    .line 1070
    .line 1071
    .line 1072
    invoke-static {v3, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 1073
    .line 1074
    .line 1075
    move-result-object v6

    .line 1076
    :goto_1
    if-eqz p6, :cond_40

    .line 1077
    .line 1078
    const v0, -0x788af6d4

    .line 1079
    .line 1080
    .line 1081
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 1082
    .line 1083
    .line 1084
    const/high16 v0, 0x1c00000

    .line 1085
    .line 1086
    and-int/2addr v5, v0

    .line 1087
    const/high16 v0, 0x800000

    .line 1088
    .line 1089
    if-eq v5, v0, :cond_3c

    .line 1090
    .line 1091
    const/16 v25, 0x0

    .line 1092
    .line 1093
    :cond_3c
    move/from16 v0, v25

    .line 1094
    .line 1095
    invoke-static {v3, v4, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 1096
    .line 1097
    .line 1098
    move-result v0

    .line 1099
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v1

    .line 1103
    if-nez v0, :cond_3d

    .line 1104
    .line 1105
    if-ne v1, v2, :cond_3e

    .line 1106
    .line 1107
    :cond_3d
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$25$1;

    .line 1108
    .line 1109
    move-object/from16 v0, v57

    .line 1110
    .line 1111
    invoke-direct {v1, v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$25$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V

    .line 1112
    .line 1113
    .line 1114
    invoke-interface {v3, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1115
    .line 1116
    .line 1117
    :cond_3e
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 1118
    .line 1119
    and-int/lit8 v4, v16, 0xe

    .line 1120
    .line 1121
    const/4 v5, 0x4

    .line 1122
    move-object/from16 v0, v57

    .line 1123
    .line 1124
    move-object/from16 v2, v23

    .line 1125
    .line 1126
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/ccv/HatchCcvLogOutConfirmationDialogKt;->HatchCcvLogOutConfirmationDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1127
    .line 1128
    .line 1129
    :goto_2
    move/from16 v0, v26

    .line 1130
    .line 1131
    invoke-static {v6, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1132
    .line 1133
    .line 1134
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v0

    .line 1138
    if-eqz v0, :cond_3f

    .line 1139
    .line 1140
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$26;

    .line 1141
    .line 1142
    move-object/from16 v2, p0

    .line 1143
    .line 1144
    move-object/from16 v3, v60

    .line 1145
    .line 1146
    move-object/from16 v4, v48

    .line 1147
    .line 1148
    move-object/from16 v5, v59

    .line 1149
    .line 1150
    move/from16 v6, v28

    .line 1151
    .line 1152
    move-object/from16 v7, v58

    .line 1153
    .line 1154
    move/from16 v8, v27

    .line 1155
    .line 1156
    move-object/from16 v9, v57

    .line 1157
    .line 1158
    move-object/from16 v10, v24

    .line 1159
    .line 1160
    move v11, v15

    .line 1161
    move/from16 v12, v56

    .line 1162
    .line 1163
    invoke-direct/range {v1 .. v12}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$26;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 1164
    .line 1165
    .line 1166
    iput-object v1, v0, LX/J7V;->A06:LX/JDN;

    .line 1167
    .line 1168
    :cond_3f
    return-void

    .line 1169
    :cond_40
    const v0, -0x7887f186

    .line 1170
    .line 1171
    .line 1172
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 1173
    .line 1174
    .line 1175
    goto :goto_2

    .line 1176
    :cond_41
    const v0, -0x788db3b8

    .line 1177
    .line 1178
    .line 1179
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 1180
    .line 1181
    .line 1182
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 1183
    .line 1184
    .line 1185
    move-result v0

    .line 1186
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v7

    .line 1190
    if-nez v0, :cond_42

    .line 1191
    .line 1192
    if-ne v7, v2, :cond_43

    .line 1193
    .line 1194
    :cond_42
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$24$1$1;

    .line 1195
    .line 1196
    invoke-direct {v7, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$24$1$1;-><init>(Ljava/lang/Object;)V

    .line 1197
    .line 1198
    .line 1199
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1200
    .line 1201
    .line 1202
    :cond_43
    check-cast v7, LX/DqV;

    .line 1203
    .line 1204
    check-cast v7, LX/JDM;

    .line 1205
    .line 1206
    const/4 v11, 0x4

    .line 1207
    move-object/from16 v8, v23

    .line 1208
    .line 1209
    move-object v9, v3

    .line 1210
    move/from16 v10, v26

    .line 1211
    .line 1212
    invoke-static/range {v6 .. v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt;->HatchCcvThreeDSChallengeDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1213
    .line 1214
    .line 1215
    move-object v6, v3

    .line 1216
    check-cast v6, LX/J7I;

    .line 1217
    .line 1218
    invoke-static {v6, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1219
    .line 1220
    .line 1221
    goto/16 :goto_1

    .line 1222
    .line 1223
    :cond_44
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 1224
    .line 1225
    .line 1226
    goto :goto_3

    .line 1227
    :cond_45
    move v5, v15

    .line 1228
    goto/16 :goto_0

    .line 1229
    .line 1230
    :cond_46
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1231
    .line 1232
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1233
    .line 1234
    .line 1235
    throw v0

    .line 1236
    :cond_47
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1237
    .line 1238
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1239
    .line 1240
    .line 1241
    throw v0
.end method

.method public static final HatchCcvCardEntryHost$lambda$0(LX/16A;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$14(LX/16A;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final HatchCcvCardEntryHost$lambda$7(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final HatchCcvCardEntryHost$lambda$8(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$11(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$12(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$2(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/JDN;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$3(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$7(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchAgeLinkingLauncher$lambda$8(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$0(LX/16A;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$7(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$HatchCcvCardEntryHost$lambda$8(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logCcvClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logCcvDismiss(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvDismiss(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$openLinker(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->openLinker(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final linkingTarget(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p0, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->FACEBOOK:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 14
    .line 15
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 16
    .line 17
    .line 18
    throw v0

    .line 19
    :cond_1
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->INSTAGRAM:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 20
    .line 21
    return-object v0
.end method

.method public static final logCcvClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 7

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CCV_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v4, p0

    .line 8
    move-object v5, v2

    .line 9
    move-object v6, v2

    .line 10
    move-object p0, v2

    .line 11
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public static final logCcvDismiss(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 6

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CCV_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v4, p0

    .line 8
    move-object v5, v2

    .line 9
    move-object p0, v2

    .line 10
    invoke-virtual/range {v0 .. v6}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logDismiss(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static final logCcvImpression(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->HATCH:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->CCV_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    move-object v5, p0

    .line 10
    move-object p0, p1

    .line 11
    move-object v6, v3

    .line 12
    move-object p1, v3

    .line 13
    invoke-virtual/range {v0 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->logImpression(Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static synthetic logCcvImpression$default(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    :cond_0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvImpression(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static final logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGE_CONFIRMATION_OUTCOME:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;->getResult()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvImpression(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 17
    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 20
    .line 21
    invoke-virtual {v0, p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logFormOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public static synthetic logCcvOutcome$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvFormOutcome;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static final openLinker(Landroid/content/Context;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 1
    .line 2
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->linkingTarget(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-virtual {p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeLinkRequest(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$1;

    .line 11
    .line 12
    invoke-direct {v3, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;)V

    .line 13
    .line 14
    .line 15
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$2;

    .line 16
    .line 17
    invoke-direct {v4, p1, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lkotlin/jvm/functions/Function0;)V

    .line 18
    .line 19
    .line 20
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$3;

    .line 21
    .line 22
    invoke-direct {v5, p1, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$openLinker$3;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lkotlin/jvm/functions/Function0;)V

    .line 23
    .line 24
    .line 25
    move-object v0, p0

    .line 26
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->openAgeVerificationLinking(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
