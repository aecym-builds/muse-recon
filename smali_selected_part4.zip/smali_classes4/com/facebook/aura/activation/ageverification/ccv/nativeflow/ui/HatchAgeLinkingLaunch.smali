.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

.field public final attemptId:Ljava/lang/String;

.field public final url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->copy(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    :cond_0
    return v2

    .line 37
    :cond_1
    return v3
.end method

.method public final getAccount()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAttemptId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    add-int/2addr v1, v0

    .line 19
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
