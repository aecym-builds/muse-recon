.class public final synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x7

    .line 8
    const-string v0, "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchAddressFormFieldJson"

    .line 9
    .line 10
    new-instance v2, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "field_id"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "field_type"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "label"

    .line 27
    .line 28
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    const-string v0, "placeholder"

    .line 32
    .line 33
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 34
    .line 35
    .line 36
    const-string v0, "is_optional"

    .line 37
    .line 38
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 39
    .line 40
    .line 41
    const-string v0, "value_type"

    .line 42
    .line 43
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 44
    .line 45
    .line 46
    const-string v0, "validation_rules"

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 49
    .line 50
    .line 51
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->descriptor:LX/Da5;

    .line 52
    .line 53
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    sget-object v0, LX/DYp;->A01:LX/DYp;

    .line 3
    .line 4
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    sget-object v6, LX/DYz;->A00:LX/DYz;

    .line 21
    .line 22
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    const/4 v0, 0x6

    .line 27
    invoke-static {v1, v0}, LX/3Rp;->A1A([Lkotlin/Lazy;I)LX/DZ7;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    filled-new-array/range {v2 .. v8}, [LX/DZ7;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;
    .locals 16

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v5}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->$childSerializers:[Lkotlin/Lazy;

    .line 13
    .line 14
    const/4 v7, 0x5

    .line 15
    const/4 v3, 0x3

    .line 16
    const/4 v2, 0x4

    .line 17
    const/4 v1, 0x6

    .line 18
    const/16 p1, 0x0

    .line 19
    .line 20
    move-object/from16 p0, p1

    .line 21
    .line 22
    move-object/from16 v15, p1

    .line 23
    .line 24
    move-object v10, v15

    .line 25
    move-object v11, v15

    .line 26
    move-object v12, v15

    .line 27
    move-object v13, v15

    .line 28
    const/4 v14, 0x0

    .line 29
    const/4 v9, 0x0

    .line 30
    :goto_0
    invoke-interface {v4, v5}, LX/Da7;->A8S(LX/Da5;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 38
    .line 39
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 40
    .line 41
    .line 42
    throw v1

    .line 43
    :pswitch_0
    invoke-static {v5, v4, v8, v1}, LX/3Rs;->A0j(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    or-int/lit8 v9, v9, 0x40

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :pswitch_1
    invoke-static {v5, v4, v7}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v15

    .line 54
    or-int/lit8 v9, v9, 0x20

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :pswitch_2
    invoke-interface {v4, v5, v2}, LX/Da7;->A8L(LX/Da5;I)Z

    .line 58
    .line 59
    .line 60
    move-result v14

    .line 61
    or-int/lit8 v9, v9, 0x10

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :pswitch_3
    invoke-static {v5, v4, v3}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v13

    .line 68
    or-int/lit8 v9, v9, 0x8

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :pswitch_4
    invoke-static {v5, v4}, LX/3Rs;->A0U(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v12

    .line 75
    or-int/lit8 v9, v9, 0x4

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :pswitch_5
    invoke-static {v5, v4}, LX/3Rs;->A0T(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v11

    .line 82
    or-int/lit8 v9, v9, 0x2

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :pswitch_6
    invoke-static {v5, v4, v6}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v10

    .line 89
    or-int/lit8 v9, v9, 0x1

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :pswitch_7
    invoke-interface {v4, v5}, LX/Da7;->AAi(LX/Da5;)V

    .line 93
    .line 94
    .line 95
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 96
    .line 97
    invoke-direct/range {v8 .. v17}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;LX/5Xm;)V

    .line 98
    .line 99
    .line 100
    return-object v8

    .line 101
    nop

    .line 102
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;)V
    .locals 1

    .line 268435456
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->descriptor:LX/Da5;

    .line 268435460
    .line 268435461
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 268435462
    .line 268435463
    .line 268435464
    move-result-object v0

    .line 268435465
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;LX/Da8;LX/Da5;)V

    .line 268435466
    .line 268435467
    .line 268435468
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 268435469
    .line 268435470
    .line 268435471
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
