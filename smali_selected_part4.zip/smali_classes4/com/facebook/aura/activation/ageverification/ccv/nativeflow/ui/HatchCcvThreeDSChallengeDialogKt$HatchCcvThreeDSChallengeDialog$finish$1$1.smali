.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentOnFinished$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;->$currentOnFinished$delegate:LX/16A;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;->invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$finish$1$1;->$currentOnFinished$delegate:LX/16A;

    .line 5
    .line 6
    invoke-static {v0, p1}, LX/16A;->A0B(LX/16A;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
