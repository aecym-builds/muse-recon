.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

.field public final synthetic $result:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->$result:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 8

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->$result:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;

    .line 7
    .line 8
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;

    .line 9
    .line 10
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;->url:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;->attemptId:Ljava/lang/String;

    .line 13
    .line 14
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 15
    .line 16
    invoke-direct {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Ljava/lang/String;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->$result:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;

    .line 20
    .line 21
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;

    .line 22
    .line 23
    iget-object p0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;->attemptId:Ljava/lang/String;

    .line 24
    .line 25
    iget-boolean v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->isResolving:Z

    .line 26
    .line 27
    iget-object v2, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 28
    .line 29
    iget v4, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 30
    .line 31
    iget v5, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 32
    .line 33
    iget-object v6, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 34
    .line 35
    iget v7, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 38
    .line 39
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1$1;->invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
