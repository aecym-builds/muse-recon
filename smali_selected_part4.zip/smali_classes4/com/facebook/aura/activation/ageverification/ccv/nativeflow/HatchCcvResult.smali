.class public interface abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;
.super Ljava/lang/Object;
.source ""
