.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion;


# instance fields
.field public final country_to_fields:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;",
            ">;"
        }
    .end annotation
.end field

.field public final default_country:Ljava/lang/String;

.field public final should_only_allow_default_country:Z

.field public final supported_countries:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion;

    .line 7
    .line 8
    sget-object v2, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v2, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion$$childSerializers$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson$Companion$$childSerializers$2;

    .line 17
    .line 18
    invoke-static {v2, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    filled-new-array {v3, v3, v1, v0}, [Lkotlin/Lazy;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->$childSerializers:[Lkotlin/Lazy;

    .line 27
    .line 28
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 805306368
    const/4 v2, 0x0

    .line 805306369
    const/4 v1, 0x0

    .line 805306370
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306371
    .line 805306372
    invoke-direct {p0, v2, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V

    .line 805306373
    .line 805306374
    .line 805306375
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;ZLjava/util/List;Ljava/util/List;LX/5Xm;)V
    .locals 1

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    if-nez v0, :cond_0

    .line 268435462
    .line 268435463
    const/4 p2, 0x0

    .line 268435464
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 268435465
    .line 268435466
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    if-nez v0, :cond_2

    .line 268435469
    .line 268435470
    const/4 v0, 0x0

    .line 268435471
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 268435472
    .line 268435473
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 268435474
    .line 268435475
    if-nez v0, :cond_1

    .line 268435476
    .line 268435477
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 268435478
    .line 268435479
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 268435480
    .line 268435481
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 268435482
    .line 268435483
    if-nez v0, :cond_3

    .line 268435484
    .line 268435485
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 268435486
    .line 268435487
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 268435488
    .line 268435489
    return-void

    .line 268435490
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 268435491
    .line 268435492
    goto :goto_1

    .line 268435493
    :cond_2
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 268435494
    .line 268435495
    goto :goto_0

    .line 268435496
    :cond_3
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 268435497
    .line 268435498
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;",
            ">;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p3, v0, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;ILX/04f;)V
    .locals 3

    .line 536870912
    invoke-static {p5, p1}, LX/3Rp;->A0w(ILjava/lang/String;)Ljava/lang/String;

    .line 536870913
    .line 536870914
    .line 536870915
    move-result-object v2

    .line 536870916
    invoke-static {p5, p2}, LX/3Rr;->A1O(IZ)Z

    .line 536870917
    .line 536870918
    .line 536870919
    move-result v1

    .line 536870920
    and-int/lit8 v0, p5, 0x4

    .line 536870921
    .line 536870922
    if-eqz v0, :cond_0

    .line 536870923
    .line 536870924
    sget-object p3, LX/0wV;->A00:LX/0wV;

    .line 536870925
    .line 536870926
    :cond_0
    and-int/lit8 v0, p5, 0x8

    .line 536870927
    .line 536870928
    if-eqz v0, :cond_1

    .line 536870929
    .line 536870930
    sget-object p4, LX/0wV;->A00:LX/0wV;

    .line 536870931
    .line 536870932
    :cond_1
    invoke-direct {p0, v2, v1, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V

    .line 536870933
    .line 536870934
    .line 536870935
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;Ljava/lang/String;ZLjava/util/List;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    const/4 v0, 0x2

    .line 25
    invoke-static {p3, v0, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 29
    .line 30
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V

    .line 31
    .line 32
    .line 33
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    if-nez v4, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v1, 0x1

    .line 21
    if-nez v4, :cond_2

    .line 22
    .line 23
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 24
    .line 25
    if-eqz v0, :cond_3

    .line 26
    .line 27
    :cond_2
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 28
    .line 29
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v4, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 36
    .line 37
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_5

    .line 42
    .line 43
    :cond_4
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 48
    .line 49
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 50
    .line 51
    .line 52
    :cond_5
    const/4 v2, 0x3

    .line 53
    if-nez v4, :cond_6

    .line 54
    .line 55
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 56
    .line 57
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-nez v0, :cond_7

    .line 62
    .line 63
    :cond_6
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 70
    .line 71
    .line 72
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component3()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;",
            ">;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x2

    .line 1
    invoke-static {p3, p0, p4}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 21
    .line 22
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 23
    .line 24
    if-ne v1, v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    :cond_0
    return v2

    .line 47
    :cond_1
    return v3
.end method

.method public final getCountry_to_fields()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDefault_country()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShould_only_allow_default_country()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getSupported_countries()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 9
    .line 10
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
