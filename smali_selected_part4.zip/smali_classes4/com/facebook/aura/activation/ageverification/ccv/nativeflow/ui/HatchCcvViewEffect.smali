.class public interface abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;
.super Ljava/lang/Object;
.source ""
