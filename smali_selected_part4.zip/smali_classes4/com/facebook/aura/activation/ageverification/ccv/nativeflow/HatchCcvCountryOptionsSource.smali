.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;

.field public static final PAYMENT_ADDRESS_FORM_DEFAULT_COUNTRY:Ljava/lang/String; = "default"

.field public static final PAYMENT_ADDRESS_FORM_ZIP_FIELD_ID:Ljava/lang/String; = "zip"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final postalField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;
    .locals 7

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;->form_fields:Ljava/util/List;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object v4

    .line 6
    :cond_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v3, 0x0

    .line 11
    if-eqz v0, :cond_6

    .line 12
    .line 13
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    move-object v0, v2

    .line 18
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 19
    .line 20
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 21
    .line 22
    const-string v0, "zip"

    .line 23
    .line 24
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    :goto_0
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 31
    .line 32
    if-eqz v2, :cond_5

    .line 33
    .line 34
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 35
    .line 36
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->toPostalRules(Ljava/util/List;)Ljava/util/List;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;

    .line 45
    .line 46
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 53
    .line 54
    if-eqz v6, :cond_1

    .line 55
    .line 56
    invoke-static {v6}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_2

    .line 61
    .line 62
    :cond_1
    move-object v6, v3

    .line 63
    :cond_2
    iget-object p0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz p0, :cond_3

    .line 66
    .line 67
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_4

    .line 72
    .line 73
    :cond_3
    move-object p0, v3

    .line 74
    :cond_4
    iget-boolean p1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 75
    .line 76
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 77
    .line 78
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;-><init>(LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 79
    .line 80
    .line 81
    :cond_5
    return-object v3

    .line 82
    :cond_6
    move-object v2, v3

    .line 83
    goto :goto_0
.end method


# virtual methods
.method public final countryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
    .locals 7

    .line 0
    const/4 v4, 0x0

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    return-object v4

    .line 4
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->country_to_fields:Ljava/util/List;

    .line 5
    .line 6
    new-instance v5, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    :cond_1
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;

    .line 26
    .line 27
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;->country_code:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_1

    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;

    .line 38
    .line 39
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;->postalField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryFormFieldsJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v1, v0, v5}, LX/002;->A1K(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_2
    invoke-static {v5}, LX/1HA;->A09(Ljava/lang/Iterable;)Ljava/util/Map;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->supported_countries:Ljava/util/List;

    .line 52
    .line 53
    new-instance p0, Ljava/util/ArrayList;

    .line 54
    .line 55
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 56
    .line 57
    .line 58
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    :cond_3
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_5

    .line 67
    .line 68
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;

    .line 73
    .line 74
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;->value:Ljava/lang/String;

    .line 75
    .line 76
    if-eqz v3, :cond_3

    .line 77
    .line 78
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-nez v0, :cond_3

    .line 83
    .line 84
    const-string v0, "default"

    .line 85
    .line 86
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-nez v0, :cond_3

    .line 91
    .line 92
    invoke-interface {v5, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 97
    .line 98
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCountryOptionJson;->label:Ljava/lang/String;

    .line 99
    .line 100
    if-eqz v1, :cond_4

    .line 101
    .line 102
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-nez v0, :cond_4

    .line 107
    .line 108
    :goto_2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 109
    .line 110
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_4
    move-object v1, v4

    .line 118
    goto :goto_2

    .line 119
    :cond_5
    invoke-static {p0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    iget-object v3, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->default_country:Ljava/lang/String;

    .line 124
    .line 125
    if-eqz v3, :cond_b

    .line 126
    .line 127
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    if-nez v0, :cond_b

    .line 132
    .line 133
    :goto_3
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-eqz v0, :cond_a

    .line 138
    .line 139
    if-eqz v3, :cond_6

    .line 140
    .line 141
    invoke-interface {v5, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 146
    .line 147
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 148
    .line 149
    invoke-direct {v0, v3, v1, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    filled-new-array {v0}, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    invoke-static {v0}, LX/Dwp;->A05([Ljava/lang/Object;)LX/Dwf;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    :goto_4
    instance-of v0, v2, Ljava/util/Collection;

    .line 161
    .line 162
    if-eqz v0, :cond_8

    .line 163
    .line 164
    move-object v0, v2

    .line 165
    check-cast v0, Ljava/util/Collection;

    .line 166
    .line 167
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    if-eqz v0, :cond_8

    .line 172
    .line 173
    :cond_6
    invoke-static {v2}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 178
    .line 179
    if-eqz v0, :cond_7

    .line 180
    .line 181
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 182
    .line 183
    :goto_5
    iget-boolean v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;->should_only_allow_default_country:Z

    .line 184
    .line 185
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 186
    .line 187
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;-><init>(Ljava/lang/String;LX/Ddn;Z)V

    .line 188
    .line 189
    .line 190
    return-object v0

    .line 191
    :cond_7
    const-string v3, "US"

    .line 192
    .line 193
    goto :goto_5

    .line 194
    :cond_8
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    :cond_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 199
    .line 200
    .line 201
    move-result v0

    .line 202
    if-eqz v0, :cond_6

    .line 203
    .line 204
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 209
    .line 210
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 211
    .line 212
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    if-eqz v0, :cond_9

    .line 217
    .line 218
    goto :goto_5

    .line 219
    :cond_a
    if-eqz v3, :cond_6

    .line 220
    .line 221
    goto :goto_4

    .line 222
    :cond_b
    move-object v3, v4

    .line 223
    goto :goto_3
.end method
