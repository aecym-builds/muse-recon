.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.ui.HatchCcvViewModel$finishThreeDSChallenge$2"
    f = "HatchCcvViewModel.kt"
    l = {
        0x27f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $challenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

.field public final synthetic $charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$challenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$challenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->L$0:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$challenge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 19
    .line 20
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v2, p1, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->access$onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 28
    .line 29
    return-object v0

    .line 30
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 34
    .line 35
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutClient:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 38
    .line 39
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->L$0:Ljava/lang/Object;

    .line 40
    .line 41
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;->label:I

    .line 42
    .line 43
    invoke-virtual {v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->finalizeAfterChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    if-ne p1, v4, :cond_0

    .line 48
    .line 49
    return-object v4

    .line 50
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    throw v0
.end method
