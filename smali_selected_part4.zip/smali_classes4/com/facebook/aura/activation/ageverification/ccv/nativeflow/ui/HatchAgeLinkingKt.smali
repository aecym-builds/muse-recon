.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p0, v2}, LX/002;->A0K(Ljava/lang/Enum;I)I

    .line 2
    .line 3
    .line 4
    move-result v1

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eq v1, v0, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->INSTAGRAM:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 14
    .line 15
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 16
    .line 17
    .line 18
    throw v0

    .line 19
    :cond_1
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->FACEBOOK:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 20
    .line 21
    return-object v0
.end method
