.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

.field public final result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 10
    .line 11
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x1

    .line 13
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;-><init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/user/provider/AgeCheckMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;-><init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 19
    .line 20
    if-eq v1, v0, :cond_1

    .line 21
    .line 22
    :cond_0
    return v2

    .line 23
    :cond_1
    return v3
.end method

.method public final getMethod()Lcom/facebook/aura/user/provider/AgeCheckMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getResult()Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;->result:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
