.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $activationVersion:I

.field public final synthetic $consumedActivationVersion$delegate:LX/CR1;

.field public final synthetic $currentOnLinkingReturned$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILX/CR1;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/CR1;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$activationVersion:I

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$consumedActivationVersion$delegate:LX/CR1;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$currentOnLinkingReturned$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$activationVersion:I

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$consumedActivationVersion$delegate:LX/CR1;

    .line 3
    .line 4
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eq v1, v0, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$consumedActivationVersion$delegate:LX/CR1;

    .line 11
    .line 12
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$activationVersion:I

    .line 13
    .line 14
    invoke-interface {v1, v0}, LX/CR1;->Ae1(I)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->$currentOnLinkingReturned$delegate:LX/16A;

    .line 18
    .line 19
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    check-cast p0, LX/JDN;

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;->COMPLETED:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 27
    .line 28
    invoke-interface {p0, v1, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1$invoke$$inlined$onDispose$1;

    .line 32
    .line 33
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 34
    .line 35
    .line 36
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchAgeLinkingLauncher$4$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
