.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $finish:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;->$finish:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvThreeDSChallengeDialogKt$HatchCcvThreeDSChallengeDialog$1$1;->$finish:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;->DISMISSED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/OneShot;->invoke(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
