.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 10

    .line 0
    const/4 v2, 0x0

    .line 1
    move-object v1, p1

    .line 2
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 6
    .line 7
    add-int/lit8 v5, v0, 0x1

    .line 8
    .line 9
    const/16 p0, 0xf7

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    move-object v4, v3

    .line 13
    move v6, v2

    .line 14
    move-object v7, v3

    .line 15
    move v8, v2

    .line 16
    move-object v9, v3

    .line 17
    move-object p1, v3

    .line 18
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;->invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
