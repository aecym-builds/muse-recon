.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/2D4;


# instance fields
.field public final synthetic $accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

.field public final synthetic $onLinkAccountClick:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDM;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;->$onLinkAccountClick:LX/JDM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final onClick(LX/2D7;)V
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;->$onLinkAccountClick:LX/JDM;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 3
    .line 4
    invoke-interface {p1, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
