.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.ui.HatchCcvViewModel$startCheckout$1"
    f = "HatchCcvViewModel.kt"
    l = {
        0x8c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 268435457
    .line 268435458
    new-instance p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;

    .line 268435459
    .line 268435460
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435466
    .line 268435467
    .line 268435468
    move-result-object p0

    .line 268435469
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 39

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v4, p0

    .line 5
    .line 6
    iget v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->label:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-eqz v0, :cond_3

    .line 10
    .line 11
    if-ne v0, v1, :cond_e

    .line 12
    .line 13
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult;

    .line 17
    .line 18
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Opened;

    .line 19
    .line 20
    const-string v2, "HatchCcvViewModel"

    .line 21
    .line 22
    const/4 v8, 0x0

    .line 23
    if-eqz v0, :cond_a

    .line 24
    .line 25
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Opened;

    .line 26
    .line 27
    iget-object v3, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Opened;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 28
    .line 29
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 30
    .line 31
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 32
    .line 33
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->access$applySupportedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Ljava/util/List;)V

    .line 34
    .line 35
    .line 36
    iget-object v5, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 37
    .line 38
    iget-object v1, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {v5, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->access$applyScreenContent(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    iget-object v5, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 46
    .line 47
    if-nez v5, :cond_4

    .line 48
    .line 49
    const-string v0, "checkout/init opened without a usable country configuration"

    .line 50
    .line 51
    invoke-static {v2, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 55
    .line 56
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 57
    .line 58
    if-eqz v0, :cond_1

    .line 59
    .line 60
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 61
    .line 62
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 63
    .line 64
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logFormConfigMissing(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    :cond_1
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 68
    .line 69
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 70
    .line 71
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;->SERVER_ERROR:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 72
    .line 73
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;

    .line 74
    .line 75
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 76
    .line 77
    .line 78
    invoke-interface {v2, v0}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 82
    .line 83
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_checkoutUnavailable:LX/EYl;

    .line 84
    .line 85
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 86
    .line 87
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 91
    .line 92
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 93
    .line 94
    :cond_2
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    move-object v7, v1

    .line 99
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 100
    .line 101
    sget-object v31, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 102
    .line 103
    const v37, 0x1f7fffff

    .line 104
    .line 105
    .line 106
    const/16 v27, 0x0

    .line 107
    .line 108
    move-object v9, v8

    .line 109
    move-object v10, v8

    .line 110
    move-object v11, v8

    .line 111
    move-object v12, v8

    .line 112
    move-object v13, v8

    .line 113
    move-object v14, v8

    .line 114
    move-object v15, v8

    .line 115
    move-object/from16 v16, v8

    .line 116
    .line 117
    move-object/from16 v17, v8

    .line 118
    .line 119
    move-object/from16 v18, v8

    .line 120
    .line 121
    move-object/from16 v19, v8

    .line 122
    .line 123
    move-object/from16 v20, v8

    .line 124
    .line 125
    move-object/from16 v21, v8

    .line 126
    .line 127
    move-object/from16 v22, v8

    .line 128
    .line 129
    move-object/from16 v23, v8

    .line 130
    .line 131
    move-object/from16 v24, v8

    .line 132
    .line 133
    move-object/from16 v25, v8

    .line 134
    .line 135
    move-object/from16 v26, v8

    .line 136
    .line 137
    move-object/from16 v28, v8

    .line 138
    .line 139
    move/from16 v29, v27

    .line 140
    .line 141
    move/from16 v30, v27

    .line 142
    .line 143
    move-object/from16 v32, v8

    .line 144
    .line 145
    move-object/from16 v33, v8

    .line 146
    .line 147
    move-object/from16 v34, v8

    .line 148
    .line 149
    move-object/from16 v35, v8

    .line 150
    .line 151
    move-object/from16 v36, v8

    .line 152
    .line 153
    move-object/from16 v38, v8

    .line 154
    .line 155
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_2

    .line 164
    .line 165
    return-object v8

    .line 166
    :cond_3
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 170
    .line 171
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutClient:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 172
    .line 173
    iput v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->label:I

    .line 174
    .line 175
    invoke-virtual {v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->startCheckout(LX/2M4;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v5

    .line 179
    if-ne v5, v3, :cond_0

    .line 180
    .line 181
    return-object v3

    .line 182
    :cond_4
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 183
    .line 184
    invoke-static {v0, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->access$applyCountryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;)V

    .line 185
    .line 186
    .line 187
    iget-object v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 188
    .line 189
    iget-object v6, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 190
    .line 191
    if-eqz v7, :cond_8

    .line 192
    .line 193
    if-eqz v6, :cond_8

    .line 194
    .line 195
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 196
    .line 197
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 198
    .line 199
    :cond_5
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    move-object v9, v1

    .line 204
    check-cast v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 205
    .line 206
    const p0, 0x1ffe7fff

    .line 207
    .line 208
    .line 209
    const/16 v29, 0x0

    .line 210
    .line 211
    move-object v10, v8

    .line 212
    move-object v11, v8

    .line 213
    move-object v12, v8

    .line 214
    move-object v13, v8

    .line 215
    move-object v14, v8

    .line 216
    move-object v15, v8

    .line 217
    move-object/from16 v16, v8

    .line 218
    .line 219
    move-object/from16 v17, v8

    .line 220
    .line 221
    move-object/from16 v18, v8

    .line 222
    .line 223
    move-object/from16 v19, v8

    .line 224
    .line 225
    move-object/from16 v20, v8

    .line 226
    .line 227
    move-object/from16 v21, v8

    .line 228
    .line 229
    move-object/from16 v22, v8

    .line 230
    .line 231
    move-object/from16 v23, v8

    .line 232
    .line 233
    move-object/from16 v24, v8

    .line 234
    .line 235
    move-object/from16 v25, v7

    .line 236
    .line 237
    move-object/from16 v26, v6

    .line 238
    .line 239
    move-object/from16 v27, v8

    .line 240
    .line 241
    move-object/from16 v28, v8

    .line 242
    .line 243
    move-object/from16 v30, v8

    .line 244
    .line 245
    move/from16 v31, v29

    .line 246
    .line 247
    move/from16 v32, v29

    .line 248
    .line 249
    move-object/from16 v33, v8

    .line 250
    .line 251
    move-object/from16 v34, v8

    .line 252
    .line 253
    move-object/from16 v35, v8

    .line 254
    .line 255
    move-object/from16 v36, v8

    .line 256
    .line 257
    move-object/from16 v37, v8

    .line 258
    .line 259
    move-object/from16 v38, v8

    .line 260
    .line 261
    move-object/from16 p1, v8

    .line 262
    .line 263
    invoke-static/range {v9 .. v40}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_5

    .line 272
    .line 273
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 274
    .line 275
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 276
    .line 277
    if-eqz v0, :cond_6

    .line 278
    .line 279
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 280
    .line 281
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 282
    .line 283
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logFormConfig(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    :cond_6
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 287
    .line 288
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 289
    .line 290
    :cond_7
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    move-object v7, v1

    .line 295
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 296
    .line 297
    sget-object v31, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->READY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 298
    .line 299
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 300
    .line 301
    const v37, 0x1f7fbfff

    .line 302
    .line 303
    .line 304
    move-object v9, v8

    .line 305
    move-object/from16 v22, v0

    .line 306
    .line 307
    move-object/from16 v25, v8

    .line 308
    .line 309
    move-object/from16 v26, v8

    .line 310
    .line 311
    move/from16 v27, v29

    .line 312
    .line 313
    move/from16 v30, v29

    .line 314
    .line 315
    move-object/from16 v32, v8

    .line 316
    .line 317
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 322
    .line 323
    .line 324
    move-result v0

    .line 325
    if-eqz v0, :cond_7

    .line 326
    .line 327
    return-object v3

    .line 328
    :cond_8
    const-string v0, "checkout/init opened without a charge amount"

    .line 329
    .line 330
    invoke-static {v2, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 331
    .line 332
    .line 333
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 334
    .line 335
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 336
    .line 337
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;->NO_AMOUNT:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 338
    .line 339
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;

    .line 340
    .line 341
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 342
    .line 343
    .line 344
    invoke-interface {v2, v0}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 345
    .line 346
    .line 347
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 348
    .line 349
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_checkoutUnavailable:LX/EYl;

    .line 350
    .line 351
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 352
    .line 353
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 354
    .line 355
    .line 356
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 357
    .line 358
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 359
    .line 360
    :cond_9
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    move-object v7, v1

    .line 365
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 366
    .line 367
    sget-object v31, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 368
    .line 369
    const v37, 0x1f7fffff

    .line 370
    .line 371
    .line 372
    const/16 v27, 0x0

    .line 373
    .line 374
    move-object v9, v8

    .line 375
    move-object v10, v8

    .line 376
    move-object v11, v8

    .line 377
    move-object v12, v8

    .line 378
    move-object v13, v8

    .line 379
    move-object v14, v8

    .line 380
    move-object v15, v8

    .line 381
    move-object/from16 v16, v8

    .line 382
    .line 383
    move-object/from16 v17, v8

    .line 384
    .line 385
    move-object/from16 v18, v8

    .line 386
    .line 387
    move-object/from16 v19, v8

    .line 388
    .line 389
    move-object/from16 v20, v8

    .line 390
    .line 391
    move-object/from16 v21, v8

    .line 392
    .line 393
    move-object/from16 v22, v8

    .line 394
    .line 395
    move-object/from16 v23, v8

    .line 396
    .line 397
    move-object/from16 v24, v8

    .line 398
    .line 399
    move-object/from16 v25, v8

    .line 400
    .line 401
    move-object/from16 v26, v8

    .line 402
    .line 403
    move-object/from16 v28, v8

    .line 404
    .line 405
    move/from16 v29, v27

    .line 406
    .line 407
    move/from16 v30, v27

    .line 408
    .line 409
    move-object/from16 v32, v8

    .line 410
    .line 411
    move-object/from16 v33, v8

    .line 412
    .line 413
    move-object/from16 v34, v8

    .line 414
    .line 415
    move-object/from16 v35, v8

    .line 416
    .line 417
    move-object/from16 v36, v8

    .line 418
    .line 419
    move-object/from16 v38, v8

    .line 420
    .line 421
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 426
    .line 427
    .line 428
    move-result v0

    .line 429
    if-eqz v0, :cond_9

    .line 430
    .line 431
    return-object v8

    .line 432
    :cond_a
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$AlreadyVerified;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$AlreadyVerified;

    .line 433
    .line 434
    invoke-static {v5, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    if-eqz v0, :cond_b

    .line 439
    .line 440
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 441
    .line 442
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_verified:LX/EYl;

    .line 443
    .line 444
    invoke-interface {v0, v8}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    return-object v8

    .line 448
    :cond_b
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Failed;

    .line 449
    .line 450
    if-eqz v0, :cond_d

    .line 451
    .line 452
    const-string v0, "checkout/init did not open"

    .line 453
    .line 454
    invoke-static {v2, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 455
    .line 456
    .line 457
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 458
    .line 459
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 460
    .line 461
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Failed;

    .line 462
    .line 463
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Failed;->reason:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 464
    .line 465
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;

    .line 466
    .line 467
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$CheckoutUnavailable;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 468
    .line 469
    .line 470
    invoke-interface {v2, v0}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 471
    .line 472
    .line 473
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 474
    .line 475
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_checkoutUnavailable:LX/EYl;

    .line 476
    .line 477
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 478
    .line 479
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 480
    .line 481
    .line 482
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;

    .line 483
    .line 484
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 485
    .line 486
    :cond_c
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 487
    .line 488
    .line 489
    move-result-object v1

    .line 490
    move-object v7, v1

    .line 491
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 492
    .line 493
    sget-object v31, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 494
    .line 495
    const v37, 0x1f7fffff

    .line 496
    .line 497
    .line 498
    const/16 v27, 0x0

    .line 499
    .line 500
    move-object v9, v8

    .line 501
    move-object v10, v8

    .line 502
    move-object v11, v8

    .line 503
    move-object v12, v8

    .line 504
    move-object v13, v8

    .line 505
    move-object v14, v8

    .line 506
    move-object v15, v8

    .line 507
    move-object/from16 v16, v8

    .line 508
    .line 509
    move-object/from16 v17, v8

    .line 510
    .line 511
    move-object/from16 v18, v8

    .line 512
    .line 513
    move-object/from16 v19, v8

    .line 514
    .line 515
    move-object/from16 v20, v8

    .line 516
    .line 517
    move-object/from16 v21, v8

    .line 518
    .line 519
    move-object/from16 v22, v8

    .line 520
    .line 521
    move-object/from16 v23, v8

    .line 522
    .line 523
    move-object/from16 v24, v8

    .line 524
    .line 525
    move-object/from16 v25, v8

    .line 526
    .line 527
    move-object/from16 v26, v8

    .line 528
    .line 529
    move-object/from16 v28, v8

    .line 530
    .line 531
    move/from16 v29, v27

    .line 532
    .line 533
    move/from16 v30, v27

    .line 534
    .line 535
    move-object/from16 v32, v8

    .line 536
    .line 537
    move-object/from16 v33, v8

    .line 538
    .line 539
    move-object/from16 v34, v8

    .line 540
    .line 541
    move-object/from16 v35, v8

    .line 542
    .line 543
    move-object/from16 v36, v8

    .line 544
    .line 545
    move-object/from16 v38, v8

    .line 546
    .line 547
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 548
    .line 549
    .line 550
    move-result-object v0

    .line 551
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 552
    .line 553
    .line 554
    move-result v0

    .line 555
    if-eqz v0, :cond_c

    .line 556
    .line 557
    return-object v8

    .line 558
    :cond_d
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 559
    .line 560
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 561
    .line 562
    .line 563
    throw v0

    .line 564
    :cond_e
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 565
    .line 566
    .line 567
    move-result-object v0

    .line 568
    throw v0
.end method
