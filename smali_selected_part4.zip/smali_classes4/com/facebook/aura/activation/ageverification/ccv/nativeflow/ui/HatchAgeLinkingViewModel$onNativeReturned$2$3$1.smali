.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2$3$1;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 9

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v0, p1

    .line 2
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2$3$1;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 6
    .line 7
    const/16 p0, 0xdf

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    move-object v3, v2

    .line 11
    move v4, v1

    .line 12
    move v5, v1

    .line 13
    move v7, v1

    .line 14
    move-object v8, v2

    .line 15
    move-object p1, v2

    .line 16
    invoke-static/range {v0 .. v10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2$3$1;->invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
