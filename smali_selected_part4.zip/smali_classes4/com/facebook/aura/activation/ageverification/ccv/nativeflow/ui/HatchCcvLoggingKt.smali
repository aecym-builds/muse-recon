.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLoggingKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final EVENT_COUNTRY_SELECTED:Ljava/lang/String; = "ccv_country_selected"

.field public static final EVENT_FORM_CONFIG:Ljava/lang/String; = "ccv_form_config"

.field public static final EVENT_FORM_OUTCOME:Ljava/lang/String; = "ccv_form_outcome"

.field public static final EVENT_FORM_VALIDATION:Ljava/lang/String; = "ccv_form_validation"

.field public static final EVENT_THREE_DS_STEP_UP:Ljava/lang/String; = "ccv_three_ds_step_up"

.field public static final EVENT_TYPE_ATTEMPT:Ljava/lang/String; = "attempt"

.field public static final EVENT_TYPE_ERROR:Ljava/lang/String; = "error"

.field public static final EVENT_TYPE_SUCCESS:Ljava/lang/String; = "success"

.field public static final EVENT_TYPE_WARNING:Ljava/lang/String; = "warning"

.field public static final FAILURE_MISSING_COUNTRY_CONFIG:Ljava/lang/String; = "missing_country_config"

.field public static final FIELD_CSC:Ljava/lang/String; = "csc"

.field public static final FIELD_EXPIRY:Ljava/lang/String; = "expiry"

.field public static final FIELD_PAN:Ljava/lang/String; = "pan"

.field public static final FIELD_ZIP:Ljava/lang/String; = "zip"

.field public static final KEY_AGE_CHECK_ID:Ljava/lang/String; = "age_check_id"

.field public static final KEY_BILLING_COUNTRY:Ljava/lang/String; = "billing_country"

.field public static final KEY_COUNTRY_COUNT:Ljava/lang/String; = "country_count"

.field public static final KEY_FIELD_ID:Ljava/lang/String; = "field_id"

.field public static final KEY_POSTAL_RULE_COUNT:Ljava/lang/String; = "postal_rule_count"

.field public static final KEY_STEP_UP_SOURCE:Ljava/lang/String; = "step_up_source"

.field public static final KEY_UPL_SESSION_ID:Ljava/lang/String; = "upl_session_id"

.field public static final NO_POSTAL_FIELD:Ljava/lang/String; = "null"

.field public static final STEP_UP_SOURCE_CREDENTIAL:Ljava/lang/String; = "credential"


# direct methods
.method public static final synthetic access$toFieldAndReason(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)LX/IBK;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLoggingKt;->toFieldAndReason(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)LX/IBK;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final toFieldAndReason(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)LX/IBK;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            ")",
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    const-string p0, "csc"

    .line 5
    .line 6
    const-string v4, "INCOMPLETE"

    .line 7
    .line 8
    const-string v3, "expiry"

    .line 9
    .line 10
    const-string v2, "EMPTY"

    .line 11
    .line 12
    const-string v1, "pan"

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 18
    .line 19
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 20
    .line 21
    .line 22
    throw v0

    .line 23
    :pswitch_0
    const-string v4, "INVALID"

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :pswitch_1
    const-string v4, "UNSUPPORTED_BRAND"

    .line 27
    .line 28
    :goto_0
    :pswitch_2
    new-instance v0, LX/IBK;

    .line 29
    .line 30
    invoke-direct {v0, v1, v4}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    return-object v0

    .line 34
    :pswitch_3
    const-string v4, "INVALID_MONTH"

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :pswitch_4
    const-string v4, "EXPIRED"

    .line 38
    .line 39
    :goto_1
    :pswitch_5
    new-instance v0, LX/IBK;

    .line 40
    .line 41
    invoke-direct {v0, v3, v4}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :pswitch_6
    const-string v2, "EXACT_LENGTH"

    .line 46
    .line 47
    :pswitch_7
    new-instance v0, LX/IBK;

    .line 48
    .line 49
    invoke-direct {v0, p0, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    return-object v0

    .line 53
    :pswitch_8
    const-string v1, "zip"

    .line 54
    .line 55
    :pswitch_9
    new-instance v0, LX/IBK;

    .line 56
    .line 57
    invoke-direct {v0, v1, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_a
    new-instance v0, LX/IBK;

    .line 62
    .line 63
    invoke-direct {v0, v3, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    return-object v0

    .line 67
    nop

    .line 68
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_2
        :pswitch_0
        :pswitch_1
        :pswitch_a
        :pswitch_5
        :pswitch_3
        :pswitch_4
        :pswitch_7
        :pswitch_6
        :pswitch_8
    .end packed-switch
.end method
