.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "HatchCcvViewModel"


# direct methods
.method public static final synthetic access$nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;->nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 2

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    const/4 v0, 0x0

    .line 7
    if-eq v1, v0, :cond_1

    .line 8
    .line 9
    const/4 v0, 0x4

    .line 10
    if-eq v1, v0, :cond_1

    .line 11
    .line 12
    const/16 v0, 0x8

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    const/16 v0, 0xa

    .line 17
    .line 18
    if-eq v1, v0, :cond_1

    .line 19
    .line 20
    :cond_0
    return-object p0

    .line 21
    :cond_1
    const/4 p0, 0x0

    .line 22
    return-object p0
.end method
