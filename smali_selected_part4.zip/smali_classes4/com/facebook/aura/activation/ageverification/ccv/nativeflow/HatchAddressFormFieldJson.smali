.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$Companion;


# instance fields
.field public final field_id:Ljava/lang/String;

.field public final field_type:Ljava/lang/String;

.field public final is_optional:Z

.field public final label:Ljava/lang/String;

.field public final placeholder:Ljava/lang/String;

.field public final validation_rules:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;"
        }
    .end annotation
.end field

.field public final value_type:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v8

    .line 16
    move-object v3, v2

    .line 17
    move-object v4, v2

    .line 18
    move-object v5, v2

    .line 19
    move-object v6, v2

    .line 20
    move-object v7, v2

    .line 21
    filled-new-array/range {v2 .. v8}, [Lkotlin/Lazy;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->$childSerializers:[Lkotlin/Lazy;

    .line 26
    .line 27
    return-void
.end method

.method public constructor <init>()V
    .locals 8

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v7, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    const/4 v5, 0x0

    .line 805306372
    move-object v0, p0

    .line 805306373
    move-object v2, v1

    .line 805306374
    move-object v3, v1

    .line 805306375
    move-object v4, v1

    .line 805306376
    move-object v6, v1

    .line 805306377
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)V

    .line 805306378
    .line 805306379
    .line 805306380
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const/4 v1, 0x0

    .line 536870918
    if-nez v0, :cond_5

    .line 536870919
    .line 536870920
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 536870921
    .line 536870922
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    if-nez v0, :cond_4

    .line 536870925
    .line 536870926
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 536870927
    .line 536870928
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_3

    .line 536870931
    .line 536870932
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 536870933
    .line 536870934
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 536870935
    .line 536870936
    if-nez v0, :cond_2

    .line 536870937
    .line 536870938
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 536870939
    .line 536870940
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 536870941
    .line 536870942
    if-nez v0, :cond_1

    .line 536870943
    .line 536870944
    const/4 v0, 0x0

    .line 536870945
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 536870946
    .line 536870947
    :goto_4
    and-int/lit8 v0, p1, 0x20

    .line 536870948
    .line 536870949
    if-nez v0, :cond_0

    .line 536870950
    .line 536870951
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 536870952
    .line 536870953
    :goto_5
    and-int/lit8 v0, p1, 0x40

    .line 536870954
    .line 536870955
    if-nez v0, :cond_6

    .line 536870956
    .line 536870957
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870958
    .line 536870959
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 536870960
    .line 536870961
    return-void

    .line 536870962
    :cond_0
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 536870963
    .line 536870964
    goto :goto_5

    .line 536870965
    :cond_1
    iput-boolean p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 536870966
    .line 536870967
    goto :goto_4

    .line 536870968
    :cond_2
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 536870969
    .line 536870970
    goto :goto_3

    .line 536870971
    :cond_3
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 536870972
    .line 536870973
    goto :goto_2

    .line 536870974
    :cond_4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 536870975
    .line 536870976
    goto :goto_1

    .line 536870977
    :cond_5
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 536870978
    .line 536870979
    goto :goto_0

    .line 536870980
    :cond_6
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 536870981
    .line 536870982
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x6

    .line 1
    invoke-static {p7, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 14
    .line 15
    iput-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 16
    .line 17
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 20
    .line 21
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p8, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    move-object p4, v1

    .line 268435477
    :cond_3
    invoke-static {p8, p5}, LX/3Rr;->A1Q(IZ)Z

    .line 268435478
    .line 268435479
    .line 268435480
    move-result p5

    .line 268435481
    and-int/lit8 v0, p8, 0x20

    .line 268435482
    .line 268435483
    if-eqz v0, :cond_4

    .line 268435484
    .line 268435485
    move-object p6, v1

    .line 268435486
    :cond_4
    and-int/lit8 v0, p8, 0x40

    .line 268435487
    .line 268435488
    if-eqz v0, :cond_5

    .line 268435489
    .line 268435490
    sget-object p7, LX/0wV;->A00:LX/0wV;

    .line 268435491
    .line 268435492
    :cond_5
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)V

    .line 268435493
    .line 268435494
    .line 268435495
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p8, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 41
    .line 42
    :cond_6
    invoke-virtual/range {p0 .. p7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    if-nez v4, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v2, 0x1

    .line 21
    if-nez v4, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 24
    .line 25
    if-eqz v0, :cond_3

    .line 26
    .line 27
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 30
    .line 31
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 32
    .line 33
    .line 34
    :cond_3
    const/4 v2, 0x2

    .line 35
    if-nez v4, :cond_4

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 38
    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 44
    .line 45
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 46
    .line 47
    .line 48
    :cond_5
    const/4 v2, 0x3

    .line 49
    if-nez v4, :cond_6

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 52
    .line 53
    if-eqz v0, :cond_7

    .line 54
    .line 55
    :cond_6
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 60
    .line 61
    .line 62
    :cond_7
    const/4 v1, 0x4

    .line 63
    if-nez v4, :cond_8

    .line 64
    .line 65
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 66
    .line 67
    if-eqz v0, :cond_9

    .line 68
    .line 69
    :cond_8
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 70
    .line 71
    invoke-interface {p1, p2, v1, v0}, LX/Da8;->AAB(LX/Da5;IZ)V

    .line 72
    .line 73
    .line 74
    :cond_9
    const/4 v2, 0x5

    .line 75
    if-nez v4, :cond_a

    .line 76
    .line 77
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v0, :cond_b

    .line 80
    .line 81
    :cond_a
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 82
    .line 83
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 84
    .line 85
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 86
    .line 87
    .line 88
    :cond_b
    const/4 v2, 0x6

    .line 89
    if-nez v4, :cond_c

    .line 90
    .line 91
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 92
    .line 93
    invoke-static {v0}, LX/3Rp;->A1Q(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-nez v0, :cond_d

    .line 98
    .line 99
    :cond_c
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 104
    .line 105
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 106
    .line 107
    .line 108
    :cond_d
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x6

    .line 1
    invoke-static {p7, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 51
    .line 52
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 53
    .line 54
    if-ne v1, v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_1

    .line 75
    .line 76
    :cond_0
    return v2

    .line 77
    :cond_1
    return v3
.end method

.method public final getField_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getField_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlaceholder()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getValidation_rules()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvValidationRuleJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getValue_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->field_type:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    add-int/2addr v1, v0

    .line 15
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->label:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    add-int/2addr v1, v0

    .line 24
    mul-int/lit8 v1, v1, 0x1f

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->placeholder:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v1, v0

    .line 33
    mul-int/lit8 v1, v1, 0x1f

    .line 34
    .line 35
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 36
    .line 37
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->value_type:Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    add-int/2addr v1, v0

    .line 48
    mul-int/lit8 v1, v1, 0x1f

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->validation_rules:Ljava/util/List;

    .line 51
    .line 52
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    return v0
.end method

.method public final is_optional()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldJson;->is_optional:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
