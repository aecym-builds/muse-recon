.class public final enum Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

.field public static final enum BLOCKED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

.field public static final enum CONTINUE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction$Companion;

.field public static final enum PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

.field public static final enum RESTART_LINKING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

.field public static final enum USE_CREDIT_CARD:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;


# instance fields
.field public final wireValue:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    .line 0
    const/4 v2, 0x0

    .line 1
    const-string v1, "pending"

    .line 2
    .line 3
    const-string v0, "PENDING"

    .line 4
    .line 5
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 6
    .line 7
    invoke-direct {v7, v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    const-string v1, "continue"

    .line 14
    .line 15
    const-string v0, "CONTINUE"

    .line 16
    .line 17
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 18
    .line 19
    invoke-direct {v6, v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sput-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->CONTINUE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const-string v1, "blocked"

    .line 26
    .line 27
    const-string v0, "BLOCKED"

    .line 28
    .line 29
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 30
    .line 31
    invoke-direct {v5, v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    sput-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->BLOCKED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    const-string v1, "use_credit_card"

    .line 38
    .line 39
    const-string v0, "USE_CREDIT_CARD"

    .line 40
    .line 41
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 42
    .line 43
    invoke-direct {v4, v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-object v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->USE_CREDIT_CARD:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 47
    .line 48
    const/4 v3, 0x4

    .line 49
    const-string v2, "restart_linking"

    .line 50
    .line 51
    const-string v1, "RESTART_LINKING"

    .line 52
    .line 53
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 54
    .line 55
    invoke-direct {v0, v1, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    .line 56
    .line 57
    .line 58
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->RESTART_LINKING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 59
    .line 60
    filled-new-array {v7, v6, v5, v4, v0}, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 65
    .line 66
    new-instance v0, LX/DvM;

    .line 67
    .line 68
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 69
    .line 70
    .line 71
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->$ENTRIES:LX/0vk;

    .line 72
    .line 73
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction$Companion;

    .line 74
    .line 75
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 76
    .line 77
    .line 78
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction$Companion;

    .line 79
    .line 80
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->wireValue:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getWireValue()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->wireValue:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
