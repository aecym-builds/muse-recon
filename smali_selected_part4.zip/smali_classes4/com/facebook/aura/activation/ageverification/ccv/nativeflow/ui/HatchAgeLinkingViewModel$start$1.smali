.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.ui.HatchAgeLinkingViewModel$start$1"
    f = "HatchAgeLinking.kt"
    l = {
        0x6c
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

.field public final synthetic $attempt:I

.field public final synthetic $method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

.field public final synthetic $reportsNotOffered:Z

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;ILcom/facebook/aura/user/provider/AgeCheckMethod;ZLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "I",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Z",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$attempt:I

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$reportsNotOffered:Z

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 3
    .line 4
    iget v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$attempt:I

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 7
    .line 8
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$reportsNotOffered:Z

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;ILcom/facebook/aura/user/provider/AgeCheckMethod;ZLX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->label:I

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    if-eqz v1, :cond_1

    .line 6
    .line 7
    if-ne v1, v0, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v2

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;

    .line 19
    .line 20
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 21
    .line 22
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$accountType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 23
    .line 24
    iget v6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$attempt:I

    .line 25
    .line 26
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$method:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 27
    .line 28
    iget-boolean v8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->$reportsNotOffered:Z

    .line 29
    .line 30
    const/4 v9, 0x0

    .line 31
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1;

    .line 32
    .line 33
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;ILcom/facebook/aura/user/provider/AgeCheckMethod;ZLX/2M4;)V

    .line 34
    .line 35
    .line 36
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;->label:I

    .line 37
    .line 38
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 39
    .line 40
    invoke-interface {v1, v0, v3, p0}, Lcom/facebook/aura/common/coroutines/SingleFlight;->invoke(Ljava/lang/Object;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-ne v0, v2, :cond_0

    .line 45
    .line 46
    return-object v2

    .line 47
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    throw v0
.end method
