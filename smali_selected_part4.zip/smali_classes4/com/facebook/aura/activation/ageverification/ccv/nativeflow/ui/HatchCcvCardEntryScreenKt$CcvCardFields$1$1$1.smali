.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/1gD;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $expiryFocus:LX/3Bk;


# direct methods
.method public constructor <init>(LX/3Bk;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;->$expiryFocus:LX/3Bk;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;->$expiryFocus:LX/3Bk;

    .line 1
    .line 2
    invoke-static {p0}, LX/3Bk;->A00(LX/3Bk;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1gD;)V
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;->$expiryFocus:LX/3Bk;

    .line 268435457
    .line 268435458
    invoke-static {p0}, LX/3Bk;->A00(LX/3Bk;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method
