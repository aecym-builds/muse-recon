.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $hasLoggedCountryPicker$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $isCountryPickerShown:Z


# direct methods
.method public constructor <init>(ZLandroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->$isCountryPickerShown:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->$hasLoggedCountryPicker$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 1

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->$isCountryPickerShown:Z

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->$hasLoggedCountryPicker$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->$hasLoggedCountryPicker$delegate:Landroidx/compose/runtime/MutableState;

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-static {v0, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 16
    .line 17
    .line 18
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CCV_COUNTRY_PICKER:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    invoke-static {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt;->logCcvImpression(Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1$invoke$$inlined$onDispose$1;

    .line 25
    .line 26
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryHostKt$HatchCcvCardEntryHost$3$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
