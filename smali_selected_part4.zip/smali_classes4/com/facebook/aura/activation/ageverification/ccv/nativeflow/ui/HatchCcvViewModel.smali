.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _checkoutUnavailable:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final _verified:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            ">;"
        }
    .end annotation
.end field

.field public final _viewEffect:LX/5Lx;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/5Lx<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;",
            ">;"
        }
    .end annotation
.end field

.field public final checkoutClient:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

.field public final checkoutUnavailable:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public volatile hasLinkingOptions:Z

.field public final isAgeConfirmation:Z

.field public final linkingOptionsMutex:LX/3Hh;

.field public final linkingOptionsRetryDelaysMs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public final pendingThreeDSChallenge:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;",
            ">;"
        }
    .end annotation
.end field

.field public volatile sessionDeferred:LX/EQR;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EQR<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;",
            ">;"
        }
    .end annotation
.end field

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;"
        }
    .end annotation
.end field

.field public final verificationPurpose:Ljava/lang/String;

.field public final verified:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            ">;"
        }
    .end annotation
.end field

.field public final viewEffect:LX/2QV;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2QV<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Ljava/lang/String;)V
    .locals 36

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v4, p0

    .line 7
    .line 8
    invoke-direct {v4}, LX/1EJ;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutClient:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 12
    .line 13
    move-object/from16 v0, p2

    .line 14
    .line 15
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->verificationPurpose:Ljava/lang/String;

    .line 16
    .line 17
    const/4 v5, 0x1

    .line 18
    invoke-static {v0}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    iput-boolean v3, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 23
    .line 24
    const p1, 0x1fffffff

    .line 25
    .line 26
    .line 27
    const/4 v8, 0x0

    .line 28
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 29
    .line 30
    move-object v9, v8

    .line 31
    move-object v10, v8

    .line 32
    move-object v11, v8

    .line 33
    move-object v12, v8

    .line 34
    move-object v13, v8

    .line 35
    move-object v14, v8

    .line 36
    move-object v15, v8

    .line 37
    move-object/from16 v16, v8

    .line 38
    .line 39
    move-object/from16 v17, v8

    .line 40
    .line 41
    move-object/from16 v18, v8

    .line 42
    .line 43
    move-object/from16 v19, v8

    .line 44
    .line 45
    move-object/from16 v20, v8

    .line 46
    .line 47
    move-object/from16 v21, v8

    .line 48
    .line 49
    move-object/from16 v22, v8

    .line 50
    .line 51
    move-object/from16 v23, v8

    .line 52
    .line 53
    move-object/from16 v24, v8

    .line 54
    .line 55
    move-object/from16 v25, v8

    .line 56
    .line 57
    move-object/from16 v26, v8

    .line 58
    .line 59
    move/from16 v27, v6

    .line 60
    .line 61
    move-object/from16 v28, v8

    .line 62
    .line 63
    move/from16 v29, v6

    .line 64
    .line 65
    move/from16 v30, v6

    .line 66
    .line 67
    move-object/from16 v31, v8

    .line 68
    .line 69
    move-object/from16 v32, v8

    .line 70
    .line 71
    move-object/from16 v33, v8

    .line 72
    .line 73
    move-object/from16 v34, v8

    .line 74
    .line 75
    move-object/from16 v35, v8

    .line 76
    .line 77
    move-object/from16 p0, v8

    .line 78
    .line 79
    move-object/from16 p2, v8

    .line 80
    .line 81
    invoke-direct/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILX/04f;)V

    .line 82
    .line 83
    .line 84
    new-instance v1, LX/Ddv;

    .line 85
    .line 86
    invoke-direct {v1, v7}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    iput-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 90
    .line 91
    new-instance v0, LX/ERk;

    .line 92
    .line 93
    invoke-direct {v0, v8, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 94
    .line 95
    .line 96
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->uiState:LX/2J3;

    .line 97
    .line 98
    sget-object v2, LX/FkO;->A00:Ljava/lang/Integer;

    .line 99
    .line 100
    invoke-static {v2, v6, v5}, LX/5NB;->A00(Ljava/lang/Integer;II)LX/Ddz;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    iput-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 105
    .line 106
    new-instance v0, LX/ETm;

    .line 107
    .line 108
    invoke-direct {v0, v8, v1}, LX/ETm;-><init>(LX/Cbu;LX/2QV;)V

    .line 109
    .line 110
    .line 111
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->viewEffect:LX/2QV;

    .line 112
    .line 113
    const/4 v1, -0x1

    .line 114
    invoke-static {v2, v1}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_verified:LX/EYl;

    .line 119
    .line 120
    invoke-static {v0}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->verified:LX/2Lw;

    .line 125
    .line 126
    invoke-static {v2, v1}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_checkoutUnavailable:LX/EYl;

    .line 131
    .line 132
    invoke-static {v0}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutUnavailable:LX/2Lw;

    .line 137
    .line 138
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 139
    .line 140
    invoke-direct {v0, v8}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->pendingThreeDSChallenge:Ljava/util/concurrent/atomic/AtomicReference;

    .line 144
    .line 145
    new-instance v0, LX/DSP;

    .line 146
    .line 147
    invoke-direct {v0}, LX/DSP;-><init>()V

    .line 148
    .line 149
    .line 150
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->linkingOptionsMutex:LX/3Hh;

    .line 151
    .line 152
    const-wide/16 v0, 0x7d0

    .line 153
    .line 154
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 155
    .line 156
    .line 157
    move-result-object v2

    .line 158
    const-wide/16 v0, 0xfa0

    .line 159
    .line 160
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    filled-new-array {v2, v0}, [Ljava/lang/Long;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->linkingOptionsRetryDelaysMs:Ljava/util/List;

    .line 173
    .line 174
    if-eqz v3, :cond_0

    .line 175
    .line 176
    invoke-direct {v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->fetchLinkingOptionsAndStartCheckout()V

    .line 177
    .line 178
    .line 179
    return-void

    .line 180
    :cond_0
    invoke-direct {v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->startCheckout()V

    .line 181
    .line 182
    .line 183
    return-void
.end method

.method public static final synthetic access$applyCountryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->applyCountryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$applyScreenContent(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->applyScreenContent(Ljava/lang/String;Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$applySupportedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->applySupportedCardTypes(Ljava/util/List;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$awaitCheckoutSession(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->awaitCheckoutSession(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getCheckoutClient$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutClient:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getHasLinkingOptions$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->hasLinkingOptions:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$getLinkingOptionsRetryDelaysMs$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)Ljava/util/List;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->linkingOptionsRetryDelaysMs:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSessionDeferred$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)LX/EQR;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->sessionDeferred:LX/EQR;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_checkoutUnavailable$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)LX/EYl;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_checkoutUnavailable:LX/EYl;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_verified$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)LX/EYl;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_verified:LX/EYl;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_viewEffect$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)LX/5Lx;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$isAgeConfirmation$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$readLinkingOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->readLinkingOptions(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$startCheckout(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->startCheckout()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final applyCountryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;)V
    .locals 37

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    iget-object v4, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->defaultCountry:Ljava/lang/String;

    .line 3
    .line 4
    move-object/from16 v6, p0

    .line 5
    .line 6
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 7
    .line 8
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    move-object v7, v2

    .line 13
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 14
    .line 15
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->countries:LX/Ddn;

    .line 16
    .line 17
    invoke-virtual {v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->isCountrySelectable()Z

    .line 18
    .line 19
    .line 20
    move-result v27

    .line 21
    invoke-virtual {v5, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;->configFor(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 28
    .line 29
    :goto_0
    const p0, 0x1fe1ffff

    .line 30
    .line 31
    .line 32
    const/4 v8, 0x0

    .line 33
    const/16 v29, 0x0

    .line 34
    .line 35
    move-object v9, v8

    .line 36
    move-object v10, v8

    .line 37
    move-object v11, v8

    .line 38
    move-object v12, v8

    .line 39
    move-object v13, v8

    .line 40
    move-object v14, v8

    .line 41
    move-object v15, v8

    .line 42
    move-object/from16 v16, v8

    .line 43
    .line 44
    move-object/from16 v17, v8

    .line 45
    .line 46
    move-object/from16 v18, v8

    .line 47
    .line 48
    move-object/from16 v19, v8

    .line 49
    .line 50
    move-object/from16 v20, v8

    .line 51
    .line 52
    move-object/from16 v21, v8

    .line 53
    .line 54
    move-object/from16 v22, v8

    .line 55
    .line 56
    move-object/from16 v23, v8

    .line 57
    .line 58
    move-object/from16 v24, v8

    .line 59
    .line 60
    move-object/from16 v25, v4

    .line 61
    .line 62
    move-object/from16 v26, v1

    .line 63
    .line 64
    move-object/from16 v28, v0

    .line 65
    .line 66
    move/from16 v30, v29

    .line 67
    .line 68
    move-object/from16 v31, v8

    .line 69
    .line 70
    move-object/from16 v32, v8

    .line 71
    .line 72
    move-object/from16 v33, v8

    .line 73
    .line 74
    move-object/from16 v34, v8

    .line 75
    .line 76
    move-object/from16 v35, v8

    .line 77
    .line 78
    move-object/from16 v36, v8

    .line 79
    .line 80
    move-object/from16 p1, v8

    .line 81
    .line 82
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-direct {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_0

    .line 95
    .line 96
    return-void

    .line 97
    :cond_1
    const/4 v0, 0x0

    .line 98
    goto :goto_0
.end method

.method private final applyOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;)V
    .locals 39

    .line 0
    move-object/from16 v6, p0

    .line 1
    .line 2
    iget-object v5, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    move-object v8, v4

    .line 9
    check-cast v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    move-object/from16 v7, p1

    .line 12
    .line 13
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 14
    .line 15
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 16
    .line 17
    .line 18
    move-result-object v36

    .line 19
    iget-object v3, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 20
    .line 21
    if-nez v3, :cond_1

    .line 22
    .line 23
    iget-object v3, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 24
    .line 25
    :cond_1
    iget-object v2, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 26
    .line 27
    if-nez v2, :cond_2

    .line 28
    .line 29
    iget-object v2, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 30
    .line 31
    :cond_2
    iget-object v1, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 32
    .line 33
    if-nez v1, :cond_3

    .line 34
    .line 35
    iget-object v1, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeAmount:Ljava/lang/String;

    .line 36
    .line 37
    :cond_3
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 38
    .line 39
    if-nez v0, :cond_4

    .line 40
    .line 41
    iget-object v0, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->chargeCurrency:Ljava/lang/String;

    .line 42
    .line 43
    :cond_4
    const v38, 0x17fe4fff

    .line 44
    .line 45
    .line 46
    const/4 v9, 0x0

    .line 47
    const/16 v28, 0x0

    .line 48
    .line 49
    move-object v10, v9

    .line 50
    move-object v11, v9

    .line 51
    move-object v12, v9

    .line 52
    move-object v13, v9

    .line 53
    move-object v14, v9

    .line 54
    move-object v15, v9

    .line 55
    move-object/from16 v16, v9

    .line 56
    .line 57
    move-object/from16 v17, v9

    .line 58
    .line 59
    move-object/from16 v18, v9

    .line 60
    .line 61
    move-object/from16 v19, v9

    .line 62
    .line 63
    move-object/from16 v20, v9

    .line 64
    .line 65
    move-object/from16 v21, v3

    .line 66
    .line 67
    move-object/from16 v22, v2

    .line 68
    .line 69
    move-object/from16 v23, v9

    .line 70
    .line 71
    move-object/from16 v24, v1

    .line 72
    .line 73
    move-object/from16 v25, v0

    .line 74
    .line 75
    move-object/from16 v26, v9

    .line 76
    .line 77
    move-object/from16 v27, v9

    .line 78
    .line 79
    move-object/from16 v29, v9

    .line 80
    .line 81
    move/from16 v30, v28

    .line 82
    .line 83
    move/from16 v31, v28

    .line 84
    .line 85
    move-object/from16 v32, v9

    .line 86
    .line 87
    move-object/from16 v33, v9

    .line 88
    .line 89
    move-object/from16 v34, v9

    .line 90
    .line 91
    move-object/from16 v35, v9

    .line 92
    .line 93
    move-object/from16 v37, v9

    .line 94
    .line 95
    move-object/from16 p0, v9

    .line 96
    .line 97
    invoke-static/range {v8 .. v39}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-direct {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-interface {v5, v4, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_0

    .line 110
    .line 111
    return-void
.end method

.method private final applyScreenContent(Ljava/lang/String;Ljava/lang/String;)V
    .locals 35

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    if-nez p2, :cond_0

    .line 3
    .line 4
    return-void

    .line 5
    :cond_0
    move-object/from16 v0, p0

    .line 6
    .line 7
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 8
    .line 9
    :cond_1
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    move-object v4, v2

    .line 14
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 15
    .line 16
    if-nez p1, :cond_3

    .line 17
    .line 18
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenTitle:Ljava/lang/String;

    .line 19
    .line 20
    :goto_0
    if-nez p2, :cond_2

    .line 21
    .line 22
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->screenSubtitle:Ljava/lang/String;

    .line 23
    .line 24
    :goto_1
    const v34, 0x1fffcfff

    .line 25
    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    const/16 v24, 0x0

    .line 29
    .line 30
    move-object v6, v5

    .line 31
    move-object v7, v5

    .line 32
    move-object v8, v5

    .line 33
    move-object v9, v5

    .line 34
    move-object v10, v5

    .line 35
    move-object v11, v5

    .line 36
    move-object v12, v5

    .line 37
    move-object v13, v5

    .line 38
    move-object v14, v5

    .line 39
    move-object v15, v5

    .line 40
    move-object/from16 v16, v5

    .line 41
    .line 42
    move-object/from16 v17, v1

    .line 43
    .line 44
    move-object/from16 v18, v0

    .line 45
    .line 46
    move-object/from16 v19, v5

    .line 47
    .line 48
    move-object/from16 v20, v5

    .line 49
    .line 50
    move-object/from16 v21, v5

    .line 51
    .line 52
    move-object/from16 v22, v5

    .line 53
    .line 54
    move-object/from16 v23, v5

    .line 55
    .line 56
    move-object/from16 v25, v5

    .line 57
    .line 58
    move/from16 v26, v24

    .line 59
    .line 60
    move/from16 v27, v24

    .line 61
    .line 62
    move-object/from16 v28, v5

    .line 63
    .line 64
    move-object/from16 v29, v5

    .line 65
    .line 66
    move-object/from16 v30, v5

    .line 67
    .line 68
    move-object/from16 v31, v5

    .line 69
    .line 70
    move-object/from16 v32, v5

    .line 71
    .line 72
    move-object/from16 v33, v5

    .line 73
    .line 74
    move-object/from16 p0, v5

    .line 75
    .line 76
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_1

    .line 85
    .line 86
    return-void

    .line 87
    :cond_2
    move-object/from16 v0, p2

    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_3
    move-object/from16 v1, p1

    .line 91
    .line 92
    goto :goto_0
.end method

.method private final applySupportedCardTypes(Ljava/util/List;)V
    .locals 57
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    move-object/from16 v2, p0

    .line 1
    .line 2
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v1}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    move-object v5, v3

    .line 9
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    move-object/from16 v4, p1

    .line 12
    .line 13
    invoke-static {v4}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 14
    .line 15
    .line 16
    move-result-object v11

    .line 17
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->Companion:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;

    .line 18
    .line 19
    invoke-virtual {v0, v4}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;->acceptedNetworks(Ljava/util/List;)Ljava/util/List;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 24
    .line 25
    .line 26
    move-result-object v12

    .line 27
    const v35, 0x1fffff9f

    .line 28
    .line 29
    .line 30
    const/4 v6, 0x0

    .line 31
    const/16 v25, 0x0

    .line 32
    .line 33
    move-object v7, v6

    .line 34
    move-object v8, v6

    .line 35
    move-object v9, v6

    .line 36
    move-object v10, v6

    .line 37
    move-object v13, v6

    .line 38
    move-object v14, v6

    .line 39
    move-object v15, v6

    .line 40
    move-object/from16 v16, v6

    .line 41
    .line 42
    move-object/from16 v17, v6

    .line 43
    .line 44
    move-object/from16 v18, v6

    .line 45
    .line 46
    move-object/from16 v19, v6

    .line 47
    .line 48
    move-object/from16 v20, v6

    .line 49
    .line 50
    move-object/from16 v21, v6

    .line 51
    .line 52
    move-object/from16 v22, v6

    .line 53
    .line 54
    move-object/from16 v23, v6

    .line 55
    .line 56
    move-object/from16 v24, v6

    .line 57
    .line 58
    move-object/from16 v26, v6

    .line 59
    .line 60
    move/from16 v27, v25

    .line 61
    .line 62
    move/from16 v28, v25

    .line 63
    .line 64
    move-object/from16 v29, v6

    .line 65
    .line 66
    move-object/from16 v30, v6

    .line 67
    .line 68
    move-object/from16 v31, v6

    .line 69
    .line 70
    move-object/from16 v32, v6

    .line 71
    .line 72
    move-object/from16 v33, v6

    .line 73
    .line 74
    move-object/from16 v34, v6

    .line 75
    .line 76
    move-object/from16 v36, v6

    .line 77
    .line 78
    invoke-static/range {v5 .. v36}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 79
    .line 80
    .line 81
    move-result-object v26

    .line 82
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->unsupportedBrandError(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 89
    .line 90
    .line 91
    move-result-object v34

    .line 92
    const v56, 0x1fffff7f

    .line 93
    .line 94
    .line 95
    move-object/from16 v27, v6

    .line 96
    .line 97
    move-object/from16 v28, v6

    .line 98
    .line 99
    move-object/from16 v35, v6

    .line 100
    .line 101
    move-object/from16 v37, v6

    .line 102
    .line 103
    move-object/from16 v38, v6

    .line 104
    .line 105
    move-object/from16 v39, v6

    .line 106
    .line 107
    move-object/from16 v40, v6

    .line 108
    .line 109
    move-object/from16 v41, v6

    .line 110
    .line 111
    move-object/from16 v42, v6

    .line 112
    .line 113
    move-object/from16 v43, v6

    .line 114
    .line 115
    move-object/from16 v44, v6

    .line 116
    .line 117
    move-object/from16 v45, v6

    .line 118
    .line 119
    move/from16 v46, v25

    .line 120
    .line 121
    move-object/from16 v47, v6

    .line 122
    .line 123
    move/from16 v48, v25

    .line 124
    .line 125
    move/from16 v49, v25

    .line 126
    .line 127
    move-object/from16 v50, v6

    .line 128
    .line 129
    move-object/from16 v51, v6

    .line 130
    .line 131
    move-object/from16 v52, v6

    .line 132
    .line 133
    move-object/from16 v53, v6

    .line 134
    .line 135
    move-object/from16 v54, v6

    .line 136
    .line 137
    move-object/from16 v55, v6

    .line 138
    .line 139
    move-object/from16 p0, v6

    .line 140
    .line 141
    invoke-static/range {v26 .. v57}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-direct {v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-interface {v1, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    if-eqz v0, :cond_0

    .line 154
    .line 155
    return-void
.end method

.method private final awaitCheckoutSession(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v3, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->label:I

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v3, :cond_1

    .line 27
    .line 28
    if-eq v3, v1, :cond_2

    .line 29
    .line 30
    if-ne v3, v2, :cond_6

    .line 31
    .line 32
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-object v0

    .line 36
    :cond_1
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->sessionDeferred:LX/EQR;

    .line 40
    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    iput v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->label:I

    .line 44
    .line 45
    invoke-static {v0, v5}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-ne v0, v4, :cond_3

    .line 50
    .line 51
    return-object v4

    .line 52
    :cond_2
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    :cond_3
    if-eqz v0, :cond_4

    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_4
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->startCheckout()V

    .line 59
    .line 60
    .line 61
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->sessionDeferred:LX/EQR;

    .line 62
    .line 63
    if-eqz v0, :cond_7

    .line 64
    .line 65
    iput v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;->label:I

    .line 66
    .line 67
    invoke-static {v0, v5}, LX/3Rp;->A0v(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    if-ne v0, v4, :cond_0

    .line 72
    .line 73
    return-object v4

    .line 74
    :cond_5
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;

    .line 75
    .line 76
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$awaitCheckoutSession$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 77
    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    throw v0

    .line 85
    :cond_7
    const/4 v0, 0x0

    .line 86
    return-object v0
.end method

.method private final clearCardFields()V
    .locals 34

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object v3, v1

    .line 9
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    sget-object v8, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->UNKNOWN:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 12
    .line 13
    const v33, 0x1fdfffea

    .line 14
    .line 15
    .line 16
    const/4 v5, 0x0

    .line 17
    const-string v4, ""

    .line 18
    .line 19
    const/16 v23, 0x0

    .line 20
    .line 21
    move-object v6, v4

    .line 22
    move-object v7, v5

    .line 23
    move-object v9, v5

    .line 24
    move-object v10, v5

    .line 25
    move-object v11, v5

    .line 26
    move-object v12, v5

    .line 27
    move-object v13, v5

    .line 28
    move-object v14, v5

    .line 29
    move-object v15, v5

    .line 30
    move-object/from16 v16, v5

    .line 31
    .line 32
    move-object/from16 v17, v5

    .line 33
    .line 34
    move-object/from16 v18, v5

    .line 35
    .line 36
    move-object/from16 v19, v5

    .line 37
    .line 38
    move-object/from16 v20, v5

    .line 39
    .line 40
    move-object/from16 v21, v5

    .line 41
    .line 42
    move-object/from16 v22, v5

    .line 43
    .line 44
    move-object/from16 v24, v5

    .line 45
    .line 46
    move/from16 v25, v23

    .line 47
    .line 48
    move/from16 v26, v23

    .line 49
    .line 50
    move-object/from16 v27, v5

    .line 51
    .line 52
    move-object/from16 v28, v5

    .line 53
    .line 54
    move-object/from16 v29, v5

    .line 55
    .line 56
    move-object/from16 v30, v5

    .line 57
    .line 58
    move-object/from16 v31, v5

    .line 59
    .line 60
    move-object/from16 v32, v5

    .line 61
    .line 62
    move-object/from16 p0, v5

    .line 63
    .line 64
    invoke-static/range {v3 .. v34}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_0

    .line 73
    .line 74
    return-void
.end method

.method private final completeCheckout(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V
    .locals 35

    .line 0
    move-object/from16 v3, p0

    .line 1
    .line 2
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object v4, v1

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    const v34, 0x1fbfffff

    .line 12
    .line 13
    .line 14
    const/4 v5, 0x0

    .line 15
    const/16 v24, 0x0

    .line 16
    .line 17
    move-object v6, v5

    .line 18
    move-object v7, v5

    .line 19
    move-object v8, v5

    .line 20
    move-object v9, v5

    .line 21
    move-object v10, v5

    .line 22
    move-object v11, v5

    .line 23
    move-object v12, v5

    .line 24
    move-object v13, v5

    .line 25
    move-object v14, v5

    .line 26
    move-object v15, v5

    .line 27
    move-object/from16 v16, v5

    .line 28
    .line 29
    move-object/from16 v17, v5

    .line 30
    .line 31
    move-object/from16 v18, v5

    .line 32
    .line 33
    move-object/from16 v19, v5

    .line 34
    .line 35
    move-object/from16 v20, v5

    .line 36
    .line 37
    move-object/from16 v21, v5

    .line 38
    .line 39
    move-object/from16 v22, v5

    .line 40
    .line 41
    move-object/from16 v23, v5

    .line 42
    .line 43
    move-object/from16 v25, v5

    .line 44
    .line 45
    move/from16 v26, v24

    .line 46
    .line 47
    move/from16 v27, v24

    .line 48
    .line 49
    move-object/from16 v28, v5

    .line 50
    .line 51
    move-object/from16 v29, v5

    .line 52
    .line 53
    move-object/from16 v30, v5

    .line 54
    .line 55
    move-object/from16 v31, v5

    .line 56
    .line 57
    move-object/from16 v32, v5

    .line 58
    .line 59
    move-object/from16 v33, v5

    .line 60
    .line 61
    move-object/from16 p0, v5

    .line 62
    .line 63
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_0

    .line 72
    .line 73
    invoke-direct {v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->clearCardFields()V

    .line 74
    .line 75
    .line 76
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_verified:LX/EYl;

    .line 77
    .line 78
    move-object/from16 v1, p1

    .line 79
    .line 80
    invoke-interface {v0, v1}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method private final fetchLinkingOptionsAndStartCheckout()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$fetchLinkingOptionsAndStartCheckout$1;

    .line 10
    .line 11
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$fetchLinkingOptionsAndStartCheckout$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final finishThreeDSChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;)V
    .locals 8

    .line 0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 1
    .line 2
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;->charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 3
    .line 4
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 9
    .line 10
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v2, p2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logThreeDSStepUpOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    const/4 v3, 0x0

    .line 18
    const/4 v6, 0x3

    .line 19
    const/4 v5, 0x1

    .line 20
    const/4 v4, 0x0

    .line 21
    const/4 v2, 0x4

    .line 22
    const/4 v1, 0x2

    .line 23
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v7, :cond_3

    .line 28
    .line 29
    if-eq v0, v1, :cond_1

    .line 30
    .line 31
    if-eq v0, v2, :cond_1

    .line 32
    .line 33
    if-eq v0, v4, :cond_2

    .line 34
    .line 35
    if-eq v0, v5, :cond_2

    .line 36
    .line 37
    if-eq v0, v6, :cond_2

    .line 38
    .line 39
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 40
    .line 41
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :cond_1
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 46
    .line 47
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;->stepUp:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 48
    .line 49
    :cond_2
    invoke-direct {p0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->completeCheckout(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_3
    if-eq v0, v1, :cond_5

    .line 54
    .line 55
    if-eq v0, v2, :cond_5

    .line 56
    .line 57
    if-eq v0, v4, :cond_4

    .line 58
    .line 59
    if-eq v0, v5, :cond_4

    .line 60
    .line 61
    if-eq v0, v6, :cond_5

    .line 62
    .line 63
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 64
    .line 65
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 66
    .line 67
    .line 68
    throw v0

    .line 69
    :cond_4
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;

    .line 78
    .line 79
    invoke-direct {v0, p0, v7, p1, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$finishThreeDSChallenge$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;LX/2M4;)V

    .line 80
    .line 81
    .line 82
    invoke-static {v1, v0, v2}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :cond_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->THREE_DS_STEP_UP:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 87
    .line 88
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 89
    .line 90
    invoke-direct {v2, v0, v3, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 94
    .line 95
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 96
    .line 97
    invoke-direct {p0, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    return-void
.end method

.method private final logAgeCheck(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    :cond_0
    return-void
.end method

.method private final logCardFailure(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;)V
    .locals 4

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 10
    .line 11
    .line 12
    throw v0

    .line 13
    :pswitch_0
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 14
    .line 15
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->CARD_DECLINED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :pswitch_1
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 19
    .line 20
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->THREE_DS_FAILED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :pswitch_2
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 24
    .line 25
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->CHECKOUT_UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :pswitch_3
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 29
    .line 30
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->CHECKOUT_SERVER_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 31
    .line 32
    :goto_0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 37
    .line 38
    sget-object v1, Lcom/facebook/aura/user/provider/AgeCheckMethod;->CREDIT_CARD:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 39
    .line 40
    const/4 p0, 0x0

    .line 41
    move-object p1, p2

    .line 42
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    :cond_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_3
        :pswitch_3
        :pswitch_0
        :pswitch_3
        :pswitch_1
    .end packed-switch
.end method

.method private final logCcv(LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 5
    .line 6
    invoke-interface {p1, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
.end method

.method private final onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V
    .locals 34

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Success;

    .line 3
    .line 4
    move-object/from16 v3, p0

    .line 5
    .line 6
    move-object/from16 v9, p2

    .line 7
    .line 8
    if-nez v0, :cond_6

    .line 9
    .line 10
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Pending;

    .line 11
    .line 12
    if-nez v0, :cond_7

    .line 13
    .line 14
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 19
    .line 20
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 21
    .line 22
    invoke-direct {v3, v0, v9}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->logCardFailure(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    iget-object v5, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 26
    .line 27
    :cond_0
    invoke-interface {v5}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    move-object v6, v3

    .line 32
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 33
    .line 34
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 35
    .line 36
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;->serverTitle:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;->serverMessage:Ljava/lang/String;

    .line 39
    .line 40
    const p2, 0x18bfffff

    .line 41
    .line 42
    .line 43
    const/4 v7, 0x0

    .line 44
    const/16 v26, 0x0

    .line 45
    .line 46
    move-object v8, v7

    .line 47
    move-object v9, v7

    .line 48
    move-object v10, v7

    .line 49
    move-object v11, v7

    .line 50
    move-object v12, v7

    .line 51
    move-object v13, v7

    .line 52
    move-object v14, v7

    .line 53
    move-object v15, v7

    .line 54
    move-object/from16 v16, v7

    .line 55
    .line 56
    move-object/from16 v17, v7

    .line 57
    .line 58
    move-object/from16 v18, v7

    .line 59
    .line 60
    move-object/from16 v19, v7

    .line 61
    .line 62
    move-object/from16 v20, v7

    .line 63
    .line 64
    move-object/from16 v21, v7

    .line 65
    .line 66
    move-object/from16 v22, v7

    .line 67
    .line 68
    move-object/from16 v23, v7

    .line 69
    .line 70
    move-object/from16 v24, v7

    .line 71
    .line 72
    move-object/from16 v25, v7

    .line 73
    .line 74
    move-object/from16 v27, v7

    .line 75
    .line 76
    move/from16 v28, v26

    .line 77
    .line 78
    move/from16 v29, v26

    .line 79
    .line 80
    move-object/from16 v30, v7

    .line 81
    .line 82
    move-object/from16 v31, v2

    .line 83
    .line 84
    move-object/from16 v32, v1

    .line 85
    .line 86
    move-object/from16 v33, v0

    .line 87
    .line 88
    move-object/from16 p0, v7

    .line 89
    .line 90
    move-object/from16 p1, v7

    .line 91
    .line 92
    move-object/from16 p3, v7

    .line 93
    .line 94
    invoke-static/range {v6 .. v37}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    invoke-interface {v5, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_0

    .line 103
    .line 104
    return-void

    .line 105
    :cond_1
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 106
    .line 107
    move-object/from16 v5, p3

    .line 108
    .line 109
    if-eqz v0, :cond_2

    .line 110
    .line 111
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 112
    .line 113
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 114
    .line 115
    invoke-direct {v0, v4, v9, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;Ljava/lang/String;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-direct {v3, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->startThreeDSChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;)V

    .line 119
    .line 120
    .line 121
    return-void

    .line 122
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$InvalidThreeDSStepUp;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$InvalidThreeDSStepUp;

    .line 123
    .line 124
    invoke-static {v4, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_5

    .line 129
    .line 130
    iget-boolean v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 131
    .line 132
    if-eqz v0, :cond_3

    .line 133
    .line 134
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 135
    .line 136
    invoke-virtual {v0, v9, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logThreeDSStepUpAttempt(Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    :cond_3
    iget-boolean v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 140
    .line 141
    if-eqz v0, :cond_4

    .line 142
    .line 143
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 144
    .line 145
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;->INVALID_URL:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;

    .line 146
    .line 147
    invoke-virtual {v1, v0, v9, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logThreeDSStepUpOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    :cond_4
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->THREE_DS_STEP_UP:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 151
    .line 152
    const/4 v1, 0x0

    .line 153
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 154
    .line 155
    invoke-direct {v0, v2, v1, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    invoke-direct {v3, v0, v9, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->onCheckoutResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    return-void

    .line 162
    :cond_5
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 163
    .line 164
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 165
    .line 166
    .line 167
    throw v0

    .line 168
    :cond_6
    iget-boolean v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 169
    .line 170
    if-eqz v0, :cond_7

    .line 171
    .line 172
    sget-object v4, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 173
    .line 174
    sget-object v5, Lcom/facebook/aura/user/provider/AgeCheckMethod;->CREDIT_CARD:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 175
    .line 176
    sget-object v6, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->VERIFIED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 177
    .line 178
    const/4 v7, 0x0

    .line 179
    move-object v8, v7

    .line 180
    invoke-virtual/range {v4 .. v9}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    :cond_7
    const/4 v0, 0x0

    .line 184
    invoke-direct {v3, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->completeCheckout(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;)V

    .line 185
    .line 186
    .line 187
    return-void
.end method

.method private final readLinkingOptions(LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v6, p1

    .line 5
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x2

    .line 25
    const/4 v3, 0x0

    .line 26
    const/4 v2, 0x1

    .line 27
    if-eqz v1, :cond_3

    .line 28
    .line 29
    if-eq v1, v2, :cond_2

    .line 30
    .line 31
    if-ne v1, v4, :cond_1

    .line 32
    .line 33
    iget-object v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->L$0:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, LX/3Hh;

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_0
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;

    .line 39
    .line 40
    invoke-direct {v6, p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0

    .line 49
    :cond_2
    iget-object v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->L$0:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v1, LX/3Hh;

    .line 52
    .line 53
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_3
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->linkingOptionsMutex:LX/3Hh;

    .line 61
    .line 62
    iput-object v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->L$0:Ljava/lang/Object;

    .line 63
    .line 64
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->label:I

    .line 65
    .line 66
    invoke-interface {v1, v3, v6}, LX/3Hh;->AQ2(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    if-ne v0, v5, :cond_4

    .line 71
    .line 72
    return-object v5

    .line 73
    :cond_4
    :goto_1
    :try_start_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;

    .line 74
    .line 75
    iput-object v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->L$0:Ljava/lang/Object;

    .line 76
    .line 77
    iput v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$readLinkingOptions$1;->label:I

    .line 78
    .line 79
    invoke-virtual {v0, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->fetchLinkingOptions(LX/2M4;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-ne v0, v5, :cond_5

    .line 84
    .line 85
    return-object v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 86
    :goto_2
    :try_start_1
    invoke-static {v0}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :cond_5
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 90
    .line 91
    if-nez v0, :cond_6

    .line 92
    .line 93
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 94
    .line 95
    invoke-interface {v1, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    return-object v0

    .line 99
    :cond_6
    :try_start_2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->applyOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;)V

    .line 100
    .line 101
    .line 102
    iput-boolean v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->hasLinkingOptions:Z

    .line 103
    .line 104
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 105
    .line 106
    invoke-interface {v1, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    return-object v0

    .line 110
    :catchall_0
    move-exception v0

    .line 111
    goto :goto_3

    .line 112
    :catchall_1
    move-exception v0

    .line 113
    :goto_3
    invoke-interface {v1, v3}, LX/3Hh;->Ai9(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    throw v0
.end method

.method private final startCheckout()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v0, 0x0

    .line 9
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;

    .line 10
    .line 11
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$startCheckout$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 15
    .line 16
    invoke-static {v0, v2, v1, v3}, LX/DRD;->A01(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ERe;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->sessionDeferred:LX/EQR;

    .line 21
    .line 22
    return-void
.end method

.method private final startThreeDSChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;)V
    .locals 34

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->stepUpRequired:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 3
    .line 4
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;->stepUp:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 5
    .line 6
    move-object/from16 v5, p0

    .line 7
    .line 8
    iget-boolean v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 13
    .line 14
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logThreeDSStepUpAttempt(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->pendingThreeDSChallenge:Ljava/util/concurrent/atomic/AtomicReference;

    .line 22
    .line 23
    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    iget-object v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 27
    .line 28
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    move-object v4, v1

    .line 33
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 34
    .line 35
    const p0, 0xfffffff

    .line 36
    .line 37
    .line 38
    const/4 v5, 0x0

    .line 39
    const/16 v24, 0x0

    .line 40
    .line 41
    move-object v6, v5

    .line 42
    move-object v7, v5

    .line 43
    move-object v8, v5

    .line 44
    move-object v9, v5

    .line 45
    move-object v10, v5

    .line 46
    move-object v11, v5

    .line 47
    move-object v12, v5

    .line 48
    move-object v13, v5

    .line 49
    move-object v14, v5

    .line 50
    move-object v15, v5

    .line 51
    move-object/from16 v16, v5

    .line 52
    .line 53
    move-object/from16 v17, v5

    .line 54
    .line 55
    move-object/from16 v18, v5

    .line 56
    .line 57
    move-object/from16 v19, v5

    .line 58
    .line 59
    move-object/from16 v20, v5

    .line 60
    .line 61
    move-object/from16 v21, v5

    .line 62
    .line 63
    move-object/from16 v22, v5

    .line 64
    .line 65
    move-object/from16 v23, v5

    .line 66
    .line 67
    move-object/from16 v25, v5

    .line 68
    .line 69
    move/from16 v26, v24

    .line 70
    .line 71
    move/from16 v27, v24

    .line 72
    .line 73
    move-object/from16 v28, v5

    .line 74
    .line 75
    move-object/from16 v29, v5

    .line 76
    .line 77
    move-object/from16 v30, v5

    .line 78
    .line 79
    move-object/from16 v31, v5

    .line 80
    .line 81
    move-object/from16 v32, v5

    .line 82
    .line 83
    move-object/from16 v33, v3

    .line 84
    .line 85
    move-object/from16 p1, v5

    .line 86
    .line 87
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_1

    .line 96
    .line 97
    return-void
.end method

.method private final submitCard()V
    .locals 37

    .line 0
    move-object/from16 v5, p0

    .line 1
    .line 2
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v4

    .line 8
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 9
    .line 10
    iget-boolean v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;

    .line 15
    .line 16
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->expirationToWireParts(Ljava/lang/String;)LX/IBK;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    if-eqz v3, :cond_1

    .line 23
    .line 24
    iget-object v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 25
    .line 26
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    move-object v6, v1

    .line 31
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 32
    .line 33
    const v36, 0x18bfffff

    .line 34
    .line 35
    .line 36
    const/4 v7, 0x0

    .line 37
    const/16 v26, 0x0

    .line 38
    .line 39
    const/16 v29, 0x1

    .line 40
    .line 41
    move-object v8, v7

    .line 42
    move-object v9, v7

    .line 43
    move-object v10, v7

    .line 44
    move-object v11, v7

    .line 45
    move-object v12, v7

    .line 46
    move-object v13, v7

    .line 47
    move-object v14, v7

    .line 48
    move-object v15, v7

    .line 49
    move-object/from16 v16, v7

    .line 50
    .line 51
    move-object/from16 v17, v7

    .line 52
    .line 53
    move-object/from16 v18, v7

    .line 54
    .line 55
    move-object/from16 v19, v7

    .line 56
    .line 57
    move-object/from16 v20, v7

    .line 58
    .line 59
    move-object/from16 v21, v7

    .line 60
    .line 61
    move-object/from16 v22, v7

    .line 62
    .line 63
    move-object/from16 v23, v7

    .line 64
    .line 65
    move-object/from16 v24, v7

    .line 66
    .line 67
    move-object/from16 v25, v7

    .line 68
    .line 69
    move-object/from16 v27, v7

    .line 70
    .line 71
    move/from16 v28, v26

    .line 72
    .line 73
    move-object/from16 v30, v7

    .line 74
    .line 75
    move-object/from16 v31, v7

    .line 76
    .line 77
    move-object/from16 v32, v7

    .line 78
    .line 79
    move-object/from16 v33, v7

    .line 80
    .line 81
    move-object/from16 v34, v7

    .line 82
    .line 83
    move-object/from16 v35, v7

    .line 84
    .line 85
    move-object/from16 p0, v7

    .line 86
    .line 87
    invoke-static/range {v6 .. v37}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_0

    .line 96
    .line 97
    invoke-static {v5}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$submitCard$2;

    .line 106
    .line 107
    invoke-direct {v0, v5, v4, v3, v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$submitCard$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/IBK;LX/2M4;)V

    .line 108
    .line 109
    .line 110
    invoke-static {v1, v0, v2}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 111
    .line 112
    .line 113
    :cond_1
    return-void
.end method

.method private final withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;
    .locals 30

    .line 0
    move-object/from16 v0, p1

    .line 1
    .line 2
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 11
    .line 12
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 13
    .line 14
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->isCardFormComplete(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/util/List;)Z

    .line 15
    .line 16
    .line 17
    move-result v22

    .line 18
    const p0, 0x1fdfffff

    .line 19
    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    const/16 v20, 0x0

    .line 23
    .line 24
    move-object v2, v1

    .line 25
    move-object v3, v1

    .line 26
    move-object v4, v1

    .line 27
    move-object v5, v1

    .line 28
    move-object v6, v1

    .line 29
    move-object v7, v1

    .line 30
    move-object v8, v1

    .line 31
    move-object v9, v1

    .line 32
    move-object v10, v1

    .line 33
    move-object v11, v1

    .line 34
    move-object v12, v1

    .line 35
    move-object v13, v1

    .line 36
    move-object v14, v1

    .line 37
    move-object v15, v1

    .line 38
    move-object/from16 v16, v1

    .line 39
    .line 40
    move-object/from16 v17, v1

    .line 41
    .line 42
    move-object/from16 v18, v1

    .line 43
    .line 44
    move-object/from16 v19, v1

    .line 45
    .line 46
    move-object/from16 v21, v1

    .line 47
    .line 48
    move/from16 v23, v20

    .line 49
    .line 50
    move-object/from16 v24, v1

    .line 51
    .line 52
    move-object/from16 v25, v1

    .line 53
    .line 54
    move-object/from16 v26, v1

    .line 55
    .line 56
    move-object/from16 v27, v1

    .line 57
    .line 58
    move-object/from16 v28, v1

    .line 59
    .line 60
    move-object/from16 v29, v1

    .line 61
    .line 62
    move-object/from16 p1, v1

    .line 63
    .line 64
    invoke-static/range {v0 .. v31}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    return-object v0
.end method


# virtual methods
.method public final canStartLinking()Z
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {p0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 7
    .line 8
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 9
    .line 10
    xor-int/lit8 p0, p0, 0x1

    .line 11
    .line 12
    return p0
.end method

.method public final fetchLinkingOptions()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v1, 0x0

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$fetchLinkingOptions$1;

    .line 10
    .line 11
    invoke-direct {v0, p0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel$fetchLinkingOptions$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v0, v3}, LX/3Rp;->A1N(LX/BqD;LX/JDN;LX/1EL;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final getCheckoutUnavailable()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->checkoutUnavailable:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVerified()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->verified:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getViewEffect()LX/2QV;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2QV<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->viewEffect:LX/2QV;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onBillingCountrySelected(Ljava/lang/String;)V
    .locals 39

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    invoke-static {v6, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v7, p0

    .line 7
    .line 8
    iget-boolean v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 13
    .line 14
    invoke-virtual {v0, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logCountrySelected(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object v4, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 18
    .line 19
    :cond_1
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    move-object v9, v3

    .line 24
    check-cast v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 25
    .line 26
    iget-object v0, v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_4

    .line 33
    .line 34
    iget-object v0, v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 35
    .line 36
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v8

    .line 40
    :cond_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    const/4 v0, 0x0

    .line 45
    if-eqz v1, :cond_5

    .line 46
    .line 47
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    move-object v1, v2

    .line 52
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 53
    .line 54
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    :goto_0
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 63
    .line 64
    if-eqz v2, :cond_3

    .line 65
    .line 66
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 67
    .line 68
    :cond_3
    const p0, 0x1fedf3f7

    .line 69
    .line 70
    .line 71
    const/4 v10, 0x0

    .line 72
    const-string v13, ""

    .line 73
    .line 74
    move-object v11, v10

    .line 75
    move-object v12, v10

    .line 76
    move-object v14, v10

    .line 77
    move-object v15, v10

    .line 78
    move-object/from16 v16, v10

    .line 79
    .line 80
    move-object/from16 v17, v10

    .line 81
    .line 82
    move-object/from16 v18, v10

    .line 83
    .line 84
    move-object/from16 v19, v10

    .line 85
    .line 86
    move-object/from16 v20, v10

    .line 87
    .line 88
    move-object/from16 v21, v10

    .line 89
    .line 90
    move-object/from16 v22, v10

    .line 91
    .line 92
    move-object/from16 v23, v10

    .line 93
    .line 94
    move-object/from16 v24, v10

    .line 95
    .line 96
    move-object/from16 v25, v10

    .line 97
    .line 98
    move-object/from16 v26, v10

    .line 99
    .line 100
    move-object/from16 v27, v6

    .line 101
    .line 102
    move-object/from16 v28, v10

    .line 103
    .line 104
    move/from16 v29, v5

    .line 105
    .line 106
    move-object/from16 v30, v0

    .line 107
    .line 108
    move/from16 v31, v5

    .line 109
    .line 110
    move/from16 v32, v5

    .line 111
    .line 112
    move-object/from16 v33, v10

    .line 113
    .line 114
    move-object/from16 v34, v10

    .line 115
    .line 116
    move-object/from16 v35, v10

    .line 117
    .line 118
    move-object/from16 v36, v10

    .line 119
    .line 120
    move-object/from16 v37, v10

    .line 121
    .line 122
    move-object/from16 v38, v10

    .line 123
    .line 124
    move-object/from16 p1, v10

    .line 125
    .line 126
    invoke-static/range {v9 .. v40}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-direct {v7, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 131
    .line 132
    .line 133
    move-result-object v9

    .line 134
    :cond_4
    invoke-interface {v4, v3, v9}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_1

    .line 139
    .line 140
    return-void

    .line 141
    :cond_5
    move-object v2, v0

    .line 142
    goto :goto_0
.end method

.method public final onCancel()V
    .locals 1

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->onLeave()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_viewEffect:LX/5Lx;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$Cancelled;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewEffect$Cancelled;

    .line 9
    .line 10
    invoke-interface {p0, v0}, LX/5Lx;->Ahz(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method

.method public final onCardNumberBlur()V
    .locals 35

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    move-object v4, v2

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 14
    .line 15
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePan(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;->nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 20
    .line 21
    .line 22
    move-result-object v12

    .line 23
    const v34, 0x1fffff7f

    .line 24
    .line 25
    .line 26
    const/4 v5, 0x0

    .line 27
    const/16 v24, 0x0

    .line 28
    .line 29
    move-object v6, v5

    .line 30
    move-object v7, v5

    .line 31
    move-object v8, v5

    .line 32
    move-object v9, v5

    .line 33
    move-object v10, v5

    .line 34
    move-object v11, v5

    .line 35
    move-object v13, v5

    .line 36
    move-object v14, v5

    .line 37
    move-object v15, v5

    .line 38
    move-object/from16 v16, v5

    .line 39
    .line 40
    move-object/from16 v17, v5

    .line 41
    .line 42
    move-object/from16 v18, v5

    .line 43
    .line 44
    move-object/from16 v19, v5

    .line 45
    .line 46
    move-object/from16 v20, v5

    .line 47
    .line 48
    move-object/from16 v21, v5

    .line 49
    .line 50
    move-object/from16 v22, v5

    .line 51
    .line 52
    move-object/from16 v23, v5

    .line 53
    .line 54
    move-object/from16 v25, v5

    .line 55
    .line 56
    move/from16 v26, v24

    .line 57
    .line 58
    move/from16 v27, v24

    .line 59
    .line 60
    move-object/from16 v28, v5

    .line 61
    .line 62
    move-object/from16 v29, v5

    .line 63
    .line 64
    move-object/from16 v30, v5

    .line 65
    .line 66
    move-object/from16 v31, v5

    .line 67
    .line 68
    move-object/from16 v32, v5

    .line 69
    .line 70
    move-object/from16 v33, v5

    .line 71
    .line 72
    move-object/from16 p0, v5

    .line 73
    .line 74
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_0

    .line 83
    .line 84
    return-void
.end method

.method public final onCardNumberChange(Ljava/lang/String;)V
    .locals 37

    .line 0
    const/4 v3, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;

    .line 7
    .line 8
    invoke-virtual {v2, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->number(Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v8

    .line 12
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->Companion:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;

    .line 13
    .line 14
    invoke-static {v8}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v1, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;->forDigits(Ljava/lang/String;)Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 19
    .line 20
    .line 21
    move-result-object v12

    .line 22
    move-object/from16 v4, p0

    .line 23
    .line 24
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 25
    .line 26
    :cond_0
    invoke-interface {v1}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    move-object v7, v5

    .line 31
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 32
    .line 33
    invoke-static {v8}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v6

    .line 37
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 38
    .line 39
    invoke-static {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->unsupportedBrandError(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 40
    .line 41
    .line 42
    move-result-object v15

    .line 43
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 44
    .line 45
    invoke-virtual {v2, v0, v8}, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->securityCode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v10

    .line 49
    const p0, 0x18fffd6a

    .line 50
    .line 51
    .line 52
    const/4 v9, 0x0

    .line 53
    move-object v11, v9

    .line 54
    move-object v13, v9

    .line 55
    move-object v14, v9

    .line 56
    move-object/from16 v16, v9

    .line 57
    .line 58
    move-object/from16 v17, v9

    .line 59
    .line 60
    move-object/from16 v18, v9

    .line 61
    .line 62
    move-object/from16 v19, v9

    .line 63
    .line 64
    move-object/from16 v20, v9

    .line 65
    .line 66
    move-object/from16 v21, v9

    .line 67
    .line 68
    move-object/from16 v22, v9

    .line 69
    .line 70
    move-object/from16 v23, v9

    .line 71
    .line 72
    move-object/from16 v24, v9

    .line 73
    .line 74
    move-object/from16 v25, v9

    .line 75
    .line 76
    move-object/from16 v26, v9

    .line 77
    .line 78
    move/from16 v27, v3

    .line 79
    .line 80
    move-object/from16 v28, v9

    .line 81
    .line 82
    move/from16 v29, v3

    .line 83
    .line 84
    move/from16 v30, v3

    .line 85
    .line 86
    move-object/from16 v31, v9

    .line 87
    .line 88
    move-object/from16 v32, v9

    .line 89
    .line 90
    move-object/from16 v33, v9

    .line 91
    .line 92
    move-object/from16 v34, v9

    .line 93
    .line 94
    move-object/from16 v35, v9

    .line 95
    .line 96
    move-object/from16 v36, v9

    .line 97
    .line 98
    move-object/from16 p1, v9

    .line 99
    .line 100
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    invoke-direct {v4, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-interface {v1, v5, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    if-eqz v0, :cond_0

    .line 113
    .line 114
    return-void
.end method

.method public onCleared()V
    .locals 36

    .line 0
    move-object/from16 v5, p0

    .line 1
    .line 2
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->pendingThreeDSChallenge:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v4

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 10
    .line 11
    if-eqz v4, :cond_0

    .line 12
    .line 13
    iget-boolean v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 18
    .line 19
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;->NOT_PRESENTED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;

    .line 20
    .line 21
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->uplSessionId:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;->billingCountry:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v3, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logThreeDSStepUpOutcome(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;Ljava/lang/String;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 29
    .line 30
    const v35, 0x1fffffff

    .line 31
    .line 32
    .line 33
    const/16 v25, 0x0

    .line 34
    .line 35
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 36
    .line 37
    move-object v7, v6

    .line 38
    move-object v8, v6

    .line 39
    move-object v9, v6

    .line 40
    move-object v10, v6

    .line 41
    move-object v11, v6

    .line 42
    move-object v12, v6

    .line 43
    move-object v13, v6

    .line 44
    move-object v14, v6

    .line 45
    move-object v15, v6

    .line 46
    move-object/from16 v16, v6

    .line 47
    .line 48
    move-object/from16 v17, v6

    .line 49
    .line 50
    move-object/from16 v18, v6

    .line 51
    .line 52
    move-object/from16 v19, v6

    .line 53
    .line 54
    move-object/from16 v20, v6

    .line 55
    .line 56
    move-object/from16 v21, v6

    .line 57
    .line 58
    move-object/from16 v22, v6

    .line 59
    .line 60
    move-object/from16 v23, v6

    .line 61
    .line 62
    move-object/from16 v24, v6

    .line 63
    .line 64
    move-object/from16 v26, v6

    .line 65
    .line 66
    move/from16 v27, v25

    .line 67
    .line 68
    move/from16 v28, v25

    .line 69
    .line 70
    move-object/from16 v29, v6

    .line 71
    .line 72
    move-object/from16 v30, v6

    .line 73
    .line 74
    move-object/from16 v31, v6

    .line 75
    .line 76
    move-object/from16 v32, v6

    .line 77
    .line 78
    move-object/from16 v33, v6

    .line 79
    .line 80
    move-object/from16 v34, v6

    .line 81
    .line 82
    move-object/from16 p0, v6

    .line 83
    .line 84
    invoke-direct/range {v5 .. v36}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILX/04f;)V

    .line 85
    .line 86
    .line 87
    invoke-static {v0, v6, v5}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    return-void
.end method

.method public final onExpiryBlur()V
    .locals 34

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object v3, v1

    .line 9
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateExpiry(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;->nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 18
    .line 19
    .line 20
    move-result-object v12

    .line 21
    const v33, 0x1ffffeff

    .line 22
    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    const/16 v23, 0x0

    .line 26
    .line 27
    move-object v5, v4

    .line 28
    move-object v6, v4

    .line 29
    move-object v7, v4

    .line 30
    move-object v8, v4

    .line 31
    move-object v9, v4

    .line 32
    move-object v10, v4

    .line 33
    move-object v11, v4

    .line 34
    move-object v13, v4

    .line 35
    move-object v14, v4

    .line 36
    move-object v15, v4

    .line 37
    move-object/from16 v16, v4

    .line 38
    .line 39
    move-object/from16 v17, v4

    .line 40
    .line 41
    move-object/from16 v18, v4

    .line 42
    .line 43
    move-object/from16 v19, v4

    .line 44
    .line 45
    move-object/from16 v20, v4

    .line 46
    .line 47
    move-object/from16 v21, v4

    .line 48
    .line 49
    move-object/from16 v22, v4

    .line 50
    .line 51
    move-object/from16 v24, v4

    .line 52
    .line 53
    move/from16 v25, v23

    .line 54
    .line 55
    move/from16 v26, v23

    .line 56
    .line 57
    move-object/from16 v27, v4

    .line 58
    .line 59
    move-object/from16 v28, v4

    .line 60
    .line 61
    move-object/from16 v29, v4

    .line 62
    .line 63
    move-object/from16 v30, v4

    .line 64
    .line 65
    move-object/from16 v31, v4

    .line 66
    .line 67
    move-object/from16 v32, v4

    .line 68
    .line 69
    move-object/from16 p0, v4

    .line 70
    .line 71
    invoke-static/range {v3 .. v34}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_0

    .line 80
    .line 81
    return-void
.end method

.method public final onExpiryChange(Ljava/lang/String;)V
    .locals 37

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v5, p1

    .line 2
    .line 3
    invoke-static {v5, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v6, p0

    .line 7
    .line 8
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    move-object v7, v2

    .line 15
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;

    .line 18
    .line 19
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->expiration(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v9

    .line 25
    const p0, 0x18fffefd

    .line 26
    .line 27
    .line 28
    const/4 v8, 0x0

    .line 29
    move-object v10, v8

    .line 30
    move-object v11, v8

    .line 31
    move-object v12, v8

    .line 32
    move-object v13, v8

    .line 33
    move-object v14, v8

    .line 34
    move-object v15, v8

    .line 35
    move-object/from16 v16, v8

    .line 36
    .line 37
    move-object/from16 v17, v8

    .line 38
    .line 39
    move-object/from16 v18, v8

    .line 40
    .line 41
    move-object/from16 v19, v8

    .line 42
    .line 43
    move-object/from16 v20, v8

    .line 44
    .line 45
    move-object/from16 v21, v8

    .line 46
    .line 47
    move-object/from16 v22, v8

    .line 48
    .line 49
    move-object/from16 v23, v8

    .line 50
    .line 51
    move-object/from16 v24, v8

    .line 52
    .line 53
    move-object/from16 v25, v8

    .line 54
    .line 55
    move-object/from16 v26, v8

    .line 56
    .line 57
    move/from16 v27, v4

    .line 58
    .line 59
    move-object/from16 v28, v8

    .line 60
    .line 61
    move/from16 v29, v4

    .line 62
    .line 63
    move/from16 v30, v4

    .line 64
    .line 65
    move-object/from16 v31, v8

    .line 66
    .line 67
    move-object/from16 v32, v8

    .line 68
    .line 69
    move-object/from16 v33, v8

    .line 70
    .line 71
    move-object/from16 v34, v8

    .line 72
    .line 73
    move-object/from16 v35, v8

    .line 74
    .line 75
    move-object/from16 v36, v8

    .line 76
    .line 77
    move-object/from16 p1, v8

    .line 78
    .line 79
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-direct {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_0

    .line 92
    .line 93
    return-void
.end method

.method public final onFormHidden()V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->CREDIT_CARD:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onLeave()Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 7
    .line 8
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    return v0

    .line 14
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->clearCardFields()V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    return v0
.end method

.method public final onRetryCheckout()V
    .locals 35

    .line 0
    move-object/from16 v3, p0

    .line 1
    .line 2
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 9
    .line 10
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->checkoutPhase:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 13
    .line 14
    if-ne v1, v0, :cond_1

    .line 15
    .line 16
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 17
    .line 18
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v4, v1

    .line 23
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 24
    .line 25
    sget-object v28, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;->LOADING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;

    .line 26
    .line 27
    const v34, 0x1f7fffff

    .line 28
    .line 29
    .line 30
    const/4 v5, 0x0

    .line 31
    const/16 v24, 0x0

    .line 32
    .line 33
    move-object v6, v5

    .line 34
    move-object v7, v5

    .line 35
    move-object v8, v5

    .line 36
    move-object v9, v5

    .line 37
    move-object v10, v5

    .line 38
    move-object v11, v5

    .line 39
    move-object v12, v5

    .line 40
    move-object v13, v5

    .line 41
    move-object v14, v5

    .line 42
    move-object v15, v5

    .line 43
    move-object/from16 v16, v5

    .line 44
    .line 45
    move-object/from16 v17, v5

    .line 46
    .line 47
    move-object/from16 v18, v5

    .line 48
    .line 49
    move-object/from16 v19, v5

    .line 50
    .line 51
    move-object/from16 v20, v5

    .line 52
    .line 53
    move-object/from16 v21, v5

    .line 54
    .line 55
    move-object/from16 v22, v5

    .line 56
    .line 57
    move-object/from16 v23, v5

    .line 58
    .line 59
    move-object/from16 v25, v5

    .line 60
    .line 61
    move/from16 v26, v24

    .line 62
    .line 63
    move/from16 v27, v24

    .line 64
    .line 65
    move-object/from16 v29, v5

    .line 66
    .line 67
    move-object/from16 v30, v5

    .line 68
    .line 69
    move-object/from16 v31, v5

    .line 70
    .line 71
    move-object/from16 v32, v5

    .line 72
    .line 73
    move-object/from16 v33, v5

    .line 74
    .line 75
    move-object/from16 p0, v5

    .line 76
    .line 77
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_0

    .line 86
    .line 87
    iput-object v5, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->sessionDeferred:LX/EQR;

    .line 88
    .line 89
    invoke-direct {v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->startCheckout()V

    .line 90
    .line 91
    .line 92
    :cond_1
    return-void
.end method

.method public final onSecurityCodeBlur()V
    .locals 35

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    move-object v4, v2

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    iget-object v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateSecurityCode(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;->nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 20
    .line 21
    .line 22
    move-result-object v14

    .line 23
    const v34, 0x1ffffdff

    .line 24
    .line 25
    .line 26
    const/4 v5, 0x0

    .line 27
    const/16 v24, 0x0

    .line 28
    .line 29
    move-object v6, v5

    .line 30
    move-object v7, v5

    .line 31
    move-object v8, v5

    .line 32
    move-object v9, v5

    .line 33
    move-object v10, v5

    .line 34
    move-object v11, v5

    .line 35
    move-object v12, v5

    .line 36
    move-object v13, v5

    .line 37
    move-object v15, v5

    .line 38
    move-object/from16 v16, v5

    .line 39
    .line 40
    move-object/from16 v17, v5

    .line 41
    .line 42
    move-object/from16 v18, v5

    .line 43
    .line 44
    move-object/from16 v19, v5

    .line 45
    .line 46
    move-object/from16 v20, v5

    .line 47
    .line 48
    move-object/from16 v21, v5

    .line 49
    .line 50
    move-object/from16 v22, v5

    .line 51
    .line 52
    move-object/from16 v23, v5

    .line 53
    .line 54
    move-object/from16 v25, v5

    .line 55
    .line 56
    move/from16 v26, v24

    .line 57
    .line 58
    move/from16 v27, v24

    .line 59
    .line 60
    move-object/from16 v28, v5

    .line 61
    .line 62
    move-object/from16 v29, v5

    .line 63
    .line 64
    move-object/from16 v30, v5

    .line 65
    .line 66
    move-object/from16 v31, v5

    .line 67
    .line 68
    move-object/from16 v32, v5

    .line 69
    .line 70
    move-object/from16 v33, v5

    .line 71
    .line 72
    move-object/from16 p0, v5

    .line 73
    .line 74
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_0

    .line 83
    .line 84
    return-void
.end method

.method public final onSecurityCodeChange(Ljava/lang/String;)V
    .locals 37

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v5, p1

    .line 2
    .line 3
    invoke-static {v5, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v6, p0

    .line 7
    .line 8
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    move-object v7, v2

    .line 15
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;

    .line 18
    .line 19
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v5, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardFieldFormat;->securityCode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v10

    .line 25
    const p0, 0x18fffdfb

    .line 26
    .line 27
    .line 28
    const/4 v8, 0x0

    .line 29
    move-object v9, v8

    .line 30
    move-object v11, v8

    .line 31
    move-object v12, v8

    .line 32
    move-object v13, v8

    .line 33
    move-object v14, v8

    .line 34
    move-object v15, v8

    .line 35
    move-object/from16 v16, v8

    .line 36
    .line 37
    move-object/from16 v17, v8

    .line 38
    .line 39
    move-object/from16 v18, v8

    .line 40
    .line 41
    move-object/from16 v19, v8

    .line 42
    .line 43
    move-object/from16 v20, v8

    .line 44
    .line 45
    move-object/from16 v21, v8

    .line 46
    .line 47
    move-object/from16 v22, v8

    .line 48
    .line 49
    move-object/from16 v23, v8

    .line 50
    .line 51
    move-object/from16 v24, v8

    .line 52
    .line 53
    move-object/from16 v25, v8

    .line 54
    .line 55
    move-object/from16 v26, v8

    .line 56
    .line 57
    move/from16 v27, v4

    .line 58
    .line 59
    move-object/from16 v28, v8

    .line 60
    .line 61
    move/from16 v29, v4

    .line 62
    .line 63
    move/from16 v30, v4

    .line 64
    .line 65
    move-object/from16 v31, v8

    .line 66
    .line 67
    move-object/from16 v32, v8

    .line 68
    .line 69
    move-object/from16 v33, v8

    .line 70
    .line 71
    move-object/from16 v34, v8

    .line 72
    .line 73
    move-object/from16 v35, v8

    .line 74
    .line 75
    move-object/from16 v36, v8

    .line 76
    .line 77
    move-object/from16 p1, v8

    .line 78
    .line 79
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-direct {v6, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-interface {v3, v2, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_0

    .line 92
    .line 93
    return-void
.end method

.method public final onSubmit()V
    .locals 35

    .line 0
    move-object/from16 v4, p0

    .line 1
    .line 2
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v5

    .line 8
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 9
    .line 10
    iget-boolean v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->supportedCardTypes:LX/Ddn;

    .line 17
    .line 18
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePan(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 19
    .line 20
    .line 21
    move-result-object v12

    .line 22
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateExpiry(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 25
    .line 26
    .line 27
    move-result-object v13

    .line 28
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 29
    .line 30
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validateSecurityCode(Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 33
    .line 34
    .line 35
    move-result-object v14

    .line 36
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 39
    .line 40
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePostalField(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;)LX/IBK;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iget-object v15, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 47
    .line 48
    iget-object v3, v0, LX/IBK;->second:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 51
    .line 52
    filled-new-array {v12, v13, v14, v15}, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_2

    .line 65
    .line 66
    if-nez v3, :cond_2

    .line 67
    .line 68
    iget-boolean v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 69
    .line 70
    if-eqz v0, :cond_0

    .line 71
    .line 72
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 73
    .line 74
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->CREDIT_CARD:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 75
    .line 76
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptStarted(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 77
    .line 78
    .line 79
    :cond_0
    invoke-direct {v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->submitCard()V

    .line 80
    .line 81
    .line 82
    :cond_1
    return-void

    .line 83
    :cond_2
    iget-boolean v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->isAgeConfirmation:Z

    .line 84
    .line 85
    if-eqz v0, :cond_3

    .line 86
    .line 87
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;

    .line 88
    .line 89
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {v1, v0, v2, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLogging;->logValidationRejected(Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;)V

    .line 92
    .line 93
    .line 94
    :cond_3
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 95
    .line 96
    :cond_4
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    move-object v4, v1

    .line 101
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 102
    .line 103
    if-eqz v3, :cond_5

    .line 104
    .line 105
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->errorMessage:Ljava/lang/String;

    .line 106
    .line 107
    :goto_0
    const v34, 0x1ffff07f

    .line 108
    .line 109
    .line 110
    const/4 v5, 0x0

    .line 111
    const/16 v24, 0x0

    .line 112
    .line 113
    move-object v6, v5

    .line 114
    move-object v7, v5

    .line 115
    move-object v8, v5

    .line 116
    move-object v9, v5

    .line 117
    move-object v10, v5

    .line 118
    move-object v11, v5

    .line 119
    move-object/from16 v16, v0

    .line 120
    .line 121
    move-object/from16 v17, v5

    .line 122
    .line 123
    move-object/from16 v18, v5

    .line 124
    .line 125
    move-object/from16 v19, v5

    .line 126
    .line 127
    move-object/from16 v20, v5

    .line 128
    .line 129
    move-object/from16 v21, v5

    .line 130
    .line 131
    move-object/from16 v22, v5

    .line 132
    .line 133
    move-object/from16 v23, v5

    .line 134
    .line 135
    move-object/from16 v25, v5

    .line 136
    .line 137
    move/from16 v26, v24

    .line 138
    .line 139
    move/from16 v27, v24

    .line 140
    .line 141
    move-object/from16 v28, v5

    .line 142
    .line 143
    move-object/from16 v29, v5

    .line 144
    .line 145
    move-object/from16 v30, v5

    .line 146
    .line 147
    move-object/from16 v31, v5

    .line 148
    .line 149
    move-object/from16 v32, v5

    .line 150
    .line 151
    move-object/from16 v33, v5

    .line 152
    .line 153
    move-object/from16 p0, v5

    .line 154
    .line 155
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_4

    .line 164
    .line 165
    return-void

    .line 166
    :cond_5
    const/4 v0, 0x0

    .line 167
    goto :goto_0
.end method

.method public final onSubmitErrorDismissed()V
    .locals 34

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object v3, v1

    .line 9
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    const v33, 0x18ffffff

    .line 12
    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    const/16 v23, 0x0

    .line 16
    .line 17
    move-object v5, v4

    .line 18
    move-object v6, v4

    .line 19
    move-object v7, v4

    .line 20
    move-object v8, v4

    .line 21
    move-object v9, v4

    .line 22
    move-object v10, v4

    .line 23
    move-object v11, v4

    .line 24
    move-object v12, v4

    .line 25
    move-object v13, v4

    .line 26
    move-object v14, v4

    .line 27
    move-object v15, v4

    .line 28
    move-object/from16 v16, v4

    .line 29
    .line 30
    move-object/from16 v17, v4

    .line 31
    .line 32
    move-object/from16 v18, v4

    .line 33
    .line 34
    move-object/from16 v19, v4

    .line 35
    .line 36
    move-object/from16 v20, v4

    .line 37
    .line 38
    move-object/from16 v21, v4

    .line 39
    .line 40
    move-object/from16 v22, v4

    .line 41
    .line 42
    move-object/from16 v24, v4

    .line 43
    .line 44
    move/from16 v25, v23

    .line 45
    .line 46
    move/from16 v26, v23

    .line 47
    .line 48
    move-object/from16 v27, v4

    .line 49
    .line 50
    move-object/from16 v28, v4

    .line 51
    .line 52
    move-object/from16 v29, v4

    .line 53
    .line 54
    move-object/from16 v30, v4

    .line 55
    .line 56
    move-object/from16 v31, v4

    .line 57
    .line 58
    move-object/from16 v32, v4

    .line 59
    .line 60
    move-object/from16 p0, v4

    .line 61
    .line 62
    invoke-static/range {v3 .. v34}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_0

    .line 71
    .line 72
    return-void
.end method

.method public final onThreeDSChallengeFinished(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;)V
    .locals 37

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v5, p1

    .line 2
    .line 3
    invoke-static {v5, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v6, p0

    .line 7
    .line 8
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->pendingThreeDSChallenge:Ljava/util/concurrent/atomic/AtomicReference;

    .line 9
    .line 10
    const/4 v8, 0x0

    .line 11
    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;

    .line 16
    .line 17
    if-eqz v3, :cond_1

    .line 18
    .line 19
    iget-object v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 20
    .line 21
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    move-object v7, v1

    .line 26
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 27
    .line 28
    const p0, 0xfffffff

    .line 29
    .line 30
    .line 31
    move-object v9, v8

    .line 32
    move-object v10, v8

    .line 33
    move-object v11, v8

    .line 34
    move-object v12, v8

    .line 35
    move-object v13, v8

    .line 36
    move-object v14, v8

    .line 37
    move-object v15, v8

    .line 38
    move-object/from16 v16, v8

    .line 39
    .line 40
    move-object/from16 v17, v8

    .line 41
    .line 42
    move-object/from16 v18, v8

    .line 43
    .line 44
    move-object/from16 v19, v8

    .line 45
    .line 46
    move-object/from16 v20, v8

    .line 47
    .line 48
    move-object/from16 v21, v8

    .line 49
    .line 50
    move-object/from16 v22, v8

    .line 51
    .line 52
    move-object/from16 v23, v8

    .line 53
    .line 54
    move-object/from16 v24, v8

    .line 55
    .line 56
    move-object/from16 v25, v8

    .line 57
    .line 58
    move-object/from16 v26, v8

    .line 59
    .line 60
    move/from16 v27, v4

    .line 61
    .line 62
    move-object/from16 v28, v8

    .line 63
    .line 64
    move/from16 v29, v4

    .line 65
    .line 66
    move/from16 v30, v4

    .line 67
    .line 68
    move-object/from16 v31, v8

    .line 69
    .line 70
    move-object/from16 v32, v8

    .line 71
    .line 72
    move-object/from16 v33, v8

    .line 73
    .line 74
    move-object/from16 v34, v8

    .line 75
    .line 76
    move-object/from16 v35, v8

    .line 77
    .line 78
    move-object/from16 v36, v8

    .line 79
    .line 80
    move-object/from16 p1, v8

    .line 81
    .line 82
    invoke-static/range {v7 .. v38}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_0

    .line 91
    .line 92
    invoke-direct {v6, v3, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->finishThreeDSChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/PendingThreeDSChallenge;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSChallengeResult;)V

    .line 93
    .line 94
    .line 95
    :cond_1
    return-void
.end method

.method public final onZipBlur()V
    .locals 36

    .line 0
    move-object/from16 v0, p0

    .line 1
    .line 2
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 3
    .line 4
    :cond_0
    invoke-interface {v4}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    move-object v5, v3

    .line 9
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 10
    .line 11
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 14
    .line 15
    invoke-static {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePostalField(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;)LX/IBK;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iget-object v2, v0, LX/IBK;->first:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 22
    .line 23
    iget-object v1, v0, LX/IBK;->second:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    if-eqz v2, :cond_2

    .line 29
    .line 30
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModelKt;->nullIfEmptyField(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 31
    .line 32
    .line 33
    move-result-object v16

    .line 34
    :goto_0
    if-eqz v1, :cond_1

    .line 35
    .line 36
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalValidationRule;->errorMessage:Ljava/lang/String;

    .line 37
    .line 38
    :cond_1
    const v35, 0x1ffff3ff

    .line 39
    .line 40
    .line 41
    const/4 v6, 0x0

    .line 42
    const/16 v25, 0x0

    .line 43
    .line 44
    move-object v7, v6

    .line 45
    move-object v8, v6

    .line 46
    move-object v9, v6

    .line 47
    move-object v10, v6

    .line 48
    move-object v11, v6

    .line 49
    move-object v12, v6

    .line 50
    move-object v13, v6

    .line 51
    move-object v14, v6

    .line 52
    move-object v15, v6

    .line 53
    move-object/from16 v17, v0

    .line 54
    .line 55
    move-object/from16 v18, v6

    .line 56
    .line 57
    move-object/from16 v19, v6

    .line 58
    .line 59
    move-object/from16 v20, v6

    .line 60
    .line 61
    move-object/from16 v21, v6

    .line 62
    .line 63
    move-object/from16 v22, v6

    .line 64
    .line 65
    move-object/from16 v23, v6

    .line 66
    .line 67
    move-object/from16 v24, v6

    .line 68
    .line 69
    move-object/from16 v26, v6

    .line 70
    .line 71
    move/from16 v27, v25

    .line 72
    .line 73
    move/from16 v28, v25

    .line 74
    .line 75
    move-object/from16 v29, v6

    .line 76
    .line 77
    move-object/from16 v30, v6

    .line 78
    .line 79
    move-object/from16 v31, v6

    .line 80
    .line 81
    move-object/from16 v32, v6

    .line 82
    .line 83
    move-object/from16 v33, v6

    .line 84
    .line 85
    move-object/from16 v34, v6

    .line 86
    .line 87
    move-object/from16 p0, v6

    .line 88
    .line 89
    invoke-static/range {v5 .. v36}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-interface {v4, v3, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_0

    .line 98
    .line 99
    return-void

    .line 100
    :cond_2
    move-object/from16 v16, v0

    .line 101
    .line 102
    goto :goto_0
.end method

.method public final onZipChange(Ljava/lang/String;)V
    .locals 36

    .line 0
    const/4 v3, 0x0

    .line 1
    move-object/from16 v4, p1

    .line 2
    .line 3
    invoke-static {v4, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v5, p0

    .line 7
    .line 8
    iget-object v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->_uiState:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    move-object v6, v1

    .line 15
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 16
    .line 17
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v4, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFormattingKt;->formatZip(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v10

    .line 23
    const p0, 0x18fff3f7

    .line 24
    .line 25
    .line 26
    const/4 v7, 0x0

    .line 27
    move-object v8, v7

    .line 28
    move-object v9, v7

    .line 29
    move-object v11, v7

    .line 30
    move-object v12, v7

    .line 31
    move-object v13, v7

    .line 32
    move-object v14, v7

    .line 33
    move-object v15, v7

    .line 34
    move-object/from16 v16, v7

    .line 35
    .line 36
    move-object/from16 v17, v7

    .line 37
    .line 38
    move-object/from16 v18, v7

    .line 39
    .line 40
    move-object/from16 v19, v7

    .line 41
    .line 42
    move-object/from16 v20, v7

    .line 43
    .line 44
    move-object/from16 v21, v7

    .line 45
    .line 46
    move-object/from16 v22, v7

    .line 47
    .line 48
    move-object/from16 v23, v7

    .line 49
    .line 50
    move-object/from16 v24, v7

    .line 51
    .line 52
    move-object/from16 v25, v7

    .line 53
    .line 54
    move/from16 v26, v3

    .line 55
    .line 56
    move-object/from16 v27, v7

    .line 57
    .line 58
    move/from16 v28, v3

    .line 59
    .line 60
    move/from16 v29, v3

    .line 61
    .line 62
    move-object/from16 v30, v7

    .line 63
    .line 64
    move-object/from16 v31, v7

    .line 65
    .line 66
    move-object/from16 v32, v7

    .line 67
    .line 68
    move-object/from16 v33, v7

    .line 69
    .line 70
    move-object/from16 v34, v7

    .line 71
    .line 72
    move-object/from16 v35, v7

    .line 73
    .line 74
    move-object/from16 p1, v7

    .line 75
    .line 76
    invoke-static/range {v6 .. v37}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/Ddn;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCheckoutPhase;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;LX/Ddn;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-direct {v5, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvViewModel;->withSubmitEnabled(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    return-void
.end method
