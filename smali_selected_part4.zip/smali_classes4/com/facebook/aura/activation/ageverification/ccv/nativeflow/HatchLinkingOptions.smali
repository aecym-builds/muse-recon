.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;
.super LX/07H;
.source ""


# instance fields
.field public final accountTypes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation
.end field

.field public final chargeAmount:Ljava/lang/String;

.field public final chargeCurrency:Ljava/lang/String;

.field public final displayAmount:Ljava/lang/String;

.field public final screenSubtitle:Ljava/lang/String;

.field public final screenTitle:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 536870912
    const/4 v2, 0x0

    .line 536870913
    sget-object v1, LX/0wV;->A00:LX/0wV;

    .line 536870914
    .line 536870915
    move-object v0, p0

    .line 536870916
    move-object v3, v2

    .line 536870917
    move-object v4, v2

    .line 536870918
    move-object v5, v2

    .line 536870919
    move-object p0, v2

    .line 536870920
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 536870921
    .line 536870922
    .line 536870923
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 268435464
    .line 268435465
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 268435466
    .line 268435467
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 268435470
    .line 268435471
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 268435472
    .line 268435473
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 268435474
    .line 268435475
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p7, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p1, LX/0wV;->A00:LX/0wV;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    move-object p2, v1

    .line 12
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object p3, v1

    .line 17
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 18
    .line 19
    if-eqz v0, :cond_3

    .line 20
    .line 21
    move-object p4, v1

    .line 22
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 23
    .line 24
    if-eqz v0, :cond_4

    .line 25
    .line 26
    move-object p5, v1

    .line 27
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 28
    .line 29
    if-eqz v0, :cond_5

    .line 30
    .line 31
    move-object p6, v1

    .line 32
    :cond_5
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;
    .locals 1

    .line 0
    and-int/lit8 v0, p7, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p7, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p7, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p7, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p7, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p7, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    invoke-virtual/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->copy(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_1

    .line 69
    .line 70
    :cond_0
    return v2

    .line 71
    :cond_1
    return v3
.end method

.method public final getAccountTypes()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChargeAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getChargeCurrency()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getDisplayAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->accountTypes:Ljava/util/List;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenTitle:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->screenSubtitle:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    mul-int/lit8 v1, v1, 0x1f

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeAmount:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v1, v0

    .line 31
    mul-int/lit8 v1, v1, 0x1f

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->chargeCurrency:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    add-int/2addr v1, v0

    .line 40
    mul-int/lit8 v1, v1, 0x1f

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;->displayAmount:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
