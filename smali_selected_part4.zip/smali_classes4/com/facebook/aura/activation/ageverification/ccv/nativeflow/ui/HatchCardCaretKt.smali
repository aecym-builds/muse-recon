.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCardCaretKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final caretAfterFormatting(Ljava/lang/String;LX/2iJ;)I
    .locals 6

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p0, p1}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    iget-object v0, p1, LX/2iJ;->A01:LX/2iK;

    .line 6
    .line 7
    iget-object v0, v0, LX/2iK;->A00:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->alphanumericsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    invoke-static {p0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->alphanumericsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCardCaretKt;->significantCharsBeforeCaret(LX/2iJ;)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    invoke-static {v4, v3}, LX/Bf6;->A11(Ljava/lang/String;I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {v1, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 26
    .line 27
    .line 28
    invoke-static {v0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    sub-int/2addr v1, v0

    .line 44
    if-nez v2, :cond_0

    .line 45
    .line 46
    add-int/2addr v3, v1

    .line 47
    :cond_0
    invoke-static {p0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCardCaretKt;->offsetPastSignificantChars(Ljava/lang/String;I)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    return v0
.end method

.method public static final offsetPastSignificantChars(Ljava/lang/String;I)I
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    if-lez p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v2

    .line 7
    const/4 v1, 0x0

    .line 8
    :goto_0
    if-ge v3, v2, :cond_2

    .line 9
    .line 10
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->isAsciiAlphanumeric(C)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    add-int/lit8 v1, v1, 0x1

    .line 21
    .line 22
    if-ne v1, p1, :cond_1

    .line 23
    .line 24
    add-int/lit8 v3, v3, 0x1

    .line 25
    .line 26
    :cond_0
    return v3

    .line 27
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_2
    return v2
.end method

.method public static final retargetingSeparatorBackspace(LX/2iJ;LX/2iJ;)LX/2iJ;
    .locals 9

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    iget-wide v2, p1, LX/2iJ;->A00:J

    .line 4
    .line 5
    invoke-static {v2, v3}, LX/3P9;->A04(J)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_7

    .line 10
    .line 11
    iget-wide v0, p0, LX/2iJ;->A00:J

    .line 12
    .line 13
    invoke-static {v0, v1}, LX/3P9;->A04(J)Z

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    if-eqz v4, :cond_7

    .line 18
    .line 19
    iget-object v4, p0, LX/2iJ;->A01:LX/2iK;

    .line 20
    .line 21
    iget-object v6, v4, LX/2iK;->A00:Ljava/lang/String;

    .line 22
    .line 23
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    iget-object v4, p1, LX/2iJ;->A01:LX/2iK;

    .line 28
    .line 29
    iget-object v7, v4, LX/2iK;->A00:Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    add-int/lit8 v8, v4, -0x1

    .line 36
    .line 37
    if-ne v5, v8, :cond_7

    .line 38
    .line 39
    invoke-static {v0, v1}, LX/002;->A0G(J)I

    .line 40
    .line 41
    .line 42
    move-result v8

    .line 43
    invoke-static {v2, v3}, LX/002;->A0G(J)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    add-int/lit8 v0, v0, -0x1

    .line 48
    .line 49
    if-ne v8, v0, :cond_7

    .line 50
    .line 51
    const/4 v3, 0x0

    .line 52
    const/4 v1, 0x0

    .line 53
    const/4 v2, 0x0

    .line 54
    :goto_0
    if-ge v1, v5, :cond_1

    .line 55
    .line 56
    invoke-virtual {v6, v1}, Ljava/lang/String;->charAt(I)C

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->isAsciiAlphanumeric(C)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    add-int/lit8 v2, v2, 0x1

    .line 67
    .line 68
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_1
    const/4 v1, 0x0

    .line 72
    :goto_1
    if-ge v3, v4, :cond_3

    .line 73
    .line 74
    invoke-virtual {v7, v3}, Ljava/lang/String;->charAt(I)C

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->isAsciiAlphanumeric(C)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_2

    .line 83
    .line 84
    add-int/lit8 v1, v1, 0x1

    .line 85
    .line 86
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_3
    if-ne v2, v1, :cond_7

    .line 90
    .line 91
    invoke-static {v6, v8}, LX/Bf6;->A11(Ljava/lang/String;I)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    add-int/lit8 v4, v0, -0x1

    .line 100
    .line 101
    if-ltz v4, :cond_7

    .line 102
    .line 103
    :goto_2
    add-int/lit8 v1, v4, -0x1

    .line 104
    .line 105
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->isAsciiAlphanumeric(C)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_5

    .line 114
    .line 115
    add-int/lit8 v3, v4, 0x1

    .line 116
    .line 117
    const/4 v2, 0x0

    .line 118
    if-lt v3, v4, :cond_6

    .line 119
    .line 120
    if-ne v3, v4, :cond_4

    .line 121
    .line 122
    invoke-virtual {v6, v2, v5}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    :goto_3
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v3

    .line 130
    invoke-static {v4, v4}, LX/005;->A0K(II)J

    .line 131
    .line 132
    .line 133
    move-result-wide v1

    .line 134
    new-instance v0, LX/2iJ;

    .line 135
    .line 136
    invoke-direct {v0, v3, v1, v2}, LX/2iJ;-><init>(Ljava/lang/String;J)V

    .line 137
    .line 138
    .line 139
    return-object v0

    .line 140
    :cond_4
    sub-int v0, v3, v4

    .line 141
    .line 142
    sub-int v0, v5, v0

    .line 143
    .line 144
    new-instance v1, Ljava/lang/StringBuilder;

    .line 145
    .line 146
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v1, v6, v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1, v6, v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    goto :goto_3

    .line 156
    :cond_5
    if-ltz v1, :cond_7

    .line 157
    .line 158
    move v4, v1

    .line 159
    goto :goto_2

    .line 160
    :cond_6
    const-string v2, "End index ("

    .line 161
    .line 162
    const-string v1, ") is less than start index ("

    .line 163
    .line 164
    const-string v0, ")."

    .line 165
    .line 166
    invoke-static {v2, v1, v0, v3, v4}, LX/Gi8;->A0q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 171
    .line 172
    invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    throw v0

    .line 176
    :cond_7
    return-object p0
.end method

.method public static final significantCharsBeforeCaret(LX/2iJ;)I
    .locals 3

    .line 0
    iget-object v0, p0, LX/2iJ;->A01:LX/2iK;

    .line 1
    .line 2
    iget-object v2, v0, LX/2iK;->A00:Ljava/lang/String;

    .line 3
    .line 4
    iget-wide v0, p0, LX/2iJ;->A00:J

    .line 5
    .line 6
    invoke-static {v0, v1}, LX/002;->A0G(J)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v2, v0}, LX/Bf6;->A11(Ljava/lang/String;I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    const/4 v2, 0x0

    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-ge v2, v0, :cond_1

    .line 21
    .line 22
    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-static {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->isAsciiAlphanumeric(C)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    add-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    return v1
.end method
