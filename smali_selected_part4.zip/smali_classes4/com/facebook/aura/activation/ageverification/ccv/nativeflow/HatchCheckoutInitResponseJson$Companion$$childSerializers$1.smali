.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/DZ7<",
        "Ljava/util/List<",
        "+",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
        ">;>;>;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/DZ7;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/DZ7<",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;>;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$$serializer;

    .line 1
    .line 2
    new-instance v0, LX/Dbs;

    .line 3
    .line 4
    invoke-direct {v0, p0}, LX/Dbs;-><init>(LX/DZ7;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 268435456
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson$$serializer;

    .line 268435457
    .line 268435458
    new-instance v0, LX/Dbs;

    .line 268435459
    .line 268435460
    invoke-direct {v0, p0}, LX/Dbs;-><init>(LX/DZ7;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object v0
.end method
