.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final CHECK_INTERVAL_MS:J = 0x7d0L
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CHECK_LIMIT:I = 0xf
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$Companion;

.field public static final KEY_ACCOUNT:Ljava/lang/String; = "age_linking_account"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final KEY_ACTIVATION_VERSION:Ljava/lang/String; = "age_linking_activation_version"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final KEY_ATTEMPT_ID:Ljava/lang/String; = "age_linking_attempt_id"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final _returns:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;",
            ">;"
        }
    .end annotation
.end field

.field public final _state:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;"
        }
    .end annotation
.end field

.field public nativeResolveJob:LX/Cbu;

.field public resolveJob:LX/Cbu;

.field public final returns:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;",
            ">;"
        }
    .end annotation
.end field

.field public final savedState:LX/17V;

.field public final startFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

.field public startJob:LX/Cbu;

.field public final state:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/AHE;LX/17V;)V
    .locals 11

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v3

    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 8
    .line 9
    const-string v0, "age_linking_account"

    .line 10
    .line 11
    invoke-virtual {p2, v0}, LX/17V;->A01(Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ljava/lang/String;

    .line 16
    .line 17
    const/4 v5, 0x0

    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType$Companion;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    :goto_0
    const-string v0, "age_linking_attempt_id"

    .line 27
    .line 28
    invoke-virtual {p2, v0}, LX/17V;->A01(Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v10

    .line 32
    check-cast v10, Ljava/lang/String;

    .line 33
    .line 34
    const-string v0, "age_linking_activation_version"

    .line 35
    .line 36
    invoke-virtual {p2, v0}, LX/17V;->A01(Ljava/lang/String;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    check-cast v0, Ljava/lang/Number;

    .line 41
    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    :goto_1
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 49
    .line 50
    move v6, v3

    .line 51
    move-object v8, v5

    .line 52
    move v9, v3

    .line 53
    invoke-direct/range {v2 .. v10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 54
    .line 55
    .line 56
    new-instance v1, LX/Ddv;

    .line 57
    .line 58
    invoke-direct {v1, v2}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 62
    .line 63
    new-instance v0, LX/ERk;

    .line 64
    .line 65
    invoke-direct {v0, v5, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 66
    .line 67
    .line 68
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->state:LX/2J3;

    .line 69
    .line 70
    const/4 v1, -0x2

    .line 71
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 72
    .line 73
    invoke-static {v0, v1}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_returns:LX/EYl;

    .line 78
    .line 79
    invoke-static {v0}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->returns:LX/2Lw;

    .line 84
    .line 85
    sget-object v0, Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;->INSTANCE:Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;

    .line 86
    .line 87
    invoke-static {p1, v0, v3}, Lcom/facebook/aura/common/coroutines/SingleFlightKt;->SingleFlight(LX/AHE;Lcom/facebook/aura/common/coroutines/OnDuplicateCall;Z)Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 92
    .line 93
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->resumeSavedAttempt()V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :cond_0
    const/4 v7, 0x0

    .line 98
    goto :goto_1

    .line 99
    :cond_1
    move-object v4, v5

    .line 100
    goto :goto_0
.end method

.method public static final synthetic access$activationChanged(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->activationChanged(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$awaitNextAction(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->awaitNextAction(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$clearSavedAttempt(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->clearSavedAttempt()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$finish(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getStartFlight$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;)Lcom/facebook/aura/common/coroutines/SingleFlight;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_returns$p(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;)LX/EYl;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_returns:LX/EYl;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$linkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->linkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$logLinkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->logLinkingResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$optionsChanged(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->optionsChanged(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$toBloksLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->toBloksLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$toLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->toLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$updateAttempt(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;ILX/JDM;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final activationChanged(I)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$activationChanged$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$activationChanged$1;

    .line 1
    .line 2
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 3
    .line 4
    .line 5
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 8
    .line 9
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 14
    .line 15
    iget v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 16
    .line 17
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    const-string v0, "age_linking_activation_version"

    .line 22
    .line 23
    invoke-virtual {p1, v0, p0}, LX/17V;->A03(Ljava/lang/String;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final awaitNextAction(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object p0, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->label:I

    .line 23
    .line 24
    const/4 v7, 0x2

    .line 25
    const/4 v5, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-eq v0, v5, :cond_1

    .line 29
    .line 30
    if-ne v0, v7, :cond_6

    .line 31
    .line 32
    iget v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$1:I

    .line 33
    .line 34
    iget v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$0:I

    .line 35
    .line 36
    iget-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$0:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 44
    .line 45
    if-lt v2, v4, :cond_3

    .line 46
    .line 47
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 48
    .line 49
    return-object v3

    .line 50
    :cond_1
    iget v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$2:I

    .line 51
    .line 52
    iget v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$1:I

    .line 53
    .line 54
    iget v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$0:I

    .line 55
    .line 56
    iget-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$0:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast p1, Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    const/4 v2, 0x0

    .line 68
    const/16 v4, 0xf

    .line 69
    .line 70
    :cond_3
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    const/4 v1, 0x0

    .line 75
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$2$nextAction$1;

    .line 76
    .line 77
    invoke-direct {v0, p1, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$2$nextAction$1;-><init>(Ljava/lang/String;LX/2M4;)V

    .line 78
    .line 79
    .line 80
    iput-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$0:Ljava/lang/Object;

    .line 81
    .line 82
    iput-object v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$1:Ljava/lang/Object;

    .line 83
    .line 84
    iput v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$0:I

    .line 85
    .line 86
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$1:I

    .line 87
    .line 88
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$2:I

    .line 89
    .line 90
    iput v5, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->label:I

    .line 91
    .line 92
    invoke-static {v6, v3, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    if-eq v3, p0, :cond_7

    .line 97
    .line 98
    move v1, v2

    .line 99
    :goto_1
    if-eqz v3, :cond_4

    .line 100
    .line 101
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 102
    .line 103
    if-eq v3, v0, :cond_4

    .line 104
    .line 105
    return-object v3

    .line 106
    :cond_4
    const/16 v0, 0xe

    .line 107
    .line 108
    if-ge v1, v0, :cond_0

    .line 109
    .line 110
    iput-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$0:Ljava/lang/Object;

    .line 111
    .line 112
    const/4 v0, 0x0

    .line 113
    iput-object v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->L$1:Ljava/lang/Object;

    .line 114
    .line 115
    iput v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$0:I

    .line 116
    .line 117
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$1:I

    .line 118
    .line 119
    iput v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->I$2:I

    .line 120
    .line 121
    iput v7, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;->label:I

    .line 122
    .line 123
    const-wide/16 v0, 0x7d0

    .line 124
    .line 125
    invoke-static {v0, v1, v6}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    if-ne v0, p0, :cond_0

    .line 130
    .line 131
    return-object p0

    .line 132
    :cond_5
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;

    .line 133
    .line 134
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$awaitNextAction$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;LX/2M4;)V

    .line 135
    .line 136
    .line 137
    goto :goto_0

    .line 138
    :cond_6
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    throw v0

    .line 143
    :cond_7
    return-object p0
.end method

.method private final clearSavedAttempt()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 1
    .line 2
    const-string v0, "age_linking_account"

    .line 3
    .line 4
    invoke-virtual {v1, v0}, LX/17V;->A02(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 8
    .line 9
    const-string v0, "age_linking_attempt_id"

    .line 10
    .line 11
    invoke-virtual {v1, v0}, LX/17V;->A02(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method private final finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;

    .line 1
    .line 2
    invoke-direct {v0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 3
    .line 4
    .line 5
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final linkingResult(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;
    .locals 0

    .line 0
    const/4 p0, -0x1

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eq p1, p0, :cond_2

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    if-eq p1, p0, :cond_2

    .line 11
    .line 12
    const/4 p0, 0x2

    .line 13
    if-eq p1, p0, :cond_2

    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    if-eq p1, p0, :cond_1

    .line 17
    .line 18
    const/4 p0, 0x4

    .line 19
    if-eq p1, p0, :cond_0

    .line 20
    .line 21
    const/4 p0, 0x3

    .line 22
    if-eq p1, p0, :cond_0

    .line 23
    .line 24
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 25
    .line 26
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 27
    .line 28
    .line 29
    throw p0

    .line 30
    :cond_0
    const/4 p0, 0x0

    .line 31
    return-object p0

    .line 32
    :cond_1
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;->PENDING:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 33
    .line 34
    return-object p0

    .line 35
    :cond_2
    sget-object p0, Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;->COMPLETED:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 36
    .line 37
    return-object p0
.end method

.method private final logLinkingResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)V
    .locals 4

    .line 0
    const/4 v0, -0x1

    .line 1
    invoke-static {p2}, LX/004;->A0s(Ljava/lang/Enum;)I

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    const/4 v1, 0x2

    .line 6
    const/4 p0, 0x0

    .line 7
    if-eq v2, v0, :cond_5

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    if-eq v2, v0, :cond_4

    .line 11
    .line 12
    if-eq v2, v1, :cond_3

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    if-eq v2, v0, :cond_2

    .line 16
    .line 17
    const/4 v0, 0x4

    .line 18
    if-eq v2, v0, :cond_1

    .line 19
    .line 20
    const/4 v0, 0x3

    .line 21
    if-ne v2, v0, :cond_6

    .line 22
    .line 23
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->NOT_OFFERED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->NOT_ELIGIBLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 26
    .line 27
    :goto_0
    new-instance v1, LX/IBK;

    .line 28
    .line 29
    invoke-direct {v1, v2, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :goto_1
    iget-object v2, v1, LX/IBK;->first:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 35
    .line 36
    iget-object v3, v1, LX/IBK;->second:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 39
    .line 40
    move-object v1, p1

    .line 41
    if-eqz p2, :cond_0

    .line 42
    .line 43
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->PENDING:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 44
    .line 45
    if-eq p2, v0, :cond_0

    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 48
    .line 49
    invoke-virtual {v0, p1, p0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptSubmitted(Lcom/facebook/aura/user/provider/AgeCheckMethod;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 53
    .line 54
    move-object p1, p0

    .line 55
    invoke-virtual/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_1
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->FAILED_RETRYABLE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 60
    .line 61
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->RESTART_LINKING:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_2
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->CANCELLED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 65
    .line 66
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->CANCELLED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_3
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->BLOCKED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 70
    .line 71
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->GENERIC:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->VERIFIED:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 75
    .line 76
    new-instance v1, LX/IBK;

    .line 77
    .line 78
    invoke-direct {v1, v0, p0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_5
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 83
    .line 84
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->GENERIC:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_6
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 88
    .line 89
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 90
    .line 91
    .line 92
    throw v0
.end method

.method private final onDialogUnavailable()V
    .locals 9

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 1
    .line 2
    invoke-virtual {v3}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->linkingReturned()V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 6
    .line 7
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 12
    .line 13
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    sget-object v5, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;->ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;

    .line 22
    .line 23
    sget-object v6, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;->GENERIC:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;

    .line 24
    .line 25
    const/4 v7, 0x0

    .line 26
    move-object v8, v7

    .line 27
    invoke-virtual/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckResult;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFailure;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->clearSavedAttempt()V

    .line 31
    .line 32
    .line 33
    iget v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onDialogUnavailable$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onDialogUnavailable$2;

    .line 36
    .line 37
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 38
    .line 39
    .line 40
    iget v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 41
    .line 42
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;->GENERIC:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 43
    .line 44
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method private final onNativeReturned()V
    .locals 6

    .line 0
    move-object v2, p0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeResolveJob:LX/Cbu;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v0, 0x1

    .line 10
    if-ne v1, v0, :cond_1

    .line 11
    .line 12
    :cond_0
    return-void

    .line 13
    :cond_1
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 14
    .line 15
    invoke-virtual {v1}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->linkingReturned()V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 19
    .line 20
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 25
    .line 26
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 27
    .line 28
    const/4 p0, 0x0

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    :goto_0
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 36
    .line 37
    invoke-direct {v2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 38
    .line 39
    .line 40
    iget-object v3, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attemptId:Ljava/lang/String;

    .line 41
    .line 42
    if-nez v3, :cond_3

    .line 43
    .line 44
    if-eqz v4, :cond_0

    .line 45
    .line 46
    invoke-virtual {v1, v4}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_2
    move-object v4, p0

    .line 51
    goto :goto_0

    .line 52
    :cond_3
    invoke-static {v2}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2;

    .line 57
    .line 58
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onNativeReturned$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Ljava/lang/String;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;LX/2M4;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v1, v0}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iput-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeResolveJob:LX/Cbu;

    .line 66
    .line 67
    return-void
.end method

.method private final optionsChanged(I)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$optionsChanged$1;

    .line 1
    .line 2
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method private final resumeSavedAttempt()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 7
    .line 8
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->launch:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attemptId:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->onNativeReturned()V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method private final toBloksLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;
    .locals 0

    .line 0
    const/4 p0, -0x1

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eq p1, p0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    if-eq p1, p0, :cond_1

    .line 11
    .line 12
    const/4 p0, 0x2

    .line 13
    if-eq p1, p0, :cond_1

    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    if-eq p1, p0, :cond_1

    .line 17
    .line 18
    const/4 p0, 0x4

    .line 19
    if-eq p1, p0, :cond_1

    .line 20
    .line 21
    const/4 p0, 0x3

    .line 22
    if-ne p1, p0, :cond_0

    .line 23
    .line 24
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;->ACCOUNT_NOT_ELIGIBLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 28
    .line 29
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 30
    .line 31
    .line 32
    throw p0

    .line 33
    :cond_1
    const/4 p0, 0x0

    .line 34
    return-object p0
.end method

.method private final toLinkingError(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p1

    .line 4
    const/4 p0, 0x1

    .line 5
    if-eq p1, p0, :cond_2

    .line 6
    .line 7
    const/4 p0, 0x2

    .line 8
    if-eq p1, p0, :cond_2

    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    if-eq p1, p0, :cond_2

    .line 12
    .line 13
    const/4 p0, 0x4

    .line 14
    if-eq p1, p0, :cond_1

    .line 15
    .line 16
    const/4 p0, 0x3

    .line 17
    if-ne p1, p0, :cond_0

    .line 18
    .line 19
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;->ACCOUNT_NOT_ELIGIBLE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 23
    .line 24
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 25
    .line 26
    .line 27
    throw p0

    .line 28
    :cond_1
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;->GENERIC:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_2
    const/4 p0, 0x0

    .line 32
    return-object p0
.end method

.method private final updateAttempt(ILX/JDM;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    :cond_0
    invoke-interface {p0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    move-object v1, v2

    .line 7
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 8
    .line 9
    iget v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 10
    .line 11
    if-ne v0, p1, :cond_1

    .line 12
    .line 13
    invoke-interface {p2, v1}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    :cond_1
    invoke-interface {p0, v2, v1}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final getReturns()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->returns:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->state:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final nativeLinkRequest(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;
    .locals 2

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    return-object p0

    .line 10
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v0, 0x1

    .line 17
    if-eq v1, v0, :cond_1

    .line 18
    .line 19
    if-ne v1, p0, :cond_2

    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->INSTAGRAM:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 22
    .line 23
    :goto_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->url:Ljava/lang/String;

    .line 24
    .line 25
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;

    .line 26
    .line 27
    invoke-direct {p0, v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;->FACEBOOK:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeAgeAccount;

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_2
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 35
    .line 36
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 37
    .line 38
    .line 39
    throw v0
.end method

.method public final onAccountPicked(Lcom/facebook/aura/user/provider/AgeCheckMethod;I)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 13
    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 17
    .line 18
    invoke-virtual {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->methodSelected(Lcom/facebook/aura/user/provider/AgeCheckMethod;I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    const/4 v1, 0x1

    .line 26
    const/4 v0, 0x3

    .line 27
    if-eq v2, v0, :cond_1

    .line 28
    .line 29
    const/4 v0, 0x4

    .line 30
    if-eq v2, v0, :cond_0

    .line 31
    .line 32
    if-eq v2, v3, :cond_2

    .line 33
    .line 34
    if-eq v2, v1, :cond_2

    .line 35
    .line 36
    const/4 v0, 0x2

    .line 37
    if-eq v2, v0, :cond_2

    .line 38
    .line 39
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 40
    .line 41
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->INSTAGRAM:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->FACEBOOK:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 49
    .line 50
    :goto_0
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->start(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Z)V

    .line 51
    .line 52
    .line 53
    :cond_2
    return-void
.end method

.method public final onCardSubmitted()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeResolveJob:LX/Cbu;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    const/4 v0, 0x1

    .line 9
    if-ne v1, v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->reset()V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public final onErrorDismissed()V
    .locals 13

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    :cond_0
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    move-object v3, v1

    .line 7
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 8
    .line 9
    const/16 v12, 0xdf

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v4, 0x0

    .line 13
    move-object v6, v5

    .line 14
    move v7, v4

    .line 15
    move v8, v4

    .line 16
    move-object v9, v5

    .line 17
    move v10, v4

    .line 18
    move-object v11, v5

    .line 19
    move-object p0, v5

    .line 20
    invoke-static/range {v3 .. v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    return-void
.end method

.method public final onLaunchSkipped()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 7
    .line 8
    iget v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 11
    .line 12
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 17
    .line 18
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->clearSavedAttempt()V

    .line 32
    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onLaunchSkipped$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onLaunchSkipped$2;

    .line 35
    .line 36
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->updateAttempt(ILX/JDM;)V

    .line 37
    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    invoke-direct {p0, v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final onLaunched(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;Z)V
    .locals 11

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v0, :cond_2

    .line 12
    .line 13
    if-ne v1, v4, :cond_3

    .line 14
    .line 15
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->LINKING_INSTAGRAM:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 18
    .line 19
    :goto_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->PICK:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 20
    .line 21
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->stepShown(Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;)V

    .line 22
    .line 23
    .line 24
    if-eqz p2, :cond_0

    .line 25
    .line 26
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 29
    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->getWireValue()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v0, "age_linking_account"

    .line 35
    .line 36
    invoke-virtual {v2, v0, v1}, LX/17V;->A03(Ljava/lang/String;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->savedState:LX/17V;

    .line 40
    .line 41
    const-string v1, "age_linking_attempt_id"

    .line 42
    .line 43
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;->attemptId:Ljava/lang/String;

    .line 44
    .line 45
    invoke-virtual {v2, v1, v0}, LX/17V;->A03(Ljava/lang/String;Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 49
    .line 50
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    move-object v3, v1

    .line 55
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 56
    .line 57
    const/16 p1, 0xfb

    .line 58
    .line 59
    const/4 v5, 0x0

    .line 60
    move-object v6, v5

    .line 61
    move v7, v4

    .line 62
    move v8, v4

    .line 63
    move-object v9, v5

    .line 64
    move v10, v4

    .line 65
    move-object p0, v5

    .line 66
    move-object p2, v5

    .line 67
    invoke-static/range {v3 .. v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_1

    .line 76
    .line 77
    return-void

    .line 78
    :cond_2
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 79
    .line 80
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->LINKING_FACEBOOK:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 84
    .line 85
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 86
    .line 87
    .line 88
    throw v0
.end method

.method public final onLinkerResult(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/002;->A0K(Ljava/lang/Enum;I)I

    .line 2
    .line 3
    .line 4
    move-result v1

    .line 5
    if-eq v1, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq v1, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-ne v1, v0, :cond_0

    .line 12
    .line 13
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->onDialogUnavailable()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 18
    .line 19
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 20
    .line 21
    .line 22
    throw v0

    .line 23
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->onNativeReturned()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final onReturned()V
    .locals 16

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 1
    .line 2
    invoke-virtual {v1}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->linkingReturned()V

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p0

    .line 6
    .line 7
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 8
    .line 9
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v6

    .line 13
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 14
    .line 15
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 16
    .line 17
    const/4 v14, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    :goto_0
    iget-object v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attemptId:Ljava/lang/String;

    .line 25
    .line 26
    if-nez v3, :cond_2

    .line 27
    .line 28
    if-eqz v5, :cond_0

    .line 29
    .line 30
    invoke-virtual {v1, v5}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_returns:LX/EYl;

    .line 34
    .line 35
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;->RETURNED:Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;

    .line 38
    .line 39
    invoke-direct {v0, v5, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingReturn;-><init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/intf/AgeLinkingResult;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v2, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    iget v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 46
    .line 47
    invoke-direct {v4, v0, v14}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->finish(ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_1
    move-object v5, v14

    .line 52
    goto :goto_0

    .line 53
    :cond_2
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 54
    .line 55
    :cond_3
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v7

    .line 59
    move-object v8, v7

    .line 60
    check-cast v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 61
    .line 62
    iget v1, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 63
    .line 64
    iget v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 65
    .line 66
    if-ne v1, v0, :cond_4

    .line 67
    .line 68
    const/4 v9, 0x1

    .line 69
    iget-object v10, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 70
    .line 71
    iget-object v11, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->launch:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 72
    .line 73
    iget v12, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 74
    .line 75
    iget v13, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 76
    .line 77
    iget v15, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 78
    .line 79
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 80
    .line 81
    move-object/from16 p0, v14

    .line 82
    .line 83
    invoke-direct/range {v8 .. v16}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :cond_4
    invoke-interface {v2, v7, v8}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_3

    .line 91
    .line 92
    invoke-static {v4}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;

    .line 101
    .line 102
    move-object v12, v14

    .line 103
    move-object v11, v6

    .line 104
    move-object v10, v4

    .line 105
    move-object v9, v5

    .line 106
    move-object v8, v3

    .line 107
    invoke-direct/range {v7 .. v12}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$onReturned$3;-><init>(Ljava/lang/String;Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;LX/2M4;)V

    .line 108
    .line 109
    .line 110
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 111
    .line 112
    invoke-static {v0, v1, v7, v2}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    iput-object v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->resolveJob:LX/Cbu;

    .line 117
    .line 118
    return-void
.end method

.method public final reset()V
    .locals 11

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 22
    .line 23
    invoke-interface {v0}, Lcom/facebook/aura/common/coroutines/SingleFlight;->clearAndCancelAll()V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startJob:LX/Cbu;

    .line 27
    .line 28
    const/4 v5, 0x0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-interface {v0, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->resolveJob:LX/Cbu;

    .line 35
    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    invoke-interface {v0, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 39
    .line 40
    .line 41
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeResolveJob:LX/Cbu;

    .line 42
    .line 43
    if-eqz v0, :cond_3

    .line 44
    .line 45
    invoke-interface {v0, v5}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 46
    .line 47
    .line 48
    :cond_3
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->clearSavedAttempt()V

    .line 49
    .line 50
    .line 51
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 52
    .line 53
    :cond_4
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    move-object v0, v1

    .line 58
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 59
    .line 60
    iget v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 61
    .line 62
    iget v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 63
    .line 64
    iget v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 65
    .line 66
    add-int/lit8 v10, v0, 0x1

    .line 67
    .line 68
    const/4 v4, 0x0

    .line 69
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 70
    .line 71
    move-object v6, v5

    .line 72
    move-object v9, v5

    .line 73
    move-object p0, v5

    .line 74
    invoke-direct/range {v3 .. v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-interface {v2, v1, v3}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_4

    .line 82
    .line 83
    return-void
.end method

.method public final start(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Z)V
    .locals 17

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    invoke-static {v6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v13, p0

    .line 7
    .line 8
    iget-object v3, v13, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->_state:LX/2J2;

    .line 9
    .line 10
    :cond_0
    invoke-interface {v3}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    move-object v1, v2

    .line 15
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 16
    .line 17
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 18
    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    move-object v4, v1

    .line 22
    :goto_0
    invoke-interface {v3, v2, v4}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->account:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    iget-object v0, v13, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->nativeResolveJob:LX/Cbu;

    .line 33
    .line 34
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 35
    .line 36
    .line 37
    invoke-direct {v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->clearSavedAttempt()V

    .line 38
    .line 39
    .line 40
    iget v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 41
    .line 42
    add-int/lit8 v15, v0, 0x1

    .line 43
    .line 44
    invoke-static {v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingKt;->getAgeCheckMethod(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 49
    .line 50
    invoke-virtual {v0, v3}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptStarted(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 51
    .line 52
    .line 53
    invoke-static {v13}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-static {}, LX/006;->A1H()LX/BqD;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    const/16 p1, 0x0

    .line 62
    .line 63
    new-instance v12, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;

    .line 64
    .line 65
    move/from16 p0, p2

    .line 66
    .line 67
    move-object v14, v6

    .line 68
    move-object/from16 v16, v3

    .line 69
    .line 70
    invoke-direct/range {v12 .. v18}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$start$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;ILcom/facebook/aura/user/provider/AgeCheckMethod;ZLX/2M4;)V

    .line 71
    .line 72
    .line 73
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 74
    .line 75
    invoke-static {v0, v1, v12, v2}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    iput-object v0, v13, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel;->startJob:LX/Cbu;

    .line 80
    .line 81
    :cond_1
    return-void

    .line 82
    :cond_2
    iget v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 83
    .line 84
    add-int/lit8 v11, v0, 0x1

    .line 85
    .line 86
    const/4 v12, 0x0

    .line 87
    iget-boolean v5, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->isResolving:Z

    .line 88
    .line 89
    iget-object v7, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->launch:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;

    .line 90
    .line 91
    iget v8, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 92
    .line 93
    iget v9, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 94
    .line 95
    iget-object v10, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 96
    .line 97
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 98
    .line 99
    invoke-direct/range {v4 .. v12}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 100
    .line 101
    .line 102
    goto :goto_0
.end method
