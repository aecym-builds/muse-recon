.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;
.super LX/07H;
.source ""


# instance fields
.field public final amount:Ljava/lang/String;

.field public final checkoutButtonLabel:Ljava/lang/String;

.field public final countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

.field public final currency:Ljava/lang/String;

.field public final orderId:Ljava/lang/String;

.field public final otcSessionId:Ljava/lang/String;

.field public final screenSubtitle:Ljava/lang/String;

.field public final screenTitle:Ljava/lang/String;

.field public final supportedCardTypes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final uplSessionId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 268435456
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435460
    .line 268435461
    .line 268435462
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 268435463
    .line 268435464
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 268435465
    .line 268435466
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 268435467
    .line 268435468
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 268435469
    .line 268435470
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 268435471
    .line 268435472
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 268435473
    .line 268435474
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 268435475
    .line 268435476
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 268435477
    .line 268435478
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 268435479
    .line 268435480
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 268435481
    .line 268435482
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 0
    and-int/lit8 v0, p11, 0x8

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p4, LX/0wV;->A00:LX/0wV;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p11, 0x10

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    move-object p5, v1

    .line 12
    :cond_1
    and-int/lit8 v0, p11, 0x20

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    move-object p6, v1

    .line 17
    :cond_2
    and-int/lit8 v0, p11, 0x40

    .line 18
    .line 19
    if-eqz v0, :cond_3

    .line 20
    .line 21
    move-object p7, v1

    .line 22
    :cond_3
    and-int/lit16 v0, p11, 0x80

    .line 23
    .line 24
    if-eqz v0, :cond_4

    .line 25
    .line 26
    move-object p8, v1

    .line 27
    :cond_4
    and-int/lit16 v0, p11, 0x100

    .line 28
    .line 29
    if-eqz v0, :cond_5

    .line 30
    .line 31
    move-object p9, v1

    .line 32
    :cond_5
    and-int/lit16 v0, p11, 0x200

    .line 33
    .line 34
    if-eqz v0, :cond_6

    .line 35
    .line 36
    move-object p10, v1

    .line 37
    :cond_6
    invoke-direct/range {p0 .. p10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;
    .locals 1

    .line 0
    and-int/lit8 v0, p11, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p11, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p11, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p11, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p11, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p11, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p11, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p11, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 47
    .line 48
    :cond_7
    and-int/lit16 v0, p11, 0x100

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    iget-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 53
    .line 54
    :cond_8
    and-int/lit16 v0, p11, 0x200

    .line 55
    .line 56
    if-eqz v0, :cond_9

    .line 57
    .line 58
    iget-object p10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 59
    .line 60
    :cond_9
    invoke-virtual/range {p0 .. p10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3, p4}, LX/005;->A12(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 91
    .line 92
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 93
    .line 94
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-nez v0, :cond_1

    .line 109
    .line 110
    :cond_0
    return v2

    .line 111
    :cond_1
    return v3
.end method

.method public final getAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCheckoutButtonLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCountryOptions()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrderId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtcSessionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getScreenTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSupportedCardTypes()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUplSessionId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->countryOptions:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 25
    .line 26
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v1, v0

    .line 31
    mul-int/lit8 v1, v1, 0x1f

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->amount:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    add-int/2addr v1, v0

    .line 40
    mul-int/lit8 v1, v1, 0x1f

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->currency:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    mul-int/lit8 v1, v1, 0x1f

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenTitle:Ljava/lang/String;

    .line 52
    .line 53
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    add-int/2addr v1, v0

    .line 58
    mul-int/lit8 v1, v1, 0x1f

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->screenSubtitle:Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    add-int/2addr v1, v0

    .line 67
    mul-int/lit8 v1, v1, 0x1f

    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->checkoutButtonLabel:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    add-int/2addr v1, v0

    .line 76
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
