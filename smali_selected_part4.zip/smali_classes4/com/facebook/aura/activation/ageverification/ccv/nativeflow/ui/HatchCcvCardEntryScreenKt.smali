.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CardMarkHeight:F = 20.0f

.field public static final CardMarkWidth:F = 30.0f

.field public static final EXPIRY_DIGITS:I = 0x4

.field public static final FieldGap:F = 12.0f

.field public static final LogoSize:F = 71.0f

.field public static final SubtitleToFieldsGap:F = 32.0f


# direct methods
.method public static final CardBrandMarks(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/3C1;LX/2d4;II)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    const v0, -0x73a7a52d

    .line 3
    .line 4
    .line 5
    move-object/from16 v14, p3

    .line 6
    .line 7
    invoke-interface {v14, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_7

    .line 17
    .line 18
    invoke-static {v14, v5}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    or-int v6, v6, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v13, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v14, v13}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v6, v0

    .line 35
    :cond_0
    and-int/lit8 v2, p5, 0x4

    .line 36
    .line 37
    if-eqz v2, :cond_6

    .line 38
    .line 39
    or-int/lit16 v6, v6, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v1, v6, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v9, 0x0

    .line 46
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, v14, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_b

    .line 55
    .line 56
    if-eqz v2, :cond_2

    .line 57
    .line 58
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    sget-object v2, Lcom/facebook/aura/payments/cardvalidation/HatchCardBrandAssets;->INSTANCE:Lcom/facebook/aura/payments/cardvalidation/HatchCardBrandAssets;

    .line 61
    .line 62
    invoke-virtual {v2, v5}, Lcom/facebook/aura/payments/cardvalidation/HatchCardBrandAssets;->forNetwork(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;)Ljava/lang/Integer;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-eqz v0, :cond_4

    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object v12

    .line 80
    :cond_3
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 81
    .line 82
    const/4 v15, 0x0

    .line 83
    const/4 v8, 0x0

    .line 84
    invoke-static {v4, v8, v8, v0, v8}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 89
    .line 90
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    sget-object v0, LX/2Id;->A05:LX/2rU;

    .line 95
    .line 96
    invoke-static {v2, v14, v0, v9}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    move-object v2, v14

    .line 101
    check-cast v2, LX/J7I;

    .line 102
    .line 103
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 104
    .line 105
    .line 106
    move-result v10

    .line 107
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 108
    .line 109
    .line 110
    move-result-object v7

    .line 111
    invoke-static {v14, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 118
    .line 119
    if-nez v0, :cond_8

    .line 120
    .line 121
    invoke-static {}, LX/1VY;->A00()V

    .line 122
    .line 123
    .line 124
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    throw v0

    .line 129
    :cond_4
    new-instance v12, Ljava/util/ArrayList;

    .line 130
    .line 131
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 132
    .line 133
    .line 134
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    :cond_5
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-eqz v0, :cond_3

    .line 143
    .line 144
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 149
    .line 150
    invoke-virtual {v2, v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardBrandAssets;->forNetwork(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;)Ljava/lang/Integer;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    if-eqz v0, :cond_5

    .line 155
    .line 156
    invoke-virtual {v12, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    goto :goto_2

    .line 160
    :cond_6
    and-int/lit16 v0, v3, 0x180

    .line 161
    .line 162
    if-nez v0, :cond_1

    .line 163
    .line 164
    invoke-static {v14, v4}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    or-int/2addr v6, v0

    .line 169
    goto :goto_1

    .line 170
    :cond_7
    move v6, v3

    .line 171
    goto/16 :goto_0

    .line 172
    .line 173
    :cond_8
    invoke-static {v14, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 174
    .line 175
    .line 176
    invoke-static {v14, v11, v7, v6, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 177
    .line 178
    .line 179
    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    if-eqz v0, :cond_a

    .line 184
    .line 185
    const v0, 0x5ae964b9

    .line 186
    .line 187
    .line 188
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 189
    .line 190
    .line 191
    const v0, 0x7f080114

    .line 192
    .line 193
    .line 194
    invoke-static {v14, v0, v9}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 195
    .line 196
    .line 197
    move-result-object v16

    .line 198
    invoke-static {v14}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 203
    .line 204
    sget-object v17, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 205
    .line 206
    sget v6, LX/2l9;->$stable:I

    .line 207
    .line 208
    shl-int/lit8 v6, v6, 0x3

    .line 209
    .line 210
    or-int/lit16 v6, v6, 0xd80

    .line 211
    .line 212
    const/16 p4, 0x21

    .line 213
    .line 214
    move-object/from16 v18, v15

    .line 215
    .line 216
    move-wide/from16 v19, v0

    .line 217
    .line 218
    move-object/from16 p1, v15

    .line 219
    .line 220
    move-object/from16 p2, v14

    .line 221
    .line 222
    move/from16 p3, v6

    .line 223
    .line 224
    invoke-static/range {v15 .. v24}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 225
    .line 226
    .line 227
    :cond_9
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 228
    .line 229
    .line 230
    goto :goto_4

    .line 231
    :cond_a
    const v0, 0x5aece31f

    .line 232
    .line 233
    .line 234
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 235
    .line 236
    .line 237
    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 238
    .line 239
    .line 240
    move-result-object v7

    .line 241
    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 242
    .line 243
    .line 244
    move-result v0

    .line 245
    if-eqz v0, :cond_9

    .line 246
    .line 247
    invoke-static {v7}, LX/003;->A0L(Ljava/util/Iterator;)I

    .line 248
    .line 249
    .line 250
    move-result v0

    .line 251
    invoke-static {v14, v0, v9}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 252
    .line 253
    .line 254
    move-result-object v18

    .line 255
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 256
    .line 257
    sget v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CardMarkWidth:F

    .line 258
    .line 259
    sget v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CardMarkHeight:F

    .line 260
    .line 261
    invoke-static {v6, v1, v0}, LX/2sI;->A0C(LX/3C1;FF)LX/3C1;

    .line 262
    .line 263
    .line 264
    move-result-object v16

    .line 265
    sget v0, LX/2l9;->$stable:I

    .line 266
    .line 267
    or-int/lit16 v0, v0, 0x1b0

    .line 268
    .line 269
    const/16 p3, 0x78

    .line 270
    .line 271
    move-object/from16 v17, v15

    .line 272
    .line 273
    move-object/from16 v19, v15

    .line 274
    .line 275
    move-object/from16 p0, v15

    .line 276
    .line 277
    move/from16 p1, v8

    .line 278
    .line 279
    move/from16 p2, v0

    .line 280
    .line 281
    invoke-static/range {v14 .. v23}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 282
    .line 283
    .line 284
    goto :goto_3

    .line 285
    :cond_b
    invoke-interface {v14}, LX/2d4;->AgJ()V

    .line 286
    .line 287
    .line 288
    :goto_4
    invoke-interface {v14}, LX/2d4;->AAg()LX/J7V;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    if-eqz v1, :cond_c

    .line 293
    .line 294
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CardBrandMarks$2;

    .line 295
    .line 296
    move-object/from16 p0, v0

    .line 297
    .line 298
    move-object/from16 p1, v5

    .line 299
    .line 300
    move-object/from16 p2, v13

    .line 301
    .line 302
    move-object/from16 p3, v4

    .line 303
    .line 304
    move/from16 p4, v3

    .line 305
    .line 306
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CardBrandMarks$2;-><init>(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/3C1;II)V

    .line 307
    .line 308
    .line 309
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 310
    .line 311
    :cond_c
    return-void
.end method

.method public static final CcvCardFields(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 78
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 0
    move-object/from16 v34, p12

    .line 1
    .line 2
    const v1, -0x4f000619

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p13

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p14

    .line 11
    .line 12
    and-int/lit8 v1, p14, 0x6

    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    if-nez v1, :cond_11

    .line 17
    .line 18
    invoke-static {v2, v0, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    or-int v1, v1, p14

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v3, p14, 0x30

    .line 29
    .line 30
    if-nez v3, :cond_0

    .line 31
    .line 32
    move/from16 v3, p1

    .line 33
    .line 34
    invoke-static {v0, v3}, LX/004;->A0j(LX/2d4;Z)I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    or-int/2addr v1, v3

    .line 39
    :cond_0
    and-int/lit16 v3, v5, 0x180

    .line 40
    .line 41
    const/16 v4, 0x80

    .line 42
    .line 43
    move-object/from16 p0, p2

    .line 44
    .line 45
    if-nez v3, :cond_1

    .line 46
    .line 47
    move-object/from16 v3, p0

    .line 48
    .line 49
    invoke-static {v0, v3}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    or-int/2addr v1, v3

    .line 54
    :cond_1
    and-int/lit16 v3, v5, 0xc00

    .line 55
    .line 56
    move-object/from16 v77, p3

    .line 57
    .line 58
    if-nez v3, :cond_2

    .line 59
    .line 60
    move-object/from16 v3, v77

    .line 61
    .line 62
    invoke-static {v0, v3}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    or-int/2addr v1, v3

    .line 67
    :cond_2
    and-int/lit16 v3, v5, 0x6000

    .line 68
    .line 69
    move-object/from16 v76, p4

    .line 70
    .line 71
    if-nez v3, :cond_3

    .line 72
    .line 73
    move-object/from16 v3, v76

    .line 74
    .line 75
    invoke-static {v0, v3}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    or-int/2addr v1, v3

    .line 80
    :cond_3
    const/high16 v3, 0x30000

    .line 81
    .line 82
    and-int v3, v3, p14

    .line 83
    .line 84
    move-object/from16 v75, p5

    .line 85
    .line 86
    if-nez v3, :cond_4

    .line 87
    .line 88
    move-object/from16 v3, v75

    .line 89
    .line 90
    invoke-static {v0, v3}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    or-int/2addr v1, v3

    .line 95
    :cond_4
    const/high16 v3, 0x180000

    .line 96
    .line 97
    and-int v3, p14, v3

    .line 98
    .line 99
    move-object/from16 v74, p6

    .line 100
    .line 101
    if-nez v3, :cond_5

    .line 102
    .line 103
    move-object/from16 v3, v74

    .line 104
    .line 105
    invoke-static {v0, v3}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 106
    .line 107
    .line 108
    move-result v3

    .line 109
    or-int/2addr v1, v3

    .line 110
    :cond_5
    const/high16 v32, 0xc00000

    .line 111
    .line 112
    and-int v3, p14, v32

    .line 113
    .line 114
    move-object/from16 v73, p7

    .line 115
    .line 116
    if-nez v3, :cond_6

    .line 117
    .line 118
    move-object/from16 v3, v73

    .line 119
    .line 120
    invoke-static {v0, v3}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    or-int/2addr v1, v3

    .line 125
    :cond_6
    const/high16 v31, 0x6000000

    .line 126
    .line 127
    and-int v3, p14, v31

    .line 128
    .line 129
    move-object/from16 v72, p8

    .line 130
    .line 131
    if-nez v3, :cond_7

    .line 132
    .line 133
    move-object/from16 v3, v72

    .line 134
    .line 135
    invoke-static {v0, v3}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    or-int/2addr v1, v3

    .line 140
    :cond_7
    const/high16 v3, 0x30000000

    .line 141
    .line 142
    and-int v3, p14, v3

    .line 143
    .line 144
    move-object/from16 v71, p9

    .line 145
    .line 146
    if-nez v3, :cond_8

    .line 147
    .line 148
    move-object/from16 v3, v71

    .line 149
    .line 150
    invoke-static {v0, v3}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    .line 151
    .line 152
    .line 153
    move-result v3

    .line 154
    or-int/2addr v1, v3

    .line 155
    :cond_8
    move/from16 v33, p15

    .line 156
    .line 157
    and-int/lit8 v3, p15, 0x6

    .line 158
    .line 159
    move-object/from16 v70, p10

    .line 160
    .line 161
    if-nez v3, :cond_10

    .line 162
    .line 163
    move-object/from16 v3, v70

    .line 164
    .line 165
    invoke-static {v0, v3}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 166
    .line 167
    .line 168
    move-result v3

    .line 169
    or-int v9, p15, v3

    .line 170
    .line 171
    :goto_1
    and-int/lit8 v3, p15, 0x30

    .line 172
    .line 173
    move-object/from16 v69, p11

    .line 174
    .line 175
    if-nez v3, :cond_9

    .line 176
    .line 177
    move-object/from16 v3, v69

    .line 178
    .line 179
    invoke-static {v0, v3}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 180
    .line 181
    .line 182
    move-result v3

    .line 183
    or-int/2addr v9, v3

    .line 184
    :cond_9
    move/from16 v68, p16

    .line 185
    .line 186
    move/from16 v3, v68

    .line 187
    .line 188
    and-int/lit16 v7, v3, 0x1000

    .line 189
    .line 190
    if-eqz v7, :cond_e

    .line 191
    .line 192
    or-int/lit16 v9, v9, 0x180

    .line 193
    .line 194
    :cond_a
    :goto_2
    const v3, 0x12492493

    .line 195
    .line 196
    .line 197
    and-int v4, v1, v3

    .line 198
    .line 199
    const v3, 0x12492492

    .line 200
    .line 201
    .line 202
    if-ne v4, v3, :cond_b

    .line 203
    .line 204
    and-int/lit16 v6, v9, 0x93

    .line 205
    .line 206
    const/16 v4, 0x92

    .line 207
    .line 208
    const/4 v3, 0x0

    .line 209
    if-eq v6, v4, :cond_c

    .line 210
    .line 211
    :cond_b
    const/4 v3, 0x1

    .line 212
    :cond_c
    invoke-static {v3, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 213
    .line 214
    .line 215
    move-result v3

    .line 216
    if-eqz v3, :cond_12

    .line 217
    .line 218
    if-eqz v7, :cond_d

    .line 219
    .line 220
    sget-object v34, LX/3C1;->A00:LX/3Cb;

    .line 221
    .line 222
    :cond_d
    sget-object v3, LX/3Fe;->A05:LX/Ip3;

    .line 223
    .line 224
    invoke-interface {v0, v3}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v8

    .line 228
    check-cast v8, LX/1Ju;

    .line 229
    .line 230
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v3

    .line 234
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 235
    .line 236
    invoke-static {v0, v3, v4}, LX/008;->A0x(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v13

    .line 240
    check-cast v13, LX/3Bk;

    .line 241
    .line 242
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v3

    .line 246
    invoke-static {v0, v3, v4}, LX/008;->A0x(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v30

    .line 250
    check-cast v30, LX/3Bk;

    .line 251
    .line 252
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v3

    .line 256
    invoke-static {v0, v3, v4}, LX/008;->A0x(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v29

    .line 260
    check-cast v29, LX/3Bk;

    .line 261
    .line 262
    sget-object v28, LX/2sI;->A02:LX/2wD;

    .line 263
    .line 264
    move-object/from16 v6, v34

    .line 265
    .line 266
    move-object/from16 v3, v28

    .line 267
    .line 268
    invoke-interface {v6, v3}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 269
    .line 270
    .line 271
    move-result-object v14

    .line 272
    sget-object v7, LX/Dn6;->A06:LX/Dps;

    .line 273
    .line 274
    sget-object v6, LX/2Id;->A02:LX/2sS;

    .line 275
    .line 276
    const/16 v27, 0x0

    .line 277
    .line 278
    move/from16 v3, v27

    .line 279
    .line 280
    invoke-static {v7, v0, v6, v3}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 281
    .line 282
    .line 283
    move-result-object v12

    .line 284
    move-object v10, v0

    .line 285
    check-cast v10, LX/J7I;

    .line 286
    .line 287
    iget-wide v6, v10, LX/J7I;->A06:J

    .line 288
    .line 289
    const/16 v3, 0x20

    .line 290
    .line 291
    ushr-long v15, v6, v3

    .line 292
    .line 293
    xor-long/2addr v6, v15

    .line 294
    long-to-int v11, v6

    .line 295
    invoke-static {v10}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 296
    .line 297
    .line 298
    move-result-object v7

    .line 299
    invoke-static {v0, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    sget-object v26, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 304
    .line 305
    iget-object v3, v10, LX/J7I;->A0V:LX/3DJ;

    .line 306
    .line 307
    if-nez v3, :cond_13

    .line 308
    .line 309
    invoke-static {}, LX/1VY;->A00()V

    .line 310
    .line 311
    .line 312
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    throw v0

    .line 317
    :cond_e
    move/from16 v3, v33

    .line 318
    .line 319
    and-int/lit16 v3, v3, 0x180

    .line 320
    .line 321
    if-nez v3, :cond_a

    .line 322
    .line 323
    move-object/from16 v3, v34

    .line 324
    .line 325
    invoke-interface {v0, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    move-result v3

    .line 329
    if-eqz v3, :cond_f

    .line 330
    .line 331
    const/16 v4, 0x100

    .line 332
    .line 333
    :cond_f
    or-int/2addr v9, v4

    .line 334
    goto/16 :goto_2

    .line 335
    .line 336
    :cond_10
    move/from16 v9, v33

    .line 337
    .line 338
    goto/16 :goto_1

    .line 339
    .line 340
    :cond_11
    move v1, v5

    .line 341
    goto/16 :goto_0

    .line 342
    .line 343
    :cond_12
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 344
    .line 345
    .line 346
    goto/16 :goto_9

    .line 347
    .line 348
    :cond_13
    move-object/from16 v3, v26

    .line 349
    .line 350
    invoke-static {v0, v10, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 351
    .line 352
    .line 353
    sget-object v25, LX/3Cl;->A04:LX/JDN;

    .line 354
    .line 355
    move-object/from16 v3, v25

    .line 356
    .line 357
    invoke-static {v0, v12, v3}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 358
    .line 359
    .line 360
    sget-object v24, LX/3Cl;->A06:LX/JDN;

    .line 361
    .line 362
    move-object/from16 v3, v24

    .line 363
    .line 364
    invoke-static {v0, v7, v3, v11}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 365
    .line 366
    .line 367
    move-result-object v23

    .line 368
    sget-object v22, LX/3Cl;->A02:LX/JDM;

    .line 369
    .line 370
    move-object/from16 v3, v22

    .line 371
    .line 372
    invoke-static {v0, v6, v3}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 373
    .line 374
    .line 375
    move-result-object v17

    .line 376
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumber:Ljava/lang/String;

    .line 377
    .line 378
    move-object/from16 v18, v3

    .line 379
    .line 380
    const v38, 0x7f120290

    .line 381
    .line 382
    .line 383
    sget-object v42, LX/0Nq;->A07:LX/0PV;

    .line 384
    .line 385
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->cardNumberError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 386
    .line 387
    move-object/from16 v16, v3

    .line 388
    .line 389
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 390
    .line 391
    const/4 v3, 0x0

    .line 392
    const/16 v21, 0x1

    .line 393
    .line 394
    const/16 v46, 0x8

    .line 395
    .line 396
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v7

    .line 400
    if-ne v7, v4, :cond_14

    .line 401
    .line 402
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;

    .line 403
    .line 404
    invoke-direct {v7, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$1$1;-><init>(LX/3Bk;)V

    .line 405
    .line 406
    .line 407
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    :cond_14
    check-cast v7, LX/JDM;

    .line 411
    .line 412
    new-instance v14, LX/3PP;

    .line 413
    .line 414
    invoke-direct {v14, v3, v3, v7, v3}, LX/3PP;-><init>(LX/JDM;LX/JDM;LX/JDM;LX/JDM;)V

    .line 415
    .line 416
    .line 417
    and-int/lit8 v20, v1, 0xe

    .line 418
    .line 419
    const/4 v15, 0x4

    .line 420
    move/from16 v6, v20

    .line 421
    .line 422
    if-eq v6, v15, :cond_15

    .line 423
    .line 424
    and-int/lit8 v6, v1, 0x8

    .line 425
    .line 426
    if-eqz v6, :cond_2b

    .line 427
    .line 428
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 429
    .line 430
    .line 431
    move-result v6

    .line 432
    if-eqz v6, :cond_2b

    .line 433
    .line 434
    :cond_15
    const/4 v11, 0x1

    .line 435
    :goto_3
    invoke-static {v1}, LX/005;->A1J(I)Z

    .line 436
    .line 437
    .line 438
    move-result v6

    .line 439
    or-int/2addr v11, v6

    .line 440
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v7

    .line 444
    if-nez v11, :cond_16

    .line 445
    .line 446
    if-ne v7, v4, :cond_17

    .line 447
    .line 448
    :cond_16
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$2$1;

    .line 449
    .line 450
    move-object/from16 v6, p0

    .line 451
    .line 452
    invoke-direct {v7, v2, v6, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/3Bk;)V

    .line 453
    .line 454
    .line 455
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 456
    .line 457
    .line 458
    :cond_17
    check-cast v7, LX/JDM;

    .line 459
    .line 460
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$3;

    .line 461
    .line 462
    invoke-direct {v6, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$3;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;)V

    .line 463
    .line 464
    .line 465
    const v11, -0x15a5f43d

    .line 466
    .line 467
    .line 468
    invoke-static {v0, v6, v11}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 469
    .line 470
    .line 471
    move-result-object v51

    .line 472
    shr-int/lit8 v6, v1, 0xf

    .line 473
    .line 474
    and-int/lit16 v6, v6, 0x380

    .line 475
    .line 476
    or-int v6, v6, v31

    .line 477
    .line 478
    shl-int/lit8 v19, v1, 0xf

    .line 479
    .line 480
    const/high16 v11, 0x380000

    .line 481
    .line 482
    and-int v19, v19, v11

    .line 483
    .line 484
    or-int v6, v6, v19

    .line 485
    .line 486
    const v54, 0x180030

    .line 487
    .line 488
    .line 489
    const v55, 0xb620

    .line 490
    .line 491
    .line 492
    move-object/from16 v35, v18

    .line 493
    .line 494
    move-object/from16 v36, v7

    .line 495
    .line 496
    move-object/from16 v37, v73

    .line 497
    .line 498
    move-object/from16 v39, v16

    .line 499
    .line 500
    move-object/from16 v40, v3

    .line 501
    .line 502
    move/from16 v41, p1

    .line 503
    .line 504
    move-object/from16 v43, v28

    .line 505
    .line 506
    move-object/from16 v44, v3

    .line 507
    .line 508
    move-object/from16 v45, v3

    .line 509
    .line 510
    move/from16 v47, v27

    .line 511
    .line 512
    move/from16 v48, v27

    .line 513
    .line 514
    move-object/from16 v49, v14

    .line 515
    .line 516
    move-object/from16 v50, v3

    .line 517
    .line 518
    move-object/from16 v52, v0

    .line 519
    .line 520
    move/from16 v53, v6

    .line 521
    .line 522
    invoke-static/range {v35 .. v55}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 523
    .line 524
    .line 525
    sget v18, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->FieldGap:F

    .line 526
    .line 527
    move/from16 v6, v18

    .line 528
    .line 529
    invoke-static {v12, v6}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 530
    .line 531
    .line 532
    move-result-object v6

    .line 533
    const/4 v11, 0x6

    .line 534
    invoke-static {v0, v6}, LX/1Vt;->A04(LX/2d4;LX/3C1;)V

    .line 535
    .line 536
    .line 537
    invoke-static/range {v18 .. v18}, LX/Dn6;->A00(F)LX/CP5;

    .line 538
    .line 539
    .line 540
    move-result-object v7

    .line 541
    sget-object v6, LX/2Id;->A05:LX/2rU;

    .line 542
    .line 543
    invoke-static {v7, v0, v6, v11}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 544
    .line 545
    .line 546
    move-result-object v7

    .line 547
    invoke-static {v10}, LX/002;->A0J(LX/J7I;)I

    .line 548
    .line 549
    .line 550
    move-result v16

    .line 551
    invoke-static {v10}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 552
    .line 553
    .line 554
    move-result-object v14

    .line 555
    move-object/from16 v6, v28

    .line 556
    .line 557
    invoke-static {v0, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 558
    .line 559
    .line 560
    move-result-object v11

    .line 561
    move-object/from16 v6, v26

    .line 562
    .line 563
    invoke-static {v0, v10, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 564
    .line 565
    .line 566
    move-object/from16 v6, v25

    .line 567
    .line 568
    invoke-static {v0, v7, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 569
    .line 570
    .line 571
    move-object/from16 v6, v24

    .line 572
    .line 573
    invoke-static {v0, v14, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 574
    .line 575
    .line 576
    move-object/from16 v14, v23

    .line 577
    .line 578
    move-object/from16 v7, v22

    .line 579
    .line 580
    move/from16 v6, v16

    .line 581
    .line 582
    invoke-static {v7, v14, v0, v6}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 583
    .line 584
    .line 585
    move-object/from16 v6, v17

    .line 586
    .line 587
    invoke-static {v0, v11, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 588
    .line 589
    .line 590
    sget-object v17, LX/CgK;->A00:LX/CgK;

    .line 591
    .line 592
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiry:Ljava/lang/String;

    .line 593
    .line 594
    move-object/from16 v23, v6

    .line 595
    .line 596
    const v50, 0x7f12029e

    .line 597
    .line 598
    .line 599
    sget-object v54, LX/0Nq;->A06:LX/0PV;

    .line 600
    .line 601
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->expiryError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 602
    .line 603
    move-object/from16 v22, v6

    .line 604
    .line 605
    const/high16 v14, 0x3f800000    # 1.0f

    .line 606
    .line 607
    move-object/from16 v7, v17

    .line 608
    .line 609
    move/from16 v6, v21

    .line 610
    .line 611
    invoke-virtual {v7, v12, v14, v6}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 612
    .line 613
    .line 614
    move-result-object v55

    .line 615
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 616
    .line 617
    .line 618
    move-result-object v7

    .line 619
    if-ne v7, v4, :cond_18

    .line 620
    .line 621
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$1$1;

    .line 622
    .line 623
    move-object/from16 v6, v30

    .line 624
    .line 625
    invoke-direct {v7, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$1$1;-><init>(LX/3Bk;)V

    .line 626
    .line 627
    .line 628
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 629
    .line 630
    .line 631
    :cond_18
    check-cast v7, LX/JDM;

    .line 632
    .line 633
    new-instance v16, LX/3PP;

    .line 634
    .line 635
    move-object/from16 v6, v16

    .line 636
    .line 637
    invoke-direct {v6, v3, v3, v7, v3}, LX/3PP;-><init>(LX/JDM;LX/JDM;LX/JDM;LX/JDM;)V

    .line 638
    .line 639
    .line 640
    move/from16 v6, v20

    .line 641
    .line 642
    if-eq v6, v15, :cond_19

    .line 643
    .line 644
    and-int/lit8 v6, v1, 0x8

    .line 645
    .line 646
    if-eqz v6, :cond_2a

    .line 647
    .line 648
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 649
    .line 650
    .line 651
    move-result v6

    .line 652
    if-eqz v6, :cond_2a

    .line 653
    .line 654
    :cond_19
    const/4 v7, 0x1

    .line 655
    :goto_4
    invoke-static {v1}, LX/005;->A1L(I)Z

    .line 656
    .line 657
    .line 658
    move-result v6

    .line 659
    or-int/2addr v7, v6

    .line 660
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 661
    .line 662
    .line 663
    move-result-object v6

    .line 664
    if-nez v7, :cond_1a

    .line 665
    .line 666
    if-ne v6, v4, :cond_1b

    .line 667
    .line 668
    :cond_1a
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;

    .line 669
    .line 670
    move-object/from16 v11, v77

    .line 671
    .line 672
    move-object/from16 v7, v30

    .line 673
    .line 674
    invoke-direct {v6, v2, v11, v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/3Bk;)V

    .line 675
    .line 676
    .line 677
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 678
    .line 679
    .line 680
    :cond_1b
    check-cast v6, LX/JDM;

    .line 681
    .line 682
    shr-int/lit8 v7, v1, 0x12

    .line 683
    .line 684
    and-int/lit16 v7, v7, 0x380

    .line 685
    .line 686
    or-int v7, v7, v19

    .line 687
    .line 688
    const/high16 v66, 0x30000

    .line 689
    .line 690
    const v67, 0x13e20

    .line 691
    .line 692
    .line 693
    move-object/from16 v47, v23

    .line 694
    .line 695
    move-object/from16 v48, v6

    .line 696
    .line 697
    move-object/from16 v49, v72

    .line 698
    .line 699
    move-object/from16 v51, v22

    .line 700
    .line 701
    move-object/from16 v52, v3

    .line 702
    .line 703
    move/from16 v53, p1

    .line 704
    .line 705
    move-object/from16 v56, v3

    .line 706
    .line 707
    move-object/from16 v57, v3

    .line 708
    .line 709
    move/from16 v58, v27

    .line 710
    .line 711
    move/from16 v59, v27

    .line 712
    .line 713
    move/from16 v60, v27

    .line 714
    .line 715
    move-object/from16 v61, v16

    .line 716
    .line 717
    move-object/from16 v62, v13

    .line 718
    .line 719
    move-object/from16 v63, v3

    .line 720
    .line 721
    move-object/from16 v64, v0

    .line 722
    .line 723
    move/from16 v65, v7

    .line 724
    .line 725
    invoke-static/range {v47 .. v67}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 726
    .line 727
    .line 728
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCode:Ljava/lang/String;

    .line 729
    .line 730
    move-object/from16 v22, v6

    .line 731
    .line 732
    const v38, 0x7f1202a9

    .line 733
    .line 734
    .line 735
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->securityCodeError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 736
    .line 737
    move-object/from16 v16, v6

    .line 738
    .line 739
    move-object/from16 v7, v17

    .line 740
    .line 741
    move/from16 v6, v21

    .line 742
    .line 743
    invoke-virtual {v7, v12, v14, v6}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 744
    .line 745
    .line 746
    move-result-object v43

    .line 747
    move/from16 v6, v20

    .line 748
    .line 749
    if-eq v6, v15, :cond_1c

    .line 750
    .line 751
    and-int/lit8 v6, v1, 0x8

    .line 752
    .line 753
    if-eqz v6, :cond_29

    .line 754
    .line 755
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 756
    .line 757
    .line 758
    move-result v6

    .line 759
    if-eqz v6, :cond_29

    .line 760
    .line 761
    :cond_1c
    const/4 v6, 0x1

    .line 762
    :goto_5
    invoke-static {v0, v8, v6}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 763
    .line 764
    .line 765
    move-result v7

    .line 766
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 767
    .line 768
    .line 769
    move-result-object v6

    .line 770
    if-nez v7, :cond_1d

    .line 771
    .line 772
    if-ne v6, v4, :cond_1e

    .line 773
    .line 774
    :cond_1d
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$3$1;

    .line 775
    .line 776
    move-object/from16 v7, v29

    .line 777
    .line 778
    invoke-direct {v6, v2, v7, v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/3Bk;LX/1Ju;)V

    .line 779
    .line 780
    .line 781
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 782
    .line 783
    .line 784
    :cond_1e
    check-cast v6, LX/JDM;

    .line 785
    .line 786
    new-instance v13, LX/3PP;

    .line 787
    .line 788
    invoke-direct {v13, v3, v3, v6, v3}, LX/3PP;-><init>(LX/JDM;LX/JDM;LX/JDM;LX/JDM;)V

    .line 789
    .line 790
    .line 791
    move/from16 v6, v20

    .line 792
    .line 793
    if-eq v6, v15, :cond_1f

    .line 794
    .line 795
    and-int/lit8 v6, v1, 0x8

    .line 796
    .line 797
    if-eqz v6, :cond_28

    .line 798
    .line 799
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 800
    .line 801
    .line 802
    move-result v6

    .line 803
    if-eqz v6, :cond_28

    .line 804
    .line 805
    :cond_1f
    const/4 v7, 0x1

    .line 806
    :goto_6
    invoke-static {v1}, LX/005;->A1N(I)Z

    .line 807
    .line 808
    .line 809
    move-result v6

    .line 810
    invoke-static {v0, v8, v7, v6}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 811
    .line 812
    .line 813
    move-result v6

    .line 814
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 815
    .line 816
    .line 817
    move-result-object v7

    .line 818
    if-nez v6, :cond_20

    .line 819
    .line 820
    if-ne v7, v4, :cond_21

    .line 821
    .line 822
    :cond_20
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$4$1;

    .line 823
    .line 824
    move-object/from16 v11, v76

    .line 825
    .line 826
    move-object/from16 v6, v29

    .line 827
    .line 828
    invoke-direct {v7, v2, v11, v6, v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$4$4$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/3Bk;LX/1Ju;)V

    .line 829
    .line 830
    .line 831
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 832
    .line 833
    .line 834
    :cond_21
    check-cast v7, LX/JDM;

    .line 835
    .line 836
    shr-int/lit8 v6, v1, 0x15

    .line 837
    .line 838
    and-int/lit16 v6, v6, 0x380

    .line 839
    .line 840
    or-int v6, v6, v32

    .line 841
    .line 842
    or-int v6, v6, v19

    .line 843
    .line 844
    const v54, 0x30030

    .line 845
    .line 846
    .line 847
    const v55, 0x13620

    .line 848
    .line 849
    .line 850
    move-object/from16 v35, v22

    .line 851
    .line 852
    move-object/from16 v36, v7

    .line 853
    .line 854
    move-object/from16 v37, v71

    .line 855
    .line 856
    move-object/from16 v39, v16

    .line 857
    .line 858
    move-object/from16 v42, v3

    .line 859
    .line 860
    move/from16 v47, v27

    .line 861
    .line 862
    move/from16 v48, v27

    .line 863
    .line 864
    move-object/from16 v49, v13

    .line 865
    .line 866
    move-object/from16 v50, v30

    .line 867
    .line 868
    move-object/from16 v51, v3

    .line 869
    .line 870
    move-object/from16 v52, v0

    .line 871
    .line 872
    move/from16 v53, v6

    .line 873
    .line 874
    invoke-static/range {v35 .. v55}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 875
    .line 876
    .line 877
    move/from16 v6, v21

    .line 878
    .line 879
    invoke-static {v10, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 880
    .line 881
    .line 882
    move/from16 v6, v18

    .line 883
    .line 884
    invoke-static {v0, v12, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 885
    .line 886
    .line 887
    iget-boolean v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isCountrySelectable:Z

    .line 888
    .line 889
    if-eqz v6, :cond_27

    .line 890
    .line 891
    const v6, -0x1b783854

    .line 892
    .line 893
    .line 894
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 895
    .line 896
    .line 897
    iget-object v13, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->countries:LX/Ddn;

    .line 898
    .line 899
    iget-object v11, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->billingCountry:Ljava/lang/String;

    .line 900
    .line 901
    shl-int/lit8 v6, v1, 0x3

    .line 902
    .line 903
    and-int/lit16 v6, v6, 0x380

    .line 904
    .line 905
    or-int/lit16 v7, v6, 0x6000

    .line 906
    .line 907
    shr-int/lit8 v6, v1, 0x9

    .line 908
    .line 909
    and-int/lit16 v6, v6, 0x1c00

    .line 910
    .line 911
    or-int/2addr v7, v6

    .line 912
    move-object/from16 v35, v13

    .line 913
    .line 914
    move-object/from16 v36, v11

    .line 915
    .line 916
    move/from16 v37, p1

    .line 917
    .line 918
    move-object/from16 v38, v74

    .line 919
    .line 920
    move-object/from16 v39, v28

    .line 921
    .line 922
    move-object/from16 v40, v0

    .line 923
    .line 924
    move/from16 v41, v7

    .line 925
    .line 926
    move/from16 v42, v27

    .line 927
    .line 928
    invoke-static/range {v35 .. v42}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvCountryField(LX/Ddn;Ljava/lang/String;ZLX/JDM;LX/3C1;LX/2d4;II)V

    .line 929
    .line 930
    .line 931
    move/from16 v6, v18

    .line 932
    .line 933
    invoke-static {v0, v12, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 934
    .line 935
    .line 936
    :goto_7
    move/from16 v6, v27

    .line 937
    .line 938
    invoke-static {v10, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 939
    .line 940
    .line 941
    iget-object v7, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 942
    .line 943
    if-nez v7, :cond_23

    .line 944
    .line 945
    const v1, -0x1b72ebd7

    .line 946
    .line 947
    .line 948
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 949
    .line 950
    .line 951
    :goto_8
    move/from16 v1, v27

    .line 952
    .line 953
    invoke-static {v10, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 954
    .line 955
    .line 956
    move/from16 v1, v21

    .line 957
    .line 958
    invoke-static {v10, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 959
    .line 960
    .line 961
    :goto_9
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 962
    .line 963
    .line 964
    move-result-object v1

    .line 965
    if-eqz v1, :cond_22

    .line 966
    .line 967
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$2;

    .line 968
    .line 969
    move-object v6, v0

    .line 970
    move-object v7, v2

    .line 971
    move/from16 v8, p1

    .line 972
    .line 973
    move-object/from16 v9, p0

    .line 974
    .line 975
    move-object/from16 v10, v77

    .line 976
    .line 977
    move-object/from16 v11, v76

    .line 978
    .line 979
    move-object/from16 v12, v75

    .line 980
    .line 981
    move-object/from16 v13, v74

    .line 982
    .line 983
    move-object/from16 v14, v73

    .line 984
    .line 985
    move-object/from16 v15, v72

    .line 986
    .line 987
    move-object/from16 v16, v71

    .line 988
    .line 989
    move-object/from16 v17, v70

    .line 990
    .line 991
    move-object/from16 v18, v69

    .line 992
    .line 993
    move-object/from16 v19, v34

    .line 994
    .line 995
    move/from16 v20, v5

    .line 996
    .line 997
    move/from16 v21, v33

    .line 998
    .line 999
    move/from16 v22, v68

    .line 1000
    .line 1001
    invoke-direct/range {v6 .. v22}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;III)V

    .line 1002
    .line 1003
    .line 1004
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 1005
    .line 1006
    :cond_22
    return-void

    .line 1007
    :cond_23
    const v6, -0x1b72ebd6

    .line 1008
    .line 1009
    .line 1010
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 1011
    .line 1012
    .line 1013
    iget-object v15, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zip:Ljava/lang/String;

    .line 1014
    .line 1015
    iget-object v14, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->placeholder:Ljava/lang/String;

    .line 1016
    .line 1017
    const v38, 0x7f1202ae

    .line 1018
    .line 1019
    .line 1020
    iget-object v13, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->label:Ljava/lang/String;

    .line 1021
    .line 1022
    sget-object v42, LX/0Nq;->A0G:LX/0PV;

    .line 1023
    .line 1024
    iget-object v11, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1025
    .line 1026
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->zipServerError:Ljava/lang/String;

    .line 1027
    .line 1028
    iget-object v12, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;->keyboardType:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 1029
    .line 1030
    sget-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;->NUMBER:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPostalKeyboardType;

    .line 1031
    .line 1032
    const/16 v46, 0x1

    .line 1033
    .line 1034
    if-ne v12, v7, :cond_24

    .line 1035
    .line 1036
    const/16 v46, 0x3

    .line 1037
    .line 1038
    :cond_24
    const/16 v48, 0x7

    .line 1039
    .line 1040
    invoke-interface {v0, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 1041
    .line 1042
    .line 1043
    move-result v12

    .line 1044
    invoke-static {v9}, LX/004;->A1S(I)Z

    .line 1045
    .line 1046
    .line 1047
    move-result v7

    .line 1048
    or-int/2addr v12, v7

    .line 1049
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v7

    .line 1053
    if-nez v12, :cond_25

    .line 1054
    .line 1055
    if-ne v7, v4, :cond_26

    .line 1056
    .line 1057
    :cond_25
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$5$1$1;

    .line 1058
    .line 1059
    move-object/from16 v4, v69

    .line 1060
    .line 1061
    invoke-direct {v7, v8, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCardFields$1$5$1$1;-><init>(LX/1Ju;Lkotlin/jvm/functions/Function0;)V

    .line 1062
    .line 1063
    .line 1064
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1065
    .line 1066
    .line 1067
    :cond_26
    check-cast v7, LX/JDM;

    .line 1068
    .line 1069
    new-instance v4, LX/3PP;

    .line 1070
    .line 1071
    invoke-direct {v4, v7, v3, v3, v3}, LX/3PP;-><init>(LX/JDM;LX/JDM;LX/JDM;LX/JDM;)V

    .line 1072
    .line 1073
    .line 1074
    shr-int/lit8 v1, v1, 0xc

    .line 1075
    .line 1076
    and-int/lit8 v53, v1, 0x70

    .line 1077
    .line 1078
    or-int v53, v53, v31

    .line 1079
    .line 1080
    shl-int/lit8 v1, v9, 0x6

    .line 1081
    .line 1082
    and-int/lit16 v1, v1, 0x380

    .line 1083
    .line 1084
    or-int v53, v53, v1

    .line 1085
    .line 1086
    or-int v53, v53, v19

    .line 1087
    .line 1088
    const v54, 0x30d80

    .line 1089
    .line 1090
    .line 1091
    const/high16 v55, 0x10000

    .line 1092
    .line 1093
    move-object/from16 v35, v15

    .line 1094
    .line 1095
    move-object/from16 v36, v75

    .line 1096
    .line 1097
    move-object/from16 v37, v70

    .line 1098
    .line 1099
    move-object/from16 v39, v11

    .line 1100
    .line 1101
    move-object/from16 v40, v6

    .line 1102
    .line 1103
    move/from16 v41, p1

    .line 1104
    .line 1105
    move-object/from16 v43, v28

    .line 1106
    .line 1107
    move-object/from16 v44, v14

    .line 1108
    .line 1109
    move-object/from16 v45, v13

    .line 1110
    .line 1111
    move/from16 v47, v21

    .line 1112
    .line 1113
    move-object/from16 v49, v4

    .line 1114
    .line 1115
    move-object/from16 v50, v29

    .line 1116
    .line 1117
    invoke-static/range {v35 .. v55}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 1118
    .line 1119
    .line 1120
    goto/16 :goto_8

    .line 1121
    .line 1122
    :cond_27
    const v6, -0x1b73ec6f

    .line 1123
    .line 1124
    .line 1125
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 1126
    .line 1127
    .line 1128
    goto/16 :goto_7

    .line 1129
    .line 1130
    :cond_28
    const/4 v7, 0x0

    .line 1131
    goto/16 :goto_6

    .line 1132
    .line 1133
    :cond_29
    const/4 v6, 0x0

    .line 1134
    goto/16 :goto_5

    .line 1135
    .line 1136
    :cond_2a
    const/4 v7, 0x0

    .line 1137
    goto/16 :goto_4

    .line 1138
    .line 1139
    :cond_2b
    const/4 v11, 0x0

    .line 1140
    goto/16 :goto_3
.end method

.method public static final CcvCheckoutUnavailable(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 45
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    const v0, -0x68709fa2

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 p3, p0

    .line 15
    .line 16
    if-nez v0, :cond_4

    .line 17
    .line 18
    move-object/from16 v0, p3

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int v4, v2, v0

    .line 25
    .line 26
    :goto_0
    move/from16 v15, p4

    .line 27
    .line 28
    and-int/lit8 v6, p4, 0x2

    .line 29
    .line 30
    if-eqz v6, :cond_3

    .line 31
    .line 32
    or-int/lit8 v4, v4, 0x30

    .line 33
    .line 34
    :cond_0
    :goto_1
    and-int/lit8 v5, v4, 0x13

    .line 35
    .line 36
    const/16 v0, 0x12

    .line 37
    .line 38
    const/4 v13, 0x1

    .line 39
    const/4 v11, 0x0

    .line 40
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_7

    .line 49
    .line 50
    if-eqz v6, :cond_1

    .line 51
    .line 52
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 53
    .line 54
    :cond_1
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 59
    .line 60
    if-ne v0, v12, :cond_2

    .line 61
    .line 62
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$1$1;

    .line 63
    .line 64
    invoke-interface {v1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    check-cast v0, LX/JDM;

    .line 68
    .line 69
    const/4 v14, 0x0

    .line 70
    invoke-static {v3, v0, v11}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 71
    .line 72
    .line 73
    move-result-object v6

    .line 74
    sget-object v7, LX/Dn6;->A02:LX/1Yw;

    .line 75
    .line 76
    sget-object v5, LX/2Id;->A00:LX/2sS;

    .line 77
    .line 78
    const/16 v0, 0x36

    .line 79
    .line 80
    invoke-static {v7, v1, v5, v0}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    move-object v0, v1

    .line 85
    check-cast v0, LX/J7I;

    .line 86
    .line 87
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 88
    .line 89
    .line 90
    move-result v9

    .line 91
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 92
    .line 93
    .line 94
    move-result-object v8

    .line 95
    invoke-static {v1, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 96
    .line 97
    .line 98
    move-result-object v7

    .line 99
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 100
    .line 101
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 102
    .line 103
    if-nez v5, :cond_5

    .line 104
    .line 105
    invoke-static {}, LX/1VY;->A00()V

    .line 106
    .line 107
    .line 108
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0

    .line 113
    :cond_3
    and-int/lit8 v0, v2, 0x30

    .line 114
    .line 115
    if-nez v0, :cond_0

    .line 116
    .line 117
    invoke-static {v1, v3}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    or-int/2addr v4, v0

    .line 122
    goto :goto_1

    .line 123
    :cond_4
    move v4, v2

    .line 124
    goto :goto_0

    .line 125
    :cond_5
    invoke-static {v1, v0, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v1, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 129
    .line 130
    .line 131
    const v5, 0x7f1202ad

    .line 132
    .line 133
    .line 134
    invoke-static {v1, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v16

    .line 138
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 139
    .line 140
    const/4 v8, 0x6

    .line 141
    invoke-virtual {v9, v1, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    iget-object v5, v5, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title3Emphasized:LX/2hg;

    .line 146
    .line 147
    move-object/from16 v20, v5

    .line 148
    .line 149
    invoke-static {v1, v9}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 150
    .line 151
    .line 152
    move-result-wide v18

    .line 153
    const/4 v6, 0x3

    .line 154
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 155
    .line 156
    sget-object v7, LX/2sI;->A02:LX/2wD;

    .line 157
    .line 158
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v10

    .line 162
    if-ne v10, v12, :cond_6

    .line 163
    .line 164
    sget-object v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$2$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$2$1$1;

    .line 165
    .line 166
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    :cond_6
    invoke-static {v7, v10, v11}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 170
    .line 171
    .line 172
    move-result-object v17

    .line 173
    new-instance v10, LX/2wS;

    .line 174
    .line 175
    invoke-direct {v10, v6}, LX/2wS;-><init>(I)V

    .line 176
    .line 177
    .line 178
    const/16 v34, 0x3fb0

    .line 179
    .line 180
    move-object/from16 v21, v14

    .line 181
    .line 182
    move-object/from16 v22, v14

    .line 183
    .line 184
    move-object/from16 v23, v10

    .line 185
    .line 186
    move/from16 v24, v11

    .line 187
    .line 188
    move/from16 v25, v11

    .line 189
    .line 190
    move/from16 v26, v11

    .line 191
    .line 192
    move/from16 v27, v11

    .line 193
    .line 194
    move-object/from16 v28, v14

    .line 195
    .line 196
    move-object/from16 v29, v14

    .line 197
    .line 198
    move-object/from16 v30, v14

    .line 199
    .line 200
    move-object/from16 v31, v1

    .line 201
    .line 202
    move/from16 v32, v11

    .line 203
    .line 204
    move/from16 v33, v11

    .line 205
    .line 206
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 207
    .line 208
    .line 209
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 210
    .line 211
    invoke-static {v1, v5, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 212
    .line 213
    .line 214
    const v10, 0x7f1202ab

    .line 215
    .line 216
    .line 217
    invoke-static {v1, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v16

    .line 221
    invoke-virtual {v9, v1, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 222
    .line 223
    .line 224
    move-result-object v8

    .line 225
    iget-object v10, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineRegular:LX/2hg;

    .line 226
    .line 227
    invoke-static {v1, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 228
    .line 229
    .line 230
    move-result-wide v18

    .line 231
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 232
    .line 233
    invoke-static {v7, v8}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 234
    .line 235
    .line 236
    move-result-object v17

    .line 237
    new-instance v8, LX/2wS;

    .line 238
    .line 239
    invoke-direct {v8, v6}, LX/2wS;-><init>(I)V

    .line 240
    .line 241
    .line 242
    move-object/from16 v20, v10

    .line 243
    .line 244
    move-object/from16 v23, v8

    .line 245
    .line 246
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 247
    .line 248
    .line 249
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 250
    .line 251
    invoke-static {v1, v5, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 252
    .line 253
    .line 254
    const v5, 0x7f1202ac

    .line 255
    .line 256
    .line 257
    invoke-static {v1, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v17

    .line 261
    sget-object v6, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 262
    .line 263
    const/16 v5, 0x30

    .line 264
    .line 265
    invoke-virtual {v6, v14, v1, v5, v13}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->primary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 266
    .line 267
    .line 268
    move-result-object v20

    .line 269
    shl-int/lit8 p0, v4, 0xc

    .line 270
    .line 271
    const v4, 0xe000

    .line 272
    .line 273
    .line 274
    and-int p0, p0, v4

    .line 275
    .line 276
    const p2, 0x7ffbfe5

    .line 277
    .line 278
    .line 279
    const/16 v44, 0xc00

    .line 280
    .line 281
    move-object/from16 v18, v14

    .line 282
    .line 283
    move/from16 v23, v11

    .line 284
    .line 285
    move-object/from16 v30, p3

    .line 286
    .line 287
    move-object/from16 v31, v14

    .line 288
    .line 289
    move-object/from16 v32, v14

    .line 290
    .line 291
    move-object/from16 v33, v14

    .line 292
    .line 293
    move-object/from16 v34, v14

    .line 294
    .line 295
    move-object/from16 v35, v14

    .line 296
    .line 297
    move-object/from16 v36, v14

    .line 298
    .line 299
    move-object/from16 v37, v14

    .line 300
    .line 301
    move-object/from16 v38, v14

    .line 302
    .line 303
    move/from16 v39, v11

    .line 304
    .line 305
    move/from16 v40, v11

    .line 306
    .line 307
    move/from16 v41, v11

    .line 308
    .line 309
    move/from16 v42, v11

    .line 310
    .line 311
    move-object/from16 v43, v1

    .line 312
    .line 313
    move/from16 p1, v11

    .line 314
    .line 315
    move-object/from16 v16, v14

    .line 316
    .line 317
    move-object/from16 v19, v7

    .line 318
    .line 319
    invoke-static/range {v16 .. v47}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 320
    .line 321
    .line 322
    invoke-static {v0, v13}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 323
    .line 324
    .line 325
    goto :goto_2

    .line 326
    :cond_7
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 327
    .line 328
    .line 329
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 330
    .line 331
    .line 332
    move-result-object v4

    .line 333
    if-eqz v4, :cond_8

    .line 334
    .line 335
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$3;

    .line 336
    .line 337
    move-object/from16 v0, p3

    .line 338
    .line 339
    invoke-direct {v1, v0, v3, v2, v15}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCheckoutUnavailable$3;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 340
    .line 341
    .line 342
    iput-object v1, v4, LX/J7V;->A06:LX/JDN;

    .line 343
    .line 344
    :cond_8
    return-void
.end method

.method public static final CcvCountryField(LX/Ddn;Ljava/lang/String;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 42
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v18, p4

    .line 1
    .line 2
    const v0, 0xd3f38e

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p5

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v0, p6

    .line 11
    .line 12
    and-int/lit8 v2, p6, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v2, :cond_10

    .line 17
    .line 18
    invoke-static {v1, v8}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    or-int v5, v5, p6

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v2, p6, 0x30

    .line 25
    .line 26
    move-object/from16 p6, p1

    .line 27
    .line 28
    if-nez v2, :cond_0

    .line 29
    .line 30
    move-object/from16 v2, p6

    .line 31
    .line 32
    invoke-static {v1, v2}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    or-int/2addr v5, v2

    .line 37
    :cond_0
    and-int/lit16 v2, v0, 0x180

    .line 38
    .line 39
    move/from16 p5, p2

    .line 40
    .line 41
    if-nez v2, :cond_1

    .line 42
    .line 43
    move/from16 v2, p5

    .line 44
    .line 45
    invoke-static {v1, v2}, LX/004;->A0k(LX/2d4;Z)I

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    or-int/2addr v5, v2

    .line 50
    :cond_1
    and-int/lit16 v2, v0, 0xc00

    .line 51
    .line 52
    move-object/from16 p4, p3

    .line 53
    .line 54
    if-nez v2, :cond_2

    .line 55
    .line 56
    move-object/from16 v2, p4

    .line 57
    .line 58
    invoke-static {v1, v2}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    or-int/2addr v5, v2

    .line 63
    :cond_2
    move/from16 p3, p7

    .line 64
    .line 65
    and-int/lit8 v4, p7, 0x10

    .line 66
    .line 67
    if-eqz v4, :cond_f

    .line 68
    .line 69
    or-int/lit16 v5, v5, 0x6000

    .line 70
    .line 71
    :cond_3
    :goto_1
    and-int/lit16 v3, v5, 0x2493

    .line 72
    .line 73
    const/16 v2, 0x2492

    .line 74
    .line 75
    const/16 v17, 0x0

    .line 76
    .line 77
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    invoke-static {v2, v1, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    if-eqz v2, :cond_18

    .line 86
    .line 87
    if-eqz v4, :cond_4

    .line 88
    .line 89
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 90
    .line 91
    :cond_4
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 96
    .line 97
    move/from16 v2, v17

    .line 98
    .line 99
    invoke-static {v1, v3, v4, v2}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 104
    .line 105
    sget-object v2, LX/3Fe;->A05:LX/Ip3;

    .line 106
    .line 107
    invoke-interface {v1, v2}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v9

    .line 111
    check-cast v9, LX/1Ju;

    .line 112
    .line 113
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    invoke-static {v1, v2, v4}, LX/004;->A1C(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    check-cast v7, LX/3Gw;

    .line 122
    .line 123
    const v2, 0x7f12028f

    .line 124
    .line 125
    .line 126
    invoke-static {v1, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v13

    .line 130
    invoke-interface {v1, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v6

    .line 134
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    if-nez v6, :cond_5

    .line 139
    .line 140
    if-ne v2, v4, :cond_6

    .line 141
    .line 142
    :cond_5
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$openMenu$2$1;

    .line 143
    .line 144
    invoke-direct {v2, v9, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$openMenu$2$1;-><init>(LX/1Ju;Landroidx/compose/runtime/MutableState;)V

    .line 145
    .line 146
    .line 147
    invoke-interface {v1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_6
    invoke-static {v1, v2}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 151
    .line 152
    .line 153
    move-result-object v14

    .line 154
    invoke-interface {v1, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v6

    .line 158
    invoke-static {v5}, LX/004;->A1S(I)Z

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    or-int/2addr v2, v6

    .line 163
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v6

    .line 167
    if-nez v2, :cond_7

    .line 168
    .line 169
    if-ne v6, v4, :cond_b

    .line 170
    .line 171
    :cond_7
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 172
    .line 173
    .line 174
    move-result-object v10

    .line 175
    :cond_8
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 176
    .line 177
    .line 178
    move-result v2

    .line 179
    if-eqz v2, :cond_e

    .line 180
    .line 181
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v9

    .line 185
    move-object v2, v9

    .line 186
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 187
    .line 188
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 189
    .line 190
    move-object/from16 v2, p6

    .line 191
    .line 192
    invoke-static {v6, v2}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v2

    .line 196
    if-eqz v2, :cond_8

    .line 197
    .line 198
    :goto_2
    check-cast v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 199
    .line 200
    if-eqz v9, :cond_9

    .line 201
    .line 202
    iget-object v6, v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 203
    .line 204
    if-nez v6, :cond_a

    .line 205
    .line 206
    :cond_9
    invoke-static/range {p6 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->countryDisplayName(Ljava/lang/String;)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v6

    .line 210
    :cond_a
    invoke-interface {v1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    :cond_b
    check-cast v6, Ljava/lang/String;

    .line 214
    .line 215
    invoke-static/range {p5 .. p5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 216
    .line 217
    .line 218
    move-result-object v11

    .line 219
    invoke-static {v5}, LX/005;->A1J(I)Z

    .line 220
    .line 221
    .line 222
    move-result v2

    .line 223
    invoke-static {v1, v14, v2}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 224
    .line 225
    .line 226
    move-result v2

    .line 227
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v9

    .line 231
    if-nez v2, :cond_c

    .line 232
    .line 233
    if-ne v9, v4, :cond_d

    .line 234
    .line 235
    :cond_c
    const/4 v10, 0x0

    .line 236
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$1$1;

    .line 237
    .line 238
    move/from16 v2, p5

    .line 239
    .line 240
    invoke-direct {v9, v7, v2, v14, v10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$1$1;-><init>(LX/3Gw;ZLX/16A;LX/2M4;)V

    .line 241
    .line 242
    .line 243
    invoke-interface {v1, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    :cond_d
    invoke-static {v1, v9, v7, v11}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    invoke-static/range {v17 .. v17}, LX/001;->A0g(Z)LX/3BI;

    .line 250
    .line 251
    .line 252
    move-result-object v16

    .line 253
    move-object v9, v1

    .line 254
    check-cast v9, LX/J7I;

    .line 255
    .line 256
    invoke-static {v9}, LX/003;->A0F(LX/J7I;)I

    .line 257
    .line 258
    .line 259
    move-result v15

    .line 260
    invoke-static {v9}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 261
    .line 262
    .line 263
    move-result-object v12

    .line 264
    move-object/from16 v2, v18

    .line 265
    .line 266
    invoke-static {v1, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 267
    .line 268
    .line 269
    move-result-object v11

    .line 270
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 271
    .line 272
    iget-object v2, v9, LX/J7I;->A0V:LX/3DJ;

    .line 273
    .line 274
    if-nez v2, :cond_11

    .line 275
    .line 276
    invoke-static {}, LX/1VY;->A00()V

    .line 277
    .line 278
    .line 279
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    throw v0

    .line 284
    :cond_e
    const/4 v9, 0x0

    .line 285
    goto :goto_2

    .line 286
    :cond_f
    and-int/lit16 v2, v0, 0x6000

    .line 287
    .line 288
    if-nez v2, :cond_3

    .line 289
    .line 290
    move-object/from16 v2, v18

    .line 291
    .line 292
    invoke-static {v1, v2}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 293
    .line 294
    .line 295
    move-result v2

    .line 296
    or-int/2addr v5, v2

    .line 297
    goto/16 :goto_1

    .line 298
    .line 299
    :cond_10
    move v5, v0

    .line 300
    goto/16 :goto_0

    .line 301
    .line 302
    :cond_11
    invoke-static {v1, v9, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 303
    .line 304
    .line 305
    move-object/from16 v2, v16

    .line 306
    .line 307
    invoke-static {v1, v2, v12, v11, v15}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 308
    .line 309
    .line 310
    sget-object v12, LX/3Jn;->A00:LX/3Jn;

    .line 311
    .line 312
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 313
    .line 314
    sget-object v10, LX/2sI;->A02:LX/2wD;

    .line 315
    .line 316
    invoke-static {v1, v13, v6, v14}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 317
    .line 318
    .line 319
    move-result v15

    .line 320
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v2

    .line 324
    if-nez v15, :cond_12

    .line 325
    .line 326
    if-ne v2, v4, :cond_13

    .line 327
    .line 328
    :cond_12
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$1$1;

    .line 329
    .line 330
    invoke-direct {v2, v13, v6, v14}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$1$1;-><init>(Ljava/lang/String;Ljava/lang/String;LX/16A;)V

    .line 331
    .line 332
    .line 333
    invoke-interface {v1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    :cond_13
    check-cast v2, LX/JDM;

    .line 337
    .line 338
    invoke-static {v10, v2}, LX/36n;->A00(LX/3C1;LX/JDM;)LX/3C1;

    .line 339
    .line 340
    .line 341
    move-result-object v21

    .line 342
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 343
    .line 344
    const/4 v10, 0x6

    .line 345
    invoke-virtual {v2, v1, v10}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 346
    .line 347
    .line 348
    move-result-object v2

    .line 349
    iget-object v15, v2, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->bodyRegular:LX/2hg;

    .line 350
    .line 351
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$2;

    .line 352
    .line 353
    invoke-direct {v2, v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$2;-><init>(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    const v13, -0x26ee680

    .line 357
    .line 358
    .line 359
    const/4 v14, 0x1

    .line 360
    invoke-static {v1, v2, v13}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 361
    .line 362
    .line 363
    move-result-object v22

    .line 364
    sget-object v31, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt;->lambda$692108522:LX/JDN;

    .line 365
    .line 366
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    move-result-object v2

    .line 370
    if-ne v2, v4, :cond_14

    .line 371
    .line 372
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$3$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$3$1;

    .line 373
    .line 374
    invoke-interface {v1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 375
    .line 376
    .line 377
    :cond_14
    check-cast v2, LX/JDM;

    .line 378
    .line 379
    shl-int/lit8 p0, v5, 0x9

    .line 380
    .line 381
    const/high16 v13, 0x70000

    .line 382
    .line 383
    and-int p0, p0, v13

    .line 384
    .line 385
    const v13, 0x186180

    .line 386
    .line 387
    .line 388
    or-int p0, p0, v13

    .line 389
    .line 390
    const p2, 0xe2e72

    .line 391
    .line 392
    .line 393
    const/16 v20, 0x0

    .line 394
    .line 395
    const v41, 0x6000c00

    .line 396
    .line 397
    .line 398
    move-object/from16 v23, v20

    .line 399
    .line 400
    move-object/from16 v24, v20

    .line 401
    .line 402
    move-object/from16 v25, v20

    .line 403
    .line 404
    move-object/from16 v26, v15

    .line 405
    .line 406
    move/from16 v27, v14

    .line 407
    .line 408
    move/from16 v28, v17

    .line 409
    .line 410
    move/from16 v29, v17

    .line 411
    .line 412
    move-object/from16 v30, v20

    .line 413
    .line 414
    move-object/from16 v32, v20

    .line 415
    .line 416
    move-object/from16 v33, v7

    .line 417
    .line 418
    move/from16 v34, p5

    .line 419
    .line 420
    move/from16 v35, v14

    .line 421
    .line 422
    move/from16 v36, v17

    .line 423
    .line 424
    move/from16 v37, v17

    .line 425
    .line 426
    move-object/from16 v38, v20

    .line 427
    .line 428
    move-object/from16 v39, v2

    .line 429
    .line 430
    move-object/from16 v40, v1

    .line 431
    .line 432
    move/from16 p1, v10

    .line 433
    .line 434
    move-object/from16 v19, v6

    .line 435
    .line 436
    invoke-static/range {v19 .. v44}, Lcom/facebook/aura/vds/compose/input/AuraTextInputKt;->AuraTextInput(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/JDN;LX/3PN;LX/3PP;LX/2WL;LX/2hg;ZIILX/JDN;LX/JDN;Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;LX/3Gw;ZZZZLX/2bW;LX/JDM;LX/2d4;IIII)V

    .line 437
    .line 438
    .line 439
    invoke-virtual {v12, v11}, LX/3Jn;->AQU(LX/3C1;)LX/3C1;

    .line 440
    .line 441
    .line 442
    move-result-object v21

    .line 443
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 444
    .line 445
    .line 446
    move-result v24

    .line 447
    invoke-interface {v1, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 448
    .line 449
    .line 450
    move-result v6

    .line 451
    invoke-static {v5}, LX/005;->A1L(I)Z

    .line 452
    .line 453
    .line 454
    move-result v2

    .line 455
    or-int/2addr v6, v2

    .line 456
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v5

    .line 460
    if-nez v6, :cond_15

    .line 461
    .line 462
    if-ne v5, v4, :cond_16

    .line 463
    .line 464
    :cond_15
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$4$1;

    .line 465
    .line 466
    move-object/from16 v2, p4

    .line 467
    .line 468
    invoke-direct {v5, v8, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$4$1;-><init>(LX/Ddn;Landroidx/compose/runtime/MutableState;LX/JDM;)V

    .line 469
    .line 470
    .line 471
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 472
    .line 473
    .line 474
    :cond_16
    check-cast v5, LX/JDM;

    .line 475
    .line 476
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v2

    .line 480
    if-ne v2, v4, :cond_17

    .line 481
    .line 482
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$5$1;

    .line 483
    .line 484
    invoke-direct {v2, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$5$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 485
    .line 486
    .line 487
    invoke-interface {v1, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 488
    .line 489
    .line 490
    :cond_17
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 491
    .line 492
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;

    .line 493
    .line 494
    move-object/from16 v4, p6

    .line 495
    .line 496
    invoke-direct {v3, v8, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;-><init>(LX/Ddn;Ljava/lang/String;)V

    .line 497
    .line 498
    .line 499
    const/16 v40, 0x7ef0

    .line 500
    .line 501
    const-wide/16 v26, 0x0

    .line 502
    .line 503
    const/16 v38, 0x180

    .line 504
    .line 505
    move-object/from16 v22, v5

    .line 506
    .line 507
    move-object/from16 v23, v2

    .line 508
    .line 509
    move-object/from16 v28, v20

    .line 510
    .line 511
    move-object/from16 v30, v3

    .line 512
    .line 513
    move/from16 v31, v17

    .line 514
    .line 515
    move/from16 v32, v17

    .line 516
    .line 517
    move-object/from16 v33, v20

    .line 518
    .line 519
    move-object/from16 v34, v20

    .line 520
    .line 521
    move-object/from16 v35, v20

    .line 522
    .line 523
    move-object/from16 v37, v1

    .line 524
    .line 525
    move/from16 v39, v17

    .line 526
    .line 527
    invoke-static/range {v21 .. v40}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuKt;->AuraContextMenu-Q3lI2Mc(LX/3C1;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuStyle;JLX/3Lr;ZLX/JDN;ZZLX/Ddn;LX/1Ot;LX/JDM;ZLX/2d4;III)V

    .line 528
    .line 529
    .line 530
    invoke-static {v9, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 531
    .line 532
    .line 533
    goto :goto_3

    .line 534
    :cond_18
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 535
    .line 536
    .line 537
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 538
    .line 539
    .line 540
    move-result-object v2

    .line 541
    if-eqz v2, :cond_19

    .line 542
    .line 543
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$3;

    .line 544
    .line 545
    move-object/from16 v38, v1

    .line 546
    .line 547
    move-object/from16 v39, v8

    .line 548
    .line 549
    move-object/from16 v40, p6

    .line 550
    .line 551
    move/from16 v41, p5

    .line 552
    .line 553
    move-object/from16 p0, p4

    .line 554
    .line 555
    move-object/from16 p1, v18

    .line 556
    .line 557
    move/from16 p2, v0

    .line 558
    .line 559
    invoke-direct/range {v38 .. v45}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$3;-><init>(LX/Ddn;Ljava/lang/String;ZLX/JDM;LX/3C1;II)V

    .line 560
    .line 561
    .line 562
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 563
    .line 564
    :cond_19
    return-void
.end method

.method public static final CcvCountryField$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final CcvCountryField$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final CcvCountryField$lambda$5(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V
    .locals 60
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;I",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            "Ljava/lang/String;",
            "Z",
            "LX/0PV;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "III",
            "LX/3PP;",
            "LX/3Bk;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    move-object/from16 v30, p5

    move-object/from16 v28, p8

    move-object/from16 v27, p9

    move-object/from16 v26, p10

    move/from16 v25, p11

    move/from16 v24, p12

    move/from16 v23, p13

    move-object/from16 v22, p15

    move-object/from16 v21, p16

    move-object/from16 v20, p14

    const v0, -0xf985c73

    .line 1145487
    move-object/from16 v5, p17

    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    move/from16 v4, p18

    and-int/lit8 v0, p18, 0x6

    if-nez v0, :cond_2b

    .line 1145488
    move-object/from16 v0, p0

    invoke-static {v5, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    move-result v8

    .line 1145489
    or-int v8, v8, p18

    :goto_0
    and-int/lit8 v0, p18, 0x30

    move-object/from16 v59, p1

    if-nez v0, :cond_0

    .line 1145490
    move-object/from16 v0, v59

    invoke-static {v5, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145491
    or-int/2addr v8, v0

    :cond_0
    and-int/lit16 v0, v4, 0x180

    move-object/from16 v58, p2

    if-nez v0, :cond_1

    .line 1145492
    move-object/from16 v0, v58

    invoke-static {v5, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145493
    or-int/2addr v8, v0

    :cond_1
    and-int/lit16 v0, v4, 0xc00

    const/16 v2, 0x800

    move/from16 v56, p3

    if-nez v0, :cond_2

    .line 1145494
    move/from16 v0, v56

    invoke-static {v5, v0}, LX/008;->A0L(LX/2d4;I)I

    move-result v0

    .line 1145495
    or-int/2addr v8, v0

    :cond_2
    and-int/lit16 v0, v4, 0x6000

    const/16 v17, 0x4000

    move-object/from16 v55, p4

    if-nez v0, :cond_3

    .line 1145496
    invoke-static/range {v55 .. v55}, LX/003;->A0G(Ljava/lang/Enum;)I

    move-result v0

    .line 1145497
    invoke-static {v5, v0}, LX/004;->A0H(LX/2d4;I)I

    move-result v0

    .line 1145498
    or-int/2addr v8, v0

    :cond_3
    move/from16 v6, p20

    and-int/lit8 v19, p20, 0x20

    const/high16 v18, 0x10000

    const/high16 v16, 0x30000

    if-eqz v19, :cond_2a

    or-int v8, v8, v16

    :cond_4
    :goto_1
    const/high16 v15, 0x180000

    and-int v0, p18, v15

    move/from16 v57, p6

    if-nez v0, :cond_5

    .line 1145499
    move/from16 v0, v57

    invoke-static {v5, v0}, LX/004;->A0o(LX/2d4;Z)I

    move-result v0

    .line 1145500
    or-int/2addr v8, v0

    :cond_5
    const/high16 v0, 0xc00000

    and-int v0, p18, v0

    move-object/from16 v29, p7

    if-nez v0, :cond_7

    const/high16 v1, 0x1000000

    .line 1145501
    move-object/from16 v0, v29

    invoke-static {v5, v0, v4, v1}, LX/005;->A1Q(LX/2d4;Ljava/lang/Object;II)Z

    move-result v1

    .line 1145502
    const/high16 v0, 0x400000

    if-eqz v1, :cond_6

    const/high16 v0, 0x800000

    :cond_6
    or-int/2addr v8, v0

    :cond_7
    and-int/lit16 v14, v6, 0x100

    const/high16 v0, 0x6000000

    if-nez v14, :cond_8

    and-int v0, p18, v0

    if-nez v0, :cond_9

    .line 1145503
    move-object/from16 v0, v28

    invoke-static {v5, v0}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145504
    :cond_8
    or-int/2addr v8, v0

    :cond_9
    and-int/lit16 v13, v6, 0x200

    const/high16 v0, 0x30000000

    if-nez v13, :cond_a

    and-int v0, p18, v0

    if-nez v0, :cond_b

    .line 1145505
    move-object/from16 v0, v27

    invoke-static {v5, v0}, LX/005;->A0C(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145506
    :cond_a
    or-int/2addr v8, v0

    :cond_b
    and-int/lit16 v12, v6, 0x400

    move/from16 v10, p19

    if-eqz v12, :cond_28

    or-int/lit8 v1, p19, 0x6

    :goto_2
    and-int/lit16 v11, v6, 0x800

    if-eqz v11, :cond_27

    or-int/lit8 v1, v1, 0x30

    :cond_c
    :goto_3
    and-int/lit16 v7, v6, 0x1000

    if-eqz v7, :cond_26

    or-int/lit16 v1, v1, 0x180

    :cond_d
    :goto_4
    and-int/lit16 v3, v6, 0x2000

    if-eqz v3, :cond_24

    or-int/lit16 v1, v1, 0xc00

    :cond_e
    :goto_5
    and-int/lit16 v2, v6, 0x4000

    or-int/lit16 v9, v1, 0x6000

    if-nez v2, :cond_10

    move v9, v1

    and-int/lit16 v0, v10, 0x6000

    if-nez v0, :cond_10

    move-object/from16 v0, v20

    invoke-interface {v5, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    const/16 v17, 0x2000

    :cond_f
    or-int v9, v1, v17

    :cond_10
    const v0, 0x8000

    and-int v17, p20, v0

    if-eqz v17, :cond_23

    or-int v9, v9, v16

    :cond_11
    :goto_6
    and-int v16, p20, v18

    if-eqz v16, :cond_22

    or-int/2addr v9, v15

    :cond_12
    :goto_7
    const v0, 0x12492493

    and-int v1, v8, v0

    const v0, 0x12492492

    if-ne v1, v0, :cond_13

    const v1, 0x92493

    and-int/2addr v1, v9

    const v15, 0x92492

    const/4 v0, 0x0

    if-eq v1, v15, :cond_14

    :cond_13
    const/4 v0, 0x1

    .line 1145507
    :cond_14
    invoke-static {v0, v5, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    move-result v0

    .line 1145508
    if-eqz v0, :cond_3d

    if-eqz v19, :cond_15

    const/16 v30, 0x0

    :cond_15
    if-eqz v14, :cond_16

    .line 1145509
    sget-object v28, LX/3C1;->A00:LX/3Cb;

    :cond_16
    if-eqz v13, :cond_17

    const/16 v27, 0x0

    :cond_17
    if-eqz v12, :cond_18

    const/16 v26, 0x0

    :cond_18
    if-eqz v11, :cond_19

    .line 1145510
    const/16 v25, 0x3

    .line 1145511
    :cond_19
    if-eqz v7, :cond_1a

    .line 1145512
    const/16 v24, 0x0

    .line 1145513
    :cond_1a
    if-eqz v3, :cond_1b

    .line 1145514
    const/16 v23, 0x6

    .line 1145515
    :cond_1b
    if-eqz v2, :cond_1c

    .line 1145516
    sget-object v20, LX/3PP;->A04:LX/3PP;

    .line 1145517
    :cond_1c
    if-eqz v17, :cond_1d

    const/16 v22, 0x0

    :cond_1d
    if-eqz v16, :cond_1e

    const/16 v21, 0x0

    .line 1145518
    :cond_1e
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v14

    .line 1145519
    sget-object v15, LX/2d6;->A00:Ljava/lang/Object;

    .line 1145520
    if-ne v14, v15, :cond_1f

    .line 1145521
    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->length()I

    move-result v0

    .line 1145522
    invoke-static {v0, v0}, LX/2iP;->A00(II)J

    move-result-wide v0

    .line 1145523
    new-instance v3, LX/2iJ;

    .line 1145524
    move-object/from16 v2, p0

    invoke-direct {v3, v2, v0, v1}, LX/2iJ;-><init>(Ljava/lang/String;J)V

    .line 1145525
    invoke-static {v5, v3}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    move-result-object v14

    .line 1145526
    :cond_1f
    check-cast v14, Landroidx/compose/runtime/MutableState;

    .line 1145527
    invoke-interface {v14}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2iJ;

    .line 1145528
    iget-object v0, v0, LX/2iJ;->A01:LX/2iK;

    .line 1145529
    iget-object v1, v0, LX/2iK;->A00:Ljava/lang/String;

    .line 1145530
    move-object/from16 v0, p0

    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .line 1145531
    invoke-interface {v14}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LX/2iJ;

    if-nez v0, :cond_20

    .line 1145532
    move-object/from16 v0, p0

    invoke-static {v0, v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCardCaretKt;->caretAfterFormatting(Ljava/lang/String;LX/2iJ;)I

    move-result v0

    .line 1145533
    invoke-static {v0, v0}, LX/2iP;->A00(II)J

    move-result-wide v0

    .line 1145534
    new-instance v7, LX/2iJ;

    .line 1145535
    move-object/from16 v2, p0

    invoke-direct {v7, v2, v0, v1}, LX/2iJ;-><init>(Ljava/lang/String;J)V

    .line 1145536
    :cond_20
    move-object/from16 v19, v26

    if-nez v26, :cond_21

    move-object/from16 v19, v27

    if-nez v27, :cond_21

    const v0, 0x750d886f

    .line 1145537
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    move/from16 v0, v56

    invoke-static {v5, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    move-result-object v19

    .line 1145538
    :goto_8
    move-object v3, v5

    check-cast v3, LX/J7I;

    .line 1145539
    const/4 v2, 0x0

    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145540
    invoke-static {v5}, LX/003;->A0X(LX/2d4;)LX/3BI;

    move-result-object v16

    .line 1145541
    iget-wide v0, v3, LX/J7I;->A06:J

    .line 1145542
    const/16 v11, 0x20

    ushr-long v11, v0, v11

    xor-long/2addr v0, v11

    long-to-int v13, v0

    .line 1145543
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    move-result-object v12

    .line 1145544
    move-object/from16 v0, v28

    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    move-result-object v11

    .line 1145545
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 1145546
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 1145547
    if-nez v0, :cond_2c

    invoke-static {}, LX/1VY;->A00()V

    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    move-result-object v0

    throw v0

    .line 1145548
    :cond_21
    const v0, 0x750d8587    # 1.7939993E32f

    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    goto :goto_8

    .line 1145549
    :cond_22
    and-int v0, p19, v15

    if-nez v0, :cond_12

    .line 1145550
    move-object/from16 v0, v21

    invoke-static {v5, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145551
    or-int/2addr v9, v0

    goto/16 :goto_7

    :cond_23
    and-int v0, p19, v16

    if-nez v0, :cond_11

    .line 1145552
    move-object/from16 v0, v22

    invoke-static {v5, v0}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145553
    or-int/2addr v9, v0

    goto/16 :goto_6

    :cond_24
    and-int/lit16 v0, v10, 0xc00

    if-nez v0, :cond_e

    move/from16 v0, v23

    invoke-interface {v5, v0}, LX/2d4;->A67(I)Z

    move-result v0

    if-nez v0, :cond_25

    const/16 v2, 0x400

    :cond_25
    or-int/2addr v1, v2

    goto/16 :goto_5

    :cond_26
    and-int/lit16 v0, v10, 0x180

    if-nez v0, :cond_d

    .line 1145554
    move/from16 v0, v24

    invoke-static {v5, v0}, LX/004;->A0G(LX/2d4;I)I

    move-result v0

    .line 1145555
    or-int/2addr v1, v0

    goto/16 :goto_4

    :cond_27
    and-int/lit8 v0, p19, 0x30

    const/4 v11, 0x0

    if-nez v0, :cond_c

    .line 1145556
    move/from16 v0, v25

    invoke-static {v5, v0}, LX/004;->A0F(LX/2d4;I)I

    move-result v0

    .line 1145557
    or-int/2addr v1, v0

    goto/16 :goto_3

    :cond_28
    and-int/lit8 v0, p19, 0x6

    const/4 v12, 0x0

    if-nez v0, :cond_29

    .line 1145558
    move-object/from16 v0, v26

    invoke-static {v5, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145559
    or-int v1, p19, v0

    goto/16 :goto_2

    :cond_29
    move v1, v10

    goto/16 :goto_2

    :cond_2a
    and-int v0, p18, v16

    if-nez v0, :cond_4

    .line 1145560
    move-object/from16 v0, v30

    invoke-static {v5, v0}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145561
    or-int/2addr v8, v0

    goto/16 :goto_1

    :cond_2b
    move v8, v4

    goto/16 :goto_0

    .line 1145562
    :cond_2c
    invoke-static {v5, v3, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 1145563
    move-object/from16 v0, v16

    invoke-static {v5, v0, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 1145564
    if-nez p4, :cond_2d

    const/16 v47, 0x0

    if-eqz v30, :cond_2e

    :cond_2d
    const/16 v47, 0x1

    .line 1145565
    :cond_2e
    const/16 v18, 0x0

    .line 1145566
    new-instance v17, LX/3PN;

    move/from16 v13, v24

    move/from16 v12, v25

    move/from16 v11, v23

    move-object/from16 v1, v17

    move-object/from16 v0, v18

    invoke-direct {v1, v0, v13, v12, v11}, LX/3PN;-><init>(Ljava/lang/Boolean;III)V

    .line 1145567
    sget-object v16, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    const/4 v12, 0x6

    move-object/from16 v0, v16

    invoke-virtual {v0, v5, v12}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    move-result-object v0

    .line 1145568
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->bodyRegular:LX/2hg;

    move-object/from16 v32, v0

    .line 1145569
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 1145570
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 1145571
    if-eqz v22, :cond_2f

    .line 1145572
    move-object/from16 v0, v22

    invoke-static {v11, v0}, LX/3De;->A00(LX/3C1;LX/3Bk;)LX/3C1;

    move-result-object v0

    if-nez v0, :cond_30

    :cond_2f
    move-object v0, v11

    :cond_30
    invoke-interface {v1, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    move-result-object v13

    if-nez p7, :cond_3a

    const v0, 0x76532d0c

    .line 1145573
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1145574
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145575
    :goto_9
    move-object v0, v11

    .line 1145576
    :cond_31
    invoke-interface {v13, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    move-result-object v13

    .line 1145577
    invoke-static {v8}, LX/005;->A1J(I)Z

    move-result v0

    .line 1145578
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_32

    .line 1145579
    if-ne v1, v15, :cond_33

    .line 1145580
    :cond_32
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$3$1;

    move-object/from16 v0, v58

    invoke-direct {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$3$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 1145581
    invoke-interface {v5, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145582
    :cond_33
    check-cast v1, LX/JDM;

    invoke-static {v13, v1}, LX/7mF;->A00(LX/3C1;LX/JDM;)LX/3C1;

    move-result-object v31

    .line 1145583
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$4;

    move-object/from16 v0, v19

    invoke-direct {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$4;-><init>(Ljava/lang/String;)V

    const v0, -0x316ce215

    const/4 v13, 0x1

    invoke-static {v5, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    move-result-object v34

    .line 1145584
    invoke-interface {v5, v7}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v1

    .line 1145585
    invoke-static {v8}, LX/004;->A1S(I)Z

    move-result v0

    .line 1145586
    or-int/2addr v1, v0

    .line 1145587
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v0

    if-nez v1, :cond_34

    .line 1145588
    if-ne v0, v15, :cond_35

    .line 1145589
    :cond_34
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$5$1;

    move-object/from16 v1, v59

    invoke-direct {v0, v7, v1, v14}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$5$1;-><init>(LX/2iJ;LX/JDM;Landroidx/compose/runtime/MutableState;)V

    .line 1145590
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145591
    :cond_35
    check-cast v0, LX/JDM;

    shl-int/lit8 v52, v9, 0x3

    const/high16 v1, 0x70000

    and-int v52, v52, v1

    const v1, 0x6000c00

    or-int v52, v52, v1

    shr-int/lit8 v1, v9, 0xf

    and-int/lit8 v53, v1, 0x70

    const v9, 0xe000

    shr-int/lit8 v1, v8, 0x6

    and-int/2addr v9, v1

    or-int v53, v53, v9

    const v54, 0x6b644

    .line 1145592
    move-object/from16 v35, v17

    move-object/from16 v36, v20

    move-object/from16 v37, v18

    move-object/from16 v38, v32

    move/from16 v39, v13

    move/from16 v40, v2

    move-object/from16 v41, v18

    move-object/from16 v42, v21

    move-object/from16 v43, v18

    move-object/from16 v44, v18

    move/from16 v45, v57

    move/from16 v46, v2

    move/from16 v48, v2

    move-object/from16 v49, v18

    move-object/from16 v50, v0

    move-object/from16 v51, v5

    move-object/from16 v32, v7

    move-object/from16 v33, v18

    invoke-static/range {v31 .. v54}, Lcom/facebook/aura/vds/compose/input/AuraTextInputKt;->AuraTextInput(LX/3C1;LX/2iJ;Ljava/lang/String;LX/JDN;LX/3PN;LX/3PP;LX/2WL;LX/2hg;ZILX/JDN;LX/JDN;Lcom/facebook/aura/vds/compose/theme/AuraColorsTextInput;LX/3Gw;ZZZZLX/2bW;LX/JDM;LX/2d4;III)V

    if-nez v30, :cond_37

    const v0, 0x7656ff20

    .line 1145593
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    if-nez p4, :cond_36

    .line 1145594
    const v0, 0x7656ff1f

    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1145595
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145596
    const/16 v31, 0x0

    .line 1145597
    :goto_a
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145598
    if-nez v31, :cond_38

    const v0, 0x765806dd

    .line 1145599
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1145600
    :goto_b
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145601
    invoke-static {v3, v13}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145602
    goto/16 :goto_c

    .line 1145603
    :cond_36
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    invoke-static/range {v55 .. v55}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)I

    move-result v0

    invoke-static {v5, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    move-result-object v31

    .line 1145604
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145605
    goto :goto_a

    .line 1145606
    :cond_37
    const v0, 0x355da278

    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1145607
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145608
    move-object/from16 v31, v30

    .line 1145609
    :cond_38
    const v0, 0x765806de

    .line 1145610
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 1145611
    move-object/from16 v0, v16

    invoke-virtual {v0, v5, v12}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    move-result-object v0

    .line 1145612
    iget-object v7, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption1Regular:LX/2hg;

    .line 1145613
    move-object/from16 v0, v16

    invoke-virtual {v0, v5, v12}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    move-result-object v0

    .line 1145614
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->errorText:J

    .line 1145615
    sget v12, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 1145616
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 1145617
    const/4 v8, 0x0

    .line 1145618
    invoke-static {v11, v12, v9, v8, v8}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    move-result-object v9

    .line 1145619
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    .line 1145620
    if-ne v8, v15, :cond_39

    .line 1145621
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$6$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$6$1$1;

    .line 1145622
    invoke-interface {v5, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145623
    :cond_39
    invoke-static {v9, v8, v2}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    move-result-object v32

    .line 1145624
    const/16 v49, 0x3ff0

    .line 1145625
    move-wide/from16 v33, v0

    move-object/from16 v35, v7

    move-object/from16 v36, v18

    move-object/from16 v38, v18

    move/from16 v39, v2

    move/from16 v41, v2

    move/from16 v42, v2

    move-object/from16 v45, v18

    move-object/from16 v46, v5

    move/from16 v47, v2

    invoke-static/range {v31 .. v49}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    goto :goto_b

    .line 1145626
    :cond_3a
    const v0, 0x76532d0d

    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    move-object/from16 v0, v29

    invoke-interface {v5, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v0

    .line 1145627
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_3b

    .line 1145628
    if-ne v1, v15, :cond_3c

    .line 1145629
    :cond_3b
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$2$1$1;

    move-object/from16 v0, v29

    invoke-direct {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$1$2$1$1;-><init>(LX/0PV;)V

    .line 1145630
    invoke-interface {v5, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145631
    :cond_3c
    check-cast v1, LX/JDM;

    .line 1145632
    invoke-static {v11, v1, v2}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    move-result-object v0

    .line 1145633
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 1145634
    if-nez v0, :cond_31

    goto/16 :goto_9

    .line 1145635
    :cond_3d
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 1145636
    :goto_c
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    move-result-object v1

    if-eqz v1, :cond_3e

    .line 1145637
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;

    move-object/from16 v50, v0

    move-object/from16 v51, p0

    move-object/from16 v52, v59

    move-object/from16 v53, v58

    move/from16 v54, v56

    move-object/from16 v56, v30

    move-object/from16 v58, v29

    move-object/from16 v59, v28

    move-object/from16 p0, v27

    move-object/from16 p1, v26

    move/from16 p2, v25

    move/from16 p3, v24

    move/from16 p4, v23

    move-object/from16 p5, v20

    move-object/from16 p6, v22

    move-object/from16 p7, v21

    move/from16 p8, v4

    move/from16 p9, v10

    move/from16 p10, v6

    invoke-direct/range {v50 .. v70}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvField$2;-><init>(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;III)V

    .line 1145638
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 1145639
    :cond_3e
    return-void
.end method

.method public static final CcvField_V4wbGKQ$lambda$1(Landroidx/compose/runtime/MutableState;)LX/2iJ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2iJ;",
            ">;)",
            "LX/2iJ;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/2iJ;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final CcvField_V4wbGKQ$lambda$2(Landroidx/compose/runtime/MutableState;LX/2iJ;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2iJ;",
            ">;",
            "LX/2iJ;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final CcvHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 30

    .line 0
    move-object/from16 v12, p2

    .line 1
    .line 2
    const v0, 0x372952b7

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v15, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v1, v15}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    or-int v2, v2, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v14, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v14}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v2, v0

    .line 35
    :cond_0
    and-int/lit8 v6, p5, 0x4

    .line 36
    .line 37
    if-eqz v6, :cond_4

    .line 38
    .line 39
    or-int/lit16 v2, v2, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v5, v2, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, v1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_9

    .line 55
    .line 56
    if-eqz v6, :cond_2

    .line 57
    .line 58
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    if-nez p0, :cond_3

    .line 61
    .line 62
    const v0, 0x121f9262

    .line 63
    .line 64
    .line 65
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 66
    .line 67
    .line 68
    const v0, 0x7f1202aa

    .line 69
    .line 70
    .line 71
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v16

    .line 75
    move-object v0, v1

    .line 76
    check-cast v0, LX/J7I;

    .line 77
    .line 78
    invoke-static {v0, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 79
    .line 80
    .line 81
    :goto_2
    sget-object v5, LX/2Id;->A00:LX/2sS;

    .line 82
    .line 83
    invoke-static {v1, v5}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 84
    .line 85
    .line 86
    move-result-object v10

    .line 87
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 88
    .line 89
    .line 90
    move-result v9

    .line 91
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 92
    .line 93
    .line 94
    move-result-object v8

    .line 95
    invoke-static {v1, v12}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 96
    .line 97
    .line 98
    move-result-object v7

    .line 99
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 100
    .line 101
    iget-object v5, v0, LX/J7I;->A0V:LX/3DJ;

    .line 102
    .line 103
    if-nez v5, :cond_6

    .line 104
    .line 105
    invoke-static {}, LX/1VY;->A00()V

    .line 106
    .line 107
    .line 108
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    throw v0

    .line 113
    :cond_3
    const v0, 0x121f9091

    .line 114
    .line 115
    .line 116
    invoke-static {v1, v0}, LX/003;->A0T(LX/2d4;I)LX/J7I;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    move-object/from16 v16, v15

    .line 121
    .line 122
    goto :goto_2

    .line 123
    :cond_4
    and-int/lit16 v0, v4, 0x180

    .line 124
    .line 125
    if-nez v0, :cond_1

    .line 126
    .line 127
    invoke-static {v1, v12}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    or-int/2addr v2, v0

    .line 132
    goto :goto_1

    .line 133
    :cond_5
    move v2, v4

    .line 134
    goto :goto_0

    .line 135
    :cond_6
    invoke-static {v1, v0, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 136
    .line 137
    .line 138
    invoke-static {v1, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 139
    .line 140
    .line 141
    const v5, 0x7f0801e0

    .line 142
    .line 143
    .line 144
    invoke-static {v1, v5, v3}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 145
    .line 146
    .line 147
    move-result-object v22

    .line 148
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 149
    .line 150
    sget v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->LogoSize:F

    .line 151
    .line 152
    invoke-static {v5, v6}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 153
    .line 154
    .line 155
    move-result-object v20

    .line 156
    sget v6, LX/2l9;->$stable:I

    .line 157
    .line 158
    or-int/lit16 v6, v6, 0x1b0

    .line 159
    .line 160
    const/16 v27, 0x78

    .line 161
    .line 162
    const/16 v21, 0x0

    .line 163
    .line 164
    const/4 v13, 0x0

    .line 165
    move-object/from16 v19, v21

    .line 166
    .line 167
    move-object/from16 v23, v21

    .line 168
    .line 169
    move-object/from16 v24, v21

    .line 170
    .line 171
    move/from16 v25, v13

    .line 172
    .line 173
    move/from16 v26, v6

    .line 174
    .line 175
    move-object/from16 v18, v1

    .line 176
    .line 177
    invoke-static/range {v18 .. v27}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 178
    .line 179
    .line 180
    sget v6, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 181
    .line 182
    invoke-static {v1, v5, v6}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 183
    .line 184
    .line 185
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 186
    .line 187
    const/4 v7, 0x6

    .line 188
    invoke-virtual {v8, v1, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 189
    .line 190
    .line 191
    move-result-object v6

    .line 192
    iget-object v6, v6, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Emphasized:LX/2hg;

    .line 193
    .line 194
    move-object/from16 v20, v6

    .line 195
    .line 196
    invoke-static {v1, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 197
    .line 198
    .line 199
    move-result-wide v18

    .line 200
    const/4 v9, 0x3

    .line 201
    sget-object v6, LX/2sI;->A02:LX/2wD;

    .line 202
    .line 203
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v10

    .line 207
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 208
    .line 209
    if-ne v10, v11, :cond_7

    .line 210
    .line 211
    sget-object v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvHeader$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvHeader$1$1$1;

    .line 212
    .line 213
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_7
    invoke-static {v6, v10, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 217
    .line 218
    .line 219
    move-result-object v17

    .line 220
    new-instance v10, LX/2wS;

    .line 221
    .line 222
    invoke-direct {v10, v9}, LX/2wS;-><init>(I)V

    .line 223
    .line 224
    .line 225
    const/16 p4, 0x3fb0

    .line 226
    .line 227
    move-object/from16 v22, v21

    .line 228
    .line 229
    move-object/from16 v23, v10

    .line 230
    .line 231
    move/from16 v24, v3

    .line 232
    .line 233
    move/from16 v25, v3

    .line 234
    .line 235
    move/from16 v26, v3

    .line 236
    .line 237
    move/from16 v27, v3

    .line 238
    .line 239
    move-object/from16 v28, v21

    .line 240
    .line 241
    move-object/from16 v29, v21

    .line 242
    .line 243
    move-object/from16 p0, v21

    .line 244
    .line 245
    move-object/from16 p1, v1

    .line 246
    .line 247
    move/from16 p2, v3

    .line 248
    .line 249
    move/from16 p3, v3

    .line 250
    .line 251
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 252
    .line 253
    .line 254
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 255
    .line 256
    invoke-static {v1, v5, v10}, LX/1Vt;->A05(LX/2d4;LX/3C1;F)V

    .line 257
    .line 258
    .line 259
    if-eqz v14, :cond_8

    .line 260
    .line 261
    const v5, 0x1384f54c

    .line 262
    .line 263
    .line 264
    invoke-interface {v1, v5}, LX/2d4;->Agj(I)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v8, v1, v7}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 268
    .line 269
    .line 270
    move-result-object v5

    .line 271
    iget-object v7, v5, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineRegular:LX/2hg;

    .line 272
    .line 273
    invoke-static {v1, v8}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 274
    .line 275
    .line 276
    move-result-wide v18

    .line 277
    sget v5, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 278
    .line 279
    invoke-static {v6, v5, v13}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 280
    .line 281
    .line 282
    move-result-object v17

    .line 283
    new-instance v5, LX/2wS;

    .line 284
    .line 285
    invoke-direct {v5, v9}, LX/2wS;-><init>(I)V

    .line 286
    .line 287
    .line 288
    shr-int/lit8 v2, v2, 0x3

    .line 289
    .line 290
    and-int/lit8 p2, v2, 0xe

    .line 291
    .line 292
    move-object/from16 v16, v14

    .line 293
    .line 294
    move-object/from16 v20, v7

    .line 295
    .line 296
    move-object/from16 v23, v5

    .line 297
    .line 298
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 299
    .line 300
    .line 301
    :goto_3
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 302
    .line 303
    .line 304
    goto :goto_4

    .line 305
    :cond_8
    const v2, 0x138a84c1

    .line 306
    .line 307
    .line 308
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 309
    .line 310
    .line 311
    goto :goto_3

    .line 312
    :cond_9
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 313
    .line 314
    .line 315
    :goto_4
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    if-eqz v1, :cond_a

    .line 320
    .line 321
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvHeader$2;

    .line 322
    .line 323
    move-object/from16 p0, v0

    .line 324
    .line 325
    move-object/from16 p1, v15

    .line 326
    .line 327
    move-object/from16 p2, v14

    .line 328
    .line 329
    move-object/from16 p3, v12

    .line 330
    .line 331
    move/from16 p4, v4

    .line 332
    .line 333
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvHeader$2;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;II)V

    .line 334
    .line 335
    .line 336
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 337
    .line 338
    :cond_a
    return-void
.end method

.method public static final CcvLinkingDisclosure(LX/Ddn;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;Z",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p3

    .line 1
    .line 2
    const v0, -0x20b28afe

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p4

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v15, p0

    .line 15
    .line 16
    if-nez v0, :cond_e

    .line 17
    .line 18
    invoke-static {v6, v15}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v13

    .line 22
    or-int v13, v13, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move/from16 v14, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v6, v14}, LX/004;->A0j(LX/2d4;Z)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v13, v0

    .line 35
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 36
    .line 37
    move-object/from16 v7, p2

    .line 38
    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    invoke-static {v6, v7}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v13, v0

    .line 46
    :cond_1
    and-int/lit8 v2, p6, 0x8

    .line 47
    .line 48
    if-eqz v2, :cond_d

    .line 49
    .line 50
    or-int/lit16 v13, v13, 0xc00

    .line 51
    .line 52
    :cond_2
    :goto_1
    and-int/lit16 v1, v13, 0x493

    .line 53
    .line 54
    const/16 v0, 0x492

    .line 55
    .line 56
    const/4 v8, 0x1

    .line 57
    const/4 v12, 0x0

    .line 58
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0, v6, v13}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_6

    .line 67
    .line 68
    if-eqz v2, :cond_3

    .line 69
    .line 70
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 71
    .line 72
    :cond_3
    invoke-interface {v15}, Ljava/util/List;->isEmpty()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_5

    .line 77
    .line 78
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    if-eqz v1, :cond_4

    .line 83
    .line 84
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLinkingDisclosure$1;

    .line 85
    .line 86
    move-object/from16 p0, v0

    .line 87
    .line 88
    move-object/from16 p1, v15

    .line 89
    .line 90
    move/from16 p2, v14

    .line 91
    .line 92
    move-object/from16 p3, v7

    .line 93
    .line 94
    move-object/from16 p4, v4

    .line 95
    .line 96
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLinkingDisclosure$1;-><init>(LX/Ddn;ZLX/JDM;LX/3C1;II)V

    .line 97
    .line 98
    .line 99
    :goto_2
    check-cast v0, LX/JDN;

    .line 100
    .line 101
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 102
    .line 103
    :cond_4
    return-void

    .line 104
    :cond_5
    const v0, 0x41c45f0b

    .line 105
    .line 106
    .line 107
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 108
    .line 109
    .line 110
    invoke-static {v15}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 111
    .line 112
    .line 113
    move-result-object v11

    .line 114
    invoke-interface {v15}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_7

    .line 123
    .line 124
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 129
    .line 130
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->labelRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)I

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    invoke-static {v6, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-virtual {v11, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    goto :goto_3

    .line 142
    :cond_6
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 143
    .line 144
    .line 145
    goto/16 :goto_6

    .line 146
    .line 147
    :cond_7
    move-object v2, v6

    .line 148
    check-cast v2, LX/J7I;

    .line 149
    .line 150
    const/16 v26, 0x0

    .line 151
    .line 152
    invoke-static {v2, v12}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 153
    .line 154
    .line 155
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    if-ne v0, v8, :cond_c

    .line 160
    .line 161
    const v0, -0x9372bb0

    .line 162
    .line 163
    .line 164
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 165
    .line 166
    .line 167
    const v3, 0x7f1202a6

    .line 168
    .line 169
    .line 170
    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    :goto_4
    invoke-static {v6, v0, v3}, LX/18b;->A0A(LX/2d4;[Ljava/lang/Object;I)Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v10

    .line 182
    invoke-static {v2, v12}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 183
    .line 184
    .line 185
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 186
    .line 187
    const/4 v8, 0x6

    .line 188
    invoke-virtual {v9, v6, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    iget-wide v2, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 193
    .line 194
    sget-object v0, LX/2W8;->A03:LX/2W8;

    .line 195
    .line 196
    const/4 v1, 0x0

    .line 197
    invoke-static {v2, v3, v0, v1}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->hatchLinkStyles-ek8zF_U(JLX/2W8;LX/IzA;)LX/2iS;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    invoke-static {v6, v10, v11}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 202
    .line 203
    .line 204
    move-result v3

    .line 205
    invoke-static {v13}, LX/008;->A1X(I)Z

    .line 206
    .line 207
    .line 208
    move-result v0

    .line 209
    invoke-static {v6, v2, v0, v3}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 210
    .line 211
    .line 212
    move-result v16

    .line 213
    invoke-static {v13}, LX/004;->A1S(I)Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    or-int v16, v16, v0

    .line 218
    .line 219
    and-int/lit16 v3, v13, 0x380

    .line 220
    .line 221
    const/16 v0, 0x100

    .line 222
    .line 223
    if-ne v3, v0, :cond_8

    .line 224
    .line 225
    const/4 v12, 0x1

    .line 226
    :cond_8
    or-int v16, v16, v12

    .line 227
    .line 228
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v0

    .line 232
    if-nez v16, :cond_9

    .line 233
    .line 234
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 235
    .line 236
    if-ne v0, v3, :cond_a

    .line 237
    .line 238
    :cond_9
    if-eqz p1, :cond_b

    .line 239
    .line 240
    invoke-static {v10, v11, v15, v2, v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->buildLinkedSentence(Ljava/lang/String;Ljava/util/List;Ljava/util/List;LX/2iS;LX/JDM;)LX/2iK;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    :goto_5
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_a
    check-cast v0, LX/2iK;

    .line 248
    .line 249
    invoke-virtual {v9, v6, v8}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 250
    .line 251
    .line 252
    move-result-object v2

    .line 253
    iget-object v3, v2, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption1Regular:LX/2hg;

    .line 254
    .line 255
    invoke-static {v6, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 256
    .line 257
    .line 258
    move-result-wide v18

    .line 259
    const/4 v8, 0x3

    .line 260
    invoke-static {v4}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 261
    .line 262
    .line 263
    move-result-object v17

    .line 264
    new-instance v2, LX/2wS;

    .line 265
    .line 266
    invoke-direct {v2, v8}, LX/2wS;-><init>(I)V

    .line 267
    .line 268
    .line 269
    const/16 p5, 0x7fb0

    .line 270
    .line 271
    const-wide/16 v24, 0x0

    .line 272
    .line 273
    move-object/from16 v22, v1

    .line 274
    .line 275
    move/from16 v27, v26

    .line 276
    .line 277
    move/from16 v28, v26

    .line 278
    .line 279
    move/from16 v29, v26

    .line 280
    .line 281
    move-object/from16 v30, v1

    .line 282
    .line 283
    move-object/from16 p0, v1

    .line 284
    .line 285
    move-object/from16 p1, v1

    .line 286
    .line 287
    move-object/from16 p2, v6

    .line 288
    .line 289
    move/from16 p3, v26

    .line 290
    .line 291
    move/from16 p4, v26

    .line 292
    .line 293
    move-object/from16 v20, v3

    .line 294
    .line 295
    move-object/from16 v21, v1

    .line 296
    .line 297
    move-object/from16 v23, v2

    .line 298
    .line 299
    move-object/from16 v16, v0

    .line 300
    .line 301
    invoke-static/range {v16 .. v36}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 302
    .line 303
    .line 304
    :goto_6
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 305
    .line 306
    .line 307
    move-result-object v1

    .line 308
    if-eqz v1, :cond_4

    .line 309
    .line 310
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLinkingDisclosure$2;

    .line 311
    .line 312
    move-object/from16 p0, v0

    .line 313
    .line 314
    move-object/from16 p1, v15

    .line 315
    .line 316
    move/from16 p2, v14

    .line 317
    .line 318
    move-object/from16 p3, v7

    .line 319
    .line 320
    move-object/from16 p4, v4

    .line 321
    .line 322
    move/from16 p5, v5

    .line 323
    .line 324
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLinkingDisclosure$2;-><init>(LX/Ddn;ZLX/JDM;LX/3C1;II)V

    .line 325
    .line 326
    .line 327
    goto/16 :goto_2

    .line 328
    .line 329
    :cond_b
    sget-object v2, LX/0wV;->A00:LX/0wV;

    .line 330
    .line 331
    new-instance v0, LX/2iK;

    .line 332
    .line 333
    invoke-direct {v0, v10, v2}, LX/2iK;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 334
    .line 335
    .line 336
    goto :goto_5

    .line 337
    :cond_c
    const v0, -0x935dd78

    .line 338
    .line 339
    .line 340
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 341
    .line 342
    .line 343
    const v3, 0x7f12029f

    .line 344
    .line 345
    .line 346
    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    invoke-interface {v11, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v0

    .line 358
    goto/16 :goto_4

    .line 359
    .line 360
    :cond_d
    and-int/lit16 v0, v5, 0xc00

    .line 361
    .line 362
    if-nez v0, :cond_2

    .line 363
    .line 364
    invoke-static {v6, v4}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 365
    .line 366
    .line 367
    move-result v0

    .line 368
    or-int/2addr v13, v0

    .line 369
    goto/16 :goto_1

    .line 370
    .line 371
    :cond_e
    move v13, v5

    .line 372
    goto/16 :goto_0
.end method

.method public static final CcvLoading(LX/3C1;LX/2d4;II)V
    .locals 5

    .line 0
    const v0, 0x50c3dc18

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v4, p3, 0x1

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    if-eqz v4, :cond_5

    .line 10
    .line 11
    or-int/lit8 v0, p2, 0x6

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v1, v0, 0x3

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-static {v1, v3}, LX/003;->A1H(II)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-static {v1, p1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_4

    .line 25
    .line 26
    if-eqz v4, :cond_0

    .line 27
    .line 28
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 29
    .line 30
    :cond_0
    const v0, 0x7f1202a8

    .line 31
    .line 32
    .line 33
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 38
    .line 39
    invoke-interface {p0, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sget-object v0, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 44
    .line 45
    invoke-static {v0, v1, v2}, LX/2sI;->A02(Landroidx/compose/ui/Alignment;LX/3C1;Z)LX/3C1;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-interface {p1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-nez v1, :cond_1

    .line 58
    .line 59
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 60
    .line 61
    if-ne v0, v1, :cond_2

    .line 62
    .line 63
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLoading$1$1;

    .line 64
    .line 65
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLoading$1$1;-><init>(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_2
    check-cast v0, LX/JDM;

    .line 72
    .line 73
    invoke-static {p1, v2, v0}, LX/009;->A0x(LX/2d4;LX/3C1;LX/JDM;)V

    .line 74
    .line 75
    .line 76
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    if-eqz v1, :cond_3

    .line 81
    .line 82
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLoading$2;

    .line 83
    .line 84
    invoke-direct {v0, p0, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvLoading$2;-><init>(LX/3C1;II)V

    .line 85
    .line 86
    .line 87
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 88
    .line 89
    :cond_3
    return-void

    .line 90
    :cond_4
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 91
    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_5
    and-int/lit8 v0, p2, 0x6

    .line 95
    .line 96
    if-nez v0, :cond_6

    .line 97
    .line 98
    invoke-static {p1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    or-int/2addr v0, p2

    .line 103
    goto :goto_0

    .line 104
    :cond_6
    move v0, p2

    .line 105
    goto :goto_0
.end method

.method public static final CcvSubmitErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, -0x750f3a8c

    .line 1
    .line 2
    .line 3
    move-object/from16 v3, p3

    .line 4
    .line 5
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v2, p4

    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    move-object/from16 v5, p0

    .line 13
    .line 14
    if-nez v0, :cond_7

    .line 15
    .line 16
    invoke-static {v5, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, LX/003;->A06(I)I

    .line 21
    .line 22
    .line 23
    move-result v7

    .line 24
    or-int v7, v7, p4

    .line 25
    .line 26
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 27
    .line 28
    move-object/from16 v15, p1

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-static {v3, v15}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v7, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 38
    .line 39
    move-object/from16 v4, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v3, v4}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v7, v0

    .line 48
    :cond_1
    and-int/lit16 v6, v7, 0x93

    .line 49
    .line 50
    const/16 v0, 0x92

    .line 51
    .line 52
    const/4 v1, 0x0

    .line 53
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-static {v0, v3, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_6

    .line 62
    .line 63
    iget-object v9, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitError:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 64
    .line 65
    if-nez v9, :cond_3

    .line 66
    .line 67
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    if-eqz v1, :cond_2

    .line 72
    .line 73
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$error$1;

    .line 74
    .line 75
    invoke-direct {v0, v5, v15, v4, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$error$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 76
    .line 77
    .line 78
    :goto_1
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 79
    .line 80
    :cond_2
    return-void

    .line 81
    :cond_3
    const v0, 0x7f120295

    .line 82
    .line 83
    .line 84
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v8

    .line 88
    iget-object v10, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerTitle:Ljava/lang/String;

    .line 89
    .line 90
    if-nez v10, :cond_5

    .line 91
    .line 92
    const v0, -0x6e2aa228

    .line 93
    .line 94
    .line 95
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 96
    .line 97
    .line 98
    invoke-static {v9}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->titleRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v10

    .line 106
    :goto_2
    move-object v6, v3

    .line 107
    check-cast v6, LX/J7I;

    .line 108
    .line 109
    invoke-static {v6, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 110
    .line 111
    .line 112
    iget-object v11, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->submitServerMessage:Ljava/lang/String;

    .line 113
    .line 114
    if-nez v11, :cond_4

    .line 115
    .line 116
    const v0, -0x6e2a97e6

    .line 117
    .line 118
    .line 119
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 120
    .line 121
    .line 122
    invoke-static {v9}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;)I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v11

    .line 130
    :goto_3
    invoke-static {v6, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 131
    .line 132
    .line 133
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;

    .line 134
    .line 135
    invoke-direct {v6, v8, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 136
    .line 137
    .line 138
    const v0, -0x3a5bd63d

    .line 139
    .line 140
    .line 141
    invoke-static {v3, v6, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 142
    .line 143
    .line 144
    move-result-object v14

    .line 145
    shl-int/lit8 p2, v7, 0xf

    .line 146
    .line 147
    const/high16 v0, 0x380000

    .line 148
    .line 149
    and-int p2, p2, v0

    .line 150
    .line 151
    const/high16 v0, 0x30000

    .line 152
    .line 153
    or-int p2, p2, v0

    .line 154
    .line 155
    const/16 p4, 0x799

    .line 156
    .line 157
    const/4 v9, 0x0

    .line 158
    move-object v12, v9

    .line 159
    move-object v13, v9

    .line 160
    move-object/from16 v16, v9

    .line 161
    .line 162
    move/from16 v18, v1

    .line 163
    .line 164
    move-object/from16 p0, v9

    .line 165
    .line 166
    move/from16 p3, v1

    .line 167
    .line 168
    move-object/from16 p1, v3

    .line 169
    .line 170
    move/from16 v17, v1

    .line 171
    .line 172
    invoke-static/range {v9 .. v23}, Lcom/facebook/aura/vds/compose/dialog/AuraAlertDialogKt;->AuraAlertDialog(LX/3C1;Ljava/lang/String;Ljava/lang/String;LX/JDN;LX/JDN;LX/JDN;Lkotlin/jvm/functions/Function0;LX/0yv;ZZLX/JDM;LX/2d4;III)V

    .line 173
    .line 174
    .line 175
    goto :goto_4

    .line 176
    :cond_4
    const v0, -0x6e2a9ba7

    .line 177
    .line 178
    .line 179
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 180
    .line 181
    .line 182
    goto :goto_3

    .line 183
    :cond_5
    const v0, -0x6e2aa5ab

    .line 184
    .line 185
    .line 186
    invoke-interface {v3, v0}, LX/2d4;->Agj(I)V

    .line 187
    .line 188
    .line 189
    goto :goto_2

    .line 190
    :cond_6
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 191
    .line 192
    .line 193
    :goto_4
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 194
    .line 195
    .line 196
    move-result-object v1

    .line 197
    if-eqz v1, :cond_2

    .line 198
    .line 199
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$2;

    .line 200
    .line 201
    invoke-direct {v0, v5, v15, v4, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvSubmitErrorDialog$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 202
    .line 203
    .line 204
    goto :goto_1

    .line 205
    :cond_7
    move v7, v2

    .line 206
    goto/16 :goto_0
.end method

.method public static final HatchAgeLinkingStatusFailureDialog(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p0

    .line 1
    .line 2
    move-object/from16 v14, p1

    .line 3
    .line 4
    move-object/from16 v8, p2

    .line 5
    .line 6
    invoke-static {v3, v14}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v16

    .line 10
    const v0, 0x53ac40f

    .line 11
    .line 12
    .line 13
    move-object/from16 v1, p3

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v2, p4

    .line 19
    .line 20
    and-int/lit8 v0, p4, 0x6

    .line 21
    .line 22
    if-nez v0, :cond_6

    .line 23
    .line 24
    invoke-static {v1, v3}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    or-int v4, v4, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v1, v14}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v4, v0

    .line 39
    :cond_0
    and-int/lit8 v5, p5, 0x4

    .line 40
    .line 41
    if-eqz v5, :cond_5

    .line 42
    .line 43
    or-int/lit16 v4, v4, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    invoke-static {v4}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_4

    .line 54
    .line 55
    if-eqz v5, :cond_2

    .line 56
    .line 57
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    const v0, 0x7f1202ac

    .line 60
    .line 61
    .line 62
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    const v0, 0x7f120295

    .line 67
    .line 68
    .line 69
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v6

    .line 73
    const v0, 0x7f1202a7

    .line 74
    .line 75
    .line 76
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v9

    .line 80
    const v0, 0x7f120299

    .line 81
    .line 82
    .line 83
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v10

    .line 87
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1;

    .line 88
    .line 89
    invoke-direct {v5, v7, v3, v6, v14}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 90
    .line 91
    .line 92
    const v0, -0x10d44720

    .line 93
    .line 94
    .line 95
    invoke-static {v1, v5, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 96
    .line 97
    .line 98
    move-result-object v13

    .line 99
    shr-int/lit8 v0, v4, 0x6

    .line 100
    .line 101
    and-int/lit8 p2, v0, 0xe

    .line 102
    .line 103
    const/high16 v0, 0x30000

    .line 104
    .line 105
    or-int p2, p2, v0

    .line 106
    .line 107
    shl-int/lit8 v4, v4, 0xf

    .line 108
    .line 109
    const/high16 v0, 0x380000

    .line 110
    .line 111
    and-int/2addr v4, v0

    .line 112
    or-int p2, p2, v4

    .line 113
    .line 114
    const/16 p4, 0x798

    .line 115
    .line 116
    const/4 v11, 0x0

    .line 117
    move-object v12, v11

    .line 118
    move-object v15, v11

    .line 119
    move/from16 v17, v16

    .line 120
    .line 121
    move-object/from16 p0, v11

    .line 122
    .line 123
    move-object/from16 p1, v1

    .line 124
    .line 125
    move/from16 p3, v16

    .line 126
    .line 127
    invoke-static/range {v8 .. v22}, Lcom/facebook/aura/vds/compose/dialog/AuraAlertDialogKt;->AuraAlertDialog(LX/3C1;Ljava/lang/String;Ljava/lang/String;LX/JDN;LX/JDN;LX/JDN;Lkotlin/jvm/functions/Function0;LX/0yv;ZZLX/JDM;LX/2d4;III)V

    .line 128
    .line 129
    .line 130
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    if-eqz v1, :cond_3

    .line 135
    .line 136
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$2;

    .line 137
    .line 138
    move-object/from16 p0, v0

    .line 139
    .line 140
    move-object/from16 p1, v3

    .line 141
    .line 142
    move-object/from16 p2, v14

    .line 143
    .line 144
    move-object/from16 p3, v8

    .line 145
    .line 146
    move/from16 p4, v2

    .line 147
    .line 148
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchAgeLinkingStatusFailureDialog$2;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 149
    .line 150
    .line 151
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 152
    .line 153
    :cond_3
    return-void

    .line 154
    :cond_4
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 155
    .line 156
    .line 157
    goto :goto_2

    .line 158
    :cond_5
    and-int/lit16 v0, v2, 0x180

    .line 159
    .line 160
    if-nez v0, :cond_1

    .line 161
    .line 162
    invoke-static {v1, v8}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    or-int/2addr v4, v0

    .line 167
    goto :goto_1

    .line 168
    :cond_6
    move v4, v2

    .line 169
    goto/16 :goto_0
.end method

.method public static final HatchCcvCardEntryScreen(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;IIII)V
    .locals 68
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "Lkotlin/Unit;",
            ">;ZZ",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "IIII)V"
        }
    .end annotation

    move-object/from16 v16, p21

    const/4 v6, 0x0

    move-object/from16 v5, p0

    invoke-static {v5, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/4 v3, 0x1

    .line 1145821
    move-object/from16 v2, p1

    move-object/from16 v1, p2

    move-object/from16 v0, p3

    invoke-static {v2, v1, v0, v3}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 1145822
    const/4 v13, 0x4

    .line 1145823
    move-object/from16 v3, p4

    move-object/from16 v2, p5

    move-object/from16 v1, p6

    move-object/from16 v0, p7

    invoke-static {v3, v2, v1, v0, v13}, LX/005;->A14(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 1145824
    const/16 v4, 0x8

    .line 1145825
    move-object/from16 p0, p10

    move-object/from16 v3, p8

    move-object/from16 v2, p9

    move-object/from16 v1, p0

    move-object/from16 v0, p11

    invoke-static {v3, v2, v1, v0, v4}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 1145826
    const/16 v1, 0xc

    move-object/from16 p10, p12

    move-object/from16 v0, p10

    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v1, 0xd

    move-object/from16 v67, p13

    move-object/from16 v0, v67

    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x11

    move-object/from16 v15, p17

    invoke-static {v15, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v10, 0x12

    move-object/from16 v14, p18

    invoke-static {v14, v10}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x13

    move-object/from16 v11, p19

    invoke-static {v11, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v1, 0x14

    move-object/from16 v64, p20

    move-object/from16 v0, v64

    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const v0, 0x737bc861

    .line 1145827
    move-object/from16 v2, p22

    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    move/from16 v1, p23

    and-int/lit8 v0, p23, 0x6

    const/16 v20, 0x2

    if-nez v0, :cond_29

    .line 1145828
    invoke-static {v5, v2, v1}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    move-result v0

    .line 1145829
    invoke-static {v0}, LX/003;->A06(I)I

    move-result v0

    .line 1145830
    or-int v12, p23, v0

    :goto_0
    and-int/lit8 v0, p23, 0x30

    const/16 v19, 0x20

    if-nez v0, :cond_0

    .line 1145831
    move-object/from16 v0, p1

    invoke-static {v2, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145832
    or-int/2addr v12, v0

    :cond_0
    and-int/lit16 v0, v1, 0x180

    const/16 v18, 0x100

    if-nez v0, :cond_1

    .line 1145833
    move-object/from16 v0, p2

    invoke-static {v2, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145834
    or-int/2addr v12, v0

    :cond_1
    and-int/lit16 v0, v1, 0xc00

    const/16 v7, 0x800

    if-nez v0, :cond_2

    .line 1145835
    move-object/from16 v0, p3

    invoke-static {v2, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145836
    or-int/2addr v12, v0

    :cond_2
    and-int/lit16 v0, v1, 0x6000

    if-nez v0, :cond_3

    .line 1145837
    move-object/from16 v0, p4

    invoke-static {v2, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145838
    or-int/2addr v12, v0

    :cond_3
    const/high16 v0, 0x30000

    and-int v0, p23, v0

    if-nez v0, :cond_4

    .line 1145839
    move-object/from16 v0, p5

    invoke-static {v2, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145840
    or-int/2addr v12, v0

    :cond_4
    const/high16 v17, 0x180000

    and-int v0, p23, v17

    if-nez v0, :cond_5

    .line 1145841
    move-object/from16 v0, p6

    invoke-static {v2, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145842
    or-int/2addr v12, v0

    :cond_5
    const/high16 v0, 0xc00000

    and-int v0, p23, v0

    if-nez v0, :cond_6

    .line 1145843
    move-object/from16 v0, p7

    invoke-static {v2, v0}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145844
    or-int/2addr v12, v0

    :cond_6
    const/high16 v0, 0x6000000

    and-int v0, p23, v0

    const/high16 v9, 0x30000

    if-nez v0, :cond_7

    .line 1145845
    invoke-static {v2, v3}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145846
    or-int/2addr v12, v0

    :cond_7
    const/high16 v8, 0x30000000

    and-int v0, p23, v8

    if-nez v0, :cond_8

    .line 1145847
    move-object/from16 v0, p9

    invoke-static {v2, v0}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145848
    or-int/2addr v12, v0

    :cond_8
    move/from16 v3, p24

    and-int/lit8 v0, p24, 0x6

    if-nez v0, :cond_28

    .line 1145849
    move-object/from16 v0, p0

    invoke-static {v2, v0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    move-result v0

    .line 1145850
    or-int v0, p24, v0

    :goto_1
    and-int/lit8 v4, p24, 0x30

    if-nez v4, :cond_9

    .line 1145851
    move-object/from16 v4, p11

    invoke-static {v2, v4}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    move-result v4

    .line 1145852
    or-int/2addr v0, v4

    :cond_9
    and-int/lit16 v4, v3, 0x180

    if-nez v4, :cond_b

    move-object/from16 v4, p10

    invoke-interface {v2, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_a

    const/16 v18, 0x80

    :cond_a
    or-int v0, v0, v18

    :cond_b
    and-int/lit16 v4, v3, 0xc00

    if-nez v4, :cond_d

    move-object/from16 v4, v67

    invoke-interface {v2, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_c

    const/16 v7, 0x400

    :cond_c
    or-int/2addr v0, v7

    :cond_d
    and-int/lit16 v4, v3, 0x6000

    move/from16 v7, p14

    if-nez v4, :cond_e

    .line 1145853
    invoke-static {v2, v7}, LX/004;->A0m(LX/2d4;Z)I

    move-result v4

    .line 1145854
    or-int/2addr v0, v4

    :cond_e
    and-int v4, p24, v9

    move/from16 v66, p15

    if-nez v4, :cond_f

    .line 1145855
    move/from16 v4, v66

    invoke-static {v2, v4}, LX/004;->A0n(LX/2d4;Z)I

    move-result v4

    .line 1145856
    or-int/2addr v0, v4

    :cond_f
    and-int v4, p24, v17

    move-object/from16 v21, p16

    if-nez v4, :cond_10

    .line 1145857
    invoke-static/range {v21 .. v21}, LX/004;->A0s(Ljava/lang/Enum;)I

    move-result v4

    .line 1145858
    invoke-interface {v2, v4}, LX/2d4;->A67(I)Z

    move-result v4

    .line 1145859
    invoke-static {v4}, LX/003;->A03(I)I

    move-result v4

    .line 1145860
    or-int/2addr v0, v4

    :cond_10
    const/high16 v4, 0xc00000

    and-int v4, v4, p24

    if-nez v4, :cond_11

    .line 1145861
    invoke-static {v2, v15}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    move-result v4

    .line 1145862
    or-int/2addr v0, v4

    :cond_11
    const/high16 v4, 0x6000000

    and-int v4, p24, v4

    if-nez v4, :cond_12

    .line 1145863
    invoke-static {v2, v14}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    move-result v4

    .line 1145864
    or-int/2addr v0, v4

    :cond_12
    and-int v4, p24, v8

    if-nez v4, :cond_13

    .line 1145865
    invoke-static {v2, v11}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    move-result v4

    .line 1145866
    or-int/2addr v0, v4

    :cond_13
    move/from16 v60, p25

    and-int/lit8 v4, p25, 0x6

    if-nez v4, :cond_27

    move-object/from16 v4, v64

    invoke-interface {v2, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    const/16 v20, 0x4

    :cond_14
    or-int v18, p25, v20

    :goto_2
    const/high16 v4, 0x200000

    move/from16 v61, p26

    and-int v17, p26, v4

    if-eqz v17, :cond_25

    or-int/lit8 v18, v18, 0x30

    :cond_15
    :goto_3
    const v9, 0x12492493

    and-int v8, v12, v9

    const v4, 0x12492492

    if-ne v8, v4, :cond_16

    and-int/2addr v9, v0

    if-ne v9, v4, :cond_16

    and-int/lit8 v8, v18, 0x13

    const/4 v4, 0x0

    if-eq v8, v10, :cond_17

    :cond_16
    const/4 v4, 0x1

    .line 1145867
    :cond_17
    invoke-static {v4, v2, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    move-result v4

    .line 1145868
    if-eqz v4, :cond_24

    if-eqz v17, :cond_18

    .line 1145869
    sget-object v16, LX/3C1;->A00:LX/3Cb;

    .line 1145870
    :cond_18
    invoke-static {v2, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->SecureScreenEffect(LX/2d4;I)V

    xor-int/lit8 v4, p14, 0x1

    .line 1145871
    and-int/lit8 v10, v12, 0xe

    if-eq v10, v13, :cond_19

    and-int/lit8 v8, v12, 0x8

    if-eqz v8, :cond_23

    invoke-interface {v2, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_23

    :cond_19
    const/4 v9, 0x1

    :goto_4
    const/high16 v8, 0xe000000

    .line 1145872
    invoke-static {v8, v0}, LX/009;->A1N(II)Z

    move-result v8

    .line 1145873
    or-int/2addr v9, v8

    .line 1145874
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v8

    if-nez v9, :cond_1a

    .line 1145875
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 1145876
    if-ne v8, v9, :cond_1b

    .line 1145877
    :cond_1a
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$1$1;

    invoke-direct {v8, v5, v14}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;)V

    .line 1145878
    invoke-interface {v2, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145879
    :cond_1b
    check-cast v8, Lkotlin/jvm/functions/Function0;

    invoke-static {v4, v8, v2, v6, v6}, Lcom/facebook/aura/navigation/AuraTerminalBackHandlerKt;->AuraTerminalBackHandler(ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 1145880
    sget-object v22, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 1145881
    sget-object v24, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    if-nez p14, :cond_1c

    .line 1145882
    iget-boolean v4, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 1145883
    const/16 v32, 0x1

    if-eqz v4, :cond_1d

    :cond_1c
    const/16 v32, 0x0

    if-nez p14, :cond_22

    .line 1145884
    :cond_1d
    iget-boolean v4, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 1145885
    if-nez v4, :cond_22

    .line 1145886
    sget-object v36, Lcom/facebook/aura/header/view/SettingsHeaderButtonKt;->SettingsHeaderButtons:LX/Ddn;

    .line 1145887
    :goto_5
    const/16 v45, 0x0

    .line 1145888
    const/high16 v8, 0x70000000

    and-int/2addr v8, v0

    const/high16 v4, 0x20000000

    .line 1145889
    invoke-static {v8, v4}, LX/003;->A1I(II)Z

    move-result v8

    .line 1145890
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    move-result-object v4

    if-nez v8, :cond_1e

    .line 1145891
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 1145892
    if-ne v4, v8, :cond_1f

    .line 1145893
    :cond_1e
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$2$1;

    invoke-direct {v4, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$2$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 1145894
    invoke-interface {v2, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 1145895
    :cond_1f
    check-cast v4, LX/JDM;

    .line 1145896
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3;

    move-object/from16 v62, v9

    move-object/from16 v63, v5

    move/from16 v65, v7

    invoke-direct/range {v62 .. v77}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$3;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;ZZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const v8, -0x5f3440c4

    invoke-static {v2, v9, v8}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    move-result-object v54

    and-int/lit8 v8, v18, 0x70

    or-int/lit16 v8, v8, 0x186

    const/high16 v12, 0x380000

    shr-int/lit8 v9, v0, 0x6

    and-int/2addr v12, v9

    or-int/2addr v8, v12

    const v58, 0x30000006

    const v59, 0x1fef9db8

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    .line 1145897
    move-object/from16 v28, v27

    move-object/from16 v29, v14

    move-object/from16 v30, v27

    move/from16 v31, v6

    move/from16 v33, v6

    move-object/from16 v34, v27

    move-object/from16 v35, v27

    move-object/from16 v37, v4

    move-object/from16 v38, v27

    move-object/from16 v39, v27

    move-wide/from16 v40, v25

    move-wide/from16 v42, v25

    move-object/from16 v44, v27

    move-object/from16 v46, v27

    move-object/from16 v47, v27

    move-object/from16 v48, v27

    move/from16 v49, v6

    move-object/from16 v50, v27

    move-object/from16 v51, v27

    move-object/from16 v52, v27

    move/from16 v53, v6

    move-object/from16 v55, v2

    move/from16 v56, v8

    move/from16 v57, v6

    move-object/from16 v23, v16

    invoke-static/range {v22 .. v59}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    if-nez p16, :cond_21

    const v4, -0xdec3a9f

    .line 1145898
    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    .line 1145899
    :goto_6
    invoke-static {v2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 1145900
    sget v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->$stable:I

    or-int/2addr v8, v10

    and-int/lit8 v4, v0, 0x70

    or-int/2addr v8, v4

    and-int/lit16 v6, v0, 0x380

    or-int/2addr v6, v8

    .line 1145901
    move-object/from16 v4, p11

    move-object/from16 v0, p10

    invoke-static {v5, v4, v0, v2, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvSubmitErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1145902
    :goto_7
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    move-result-object v2

    if-eqz v2, :cond_20

    .line 1145903
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$5;

    move-object/from16 v35, v0

    move-object/from16 v36, v5

    move-object/from16 v37, p1

    move-object/from16 v38, p2

    move-object/from16 v39, p3

    move-object/from16 v40, p4

    move-object/from16 v41, p5

    move-object/from16 v42, p6

    move-object/from16 v43, p7

    move-object/from16 v44, p8

    move-object/from16 v45, p9

    move-object/from16 v46, p0

    move-object/from16 v47, p11

    move-object/from16 v48, p10

    move-object/from16 v49, v67

    move/from16 v50, v7

    move/from16 v51, v66

    move-object/from16 v52, v21

    move-object/from16 v53, v15

    move-object/from16 v54, v14

    move-object/from16 v55, v11

    move-object/from16 v56, v64

    move-object/from16 v57, v16

    move/from16 v58, v1

    move/from16 v59, v3

    invoke-direct/range {v35 .. v61}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardEntryScreen$5;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;ZZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;IIII)V

    .line 1145904
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 1145905
    :cond_20
    return-void

    .line 1145906
    :cond_21
    const v4, -0xdec3a9e

    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    shr-int/lit8 v4, v0, 0x12

    and-int/lit8 v6, v4, 0x70

    move-object/from16 v4, v21

    invoke-static {v4, v15, v2, v6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->HatchCcvLinkingErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    goto :goto_6

    .line 1145907
    :cond_22
    sget-object v36, LX/Dwg;->A01:LX/Dwg;

    .line 1145908
    goto/16 :goto_5

    .line 1145909
    :cond_23
    const/4 v9, 0x0

    goto/16 :goto_4

    .line 1145910
    :cond_24
    invoke-interface {v2}, LX/2d4;->AgJ()V

    goto :goto_7

    .line 1145911
    :cond_25
    and-int/lit8 v4, p25, 0x30

    if-nez v4, :cond_15

    move-object/from16 v4, v16

    invoke-interface {v2, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_26

    const/16 v19, 0x10

    :cond_26
    or-int v18, v18, v19

    goto/16 :goto_3

    :cond_27
    move/from16 v18, v60

    goto/16 :goto_2

    :cond_28
    move v0, v3

    goto/16 :goto_1

    :cond_29
    move v12, v1

    goto/16 :goto_0
.end method

.method public static final HatchCcvCardFields(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "III)V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p12

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v8, p0

    .line 4
    .line 5
    invoke-static {v8, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v6, 0x1

    .line 9
    move-object/from16 v5, p1

    .line 10
    .line 11
    move-object/from16 v4, p2

    .line 12
    .line 13
    move-object/from16 v3, p3

    .line 14
    .line 15
    move-object/from16 v0, p4

    .line 16
    .line 17
    invoke-static {v5, v4, v3, v0, v6}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    move-object/from16 v3, p5

    .line 21
    .line 22
    move-object/from16 v0, p6

    .line 23
    .line 24
    invoke-static {v3, v0}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    const/4 v3, 0x7

    .line 28
    move-object/from16 v0, p7

    .line 29
    .line 30
    invoke-static {v0, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 31
    .line 32
    .line 33
    const/16 v0, 0x8

    .line 34
    .line 35
    move-object/from16 v9, p8

    .line 36
    .line 37
    move-object/from16 v7, p9

    .line 38
    .line 39
    move-object/from16 v6, p10

    .line 40
    .line 41
    move-object/from16 v5, p11

    .line 42
    .line 43
    invoke-static {v9, v7, v6, v5, v0}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 44
    .line 45
    .line 46
    const v0, -0x12b1f645

    .line 47
    .line 48
    .line 49
    move-object/from16 v4, p13

    .line 50
    .line 51
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 52
    .line 53
    .line 54
    move/from16 v3, p14

    .line 55
    .line 56
    and-int/lit8 v0, p14, 0x6

    .line 57
    .line 58
    const/4 v11, 0x4

    .line 59
    if-nez v0, :cond_15

    .line 60
    .line 61
    invoke-static {v8, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0}, LX/003;->A06(I)I

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    or-int v10, v10, p14

    .line 70
    .line 71
    :goto_0
    and-int/lit8 v0, p14, 0x30

    .line 72
    .line 73
    const/16 v13, 0x20

    .line 74
    .line 75
    if-nez v0, :cond_0

    .line 76
    .line 77
    move-object/from16 v0, p1

    .line 78
    .line 79
    invoke-static {v4, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    or-int/2addr v10, v0

    .line 84
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 85
    .line 86
    const/16 v14, 0x100

    .line 87
    .line 88
    if-nez v0, :cond_1

    .line 89
    .line 90
    move-object/from16 v0, p2

    .line 91
    .line 92
    invoke-static {v4, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    or-int/2addr v10, v0

    .line 97
    :cond_1
    and-int/lit16 v0, v3, 0xc00

    .line 98
    .line 99
    if-nez v0, :cond_2

    .line 100
    .line 101
    move-object/from16 v0, p3

    .line 102
    .line 103
    invoke-static {v4, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    or-int/2addr v10, v0

    .line 108
    :cond_2
    and-int/lit16 v0, v3, 0x6000

    .line 109
    .line 110
    if-nez v0, :cond_3

    .line 111
    .line 112
    move-object/from16 v0, p4

    .line 113
    .line 114
    invoke-static {v4, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    or-int/2addr v10, v0

    .line 119
    :cond_3
    const/high16 v0, 0x30000

    .line 120
    .line 121
    and-int v0, v0, p14

    .line 122
    .line 123
    if-nez v0, :cond_4

    .line 124
    .line 125
    move-object/from16 v0, p5

    .line 126
    .line 127
    invoke-static {v4, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    or-int/2addr v10, v0

    .line 132
    :cond_4
    const/high16 v0, 0x180000

    .line 133
    .line 134
    and-int v0, v0, p14

    .line 135
    .line 136
    if-nez v0, :cond_5

    .line 137
    .line 138
    move-object/from16 v0, p6

    .line 139
    .line 140
    invoke-static {v4, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    or-int/2addr v10, v0

    .line 145
    :cond_5
    const/high16 v0, 0xc00000

    .line 146
    .line 147
    and-int v0, v0, p14

    .line 148
    .line 149
    if-nez v0, :cond_6

    .line 150
    .line 151
    move-object/from16 v0, p7

    .line 152
    .line 153
    invoke-static {v4, v0}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    or-int/2addr v10, v0

    .line 158
    :cond_6
    const/high16 v0, 0x6000000

    .line 159
    .line 160
    and-int v0, v0, p14

    .line 161
    .line 162
    if-nez v0, :cond_7

    .line 163
    .line 164
    invoke-static {v4, v9}, LX/004;->A0X(LX/2d4;Ljava/lang/Object;)I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    or-int/2addr v10, v0

    .line 169
    :cond_7
    const/high16 v0, 0x30000000

    .line 170
    .line 171
    and-int v0, v0, p14

    .line 172
    .line 173
    if-nez v0, :cond_8

    .line 174
    .line 175
    invoke-static {v4, v7}, LX/004;->A0Y(LX/2d4;Ljava/lang/Object;)I

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    or-int/2addr v10, v0

    .line 180
    :cond_8
    move/from16 v12, p15

    .line 181
    .line 182
    and-int/lit8 v0, p15, 0x6

    .line 183
    .line 184
    if-nez v0, :cond_14

    .line 185
    .line 186
    invoke-interface {v4, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    if-nez v0, :cond_9

    .line 191
    .line 192
    const/4 v11, 0x2

    .line 193
    :cond_9
    or-int v11, p15, v11

    .line 194
    .line 195
    :goto_1
    and-int/lit8 v0, p15, 0x30

    .line 196
    .line 197
    if-nez v0, :cond_b

    .line 198
    .line 199
    invoke-interface {v4, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    move-result v0

    .line 203
    if-nez v0, :cond_a

    .line 204
    .line 205
    const/16 v13, 0x10

    .line 206
    .line 207
    :cond_a
    or-int/2addr v11, v13

    .line 208
    :cond_b
    move/from16 v0, p16

    .line 209
    .line 210
    and-int/lit16 v13, v0, 0x1000

    .line 211
    .line 212
    if-eqz v13, :cond_12

    .line 213
    .line 214
    or-int/lit16 v11, v11, 0x180

    .line 215
    .line 216
    :cond_c
    :goto_2
    const v0, 0x12492493

    .line 217
    .line 218
    .line 219
    and-int v14, v10, v0

    .line 220
    .line 221
    const v0, 0x12492492

    .line 222
    .line 223
    .line 224
    if-ne v14, v0, :cond_d

    .line 225
    .line 226
    and-int/lit16 v15, v11, 0x93

    .line 227
    .line 228
    const/16 v14, 0x92

    .line 229
    .line 230
    const/4 v0, 0x0

    .line 231
    if-eq v15, v14, :cond_e

    .line 232
    .line 233
    :cond_d
    const/4 v0, 0x1

    .line 234
    :cond_e
    invoke-static {v0, v4, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    if-eqz v0, :cond_11

    .line 239
    .line 240
    if-eqz v13, :cond_f

    .line 241
    .line 242
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 243
    .line 244
    :cond_f
    invoke-static {v4, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->SecureScreenEffect(LX/2d4;I)V

    .line 245
    .line 246
    .line 247
    iget-boolean v0, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->isSubmitting:Z

    .line 248
    .line 249
    xor-int/lit8 p0, v0, 0x1

    .line 250
    .line 251
    sget v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->$stable:I

    .line 252
    .line 253
    and-int/lit8 v15, v10, 0xe

    .line 254
    .line 255
    or-int/2addr v0, v15

    .line 256
    shl-int/lit8 v13, v10, 0x3

    .line 257
    .line 258
    and-int/lit16 v14, v13, 0x380

    .line 259
    .line 260
    or-int/2addr v14, v0

    .line 261
    and-int/lit16 v0, v13, 0x1c00

    .line 262
    .line 263
    or-int/2addr v14, v0

    .line 264
    invoke-static {v13, v14}, LX/005;->A06(II)I

    .line 265
    .line 266
    .line 267
    move-result p13

    .line 268
    const/high16 v0, 0x380000

    .line 269
    .line 270
    and-int/2addr v0, v13

    .line 271
    or-int p13, p13, v0

    .line 272
    .line 273
    const/high16 v0, 0x1c00000

    .line 274
    .line 275
    and-int/2addr v0, v13

    .line 276
    or-int p13, p13, v0

    .line 277
    .line 278
    const/high16 v0, 0xe000000

    .line 279
    .line 280
    and-int/2addr v0, v13

    .line 281
    or-int p13, p13, v0

    .line 282
    .line 283
    const/high16 v0, 0x70000000

    .line 284
    .line 285
    and-int/2addr v0, v13

    .line 286
    or-int p13, p13, v0

    .line 287
    .line 288
    shr-int/lit8 v0, v10, 0x1b

    .line 289
    .line 290
    and-int/lit8 p14, v0, 0xe

    .line 291
    .line 292
    shl-int/lit8 v10, v11, 0x3

    .line 293
    .line 294
    and-int/lit8 v0, v10, 0x70

    .line 295
    .line 296
    or-int p14, p14, v0

    .line 297
    .line 298
    and-int/lit16 v0, v11, 0x380

    .line 299
    .line 300
    or-int p14, p14, v0

    .line 301
    .line 302
    move-object/from16 p11, v1

    .line 303
    .line 304
    move-object/from16 p12, v4

    .line 305
    .line 306
    move/from16 p15, v2

    .line 307
    .line 308
    move-object/from16 v16, v8

    .line 309
    .line 310
    invoke-static/range {v16 .. v32}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvCardFields(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 311
    .line 312
    .line 313
    sget v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;->$stable:I

    .line 314
    .line 315
    or-int/2addr v2, v15

    .line 316
    and-int/lit8 v0, v11, 0x70

    .line 317
    .line 318
    or-int/2addr v2, v0

    .line 319
    and-int/lit16 v0, v10, 0x380

    .line 320
    .line 321
    or-int/2addr v2, v0

    .line 322
    invoke-static {v8, v5, v5, v4, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvSubmitErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 323
    .line 324
    .line 325
    :goto_3
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 326
    .line 327
    .line 328
    move-result-object v2

    .line 329
    if-eqz v2, :cond_10

    .line 330
    .line 331
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardFields$1;

    .line 332
    .line 333
    move-object v13, v0

    .line 334
    move-object v14, v8

    .line 335
    move-object/from16 v15, p1

    .line 336
    .line 337
    move-object/from16 v16, p2

    .line 338
    .line 339
    move-object/from16 p0, p3

    .line 340
    .line 341
    move-object/from16 p1, p4

    .line 342
    .line 343
    move-object/from16 p2, p5

    .line 344
    .line 345
    move-object/from16 p3, p6

    .line 346
    .line 347
    move-object/from16 p4, p7

    .line 348
    .line 349
    move-object/from16 p5, v9

    .line 350
    .line 351
    move-object/from16 p6, v7

    .line 352
    .line 353
    move-object/from16 p7, v6

    .line 354
    .line 355
    move-object/from16 p8, v5

    .line 356
    .line 357
    move-object/from16 p9, v1

    .line 358
    .line 359
    move/from16 p10, v3

    .line 360
    .line 361
    move/from16 p11, v12

    .line 362
    .line 363
    move/from16 p12, p16

    .line 364
    .line 365
    invoke-direct/range {v13 .. v29}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvCardFields$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;LX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;III)V

    .line 366
    .line 367
    .line 368
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 369
    .line 370
    :cond_10
    return-void

    .line 371
    :cond_11
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 372
    .line 373
    .line 374
    goto :goto_3

    .line 375
    :cond_12
    and-int/lit16 v0, v12, 0x180

    .line 376
    .line 377
    if-nez v0, :cond_c

    .line 378
    .line 379
    invoke-interface {v4, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 380
    .line 381
    .line 382
    move-result v0

    .line 383
    if-nez v0, :cond_13

    .line 384
    .line 385
    const/16 v14, 0x80

    .line 386
    .line 387
    :cond_13
    or-int/2addr v11, v14

    .line 388
    goto/16 :goto_2

    .line 389
    .line 390
    :cond_14
    move v11, v12

    .line 391
    goto/16 :goto_1

    .line 392
    .line 393
    :cond_15
    move v10, v3

    .line 394
    goto/16 :goto_0
.end method

.method public static final HatchCcvLinkingErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p0

    .line 1
    .line 2
    move-object/from16 v12, p1

    .line 3
    .line 4
    invoke-static {v3, v12}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v14

    .line 8
    const v0, -0x2ffdb755

    .line 9
    .line 10
    .line 11
    move-object/from16 v4, p2

    .line 12
    .line 13
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_3

    .line 21
    .line 22
    invoke-static {v4, v3}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    or-int v6, p3, v0

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-static {v4, v12}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v6, v0

    .line 37
    :cond_0
    invoke-static {v6}, LX/005;->A1G(I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v4, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    const v0, 0x7f120295

    .line 48
    .line 49
    .line 50
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    invoke-static {v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->titleRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v7

    .line 62
    invoke-static {v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvLinkingErrorDialog$1;

    .line 71
    .line 72
    invoke-direct {v1, v5, v12}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvLinkingErrorDialog$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 73
    .line 74
    .line 75
    const v0, -0x144491c4

    .line 76
    .line 77
    .line 78
    invoke-static {v4, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 79
    .line 80
    .line 81
    move-result-object v11

    .line 82
    shl-int/lit8 p1, v6, 0xf

    .line 83
    .line 84
    const/high16 v0, 0x380000

    .line 85
    .line 86
    and-int p1, p1, v0

    .line 87
    .line 88
    const/high16 v0, 0x30000

    .line 89
    .line 90
    or-int p1, p1, v0

    .line 91
    .line 92
    const/16 p3, 0x799

    .line 93
    .line 94
    const/4 v6, 0x0

    .line 95
    move-object v9, v6

    .line 96
    move-object v10, v6

    .line 97
    move-object v13, v6

    .line 98
    move v15, v14

    .line 99
    move-object/from16 v16, v6

    .line 100
    .line 101
    move/from16 p2, v14

    .line 102
    .line 103
    move-object/from16 p0, v4

    .line 104
    .line 105
    invoke-static/range {v6 .. v20}, Lcom/facebook/aura/vds/compose/dialog/AuraAlertDialogKt;->AuraAlertDialog(LX/3C1;Ljava/lang/String;Ljava/lang/String;LX/JDN;LX/JDN;LX/JDN;Lkotlin/jvm/functions/Function0;LX/0yv;ZZLX/JDM;LX/2d4;III)V

    .line 106
    .line 107
    .line 108
    :goto_1
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    if-eqz v1, :cond_1

    .line 113
    .line 114
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvLinkingErrorDialog$2;

    .line 115
    .line 116
    invoke-direct {v0, v3, v12, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$HatchCcvLinkingErrorDialog$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;Lkotlin/jvm/functions/Function0;I)V

    .line 117
    .line 118
    .line 119
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 120
    .line 121
    :cond_1
    return-void

    .line 122
    :cond_2
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 123
    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_3
    move v6, v2

    .line 127
    goto :goto_0
.end method

.method public static final SecureScreenEffect(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, 0x7879ff3

    .line 1
    .line 2
    .line 3
    invoke-interface {p0, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    invoke-static {p1}, LX/003;->A1B(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-static {v0, p0, p1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 18
    .line 19
    invoke-interface {p0, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Landroid/app/Activity;

    .line 24
    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    :goto_0
    const/4 v0, 0x1

    .line 32
    invoke-static {v1, v0, p0, v2, v2}, Lcom/facebook/aura/ui/SecureWindowEffectKt;->SecureWindowEffect(Landroid/view/Window;ZLX/2d4;II)V

    .line 33
    .line 34
    .line 35
    :goto_1
    invoke-interface {p0}, LX/2d4;->AAg()LX/J7V;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    if-eqz v1, :cond_0

    .line 40
    .line 41
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$SecureScreenEffect$1;

    .line 42
    .line 43
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$SecureScreenEffect$1;-><init>(I)V

    .line 44
    .line 45
    .line 46
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 47
    .line 48
    :cond_0
    return-void

    .line 49
    :cond_1
    const/4 v1, 0x0

    .line 50
    goto :goto_0

    .line 51
    :cond_2
    invoke-interface {p0}, LX/2d4;->AgJ()V

    .line 52
    .line 53
    .line 54
    goto :goto_1
.end method

.method public static final synthetic access$CardBrandMarks(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CardBrandMarks(Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;LX/Ddn;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvCardFields(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p16}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvCardFields(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;ZLX/JDM;LX/JDM;LX/JDM;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;III)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvCheckoutUnavailable(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvCheckoutUnavailable(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvCountryField(LX/Ddn;Ljava/lang/String;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvCountryField(LX/Ddn;Ljava/lang/String;ZLX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvCountryField$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvCountryField$lambda$5(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p20}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvField-V4wbGKQ(Ljava/lang/String;LX/JDM;Lkotlin/jvm/functions/Function0;ILcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;Ljava/lang/String;ZLX/0PV;LX/3C1;Ljava/lang/String;Ljava/lang/String;IIILX/3PP;LX/3Bk;LX/JDN;LX/2d4;III)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvField_V4wbGKQ$lambda$2(Landroidx/compose/runtime/MutableState;LX/2iJ;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvLinkingDisclosure(LX/Ddn;ZLX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvLinkingDisclosure(LX/Ddn;ZLX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvLoading(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvLoading(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CcvSubmitErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->CcvSubmitErrorDialog(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$SecureScreenEffect(LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->SecureScreenEffect(LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$countryDisplayName(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->countryDisplayName(Ljava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getSubtitleToFieldsGap$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->SubtitleToFieldsGap:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$isPanComplete(Ljava/lang/String;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->isPanComplete(Ljava/lang/String;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final buildLinkedSentence(Ljava/lang/String;Ljava/util/List;Ljava/util/List;LX/2iS;LX/JDM;)LX/2iK;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            ">;",
            "LX/2iS;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "Lkotlin/Unit;",
            ">;)",
            "LX/2iK;"
        }
    .end annotation

    .line 0
    new-instance v7, Ljava/util/ArrayList;

    .line 1
    .line 2
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v6

    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x0

    .line 11
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    add-int/lit8 v4, v2, 0x1

    .line 22
    .line 23
    if-gez v2, :cond_0

    .line 24
    .line 25
    invoke-static {}, LX/B8B;->A1A()V

    .line 26
    .line 27
    .line 28
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    throw v0

    .line 33
    :cond_0
    check-cast v5, Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {p0, v5, v1, v1}, LX/AdT;->A0G(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    if-ltz v0, :cond_1

    .line 44
    .line 45
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    new-instance v0, LX/IAg;

    .line 50
    .line 51
    invoke-direct {v0, v3, v5, v2}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    :cond_1
    move v2, v4

    .line 58
    goto :goto_0

    .line 59
    :cond_2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$$inlined$sortedBy$1;

    .line 60
    .line 61
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$$inlined$sortedBy$1;-><init>()V

    .line 62
    .line 63
    .line 64
    invoke-static {v7, v0}, LX/B89;->A0p(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    const/16 v0, 0x10

    .line 69
    .line 70
    new-instance v5, LX/2b4;

    .line 71
    .line 72
    invoke-direct {v5, v0}, LX/2b4;-><init>(I)V

    .line 73
    .line 74
    .line 75
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    :cond_3
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_4

    .line 84
    .line 85
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    check-cast v2, LX/IAg;

    .line 90
    .line 91
    iget-object v0, v2, LX/IAg;->first:Ljava/lang/Object;

    .line 92
    .line 93
    invoke-static {v0}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    iget-object v3, v2, LX/IAg;->second:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v3, Ljava/lang/String;

    .line 100
    .line 101
    iget-object v0, v2, LX/IAg;->third:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 104
    .line 105
    if-lt v4, v1, :cond_3

    .line 106
    .line 107
    invoke-virtual {v5, p0, v1, v4}, LX/2b4;->A0D(Ljava/lang/CharSequence;II)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;

    .line 115
    .line 116
    invoke-direct {v1, p4, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$buildLinkedSentence$1$1;-><init>(LX/JDM;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)V

    .line 117
    .line 118
    .line 119
    new-instance v0, LX/2iM;

    .line 120
    .line 121
    invoke-direct {v0, v1, p3, v2}, LX/2iM;-><init>(LX/2D4;LX/2iS;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v5, v0}, LX/2b4;->A02(LX/2D7;)I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    :try_start_0
    invoke-virtual {v5, v3}, LX/2b4;->A0E(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 129
    .line 130
    .line 131
    invoke-virtual {v5, v1}, LX/2b4;->A06(I)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    add-int/2addr v1, v4

    .line 139
    goto :goto_1

    .line 140
    :catchall_0
    move-exception v0

    .line 141
    invoke-virtual {v5, v1}, LX/2b4;->A06(I)V

    .line 142
    .line 143
    .line 144
    throw v0

    .line 145
    :cond_4
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    invoke-virtual {v5, p0, v1, v0}, LX/2b4;->A0D(Ljava/lang/CharSequence;II)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v5}, LX/2b4;->A04()LX/2iK;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    return-object v0
.end method

.method public static final countryDisplayName(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 0
    new-instance v0, Ljava/util/Locale$Builder;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/util/Locale$Builder;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {v0, p0}, Ljava/util/Locale$Builder;->setRegion(Ljava/lang/String;)Ljava/util/Locale$Builder;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/util/Locale$Builder;->build()Ljava/util/Locale;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Ljava/util/Locale;->getDisplayCountry()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    return-object v1

    .line 24
    :cond_0
    return-object p0
.end method

.method public static final isEndToEndTestOnDebugOrInternalBuild()Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    return v0
.end method

.method public static final isPanComplete(Ljava/lang/String;)Z
    .locals 2

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v1

    .line 4
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    if-lez p0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->Companion:Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork$Companion;->forDigits(Ljava/lang/String;)Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetwork;->getMaxPanLength()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v0, 0x1

    .line 21
    if-ge p0, v1, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :cond_1
    return v0
.end method

.method public static final labelRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p0, v0, :cond_0

    .line 9
    .line 10
    const v0, 0x7f1202a3

    .line 11
    .line 12
    .line 13
    return v0

    .line 14
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 15
    .line 16
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 17
    .line 18
    .line 19
    throw v0

    .line 20
    :cond_1
    const v0, 0x7f1202a4

    .line 21
    .line 22
    .line 23
    return v0
.end method

.method public static final messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;)I
    .locals 0

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 10
    .line 11
    .line 12
    throw p0

    .line 13
    :pswitch_0
    const p0, 0x7f12029d

    .line 14
    .line 15
    .line 16
    return p0

    .line 17
    :pswitch_1
    const p0, 0x7f12029c

    .line 18
    .line 19
    .line 20
    return p0

    .line 21
    :pswitch_2
    const p0, 0x7f120297

    .line 22
    .line 23
    .line 24
    return p0

    .line 25
    :pswitch_3
    const p0, 0x7f120296

    .line 26
    .line 27
    .line 28
    return p0

    .line 29
    :pswitch_4
    const p0, 0x7f120293

    .line 30
    .line 31
    .line 32
    return p0

    .line 33
    :pswitch_5
    const p0, 0x7f120292

    .line 34
    .line 35
    .line 36
    return p0

    .line 37
    :pswitch_6
    const p0, 0x7f120291

    .line 38
    .line 39
    .line 40
    return p0

    .line 41
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static final messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;)I
    .locals 0

    .line 536870912
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 536870913
    .line 536870914
    .line 536870915
    move-result p0

    .line 536870916
    packed-switch p0, :pswitch_data_0

    .line 536870917
    .line 536870918
    .line 536870919
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    .line 536870920
    .line 536870921
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 536870922
    .line 536870923
    .line 536870924
    throw p0

    .line 536870925
    :pswitch_0
    const p0, 0x7f120299

    .line 536870926
    .line 536870927
    .line 536870928
    return p0

    .line 536870929
    :pswitch_1
    const p0, 0x7f120298

    .line 536870930
    .line 536870931
    .line 536870932
    return p0

    .line 536870933
    :pswitch_2
    const p0, 0x7f120294

    .line 536870934
    .line 536870935
    .line 536870936
    return p0

    .line 536870937
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public static final messageRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)I
    .locals 1

    .line 268435456
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p0

    .line 268435460
    const/4 v0, 0x0

    .line 268435461
    if-eq p0, v0, :cond_1

    .line 268435462
    .line 268435463
    const/4 v0, 0x1

    .line 268435464
    if-ne p0, v0, :cond_0

    .line 268435465
    .line 268435466
    const v0, 0x7f1202a0

    .line 268435467
    .line 268435468
    .line 268435469
    return v0

    .line 268435470
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 268435471
    .line 268435472
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 268435473
    .line 268435474
    .line 268435475
    throw v0

    .line 268435476
    :cond_1
    const v0, 0x7f1202a1

    .line 268435477
    .line 268435478
    .line 268435479
    return v0
.end method

.method public static final titleRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;)I
    .locals 2

    .line 268435456
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p0

    .line 268435460
    const/4 v0, 0x3

    .line 268435461
    if-eq p0, v0, :cond_0

    .line 268435462
    .line 268435463
    const/4 v0, 0x4

    .line 268435464
    if-eq p0, v0, :cond_0

    .line 268435465
    .line 268435466
    const/4 v1, 0x5

    .line 268435467
    const v0, 0x7f12029a

    .line 268435468
    .line 268435469
    .line 268435470
    if-ne p0, v1, :cond_1

    .line 268435471
    .line 268435472
    :cond_0
    const v0, 0x7f12029b

    .line 268435473
    .line 268435474
    .line 268435475
    :cond_1
    return v0
.end method

.method public static final titleRes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p0, v0, :cond_0

    .line 9
    .line 10
    const v0, 0x7f12029a

    .line 11
    .line 12
    .line 13
    return v0

    .line 14
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 15
    .line 16
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 17
    .line 18
    .line 19
    throw v0

    .line 20
    :cond_1
    const v0, 0x7f1202a2

    .line 21
    .line 22
    .line 23
    return v0
.end method
