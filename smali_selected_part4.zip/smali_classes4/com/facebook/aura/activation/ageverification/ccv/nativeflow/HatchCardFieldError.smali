.class public final enum Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum CSC_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum CSC_WRONG_LENGTH:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum EXPIRY_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum EXPIRY_MALFORMED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum EXPIRY_MONTH_INVALID:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum EXPIRY_PAST:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum PAN_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum PAN_INCOMPLETE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum PAN_INVALID:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum PAN_UNSUPPORTED_BRAND:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

.field public static final enum ZIP_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;


# direct methods
.method public static constructor <clinit>()V
    .locals 13

    .line 0
    const-string v1, "PAN_EMPTY"

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 4
    .line 5
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 9
    .line 10
    const-string v1, "PAN_INCOMPLETE"

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 14
    .line 15
    invoke-direct {v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 16
    .line 17
    .line 18
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_INCOMPLETE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 19
    .line 20
    const-string v1, "PAN_INVALID"

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 24
    .line 25
    invoke-direct {v4, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    sput-object v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_INVALID:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 29
    .line 30
    const-string v1, "PAN_UNSUPPORTED_BRAND"

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 34
    .line 35
    invoke-direct {v5, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    sput-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->PAN_UNSUPPORTED_BRAND:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 39
    .line 40
    const-string v1, "EXPIRY_EMPTY"

    .line 41
    .line 42
    const/4 v0, 0x4

    .line 43
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 44
    .line 45
    invoke-direct {v6, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    sput-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 49
    .line 50
    const-string v1, "EXPIRY_MALFORMED"

    .line 51
    .line 52
    const/4 v0, 0x5

    .line 53
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 54
    .line 55
    invoke-direct {v7, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 56
    .line 57
    .line 58
    sput-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_MALFORMED:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 59
    .line 60
    const-string v1, "EXPIRY_MONTH_INVALID"

    .line 61
    .line 62
    const/4 v0, 0x6

    .line 63
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 64
    .line 65
    invoke-direct {v8, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_MONTH_INVALID:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 69
    .line 70
    const-string v1, "EXPIRY_PAST"

    .line 71
    .line 72
    const/4 v0, 0x7

    .line 73
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 74
    .line 75
    invoke-direct {v9, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 76
    .line 77
    .line 78
    sput-object v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->EXPIRY_PAST:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 79
    .line 80
    const-string v1, "CSC_EMPTY"

    .line 81
    .line 82
    const/16 v0, 0x8

    .line 83
    .line 84
    new-instance v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 85
    .line 86
    invoke-direct {v10, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 87
    .line 88
    .line 89
    sput-object v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 90
    .line 91
    const-string v1, "CSC_WRONG_LENGTH"

    .line 92
    .line 93
    const/16 v0, 0x9

    .line 94
    .line 95
    new-instance v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 96
    .line 97
    invoke-direct {v11, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 98
    .line 99
    .line 100
    sput-object v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->CSC_WRONG_LENGTH:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 101
    .line 102
    const-string v1, "ZIP_EMPTY"

    .line 103
    .line 104
    const/16 v0, 0xa

    .line 105
    .line 106
    new-instance v12, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 107
    .line 108
    invoke-direct {v12, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;-><init>(Ljava/lang/String;I)V

    .line 109
    .line 110
    .line 111
    sput-object v12, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->ZIP_EMPTY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 112
    .line 113
    filled-new-array/range {v2 .. v12}, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    sput-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 118
    .line 119
    new-instance v0, LX/DvM;

    .line 120
    .line 121
    invoke-direct {v0, v1}, LX/DvM;-><init>([Ljava/lang/Enum;)V

    .line 122
    .line 123
    .line 124
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->$ENTRIES:LX/0vk;

    .line 125
    .line 126
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;->$VALUES:[Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 7
    .line 8
    return-object v0
.end method
