.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;
    .locals 7

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;->$error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    iget v4, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->optionsVersion:I

    .line 8
    .line 9
    iget v5, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->activationVersion:I

    .line 10
    .line 11
    iget p0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attempt:I

    .line 12
    .line 13
    iget-object p1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;->attemptId:Ljava/lang/String;

    .line 14
    .line 15
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 16
    .line 17
    move-object v3, v2

    .line 18
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;-><init>(ZLcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingLaunch;IILcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvLinkingError;ILjava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingViewModel$finish$1;->invoke(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchAgeLinkingState;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
