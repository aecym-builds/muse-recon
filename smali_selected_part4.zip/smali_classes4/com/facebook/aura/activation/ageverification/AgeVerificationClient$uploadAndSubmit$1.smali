.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.AgeVerificationClient"
    f = "AgeVerificationClient.kt"
    l = {
        0xc3,
        0xc9,
        0xd5
    }
    m = "uploadAndSubmit-0E7RQCE"
    v = 0x2
.end annotation


# instance fields
.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public Z$0:Z

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->this$0:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->label:I

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$1;->this$0:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {v1, v0, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->access$uploadAndSubmit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/Map;LX/2M4;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v0}, LX/3Rs;->A0C(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method
