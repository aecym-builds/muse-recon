.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Landroid/content/Context;",
        "LX/FCr;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $view:LX/FCr;


# direct methods
.method public constructor <init>(LX/FCr;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;->$view:LX/FCr;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Landroid/content/Context;)LX/FCr;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;->$view:LX/FCr;

    .line 1
    .line 2
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;->$view:LX/FCr;

    .line 268435457
    .line 268435458
    return-object p0
.end method
