.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationIntegration;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public ActivationAgeStep(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;I)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Z",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v2, 0x0

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    invoke-static {v6, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    const/4 v5, 0x1

    .line 8
    move-object/from16 v8, p3

    .line 9
    .line 10
    move-object/from16 v9, p4

    .line 11
    .line 12
    move-object/from16 v10, p5

    .line 13
    .line 14
    invoke-static {v8, v9, v10, v0}, LX/005;->A11(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x6

    .line 18
    move-object/from16 v12, p7

    .line 19
    .line 20
    move-object/from16 v13, p8

    .line 21
    .line 22
    move-object/from16 v14, p9

    .line 23
    .line 24
    invoke-static {v12, v13, v14, v0}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    const v0, -0x480bc72c

    .line 28
    .line 29
    .line 30
    move-object/from16 v1, p10

    .line 31
    .line 32
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 33
    .line 34
    .line 35
    move/from16 v15, p11

    .line 36
    .line 37
    and-int/lit8 v0, p11, 0x6

    .line 38
    .line 39
    if-nez v0, :cond_b

    .line 40
    .line 41
    invoke-static {v1, v6}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    or-int v4, v4, p11

    .line 46
    .line 47
    :goto_0
    and-int/lit8 v0, p11, 0x30

    .line 48
    .line 49
    move/from16 v7, p2

    .line 50
    .line 51
    if-nez v0, :cond_0

    .line 52
    .line 53
    invoke-static {v1, v7}, LX/004;->A0j(LX/2d4;Z)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    or-int/2addr v4, v0

    .line 58
    :cond_0
    and-int/lit16 v0, v15, 0x180

    .line 59
    .line 60
    if-nez v0, :cond_1

    .line 61
    .line 62
    invoke-static {v1, v8}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v4, v0

    .line 67
    :cond_1
    and-int/lit16 v0, v15, 0xc00

    .line 68
    .line 69
    if-nez v0, :cond_2

    .line 70
    .line 71
    invoke-static {v1, v9}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    or-int/2addr v4, v0

    .line 76
    :cond_2
    and-int/lit16 v0, v15, 0x6000

    .line 77
    .line 78
    if-nez v0, :cond_3

    .line 79
    .line 80
    invoke-static {v1, v10}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    or-int/2addr v4, v0

    .line 85
    :cond_3
    const/high16 v0, 0x30000

    .line 86
    .line 87
    and-int v0, v0, p11

    .line 88
    .line 89
    move/from16 v11, p6

    .line 90
    .line 91
    if-nez v0, :cond_4

    .line 92
    .line 93
    invoke-static {v1, v11}, LX/008;->A0M(LX/2d4;I)I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    or-int/2addr v4, v0

    .line 98
    :cond_4
    const/high16 v0, 0x180000

    .line 99
    .line 100
    and-int v0, v0, p11

    .line 101
    .line 102
    if-nez v0, :cond_5

    .line 103
    .line 104
    invoke-static {v1, v12}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    or-int/2addr v4, v0

    .line 109
    :cond_5
    const/high16 v0, 0xc00000

    .line 110
    .line 111
    and-int v0, v0, p11

    .line 112
    .line 113
    if-nez v0, :cond_6

    .line 114
    .line 115
    invoke-static {v1, v13}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    or-int/2addr v4, v0

    .line 120
    :cond_6
    const/high16 v0, 0x6000000

    .line 121
    .line 122
    and-int v0, v0, p11

    .line 123
    .line 124
    if-nez v0, :cond_7

    .line 125
    .line 126
    invoke-static {v1, v14}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    or-int/2addr v4, v0

    .line 131
    :cond_7
    const v3, 0x2492493

    .line 132
    .line 133
    .line 134
    and-int/2addr v3, v4

    .line 135
    const v0, 0x2492492

    .line 136
    .line 137
    .line 138
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 143
    .line 144
    .line 145
    move-result v0

    .line 146
    if-eqz v0, :cond_a

    .line 147
    .line 148
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    const v3, 0x1fffffe

    .line 153
    .line 154
    .line 155
    if-eq v0, v2, :cond_9

    .line 156
    .line 157
    if-ne v0, v5, :cond_c

    .line 158
    .line 159
    const v0, -0x74364b19

    .line 160
    .line 161
    .line 162
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 163
    .line 164
    .line 165
    shr-int/lit8 v25, v4, 0x3

    .line 166
    .line 167
    and-int v25, v25, v3

    .line 168
    .line 169
    move/from16 v16, v7

    .line 170
    .line 171
    move-object/from16 v17, v8

    .line 172
    .line 173
    move-object/from16 v18, v9

    .line 174
    .line 175
    move-object/from16 v19, v10

    .line 176
    .line 177
    move/from16 v20, v11

    .line 178
    .line 179
    move-object/from16 v21, v12

    .line 180
    .line 181
    move-object/from16 v22, v13

    .line 182
    .line 183
    move-object/from16 v23, v14

    .line 184
    .line 185
    move-object/from16 v24, v1

    .line 186
    .line 187
    move/from16 v26, v2

    .line 188
    .line 189
    invoke-static/range {v16 .. v26}, Lcom/facebook/aura/activation/ageverification/IdAgeStepScreenKt;->IdAgeStep(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 190
    .line 191
    .line 192
    :goto_1
    invoke-static {v1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 193
    .line 194
    .line 195
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    if-eqz v0, :cond_8

    .line 200
    .line 201
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$ActivationAgeStep$1;

    .line 202
    .line 203
    move-object/from16 v5, p0

    .line 204
    .line 205
    invoke-direct/range {v4 .. v15}, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$ActivationAgeStep$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;I)V

    .line 206
    .line 207
    .line 208
    iput-object v4, v0, LX/J7V;->A06:LX/JDN;

    .line 209
    .line 210
    :cond_8
    return-void

    .line 211
    :cond_9
    const v0, -0x74366f95

    .line 212
    .line 213
    .line 214
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 215
    .line 216
    .line 217
    shr-int/lit8 v25, v4, 0x3

    .line 218
    .line 219
    and-int v25, v25, v3

    .line 220
    .line 221
    move/from16 v16, v7

    .line 222
    .line 223
    move-object/from16 v17, v8

    .line 224
    .line 225
    move-object/from16 v18, v9

    .line 226
    .line 227
    move-object/from16 v19, v10

    .line 228
    .line 229
    move/from16 v20, v11

    .line 230
    .line 231
    move-object/from16 v21, v12

    .line 232
    .line 233
    move-object/from16 v22, v13

    .line 234
    .line 235
    move-object/from16 v23, v14

    .line 236
    .line 237
    move-object/from16 v24, v1

    .line 238
    .line 239
    move/from16 v26, v2

    .line 240
    .line 241
    invoke-static/range {v16 .. v26}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->SelfieAgeStep(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 242
    .line 243
    .line 244
    goto :goto_1

    .line 245
    :cond_a
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 246
    .line 247
    .line 248
    goto :goto_2

    .line 249
    :cond_b
    move v4, v15

    .line 250
    goto/16 :goto_0

    .line 251
    .line 252
    :cond_c
    const v0, -0x7436762f

    .line 253
    .line 254
    .line 255
    invoke-static {v1, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    throw v0
.end method

.method public AgeMethodList(LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;I)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const/4 v15, 0x0

    .line 1
    move-object/from16 v4, p1

    .line 2
    .line 3
    invoke-static {v4, v15}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    move-object/from16 v5, p2

    .line 8
    .line 9
    move-object/from16 v7, p4

    .line 10
    .line 11
    move-object/from16 v8, p5

    .line 12
    .line 13
    invoke-static {v5, v7, v8, v0}, LX/005;->A11(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x6

    .line 17
    move-object/from16 v10, p7

    .line 18
    .line 19
    move-object/from16 v11, p8

    .line 20
    .line 21
    move-object/from16 v12, p9

    .line 22
    .line 23
    invoke-static {v10, v11, v12, v0}, LX/3Rs;->A16(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 24
    .line 25
    .line 26
    const v0, -0x120e9bd

    .line 27
    .line 28
    .line 29
    move-object/from16 v13, p10

    .line 30
    .line 31
    invoke-interface {v13, v0}, LX/2d4;->Agl(I)V

    .line 32
    .line 33
    .line 34
    move/from16 v1, p11

    .line 35
    .line 36
    and-int/lit8 v0, p11, 0x6

    .line 37
    .line 38
    if-nez v0, :cond_a

    .line 39
    .line 40
    invoke-static {v13, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    or-int v2, v2, p11

    .line 45
    .line 46
    :goto_0
    and-int/lit8 v0, p11, 0x30

    .line 47
    .line 48
    if-nez v0, :cond_0

    .line 49
    .line 50
    invoke-static {v13, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v2, v0

    .line 55
    :cond_0
    and-int/lit16 v0, v1, 0x180

    .line 56
    .line 57
    move-object/from16 v6, p3

    .line 58
    .line 59
    if-nez v0, :cond_1

    .line 60
    .line 61
    invoke-static {v6}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v13, v0}, LX/004;->A0G(LX/2d4;I)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    or-int/2addr v2, v0

    .line 70
    :cond_1
    and-int/lit16 v0, v1, 0xc00

    .line 71
    .line 72
    if-nez v0, :cond_2

    .line 73
    .line 74
    invoke-static {v13, v7}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    or-int/2addr v2, v0

    .line 79
    :cond_2
    and-int/lit16 v0, v1, 0x6000

    .line 80
    .line 81
    if-nez v0, :cond_3

    .line 82
    .line 83
    invoke-static {v13, v8}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    or-int/2addr v2, v0

    .line 88
    :cond_3
    const/high16 v0, 0x30000

    .line 89
    .line 90
    and-int v0, v0, p11

    .line 91
    .line 92
    move/from16 v9, p6

    .line 93
    .line 94
    if-nez v0, :cond_4

    .line 95
    .line 96
    invoke-static {v13, v9}, LX/004;->A0n(LX/2d4;Z)I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    or-int/2addr v2, v0

    .line 101
    :cond_4
    const/high16 v0, 0x180000

    .line 102
    .line 103
    and-int v0, v0, p11

    .line 104
    .line 105
    if-nez v0, :cond_5

    .line 106
    .line 107
    invoke-static {v13, v10}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    or-int/2addr v2, v0

    .line 112
    :cond_5
    const/high16 v0, 0xc00000

    .line 113
    .line 114
    and-int v0, v0, p11

    .line 115
    .line 116
    if-nez v0, :cond_6

    .line 117
    .line 118
    invoke-static {v13, v11}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    or-int/2addr v2, v0

    .line 123
    :cond_6
    const/high16 v0, 0x6000000

    .line 124
    .line 125
    and-int v0, v0, p11

    .line 126
    .line 127
    if-nez v0, :cond_7

    .line 128
    .line 129
    invoke-static {v13, v12}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    .line 130
    .line 131
    .line 132
    move-result v0

    .line 133
    or-int/2addr v2, v0

    .line 134
    :cond_7
    const v3, 0x2492493

    .line 135
    .line 136
    .line 137
    and-int/2addr v3, v2

    .line 138
    const v0, 0x2492492

    .line 139
    .line 140
    .line 141
    invoke-static {v3, v0}, LX/003;->A1H(II)Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    invoke-static {v0, v13, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    if-eqz v0, :cond_9

    .line 150
    .line 151
    const v14, 0xffffffe

    .line 152
    .line 153
    .line 154
    and-int/2addr v14, v2

    .line 155
    invoke-static/range {v4 .. v15}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodListScreen(LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 156
    .line 157
    .line 158
    :goto_1
    invoke-interface {v13}, LX/2d4;->AAg()LX/J7V;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    if-eqz v0, :cond_8

    .line 163
    .line 164
    new-instance v15, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;

    .line 165
    .line 166
    move/from16 p10, v1

    .line 167
    .line 168
    invoke-direct/range {v15 .. v26}, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;I)V

    .line 169
    .line 170
    .line 171
    iput-object v15, v0, LX/J7V;->A06:LX/JDN;

    .line 172
    .line 173
    :cond_8
    return-void

    .line 174
    :cond_9
    invoke-interface {v13}, LX/2d4;->AgJ()V

    .line 175
    .line 176
    .line 177
    goto :goto_1

    .line 178
    :cond_a
    move v2, v1

    .line 179
    goto/16 :goto_0
.end method

.method public clearCaptureFiles(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/common/appcontext/AuraAppContext;->INSTANCE:Lcom/facebook/aura/common/appcontext/AuraAppContext;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/aura/common/appcontext/AuraAppContext;->requireContext()Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p0, v0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationFiles;->clear(Landroid/content/Context;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
