.class public final Lcom/facebook/aura/activation/ageverification/NormalizedFace;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final centerX:F

.field public final centerY:F

.field public final height:F

.field public final pitchDegrees:F

.field public final yawDegrees:F


# direct methods
.method public constructor <init>(FFFFF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerX:F

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerY:F

    .line 6
    .line 7
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->height:F

    .line 8
    .line 9
    iput p4, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->yawDegrees:F

    .line 10
    .line 11
    iput p5, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->pitchDegrees:F

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final getCenterX()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerX:F

    .line 1
    .line 2
    return p0
.end method

.method public final getCenterY()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerY:F

    .line 1
    .line 2
    return p0
.end method

.method public final getHeight()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->height:F

    .line 1
    .line 2
    return p0
.end method

.method public final getPitchDegrees()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->pitchDegrees:F

    .line 1
    .line 2
    return p0
.end method

.method public final getYawDegrees()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->yawDegrees:F

    .line 1
    .line 2
    return p0
.end method
