.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

.field public final headMovements:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation
.end field

.field public final methods:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final retriesLeft:Ljava/lang/Integer;

.field public final state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationState;Ljava/util/List;Ljava/lang/Integer;Lcom/facebook/aura/activation/ageverification/AttemptView;LX/Ddn;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationState;",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            ">;",
            "Ljava/lang/Integer;",
            "Lcom/facebook/aura/activation/ageverification/AttemptView;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0, p5}, LX/003;->A0z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->retriesLeft:Ljava/lang/Integer;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 14
    .line 15
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->headMovements:LX/Ddn;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final getAttempt()Lcom/facebook/aura/activation/ageverification/AttemptView;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHeadMovements()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->headMovements:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMethods()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRetriesLeft()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->retriesLeft:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getState()Lcom/facebook/aura/activation/ageverification/AgeVerificationState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 1
    .line 2
    return-object p0
.end method
