.class public abstract Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final CameraPermissionGate(ILX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/3C1;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v12, p1

    .line 1
    .line 2
    const/4 v10, 0x2

    .line 3
    move-object/from16 v13, p2

    .line 4
    .line 5
    invoke-static {v13, v10}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x686c724e

    .line 9
    .line 10
    .line 11
    move-object/from16 v5, p3

    .line 12
    .line 13
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v14, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    move/from16 v11, p0

    .line 21
    .line 22
    if-nez v0, :cond_b

    .line 23
    .line 24
    invoke-static {v5, v11}, LX/004;->A0E(LX/2d4;I)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    or-int v1, v1, p4

    .line 29
    .line 30
    :goto_0
    move/from16 v15, p5

    .line 31
    .line 32
    and-int/lit8 v2, p5, 0x2

    .line 33
    .line 34
    if-eqz v2, :cond_a

    .line 35
    .line 36
    or-int/lit8 v1, v1, 0x30

    .line 37
    .line 38
    :cond_0
    :goto_1
    and-int/lit16 v0, v14, 0x180

    .line 39
    .line 40
    if-nez v0, :cond_1

    .line 41
    .line 42
    invoke-static {v5, v13}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    or-int/2addr v1, v0

    .line 47
    :cond_1
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0, v5, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_9

    .line 56
    .line 57
    if-eqz v2, :cond_2

    .line 58
    .line 59
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 60
    .line 61
    :cond_2
    invoke-static {v5}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 70
    .line 71
    if-ne v4, v3, :cond_3

    .line 72
    .line 73
    sget-object v4, Lcom/facebook/aura/utils/HatchPermissionUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchPermissionUtils;

    .line 74
    .line 75
    const-string v0, "android.permission.CAMERA"

    .line 76
    .line 77
    invoke-virtual {v4, v2, v0}, Lcom/facebook/aura/utils/HatchPermissionUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    invoke-static {v5, v0}, LX/005;->A0Y(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 82
    .line 83
    .line 84
    move-result-object v4

    .line 85
    :cond_3
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 86
    .line 87
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 88
    .line 89
    invoke-interface {v5, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v8

    .line 97
    if-nez v0, :cond_4

    .line 98
    .line 99
    if-ne v8, v3, :cond_5

    .line 100
    .line 101
    :cond_4
    new-instance v8, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;

    .line 102
    .line 103
    invoke-direct {v8, v2, v4}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$1$1;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V

    .line 104
    .line 105
    .line 106
    invoke-interface {v5, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    :cond_5
    check-cast v8, LX/JDM;

    .line 110
    .line 111
    const/4 v9, 0x6

    .line 112
    const/4 v6, 0x0

    .line 113
    invoke-static/range {v5 .. v10}, LX/CcX;->A05(LX/2d4;LX/07p;Ljava/lang/Object;LX/JDM;II)V

    .line 114
    .line 115
    .line 116
    invoke-static {v4}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    if-eqz v0, :cond_7

    .line 121
    .line 122
    const v0, 0x1bfd55d5

    .line 123
    .line 124
    .line 125
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 126
    .line 127
    .line 128
    shr-int/lit8 v0, v1, 0x3

    .line 129
    .line 130
    and-int/lit8 v0, v0, 0x7e

    .line 131
    .line 132
    invoke-static {v12, v5, v13, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 133
    .line 134
    .line 135
    :goto_2
    invoke-static {v5}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    :goto_3
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    if-eqz v0, :cond_6

    .line 143
    .line 144
    new-instance v10, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$3;

    .line 145
    .line 146
    invoke-direct/range {v10 .. v15}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$3;-><init>(ILX/3C1;LX/JDQ;II)V

    .line 147
    .line 148
    .line 149
    iput-object v10, v0, LX/J7V;->A06:LX/JDN;

    .line 150
    .line 151
    :cond_6
    return-void

    .line 152
    :cond_7
    const v0, 0x1bfde49a

    .line 153
    .line 154
    .line 155
    invoke-interface {v5, v0}, LX/2d4;->Agj(I)V

    .line 156
    .line 157
    .line 158
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    if-ne v2, v3, :cond_8

    .line 163
    .line 164
    new-instance v2, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$2$1;

    .line 165
    .line 166
    invoke-direct {v2, v4}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionGate$2$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 167
    .line 168
    .line 169
    invoke-interface {v5, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    :cond_8
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 173
    .line 174
    and-int/lit8 v0, v1, 0xe

    .line 175
    .line 176
    or-int/lit8 p4, v0, 0x30

    .line 177
    .line 178
    shl-int/lit8 v0, v1, 0x3

    .line 179
    .line 180
    and-int/lit16 v0, v0, 0x380

    .line 181
    .line 182
    or-int p4, p4, v0

    .line 183
    .line 184
    const/16 p5, 0x0

    .line 185
    .line 186
    move-object/from16 p1, v2

    .line 187
    .line 188
    move-object/from16 p2, v12

    .line 189
    .line 190
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->CameraPermissionRequest(ILkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 191
    .line 192
    .line 193
    goto :goto_2

    .line 194
    :cond_9
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 195
    .line 196
    .line 197
    goto :goto_3

    .line 198
    :cond_a
    and-int/lit8 v0, p4, 0x30

    .line 199
    .line 200
    if-nez v0, :cond_0

    .line 201
    .line 202
    invoke-static {v5, v12}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    or-int/2addr v1, v0

    .line 207
    goto/16 :goto_1

    .line 208
    .line 209
    :cond_b
    move v1, v14

    .line 210
    goto/16 :goto_0
.end method

.method public static final CameraPermissionGate$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final CameraPermissionGate$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final CameraPermissionRequest(ILkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 48
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v15, p2

    .line 1
    .line 2
    const v0, -0x68a18402

    .line 3
    .line 4
    .line 5
    move-object/from16 v5, p3

    .line 6
    .line 7
    invoke-interface {v5, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v8, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move/from16 p4, p0

    .line 15
    .line 16
    if-nez v0, :cond_9

    .line 17
    .line 18
    move/from16 v0, p4

    .line 19
    .line 20
    invoke-static {v5, v0}, LX/004;->A0E(LX/2d4;I)I

    .line 21
    .line 22
    .line 23
    move-result v9

    .line 24
    or-int/2addr v9, v8

    .line 25
    :goto_0
    and-int/lit8 v0, v8, 0x30

    .line 26
    .line 27
    move-object/from16 p3, p1

    .line 28
    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    move-object/from16 v0, p3

    .line 32
    .line 33
    invoke-static {v5, v0}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    or-int/2addr v9, v0

    .line 38
    :cond_0
    move/from16 p2, p5

    .line 39
    .line 40
    and-int/lit8 v2, p5, 0x4

    .line 41
    .line 42
    if-eqz v2, :cond_8

    .line 43
    .line 44
    or-int/lit16 v9, v9, 0x180

    .line 45
    .line 46
    :cond_1
    :goto_1
    and-int/lit16 v1, v9, 0x93

    .line 47
    .line 48
    const/16 v0, 0x92

    .line 49
    .line 50
    const/4 v4, 0x0

    .line 51
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v5, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_e

    .line 60
    .line 61
    if-eqz v2, :cond_2

    .line 62
    .line 63
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    invoke-static {v5}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 66
    .line 67
    .line 68
    move-result-object v17

    .line 69
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 70
    .line 71
    invoke-interface {v5, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    check-cast v7, Landroid/app/Activity;

    .line 76
    .line 77
    new-array v1, v4, [Ljava/lang/Object;

    .line 78
    .line 79
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 84
    .line 85
    if-ne v0, v6, :cond_3

    .line 86
    .line 87
    sget-object v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$deniedPermanently$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$deniedPermanently$2$1;

    .line 88
    .line 89
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    :cond_3
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 93
    .line 94
    const/16 v11, 0x30

    .line 95
    .line 96
    invoke-static {v5, v0, v1}, LX/39E;->A05(LX/2d4;Lkotlin/jvm/functions/Function0;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 101
    .line 102
    new-array v1, v4, [Ljava/lang/Object;

    .line 103
    .line 104
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    if-ne v0, v6, :cond_4

    .line 109
    .line 110
    sget-object v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$rationaleBefore$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$rationaleBefore$2$1;

    .line 111
    .line 112
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :cond_4
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    invoke-static {v5, v0, v1}, LX/39E;->A05(LX/2d4;Lkotlin/jvm/functions/Function0;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    check-cast v2, Landroidx/compose/runtime/MutableState;

    .line 122
    .line 123
    new-array v1, v4, [Ljava/lang/Object;

    .line 124
    .line 125
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    if-ne v0, v6, :cond_5

    .line 130
    .line 131
    sget-object v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;

    .line 132
    .line 133
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    :cond_5
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 137
    .line 138
    invoke-static {v5, v0, v1}, LX/39E;->A05(LX/2d4;Lkotlin/jvm/functions/Function0;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v1

    .line 142
    check-cast v1, LX/2kB;

    .line 143
    .line 144
    new-instance v10, LX/14B;

    .line 145
    .line 146
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 147
    .line 148
    .line 149
    invoke-static {v9}, LX/004;->A1S(I)Z

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    invoke-static {v5, v2, v7, v0}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    invoke-static {v5, v1, v3, v0}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 158
    .line 159
    .line 160
    move-result v9

    .line 161
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    if-nez v9, :cond_6

    .line 166
    .line 167
    if-ne v0, v6, :cond_7

    .line 168
    .line 169
    :cond_6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;

    .line 170
    .line 171
    move-object/from16 v18, v0

    .line 172
    .line 173
    move-object/from16 v19, p3

    .line 174
    .line 175
    move-object/from16 v20, v7

    .line 176
    .line 177
    move-object/from16 v21, v2

    .line 178
    .line 179
    move-object/from16 v22, v1

    .line 180
    .line 181
    move-object/from16 v23, v3

    .line 182
    .line 183
    invoke-direct/range {v18 .. v23}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$request$1$1;-><init>(Lkotlin/jvm/functions/Function0;Landroid/app/Activity;Landroidx/compose/runtime/MutableState;LX/2kB;Landroidx/compose/runtime/MutableState;)V

    .line 184
    .line 185
    .line 186
    invoke-interface {v5, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    :cond_7
    check-cast v0, LX/JDM;

    .line 190
    .line 191
    invoke-static {v10, v5, v0}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 192
    .line 193
    .line 194
    move-result-object v16

    .line 195
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 196
    .line 197
    invoke-interface {v15, v0}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 198
    .line 199
    .line 200
    move-result-object v9

    .line 201
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 202
    .line 203
    invoke-static {v9, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 204
    .line 205
    .line 206
    move-result-object v9

    .line 207
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 208
    .line 209
    sget-object v0, LX/2Id;->A04:LX/2rU;

    .line 210
    .line 211
    invoke-static {v0, v10}, LX/Dn6;->A02(LX/2rU;F)LX/CP5;

    .line 212
    .line 213
    .line 214
    move-result-object v10

    .line 215
    sget-object v0, LX/2Id;->A00:LX/2sS;

    .line 216
    .line 217
    invoke-static {v10, v5, v0, v11}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 218
    .line 219
    .line 220
    move-result-object v14

    .line 221
    move-object v0, v5

    .line 222
    check-cast v0, LX/J7I;

    .line 223
    .line 224
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 225
    .line 226
    .line 227
    move-result v13

    .line 228
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 229
    .line 230
    .line 231
    move-result-object v12

    .line 232
    invoke-static {v5, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 233
    .line 234
    .line 235
    move-result-object v11

    .line 236
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 237
    .line 238
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 239
    .line 240
    if-nez v9, :cond_a

    .line 241
    .line 242
    invoke-static {}, LX/1VY;->A00()V

    .line 243
    .line 244
    .line 245
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    throw v0

    .line 250
    :cond_8
    and-int/lit16 v0, v8, 0x180

    .line 251
    .line 252
    if-nez v0, :cond_1

    .line 253
    .line 254
    invoke-static {v5, v15}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 255
    .line 256
    .line 257
    move-result v0

    .line 258
    or-int/2addr v9, v0

    .line 259
    goto/16 :goto_1

    .line 260
    .line 261
    :cond_9
    move v9, v8

    .line 262
    goto/16 :goto_0

    .line 263
    .line 264
    :cond_a
    invoke-static {v5, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 265
    .line 266
    .line 267
    invoke-static {v5, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268
    .line 269
    .line 270
    move/from16 v9, p4

    .line 271
    .line 272
    invoke-static {v5, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v19

    .line 276
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 277
    .line 278
    const/4 v9, 0x6

    .line 279
    invoke-virtual {v10, v5, v9}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 280
    .line 281
    .line 282
    move-result-object v9

    .line 283
    iget-object v11, v9, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 284
    .line 285
    invoke-static {v5, v10}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 286
    .line 287
    .line 288
    move-result-wide v21

    .line 289
    const/4 v10, 0x3

    .line 290
    new-instance v9, LX/2wS;

    .line 291
    .line 292
    invoke-direct {v9, v10}, LX/2wS;-><init>(I)V

    .line 293
    .line 294
    .line 295
    const/16 v37, 0x3fb2

    .line 296
    .line 297
    const/16 v18, 0x0

    .line 298
    .line 299
    move-object/from16 v20, v18

    .line 300
    .line 301
    move-object/from16 v23, v11

    .line 302
    .line 303
    move-object/from16 v24, v18

    .line 304
    .line 305
    move-object/from16 v25, v18

    .line 306
    .line 307
    move-object/from16 v26, v9

    .line 308
    .line 309
    move/from16 v27, v4

    .line 310
    .line 311
    move/from16 v28, v4

    .line 312
    .line 313
    move/from16 v29, v4

    .line 314
    .line 315
    move/from16 v30, v4

    .line 316
    .line 317
    move-object/from16 v31, v18

    .line 318
    .line 319
    move-object/from16 v32, v18

    .line 320
    .line 321
    move-object/from16 v33, v18

    .line 322
    .line 323
    move-object/from16 v34, v5

    .line 324
    .line 325
    move/from16 v35, v4

    .line 326
    .line 327
    move/from16 v36, v4

    .line 328
    .line 329
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 330
    .line 331
    .line 332
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 333
    .line 334
    .line 335
    move-result v10

    .line 336
    const v9, 0x7f12004d

    .line 337
    .line 338
    .line 339
    if-eqz v10, :cond_b

    .line 340
    .line 341
    const v9, 0x7f12004f

    .line 342
    .line 343
    .line 344
    :cond_b
    invoke-static {v5, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v19

    .line 348
    sget-object v21, LX/2sI;->A02:LX/2wD;

    .line 349
    .line 350
    invoke-interface {v5, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result v10

    .line 354
    move-object/from16 v9, v17

    .line 355
    .line 356
    invoke-interface {v5, v9}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 357
    .line 358
    .line 359
    move-result v9

    .line 360
    invoke-static {v5, v2, v7, v10, v9}, LX/603;->A1T(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;ZZ)Z

    .line 361
    .line 362
    .line 363
    move-result v10

    .line 364
    move-object/from16 v9, v16

    .line 365
    .line 366
    invoke-static {v5, v1, v9, v10}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 367
    .line 368
    .line 369
    move-result v10

    .line 370
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v9

    .line 374
    if-nez v10, :cond_c

    .line 375
    .line 376
    if-ne v9, v6, :cond_d

    .line 377
    .line 378
    :cond_c
    new-instance v9, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;

    .line 379
    .line 380
    move-object/from16 v22, v9

    .line 381
    .line 382
    move-object/from16 v23, v17

    .line 383
    .line 384
    move-object/from16 v24, v7

    .line 385
    .line 386
    move-object/from16 v25, v16

    .line 387
    .line 388
    move-object/from16 v26, v3

    .line 389
    .line 390
    move-object/from16 v27, v2

    .line 391
    .line 392
    move-object/from16 v28, v1

    .line 393
    .line 394
    invoke-direct/range {v22 .. v28}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$1$1$1;-><init>(Landroid/content/Context;Landroid/app/Activity;LX/166;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;LX/2kB;)V

    .line 395
    .line 396
    .line 397
    invoke-interface {v5, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 398
    .line 399
    .line 400
    :cond_d
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 401
    .line 402
    const p1, 0x7ffbff5

    .line 403
    .line 404
    .line 405
    const/16 v46, 0xc00

    .line 406
    .line 407
    move-object/from16 v22, v18

    .line 408
    .line 409
    move-object/from16 v23, v18

    .line 410
    .line 411
    move-object/from16 v24, v18

    .line 412
    .line 413
    move/from16 v26, v4

    .line 414
    .line 415
    move/from16 v27, v4

    .line 416
    .line 417
    move/from16 v28, v4

    .line 418
    .line 419
    move-object/from16 v30, v18

    .line 420
    .line 421
    move-object/from16 v32, v9

    .line 422
    .line 423
    move-object/from16 v34, v18

    .line 424
    .line 425
    move-object/from16 v35, v18

    .line 426
    .line 427
    move-object/from16 v36, v18

    .line 428
    .line 429
    move-object/from16 v37, v18

    .line 430
    .line 431
    move-object/from16 v38, v18

    .line 432
    .line 433
    move-object/from16 v39, v18

    .line 434
    .line 435
    move-object/from16 v40, v18

    .line 436
    .line 437
    move/from16 v41, v4

    .line 438
    .line 439
    move/from16 v42, v4

    .line 440
    .line 441
    move/from16 v43, v4

    .line 442
    .line 443
    move/from16 v44, v4

    .line 444
    .line 445
    move-object/from16 v45, v5

    .line 446
    .line 447
    move/from16 v47, v4

    .line 448
    .line 449
    move/from16 p0, v4

    .line 450
    .line 451
    move/from16 v25, v4

    .line 452
    .line 453
    invoke-static/range {v18 .. v49}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 454
    .line 455
    .line 456
    const/4 v1, 0x1

    .line 457
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 458
    .line 459
    .line 460
    goto :goto_2

    .line 461
    :cond_e
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 462
    .line 463
    .line 464
    :goto_2
    invoke-interface {v5}, LX/2d4;->AAg()LX/J7V;

    .line 465
    .line 466
    .line 467
    move-result-object v1

    .line 468
    if-eqz v1, :cond_f

    .line 469
    .line 470
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$2;

    .line 471
    .line 472
    move-object/from16 v45, v0

    .line 473
    .line 474
    move/from16 v46, p4

    .line 475
    .line 476
    move-object/from16 v47, p3

    .line 477
    .line 478
    move-object/from16 p0, v15

    .line 479
    .line 480
    move/from16 p1, v8

    .line 481
    .line 482
    invoke-direct/range {v45 .. v50}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$2;-><init>(ILkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 483
    .line 484
    .line 485
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 486
    .line 487
    :cond_f
    return-void
.end method

.method public static final CameraPermissionRequest$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final CameraPermissionRequest$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final CameraPermissionRequest$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final CameraPermissionRequest$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final CameraPermissionRequest$lambda$7(LX/2kB;)J
    .locals 1

    .line 0
    invoke-interface {p0}, LX/2kB;->AHO()J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method public static final CameraPermissionRequest$lambda$8(LX/2kB;J)V
    .locals 0

    .line 0
    invoke-interface {p0, p1, p2}, LX/2kB;->AeA(J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CameraPermissionGate$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CameraPermissionRequest(ILkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt;->CameraPermissionRequest(ILkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$7(LX/2kB;)J
    .locals 1

    .line 0
    invoke-interface {p0}, LX/2kB;->AHO()J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method public static final synthetic access$CameraPermissionRequest$lambda$8(LX/2kB;J)V
    .locals 0

    .line 0
    invoke-interface {p0, p1, p2}, LX/2kB;->AeA(J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final isCameraBlocked(ZZJ)Z
    .locals 3

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    if-eqz p1, :cond_1

    .line 3
    .line 4
    :cond_0
    sget-object v2, Lcom/facebook/aura/permissions/access/PermissionDenial;->Companion:Lcom/facebook/aura/permissions/access/PermissionDenial$Companion;

    .line 5
    .line 6
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    sub-long/2addr v0, p2

    .line 11
    invoke-virtual {v2, p0, p1, v0, v1}, Lcom/facebook/aura/permissions/access/PermissionDenial$Companion;->classify(ZZJ)Lcom/facebook/aura/permissions/access/PermissionDenial;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    sget-object v1, Lcom/facebook/aura/permissions/access/PermissionDenial;->OS_BLOCKED:Lcom/facebook/aura/permissions/access/PermissionDenial;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    if-ne v2, v1, :cond_2

    .line 19
    .line 20
    :cond_1
    const/4 v0, 0x1

    .line 21
    :cond_2
    return v0
.end method

.method public static final showsCameraRationale(Landroid/app/Activity;)Z
    .locals 1

    .line 0
    if-eqz p0, :cond_0

    .line 1
    .line 2
    const-string v0, "android.permission.CAMERA"

    .line 3
    .line 4
    invoke-static {p0, v0}, LX/0rg;->A01(Landroid/app/Activity;Ljava/lang/String;)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    const/4 v0, 0x1

    .line 9
    if-nez p0, :cond_1

    .line 10
    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :cond_1
    return v0
.end method
