.class public interface abstract Lcom/facebook/aura/activation/ageverification/ReviewResult;
.super Ljava/lang/Object;
.source ""
