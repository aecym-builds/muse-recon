.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2cF;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $boxSize$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/2RQ;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2RQ;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;->$boxSize$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2cF;

    .line 1
    .line 2
    iget-wide v0, p1, LX/2cF;->A00:J

    .line 3
    .line 4
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;->invoke-ozmzZPI(J)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke-ozmzZPI(J)V
    .locals 2

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;->$boxSize$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {p1, p2}, LX/19y;->A01(J)J

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    invoke-static {p0, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$4(Landroidx/compose/runtime/MutableState;J)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
