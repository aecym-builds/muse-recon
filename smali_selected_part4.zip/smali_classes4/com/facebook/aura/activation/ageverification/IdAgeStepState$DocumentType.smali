.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final selected:Lcom/facebook/aura/activation/ageverification/IdDocument;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdDocument;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;->selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final getSelected()Lcom/facebook/aura/activation/ageverification/IdDocument;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;->selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 1
    .line 2
    return-object p0
.end method
