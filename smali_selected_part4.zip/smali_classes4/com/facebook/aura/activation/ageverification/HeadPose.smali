.class public final Lcom/facebook/aura/activation/ageverification/HeadPose;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final pitch:F

.field public final yaw:F


# direct methods
.method public constructor <init>(FF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->yaw:F

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->pitch:F

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getPitch()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->pitch:F

    .line 1
    .line 2
    return p0
.end method

.method public final getYaw()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->yaw:F

    .line 1
    .line 2
    return p0
.end method

.method public final isNeutral()Z
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->yaw:F

    .line 1
    .line 2
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const v1, 0x3c888889

    .line 7
    .line 8
    .line 9
    cmpg-float v0, v0, v1

    .line 10
    .line 11
    if-gtz v0, :cond_0

    .line 12
    .line 13
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/HeadPose;->pitch:F

    .line 14
    .line 15
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    cmpg-float v1, v0, v1

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    if-lez v1, :cond_1

    .line 23
    .line 24
    :cond_0
    const/4 v0, 0x0

    .line 25
    :cond_1
    return v0
.end method
