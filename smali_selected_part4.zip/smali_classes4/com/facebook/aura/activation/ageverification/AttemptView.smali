.class public final Lcom/facebook/aura/activation/ageverification/AttemptView;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public final status:Ljava/lang/String;

.field public final updatedTime:Ljava/lang/Long;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Ljava/lang/String;Ljava/lang/Long;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->status:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->updatedTime:Ljava/lang/Long;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getMethod()Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStatus()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUpdatedTime()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AttemptView;->updatedTime:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method
