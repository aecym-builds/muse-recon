.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final _documentInFrame:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final _effects:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;",
            ">;"
        }
    .end annotation
.end field

.field public final _state:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState;",
            ">;"
        }
    .end annotation
.end field

.field public autoCaptured:Z

.field public awaitingSubmit:Z

.field public final context:Landroid/content/Context;

.field public documentAnchor:[F

.field public final documentInFrame:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public documentSeenMs:J

.field public final effects:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;",
            ">;"
        }
    .end annotation
.end field

.field public handledFailedRefreshes:I

.field public job:LX/Cbu;

.field public leftReviewPending:Z

.field public pollDeadlineMs:J

.field public pollJob:LX/Cbu;

.field public previousAttemptTime:Ljava/lang/Long;

.field public resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public resumed:Z

.field public steadySinceMs:J

.field public stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

.field public submitted:Z

.field public submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

.field public final ui:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;",
            ">;"
        }
    .end annotation
.end field

.field public final userId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 7

    .line 0
    const/4 v6, 0x0

    .line 1
    invoke-static {p1, p2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v5

    .line 5
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->context:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->userId:Ljava/lang/String;

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 13
    .line 14
    invoke-static {v0}, LX/EPQ;->A00(Ljava/lang/Object;)LX/Ddv;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 19
    .line 20
    new-instance v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$special$$inlined$map$1;

    .line 21
    .line 22
    invoke-direct {v4, v0, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$special$$inlined$map$1;-><init>(LX/2Lw;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 23
    .line 24
    .line 25
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    sget-object v2, LX/5Lz;->A00:LX/5Ly;

    .line 30
    .line 31
    invoke-virtual {v0}, LX/Ddv;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;

    .line 38
    .line 39
    invoke-direct {v0, v1, v5, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;ZZ)V

    .line 40
    .line 41
    .line 42
    invoke-static {v0, v3, v4, v2}, LX/5Lu;->A00(Ljava/lang/Object;LX/1EL;LX/2Lw;LX/5Ly;)LX/ERk;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->ui:LX/2J3;

    .line 47
    .line 48
    invoke-static {v6}, LX/3Rp;->A18(Z)LX/Ddv;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_documentInFrame:LX/2J2;

    .line 53
    .line 54
    const/4 v4, 0x0

    .line 55
    new-instance v0, LX/ERk;

    .line 56
    .line 57
    invoke-direct {v0, v4, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 58
    .line 59
    .line 60
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentInFrame:LX/2J3;

    .line 61
    .line 62
    const/4 v0, -0x2

    .line 63
    sget-object v3, LX/FkO;->A00:Ljava/lang/Integer;

    .line 64
    .line 65
    invoke-static {v3, v0}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 70
    .line 71
    invoke-static {v0}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->effects:LX/2Lw;

    .line 76
    .line 77
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 78
    .line 79
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 80
    .line 81
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->SERVER_REFRESH:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 82
    .line 83
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 84
    .line 85
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolve()V

    .line 86
    .line 87
    .line 88
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    new-instance v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$1;

    .line 93
    .line 94
    invoke-direct {v1, p0, v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 95
    .line 96
    .line 97
    sget-object v0, LX/39s;->A00:LX/39s;

    .line 98
    .line 99
    invoke-static {v3, v0, v1, v2}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 100
    .line 101
    .line 102
    return-void
.end method

.method public static final synthetic access$applyResult(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->applyResult(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$clearFiles(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$confirmed(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->confirmed()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$delete(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Ljava/io/File;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->delete(Ljava/io/File;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$finalFailure(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->finalFailure()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getAwaitingSubmit$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 1
    .line 2
    return p0
.end method

.method public static final synthetic access$getContext$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)Landroid/content/Context;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->context:Landroid/content/Context;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getFilePrefix(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdSide;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->getFilePrefix(Lcom/facebook/aura/activation/ageverification/IdSide;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getPollDeadlineMs$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public static final synthetic access$getPreviousAttemptTime$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->previousAttemptTime:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSubmittedPhotos$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getUserId$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->userId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_state$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$logStep(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logStep(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$resolve(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolve()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$resolved(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolved()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$restart(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->restart()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$review(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->review(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$setAwaitingSubmit$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setPollDeadlineMs$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;J)V
    .locals 0

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setPreviousAttemptTime$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Ljava/lang/Long;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->previousAttemptTime:Ljava/lang/Long;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setResolvedMethod$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$setSubmitted$p(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Z)V
    .locals 0

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submitted:Z

    .line 1
    .line 2
    return-void
.end method

.method public static final synthetic access$showsBackOn(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->showsBackOn(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$unavailable(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->unavailable()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$with(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->with(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final applyResult(Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;)V
    .locals 5

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->attempt:Lcom/facebook/aura/activation/ageverification/AttemptView;

    .line 1
    .line 2
    const/4 v4, 0x0

    .line 3
    if-eqz v1, :cond_2

    .line 4
    .line 5
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AttemptView;->updatedTime:Ljava/lang/Long;

    .line 6
    .line 7
    :goto_0
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->previousAttemptTime:Ljava/lang/Long;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/AttemptView;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 12
    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 16
    .line 17
    :cond_1
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    iput-boolean v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 21
    .line 22
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeCheckReview;

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 25
    .line 26
    invoke-virtual {v1, v0, p1, v4}, Lcom/facebook/aura/activation/ageverification/AgeCheckReview;->logResult(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;Ljava/lang/Integer;)V

    .line 27
    .line 28
    .line 29
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->methods:Ljava/util/List;

    .line 30
    .line 31
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 32
    .line 33
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStatus;->state:Lcom/facebook/aura/activation/ageverification/AgeVerificationState;

    .line 38
    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    packed-switch v0, :pswitch_data_0

    .line 46
    .line 47
    .line 48
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 49
    .line 50
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 51
    .line 52
    .line 53
    throw v0

    .line 54
    :cond_2
    move-object v0, v4

    .line 55
    goto :goto_0

    .line 56
    :pswitch_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->confirmed()V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :pswitch_1
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolved()V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :pswitch_2
    if-eqz v1, :cond_3

    .line 65
    .line 66
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 67
    .line 68
    sget-object v1, Lcom/facebook/aura/activation/ageverification/RetryAction;->RECAPTURE:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 69
    .line 70
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 71
    .line 72
    invoke-direct {v0, v1, v3, v3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 73
    .line 74
    .line 75
    invoke-static {v2, v4, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_3
    :pswitch_3
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->finalFailure()V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    nop

    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_3
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_3
        :pswitch_3
    .end packed-switch
.end method

.method private final clearFiles()V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$clearFiles$1;

    .line 10
    .line 11
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$clearFiles$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 12
    .line 13
    .line 14
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method private final confirmed()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 1
    .line 2
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 3
    .line 4
    .line 5
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 6
    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 12
    .line 13
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;-><init>(Z)V

    .line 14
    .line 15
    .line 16
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->CONFIRMED:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 22
    .line 23
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final delete(Ljava/io/File;)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$delete$1;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$delete$1;-><init>(Ljava/io/File;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method private final deletePhotos(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;)V
    .locals 3

    .line 0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    if-eqz v1, :cond_1

    .line 4
    .line 5
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 6
    .line 7
    :goto_0
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 12
    .line 13
    :cond_0
    filled-new-array {v2, v0}, [Ljava/io/File;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Ljava/io/File;

    .line 36
    .line 37
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->delete(Ljava/io/File;)V

    .line 38
    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_1
    move-object v2, v0

    .line 42
    goto :goto_0

    .line 43
    :cond_2
    return-void
.end method

.method private final finalFailure()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 1
    .line 2
    const/4 v2, 0x1

    .line 3
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 10
    .line 11
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 12
    .line 13
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;-><init>(Z)V

    .line 14
    .line 15
    .line 16
    invoke-static {v1, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->RESOLVED:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 22
    .line 23
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method private final getFilePrefix(Lcom/facebook/aura/activation/ageverification/IdSide;)Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/IdSide;->FRONT:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 1
    .line 2
    if-ne p1, p0, :cond_0

    .line 3
    .line 4
    const-string p0, "id_front_"

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_0
    const-string p0, "id_back_"

    .line 8
    .line 9
    return-object p0
.end method

.method private final hasPendingAttempt()Z
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 15
    .line 16
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    instance-of v1, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    :cond_0
    const/4 v0, 0x1

    .line 26
    :cond_1
    return v0
.end method

.method private final isNear([F[F)Z
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-static {p1, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    array-length v0, p1

    .line 5
    add-int/lit8 v0, v0, -0x1

    .line 6
    .line 7
    new-instance v1, LX/34l;

    .line 8
    .line 9
    invoke-direct {v1, v2, v0}, LX/34l;-><init>(II)V

    .line 10
    .line 11
    .line 12
    instance-of v0, v1, Ljava/util/Collection;

    .line 13
    .line 14
    const/4 p0, 0x1

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    move-object v0, v1

    .line 18
    check-cast v0, Ljava/util/Collection;

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    :cond_0
    return p0

    .line 27
    :cond_1
    invoke-virtual {v1}, LX/A7z;->iterator()Ljava/util/Iterator;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    move-object v0, v2

    .line 38
    check-cast v0, LX/0Xe;

    .line 39
    .line 40
    invoke-virtual {v0}, LX/0Xe;->A01()I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    aget v1, p1, v0

    .line 45
    .line 46
    aget v0, p2, v0

    .line 47
    .line 48
    sub-float/2addr v1, v0

    .line 49
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    const v0, 0x3cf5c28f    # 0.03f

    .line 54
    .line 55
    .line 56
    cmpg-float v0, v1, v0

    .line 57
    .line 58
    if-lez v0, :cond_2

    .line 59
    .line 60
    const/4 p0, 0x0

    .line 61
    return p0
.end method

.method private final isPortraitIn(Lcom/facebook/aura/activation/ageverification/NormalizedFace;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Lcom/facebook/aura/activation/ageverification/IdDocument;)Z
    .locals 4

    .line 0
    iget v3, p1, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerX:F

    .line 1
    .line 2
    iget p0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->height:F

    .line 3
    .line 4
    const/high16 v0, 0x40000000    # 2.0f

    .line 5
    .line 6
    div-float v2, p0, v0

    .line 7
    .line 8
    sub-float v1, v3, v2

    .line 9
    .line 10
    iget v0, p2, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 11
    .line 12
    cmpl-float v0, v1, v0

    .line 13
    .line 14
    if-ltz v0, :cond_1

    .line 15
    .line 16
    add-float/2addr v3, v2

    .line 17
    iget v0, p2, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 18
    .line 19
    cmpg-float v0, v3, v0

    .line 20
    .line 21
    if-gtz v0, :cond_1

    .line 22
    .line 23
    iget v1, p1, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerY:F

    .line 24
    .line 25
    sub-float v0, v1, v2

    .line 26
    .line 27
    iget v3, p2, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 28
    .line 29
    cmpl-float v0, v0, v3

    .line 30
    .line 31
    if-ltz v0, :cond_1

    .line 32
    .line 33
    add-float/2addr v1, v2

    .line 34
    iget v2, p2, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 35
    .line 36
    cmpg-float v0, v1, v2

    .line 37
    .line 38
    if-gtz v0, :cond_1

    .line 39
    .line 40
    sget-object v1, Lcom/facebook/aura/activation/ageverification/IdDocument;->PASSPORT:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 41
    .line 42
    const v0, 0x3e4ccccd    # 0.2f

    .line 43
    .line 44
    .line 45
    if-ne p3, v1, :cond_0

    .line 46
    .line 47
    const v0, 0x3dcccccd    # 0.1f

    .line 48
    .line 49
    .line 50
    :cond_0
    sub-float/2addr v2, v3

    .line 51
    div-float/2addr p0, v2

    .line 52
    cmpg-float v0, v0, p0

    .line 53
    .line 54
    if-gtz v0, :cond_1

    .line 55
    .line 56
    const/high16 v0, 0x3f000000    # 0.5f

    .line 57
    .line 58
    cmpg-float v1, p0, v0

    .line 59
    .line 60
    const/4 v0, 0x1

    .line 61
    if-lez v1, :cond_2

    .line 62
    .line 63
    :cond_1
    const/4 v0, 0x0

    .line 64
    :cond_2
    return v0
.end method

.method private final leave(Z)V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->hasPendingAttempt()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leftReviewPending:Z

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 11
    .line 12
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 21
    .line 22
    .line 23
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 28
    .line 29
    .line 30
    :cond_2
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 31
    .line 32
    .line 33
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 34
    .line 35
    if-eqz p1, :cond_3

    .line 36
    .line 37
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leftReviewPending:Z

    .line 38
    .line 39
    if-nez v0, :cond_3

    .line 40
    .line 41
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->BACK:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 42
    .line 43
    :goto_0
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->OTHER_METHODS:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 48
    .line 49
    goto :goto_0
.end method

.method private final logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 1

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_ID:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method private final logStep(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)V
    .locals 3

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->ID_TYPE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 5
    .line 6
    :goto_0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 9
    .line 10
    invoke-virtual {v1, v2, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->stepShown(Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->SERVER_REFRESH:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 14
    .line 15
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 16
    .line 17
    :cond_0
    return-void

    .line 18
    :cond_1
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 19
    .line 20
    if-eqz v0, :cond_2

    .line 21
    .line 22
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->ID_PHOTOS:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_2
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 26
    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->ID_CAPTURE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 33
    .line 34
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_6

    .line 39
    .line 40
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 41
    .line 42
    if-eqz v0, :cond_4

    .line 43
    .line 44
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 45
    .line 46
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 47
    .line 48
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 49
    .line 50
    if-eq v1, v0, :cond_6

    .line 51
    .line 52
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->SELFIE_REVIEWING:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_4
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 56
    .line 57
    if-eqz v0, :cond_5

    .line 58
    .line 59
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->ID_ERROR:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 63
    .line 64
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_0

    .line 69
    .line 70
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 71
    .line 72
    if-nez v0, :cond_0

    .line 73
    .line 74
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 75
    .line 76
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 77
    .line 78
    .line 79
    throw v0

    .line 80
    :cond_6
    sget-object v2, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;->ID_REVIEWING:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckStep;

    .line 81
    .line 82
    goto :goto_0
.end method

.method private final onDocumentSeen(Lcom/facebook/aura/activation/ageverification/IdSide;[FZJ)V
    .locals 10

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v6

    .line 6
    instance-of v0, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    check-cast v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 11
    .line 12
    if-eqz v6, :cond_2

    .line 13
    .line 14
    iget-boolean v0, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 15
    .line 16
    if-nez v0, :cond_2

    .line 17
    .line 18
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 19
    .line 20
    if-ne v0, p1, :cond_2

    .line 21
    .line 22
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->autoCaptured:Z

    .line 23
    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 27
    .line 28
    .line 29
    move-result-wide v1

    .line 30
    const/4 v7, 0x0

    .line 31
    const/4 v5, 0x1

    .line 32
    if-nez p3, :cond_0

    .line 33
    .line 34
    iget-wide v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentSeenMs:J

    .line 35
    .line 36
    sub-long v8, v1, v3

    .line 37
    .line 38
    const-wide/16 v3, 0x190

    .line 39
    .line 40
    cmp-long v0, v8, v3

    .line 41
    .line 42
    const/4 v3, 0x0

    .line 43
    if-lez v0, :cond_1

    .line 44
    .line 45
    :cond_0
    const/4 v3, 0x1

    .line 46
    :cond_1
    if-nez p2, :cond_3

    .line 47
    .line 48
    if-eqz v3, :cond_2

    .line 49
    .line 50
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_documentInFrame:LX/2J2;

    .line 51
    .line 52
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    :goto_0
    invoke-static {v3, v2}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_2
    return-void

    .line 60
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentAnchor:[F

    .line 61
    .line 62
    if-eqz v0, :cond_4

    .line 63
    .line 64
    if-nez v3, :cond_4

    .line 65
    .line 66
    invoke-direct {p0, v0, p2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->isNear([F[F)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_5

    .line 71
    .line 72
    :cond_4
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentAnchor:[F

    .line 73
    .line 74
    iput-wide v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->steadySinceMs:J

    .line 75
    .line 76
    :cond_5
    iput-wide v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentSeenMs:J

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_documentInFrame:LX/2J2;

    .line 79
    .line 80
    invoke-static {v0, v5}, LX/8ml;->A0I(Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    iget-wide v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->steadySinceMs:J

    .line 84
    .line 85
    sub-long/2addr v1, v3

    .line 86
    cmp-long v0, v1, p4

    .line 87
    .line 88
    if-ltz v0, :cond_2

    .line 89
    .line 90
    iput-boolean v5, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->autoCaptured:Z

    .line 91
    .line 92
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_documentInFrame:LX/2J2;

    .line 93
    .line 94
    invoke-static {v0, v7}, LX/602;->A1H(Ljava/lang/Object;Z)V

    .line 95
    .line 96
    .line 97
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 98
    .line 99
    iget-object v1, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 100
    .line 101
    iget-object v0, v6, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 102
    .line 103
    new-instance v2, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 104
    .line 105
    invoke-direct {v2, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Z)V

    .line 106
    .line 107
    .line 108
    goto :goto_0
.end method

.method private final photo(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/IdSide;->FRONT:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 1
    .line 2
    if-ne p2, p0, :cond_0

    .line 3
    .line 4
    iget-object p0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_0
    iget-object p0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 8
    .line 9
    return-object p0
.end method

.method private final photos(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
    .locals 1

    .line 0
    if-eqz p2, :cond_1

    .line 1
    .line 2
    invoke-virtual {p1}, Lcom/facebook/aura/activation/ageverification/IdDocument;->getSides()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/4 p0, 0x1

    .line 7
    if-eq v0, p0, :cond_0

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    :cond_0
    :goto_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 12
    .line 13
    invoke-direct {v0, p1, p2, p3, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Z)V

    .line 14
    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_1
    const/4 p0, 0x0

    .line 18
    goto :goto_0
.end method

.method private final resolve()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 1
    .line 2
    invoke-static {v0}, LX/603;->A0z(LX/Cbu;)LX/2M4;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    const-wide/16 v0, 0x0

    .line 7
    .line 8
    iput-wide v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->awaitingSubmit:Z

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 14
    .line 15
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 16
    .line 17
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;

    .line 25
    .line 26
    invoke-direct {v0, p0, v2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$resolve$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 27
    .line 28
    .line 29
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 34
    .line 35
    return-void
.end method

.method private final resolved()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 1
    .line 2
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 3
    .line 4
    .line 5
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 9
    .line 10
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;-><init>(Z)V

    .line 11
    .line 12
    .line 13
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->RESOLVED:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 19
    .line 20
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method private final restart()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 1
    .line 2
    .line 3
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v1, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method private final retry(Lcom/facebook/aura/activation/ageverification/RetryAction;)V
    .locals 2

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v1

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq v1, v0, :cond_2

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq v1, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq v1, v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-eq v1, v0, :cond_0

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-eq v1, v0, :cond_0

    .line 18
    .line 19
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 22
    .line 23
    .line 24
    throw v0

    .line 25
    :cond_0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolve()V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submit(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_2
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->restart()V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method private final review(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)V
    .locals 5

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    iget-wide v3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 3
    .line 4
    const-wide/16 v1, 0x0

    .line 5
    .line 6
    cmp-long v0, v3, v1

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 11
    .line 12
    .line 13
    move-result-wide v2

    .line 14
    const-wide/32 v0, 0x1d4c0

    .line 15
    .line 16
    .line 17
    add-long/2addr v2, v0

    .line 18
    iput-wide v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 19
    .line 20
    :cond_0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 24
    .line 25
    invoke-direct {v0, p1, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V

    .line 26
    .line 27
    .line 28
    invoke-static {v2, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->startPolling()V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method private final showsBackOn(Lcom/facebook/aura/activation/ageverification/IdAgeStepState;)Z
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 1
    .line 2
    invoke-static {p1, p0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-nez p0, :cond_0

    .line 7
    .line 8
    instance-of p0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 9
    .line 10
    if-nez p0, :cond_0

    .line 11
    .line 12
    instance-of p1, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 13
    .line 14
    const/4 p0, 0x1

    .line 15
    if-eqz p1, :cond_1

    .line 16
    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    :cond_1
    return p0
.end method

.method private final startPolling()V
    .locals 4

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resumed:Z

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v0, 0x1

    .line 13
    if-ne v1, v0, :cond_1

    .line 14
    .line 15
    :cond_0
    return-void

    .line 16
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 17
    .line 18
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 28
    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 32
    .line 33
    if-eqz v2, :cond_0

    .line 34
    .line 35
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;

    .line 40
    .line 41
    invoke-direct {v0, v2, p0, v3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$startPolling$1;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 42
    .line 43
    .line 44
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 49
    .line 50
    return-void
.end method

.method private final submit(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;)V
    .locals 5

    .line 0
    iget-object v2, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 1
    .line 2
    if-eqz v2, :cond_1

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 5
    .line 6
    const/4 v4, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-interface {v0, v4}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submittedPhotos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 17
    .line 18
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 22
    .line 23
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 24
    .line 25
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 28
    .line 29
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptStarted(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 30
    .line 31
    .line 32
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->ID_FRONT:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 33
    .line 34
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 35
    .line 36
    new-instance v3, LX/IBK;

    .line 37
    .line 38
    invoke-direct {v3, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 42
    .line 43
    if-eqz v0, :cond_2

    .line 44
    .line 45
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;->ID_BACK:Lcom/facebook/aura/activation/ageverification/AgeVerificationUploadKind;

    .line 46
    .line 47
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 48
    .line 49
    new-instance v0, LX/IBK;

    .line 50
    .line 51
    invoke-direct {v0, v2, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :goto_0
    filled-new-array {v3, v0}, [LX/IBK;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-static {v0}, LX/1HA;->A09(Ljava/lang/Iterable;)Ljava/util/Map;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;

    .line 71
    .line 72
    invoke-direct {v0, p1, v2, p0, v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$submit$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Ljava/util/Map;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/2M4;)V

    .line 73
    .line 74
    .line 75
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 80
    .line 81
    :cond_1
    return-void

    .line 82
    :cond_2
    move-object v0, v4

    .line 83
    goto :goto_0
.end method

.method private final unavailable()V
    .locals 1

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submitted:Z

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->finalFailure()V

    .line 5
    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->UNAVAILABLE:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 11
    .line 12
    invoke-interface {p0, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method private final with(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdSide;->FRONT:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 1
    .line 2
    iget-object v1, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 3
    .line 4
    if-ne p2, v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 7
    .line 8
    invoke-direct {p0, v1, p3, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->photos(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 14
    .line 15
    invoke-direct {p0, v1, v0, p3}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->photos(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method


# virtual methods
.method public final getDocumentInFrame()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentInFrame:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEffects()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->effects:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLeftReviewPending()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leftReviewPending:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getResolvedMethod()Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUi()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepUi;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->ui:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onBack(Z)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->BACK:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 3
    .line 4
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 7
    .line 8
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 13
    .line 14
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 19
    .line 20
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 21
    .line 22
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 23
    .line 24
    :goto_0
    invoke-interface {v2, v1}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :goto_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->BACK_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 28
    .line 29
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 38
    .line 39
    invoke-direct {p0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->deletePhotos(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;)V

    .line 40
    .line 41
    .line 42
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 43
    .line 44
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 45
    .line 46
    new-instance v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 47
    .line 48
    invoke-direct {v1, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 53
    .line 54
    if-eqz v0, :cond_2

    .line 55
    .line 56
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leave(Z)V

    .line 57
    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 61
    .line 62
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-nez v0, :cond_3

    .line 67
    .line 68
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 69
    .line 70
    if-nez v0, :cond_3

    .line 71
    .line 72
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Submitting;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_4

    .line 79
    .line 80
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 81
    .line 82
    if-nez v0, :cond_4

    .line 83
    .line 84
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 85
    .line 86
    if-nez v0, :cond_4

    .line 87
    .line 88
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 89
    .line 90
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 91
    .line 92
    .line 93
    throw v0

    .line 94
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 95
    .line 96
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 97
    .line 98
    .line 99
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 100
    .line 101
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->BACK:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 102
    .line 103
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_4
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 108
    .line 109
    return-void
.end method

.method public final onCaptureFailed()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 15
    .line 16
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 17
    .line 18
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 22
    .line 23
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Z)V

    .line 24
    .line 25
    .line 26
    invoke-static {p0, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    sget-object v1, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 30
    .line 31
    const v0, 0x7f12005b

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1, v0}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(I)V

    .line 35
    .line 36
    .line 37
    :cond_0
    return-void
.end method

.method public final onCardEdges(Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V
    .locals 7

    .line 0
    sget-object v2, Lcom/facebook/aura/activation/ageverification/IdSide;->BACK:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 1
    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    new-array v3, v0, [F

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->left:F

    .line 9
    .line 10
    aput v0, v3, v1

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->top:F

    .line 14
    .line 15
    aput v0, v3, v1

    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->right:F

    .line 19
    .line 20
    aput v0, v3, v1

    .line 21
    .line 22
    const/4 v1, 0x3

    .line 23
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;->bottom:F

    .line 24
    .line 25
    aput v0, v3, v1

    .line 26
    .line 27
    :goto_0
    const/4 v4, 0x0

    .line 28
    const-wide/16 v5, 0x1f4

    .line 29
    .line 30
    move-object v1, p0

    .line 31
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onDocumentSeen(Lcom/facebook/aura/activation/ageverification/IdSide;[FZJ)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_0
    const/4 v3, 0x0

    .line 36
    goto :goto_0
.end method

.method public onCleared()V
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onCleared$1;

    .line 7
    .line 8
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onCleared$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final onDocumentContinue()V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;->selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 16
    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CONTINUE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 20
    .line 21
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 25
    .line 26
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->methodSelectedIfNew(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 29
    .line 30
    .line 31
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->PICK:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 32
    .line 33
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 34
    .line 35
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 39
    .line 40
    invoke-direct {v0, v3, v4, v4, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Z)V

    .line 41
    .line 42
    .line 43
    invoke-static {v2, v4, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    return-void
.end method

.method public final onDocumentFrame(Lcom/facebook/aura/activation/ageverification/FaceFrame;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V
    .locals 12

    .line 0
    const/4 v4, 0x1

    .line 1
    invoke-static {p2, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    move-object v9, p0

    .line 5
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 6
    .line 7
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 12
    .line 13
    const/4 v11, 0x0

    .line 14
    if-eqz v0, :cond_6

    .line 15
    .line 16
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 17
    .line 18
    if-eqz v1, :cond_6

    .line 19
    .line 20
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 21
    .line 22
    if-eqz v0, :cond_6

    .line 23
    .line 24
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 25
    .line 26
    :goto_0
    if-eqz p1, :cond_5

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/FaceFrame;->faces:Ljava/util/List;

    .line 29
    .line 30
    if-eqz v0, :cond_5

    .line 31
    .line 32
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object v8

    .line 36
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_2

    .line 41
    .line 42
    move-object v5, v11

    .line 43
    :cond_0
    :goto_1
    check-cast v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 44
    .line 45
    if-eqz v5, :cond_5

    .line 46
    .line 47
    invoke-direct {p0, v5, p2, v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->isPortraitIn(Lcom/facebook/aura/activation/ageverification/NormalizedFace;Lcom/facebook/aura/activation/ageverification/NormalizedRect;Lcom/facebook/aura/activation/ageverification/IdDocument;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_5

    .line 52
    .line 53
    :goto_2
    sget-object v10, Lcom/facebook/aura/activation/ageverification/IdSide;->FRONT:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 54
    .line 55
    const/4 v1, 0x0

    .line 56
    if-eqz v5, :cond_1

    .line 57
    .line 58
    const/4 v0, 0x2

    .line 59
    new-array v11, v0, [F

    .line 60
    .line 61
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerX:F

    .line 62
    .line 63
    aput v0, v11, v1

    .line 64
    .line 65
    iget v0, v5, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->centerY:F

    .line 66
    .line 67
    aput v0, v11, v4

    .line 68
    .line 69
    :cond_1
    invoke-static {p1}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result p0

    .line 73
    const-wide/16 p1, 0x12c

    .line 74
    .line 75
    invoke-direct/range {v9 .. v14}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onDocumentSeen(Lcom/facebook/aura/activation/ageverification/IdSide;[FZJ)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_2
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_0

    .line 88
    .line 89
    move-object v0, v5

    .line 90
    check-cast v0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 91
    .line 92
    iget v3, v0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->height:F

    .line 93
    .line 94
    :cond_3
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    move-object v0, v2

    .line 99
    check-cast v0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;

    .line 100
    .line 101
    iget v1, v0, Lcom/facebook/aura/activation/ageverification/NormalizedFace;->height:F

    .line 102
    .line 103
    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-gez v0, :cond_4

    .line 108
    .line 109
    move-object v5, v2

    .line 110
    move v3, v1

    .line 111
    :cond_4
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-nez v0, :cond_3

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_5
    move-object v5, v11

    .line 119
    goto :goto_2

    .line 120
    :cond_6
    move-object v6, v11

    .line 121
    goto :goto_0
.end method

.method public final onDocumentSelected(Lcom/facebook/aura/activation/ageverification/IdDocument;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;

    .line 17
    .line 18
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$DocumentType;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;)V

    .line 19
    .line 20
    .line 21
    invoke-static {p0, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void
.end method

.method public final onFailedRefreshes(I)V
    .locals 3

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->handledFailedRefreshes:I

    .line 1
    .line 2
    if-le p1, v0, :cond_0

    .line 3
    .line 4
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->handledFailedRefreshes:I

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 7
    .line 8
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 21
    .line 22
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolved;->afterFinalFailure:Z

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    const/4 p0, 0x0

    .line 27
    :goto_0
    const/4 v2, 0x1

    .line 28
    const/4 v1, 0x0

    .line 29
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 30
    .line 31
    invoke-direct {v0, p0, v1, v2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;-><init>(Lcom/facebook/aura/activation/ageverification/RetryAction;ZZ)V

    .line 32
    .line 33
    .line 34
    invoke-static {p1, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    return-void

    .line 38
    :cond_1
    sget-object p0, Lcom/facebook/aura/activation/ageverification/RetryAction;->REFRESH:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 39
    .line 40
    goto :goto_0
.end method

.method public final onHidden()V
    .locals 2

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->hasPendingAttempt()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->INSTANCE:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckFunnelLogging;->attemptCancelled(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 19
    .line 20
    .line 21
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 22
    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    invoke-interface {v0, v1}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 26
    .line 27
    .line 28
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 29
    .line 30
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    instance-of v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 35
    .line 36
    if-nez v0, :cond_3

    .line 37
    .line 38
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->clearFiles()V

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 42
    .line 43
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 44
    .line 45
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 49
    .line 50
    invoke-interface {v0}, LX/DpP;->Ai2()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    instance-of v0, v0, LX/34S;

    .line 55
    .line 56
    xor-int/lit8 v0, v0, 0x1

    .line 57
    .line 58
    if-nez v0, :cond_3

    .line 59
    .line 60
    return-void
.end method

.method public final onLearnMore()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->HOW_ID_CHECKS_WORK_LINK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onOtherMethods(Z)V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->TRY_ANOTHER_METHOD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 3
    .line 4
    .line 5
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->leave(Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final onPause()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resumed:Z

    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollJob:LX/Cbu;

    .line 4
    .line 5
    invoke-static {v0}, LX/3Rr;->A1M(LX/Cbu;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final onPhotoTaken(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V
    .locals 4

    .line 0
    move-object v2, p1

    .line 1
    move-object p1, p2

    .line 2
    invoke-static {v2, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    move-object v3, p0

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 7
    .line 8
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    check-cast p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 17
    .line 18
    if-eqz p0, :cond_0

    .line 19
    .line 20
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-static {v3}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 p2, 0x0

    .line 29
    new-instance v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;

    .line 30
    .line 31
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel$onPhotoTaken$1;-><init>(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/NormalizedRect;LX/2M4;)V

    .line 32
    .line 33
    .line 34
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final onPhotoTips()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->ID_PHOTO_TIPS_LINK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onPhotosContinue()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->canContinue:Z

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CONTINUE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 21
    .line 22
    .line 23
    invoke-direct {p0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->submit(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final onRemovePhoto(Lcom/facebook/aura/activation/ageverification/IdSide;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    check-cast v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 16
    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    invoke-direct {p0, v3, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->photo(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    if-eqz v1, :cond_0

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->DELETE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 26
    .line 27
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 28
    .line 29
    .line 30
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->file:Ljava/io/File;

    .line 31
    .line 32
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->delete(Ljava/io/File;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 36
    .line 37
    invoke-direct {p0, v3, p1, v2}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->with(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;)Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {v1, v0}, LX/2J2;->Afc(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    return-void
.end method

.method public final onResume()V
    .locals 4

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onShown()V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    iput-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resumed:Z

    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 7
    .line 8
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState;

    .line 13
    .line 14
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Reviewing;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 19
    .line 20
    .line 21
    move-result-wide v2

    .line 22
    const-wide/32 v0, 0x1d4c0

    .line 23
    .line 24
    .line 25
    add-long/2addr v2, v0

    .line 26
    iput-wide v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->pollDeadlineMs:J

    .line 27
    .line 28
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->startPolling()V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void

    .line 32
    :cond_1
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 37
    .line 38
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retryOnResume:Z

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 43
    .line 44
    if-eqz v0, :cond_2

    .line 45
    .line 46
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->retry(Lcom/facebook/aura/activation/ageverification/RetryAction;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_effects:LX/EYl;

    .line 51
    .line 52
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;->RESOLVED:Lcom/facebook/aura/activation/ageverification/IdAgeStepEffect;

    .line 53
    .line 54
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final onRetry()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->RETRY_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 21
    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->RETRY:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 24
    .line 25
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 26
    .line 27
    invoke-direct {p0, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->retry(Lcom/facebook/aura/activation/ageverification/RetryAction;)V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method public final onShown()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Resolving;

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->job:LX/Cbu;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, LX/Cbu;->isActive()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/4 v0, 0x1

    .line 23
    if-ne v1, v0, :cond_1

    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :cond_1
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->resolve()V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public final onShutter()V
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-boolean v0, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CAMERA_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 21
    .line 22
    .line 23
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 24
    .line 25
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 26
    .line 27
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 31
    .line 32
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Z)V

    .line 33
    .line 34
    .line 35
    invoke-static {p0, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
.end method

.method public final onTakePhoto(Lcom/facebook/aura/activation/ageverification/IdSide;)V
    .locals 5

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 5
    .line 6
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    check-cast v3, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 16
    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    invoke-direct {p0, v3, p1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->photo(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;)Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->ID_PHOTO_TILE:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 26
    .line 27
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 28
    .line 29
    .line 30
    sget-object v0, Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;->PICK:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 31
    .line 32
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->stepVia:Lcom/facebook/aura/activation/ageverification/intf/AgeCheckVia;

    .line 33
    .line 34
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentAnchor:[F

    .line 35
    .line 36
    const-wide/16 v0, 0x0

    .line 37
    .line 38
    iput-wide v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentSeenMs:J

    .line 39
    .line 40
    iput-boolean v4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->autoCaptured:Z

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_documentInFrame:LX/2J2;

    .line 43
    .line 44
    invoke-static {v0, v4}, LX/602;->A1H(Ljava/lang/Object;Z)V

    .line 45
    .line 46
    .line 47
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->_state:LX/2J2;

    .line 48
    .line 49
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 50
    .line 51
    invoke-direct {v0, v3, p1, v4}, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;Lcom/facebook/aura/activation/ageverification/IdSide;Z)V

    .line 52
    .line 53
    .line 54
    invoke-static {v1, v2, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_0
    return-void
.end method
