.class public final Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/DZ7;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/DZ7<",
        "Ljava/util/List<",
        "+",
        "Ljava/lang/String;",
        ">;>;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    message = "Anti-pattern: lenient decoding hides contract bugs. Fail fast on malformed wire fields; don\'t add new uses."
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

.field public static final delegate:LX/DZ7;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DZ7<",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;

    .line 6
    .line 7
    sget-object v0, LX/DYp;->A01:LX/DYp;

    .line 8
    .line 9
    invoke-static {v0}, LX/DZ8;->A01(LX/DZ7;)LX/Dbs;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->delegate:LX/DZ7;

    .line 14
    .line 15
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {v0}, LX/DZ7;->getDescriptor()LX/Da5;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sput-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->descriptor:LX/Da5;

    .line 24
    .line 25
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->deserialize(LX/DYy;)Ljava/util/List;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public deserialize(LX/DYy;)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DYy;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lkotlinx/serialization/json/JsonElementSerializer;->A00:Lkotlinx/serialization/json/JsonElementSerializer;

    .line 5
    .line 6
    invoke-interface {p1, v0}, LX/DYy;->A8g(LX/Dci;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    check-cast p1, Lkotlinx/serialization/json/JsonElement;

    .line 11
    .line 12
    :try_start_0
    sget-object p0, Lcom/facebook/aura/json/HatchJsonKt;->HatchJson:LX/Dcb;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->delegate:LX/DZ7;

    .line 15
    .line 16
    invoke-virtual {p0, v0, p1}, LX/Dcb;->A01(LX/Dci;Lkotlinx/serialization/json/JsonElement;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    check-cast p0, Ljava/util/List;

    .line 21
    .line 22
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    :catchall_0
    move-exception v0

    .line 24
    new-instance p0, LX/2PH;

    .line 25
    .line 26
    invoke-direct {p0, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    instance-of v0, p0, LX/2PH;

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    :cond_0
    check-cast p0, Ljava/util/List;

    .line 35
    .line 36
    return-object p0
.end method

.method public getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p2, Ljava/util/List;

    .line 1
    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->serialize(LX/DZ5;Ljava/util/List;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public serialize(LX/DZ5;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DZ5;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 268435456
    const/4 p0, 0x0

    .line 268435457
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    sget-object p0, Lcom/facebook/aura/activation/ageverification/LenientHeadMovementsSerializer;->delegate:LX/DZ7;

    .line 268435461
    .line 268435462
    invoke-static {p0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object p0

    .line 268435466
    invoke-interface {p1, p2, p0}, LX/DZ5;->AAV(Ljava/lang/Object;LX/DZE;)V

    .line 268435467
    .line 268435468
    .line 268435469
    return-void
.end method
