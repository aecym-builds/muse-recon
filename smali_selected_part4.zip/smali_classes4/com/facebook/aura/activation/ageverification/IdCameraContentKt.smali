.class public abstract Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "IdCameraContent"


# direct methods
.method public static final IdCameraContent(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V
    .locals 38

    .line 0
    move-object/from16 v30, p2

    .line 1
    .line 2
    const/16 v29, 0x0

    .line 3
    .line 4
    move-object/from16 v4, p0

    .line 5
    .line 6
    move-object/from16 v7, p1

    .line 7
    .line 8
    invoke-static {v4, v7}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v28

    .line 12
    const v0, 0x24b77bbe

    .line 13
    .line 14
    .line 15
    move-object/from16 v3, p3

    .line 16
    .line 17
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 18
    .line 19
    .line 20
    move/from16 v2, p4

    .line 21
    .line 22
    and-int/lit8 v0, p4, 0x6

    .line 23
    .line 24
    if-nez v0, :cond_16

    .line 25
    .line 26
    invoke-static {v4, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0}, LX/003;->A06(I)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    or-int v1, v1, p4

    .line 35
    .line 36
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 37
    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    invoke-static {v7, v3, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {v0}, LX/003;->A07(I)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    or-int/2addr v1, v0

    .line 49
    :cond_0
    and-int/lit8 v5, p5, 0x4

    .line 50
    .line 51
    if-eqz v5, :cond_15

    .line 52
    .line 53
    or-int/lit16 v1, v1, 0x180

    .line 54
    .line 55
    :cond_1
    :goto_1
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_21

    .line 64
    .line 65
    if-eqz v5, :cond_2

    .line 66
    .line 67
    sget-object v30, LX/3C1;->A00:LX/3Cb;

    .line 68
    .line 69
    :cond_2
    invoke-static {v3}, LX/3Rp;->A01(LX/2d4;)Landroid/content/Context;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    sget-object v0, LX/39S;->A00:LX/Ip3;

    .line 74
    .line 75
    invoke-interface {v3, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v11

    .line 79
    check-cast v11, LX/07p;

    .line 80
    .line 81
    sget-object v0, LX/3Fe;->A04:LX/Ip3;

    .line 82
    .line 83
    invoke-interface {v3, v0}, LX/2d4;->A6z(LX/Iow;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v9

    .line 87
    check-cast v9, LX/34Y;

    .line 88
    .line 89
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 90
    .line 91
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 92
    .line 93
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModelKt;->getFrameAspect(Lcom/facebook/aura/activation/ageverification/IdDocument;)F

    .line 94
    .line 95
    .line 96
    move-result v27

    .line 97
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v8

    .line 101
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 102
    .line 103
    if-ne v8, v0, :cond_3

    .line 104
    .line 105
    new-instance v8, Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 106
    .line 107
    invoke-direct {v8, v5}, Lcom/facebook/aura/activation/ageverification/IdCamera;-><init>(Landroid/content/Context;)V

    .line 108
    .line 109
    .line 110
    invoke-interface {v3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_3
    check-cast v8, Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 114
    .line 115
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v10

    .line 119
    if-ne v10, v0, :cond_4

    .line 120
    .line 121
    new-instance v10, LX/FCr;

    .line 122
    .line 123
    invoke-direct {v10, v5}, LX/FCr;-><init>(Landroid/content/Context;)V

    .line 124
    .line 125
    .line 126
    sget-object v5, LX/I2w;->A01:LX/I2w;

    .line 127
    .line 128
    invoke-virtual {v10, v5}, LX/FCr;->setImplementationMode(LX/I2w;)V

    .line 129
    .line 130
    .line 131
    invoke-interface {v3, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    :cond_4
    check-cast v10, LX/FCr;

    .line 135
    .line 136
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    if-ne v5, v0, :cond_5

    .line 141
    .line 142
    const-wide/16 v5, 0x0

    .line 143
    .line 144
    new-instance v12, LX/2RQ;

    .line 145
    .line 146
    invoke-direct {v12, v5, v6}, LX/2RQ;-><init>(J)V

    .line 147
    .line 148
    .line 149
    invoke-static {v3, v12}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 150
    .line 151
    .line 152
    move-result-object v5

    .line 153
    :cond_5
    check-cast v5, Landroidx/compose/runtime/MutableState;

    .line 154
    .line 155
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J

    .line 156
    .line 157
    .line 158
    move-result-wide v12

    .line 159
    new-instance v6, LX/2RQ;

    .line 160
    .line 161
    invoke-direct {v6, v12, v13}, LX/2RQ;-><init>(J)V

    .line 162
    .line 163
    .line 164
    invoke-static {v3, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 165
    .line 166
    .line 167
    move-result-object v15

    .line 168
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J

    .line 169
    .line 170
    .line 171
    move-result-wide v12

    .line 172
    const-wide/16 v16, 0x0

    .line 173
    .line 174
    cmp-long v6, v12, v16

    .line 175
    .line 176
    if-nez v6, :cond_14

    .line 177
    .line 178
    const/4 v6, 0x0

    .line 179
    :goto_2
    invoke-static {v3, v6}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 180
    .line 181
    .line 182
    move-result-object v18

    .line 183
    iget-object v6, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 184
    .line 185
    move-object/from16 v19, v6

    .line 186
    .line 187
    invoke-interface {v3, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v6

    .line 191
    invoke-static {v3, v10, v11, v6}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 192
    .line 193
    .line 194
    move-result v14

    .line 195
    and-int/lit8 v26, v1, 0x70

    .line 196
    .line 197
    const/16 v12, 0x20

    .line 198
    .line 199
    move/from16 v6, v26

    .line 200
    .line 201
    if-eq v6, v12, :cond_6

    .line 202
    .line 203
    and-int/lit8 v6, v1, 0x40

    .line 204
    .line 205
    if-eqz v6, :cond_13

    .line 206
    .line 207
    invoke-interface {v3, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result v6

    .line 211
    if-eqz v6, :cond_13

    .line 212
    .line 213
    :cond_6
    const/4 v6, 0x1

    .line 214
    :goto_3
    or-int/2addr v14, v6

    .line 215
    and-int/lit8 v25, v1, 0xe

    .line 216
    .line 217
    const/4 v13, 0x4

    .line 218
    move/from16 v6, v25

    .line 219
    .line 220
    if-eq v6, v13, :cond_7

    .line 221
    .line 222
    and-int/lit8 v6, v1, 0x8

    .line 223
    .line 224
    if-eqz v6, :cond_12

    .line 225
    .line 226
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v6

    .line 230
    if-eqz v6, :cond_12

    .line 231
    .line 232
    :cond_7
    const/4 v6, 0x1

    .line 233
    :goto_4
    or-int/2addr v6, v14

    .line 234
    invoke-static {v3, v15, v9, v6}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 235
    .line 236
    .line 237
    move-result v14

    .line 238
    move/from16 v6, v27

    .line 239
    .line 240
    invoke-interface {v3, v6}, LX/2d4;->A66(F)Z

    .line 241
    .line 242
    .line 243
    move-result v12

    .line 244
    move-object/from16 v6, v18

    .line 245
    .line 246
    invoke-static {v3, v6, v14, v12}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 247
    .line 248
    .line 249
    move-result v12

    .line 250
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v6

    .line 254
    if-nez v12, :cond_8

    .line 255
    .line 256
    if-ne v6, v0, :cond_9

    .line 257
    .line 258
    :cond_8
    const/16 p3, 0x0

    .line 259
    .line 260
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;

    .line 261
    .line 262
    move-object/from16 v31, v6

    .line 263
    .line 264
    move-object/from16 v32, v8

    .line 265
    .line 266
    move-object/from16 v33, v10

    .line 267
    .line 268
    move-object/from16 v34, v11

    .line 269
    .line 270
    move-object/from16 v35, v7

    .line 271
    .line 272
    move-object/from16 v36, v4

    .line 273
    .line 274
    move-object/from16 v37, v9

    .line 275
    .line 276
    move/from16 p0, v27

    .line 277
    .line 278
    move-object/from16 p1, v15

    .line 279
    .line 280
    move-object/from16 p2, v18

    .line 281
    .line 282
    invoke-direct/range {v31 .. v41}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;LX/FCr;LX/07p;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLX/16A;LX/16A;LX/2M4;)V

    .line 283
    .line 284
    .line 285
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    :cond_9
    check-cast v6, LX/JDN;

    .line 289
    .line 290
    move-object/from16 v12, v19

    .line 291
    .line 292
    invoke-static {v3, v8, v11, v12, v6}, LX/CdB;->A02(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;LX/JDN;)V

    .line 293
    .line 294
    .line 295
    invoke-interface {v3, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v11

    .line 299
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    if-nez v11, :cond_a

    .line 304
    .line 305
    if-ne v6, v0, :cond_b

    .line 306
    .line 307
    :cond_a
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;

    .line 308
    .line 309
    invoke-direct {v6, v8}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdCamera;)V

    .line 310
    .line 311
    .line 312
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 313
    .line 314
    .line 315
    :cond_b
    invoke-static {v3, v6, v8}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    iget-boolean v6, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 319
    .line 320
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 321
    .line 322
    .line 323
    move-result-object v11

    .line 324
    move/from16 v6, v25

    .line 325
    .line 326
    if-eq v6, v13, :cond_c

    .line 327
    .line 328
    and-int/lit8 v6, v1, 0x8

    .line 329
    .line 330
    if-eqz v6, :cond_11

    .line 331
    .line 332
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 333
    .line 334
    .line 335
    move-result v6

    .line 336
    if-eqz v6, :cond_11

    .line 337
    .line 338
    :cond_c
    const/4 v6, 0x1

    .line 339
    :goto_5
    invoke-static {v3, v15, v9, v6}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 340
    .line 341
    .line 342
    move-result v12

    .line 343
    move/from16 v6, v27

    .line 344
    .line 345
    invoke-interface {v3, v6}, LX/2d4;->A66(F)Z

    .line 346
    .line 347
    .line 348
    move-result v6

    .line 349
    or-int/2addr v12, v6

    .line 350
    const/16 v24, 0x20

    .line 351
    .line 352
    move/from16 v13, v24

    .line 353
    .line 354
    move/from16 v6, v26

    .line 355
    .line 356
    if-eq v6, v13, :cond_d

    .line 357
    .line 358
    and-int/lit8 v6, v1, 0x40

    .line 359
    .line 360
    if-eqz v6, :cond_10

    .line 361
    .line 362
    invoke-interface {v3, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 363
    .line 364
    .line 365
    move-result v6

    .line 366
    if-eqz v6, :cond_10

    .line 367
    .line 368
    :cond_d
    const/4 v6, 0x1

    .line 369
    :goto_6
    invoke-static {v3, v8, v12, v6}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 370
    .line 371
    .line 372
    move-result v12

    .line 373
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    move-result-object v6

    .line 377
    if-nez v12, :cond_e

    .line 378
    .line 379
    if-ne v6, v0, :cond_f

    .line 380
    .line 381
    :cond_e
    const/16 p0, 0x0

    .line 382
    .line 383
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;

    .line 384
    .line 385
    move-object/from16 v31, v6

    .line 386
    .line 387
    move-object/from16 v32, v4

    .line 388
    .line 389
    move-object/from16 v33, v9

    .line 390
    .line 391
    move/from16 v34, v27

    .line 392
    .line 393
    move-object/from16 v35, v7

    .line 394
    .line 395
    move-object/from16 v36, v8

    .line 396
    .line 397
    move-object/from16 v37, v15

    .line 398
    .line 399
    invoke-direct/range {v31 .. v38}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdCamera;LX/16A;LX/2M4;)V

    .line 400
    .line 401
    .line 402
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 403
    .line 404
    .line 405
    :cond_f
    invoke-static {v3, v6, v11}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 406
    .line 407
    .line 408
    sget-object v23, LX/2sI;->A01:LX/2wD;

    .line 409
    .line 410
    move-object/from16 v8, v30

    .line 411
    .line 412
    move-object/from16 v6, v23

    .line 413
    .line 414
    invoke-interface {v8, v6}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 415
    .line 416
    .line 417
    move-result-object v8

    .line 418
    invoke-static {v3}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 419
    .line 420
    .line 421
    move-result-object v12

    .line 422
    move-object v6, v3

    .line 423
    check-cast v6, LX/J7I;

    .line 424
    .line 425
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 426
    .line 427
    .line 428
    move-result v13

    .line 429
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 430
    .line 431
    .line 432
    move-result-object v9

    .line 433
    invoke-static {v3, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 434
    .line 435
    .line 436
    move-result-object v11

    .line 437
    sget-object v22, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 438
    .line 439
    iget-object v8, v6, LX/J7I;->A0V:LX/3DJ;

    .line 440
    .line 441
    if-nez v8, :cond_17

    .line 442
    .line 443
    invoke-static {}, LX/1VY;->A00()V

    .line 444
    .line 445
    .line 446
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 447
    .line 448
    .line 449
    move-result-object v0

    .line 450
    throw v0

    .line 451
    :cond_10
    const/4 v6, 0x0

    .line 452
    goto :goto_6

    .line 453
    :cond_11
    const/4 v6, 0x0

    .line 454
    goto :goto_5

    .line 455
    :cond_12
    const/4 v6, 0x0

    .line 456
    goto/16 :goto_4

    .line 457
    .line 458
    :cond_13
    const/4 v6, 0x0

    .line 459
    goto/16 :goto_3

    .line 460
    .line 461
    :cond_14
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J

    .line 462
    .line 463
    .line 464
    move-result-wide v12

    .line 465
    sget v6, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->ID_FRAME_MARGIN:F

    .line 466
    .line 467
    invoke-interface {v9, v6}, LX/34Y;->AhZ(F)F

    .line 468
    .line 469
    .line 470
    move-result v14

    .line 471
    move/from16 v6, v27

    .line 472
    .line 473
    invoke-static {v12, v13, v14, v6}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->idFrameRect-Pq9zytI(JFF)LX/36Z;

    .line 474
    .line 475
    .line 476
    move-result-object v6

    .line 477
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J

    .line 478
    .line 479
    .line 480
    move-result-wide v12

    .line 481
    invoke-static {v6, v12, v13}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->normalizedIn-d16Qtg0(LX/36Z;J)Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 482
    .line 483
    .line 484
    move-result-object v6

    .line 485
    goto/16 :goto_2

    .line 486
    .line 487
    :cond_15
    and-int/lit16 v0, v2, 0x180

    .line 488
    .line 489
    if-nez v0, :cond_1

    .line 490
    .line 491
    move-object/from16 v0, v30

    .line 492
    .line 493
    invoke-static {v3, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 494
    .line 495
    .line 496
    move-result v0

    .line 497
    or-int/2addr v1, v0

    .line 498
    goto/16 :goto_1

    .line 499
    .line 500
    :cond_16
    move v1, v2

    .line 501
    goto/16 :goto_0

    .line 502
    .line 503
    :cond_17
    move-object/from16 v8, v22

    .line 504
    .line 505
    invoke-static {v3, v6, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 506
    .line 507
    .line 508
    sget-object v21, LX/3Cl;->A04:LX/JDN;

    .line 509
    .line 510
    move-object/from16 v8, v21

    .line 511
    .line 512
    invoke-static {v3, v12, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 513
    .line 514
    .line 515
    sget-object v20, LX/3Cl;->A06:LX/JDN;

    .line 516
    .line 517
    move-object/from16 v8, v20

    .line 518
    .line 519
    invoke-static {v3, v9, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 520
    .line 521
    .line 522
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 523
    .line 524
    .line 525
    move-result-object v8

    .line 526
    sget-object v9, LX/3Cl;->A03:LX/JDN;

    .line 527
    .line 528
    invoke-static {v3, v8, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 529
    .line 530
    .line 531
    sget-object v8, LX/3Cl;->A02:LX/JDM;

    .line 532
    .line 533
    invoke-static {v3, v11, v8}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 534
    .line 535
    .line 536
    move-result-object v19

    .line 537
    sget-object v13, LX/CgJ;->A00:LX/CgJ;

    .line 538
    .line 539
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 540
    .line 541
    const/high16 v14, 0x3f800000    # 1.0f

    .line 542
    .line 543
    move-object/from16 v12, v18

    .line 544
    .line 545
    move/from16 v11, v29

    .line 546
    .line 547
    invoke-virtual {v13, v12, v14, v11}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 548
    .line 549
    .line 550
    move-result-object v14

    .line 551
    const/high16 v12, 0x3f400000    # 0.75f

    .line 552
    .line 553
    move/from16 v11, v28

    .line 554
    .line 555
    invoke-static {v14, v12, v11}, LX/7b5;->A00(LX/3C1;FZ)LX/3C1;

    .line 556
    .line 557
    .line 558
    move-result-object v12

    .line 559
    sget-object v11, LX/2Id;->A00:LX/2sS;

    .line 560
    .line 561
    invoke-virtual {v13, v11, v12}, LX/CgJ;->A4E(LX/2sS;LX/3C1;)LX/3C1;

    .line 562
    .line 563
    .line 564
    move-result-object v12

    .line 565
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 566
    .line 567
    .line 568
    move-result-object v11

    .line 569
    if-ne v11, v0, :cond_18

    .line 570
    .line 571
    new-instance v11, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;

    .line 572
    .line 573
    invoke-direct {v11, v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 574
    .line 575
    .line 576
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 577
    .line 578
    .line 579
    :cond_18
    check-cast v11, LX/JDM;

    .line 580
    .line 581
    invoke-static {v12, v11}, LX/3N4;->A00(LX/3C1;LX/JDM;)LX/3C1;

    .line 582
    .line 583
    .line 584
    move-result-object v11

    .line 585
    invoke-static/range {v29 .. v29}, LX/001;->A0g(Z)LX/3BI;

    .line 586
    .line 587
    .line 588
    move-result-object v15

    .line 589
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 590
    .line 591
    .line 592
    move-result v14

    .line 593
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 594
    .line 595
    .line 596
    move-result-object v13

    .line 597
    invoke-static {v3, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 598
    .line 599
    .line 600
    move-result-object v12

    .line 601
    move-object/from16 v11, v22

    .line 602
    .line 603
    invoke-static {v3, v6, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 604
    .line 605
    .line 606
    move-object/from16 v11, v21

    .line 607
    .line 608
    invoke-static {v3, v15, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 609
    .line 610
    .line 611
    move-object/from16 v11, v20

    .line 612
    .line 613
    invoke-static {v3, v13, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 614
    .line 615
    .line 616
    invoke-static {v8, v9, v3, v14}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 617
    .line 618
    .line 619
    move-object/from16 v11, v19

    .line 620
    .line 621
    invoke-static {v3, v12, v11}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 622
    .line 623
    .line 624
    sget-object v12, LX/3Jn;->A00:LX/3Jn;

    .line 625
    .line 626
    invoke-interface {v3, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 627
    .line 628
    .line 629
    move-result v13

    .line 630
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 631
    .line 632
    .line 633
    move-result-object v11

    .line 634
    if-nez v13, :cond_19

    .line 635
    .line 636
    if-ne v11, v0, :cond_1a

    .line 637
    .line 638
    :cond_19
    new-instance v11, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;

    .line 639
    .line 640
    invoke-direct {v11, v10}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$2$1$1;-><init>(LX/FCr;)V

    .line 641
    .line 642
    .line 643
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 644
    .line 645
    .line 646
    :cond_1a
    check-cast v11, LX/JDM;

    .line 647
    .line 648
    const/16 v34, 0x0

    .line 649
    .line 650
    const/16 v35, 0x30

    .line 651
    .line 652
    const/16 v36, 0x4

    .line 653
    .line 654
    move-object/from16 v31, v3

    .line 655
    .line 656
    move-object/from16 v32, v23

    .line 657
    .line 658
    move-object/from16 v33, v11

    .line 659
    .line 660
    invoke-static/range {v31 .. v36}, LX/39N;->A03(LX/2d4;LX/3C1;LX/JDM;LX/JDM;II)V

    .line 661
    .line 662
    .line 663
    iget-object v10, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 664
    .line 665
    iget-object v11, v10, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 666
    .line 667
    sget-object v10, Lcom/facebook/aura/activation/ageverification/IdDocument;->PASSPORT:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 668
    .line 669
    invoke-static {v11, v10}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 670
    .line 671
    .line 672
    move-result p0

    .line 673
    const/16 p3, 0x180

    .line 674
    .line 675
    move/from16 v37, v27

    .line 676
    .line 677
    move-object/from16 p1, v23

    .line 678
    .line 679
    move-object/from16 p2, v3

    .line 680
    .line 681
    move/from16 p4, v29

    .line 682
    .line 683
    invoke-static/range {v37 .. v42}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->IdFrameOverlay(FZLX/3C1;LX/2d4;II)V

    .line 684
    .line 685
    .line 686
    sget-object v11, LX/2Id;->A0C:Landroidx/compose/ui/Alignment;

    .line 687
    .line 688
    move-object/from16 v10, v18

    .line 689
    .line 690
    invoke-virtual {v12, v11, v10}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 691
    .line 692
    .line 693
    move-result-object v11

    .line 694
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 695
    .line 696
    invoke-static {v11, v10}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 697
    .line 698
    .line 699
    move-result-object v12

    .line 700
    sget v14, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->$stable:I

    .line 701
    .line 702
    or-int v14, v14, v25

    .line 703
    .line 704
    sget v10, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->$stable:I

    .line 705
    .line 706
    shl-int/lit8 v10, v10, 0x3

    .line 707
    .line 708
    or-int/2addr v14, v10

    .line 709
    or-int v14, v14, v26

    .line 710
    .line 711
    move-object v10, v4

    .line 712
    move-object v11, v7

    .line 713
    move-object v13, v3

    .line 714
    move/from16 v15, v29

    .line 715
    .line 716
    invoke-static/range {v10 .. v15}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCaptureTip(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V

    .line 717
    .line 718
    .line 719
    move/from16 v10, v28

    .line 720
    .line 721
    invoke-static {v6, v10}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 722
    .line 723
    .line 724
    sget-object v12, LX/2sI;->A02:LX/2wD;

    .line 725
    .line 726
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 727
    .line 728
    const/4 v10, 0x0

    .line 729
    invoke-static {v12, v10, v11}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 730
    .line 731
    .line 732
    move-result-object v10

    .line 733
    sget-object v12, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 734
    .line 735
    invoke-static {v12, v15}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 736
    .line 737
    .line 738
    move-result-object v13

    .line 739
    invoke-static {v6}, LX/002;->A0J(LX/J7I;)I

    .line 740
    .line 741
    .line 742
    move-result v14

    .line 743
    invoke-static {v6}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 744
    .line 745
    .line 746
    move-result-object v12

    .line 747
    invoke-static {v3, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 748
    .line 749
    .line 750
    move-result-object v11

    .line 751
    move-object/from16 v10, v22

    .line 752
    .line 753
    invoke-static {v3, v6, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 754
    .line 755
    .line 756
    move-object/from16 v10, v21

    .line 757
    .line 758
    invoke-static {v3, v13, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 759
    .line 760
    .line 761
    move-object/from16 v10, v20

    .line 762
    .line 763
    invoke-static {v3, v12, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 764
    .line 765
    .line 766
    invoke-static {v8, v9, v3, v14}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 767
    .line 768
    .line 769
    move-object/from16 v8, v19

    .line 770
    .line 771
    invoke-static {v3, v11, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 772
    .line 773
    .line 774
    iget-boolean v8, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 775
    .line 776
    if-nez v8, :cond_1b

    .line 777
    .line 778
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J

    .line 779
    .line 780
    .line 781
    move-result-wide v8

    .line 782
    cmp-long v5, v8, v16

    .line 783
    .line 784
    const/4 v9, 0x1

    .line 785
    if-nez v5, :cond_1c

    .line 786
    .line 787
    :cond_1b
    const/4 v9, 0x0

    .line 788
    :cond_1c
    move/from16 v8, v24

    .line 789
    .line 790
    move/from16 v5, v26

    .line 791
    .line 792
    if-eq v5, v8, :cond_1d

    .line 793
    .line 794
    and-int/lit8 v1, v1, 0x40

    .line 795
    .line 796
    if-eqz v1, :cond_20

    .line 797
    .line 798
    invoke-interface {v3, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 799
    .line 800
    .line 801
    move-result v1

    .line 802
    if-eqz v1, :cond_20

    .line 803
    .line 804
    :cond_1d
    const/4 v5, 0x1

    .line 805
    :goto_7
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 806
    .line 807
    .line 808
    move-result-object v1

    .line 809
    if-nez v5, :cond_1e

    .line 810
    .line 811
    if-ne v1, v0, :cond_1f

    .line 812
    .line 813
    :cond_1e
    new-instance v1, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$3$1$1;

    .line 814
    .line 815
    invoke-direct {v1, v7}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$4$3$1$1;-><init>(Ljava/lang/Object;)V

    .line 816
    .line 817
    .line 818
    invoke-interface {v3, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 819
    .line 820
    .line 821
    :cond_1f
    check-cast v1, LX/DqV;

    .line 822
    .line 823
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 824
    .line 825
    move-object v10, v1

    .line 826
    move-object/from16 v11, v34

    .line 827
    .line 828
    move-object v12, v3

    .line 829
    move v13, v15

    .line 830
    move/from16 v14, v36

    .line 831
    .line 832
    invoke-static/range {v9 .. v14}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdShutterButton(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 833
    .line 834
    .line 835
    move/from16 v0, v28

    .line 836
    .line 837
    invoke-static {v6, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 838
    .line 839
    .line 840
    invoke-static {v6, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 841
    .line 842
    .line 843
    goto :goto_8

    .line 844
    :cond_20
    const/4 v5, 0x0

    .line 845
    goto :goto_7

    .line 846
    :cond_21
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 847
    .line 848
    .line 849
    :goto_8
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 850
    .line 851
    .line 852
    move-result-object v1

    .line 853
    if-eqz v1, :cond_22

    .line 854
    .line 855
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$5;

    .line 856
    .line 857
    move-object/from16 p0, v0

    .line 858
    .line 859
    move-object/from16 p1, v4

    .line 860
    .line 861
    move-object/from16 p2, v7

    .line 862
    .line 863
    move-object/from16 p3, v30

    .line 864
    .line 865
    move/from16 p4, v2

    .line 866
    .line 867
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$5;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;II)V

    .line 868
    .line 869
    .line 870
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 871
    .line 872
    :cond_22
    return-void
.end method

.method public static final IdCameraContent$lambda$3(Landroidx/compose/runtime/MutableState;)J
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2RQ;",
            ">;)J"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    check-cast v0, LX/2RQ;

    .line 5
    .line 6
    iget-wide v0, v0, LX/2RQ;->A00:J

    .line 7
    .line 8
    return-wide v0
.end method

.method public static final IdCameraContent$lambda$4(Landroidx/compose/runtime/MutableState;J)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/2RQ;",
            ">;J)V"
        }
    .end annotation

    .line 0
    new-instance v0, LX/2RQ;

    .line 1
    .line 2
    invoke-direct {v0, p1, p2}, LX/2RQ;-><init>(J)V

    .line 3
    .line 4
    .line 5
    invoke-interface {p0, v0}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static final IdCameraContent$lambda$5(LX/16A;)J
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "LX/2RQ;",
            ">;)J"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    check-cast v0, LX/2RQ;

    .line 5
    .line 6
    iget-wide v0, v0, LX/2RQ;->A00:J

    .line 7
    .line 8
    return-wide v0
.end method

.method public static final IdCameraContent$lambda$7(LX/16A;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/NormalizedRect;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final IdCaptureTip(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V
    .locals 23

    .line 0
    move-object/from16 v1, p2

    .line 1
    .line 2
    const v0, -0x612fdaef

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p3

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move-object/from16 v5, p0

    .line 15
    .line 16
    if-nez v0, :cond_b

    .line 17
    .line 18
    invoke-static {v5, v3, v2}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v10

    .line 26
    or-int v10, v10, p4

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 29
    .line 30
    move-object/from16 v4, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v4, v3, v2}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v0}, LX/003;->A07(I)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v10, v0

    .line 43
    :cond_0
    and-int/lit8 v9, p5, 0x4

    .line 44
    .line 45
    if-eqz v9, :cond_a

    .line 46
    .line 47
    or-int/lit16 v10, v10, 0x180

    .line 48
    .line 49
    :cond_1
    :goto_1
    and-int/lit16 v6, v10, 0x93

    .line 50
    .line 51
    const/16 v0, 0x92

    .line 52
    .line 53
    const/4 v7, 0x0

    .line 54
    const/4 v8, 0x1

    .line 55
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    invoke-static {v0, v3, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_9

    .line 64
    .line 65
    if-eqz v9, :cond_2

    .line 66
    .line 67
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 68
    .line 69
    :cond_2
    iget-object v0, v4, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->documentInFrame:LX/2J3;

    .line 70
    .line 71
    const/4 v14, 0x0

    .line 72
    invoke-static {v3, v0, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    iget-boolean v0, v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 77
    .line 78
    if-eqz v0, :cond_6

    .line 79
    .line 80
    const v8, 0x7f12006d

    .line 81
    .line 82
    .line 83
    :cond_3
    :goto_2
    invoke-static {v3, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v9

    .line 87
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 88
    .line 89
    const/4 v6, 0x6

    .line 90
    invoke-virtual {v8, v3, v6}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getTypography(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    iget-object v13, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->bodyEmphasized:LX/2hg;

    .line 95
    .line 96
    invoke-virtual {v8, v3, v6}, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->getColors(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    iget-wide v11, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->onMedia:J

    .line 101
    .line 102
    const/4 v6, 0x3

    .line 103
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v8

    .line 107
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 108
    .line 109
    if-ne v8, v0, :cond_4

    .line 110
    .line 111
    sget-object v8, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCaptureTip$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCaptureTip$1$1;

    .line 112
    .line 113
    invoke-interface {v3, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    :cond_4
    invoke-static {v1, v8, v7}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 117
    .line 118
    .line 119
    move-result-object v10

    .line 120
    new-instance v0, LX/2wS;

    .line 121
    .line 122
    invoke-direct {v0, v6}, LX/2wS;-><init>(I)V

    .line 123
    .line 124
    .line 125
    const/16 p4, 0x3fb0

    .line 126
    .line 127
    move-object v15, v14

    .line 128
    move/from16 v18, v7

    .line 129
    .line 130
    move/from16 v19, v7

    .line 131
    .line 132
    move/from16 v20, v7

    .line 133
    .line 134
    move-object/from16 v21, v14

    .line 135
    .line 136
    move-object/from16 v22, v14

    .line 137
    .line 138
    move-object/from16 p0, v14

    .line 139
    .line 140
    move-object/from16 p1, v3

    .line 141
    .line 142
    move/from16 p2, v7

    .line 143
    .line 144
    move/from16 p3, v7

    .line 145
    .line 146
    move/from16 v17, v7

    .line 147
    .line 148
    move-object/from16 v16, v0

    .line 149
    .line 150
    invoke-static/range {v9 .. v27}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 151
    .line 152
    .line 153
    :goto_3
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    if-eqz v3, :cond_5

    .line 158
    .line 159
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCaptureTip$2;

    .line 160
    .line 161
    move-object/from16 p0, v0

    .line 162
    .line 163
    move-object/from16 p1, v5

    .line 164
    .line 165
    move-object/from16 p2, v4

    .line 166
    .line 167
    move-object/from16 p3, v1

    .line 168
    .line 169
    move/from16 p4, v2

    .line 170
    .line 171
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCaptureTip$2;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;II)V

    .line 172
    .line 173
    .line 174
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 175
    .line 176
    :cond_5
    return-void

    .line 177
    :cond_6
    invoke-static {v6}, LX/16A;->A0C(LX/16A;)Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-eqz v0, :cond_7

    .line 182
    .line 183
    const v8, 0x7f120089

    .line 184
    .line 185
    .line 186
    goto :goto_2

    .line 187
    :cond_7
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->photos:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;

    .line 188
    .line 189
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 190
    .line 191
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdDocument;->getSides()I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-ne v0, v8, :cond_8

    .line 196
    .line 197
    const v8, 0x7f12006a

    .line 198
    .line 199
    .line 200
    goto :goto_2

    .line 201
    :cond_8
    iget-object v6, v5, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->side:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 202
    .line 203
    sget-object v0, Lcom/facebook/aura/activation/ageverification/IdSide;->FRONT:Lcom/facebook/aura/activation/ageverification/IdSide;

    .line 204
    .line 205
    const v8, 0x7f12006b

    .line 206
    .line 207
    .line 208
    if-ne v6, v0, :cond_3

    .line 209
    .line 210
    const v8, 0x7f12006c

    .line 211
    .line 212
    .line 213
    goto/16 :goto_2

    .line 214
    .line 215
    :cond_9
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 216
    .line 217
    .line 218
    goto :goto_3

    .line 219
    :cond_a
    and-int/lit16 v0, v2, 0x180

    .line 220
    .line 221
    if-nez v0, :cond_1

    .line 222
    .line 223
    invoke-static {v3, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 224
    .line 225
    .line 226
    move-result v0

    .line 227
    or-int/2addr v10, v0

    .line 228
    goto/16 :goto_1

    .line 229
    .line 230
    :cond_b
    move v10, v2

    .line 231
    goto/16 :goto_0
.end method

.method public static final IdCaptureTip$lambda$0(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final IdShutterButton(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v9, p2

    .line 1
    const v0, 0x127095f6

    .line 2
    .line 3
    .line 4
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    move v10, p4

    .line 8
    and-int/lit8 v0, p4, 0x6

    .line 9
    .line 10
    move v7, p0

    .line 11
    if-nez v0, :cond_b

    .line 12
    .line 13
    invoke-static {p3, p0}, LX/004;->A0i(LX/2d4;Z)I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    or-int/2addr v3, p4

    .line 18
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 19
    .line 20
    move-object v8, p1

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-static {p3, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    or-int/2addr v3, v0

    .line 28
    :cond_0
    move/from16 p0, p5

    .line 29
    .line 30
    and-int/lit8 v2, p5, 0x4

    .line 31
    .line 32
    if-eqz v2, :cond_a

    .line 33
    .line 34
    or-int/lit16 v3, v3, 0x180

    .line 35
    .line 36
    :cond_1
    :goto_1
    and-int/lit16 v1, v3, 0x93

    .line 37
    .line 38
    const/16 v0, 0x92

    .line 39
    .line 40
    const/4 v5, 0x0

    .line 41
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0, p3, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_9

    .line 50
    .line 51
    if-eqz v2, :cond_2

    .line 52
    .line 53
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 54
    .line 55
    :cond_2
    invoke-static {p3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 60
    .line 61
    const v2, 0x7f120069

    .line 62
    .line 63
    .line 64
    invoke-static {p3, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    const/high16 v2, 0x429c0000    # 78.0f

    .line 69
    .line 70
    invoke-static {v9, v2}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    const v2, 0x3ecccccd    # 0.4f

    .line 75
    .line 76
    .line 77
    if-eqz v7, :cond_3

    .line 78
    .line 79
    const/high16 v2, 0x3f800000    # 1.0f

    .line 80
    .line 81
    :cond_3
    invoke-static {v3, v2}, LX/1qG;->A00(LX/3C1;F)LX/3C1;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    sget-object v2, LX/2bA;->A00:LX/2bC;

    .line 86
    .line 87
    invoke-static {v3, v2}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-static {v2, v6, p1, v7}, LX/1Y9;->A00(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    invoke-interface {p3, v6}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v3

    .line 99
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    if-nez v3, :cond_4

    .line 104
    .line 105
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 106
    .line 107
    if-ne v2, v3, :cond_5

    .line 108
    .line 109
    :cond_4
    new-instance v2, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$1$1;

    .line 110
    .line 111
    invoke-direct {v2, v6}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$1$1;-><init>(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    invoke-interface {p3, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_5
    invoke-static {v4, v2, v5}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    invoke-interface {p3, v0, v1}, LX/2d4;->A68(J)Z

    .line 122
    .line 123
    .line 124
    move-result v3

    .line 125
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    if-nez v3, :cond_6

    .line 130
    .line 131
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 132
    .line 133
    if-ne v2, v3, :cond_7

    .line 134
    .line 135
    :cond_6
    new-instance v2, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;

    .line 136
    .line 137
    invoke-direct {v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;-><init>(J)V

    .line 138
    .line 139
    .line 140
    invoke-interface {p3, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    :cond_7
    check-cast v2, LX/JDM;

    .line 144
    .line 145
    invoke-static {v4, v2, p3, v5}, LX/1vS;->A00(LX/3C1;LX/JDM;LX/2d4;I)V

    .line 146
    .line 147
    .line 148
    :goto_2
    invoke-interface {p3}, LX/2d4;->AAg()LX/J7V;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    if-eqz v0, :cond_8

    .line 153
    .line 154
    new-instance v6, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$3;

    .line 155
    .line 156
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$3;-><init>(ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 157
    .line 158
    .line 159
    iput-object v6, v0, LX/J7V;->A06:LX/JDN;

    .line 160
    .line 161
    :cond_8
    return-void

    .line 162
    :cond_9
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 163
    .line 164
    .line 165
    goto :goto_2

    .line 166
    :cond_a
    and-int/lit16 v0, p4, 0x180

    .line 167
    .line 168
    if-nez v0, :cond_1

    .line 169
    .line 170
    invoke-static {p3, p2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 171
    .line 172
    .line 173
    move-result v0

    .line 174
    or-int/2addr v3, v0

    .line 175
    goto/16 :goto_1

    .line 176
    .line 177
    :cond_b
    move v3, p4

    .line 178
    goto/16 :goto_0
.end method

.method public static final synthetic access$IdCameraContent$lambda$4(Landroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$4(Landroidx/compose/runtime/MutableState;J)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$IdCameraContent$lambda$5(LX/16A;)J
    .locals 1

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$5(LX/16A;)J

    .line 1
    .line 2
    .line 3
    move-result-wide v0

    .line 4
    return-wide v0
.end method

.method public static final synthetic access$IdCameraContent$lambda$7(LX/16A;)Lcom/facebook/aura/activation/ageverification/NormalizedRect;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$IdCaptureTip(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCaptureTip(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$IdShutterButton(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdShutterButton(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
