.class public abstract Lcom/facebook/aura/activation/ageverification/AgeCheckReviewKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ATTEMPT_USABILITY_ERROR:Ljava/lang/String; = "USABILITY_ERROR"

.field public static final HTTP_TOO_MANY_REQUESTS:I = 0x1ad

.field public static final HTTP_UNAUTHORIZED:I = 0x191

.field public static final ID_POLL_INTERVAL_MS:J = 0x1388L

.field public static final INVALID_ID_SIDES:Ljava/lang/String; = "invalid_id_sides"

.field public static final MISSING_UPLOADS:Ljava/lang/String; = "missing_uploads"

.field public static final POLL_INTERVAL_MS:J = 0x7d0L

.field public static final POLL_WINDOW_MS:J = 0x1d4c0L

.field public static final UPLOAD_KIND_NOT_ALLOWED:Ljava/lang/String; = "upload_kind_not_allowed"

.field public static final UPLOAD_MEDIUM_NOT_ALLOWED:Ljava/lang/String; = "upload_medium_not_allowed"


# direct methods
.method public static final getFunnelMethod(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;)Lcom/facebook/aura/user/provider/AgeCheckMethod;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/002;->A0K(Ljava/lang/Enum;I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    if-eq p0, v0, :cond_1

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p0, v0, :cond_0

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->ID:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 14
    .line 15
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 16
    .line 17
    .line 18
    throw v0

    .line 19
    :cond_1
    sget-object v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;->SELFIE:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 20
    .line 21
    return-object v0
.end method
