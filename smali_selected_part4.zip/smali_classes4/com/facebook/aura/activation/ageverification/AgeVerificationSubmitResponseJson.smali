.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson$Companion;


# instance fields
.field public final status:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 805306368
    const-string v0, ""

    .line 805306369
    .line 805306370
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;-><init>(Ljava/lang/String;)V

    .line 805306371
    .line 805306372
    .line 805306373
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;LX/5Xm;)V
    .locals 1

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    if-nez v0, :cond_0

    .line 536870918
    .line 536870919
    const-string v0, ""

    .line 536870920
    .line 536870921
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 536870922
    .line 536870923
    return-void

    .line 536870924
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 536870925
    .line 536870926
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 268435456
    const/4 v0, 0x0

    .line 268435457
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435458
    .line 268435459
    .line 268435460
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435461
    .line 268435462
    .line 268435463
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 268435464
    .line 268435465
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ILX/04f;)V
    .locals 1

    .line 0
    invoke-static {p2, p1}, LX/3Rr;->A0h(ILjava/lang/String;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;LX/Da8;LX/Da5;)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v0}, LX/3Rq;->A1U(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;

    .line 5
    .line 6
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    :cond_0
    return v2

    .line 21
    :cond_1
    return v3
.end method

.method public final getStatus()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationSubmitResponseJson;->status:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
