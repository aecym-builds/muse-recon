.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Lkotlin/Unit;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.AgeVerificationClient$uploadAndSubmit$2"
    f = "AgeVerificationClient.kt"
    l = {
        0xd5
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

.field public final synthetic $fileHandles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/List;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$fileHandles:Ljava/util/List;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$fileHandles:Ljava/util/List;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;

    .line 5
    .line 6
    invoke-direct {v0, v2, v1, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Ljava/util/List;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1}, LX/DrA;->create(LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    :cond_0
    new-instance v4, LX/2PJ;

    .line 14
    .line 15
    invoke-direct {v4, v0}, LX/2PJ;-><init>(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-object v4

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 25
    .line 26
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;->id:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->$fileHandles:Ljava/util/List;

    .line 29
    .line 30
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$2;->label:I

    .line 31
    .line 32
    invoke-static {v2, v1, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->access$submit-0E7RQCE(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;Ljava/lang/String;Ljava/util/List;LX/2M4;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-ne v0, v4, :cond_0

    .line 37
    .line 38
    return-object v4

    .line 39
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    throw v0
.end method
