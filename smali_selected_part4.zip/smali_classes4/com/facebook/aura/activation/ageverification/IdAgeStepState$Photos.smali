.class public final Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/IdAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

.field public final canContinue:Z

.field public final document:Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public final front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/ageverification/CapturedPhoto;->$stable:I

    .line 1
    .line 2
    or-int/2addr v0, v0

    .line 3
    sput v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->$stable:I

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Lcom/facebook/aura/activation/ageverification/CapturedPhoto;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 12
    .line 13
    iput-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->canContinue:Z

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final getBack()Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->back:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCanContinue()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->canContinue:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getDocument()Lcom/facebook/aura/activation/ageverification/IdDocument;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFront()Lcom/facebook/aura/activation/ageverification/CapturedPhoto;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Photos;->front:Lcom/facebook/aura/activation/ageverification/CapturedPhoto;

    .line 1
    .line 2
    return-object p0
.end method
