.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "LX/2PJ<",
        "+",
        "Ljava/lang/String;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.AgeVerificationClient$uploadAndSubmit$uploads$1$1$1"
    f = "AgeVerificationClient.kt"
    l = {
        0xcc
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

.field public final synthetic $expected:Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

.field public final synthetic $file:Ljava/io/File;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;Ljava/io/File;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;",
            "Ljava/io/File;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$expected:Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$file:Ljava/io/File;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$expected:Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$file:Ljava/io/File;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;Ljava/io/File;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "LX/2PJ<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    sget-object v7, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v6, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v6, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/3Rp;->A0u(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    :cond_0
    new-instance v7, LX/2PJ;

    .line 14
    .line 15
    invoke-direct {v7, v0}, LX/2PJ;-><init>(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-object v7

    .line 19
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    sget-object v5, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;

    .line 23
    .line 24
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$attempt:Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;

    .line 25
    .line 26
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$expected:Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;

    .line 27
    .line 28
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->$file:Ljava/io/File;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1$1;

    .line 32
    .line 33
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationAttempt;Lcom/facebook/aura/activation/ageverification/AgeVerificationUpload;Ljava/io/File;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    iput v6, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient$uploadAndSubmit$uploads$1$1$1;->label:I

    .line 37
    .line 38
    invoke-static {v5, v0, p0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;->access$retryServerFailureOnce-gIAlu-s(Lcom/facebook/aura/activation/ageverification/AgeVerificationClient;LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    if-ne v0, v7, :cond_0

    .line 43
    .line 44
    return-object v7

    .line 45
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    throw v0
.end method
