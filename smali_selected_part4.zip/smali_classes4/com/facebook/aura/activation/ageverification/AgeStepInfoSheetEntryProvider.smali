.class public final Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/navigation/AuraNavEntryProvider;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public provideEntry(LX/1Ge;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1Ge<",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v8, 0x0

    .line 1
    invoke-static {p1, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v5, Lcom/facebook/aura/navigation/BottomSheetSceneStrategy;->Companion:Lcom/facebook/aura/navigation/BottomSheetSceneStrategy$Companion;

    .line 5
    .line 6
    const/4 v6, 0x1

    .line 7
    move v7, v6

    .line 8
    move v9, v8

    .line 9
    move p0, v8

    .line 10
    invoke-virtual/range {v5 .. v10}, Lcom/facebook/aura/navigation/BottomSheetSceneStrategy$Companion;->bottomSheet(ZZZZZ)Ljava/util/Map;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$2099004224:LX/JDQ;

    .line 15
    .line 16
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$1;

    .line 17
    .line 18
    const-class v0, Lcom/facebook/aura/navigation/key/AgeVerificationHowSelfiesWorkSheetKey;

    .line 19
    .line 20
    new-instance v1, LX/Ddf;

    .line 21
    .line 22
    invoke-direct {v1, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 23
    .line 24
    .line 25
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$2;

    .line 26
    .line 27
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$2;-><init>(Ljava/util/Map;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1, v2, v0, v3, v1}, LX/1Ge;->A00(LX/JDM;LX/JDM;LX/JDQ;LX/DVF;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual/range {v5 .. v10}, Lcom/facebook/aura/navigation/BottomSheetSceneStrategy$Companion;->bottomSheet(ZZZZZ)Ljava/util/Map;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$718351902:LX/JDQ;

    .line 38
    .line 39
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$3;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$3;

    .line 40
    .line 41
    const-class v0, Lcom/facebook/aura/navigation/key/AgeVerificationIdTipsSheetKey;

    .line 42
    .line 43
    new-instance v1, LX/Ddf;

    .line 44
    .line 45
    invoke-direct {v1, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 46
    .line 47
    .line 48
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$4;

    .line 49
    .line 50
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$4;-><init>(Ljava/util/Map;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1, v2, v0, v3, v1}, LX/1Ge;->A00(LX/JDM;LX/JDM;LX/JDQ;LX/DVF;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual/range {v5 .. v10}, Lcom/facebook/aura/navigation/BottomSheetSceneStrategy$Companion;->bottomSheet(ZZZZZ)Ljava/util/Map;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$614631779:LX/JDQ;

    .line 61
    .line 62
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$5;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$5;

    .line 63
    .line 64
    const-class v0, Lcom/facebook/aura/navigation/key/AgeVerificationHowIdWorksSheetKey;

    .line 65
    .line 66
    new-instance v1, LX/Ddf;

    .line 67
    .line 68
    invoke-direct {v1, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 69
    .line 70
    .line 71
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;

    .line 72
    .line 73
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;-><init>(Ljava/util/Map;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v2, v0, v3, v1}, LX/1Ge;->A00(LX/JDM;LX/JDM;LX/JDQ;LX/DVF;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual/range {v5 .. v10}, Lcom/facebook/aura/navigation/BottomSheetSceneStrategy$Companion;->bottomSheet(ZZZZZ)Ljava/util/Map;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$-1452433275:LX/JDQ;

    .line 84
    .line 85
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$7;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$7;

    .line 86
    .line 87
    const-class v0, Lcom/facebook/aura/navigation/key/AgeVerificationWhyConfirmSheetKey;

    .line 88
    .line 89
    new-instance v1, LX/Ddf;

    .line 90
    .line 91
    invoke-direct {v1, v0}, LX/Ddf;-><init>(Ljava/lang/Class;)V

    .line 92
    .line 93
    .line 94
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$8;

    .line 95
    .line 96
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$8;-><init>(Ljava/util/Map;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1, v2, v0, v3, v1}, LX/1Ge;->A00(LX/JDM;LX/JDM;LX/JDQ;LX/DVF;)V

    .line 100
    .line 101
    .line 102
    return-void
.end method
