.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.IdCameraContentKt$IdCameraContent$3$1"
    f = "IdCameraContent.kt"
    l = {
        0x6a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $aspect:F

.field public final synthetic $camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

.field public final synthetic $currentBoxSize$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/2RQ;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $density:LX/34Y;

.field public final synthetic $step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdCamera;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;",
            "LX/34Y;",
            "F",
            "Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;",
            "Lcom/facebook/aura/activation/ageverification/IdCamera;",
            "LX/16A<",
            "LX/2RQ;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$density:LX/34Y;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$aspect:F

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$currentBoxSize$delegate:LX/16A;

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0, p7}, LX/DRu;-><init>(ILX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$density:LX/34Y;

    .line 3
    .line 4
    iget v3, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$aspect:F

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 9
    .line 10
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$currentBoxSize$delegate:LX/16A;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;

    .line 13
    .line 14
    move-object p1, p2

    .line 15
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;LX/34Y;FLcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;Lcom/facebook/aura/activation/ageverification/IdCamera;LX/16A;LX/2M4;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p1

    .line 268435460
    check-cast p1, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;

    .line 268435461
    .line 268435462
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435463
    .line 268435464
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435465
    .line 268435466
    .line 268435467
    move-result-object p0

    .line 268435468
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/1EL;

    .line 1
    .line 2
    check-cast p2, LX/2M4;

    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-ne v0, v4, :cond_3

    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->L$1:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->L$0:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$step:Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;

    .line 22
    .line 23
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/IdAgeStepState$Capturing;->busy:Z

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$currentBoxSize$delegate:LX/16A;

    .line 28
    .line 29
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$5(LX/16A;)J

    .line 30
    .line 31
    .line 32
    move-result-wide v2

    .line 33
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$density:LX/34Y;

    .line 34
    .line 35
    sget v0, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->ID_FRAME_MARGIN:F

    .line 36
    .line 37
    invoke-interface {v1, v0}, LX/34Y;->AhZ(F)F

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$aspect:F

    .line 42
    .line 43
    invoke-static {v2, v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->idFrameRect-Pq9zytI(JFF)LX/36Z;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$currentBoxSize$delegate:LX/16A;

    .line 48
    .line 49
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt;->IdCameraContent$lambda$5(LX/16A;)J

    .line 50
    .line 51
    .line 52
    move-result-wide v0

    .line 53
    invoke-static {v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/IdFrameOverlayKt;->normalizedIn-d16Qtg0(LX/36Z;J)Lcom/facebook/aura/activation/ageverification/NormalizedRect;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    :try_start_0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$camera:Lcom/facebook/aura/activation/ageverification/IdCamera;

    .line 60
    .line 61
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->L$0:Ljava/lang/Object;

    .line 62
    .line 63
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->L$1:Ljava/lang/Object;

    .line 64
    .line 65
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->label:I

    .line 66
    .line 67
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/ageverification/IdCamera;->takeVisiblePhoto(LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v5, :cond_1

    .line 72
    .line 73
    return-object v5

    .line 74
    :goto_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    :cond_1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 78
    .line 79
    invoke-virtual {v2, p1, v1}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onPhotoTaken(Landroid/graphics/Bitmap;Lcom/facebook/aura/activation/ageverification/NormalizedRect;)V

    .line 80
    .line 81
    .line 82
    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 83
    :catch_0
    move-exception v2

    .line 84
    instance-of v0, v2, Ljava/util/concurrent/CancellationException;

    .line 85
    .line 86
    if-nez v0, :cond_4

    .line 87
    .line 88
    const-string v1, "Could not take the ID photo"

    .line 89
    .line 90
    const-string v0, "IdCameraContent"

    .line 91
    .line 92
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdCameraContent$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;

    .line 96
    .line 97
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/IdAgeStepViewModel;->onCaptureFailed()V

    .line 98
    .line 99
    .line 100
    :cond_2
    :goto_1
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 101
    .line 102
    return-object v5

    .line 103
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    :cond_4
    throw v2
.end method
