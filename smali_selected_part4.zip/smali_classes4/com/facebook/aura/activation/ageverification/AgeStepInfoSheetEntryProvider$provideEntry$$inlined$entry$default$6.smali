.class public final Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDM<",
        "Lcom/facebook/aura/navigation/key/AgeVerificationHowIdWorksSheetKey;",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "+",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $metadata:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;->$metadata:Ljava/util/Map;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;->$metadata:Ljava/util/Map;

    .line 1
    .line 2
    return-object p0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/util/Map;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/navigation/key/AgeVerificationHowIdWorksSheetKey;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetEntryProvider$provideEntry$$inlined$entry$default$6;->$metadata:Ljava/util/Map;

    .line 268435457
    .line 268435458
    return-object p0
.end method
