.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $accounts:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $backEnabled:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onAccountPick:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onBack:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onPick:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $primary:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;

.field public final synthetic $tmp0_rcvr:Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "I)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$tmp0_rcvr:Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$primary:LX/Ddn;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$accounts:LX/Ddn;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onPick:LX/JDN;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onAccountPick:LX/JDN;

    .line 11
    .line 12
    iput-boolean p7, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$backEnabled:Z

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$modifier:LX/3C1;

    .line 19
    .line 20
    iput p11, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$$changed:I

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    check-cast p1, LX/2d4;

    .line 1
    .line 2
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->invoke(LX/2d4;I)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 12

    .line 268435456
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$tmp0_rcvr:Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;

    .line 268435457
    .line 268435458
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$primary:LX/Ddn;

    .line 268435459
    .line 268435460
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$accounts:LX/Ddn;

    .line 268435461
    .line 268435462
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 268435463
    .line 268435464
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onPick:LX/JDN;

    .line 268435465
    .line 268435466
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onAccountPick:LX/JDN;

    .line 268435467
    .line 268435468
    iget-boolean v7, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$backEnabled:Z

    .line 268435469
    .line 268435470
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 268435471
    .line 268435472
    iget-object v9, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 268435473
    .line 268435474
    iget-object v10, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$modifier:LX/3C1;

    .line 268435475
    .line 268435476
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl$AgeMethodList$1;->$$changed:I

    .line 268435477
    .line 268435478
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 268435479
    .line 268435480
    .line 268435481
    move-result p0

    .line 268435482
    move-object v11, p1

    .line 268435483
    invoke-virtual/range {v1 .. v12}, Lcom/facebook/aura/activation/ageverification/AgeVerificationIntegrationImpl;->AgeMethodList(LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;I)V

    .line 268435484
    .line 268435485
    .line 268435486
    return-void
.end method
