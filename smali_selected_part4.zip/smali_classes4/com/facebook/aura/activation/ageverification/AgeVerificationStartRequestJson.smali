.class public final Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson$Companion;


# instance fields
.field public final document_type:Ljava/lang/String;

.field public final id_sides:Ljava/lang/Integer;

.field public final method:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p1, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x1

    .line 268435459
    if-eq v1, v0, :cond_0

    .line 268435460
    .line 268435461
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson$$serializer;->descriptor:LX/Da5;

    .line 268435462
    .line 268435463
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 268435464
    .line 268435465
    .line 268435466
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435467
    .line 268435468
    .line 268435469
    move-result-object v0

    .line 268435470
    throw v0

    .line 268435471
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435472
    .line 268435473
    .line 268435474
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 268435475
    .line 268435476
    and-int/lit8 v0, p1, 0x2

    .line 268435477
    .line 268435478
    const/4 v1, 0x0

    .line 268435479
    if-nez v0, :cond_1

    .line 268435480
    .line 268435481
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 268435482
    .line 268435483
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 268435484
    .line 268435485
    if-nez v0, :cond_2

    .line 268435486
    .line 268435487
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 268435488
    .line 268435489
    return-void

    .line 268435490
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 268435491
    .line 268435492
    goto :goto_0

    .line 268435493
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 268435494
    .line 268435495
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p4, 0x2

    .line 536870913
    .line 536870914
    const/4 v1, 0x0

    .line 536870915
    if-eqz v0, :cond_0

    .line 536870916
    .line 536870917
    move-object p2, v1

    .line 536870918
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    move-object p3, v1

    .line 536870923
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 536870924
    .line 536870925
    .line 536870926
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->copy(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl(Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-nez v3, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    :cond_0
    sget-object v1, LX/DYo;->A00:LX/DYo;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    const/4 v2, 0x2

    .line 25
    if-nez v3, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz v0, :cond_3

    .line 30
    .line 31
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 36
    .line 37
    .line 38
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getDocument_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getId_sides()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMethod()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->method:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->id_sides:Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeVerificationStartRequestJson;->document_type:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
