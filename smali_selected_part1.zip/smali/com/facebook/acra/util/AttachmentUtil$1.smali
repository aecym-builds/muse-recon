.class public Lcom/facebook/acra/util/AttachmentUtil$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic val$lastModifiedCache:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/acra/util/AttachmentUtil$1;->val$lastModifiedCache:Ljava/util/Map;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public compare(Ljava/io/File;Ljava/io/File;)I
    .locals 4

    .line 0
    iget-object v0, p0, Lcom/facebook/acra/util/AttachmentUtil$1;->val$lastModifiedCache:Ljava/util/Map;

    .line 1
    .line 2
    invoke-static {p1, v0}, LX/006;->A0q(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Number;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    iget-object v0, p0, Lcom/facebook/acra/util/AttachmentUtil$1;->val$lastModifiedCache:Ljava/util/Map;

    .line 7
    .line 8
    invoke-static {p2, v0}, LX/006;->A0q(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Number;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-wide/16 v3, 0x0

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 17
    .line 18
    .line 19
    move-result-wide v1

    .line 20
    :goto_0
    if-eqz p1, :cond_0

    .line 21
    .line 22
    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    .line 23
    .line 24
    .line 25
    move-result-wide v3

    .line 26
    :cond_0
    cmp-long v0, v1, v3

    .line 27
    .line 28
    return v0

    .line 29
    :cond_1
    const-wide/16 v1, 0x0

    .line 30
    .line 31
    goto :goto_0
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 268435456
    check-cast p1, Ljava/io/File;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/io/File;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/acra/util/AttachmentUtil$1;->compare(Ljava/io/File;Ljava/io/File;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result p0

    .line 268435464
    return p0
.end method
