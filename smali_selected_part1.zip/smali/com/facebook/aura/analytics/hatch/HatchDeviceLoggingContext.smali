.class public final Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;

.field public static final isWatch$delegate:Lkotlin/Lazy;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext$isWatch$2;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext$isWatch$2;

    .line 8
    .line 9
    invoke-static {v0}, LX/E2q;->A02(Lkotlin/jvm/functions/Function0;)LX/E2r;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;->isWatch$delegate:Lkotlin/Lazy;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final isWatch()Z
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/analytics/hatch/HatchDeviceLoggingContext;->isWatch$delegate:Lkotlin/Lazy;

    .line 1
    .line 2
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method
