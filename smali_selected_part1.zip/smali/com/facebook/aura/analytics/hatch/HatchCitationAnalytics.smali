.class public final Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final messageId:Ljava/lang/String;

.field public final resourceUris:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 10
    .line 11
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;Ljava/lang/String;Ljava/util/List;ILjava/lang/Object;)Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x1

    .line 13
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method private final indexOf(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 1
    .line 2
    invoke-interface {p0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    if-gez p0, :cond_0

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    :cond_0
    return-object p1
.end method

.method private final putMessageId(Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 1
    .line 2
    if-eqz p0, :cond_0

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->MESSAGE_ID:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {p1, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method

.method public static synthetic sourceRowMetadata$default(Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;Ljava/lang/String;Ljava/lang/Integer;ILjava/lang/Object;)Ljava/util/Map;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    const/4 p2, 0x0

    .line 5
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->sourceRowMetadata(Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v2

    .line 31
    :cond_1
    return v3
.end method

.method public final getMessageId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getResourceUris()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->messageId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public final linkMetadata(Ljava/lang/String;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v2, LX/Imj;

    .line 5
    .line 6
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, v2}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->putMessageId(Ljava/util/Map;)V

    .line 10
    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->indexOf(Ljava/lang/String;)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_MATCH:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-nez v3, :cond_0

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;->NONE:Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;->getValue()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    :goto_0
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    return-object v0

    .line 38
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;->RESOURCE:Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;

    .line 39
    .line 40
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchCitationMatch;->getValue()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_INDEX:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_COUNT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 65
    .line 66
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 71
    .line 72
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    goto :goto_0
.end method

.method public final sourceRowMetadata(Ljava/lang/String;Ljava/lang/Integer;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance v3, LX/Imj;

    .line 5
    .line 6
    invoke-direct {v3}, LX/Imj;-><init>()V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, v3}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->putMessageId(Ljava/util/Map;)V

    .line 10
    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_COUNT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v3, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    invoke-direct {p0, p1}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->indexOf(Ljava/lang/String;)Ljava/lang/Integer;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_INDEX:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 42
    .line 43
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v3, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    :cond_0
    if-eqz p2, :cond_1

    .line 55
    .line 56
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->ABSOLUTE_POSITION:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 61
    .line 62
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {v3, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    :cond_1
    invoke-static {v3}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    return-object v0
.end method

.method public final sourcesMetadata()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance v2, LX/Imj;

    .line 1
    .line 2
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 3
    .line 4
    .line 5
    invoke-direct {p0, v2}, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->putMessageId(Ljava/util/Map;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->CITATION_COUNT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/analytics/hatch/HatchCitationAnalytics;->resourceUris:Ljava/util/List;

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
