.class public abstract synthetic Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger$-CC;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static synthetic reportNavigationEventForComposable$default(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;ILjava/lang/Object;)V
    .locals 1

    .line 0
    if-nez p6, :cond_1

    .line 1
    .line 2
    and-int/lit8 v0, p5, 0x8

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    sget-object p4, LX/0Xj;->A00:LX/0Xj;

    .line 7
    .line 8
    :cond_0
    invoke-interface {p0, p1, p2, p3, p4}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->reportNavigationEventForComposable(Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_1
    const-string v0, "Super calls with default arguments not supported in this target, function: reportNavigationEventForComposable"

    .line 13
    .line 14
    invoke-static {v0}, LX/001;->A0z(Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    throw v0
.end method
