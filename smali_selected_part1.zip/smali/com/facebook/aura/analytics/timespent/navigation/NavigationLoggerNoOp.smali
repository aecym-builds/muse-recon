.class public final Lcom/facebook/aura/analytics/timespent/navigation/NavigationLoggerNoOp;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public getCurrentNavEventData()LX/DXZ;
    .locals 0

    .line 0
    new-instance p0, LX/DXZ;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public getModuleInfo()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, ""

    .line 1
    .line 2
    return-object p0
.end method

.method public getPrevNavEventData()LX/DXZ;
    .locals 0

    .line 0
    new-instance p0, LX/DXZ;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public reportNavigationEventForActivity(Landroid/app/Activity;)V
    .locals 0

    .line 0
    return-void
.end method

.method public reportNavigationEventForComposable(Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 0
    return-void
.end method

.method public reportNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method
