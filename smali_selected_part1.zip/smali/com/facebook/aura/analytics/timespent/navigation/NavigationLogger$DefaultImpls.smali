.class public abstract Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger$DefaultImpls;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static synthetic reportNavigationEventForComposable$default(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;ILjava/lang/Object;)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger$-CC;->reportNavigationEventForComposable$default(Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;ILjava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
