.class public interface abstract Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getCurrentNavEventData()LX/DXZ;
.end method

.method public abstract getModuleInfo()Ljava/lang/String;
.end method

.method public abstract getPrevNavEventData()LX/DXZ;
.end method

.method public abstract reportNavigationEventForActivity(Landroid/app/Activity;)V
.end method

.method public abstract reportNavigationEventForComposable(Ljava/lang/String;Ljava/lang/String;ILjava/util/Map;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract reportNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V
.end method
