.class public final Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler$Companion;

.field public static final TAG:Ljava/lang/String; = "NavigationEventHandler"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->Companion:Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final A00(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Landroidx/fragment/app/Fragment;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    instance-of v0, p0, Ljava/util/Collection;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return-void

    .line 17
    :cond_1
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    goto :goto_0
.end method

.method private final assertOnUiThread()V
    .locals 1

    .line 0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    const-string v0, "NavigationEventHandler must be executed on main UI thread"

    .line 20
    .line 21
    invoke-static {v0}, LX/001;->A0u(Ljava/lang/String;)Ljava/lang/RuntimeException;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    throw v0
.end method


# virtual methods
.method public final directlyHandleNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->assertOnUiThread()V

    .line 4
    .line 5
    .line 6
    sget-object p0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 7
    .line 8
    invoke-interface {p0, p1, p2}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->reportNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final handleNavigationEventForActivity(Landroid/app/Activity;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->assertOnUiThread()V

    .line 5
    .line 6
    .line 7
    instance-of v0, p1, Landroidx/fragment/app/FragmentActivity;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    move-object v0, p1

    .line 12
    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    .line 13
    .line 14
    invoke-static {v0}, LX/0so;->A00(Landroidx/fragment/app/FragmentActivity;)LX/12g;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {v0}, LX/12g;->A05(LX/12g;)Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-static {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->A00(Ljava/util/List;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    sget-object v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 32
    .line 33
    invoke-interface {v0, p1}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->reportNavigationEventForActivity(Landroid/app/Activity;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final handleNavigationEventForFragmentWithVisibilityDetector(Landroidx/fragment/app/Fragment;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->assertOnUiThread()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    :try_start_0
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()LX/12g;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, LX/12g;->A05(LX/12g;)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    goto :goto_0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    :catch_0
    :cond_0
    sget-object p0, LX/0wV;->A00:LX/0wV;

    .line 23
    .line 24
    :goto_0
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_1

    .line 37
    .line 38
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_1
    instance-of v0, v2, Ljava/util/Collection;

    .line 43
    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    :cond_2
    invoke-static {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->A00(Ljava/util/List;)V

    .line 53
    .line 54
    .line 55
    sget-object v1, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    invoke-interface {v1, p1, v0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->reportNavigationEventForFragment(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_3
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_2

    .line 71
    .line 72
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    const-string v0, "getFragmentVisibilityDetector"

    .line 76
    .line 77
    invoke-static {v0}, LX/001;->A0s(Ljava/lang/String;)Ljava/lang/NullPointerException;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    throw v0
.end method

.method public synthetic onFragmentCreate(Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onFragmentVisibilityChange(Landroidx/fragment/app/Fragment;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    if-eqz p2, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->handleNavigationEventForFragmentWithVisibilityDetector(Landroidx/fragment/app/Fragment;)V

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
.end method

.method public final setClickPointOnBackPressed()V
    .locals 4

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationEventHandler;->assertOnUiThread()V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/analytics/timespent/navigation/AuraNavigationLogger;->instance:Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;

    .line 4
    .line 5
    invoke-interface {v0}, Lcom/facebook/aura/analytics/timespent/navigation/NavigationLogger;->getCurrentNavEventData()LX/DXZ;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    const-string p0, "click_point"

    .line 10
    .line 11
    const-string v1, "tap_back_button"

    .line 12
    .line 13
    iget-object v0, v2, LX/DXZ;->A07:Ljava/util/Map;

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-static {}, LX/001;->A14()Ljava/util/HashMap;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, v2, LX/DXZ;->A07:Ljava/util/Map;

    .line 22
    .line 23
    :cond_0
    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    iget-object v3, v2, LX/DXZ;->A07:Ljava/util/Map;

    .line 30
    .line 31
    new-instance v2, LX/145;

    .line 32
    .line 33
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 34
    .line 35
    .line 36
    iput-object v1, v2, LX/145;->A01:Ljava/lang/Object;

    .line 37
    .line 38
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 39
    .line 40
    .line 41
    move-result-wide v0

    .line 42
    iput-wide v0, v2, LX/145;->A00:J

    .line 43
    .line 44
    invoke-interface {v3, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    :cond_1
    return-void
.end method
