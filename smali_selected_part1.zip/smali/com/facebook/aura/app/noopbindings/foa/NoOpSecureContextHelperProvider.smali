.class public final Lcom/facebook/aura/app/noopbindings/foa/NoOpSecureContextHelperProvider;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpSecureContextHelperProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpSecureContextHelperProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpSecureContextHelperProvider;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpSecureContextHelperProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public get()LX/FdB;
    .locals 0

    .line 0
    invoke-static {}, LX/FdB;->A00()LX/FdB;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-static {p0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method
