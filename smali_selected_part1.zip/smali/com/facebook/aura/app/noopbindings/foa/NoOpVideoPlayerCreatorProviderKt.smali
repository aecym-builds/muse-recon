.class public abstract Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreatorProviderKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TAG:Ljava/lang/String; = "NoOpVideoPlayerCreatorProvider"
