.class public final Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public attachPlayerView(Landroid/view/ViewGroup;)V
    .locals 0

    .line 0
    return-void
.end method

.method public detachPlayerView(Landroid/view/ViewGroup;)V
    .locals 0

    .line 0
    return-void
.end method

.method public getCurrentPositionMs()I
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public getLooping()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public getPlaybackSpeed()F
    .locals 0

    .line 0
    const/high16 p0, 0x3f800000    # 1.0f

    .line 1
    .line 2
    return p0
.end method

.method public getVolume()F
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public init(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/net/Uri;II)V
    .locals 0

    .line 0
    return-void
.end method

.method public isPlaying()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return p0
.end method

.method public pause(Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public play()V
    .locals 0

    .line 0
    return-void
.end method

.method public release()V
    .locals 0

    .line 0
    return-void
.end method

.method public seekTo(I)V
    .locals 0

    .line 0
    return-void
.end method

.method public setLooping(Z)V
    .locals 0

    .line 0
    return-void
.end method

.method public setPlaybackSpeed(F)V
    .locals 0

    .line 0
    return-void
.end method

.method public setVolume(FLjava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method
