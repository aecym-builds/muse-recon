.class public final Lcom/facebook/aura/app/noopbindings/foa/NoOpFoaUserSessionBundleUtil;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpFoaUserSessionBundleUtil;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpFoaUserSessionBundleUtil;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpFoaUserSessionBundleUtil;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpFoaUserSessionBundleUtil;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public readFromBundle(Landroid/os/Bundle;)LX/0HH;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    return-object p0
.end method

.method public writeToBundle(LX/0HH;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    return-void
.end method
