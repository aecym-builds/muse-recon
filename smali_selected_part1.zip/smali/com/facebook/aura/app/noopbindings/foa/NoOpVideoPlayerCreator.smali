.class public final Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreator;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreator;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreator;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreator;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayerCreator;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public createPlayer(Landroid/content/Context;LX/0NN;LX/0NM;)Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;
    .locals 0

    .line 0
    const-string p1, "NoOpVideoPlayerCreatorProvider"

    .line 1
    .line 2
    const-string p0, "Video playback is unsupported in Aura; rendering an empty video surface"

    .line 3
    .line 4
    invoke-static {p1, p0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;->INSTANCE:Lcom/facebook/aura/app/noopbindings/foa/NoOpVideoPlayer;

    .line 8
    .line 9
    return-object p0
.end method
