.class public final Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0oe;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/0oe;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;->INSTANCE:Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/Throwable;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/app/AuraApplication$workManagerConfiguration$1;->accept(Ljava/lang/Throwable;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public final accept(Ljava/lang/Throwable;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const-string p0, "AuraApplication"

    .line 5
    .line 6
    const-string v0, "WorkManager failed to initialize"

    .line 7
    .line 8
    invoke-static {p0, v0, p1}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
