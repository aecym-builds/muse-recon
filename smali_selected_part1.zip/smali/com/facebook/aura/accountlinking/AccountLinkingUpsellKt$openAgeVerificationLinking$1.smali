.class public final Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onBloksReturned:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resolved:LX/0Rg;


# direct methods
.method public constructor <init>(LX/0Rg;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/0Rg;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;->$resolved:LX/0Rg;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;->$onBloksReturned:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;->invoke(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;)V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;->$resolved:LX/0Rg;

    .line 1
    .line 2
    iget-boolean v0, v1, LX/0Rg;->element:Z

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, v1, LX/0Rg;->element:Z

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;->$onBloksReturned:Lkotlin/jvm/functions/Function0;

    .line 10
    .line 11
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method
