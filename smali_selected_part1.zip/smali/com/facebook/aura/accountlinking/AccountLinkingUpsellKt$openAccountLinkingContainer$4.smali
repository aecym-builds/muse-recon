.class public final Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0c3;


# instance fields
.field public final synthetic $onDismiss:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $presentation:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;LX/JDM;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$presentation:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$onDismiss:LX/JDM;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final run(I)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$presentation:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 1
    .line 2
    if-nez v2, :cond_0

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$onDismiss:LX/JDM;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$onDismiss:LX/JDM;

    .line 12
    .line 13
    new-instance v0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4$1;

    .line 14
    .line 15
    invoke-direct {v0, v1}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4$1;-><init>(LX/JDM;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2, v0}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;->dismiss(Lkotlin/jvm/functions/Function0;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$presentation:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->release(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :catchall_0
    move-exception v2

    .line 30
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;->$presentation:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 33
    .line 34
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->release(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 35
    .line 36
    .line 37
    throw v2
.end method
