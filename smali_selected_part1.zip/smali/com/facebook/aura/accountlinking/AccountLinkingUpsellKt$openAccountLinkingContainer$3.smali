.class public final Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;->INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/content/Context;Landroid/widget/FrameLayout;LX/0am;)V
    .locals 0

    .line 0
    return-void
.end method
