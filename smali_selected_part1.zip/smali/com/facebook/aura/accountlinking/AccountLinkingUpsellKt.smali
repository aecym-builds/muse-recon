.class public abstract Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final getIneligibleReason(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;)Ljava/lang/String;
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x2

    .line 5
    if-eq p0, v0, :cond_2

    .line 6
    .line 7
    const/4 v0, 0x3

    .line 8
    if-eq p0, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    if-eq p0, v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    if-eq p0, v0, :cond_0

    .line 15
    .line 16
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    throw v0

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    return-object v0

    .line 23
    :cond_1
    const-string v0, "launch_failed"

    .line 24
    .line 25
    return-object v0

    .line 26
    :cond_2
    const-string v0, "no_session"

    .line 27
    .line 28
    return-object v0
.end method

.method public static final openAccountLinkingContainer(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;ZLX/JDM;Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V
    .locals 42
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;",
            "Z",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;",
            ")V"
        }
    .end annotation

    .line 0
    move-object/from16 v1, p0

    .line 1
    .line 2
    invoke-static {v1}, Lcom/facebook/aura/bloks/AuraBloksInitializer;->initBloksLazy(Landroid/content/Context;)V

    .line 3
    .line 4
    .line 5
    invoke-virtual/range {p1 .. p1}, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->getWireValue()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-static/range {p2 .. p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    new-instance v4, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$1;

    .line 14
    .line 15
    move-object/from16 v7, p3

    .line 16
    .line 17
    move-object/from16 v5, p4

    .line 18
    .line 19
    invoke-direct {v4, v5, v7}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;LX/JDM;)V

    .line 20
    .line 21
    .line 22
    sget-object v11, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$2;->INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$2;

    .line 23
    .line 24
    const/4 v13, 0x0

    .line 25
    const-string v0, "account_type"

    .line 26
    .line 27
    invoke-static {v0, v2}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 28
    .line 29
    .line 30
    move-result-object v9

    .line 31
    const/4 v0, 0x0

    .line 32
    const-string v2, "context_data"

    .line 33
    .line 34
    invoke-static {v2, v13}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 35
    .line 36
    .line 37
    move-result-object v8

    .line 38
    const-string v2, "is_age_confirmation"

    .line 39
    .line 40
    invoke-static {v2, v3}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 41
    .line 42
    .line 43
    move-result-object v6

    .line 44
    const/4 v10, 0x0

    .line 45
    const/16 v3, 0x12

    .line 46
    .line 47
    new-instance v2, LX/3Rb;

    .line 48
    .line 49
    invoke-direct {v2, v4, v3}, LX/3Rb;-><init>(Ljava/lang/Object;I)V

    .line 50
    .line 51
    .line 52
    new-instance v3, LX/03P;

    .line 53
    .line 54
    invoke-direct {v3, v2}, LX/03P;-><init>(LX/JDM;)V

    .line 55
    .line 56
    .line 57
    const-string v2, "on_dismiss"

    .line 58
    .line 59
    invoke-static {v2, v3}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    if-eqz v11, :cond_0

    .line 64
    .line 65
    const/16 v3, 0x13

    .line 66
    .line 67
    new-instance v2, LX/3Rb;

    .line 68
    .line 69
    invoke-direct {v2, v11, v3}, LX/3Rb;-><init>(Ljava/lang/Object;I)V

    .line 70
    .line 71
    .line 72
    new-instance v10, LX/03P;

    .line 73
    .line 74
    invoke-direct {v10, v2}, LX/03P;-><init>(LX/JDM;)V

    .line 75
    .line 76
    .line 77
    :cond_0
    const-string v2, "on_success"

    .line 78
    .line 79
    invoke-static {v2, v10}, LX/001;->A1B(Ljava/lang/Object;Ljava/lang/Object;)LX/IBK;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    filled-new-array {v9, v8, v6, v4, v2}, [LX/IBK;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-static {v2}, LX/1HA;->A0G([LX/IBK;)Ljava/util/Map;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-static {}, LX/001;->A16()Ljava/util/LinkedHashMap;

    .line 92
    .line 93
    .line 94
    move-result-object v10

    .line 95
    const/4 v4, 0x1

    .line 96
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 97
    .line 98
    .line 99
    move-result-object v15

    .line 100
    invoke-virtual {v10, v2}, Ljava/util/AbstractMap;->putAll(Ljava/util/Map;)V

    .line 101
    .line 102
    .line 103
    new-instance v2, Ljava/util/BitSet;

    .line 104
    .line 105
    invoke-direct {v2, v0}, Ljava/util/BitSet;-><init>(I)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2, v0}, Ljava/util/BitSet;->nextClearBit(I)I

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    if-lt v2, v0, :cond_8

    .line 113
    .line 114
    invoke-static {}, LX/001;->A16()Ljava/util/LinkedHashMap;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    invoke-static {v10}, LX/002;->A19(Ljava/util/AbstractMap;)Ljava/util/Iterator;

    .line 119
    .line 120
    .line 121
    move-result-object v9

    .line 122
    :cond_1
    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 123
    .line 124
    .line 125
    move-result v3

    .line 126
    if-eqz v3, :cond_2

    .line 127
    .line 128
    invoke-static {v9}, LX/001;->A18(Ljava/util/Iterator;)Ljava/util/Map$Entry;

    .line 129
    .line 130
    .line 131
    move-result-object v8

    .line 132
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v6

    .line 136
    sget-object v3, LX/0bg;->A00:Ljava/util/Set;

    .line 137
    .line 138
    invoke-interface {v3, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    if-eqz v3, :cond_1

    .line 143
    .line 144
    invoke-static {v2, v8}, LX/008;->A1T(Ljava/util/AbstractMap;Ljava/util/Map$Entry;)V

    .line 145
    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_2
    invoke-static {v10}, LX/1HA;->A0E(Ljava/util/Map;)Ljava/util/Map;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    const-string v14, "com.bloks.www.screen_query.BloksHatchAccountLinkingTrampolineScreenQuery"

    .line 153
    .line 154
    const-wide/16 p1, 0x0

    .line 155
    .line 156
    invoke-static {v3, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 157
    .line 158
    .line 159
    invoke-static {v1}, Lcom/facebook/aura/bloks/screenquery/AuraObjectSetUtilsKt;->createObjectSet(Landroid/content/Context;)LX/09w;

    .line 160
    .line 161
    .line 162
    move-result-object v11

    .line 163
    sget-object v28, LX/0b0;->A04:LX/0b0;

    .line 164
    .line 165
    sget-object v30, LX/0b3;->A04:LX/0b3;

    .line 166
    .line 167
    sget-object v27, LX/0b1;->A04:LX/0b1;

    .line 168
    .line 169
    sget-object v22, Lcom/meta/foa/cds/CdsBottomSheetDimmingBehaviour$Default;->A00:Lcom/meta/foa/cds/CdsBottomSheetDimmingBehaviour$Default;

    .line 170
    .line 171
    sget-object v19, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;->INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;

    .line 172
    .line 173
    new-instance v6, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;

    .line 174
    .line 175
    invoke-direct {v6, v5, v7}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$4;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;LX/JDM;)V

    .line 176
    .line 177
    .line 178
    new-instance v5, Lcom/meta/foa/cds/CdsOpenScreenCallerDismissCallback;

    .line 179
    .line 180
    invoke-direct {v5, v6}, Lcom/meta/foa/cds/CdsOpenScreenCallerDismissCallback;-><init>(LX/0c3;)V

    .line 181
    .line 182
    .line 183
    sget-object v6, LX/0av;->A0Q:LX/0b2;

    .line 184
    .line 185
    const/16 v10, 0x409e

    .line 186
    .line 187
    sget-object v32, LX/FkO;->A0C:Ljava/lang/Integer;

    .line 188
    .line 189
    sget-object v24, LX/0b2;->A06:LX/0b2;

    .line 190
    .line 191
    sget-object v17, LX/0Pl;->A02:LX/0Pl;

    .line 192
    .line 193
    sget-object v26, LX/0bD;->A03:LX/0bD;

    .line 194
    .line 195
    new-instance v16, LX/0av;

    .line 196
    .line 197
    move-object/from16 v18, v17

    .line 198
    .line 199
    move-object/from16 v21, v13

    .line 200
    .line 201
    move-object/from16 v23, v5

    .line 202
    .line 203
    move-object/from16 v25, v13

    .line 204
    .line 205
    move-object/from16 v29, v13

    .line 206
    .line 207
    move-object/from16 v31, v13

    .line 208
    .line 209
    move-object/from16 v33, v13

    .line 210
    .line 211
    move-object/from16 v34, v13

    .line 212
    .line 213
    move/from16 v35, v10

    .line 214
    .line 215
    move/from16 v36, v0

    .line 216
    .line 217
    move/from16 v37, v0

    .line 218
    .line 219
    move/from16 v38, v4

    .line 220
    .line 221
    move/from16 v39, v4

    .line 222
    .line 223
    move/from16 v40, v0

    .line 224
    .line 225
    move/from16 v41, v0

    .line 226
    .line 227
    move/from16 p0, v0

    .line 228
    .line 229
    move-object/from16 v20, v13

    .line 230
    .line 231
    invoke-direct/range {v16 .. v42}, LX/0av;-><init>(LX/0Pl;LX/0Pl;Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingContainer$3;Lcom/facebook/dsp/core/ColorData;Lcom/facebook/dsp/core/ColorData;Lcom/meta/foa/cds/CdsBottomSheetDimmingBehaviour;Lcom/meta/foa/cds/CdsOpenScreenCallerDismissCallback;LX/0b2;Lcom/meta/foa/cds/CdsOpenScreenConfig$BottomSheetMargins;LX/0bD;LX/0b1;LX/0b0;LX/0b0;LX/0b3;LX/0bF;Ljava/lang/Integer;Ljava/lang/Integer;LX/JDM;IZZZZZZZ)V

    .line 232
    .line 233
    .line 234
    filled-new-array/range {v16 .. v16}, [LX/0TO;

    .line 235
    .line 236
    .line 237
    move-result-object v5

    .line 238
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 239
    .line 240
    .line 241
    invoke-static {v5, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v12

    .line 245
    check-cast v12, [LX/0TO;

    .line 246
    .line 247
    const/4 v5, 0x2

    .line 248
    invoke-static {v12, v5}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 249
    .line 250
    .line 251
    array-length v9, v12

    .line 252
    const/4 v8, 0x0

    .line 253
    const/4 v7, 0x0

    .line 254
    :goto_1
    if-ge v7, v9, :cond_6

    .line 255
    .line 256
    aget-object v17, v12, v7

    .line 257
    .line 258
    invoke-interface/range {v17 .. v17}, LX/0TO;->AKA()I

    .line 259
    .line 260
    .line 261
    move-result v6

    .line 262
    if-eq v6, v10, :cond_3

    .line 263
    .line 264
    const/16 v5, 0x5940

    .line 265
    .line 266
    if-eq v6, v5, :cond_3

    .line 267
    .line 268
    add-int/lit8 v7, v7, 0x1

    .line 269
    .line 270
    goto :goto_1

    .line 271
    :cond_3
    invoke-interface/range {v17 .. v17}, LX/0TO;->AKA()I

    .line 272
    .line 273
    .line 274
    move-result v6

    .line 275
    const-string v8, "__infra__container_config_id"

    .line 276
    .line 277
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 278
    .line 279
    .line 280
    move-result-object v7

    .line 281
    invoke-static {v8, v7}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 282
    .line 283
    .line 284
    move-result-object v5

    .line 285
    invoke-static {v2, v5}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 286
    .line 287
    .line 288
    move-result-object v41

    .line 289
    invoke-static {v11}, Lcom/facebook/aura/bloks/asynccomponent/AuraComponentQueryStoreProviderImpl;->getInstance(LX/09w;)LX/0C2;

    .line 290
    .line 291
    .line 292
    move-result-object v9

    .line 293
    invoke-static {v9}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    invoke-static {v8}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 297
    .line 298
    .line 299
    move-result-object p0

    .line 300
    sget-object v37, LX/0OD;->A03:LX/0OD;

    .line 301
    .line 302
    iget-object v5, v9, LX/0C2;->A0A:Ljava/util/concurrent/Executor;

    .line 303
    .line 304
    new-instance v2, LX/0C3;

    .line 305
    .line 306
    move-object/from16 v36, v2

    .line 307
    .line 308
    move-object/from16 v38, v9

    .line 309
    .line 310
    move-object/from16 v39, v13

    .line 311
    .line 312
    move-object/from16 v40, v14

    .line 313
    .line 314
    move/from16 p3, v4

    .line 315
    .line 316
    move/from16 p4, v4

    .line 317
    .line 318
    invoke-direct/range {v36 .. v46}, LX/0C3;-><init>(LX/0OD;LX/0C2;Ljava/lang/Long;Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;JZZ)V

    .line 319
    .line 320
    .line 321
    invoke-interface {v5, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 322
    .line 323
    .line 324
    sget-object v4, LX/03l;->A00:LX/03l;

    .line 325
    .line 326
    invoke-interface/range {v17 .. v17}, LX/0TO;->AJ3()Ljava/lang/Integer;

    .line 327
    .line 328
    .line 329
    move-result-object v2

    .line 330
    invoke-virtual {v4, v1, v2}, LX/03l;->A00(Landroid/content/Context;Ljava/lang/Integer;)Lcom/instagram/common/bloks/BloksParseResult;

    .line 331
    .line 332
    .line 333
    move-result-object v2

    .line 334
    invoke-static {v2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 335
    .line 336
    .line 337
    new-instance v5, LX/Imj;

    .line 338
    .line 339
    invoke-direct {v5}, LX/Imj;-><init>()V

    .line 340
    .line 341
    .line 342
    const-string v4, "__infra__app_id"

    .line 343
    .line 344
    invoke-virtual {v5, v4, v14}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    new-instance v4, Ljava/security/SecureRandom;

    .line 348
    .line 349
    invoke-direct {v4}, Ljava/security/SecureRandom;-><init>()V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v4}, Ljava/util/Random;->nextInt()I

    .line 353
    .line 354
    .line 355
    move-result v4

    .line 356
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v9

    .line 360
    const-string v4, "__infra__screen_id"

    .line 361
    .line 362
    invoke-virtual {v5, v4, v9}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    invoke-static/range {p1 .. p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 366
    .line 367
    .line 368
    move-result-object v9

    .line 369
    const-string v4, "__infra__cache_ttl"

    .line 370
    .line 371
    invoke-virtual {v5, v4, v9}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    const-string v4, "__infra__enable_disk_cache"

    .line 375
    .line 376
    invoke-virtual {v5, v4, v15}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 377
    .line 378
    .line 379
    const v4, 0x2aea1260

    .line 380
    .line 381
    .line 382
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 383
    .line 384
    .line 385
    move-result-object v9

    .line 386
    const-string v4, "__infra__ttrc_marker_id"

    .line 387
    .line 388
    invoke-virtual {v5, v4, v9}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    const-string v4, "__infra__ttrc_analytics_extras"

    .line 392
    .line 393
    invoke-virtual {v5, v4, v13}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    invoke-static {v5}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 397
    .line 398
    .line 399
    move-result-object v4

    .line 400
    invoke-static {v3, v4}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 401
    .line 402
    .line 403
    move-result-object v4

    .line 404
    invoke-static {v8, v7}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 405
    .line 406
    .line 407
    move-result-object v3

    .line 408
    invoke-static {v4, v3}, LX/1HA;->A07(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 409
    .line 410
    .line 411
    move-result-object v22

    .line 412
    sget-object v21, LX/0wV;->A00:LX/0wV;

    .line 413
    .line 414
    new-instance v3, LX/0Ya;

    .line 415
    .line 416
    move-object/from16 v16, v3

    .line 417
    .line 418
    move-object/from16 v18, v2

    .line 419
    .line 420
    move-object/from16 v19, v15

    .line 421
    .line 422
    move-object/from16 v23, v13

    .line 423
    .line 424
    move/from16 v24, v0

    .line 425
    .line 426
    move/from16 v25, v0

    .line 427
    .line 428
    invoke-direct/range {v16 .. v25}, LX/0Ya;-><init>(LX/0TO;Lcom/instagram/common/bloks/BloksParseResult;Ljava/lang/Boolean;Ljava/lang/String;Ljava/util/List;Ljava/util/Map;Ljava/util/Map;ZZ)V

    .line 429
    .line 430
    .line 431
    sget-object v2, LX/0As;->A03:LX/0As;

    .line 432
    .line 433
    invoke-virtual {v2, v1}, LX/0As;->A02(Landroid/content/Context;)V

    .line 434
    .line 435
    .line 436
    if-eq v6, v10, :cond_5

    .line 437
    .line 438
    const/16 v2, 0x5940

    .line 439
    .line 440
    if-ne v6, v2, :cond_4

    .line 441
    .line 442
    sget-object v2, Lcom/facebook/aura/bloks/screenquery/AuraBloksFullScreenContainerNavigator;->INSTANCE:Lcom/facebook/aura/bloks/screenquery/AuraBloksFullScreenContainerNavigator;

    .line 443
    .line 444
    invoke-virtual {v2, v1, v3, v11, v0}, Lcom/facebook/aura/bloks/screenquery/AuraBloksFullScreenContainerNavigator;->openScreen(Landroid/content/Context;LX/0Ya;LX/09w;Z)V

    .line 445
    .line 446
    .line 447
    return-void

    .line 448
    :cond_4
    invoke-static {v6}, LX/009;->A0Z(I)Ljava/lang/IllegalArgumentException;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    throw v0

    .line 453
    :cond_5
    sget-object v2, Lcom/facebook/aura/bloks/screenquery/navigator/AuraCdsScreenQueryNavigator;->INSTANCE:Lcom/facebook/aura/bloks/screenquery/navigator/AuraCdsScreenQueryNavigator;

    .line 454
    .line 455
    invoke-virtual {v2, v1, v3, v11, v0}, Lcom/facebook/aura/bloks/screenquery/navigator/AuraCdsScreenQueryNavigator;->openScreen(Landroid/content/Context;LX/0Ya;LX/09w;Z)V

    .line 456
    .line 457
    .line 458
    return-void

    .line 459
    :cond_6
    invoke-static {v9}, LX/001;->A12(I)Ljava/util/ArrayList;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    :goto_2
    if-ge v8, v9, :cond_7

    .line 464
    .line 465
    aget-object v0, v12, v8

    .line 466
    .line 467
    invoke-interface {v0}, LX/0TO;->AKA()I

    .line 468
    .line 469
    .line 470
    move-result v0

    .line 471
    invoke-static {v1, v0}, LX/006;->A1U(Ljava/util/AbstractCollection;I)V

    .line 472
    .line 473
    .line 474
    add-int/lit8 v8, v8, 0x1

    .line 475
    .line 476
    goto :goto_2

    .line 477
    :cond_7
    const-string v0, "No matching container config found. None of the provided container config style IDs ("

    .line 478
    .line 479
    invoke-static {v1, v0}, LX/002;->A14(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 480
    .line 481
    .line 482
    move-result-object v1

    .line 483
    const-string v0, ") have a registered navigator in this host app."

    .line 484
    .line 485
    invoke-static {v0, v1}, LX/004;->A19(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;

    .line 486
    .line 487
    .line 488
    move-result-object v0

    .line 489
    throw v0

    .line 490
    :cond_8
    const-string v0, "Missing required params"

    .line 491
    .line 492
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    throw v0
.end method

.method public static final openAccountLinkingUpsellBloksScreen(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;ZLX/JDM;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;",
            "Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;",
            "Z",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p0, p1, p2}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x5

    .line 5
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v5, 0x0

    .line 9
    if-nez p4, :cond_2

    .line 10
    .line 11
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;

    .line 12
    .line 13
    invoke-direct {v1, p1, p2, p3}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$Connector;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;)V

    .line 14
    .line 15
    .line 16
    sget-object v4, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->INSTANCE:Lcom/facebook/aura/perf/HatchConnectorQplLogger;

    .line 17
    .line 18
    invoke-virtual {v4}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->activeAuthTraceId()Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->NONE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 23
    .line 24
    if-ne p2, v0, :cond_0

    .line 25
    .line 26
    move-object v2, v5

    .line 27
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;

    .line 28
    .line 29
    invoke-virtual {v0, p0, v1, p5}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;->open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    if-eqz v2, :cond_1

    .line 34
    .line 35
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OPENED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 36
    .line 37
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {v4, v2, v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->annotateLinker(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Z)V

    .line 42
    .line 43
    .line 44
    invoke-static {v1}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->getIneligibleReason(Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    invoke-virtual {v4, v2, v0}, Lcom/facebook/aura/perf/HatchConnectorQplLogger;->annotateNativeIneligible(Lcom/facebook/aura/perf/HatchConnectorAuthTraceId;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OPENED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 54
    .line 55
    if-eq v1, v0, :cond_3

    .line 56
    .line 57
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 58
    .line 59
    invoke-virtual {v0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->bind(Z)Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    :cond_2
    :try_start_0
    invoke-static {p0, p1, p4, p5, v5}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->openAccountLinkingContainer(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;ZLX/JDM;Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 64
    .line 65
    .line 66
    :cond_3
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 67
    :catch_0
    move-exception v1

    .line 68
    if-eqz v5, :cond_4

    .line 69
    .line 70
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 71
    .line 72
    invoke-virtual {v0, v5}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->release(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 73
    .line 74
    .line 75
    :cond_4
    throw v1
.end method

.method public static synthetic openAccountLinkingUpsellBloksScreen$default(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;ZLX/JDM;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x4

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->NONE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x8

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    const/4 p3, 0x0

    .line 11
    :cond_1
    and-int/lit8 v0, p6, 0x10

    .line 12
    .line 13
    invoke-static {v0, p4}, LX/001;->A1P(IZ)Z

    .line 14
    .line 15
    .line 16
    move-result p4

    .line 17
    and-int/lit8 v0, p6, 0x20

    .line 18
    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    sget-object p5, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingUpsellBloksScreen$1;->INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingUpsellBloksScreen$1;

    .line 22
    .line 23
    :cond_2
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->openAccountLinkingUpsellBloksScreen(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;ZLX/JDM;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public static final openAgeVerificationLinking(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;LX/JDM;LX/JDM;Lkotlin/jvm/functions/Function0;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest$AgeVerification;",
            "LX/JDM<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object v3, p0

    .line 2
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    move-object v4, p1

    .line 7
    invoke-static {p1, p3, p4, p0}, LX/005;->A11(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x5

    .line 11
    invoke-static {p5, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 12
    .line 13
    .line 14
    if-eqz p2, :cond_0

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;

    .line 17
    .line 18
    invoke-virtual {v0, v3, p2, p4}, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;->open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OPENED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    if-eq v2, v1, :cond_1

    .line 26
    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :cond_1
    invoke-static {v0, p3}, LX/002;->A1R(ZLX/JDM;)V

    .line 29
    .line 30
    .line 31
    if-nez v0, :cond_2

    .line 32
    .line 33
    new-instance v0, LX/0Rg;

    .line 34
    .line 35
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    new-instance p1, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;

    .line 39
    .line 40
    invoke-direct {p1, v0, p5}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAgeVerificationLinking$1;-><init>(LX/0Rg;Lkotlin/jvm/functions/Function0;)V

    .line 41
    .line 42
    .line 43
    const/4 v6, 0x0

    .line 44
    sget-object v5, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->NONE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 45
    .line 46
    invoke-static/range {v3 .. v8}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->openAccountLinkingUpsellBloksScreen(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;ZLX/JDM;)V

    .line 47
    .line 48
    .line 49
    :cond_2
    return-void
.end method
