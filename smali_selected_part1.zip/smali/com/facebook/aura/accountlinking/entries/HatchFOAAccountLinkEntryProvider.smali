.class public final Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/navigation/AuraNavEntryProvider;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public provideEntry(LX/1Ge;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1Ge<",
            "Lcom/facebook/aura/navigation/AuraNavKey;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v1, Lcom/facebook/aura/navigation/OverlaySceneStrategy;->Companion:Lcom/facebook/aura/navigation/OverlaySceneStrategy$Companion;

    .line 5
    .line 6
    const v0, 0x7fffffff

    .line 7
    .line 8
    .line 9
    invoke-virtual {v1, v0}, Lcom/facebook/aura/navigation/OverlaySceneStrategy$Companion;->overlay(I)Ljava/util/Map;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    sget-object v3, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt;->lambda$-1637691058:LX/JDQ;

    .line 14
    .line 15
    sget-object v2, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider$provideEntry$$inlined$entry$default$1;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider$provideEntry$$inlined$entry$default$1;

    .line 16
    .line 17
    const-class v0, Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

    .line 18
    .line 19
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider$provideEntry$$inlined$entry$default$2;

    .line 24
    .line 25
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkEntryProvider$provideEntry$$inlined$entry$default$2;-><init>(Ljava/util/Map;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1, v2, v0, v3, v1}, LX/1Ge;->A00(LX/JDM;LX/JDM;LX/JDQ;LX/DVF;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
