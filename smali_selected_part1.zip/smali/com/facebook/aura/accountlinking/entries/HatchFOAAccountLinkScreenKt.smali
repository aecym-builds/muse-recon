.class public abstract Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final HatchFOAAccountLinkContent(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    invoke-static {p0, p1}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const v0, -0x380e8a25

    .line 4
    .line 5
    .line 6
    move-object/from16 v8, p2

    .line 7
    .line 8
    invoke-interface {v8, v0}, LX/2d4;->Agl(I)V

    .line 9
    .line 10
    .line 11
    move/from16 v2, p3

    .line 12
    .line 13
    and-int/lit8 v0, p3, 0x6

    .line 14
    .line 15
    if-nez v0, :cond_9

    .line 16
    .line 17
    invoke-static {v8, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 18
    .line 19
    .line 20
    move-result v6

    .line 21
    or-int v6, v6, p3

    .line 22
    .line 23
    :goto_0
    and-int/lit8 v0, p3, 0x30

    .line 24
    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    invoke-static {v8, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    or-int/2addr v6, v0

    .line 32
    :cond_0
    and-int/lit8 v1, v6, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-static {v0, v8, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_8

    .line 45
    .line 46
    const/4 v7, -0x1

    .line 47
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 48
    .line 49
    invoke-static {v0, v8}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    instance-of v0, v4, Landroidx/fragment/app/FragmentActivity;

    .line 54
    .line 55
    const/4 v3, 0x0

    .line 56
    if-eqz v0, :cond_7

    .line 57
    .line 58
    check-cast v4, Landroidx/fragment/app/FragmentActivity;

    .line 59
    .line 60
    :goto_1
    invoke-static {}, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->getEntries()LX/0vk;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 65
    .line 66
    .line 67
    move-result-object v5

    .line 68
    :cond_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_2

    .line 73
    .line 74
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    move-object v0, v1

    .line 79
    check-cast v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 80
    .line 81
    invoke-virtual {v0}, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;->getWireValue()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    if-eqz v0, :cond_1

    .line 86
    .line 87
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_1

    .line 92
    .line 93
    move-object v3, v1

    .line 94
    :cond_2
    check-cast v3, Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 95
    .line 96
    sget-object v9, LX/DqI;->ON_RESUME:LX/DqI;

    .line 97
    .line 98
    if-eqz v3, :cond_3

    .line 99
    .line 100
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 101
    .line 102
    .line 103
    move-result v7

    .line 104
    :cond_3
    invoke-interface {v8, v7}, LX/2d4;->A67(I)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    invoke-static {v8, v4, v0}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    invoke-static {v6}, LX/006;->A1W(I)Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    or-int/2addr v1, v0

    .line 117
    invoke-interface {v8}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v11

    .line 121
    if-nez v1, :cond_4

    .line 122
    .line 123
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 124
    .line 125
    if-ne v11, v0, :cond_5

    .line 126
    .line 127
    :cond_4
    new-instance v11, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;

    .line 128
    .line 129
    invoke-direct {v11, v3, v4, p1}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Landroidx/fragment/app/FragmentActivity;Lkotlin/jvm/functions/Function0;)V

    .line 130
    .line 131
    .line 132
    invoke-interface {v8, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    :cond_5
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 136
    .line 137
    const/4 v12, 0x6

    .line 138
    const/4 v13, 0x2

    .line 139
    const/4 v10, 0x0

    .line 140
    invoke-static/range {v8 .. v13}, LX/CcX;->A00(LX/2d4;LX/DqI;LX/07p;Lkotlin/jvm/functions/Function0;II)V

    .line 141
    .line 142
    .line 143
    :goto_2
    invoke-interface {v8}, LX/2d4;->AAg()LX/J7V;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    if-eqz v1, :cond_6

    .line 148
    .line 149
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$2;

    .line 150
    .line 151
    invoke-direct {v0, p0, p1, v2}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$2;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;I)V

    .line 152
    .line 153
    .line 154
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 155
    .line 156
    :cond_6
    return-void

    .line 157
    :cond_7
    move-object v4, v3

    .line 158
    goto :goto_1

    .line 159
    :cond_8
    invoke-interface {v8}, LX/2d4;->AgJ()V

    .line 160
    .line 161
    .line 162
    goto :goto_2

    .line 163
    :cond_9
    move v6, v2

    .line 164
    goto/16 :goto_0
.end method
