.class public final Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $key:Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;->$key:Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;->$key:Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

    .line 3
    .line 4
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v1, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->popAll(Ljava/util/Collection;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
