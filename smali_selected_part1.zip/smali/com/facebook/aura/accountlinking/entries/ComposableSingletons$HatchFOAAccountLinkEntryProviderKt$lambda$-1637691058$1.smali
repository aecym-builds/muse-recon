.class public final Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;->INSTANCE:Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1;->invoke(Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;LX/2d4;I)V
    .locals 4

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p2}, LX/005;->A0d(Ljava/lang/Object;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    iget-object v2, p1, Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;->accountTypeWire:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {p2, v3, p1}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 21
    .line 22
    if-ne v0, v1, :cond_1

    .line 23
    .line 24
    :cond_0
    new-instance v0, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;

    .line 25
    .line 26
    invoke-direct {v0, v3, p1}, Lcom/facebook/aura/accountlinking/entries/ComposableSingletons$HatchFOAAccountLinkEntryProviderKt$lambda$-1637691058$1$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/navigation/key/HatchFOAAccountLinkScreenKey;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_1
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 33
    .line 34
    invoke-static {v2, v0, p2, p0}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt;->HatchFOAAccountLinkContent(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 35
    .line 36
    .line 37
    return-void
.end method
