.class public final Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $hostActivity:Landroidx/fragment/app/FragmentActivity;

.field public final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Landroidx/fragment/app/FragmentActivity;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;",
            "Landroidx/fragment/app/FragmentActivity;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$hostActivity:Landroidx/fragment/app/FragmentActivity;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 6

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$target:Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$hostActivity:Landroidx/fragment/app/FragmentActivity;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    sget-object v2, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;->NONE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object v5, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingUpsellBloksScreen$1;->INSTANCE:Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt$openAccountLinkingUpsellBloksScreen$1;

    .line 13
    .line 14
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/accountlinking/AccountLinkingUpsellKt;->openAccountLinkingUpsellBloksScreen(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/HatchAccountLinkingTarget;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkAuthTrace;Lcom/facebook/aura/analytics/hatch/HatchSkillOAuthOrigin;ZLX/JDM;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/entries/HatchFOAAccountLinkScreenKt$HatchFOAAccountLinkContent$1$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 18
    .line 19
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    return-void
.end method
