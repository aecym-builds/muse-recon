.class public abstract Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final NativeLinkAccountAvatar(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;LX/3C1;LX/2d4;II)V
    .locals 12

    .line 0
    move-object v2, p1

    .line 1
    const v0, -0x29dafc48

    .line 2
    .line 3
    .line 4
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    move v4, p3

    .line 8
    and-int/lit8 v0, p3, 0x6

    .line 9
    .line 10
    move-object v5, p0

    .line 11
    if-nez v0, :cond_7

    .line 12
    .line 13
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 14
    .line 15
    .line 16
    move-result v6

    .line 17
    or-int/2addr v6, p3

    .line 18
    :goto_0
    move/from16 v3, p4

    .line 19
    .line 20
    and-int/lit8 v1, p4, 0x2

    .line 21
    .line 22
    if-eqz v1, :cond_6

    .line 23
    .line 24
    or-int/lit8 v6, v6, 0x30

    .line 25
    .line 26
    :cond_0
    :goto_1
    invoke-static {v6}, LX/005;->A1G(I)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    invoke-static {v0, p2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_5

    .line 35
    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 39
    .line 40
    :cond_1
    iget-object v6, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->avatarUrl:Ljava/lang/String;

    .line 41
    .line 42
    if-nez v6, :cond_2

    .line 43
    .line 44
    const-string v6, ""

    .line 45
    .line 46
    :cond_2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appBadge:I

    .line 47
    .line 48
    new-instance v7, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;

    .line 49
    .line 50
    invoke-direct {v7, v0}, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;-><init>(I)V

    .line 51
    .line 52
    .line 53
    const/high16 v9, 0x42200000    # 40.0f

    .line 54
    .line 55
    invoke-static {p2}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->modal:J

    .line 60
    .line 61
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {p2, v0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 66
    .line 67
    .line 68
    move-result-object v11

    .line 69
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 74
    .line 75
    if-ne v1, v0, :cond_3

    .line 76
    .line 77
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountAvatar$1$1;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountAvatar$1$1;

    .line 78
    .line 79
    invoke-interface {p2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_3
    invoke-static {v2, v1}, LX/001;->A0Y(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v8

    .line 86
    const/16 p3, 0xc00

    .line 87
    .line 88
    const/16 p4, 0xd0

    .line 89
    .line 90
    const/4 v10, 0x0

    .line 91
    move p0, v10

    .line 92
    move p1, v10

    .line 93
    invoke-static/range {v6 .. v16}, Lcom/facebook/aura/vds/compose/profilepicture/AuraBadgedProfilePictureKt;->AuraBadgedProfilePicture-7lJw--U(Ljava/lang/String;Lcom/facebook/aura/vds/compose/common/AuraDrawableSource;LX/3C1;FFLX/16A;FFLX/2d4;II)V

    .line 94
    .line 95
    .line 96
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    if-eqz v1, :cond_4

    .line 101
    .line 102
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountAvatar$2;

    .line 103
    .line 104
    invoke-direct {v0, v5, v2, v4, v3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountAvatar$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;LX/3C1;II)V

    .line 105
    .line 106
    .line 107
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 108
    .line 109
    :cond_4
    return-void

    .line 110
    :cond_5
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 111
    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_6
    and-int/lit8 v0, p3, 0x30

    .line 115
    .line 116
    if-nez v0, :cond_0

    .line 117
    .line 118
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    or-int/2addr v6, v0

    .line 123
    goto :goto_1

    .line 124
    :cond_7
    move v6, p3

    .line 125
    goto :goto_0
.end method

.method public static final NativeLinkAccountOption(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 57
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p3

    .line 1
    .line 2
    const v0, 0x55076aac

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p4

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v0, p5

    .line 11
    .line 12
    and-int/lit8 v2, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v4, p0

    .line 15
    .line 16
    if-nez v2, :cond_b

    .line 17
    .line 18
    invoke-static {v1, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    or-int v2, v2, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v3, p5, 0x30

    .line 25
    .line 26
    move/from16 v13, p1

    .line 27
    .line 28
    if-nez v3, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v13}, LX/004;->A0j(LX/2d4;Z)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    or-int/2addr v2, v3

    .line 35
    :cond_0
    and-int/lit16 v3, v0, 0x180

    .line 36
    .line 37
    const/16 v5, 0x100

    .line 38
    .line 39
    move-object/from16 v12, p2

    .line 40
    .line 41
    if-nez v3, :cond_1

    .line 42
    .line 43
    invoke-static {v1, v12}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    or-int/2addr v2, v3

    .line 48
    :cond_1
    and-int/lit8 v8, p6, 0x8

    .line 49
    .line 50
    if-eqz v8, :cond_a

    .line 51
    .line 52
    or-int/lit16 v2, v2, 0xc00

    .line 53
    .line 54
    :cond_2
    :goto_1
    and-int/lit16 v7, v2, 0x493

    .line 55
    .line 56
    const/16 v6, 0x492

    .line 57
    .line 58
    const/4 v11, 0x0

    .line 59
    const/4 v3, 0x1

    .line 60
    invoke-static {v7, v6}, LX/003;->A1H(II)Z

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    invoke-static {v6, v1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    if-eqz v6, :cond_9

    .line 69
    .line 70
    if-eqz v8, :cond_3

    .line 71
    .line 72
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 73
    .line 74
    :cond_3
    iget v6, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appName:I

    .line 75
    .line 76
    invoke-static {v1, v6}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    sget-object v43, Lcom/facebook/aura/vds/compose/card/AuraCardType$Radio;->INSTANCE:Lcom/facebook/aura/vds/compose/card/AuraCardType$Radio;

    .line 81
    .line 82
    const/4 v7, 0x0

    .line 83
    invoke-static {v9}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 84
    .line 85
    .line 86
    move-result-object v40

    .line 87
    invoke-static {v7, v1, v11, v3}, Lcom/facebook/aura/vds/compose/card/SettingsKt;->cardStyleForSettings(LX/2rU;LX/2d4;II)Lcom/facebook/aura/vds/compose/card/AuraCardStyle;

    .line 88
    .line 89
    .line 90
    move-result-object v41

    .line 91
    sget-object v16, Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;->BODY_REGULAR:Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;

    .line 92
    .line 93
    iget-object v10, v4, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->name:Ljava/lang/String;

    .line 94
    .line 95
    if-nez v10, :cond_4

    .line 96
    .line 97
    move-object v10, v8

    .line 98
    :cond_4
    sget-object v6, LX/0wV;->A00:LX/0wV;

    .line 99
    .line 100
    invoke-static {v10, v6}, LX/001;->A0h(Ljava/lang/String;Ljava/util/List;)LX/2iK;

    .line 101
    .line 102
    .line 103
    move-result-object v15

    .line 104
    invoke-static {v8, v6}, LX/001;->A0h(Ljava/lang/String;Ljava/util/List;)LX/2iK;

    .line 105
    .line 106
    .line 107
    move-result-object v19

    .line 108
    const v38, 0x1fffec

    .line 109
    .line 110
    .line 111
    const-wide/16 v33, 0x0

    .line 112
    .line 113
    new-instance v14, Lcom/facebook/aura/vds/compose/card/AuraCardContent;

    .line 114
    .line 115
    move-object/from16 v18, v7

    .line 116
    .line 117
    move-object/from16 v20, v7

    .line 118
    .line 119
    move-object/from16 v21, v7

    .line 120
    .line 121
    move-object/from16 v22, v7

    .line 122
    .line 123
    move-object/from16 v23, v7

    .line 124
    .line 125
    move-object/from16 v24, v7

    .line 126
    .line 127
    move/from16 v25, v11

    .line 128
    .line 129
    move/from16 v26, v11

    .line 130
    .line 131
    move/from16 v27, v11

    .line 132
    .line 133
    move-object/from16 v28, v7

    .line 134
    .line 135
    move/from16 v29, v11

    .line 136
    .line 137
    move/from16 v30, v11

    .line 138
    .line 139
    move-object/from16 v31, v7

    .line 140
    .line 141
    move-object/from16 v32, v7

    .line 142
    .line 143
    move-wide/from16 v35, v33

    .line 144
    .line 145
    move-object/from16 v37, v7

    .line 146
    .line 147
    move-object/from16 v39, v7

    .line 148
    .line 149
    move-object/from16 v17, v7

    .line 150
    .line 151
    invoke-direct/range {v14 .. v39}, Lcom/facebook/aura/vds/compose/card/AuraCardContent;-><init>(LX/2iK;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;LX/0Xl;LX/JOw;LX/2iK;LX/JDM;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndBodyStyle;LX/JOw;Ljava/lang/String;LX/2hg;IIILjava/lang/String;ZZLX/2iK;LX/2hg;JJLX/2wS;ILX/04f;)V

    .line 152
    .line 153
    .line 154
    new-instance v8, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$1;

    .line 155
    .line 156
    invoke-direct {v8, v4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;)V

    .line 157
    .line 158
    .line 159
    const v6, -0x7bb3b6b0

    .line 160
    .line 161
    .line 162
    invoke-static {v1, v8, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 163
    .line 164
    .line 165
    move-result-object v44

    .line 166
    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 167
    .line 168
    .line 169
    move-result-object v47

    .line 170
    and-int/lit16 v6, v2, 0x380

    .line 171
    .line 172
    if-eq v6, v5, :cond_5

    .line 173
    .line 174
    const/4 v3, 0x0

    .line 175
    :cond_5
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v5

    .line 179
    if-nez v3, :cond_6

    .line 180
    .line 181
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 182
    .line 183
    if-ne v5, v3, :cond_7

    .line 184
    .line 185
    :cond_6
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$2$1;

    .line 186
    .line 187
    invoke-direct {v5, v12}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$2$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 188
    .line 189
    .line 190
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_7
    check-cast v5, LX/JDM;

    .line 194
    .line 195
    shl-int/lit8 v2, v2, 0x12

    .line 196
    .line 197
    const/high16 v3, 0x1c00000

    .line 198
    .line 199
    and-int/2addr v2, v3

    .line 200
    or-int/lit16 v2, v2, 0x6c00

    .line 201
    .line 202
    const p5, 0x3fe60

    .line 203
    .line 204
    .line 205
    move-object/from16 v42, v14

    .line 206
    .line 207
    move-object/from16 v45, v7

    .line 208
    .line 209
    move-object/from16 v46, v7

    .line 210
    .line 211
    move-object/from16 v48, v5

    .line 212
    .line 213
    move-object/from16 v49, v7

    .line 214
    .line 215
    move/from16 v50, v11

    .line 216
    .line 217
    move/from16 v51, v11

    .line 218
    .line 219
    move-object/from16 v52, v7

    .line 220
    .line 221
    move-object/from16 v53, v7

    .line 222
    .line 223
    move-wide/from16 v54, v33

    .line 224
    .line 225
    move/from16 v56, v11

    .line 226
    .line 227
    move-object/from16 p0, v7

    .line 228
    .line 229
    move-object/from16 p1, v7

    .line 230
    .line 231
    move-object/from16 p2, v1

    .line 232
    .line 233
    move/from16 p3, v2

    .line 234
    .line 235
    move/from16 p4, v11

    .line 236
    .line 237
    invoke-static/range {v40 .. v62}, Lcom/facebook/aura/vds/compose/card/AuraCardKt;->AuraCard-jQVUvHA(LX/3C1;Lcom/facebook/aura/vds/compose/card/AuraCardStyle;Lcom/facebook/aura/vds/compose/card/AuraCardContent;Lcom/facebook/aura/vds/compose/card/AuraCardType;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;Ljava/lang/Boolean;LX/JDM;LX/JDM;ZZLX/346;LX/2bW;JZLX/JDQ;LX/JDQ;LX/2d4;III)V

    .line 238
    .line 239
    .line 240
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 241
    .line 242
    .line 243
    move-result-object v2

    .line 244
    if-eqz v2, :cond_8

    .line 245
    .line 246
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$3;

    .line 247
    .line 248
    move/from16 p5, v0

    .line 249
    .line 250
    move-object/from16 p0, v1

    .line 251
    .line 252
    move-object/from16 p1, v4

    .line 253
    .line 254
    move/from16 p2, v13

    .line 255
    .line 256
    move-object/from16 p3, v12

    .line 257
    .line 258
    move-object/from16 p4, v9

    .line 259
    .line 260
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountOption$3;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 261
    .line 262
    .line 263
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 264
    .line 265
    :cond_8
    return-void

    .line 266
    :cond_9
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 267
    .line 268
    .line 269
    goto :goto_2

    .line 270
    :cond_a
    and-int/lit16 v3, v0, 0xc00

    .line 271
    .line 272
    if-nez v3, :cond_2

    .line 273
    .line 274
    invoke-static {v1, v9}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 275
    .line 276
    .line 277
    move-result v3

    .line 278
    or-int/2addr v2, v3

    .line 279
    goto/16 :goto_1

    .line 280
    .line 281
    :cond_b
    move v2, v0

    .line 282
    goto/16 :goto_0
.end method

.method public static final NativeLinkAccountSheet(LX/Ddn;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p0

    .line 1
    .line 2
    move-object/from16 v2, p1

    .line 3
    .line 4
    move-object/from16 v9, p2

    .line 5
    .line 6
    invoke-static {v3, v2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v17

    .line 10
    const v0, 0xd499d01

    .line 11
    .line 12
    .line 13
    move-object/from16 v1, p3

    .line 14
    .line 15
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v0, p4

    .line 19
    .line 20
    and-int/lit8 v4, p4, 0x6

    .line 21
    .line 22
    if-nez v4, :cond_a

    .line 23
    .line 24
    invoke-static {v1, v3}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    or-int v4, v4, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v5, p4, 0x30

    .line 31
    .line 32
    if-nez v5, :cond_0

    .line 33
    .line 34
    invoke-static {v1, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    or-int/2addr v4, v5

    .line 39
    :cond_0
    and-int/lit8 v6, p5, 0x4

    .line 40
    .line 41
    if-eqz v6, :cond_9

    .line 42
    .line 43
    or-int/lit16 v4, v4, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_1
    invoke-static {v4}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    invoke-static {v5, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    if-eqz v5, :cond_8

    .line 54
    .line 55
    if-eqz v6, :cond_2

    .line 56
    .line 57
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    invoke-static {v4}, LX/008;->A1X(I)Z

    .line 60
    .line 61
    .line 62
    move-result v6

    .line 63
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v5

    .line 67
    if-nez v6, :cond_3

    .line 68
    .line 69
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 70
    .line 71
    if-ne v5, v6, :cond_4

    .line 72
    .line 73
    :cond_3
    const/4 v5, -0x1

    .line 74
    invoke-static {v1, v5}, LX/007;->A0c(LX/2d4;I)Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    :cond_4
    check-cast v5, LX/CR1;

    .line 79
    .line 80
    invoke-static {v4}, LX/004;->A1S(I)Z

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v10

    .line 88
    if-nez v6, :cond_5

    .line 89
    .line 90
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 91
    .line 92
    if-ne v10, v6, :cond_6

    .line 93
    .line 94
    :cond_5
    new-instance v10, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$1$1;

    .line 95
    .line 96
    invoke-direct {v10, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$1$1;-><init>(LX/JDM;)V

    .line 97
    .line 98
    .line 99
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_6
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 103
    .line 104
    const v6, 0x7f120534

    .line 105
    .line 106
    .line 107
    invoke-static {v1, v6}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v19

    .line 111
    sget-object p2, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;->LARGE_START_ALIGNED:Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;

    .line 112
    .line 113
    const/4 v8, 0x0

    .line 114
    const p4, 0x7fffffff

    .line 115
    .line 116
    .line 117
    new-instance v13, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;

    .line 118
    .line 119
    move-object/from16 v18, v13

    .line 120
    .line 121
    move-object/from16 v20, v8

    .line 122
    .line 123
    move-object/from16 v21, v8

    .line 124
    .line 125
    move-object/from16 p0, v8

    .line 126
    .line 127
    move-object/from16 p1, v8

    .line 128
    .line 129
    move-object/from16 p3, v8

    .line 130
    .line 131
    invoke-direct/range {v18 .. v26}, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;I)V

    .line 132
    .line 133
    .line 134
    new-instance v7, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2;

    .line 135
    .line 136
    invoke-direct {v7, v5, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2;-><init>(LX/CR1;LX/JDM;)V

    .line 137
    .line 138
    .line 139
    const v6, -0x34c1638

    .line 140
    .line 141
    .line 142
    invoke-static {v1, v7, v6}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 143
    .line 144
    .line 145
    move-result-object v14

    .line 146
    new-instance v6, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;

    .line 147
    .line 148
    invoke-direct {v6, v3, v5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;-><init>(LX/Ddn;LX/CR1;)V

    .line 149
    .line 150
    .line 151
    const v5, 0x2d7aa7e5

    .line 152
    .line 153
    .line 154
    invoke-static {v1, v6, v5}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 155
    .line 156
    .line 157
    move-result-object v20

    .line 158
    shr-int/lit8 v4, v4, 0x3

    .line 159
    .line 160
    and-int/lit8 p0, v4, 0x70

    .line 161
    .line 162
    const/high16 v4, 0x180000

    .line 163
    .line 164
    or-int p0, p0, v4

    .line 165
    .line 166
    const/16 p1, 0x180

    .line 167
    .line 168
    const/16 p2, 0xf99

    .line 169
    .line 170
    move-object v11, v8

    .line 171
    move-object v12, v8

    .line 172
    move-object v15, v8

    .line 173
    move-object/from16 v16, v8

    .line 174
    .line 175
    move/from16 v18, v17

    .line 176
    .line 177
    move/from16 v19, v17

    .line 178
    .line 179
    move-object/from16 v21, v1

    .line 180
    .line 181
    invoke-static/range {v8 .. v24}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraInlineBottomSheetKt;->AuraInlineBottomSheet(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;ZZZLX/JDQ;LX/2d4;III)V

    .line 182
    .line 183
    .line 184
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 185
    .line 186
    .line 187
    move-result-object v4

    .line 188
    if-eqz v4, :cond_7

    .line 189
    .line 190
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$4;

    .line 191
    .line 192
    move-object/from16 p0, v1

    .line 193
    .line 194
    move-object/from16 p1, v3

    .line 195
    .line 196
    move-object/from16 p2, v2

    .line 197
    .line 198
    move-object/from16 p3, v9

    .line 199
    .line 200
    move/from16 p4, v0

    .line 201
    .line 202
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$4;-><init>(LX/Ddn;LX/JDM;LX/3C1;II)V

    .line 203
    .line 204
    .line 205
    iput-object v1, v4, LX/J7V;->A06:LX/JDN;

    .line 206
    .line 207
    :cond_7
    return-void

    .line 208
    :cond_8
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 209
    .line 210
    .line 211
    goto :goto_2

    .line 212
    :cond_9
    and-int/lit16 v5, v0, 0x180

    .line 213
    .line 214
    if-nez v5, :cond_1

    .line 215
    .line 216
    invoke-static {v1, v9}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 217
    .line 218
    .line 219
    move-result v5

    .line 220
    or-int/2addr v4, v5

    .line 221
    goto/16 :goto_1

    .line 222
    .line 223
    :cond_a
    move v4, v0

    .line 224
    goto/16 :goto_0
.end method

.method public static final NativeLinkAccountSheet$lambda$1(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final NativeLinkAccountSheet$lambda$2(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NativeLinkAccountAvatar(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt;->NativeLinkAccountAvatar(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NativeLinkAccountOption(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt;->NativeLinkAccountOption(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$NativeLinkAccountSheet$lambda$1(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$NativeLinkAccountSheet$lambda$2(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
