.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final armedIn(Landroidx/activity/ComponentActivity;)Z
    .locals 3

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Landroidx/activity/ComponentActivity;->savedStateRegistryController:LX/14m;

    .line 5
    .line 6
    iget-object v2, v0, LX/14m;->A00:Landroidx/savedstate/SavedStateRegistry;

    .line 7
    .line 8
    const-string v1, "native_link_armed_marker"

    .line 9
    .line 10
    invoke-virtual {v2, v1}, Landroidx/savedstate/SavedStateRegistry;->A01(Ljava/lang/String;)LX/14p;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {v2, v1}, Landroidx/savedstate/SavedStateRegistry;->A00(Ljava/lang/String;)Landroid/os/Bundle;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :cond_0
    const/4 p0, 0x1

    .line 23
    :cond_1
    return p0
.end method

.method public final of(Landroidx/activity/ComponentActivity;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion$of$1;

    .line 5
    .line 6
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion$of$1;-><init>()V

    .line 7
    .line 8
    .line 9
    invoke-interface {p1}, LX/13Z;->getViewModelStore()LX/14b;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-static {p1}, LX/004;->A14(LX/15O;)LX/13i;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    new-instance v1, LX/15D;

    .line 18
    .line 19
    invoke-direct {v1, p0, v2, v0}, LX/15D;-><init>(LX/15L;LX/14b;LX/13i;)V

    .line 20
    .line 21
    .line 22
    const-class v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 23
    .line 24
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v1, v0}, LX/15D;->A02(LX/DVF;)LX/1EJ;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 33
    .line 34
    return-object v0
.end method
