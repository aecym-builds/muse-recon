.class public interface abstract Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;
.super Ljava/lang/Object;
.source ""
