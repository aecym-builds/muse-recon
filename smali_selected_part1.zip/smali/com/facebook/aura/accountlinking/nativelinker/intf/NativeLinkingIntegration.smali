.class public interface abstract Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkingIntegration;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;"
        }
    .end annotation
.end method
