.class public interface abstract Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
.super Ljava/lang/Object;
.source ""
