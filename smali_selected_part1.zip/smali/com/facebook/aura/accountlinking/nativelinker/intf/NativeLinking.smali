.class public final Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinking;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p2, p3}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    filled-new-array {p0}, [I

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    aget p0, v0, p0

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez p0, :cond_1

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;

    .line 17
    .line 18
    invoke-virtual {v0, p1, p2, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;->open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OFF:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 25
    .line 26
    :cond_0
    return-object v0

    .line 27
    :cond_1
    invoke-static {v0}, LX/005;->A0g(Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    throw v0
.end method
