.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion$of$1;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic create(LX/13i;)LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion$of$1;->create(LX/13i;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create(LX/13i;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/158;->A00(LX/13i;)LX/17V;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    new-instance p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;-><init>(LX/17V;)V

    .line 11
    .line 12
    .line 13
    return-object p0
.end method
