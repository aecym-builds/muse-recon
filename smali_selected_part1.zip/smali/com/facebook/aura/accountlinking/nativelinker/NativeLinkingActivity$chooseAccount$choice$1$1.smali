.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $continuation:LX/DT0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DT0<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;LX/DT0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            ">;",
            "LX/DT0<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->$rows:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->$continuation:LX/DT0;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 6

    .line 0
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object v5, p1

    .line 5
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->$rows:Ljava/util/List;

    .line 12
    .line 13
    invoke-static {v0}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->$continuation:LX/DT0;

    .line 18
    .line 19
    invoke-interface {p1, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1;->$continuation:LX/DT0;

    .line 24
    .line 25
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 32
    .line 33
    if-ne v3, v0, :cond_1

    .line 34
    .line 35
    :cond_0
    new-instance v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1$1$1;

    .line 36
    .line 37
    invoke-direct {v3, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$chooseAccount$choice$1$1$1$1;-><init>(LX/DT0;)V

    .line 38
    .line 39
    .line 40
    invoke-interface {p1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    check-cast v3, LX/JDM;

    .line 44
    .line 45
    sget p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->$stable:I

    .line 46
    .line 47
    const/4 p1, 0x4

    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-static/range {v2 .. v7}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt;->NativeLinkAccountSheet(LX/Ddn;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_2
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    return-void
.end method
