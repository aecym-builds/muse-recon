.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $host:Landroidx/activity/ComponentActivity;


# direct methods
.method public constructor <init>(Landroidx/activity/ComponentActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;->$host:Landroidx/activity/ComponentActivity;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;->$host:Landroidx/activity/ComponentActivity;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;->armedIn(Landroidx/activity/ComponentActivity;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;->$host:Landroidx/activity/ComponentActivity;

    .line 11
    .line 12
    invoke-virtual {v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;->of(Landroidx/activity/ComponentActivity;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;->$host:Landroidx/activity/ComponentActivity;

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->restore(Landroidx/activity/ComponentActivity;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1$invoke$$inlined$onDispose$1;

    .line 22
    .line 23
    invoke-direct {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
