.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $account:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;

.field public final synthetic $index:I

.field public final synthetic $selected$delegate:LX/CR1;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ILX/CR1;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$account:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$index:I

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 6

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object p1, p2

    .line 5
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    iget-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$account:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 14
    .line 15
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$index:I

    .line 20
    .line 21
    invoke-static {v1, v0}, LX/003;->A1I(II)Z

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 26
    .line 27
    invoke-interface {p2, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$index:I

    .line 32
    .line 33
    invoke-static {v1, p2, v0}, LX/001;->A1Z(ZLX/2d4;I)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    iget v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$index:I

    .line 38
    .line 39
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 40
    .line 41
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    if-nez v0, :cond_0

    .line 46
    .line 47
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 48
    .line 49
    if-ne v5, v0, :cond_1

    .line 50
    .line 51
    :cond_0
    new-instance v5, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;

    .line 52
    .line 53
    invoke-direct {v5, v2, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;-><init>(ILX/CR1;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {p2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_1
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 60
    .line 61
    const/4 p0, 0x0

    .line 62
    const/4 p2, 0x0

    .line 63
    const/16 p3, 0x8

    .line 64
    .line 65
    invoke-static/range {v3 .. v9}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt;->NativeLinkAccountOption(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_2
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 70
    .line 71
    .line 72
    return-void
.end method
