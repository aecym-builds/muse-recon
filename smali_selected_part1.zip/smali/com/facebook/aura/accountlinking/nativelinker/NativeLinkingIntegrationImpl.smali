.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkingIntegration;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingIntegrationImpl;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public open(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;LX/JDM;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p1}, Lcom/facebook/aura/utils/ContextUtilsKt;->findActivity(Landroid/content/Context;)Landroid/app/Activity;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    instance-of v0, p1, Landroidx/activity/ComponentActivity;

    .line 8
    .line 9
    if-eqz v0, :cond_3

    .line 10
    .line 11
    check-cast p1, Landroidx/activity/ComponentActivity;

    .line 12
    .line 13
    if-eqz p1, :cond_3

    .line 14
    .line 15
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;

    .line 16
    .line 17
    invoke-virtual {v1, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;->armedIn(Landroidx/activity/ComponentActivity;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;->of(Landroidx/activity/ComponentActivity;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->restore(Landroidx/activity/ComponentActivity;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->isArmed()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OPENED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 37
    .line 38
    return-object v0

    .line 39
    :cond_1
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/facebook/aura/auth/api/AuraSessionManager;->getCurrentSession()LX/AHE;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    if-nez p0, :cond_2

    .line 46
    .line 47
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->NO_SESSION:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 48
    .line 49
    return-object v0

    .line 50
    :cond_2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;

    .line 51
    .line 52
    invoke-virtual {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingGating;->isEnabled()Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    invoke-virtual {v1, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;->of(Landroidx/activity/ComponentActivity;)Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->Companion:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;

    .line 63
    .line 64
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 65
    .line 66
    invoke-virtual {v0, p1, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->newIntent(Landroid/content/Context;Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;)Landroid/content/Intent;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {v1, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;->withCookieExchange(Landroid/content/Intent;)Landroid/content/Intent;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {v2, p1, p0, v0, p3}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->launch(Landroidx/activity/ComponentActivity;LX/AHE;Landroid/content/Intent;LX/JDM;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-nez v0, :cond_0

    .line 79
    .line 80
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->LAUNCH_FAILED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 81
    .line 82
    return-object v0

    .line 83
    :cond_3
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;->OFF:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkOpen;

    .line 84
    .line 85
    return-object v0
.end method
