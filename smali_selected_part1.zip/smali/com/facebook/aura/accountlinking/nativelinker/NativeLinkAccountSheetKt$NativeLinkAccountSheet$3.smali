.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $accounts:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $selected$delegate:LX/CR1;


# direct methods
.method public constructor <init>(LX/Ddn;LX/CR1;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;",
            ">;",
            "LX/CR1;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;->$accounts:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;->$selected$delegate:LX/CR1;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 7

    .line 0
    and-int/lit8 v1, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_3

    .line 13
    .line 14
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 15
    .line 16
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 17
    .line 18
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;->$accounts:LX/Ddn;

    .line 23
    .line 24
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3;->$selected$delegate:LX/CR1;

    .line 25
    .line 26
    invoke-static {p2}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 27
    .line 28
    .line 29
    move-result-object v6

    .line 30
    move-object v5, p2

    .line 31
    check-cast v5, LX/J7I;

    .line 32
    .line 33
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    invoke-static {p2, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 46
    .line 47
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    invoke-static {}, LX/1VY;->A00()V

    .line 52
    .line 53
    .line 54
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    throw v0

    .line 59
    :cond_0
    invoke-static {p2, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 60
    .line 61
    .line 62
    invoke-static {p2, v6, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 63
    .line 64
    .line 65
    sget-object v2, LX/CgJ;->A00:LX/CgJ;

    .line 66
    .line 67
    invoke-static {p2, p1, p0}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    if-nez v0, :cond_1

    .line 76
    .line 77
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 78
    .line 79
    if-ne v1, v0, :cond_2

    .line 80
    .line 81
    :cond_1
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1;

    .line 82
    .line 83
    invoke-direct {v1, p1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1;-><init>(LX/Ddn;LX/CR1;)V

    .line 84
    .line 85
    .line 86
    invoke-interface {p2, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :cond_2
    check-cast v1, LX/JDM;

    .line 90
    .line 91
    const/4 v0, 0x6

    .line 92
    invoke-static {v2, v1, p2, v0}, LX/009;->A0s(LX/3dS;LX/JDM;LX/2d4;I)V

    .line 93
    .line 94
    .line 95
    const/4 v0, 0x1

    .line 96
    invoke-static {v5, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 101
    .line 102
    .line 103
    return-void
.end method
