.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity;

    .line 3
    .line 4
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    invoke-static {v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;->access$toNativeLinkRequest(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$Companion;Landroid/content/Intent;)Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkingActivity$request$2;->invoke()Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkRequest;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
