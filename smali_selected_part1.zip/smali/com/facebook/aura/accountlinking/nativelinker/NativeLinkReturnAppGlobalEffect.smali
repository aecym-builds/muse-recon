.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/globaleffects/api/AppGlobalEffect;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;

.field public static final runsUnderBlockingOverlay:Z = true


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public Effect(LX/2d4;I)V
    .locals 3

    .line 0
    const v0, 0x7082b78a

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v1, p2, 0x1

    .line 7
    .line 8
    invoke-static {v1}, LX/003;->A1B(I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-interface {p1, v1, v0}, LX/2d4;->Afw(IZ)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_4

    .line 17
    .line 18
    sget-object v0, LX/3J2;->A00:LX/Ip3;

    .line 19
    .line 20
    invoke-static {v0, p1}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    instance-of v0, v2, Landroidx/activity/ComponentActivity;

    .line 25
    .line 26
    if-eqz v0, :cond_3

    .line 27
    .line 28
    check-cast v2, Landroidx/activity/ComponentActivity;

    .line 29
    .line 30
    if-eqz v2, :cond_3

    .line 31
    .line 32
    invoke-interface {p1, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 43
    .line 44
    if-ne v0, v1, :cond_1

    .line 45
    .line 46
    :cond_0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;

    .line 47
    .line 48
    invoke-direct {v0, v2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$1$1;-><init>(Landroidx/activity/ComponentActivity;)V

    .line 49
    .line 50
    .line 51
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    invoke-static {p1, v0, v2}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :goto_0
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    if-eqz v1, :cond_2

    .line 62
    .line 63
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$2;

    .line 64
    .line 65
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$2;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;I)V

    .line 66
    .line 67
    .line 68
    :goto_1
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_2
    return-void

    .line 72
    :cond_3
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    if-eqz v1, :cond_2

    .line 77
    .line 78
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$host$1;

    .line 79
    .line 80
    invoke-direct {v0, p0, p2}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect$Effect$host$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;I)V

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_4
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 85
    .line 86
    .line 87
    goto :goto_0
.end method

.method public getRunsUnderBlockingOverlay()Z
    .locals 0

    .line 0
    sget-boolean p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkReturnAppGlobalEffect;->runsUnderBlockingOverlay:Z

    .line 1
    .line 2
    return p0
.end method
