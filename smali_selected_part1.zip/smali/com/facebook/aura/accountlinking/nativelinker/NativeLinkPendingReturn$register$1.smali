.class public final synthetic Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/1EY;
.implements LX/14M;


# instance fields
.field public final synthetic $tmp0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->$tmp0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 0
    instance-of v0, p1, LX/14M;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p1, LX/1EY;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->getFunctionDelegate()LX/1EZ;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast p1, LX/1EY;

    .line 14
    .line 15
    invoke-interface {p1}, LX/1EY;->getFunctionDelegate()LX/1EZ;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    return v0

    .line 24
    :cond_0
    return v1
.end method

.method public final getFunctionDelegate()LX/1EZ;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/1EZ<",
            "*>;"
        }
    .end annotation

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->$tmp0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 1
    .line 2
    const-class v3, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 3
    .line 4
    const-string v5, "onResult(Landroidx/activity/result/ActivityResult;)V"

    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    const/4 v1, 0x1

    .line 8
    const-string v4, "onResult"

    .line 9
    .line 10
    new-instance v0, LX/DVE;

    .line 11
    .line 12
    invoke-direct/range {v0 .. v6}, LX/DVE;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final hashCode()I
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->getFunctionDelegate()LX/1EZ;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public final onActivityResult(Landroidx/activity/result/ActivityResult;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->$tmp0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 5
    .line 6
    invoke-static {v0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->access$onResult(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;Landroidx/activity/result/ActivityResult;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public bridge synthetic onActivityResult(Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;->onActivityResult(Landroidx/activity/result/ActivityResult;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method
