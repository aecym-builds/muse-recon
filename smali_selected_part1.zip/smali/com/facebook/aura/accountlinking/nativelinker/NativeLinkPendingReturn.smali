.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;
.super LX/1EJ;
.source ""


# static fields
.field public static final $stable:I = 0x8

.field public static final ARMED_MARKER_KEY:Ljava/lang/String; = "native_link_armed_marker"

.field public static final Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;

.field public static final KEY_ARMED:Ljava/lang/String; = "native_link_armed"

.field public static final RESULT_KEY:Ljava/lang/String; = "native_link_return"

.field public static final TAG:Ljava/lang/String; = "NativeLinkPendingReturn"


# instance fields
.field public launcher:LX/13y;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/13y<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field

.field public markedRegistry:Landroidx/savedstate/SavedStateRegistry;

.field public observed:LX/AaB;

.field public observer:LX/E0Z;

.field public onReturn:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public result:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

.field public final savedState:LX/17V;

.field public session:LX/AHE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->Companion:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LX/17V;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->savedState:LX/17V;

    .line 8
    .line 9
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->CANCELLED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 10
    .line 11
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->result:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 12
    .line 13
    return-void
.end method

.method public static final synthetic access$deliver(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->deliver()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$detach(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->detach()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$onResult(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;Landroidx/activity/result/ActivityResult;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->onResult(Landroidx/activity/result/ActivityResult;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final deliver()V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->onReturn:LX/JDM;

    .line 1
    .line 2
    iget-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->session:LX/AHE;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->savedState:LX/17V;

    .line 5
    .line 6
    invoke-static {}, LX/002;->A0i()Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v0, "native_link_armed"

    .line 11
    .line 12
    invoke-virtual {v2, v0, v1}, LX/17V;->A03(Ljava/lang/String;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->onReturn:LX/JDM;

    .line 17
    .line 18
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->session:LX/AHE;

    .line 19
    .line 20
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->detach()V

    .line 21
    .line 22
    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    sget-object v0, Lcom/facebook/aura/auth/api/AuraSessionManager;->INSTANCE:Lcom/facebook/aura/auth/api/AuraSessionManager;

    .line 26
    .line 27
    invoke-virtual {v0, v3}, Lcom/facebook/aura/auth/api/AuraSessionManager;->isCurrentSession(LX/AHE;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    if-eqz v4, :cond_0

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->result:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 36
    .line 37
    invoke-interface {v4, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    :cond_0
    return-void
.end method

.method private final detach()V
    .locals 4

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observer:LX/E0Z;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observed:LX/AaB;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0, v1}, LX/AaB;->A05(LX/0TL;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    const/4 v3, 0x0

    .line 12
    iput-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observer:LX/E0Z;

    .line 13
    .line 14
    iput-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observed:LX/AaB;

    .line 15
    .line 16
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->markedRegistry:Landroidx/savedstate/SavedStateRegistry;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    const-string v2, "native_link_armed_marker"

    .line 21
    .line 22
    iget-object v0, v0, Landroidx/savedstate/SavedStateRegistry;->A01:LX/14n;

    .line 23
    .line 24
    iget-object v1, v0, LX/14n;->A05:LX/14q;

    .line 25
    .line 26
    monitor-enter v1

    .line 27
    :try_start_0
    iget-object v0, v0, LX/14n;->A06:Ljava/util/Map;

    .line 28
    .line 29
    invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    monitor-exit v1

    .line 35
    throw v0

    .line 36
    :goto_0
    monitor-exit v1

    .line 37
    :cond_1
    iput-object v3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->markedRegistry:Landroidx/savedstate/SavedStateRegistry;

    .line 38
    .line 39
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->unregister()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method private final mark(Landroidx/activity/ComponentActivity;)V
    .locals 3

    .line 0
    iget-object v0, p1, Landroidx/activity/ComponentActivity;->savedStateRegistryController:LX/14m;

    .line 1
    .line 2
    iget-object v2, v0, LX/14m;->A00:Landroidx/savedstate/SavedStateRegistry;

    .line 3
    .line 4
    const-string v1, "native_link_armed_marker"

    .line 5
    .line 6
    invoke-virtual {v2, v1}, Landroidx/savedstate/SavedStateRegistry;->A01(Ljava/lang/String;)LX/14p;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$mark$1;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$mark$1;

    .line 13
    .line 14
    invoke-virtual {v2, v0, v1}, Landroidx/savedstate/SavedStateRegistry;->A03(LX/14p;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iput-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->markedRegistry:Landroidx/savedstate/SavedStateRegistry;

    .line 18
    .line 19
    return-void
.end method

.method private final observe(LX/07p;Z)V
    .locals 2

    .line 0
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;

    .line 1
    .line 2
    invoke-direct {v1, p2, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;-><init>(ZLcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V

    .line 3
    .line 4
    .line 5
    iput-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observer:LX/E0Z;

    .line 6
    .line 7
    invoke-interface {p1}, LX/07p;->getLifecycle()LX/AaB;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observed:LX/AaB;

    .line 12
    .line 13
    invoke-interface {p1}, LX/07p;->getLifecycle()LX/AaB;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0, v1}, LX/AaB;->A04(LX/0TL;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method private final onResult(Landroidx/activity/result/ActivityResult;)V
    .locals 4

    .line 0
    iget v1, p1, Landroidx/activity/result/ActivityResult;->A00:I

    .line 1
    .line 2
    const/4 v0, -0x1

    .line 3
    const/4 v3, 0x1

    .line 4
    if-eq v1, v0, :cond_2

    .line 5
    .line 6
    if-eq v1, v3, :cond_1

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->CANCELLED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 9
    .line 10
    :goto_0
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->result:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 11
    .line 12
    iget-object v2, p1, Landroidx/activity/result/ActivityResult;->A01:Landroid/content/Intent;

    .line 13
    .line 14
    if-eqz v2, :cond_0

    .line 15
    .line 16
    const-string v1, "native_link_one_tap_stored"

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ne v0, v3, :cond_0

    .line 24
    .line 25
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const/4 v1, 0x0

    .line 30
    new-instance v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$onResult$1;

    .line 31
    .line 32
    invoke-direct {v0, v1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$onResult$1;-><init>(LX/2M4;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0, v2}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void

    .line 39
    :cond_1
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->DIALOG_UNAVAILABLE:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->COMPLETED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 43
    .line 44
    goto :goto_0
.end method

.method private final register(Landroidx/activity/ComponentActivity;)LX/13y;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/activity/ComponentActivity;",
            ")",
            "LX/13y<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p1, Landroidx/activity/ComponentActivity;->activityResultRegistry:LX/14G;

    .line 1
    .line 2
    new-instance v2, LX/13u;

    .line 3
    .line 4
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;

    .line 8
    .line 9
    invoke-direct {v1, p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$register$1;-><init>(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V

    .line 10
    .line 11
    .line 12
    const-string v0, "native_link_return"

    .line 13
    .line 14
    invoke-virtual {v3, v1, v2, v0}, LX/14G;->A02(LX/14M;LX/14D;Ljava/lang/String;)LX/14J;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->launcher:LX/13y;

    .line 19
    .line 20
    return-object v0
.end method

.method private final unregister()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->launcher:LX/13y;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    invoke-virtual {v0}, LX/13y;->A00()V

    .line 5
    .line 6
    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->launcher:LX/13y;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final isArmed()Z
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->savedState:LX/17V;

    .line 1
    .line 2
    const-string v0, "native_link_armed"

    .line 3
    .line 4
    invoke-virtual {p0, v0}, LX/17V;->A01(Ljava/lang/String;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Ljava/lang/Boolean;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    return v0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    return v0
.end method

.method public final launch(Landroidx/activity/ComponentActivity;LX/AHE;Landroid/content/Intent;LX/JDM;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/activity/ComponentActivity;",
            "LX/AHE;",
            "Landroid/content/Intent;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    invoke-static {p2, p3, p4, v3}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;->CANCELLED:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 9
    .line 10
    iput-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->result:Lcom/facebook/aura/accountlinking/nativelinker/intf/NativeLinkResult;

    .line 11
    .line 12
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->register(Landroidx/activity/ComponentActivity;)LX/13y;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    :try_start_0
    const/4 v0, 0x0

    .line 17
    invoke-virtual {v1, v0, p3}, LX/13y;->A01(LX/13z;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 18
    .line 19
    .line 20
    iget-object v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->savedState:LX/17V;

    .line 21
    .line 22
    const-string v1, "native_link_armed"

    .line 23
    .line 24
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v2, v1, v0}, LX/17V;->A03(Ljava/lang/String;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->mark(Landroidx/activity/ComponentActivity;)V

    .line 32
    .line 33
    .line 34
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->session:LX/AHE;

    .line 35
    .line 36
    iput-object p4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->onReturn:LX/JDM;

    .line 37
    .line 38
    iget-object v0, p1, Landroidx/core/app/ComponentActivity;->lifecycleRegistry:LX/E0b;

    .line 39
    .line 40
    iget-object v1, v0, LX/E0b;->A01:LX/15h;

    .line 41
    .line 42
    sget-object v0, LX/15h;->A05:LX/15h;

    .line 43
    .line 44
    invoke-virtual {v1, v0}, LX/15h;->A00(LX/15h;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    xor-int/lit8 v0, v0, 0x1

    .line 49
    .line 50
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observe(LX/07p;Z)V

    .line 51
    .line 52
    .line 53
    return v3

    .line 54
    :catch_0
    move-exception v2

    .line 55
    const-string v1, "Native linker launch failed"

    .line 56
    .line 57
    const-string v0, "NativeLinkPendingReturn"

    .line 58
    .line 59
    invoke-static {v0, v1, v2}, LX/FnY;->A0B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 60
    .line 61
    .line 62
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->unregister()V

    .line 63
    .line 64
    .line 65
    return v4
.end method

.method public final restore(Landroidx/activity/ComponentActivity;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->isArmed()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observer:LX/E0Z;

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->mark(Landroidx/activity/ComponentActivity;)V

    .line 15
    .line 16
    .line 17
    invoke-direct {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->register(Landroidx/activity/ComponentActivity;)LX/13y;

    .line 18
    .line 19
    .line 20
    iget-object v0, p1, Landroidx/core/app/ComponentActivity;->lifecycleRegistry:LX/E0b;

    .line 21
    .line 22
    iget-object v1, v0, LX/E0b;->A01:LX/15h;

    .line 23
    .line 24
    sget-object v0, LX/15h;->A05:LX/15h;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, LX/15h;->A00(LX/15h;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-direct {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->deliver()V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void

    .line 36
    :cond_1
    const/4 v0, 0x1

    .line 37
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->observe(LX/07p;Z)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
