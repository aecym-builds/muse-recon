.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;


# static fields
.field public static final $stable:I


# instance fields
.field public final index:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;->index:I

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final getIndex()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$Picked;->index:I

    .line 1
    .line 2
    return p0
.end method
