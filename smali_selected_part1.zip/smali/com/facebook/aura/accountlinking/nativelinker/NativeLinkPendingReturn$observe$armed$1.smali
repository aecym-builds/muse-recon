.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/E0Z;


# instance fields
.field public paused:Z

.field public final synthetic this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;


# direct methods
.method public constructor <init>(ZLcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V
    .locals 0

    .line 0
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    iput-boolean p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->paused:Z

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public onStateChanged(LX/07p;LX/DqI;)V
    .locals 3

    .line 0
    const/4 v2, 0x1

    .line 1
    const/4 v0, 0x3

    .line 2
    invoke-static {p2, v2}, LX/002;->A0K(Ljava/lang/Enum;I)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    if-eq v1, v0, :cond_2

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    if-eq v1, v0, :cond_1

    .line 10
    .line 11
    const/4 v0, 0x5

    .line 12
    if-ne v1, v0, :cond_0

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 15
    .line 16
    invoke-static {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->access$detach(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void

    .line 20
    :cond_1
    iget-boolean v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->paused:Z

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->this$0:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;

    .line 25
    .line 26
    invoke-static {v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;->access$deliver(Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_2
    iput-boolean v2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkPendingReturn$observe$armed$1;->paused:Z

    .line 31
    .line 32
    return-void
.end method
