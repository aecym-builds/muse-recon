.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onChoice:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $selected$delegate:LX/CR1;


# direct methods
.method public constructor <init>(LX/CR1;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/CR1;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$selected$delegate:LX/CR1;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$onChoice:LX/JDM;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;)V
    .locals 12

    .line 0
    const/4 v7, 0x0

    .line 1
    move-object v2, p1

    .line 2
    invoke-static {p1, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$selected$delegate:LX/CR1;

    .line 6
    .line 7
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-static {v0}, LX/003;->A1D(I)Z

    .line 12
    .line 13
    .line 14
    move-result v6

    .line 15
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$onChoice:LX/JDM;

    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$selected$delegate:LX/CR1;

    .line 18
    .line 19
    new-instance v9, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$1;

    .line 20
    .line 21
    invoke-direct {v9, v1, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$1;-><init>(LX/JDM;LX/CR1;)V

    .line 22
    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    const v3, 0x7f1202b8

    .line 26
    .line 27
    .line 28
    const-string v8, "primary_button"

    .line 29
    .line 30
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 31
    .line 32
    move-object v5, v4

    .line 33
    move-object v10, v4

    .line 34
    invoke-interface/range {v2 .. v11}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->primaryButton(I[Ljava/lang/Object;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1;->$onChoice:LX/JDM;

    .line 38
    .line 39
    new-instance v9, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;

    .line 40
    .line 41
    invoke-direct {v9, v0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;-><init>(LX/JDM;)V

    .line 42
    .line 43
    .line 44
    const v3, 0x7f120530

    .line 45
    .line 46
    .line 47
    const/4 v6, 0x1

    .line 48
    const-string v8, "secondary_button"

    .line 49
    .line 50
    invoke-interface/range {v2 .. v11}, Lcom/facebook/aura/vds/compose/buttongroup/AuraButtonGroupScope;->secondaryButton(I[Ljava/lang/Object;Landroid/graphics/drawable/Drawable;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;LX/3C1;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method
