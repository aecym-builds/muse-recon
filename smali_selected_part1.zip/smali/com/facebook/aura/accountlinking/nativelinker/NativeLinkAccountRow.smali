.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final appBadge:I

.field public final appName:I

.field public final avatarUrl:Ljava/lang/String;

.field public final name:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->name:Ljava/lang/String;

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appName:I

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->avatarUrl:Ljava/lang/String;

    .line 8
    .line 9
    iput p4, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appBadge:I

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final getAppBadge()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appBadge:I

    .line 1
    .line 2
    return p0
.end method

.method public final getAppName()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->appName:I

    .line 1
    .line 2
    return p0
.end method

.method public final getAvatarUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->avatarUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getName()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountRow;->name:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
