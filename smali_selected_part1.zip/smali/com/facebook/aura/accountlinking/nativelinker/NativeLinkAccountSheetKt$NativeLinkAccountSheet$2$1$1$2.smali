.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onChoice:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;->$onChoice:LX/JDM;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$2$1$1$2;->$onChoice:LX/JDM;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$UseAnotherAccount;->INSTANCE:Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountChoice$UseAnotherAccount;

    .line 3
    .line 4
    invoke-interface {p0, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
