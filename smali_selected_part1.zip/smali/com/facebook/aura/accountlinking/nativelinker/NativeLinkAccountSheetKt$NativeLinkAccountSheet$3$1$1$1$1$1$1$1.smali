.class public final Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $index:I

.field public final synthetic $selected$delegate:LX/CR1;


# direct methods
.method public constructor <init>(ILX/CR1;)V
    .locals 1

    .line 0
    iput p1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;->$index:I

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;->$selected$delegate:LX/CR1;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/accountlinking/nativelinker/NativeLinkAccountSheetKt$NativeLinkAccountSheet$3$1$1$1$1$1$1$1;->$index:I

    .line 3
    .line 4
    invoke-interface {v1, v0}, LX/CR1;->Ae1(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
