.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final expectedFingerprint:Ljava/lang/String;

.field public final fallback:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final onResult:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "Ljava/lang/Long;",
            "Ljava/lang/String;",
            "Ljava/lang/Throwable;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final startedAtNs:J


# direct methods
.method public constructor <init>(Ljava/lang/String;JLX/JDQ;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "LX/JDQ<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p4, v0, p5}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->expectedFingerprint:Ljava/lang/String;

    .line 8
    .line 9
    iput-wide p2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->startedAtNs:J

    .line 10
    .line 11
    iput-object p4, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->onResult:LX/JDQ;

    .line 12
    .line 13
    iput-object p5, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->fallback:Lkotlin/jvm/functions/Function0;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final deliver(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->expectedFingerprint:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->fallback:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    iget-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->onResult:LX/JDQ;

    .line 15
    .line 16
    iget-wide v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->startedAtNs:J

    .line 17
    .line 18
    invoke-static {v0, p0}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-interface {p1, v0, p2, p3}, LX/JDQ;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    return-void
.end method
