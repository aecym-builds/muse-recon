.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;

.field public static final MAX_PENDING_MS:J = 0x7530L

.field public static final mainHandler:Landroid/os/Handler;

.field public static volatile pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;

    .line 6
    .line 7
    invoke-static {}, LX/003;->A0P()Landroid/os/Handler;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->mainHandler:Landroid/os/Handler;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getPending$p()Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$setPending$p(Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;)V
    .locals 0

    .line 0
    sput-object p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    return-void
.end method


# virtual methods
.method public final join(JLjava/lang/String;LX/JDQ;Lkotlin/jvm/functions/Function0;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/lang/String;",
            "LX/JDQ<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-static {p4, v0, p5}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 5
    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->accepts(J)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 16
    .line 17
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->mainHandler:Landroid/os/Handler;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->expiry:Ljava/lang/Runnable;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p3, p4, p5}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->join(Ljava/lang/String;LX/JDQ;Lkotlin/jvm/functions/Function0;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    return v0

    .line 29
    :cond_0
    const/4 v0, 0x0

    .line 30
    return v0
.end method

.method public final start(J)V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    if-eqz v1, :cond_0

    .line 3
    .line 4
    invoke-virtual {v1, p1, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->accept(J)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_2

    .line 9
    .line 10
    invoke-virtual {v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->acceptedGenerations()Ljava/util/Set;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    if-nez v1, :cond_1

    .line 15
    .line 16
    :cond_0
    sget-object v1, LX/0wX;->A00:LX/0wX;

    .line 17
    .line 18
    :cond_1
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0, v1}, LX/163;->A01(Ljava/lang/Object;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance p2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 27
    .line 28
    invoke-direct {p2, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;-><init>(Ljava/util/Set;)V

    .line 29
    .line 30
    .line 31
    sput-object p2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 32
    .line 33
    sget-object p1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->mainHandler:Landroid/os/Handler;

    .line 34
    .line 35
    iget-object p0, p2, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->expiry:Ljava/lang/Runnable;

    .line 36
    .line 37
    const-wide/16 v0, 0x7530

    .line 38
    .line 39
    invoke-virtual {p1, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 40
    .line 41
    .line 42
    sget-object v0, Lcom/facebook/aura/executors/AuraExecutors;->INSTANCE:Lcom/facebook/aura/executors/AuraExecutors;

    .line 43
    .line 44
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraExecutors;->getIoExecutor()Ljava/util/concurrent/ExecutorService;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$start$1;

    .line 49
    .line 50
    invoke-direct {v0, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$start$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 54
    .line 55
    .line 56
    :cond_2
    return-void
.end method
