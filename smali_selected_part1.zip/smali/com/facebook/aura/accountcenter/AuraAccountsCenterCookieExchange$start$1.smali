.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$start$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $exchange:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$start$1;->$exchange:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$start$1;->$exchange:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    invoke-virtual {p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->run()V

    .line 3
    .line 4
    .line 5
    return-void
.end method
