.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange$expiry$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange$expiry$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange$expiry$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 3
    .line 4
    if-ne v1, v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    sput-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->pending:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;

    .line 8
    .line 9
    :cond_0
    return-void
.end method
