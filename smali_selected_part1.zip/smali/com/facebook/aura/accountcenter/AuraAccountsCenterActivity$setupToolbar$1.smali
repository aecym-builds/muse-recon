.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/0aD;


# instance fields
.field public final synthetic $toolbar:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;->$toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;LX/0tm;)LX/0tm;
    .locals 7

    .line 0
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v6

    .line 4
    const/16 v1, 0x28f

    .line 5
    .line 6
    iget-object v0, p2, LX/0tm;->A00:LX/0tg;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, LX/0tg;->A0D(I)LX/0lh;

    .line 9
    .line 10
    .line 11
    move-result-object v5

    .line 12
    invoke-static {v5}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-object v4, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;->$toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 16
    .line 17
    invoke-virtual {v4}, Landroid/view/View;->getPaddingLeft()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    iget v2, v5, LX/0lh;->A03:I

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;->$toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 24
    .line 25
    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$1;->$toolbar:Landroidx/appcompat/widget/Toolbar;

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-virtual {v4, v3, v2, v1, v0}, Landroid/view/View;->setPadding(IIII)V

    .line 36
    .line 37
    .line 38
    iget v2, v5, LX/0lh;->A01:I

    .line 39
    .line 40
    iget v1, v5, LX/0lh;->A02:I

    .line 41
    .line 42
    iget v0, v5, LX/0lh;->A00:I

    .line 43
    .line 44
    invoke-virtual {p1, v2, v6, v1, v0}, Landroid/view/View;->setPadding(IIII)V

    .line 45
    .line 46
    .line 47
    sget-object v0, LX/0tm;->A01:LX/0tm;

    .line 48
    .line 49
    return-object v0
.end method
