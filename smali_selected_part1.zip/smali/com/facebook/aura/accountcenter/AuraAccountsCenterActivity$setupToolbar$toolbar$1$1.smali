.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$toolbar$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$toolbar$1$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$setupToolbar$toolbar$1$1;->this$0:Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 1
    .line 2
    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->onSupportNavigateUp()Z

    .line 3
    .line 4
    .line 5
    return-void
.end method
