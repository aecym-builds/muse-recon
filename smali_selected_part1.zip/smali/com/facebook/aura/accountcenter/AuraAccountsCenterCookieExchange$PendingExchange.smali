.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/AYT;


# instance fields
.field public completed:Z

.field public cookie:Ljava/lang/String;

.field public credentialFingerprint:Ljava/lang/String;

.field public credentialRead:Z

.field public error:Ljava/lang/Throwable;

.field public final expiry:Ljava/lang/Runnable;

.field public final generations:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public final startedAtNs:J

.field public waiter:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;


# direct methods
.method public constructor <init>(Ljava/util/Set;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange$expiry$1;

    .line 8
    .line 9
    invoke-direct {v0, p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange$expiry$1;-><init>(Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->expiry:Ljava/lang/Runnable;

    .line 13
    .line 14
    invoke-static {p1}, LX/B89;->A0s(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->generations:Ljava/util/Set;

    .line 19
    .line 20
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 21
    .line 22
    .line 23
    move-result-wide v0

    .line 24
    iput-wide v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->startedAtNs:J

    .line 25
    .line 26
    return-void
.end method

.method private final complete(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->completed:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    .line 5
    monitor-exit p0

    .line 6
    return-void

    .line 7
    :cond_0
    :try_start_1
    const/4 v0, 0x1

    .line 8
    iput-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->completed:Z

    .line 9
    .line 10
    iput-object p1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->cookie:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->error:Ljava/lang/Throwable;

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->waiter:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->waiter:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialFingerprint:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    .line 21
    monitor-exit p0

    .line 22
    if-eqz v1, :cond_1

    .line 23
    .line 24
    invoke-virtual {v1, v0, p1, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->deliver(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 25
    .line 26
    .line 27
    :cond_1
    return-void

    .line 28
    :catchall_0
    move-exception v0

    .line 29
    monitor-exit p0

    .line 30
    throw v0
.end method


# virtual methods
.method public final accept(J)Z
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->completed:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->error:Ljava/lang/Throwable;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->generations:Ljava/util/Set;

    .line 11
    .line 12
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x1

    .line 20
    goto :goto_1

    .line 21
    :goto_0
    const/4 v0, 0x0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    :goto_1
    monitor-exit p0

    .line 23
    return v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0

    .line 26
    throw v0
.end method

.method public final acceptedGenerations()Ljava/util/Set;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->generations:Ljava/util/Set;

    .line 2
    .line 3
    invoke-static {v0}, LX/B89;->A0t(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 4
    .line 5
    .line 6
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    monitor-exit p0

    .line 8
    return-object v0

    .line 9
    :catchall_0
    move-exception v0

    .line 10
    monitor-exit p0

    .line 11
    throw v0
.end method

.method public final accepts(J)Z
    .locals 2

    .line 0
    monitor-enter p0

    .line 1
    :try_start_0
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->generations:Ljava/util/Set;

    .line 2
    .line 3
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    monitor-exit p0

    .line 12
    return v0

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    monitor-exit p0

    .line 15
    throw v0
.end method

.method public final getExpiry()Ljava/lang/Runnable;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->expiry:Ljava/lang/Runnable;

    .line 1
    .line 2
    return-object p0
.end method

.method public final join(Ljava/lang/String;LX/JDQ;Lkotlin/jvm/functions/Function0;)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/JDQ<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 0
    const/4 v3, 0x1

    .line 1
    move-object v8, p2

    .line 2
    move-object v9, p3

    .line 3
    invoke-static {p2, v3, p3}, LX/003;->A0x(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-wide v6, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->startedAtNs:J

    .line 7
    .line 8
    new-instance v4, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;

    .line 9
    .line 10
    move-object v5, p1

    .line 11
    invoke-direct/range {v4 .. v9}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;-><init>(Ljava/lang/String;JLX/JDQ;Lkotlin/jvm/functions/Function0;)V

    .line 12
    .line 13
    .line 14
    monitor-enter p0

    .line 15
    :try_start_0
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialRead:Z

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialFingerprint:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    .line 27
    monitor-exit p0

    .line 28
    const/4 v0, 0x0

    .line 29
    return v0

    .line 30
    :cond_0
    :try_start_1
    iget-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->completed:Z

    .line 31
    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    iput-object v4, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->waiter:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 35
    .line 36
    monitor-exit p0

    .line 37
    return v3

    .line 38
    :cond_1
    monitor-exit p0

    .line 39
    iget-object v2, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialFingerprint:Ljava/lang/String;

    .line 40
    .line 41
    iget-object v1, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->cookie:Ljava/lang/String;

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->error:Ljava/lang/Throwable;

    .line 44
    .line 45
    invoke-virtual {v4, v2, v1, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$Waiter;->deliver(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 46
    .line 47
    .line 48
    return v3

    .line 49
    :catchall_0
    move-exception v0

    .line 50
    monitor-exit p0

    .line 51
    throw v0
.end method

.method public onFail(Ljava/lang/Throwable;)V
    .locals 1

    .line 0
    if-nez p1, :cond_0

    .line 1
    .line 2
    const-string v0, "Session cookie exchange failed"

    .line 3
    .line 4
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->complete(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public onSuccess(Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->complete(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final run()V
    .locals 2

    .line 0
    sget-object v0, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->INSTANCE:Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->getMetaAccessToken()Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/bloks/storage/AuraMetaFRLSecureTokenStore;->frlFingerprint()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    monitor-enter p0

    .line 11
    :try_start_0
    iput-object v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialFingerprint:Ljava/lang/String;

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->credentialRead:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    monitor-exit p0

    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    const-string v0, "No Meta access token"

    .line 20
    .line 21
    invoke-static {v0}, LX/001;->A0r(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/4 v0, 0x0

    .line 26
    invoke-direct {p0, v0, v1}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange$PendingExchange;->complete(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;

    .line 31
    .line 32
    invoke-virtual {v0}, Lcom/facebook/aura/accountcenter/AuraMetaCookieRequestFactory;->getInstance()LX/GIo;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    new-instance v0, LX/GIX;

    .line 37
    .line 38
    invoke-direct {v0, v1}, LX/GIX;-><init>(LX/GIo;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, p0}, LX/GIX;->A00(LX/AYT;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    monitor-exit p0

    .line 47
    throw v0
.end method
