.class public final Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final launchFromSettings(Landroid/content/Context;LX/AHE;)V
    .locals 2

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;->startSettingsLoad()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p2}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterLoadLogger;->logSettingsEntrypointNavigate(LX/AHE;)V

    .line 9
    .line 10
    .line 11
    const-class v1, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;

    .line 12
    .line 13
    new-instance v0, Landroid/content/Intent;

    .line 14
    .line 15
    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, v0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity$Companion;->withCookieExchange(Landroid/content/Intent;)Landroid/content/Intent;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {p1, v0}, LX/1I0;->A00(Landroid/content/Context;Landroid/content/Intent;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final withCookieExchange(Landroid/content/Intent;)Landroid/content/Intent;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterActivity;->measurementLaunchGeneration:Ljava/util/concurrent/atomic/AtomicLong;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 7
    .line 8
    .line 9
    move-result-wide v1

    .line 10
    sget-object v0, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->INSTANCE:Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;

    .line 11
    .line 12
    invoke-virtual {v0, v1, p0}, Lcom/facebook/aura/accountcenter/AuraAccountsCenterCookieExchange;->start(J)V

    .line 13
    .line 14
    .line 15
    const-string v0, "hatch_ac_measurement_generation"

    .line 16
    .line 17
    invoke-virtual {p1, v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method
