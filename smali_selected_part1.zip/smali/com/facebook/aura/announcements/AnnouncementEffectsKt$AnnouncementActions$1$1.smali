.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.announcements.AnnouncementEffectsKt$AnnouncementActions$1$1"
    f = "AnnouncementEffects.kt"
    l = {
        0x47
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $userSession:LX/AHE;

.field public final synthetic $viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Lcom/facebook/aura/navigation/AuraNavigator;LX/AHE;Landroid/content/Context;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/announcements/AnnouncementViewModel;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "LX/AHE;",
            "Landroid/content/Context;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$userSession:LX/AHE;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$context:Landroid/content/Context;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$userSession:LX/AHE;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$context:Landroid/content/Context;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;-><init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Lcom/facebook/aura/navigation/AuraNavigator;LX/AHE;Landroid/content/Context;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-eq v0, v5, :cond_1

    .line 8
    .line 9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    throw v0

    .line 14
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 18
    .line 19
    iget-object v4, v0, Lcom/facebook/aura/announcements/AnnouncementViewModel;->dismissRequests:LX/2QV;

    .line 20
    .line 21
    iget-object v3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 22
    .line 23
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$userSession:LX/AHE;

    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->$context:Landroid/content/Context;

    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;

    .line 28
    .line 29
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;LX/AHE;Landroid/content/Context;)V

    .line 30
    .line 31
    .line 32
    iput v5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1;->label:I

    .line 33
    .line 34
    invoke-interface {v4, v0, p0}, LX/2QV;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-ne v0, v6, :cond_2

    .line 39
    .line 40
    return-object v6

    .line 41
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_2
    invoke-static {}, LX/001;->A19()Lkotlin/KotlinNothingValueException;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    throw v0
.end method
