.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "Ljava/lang/Boolean;",
        "LX/2M4<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.announcements.AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2"
    f = "AnnouncementEffects.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic Z$0:Z

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iput-boolean v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;->Z$0:Z

    .line 10
    .line 11
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    check-cast p2, LX/2M4;

    .line 268435461
    .line 268435462
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;->invoke(ZLX/2M4;)Ljava/lang/Object;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method

.method public final invoke(ZLX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-static {p2, p0, p1}, LX/002;->A1D(LX/2M4;LX/DrA;Z)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;->Z$0:Z

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;->label:I

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    invoke-static {p1, v1}, LX/2PI;->A01(Ljava/lang/Object;Z)Ljava/lang/Boolean;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    throw v0
.end method
