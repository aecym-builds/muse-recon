.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.announcements.AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1"
    f = "AnnouncementEffects.kt"
    l = {
        0x2a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $density:LX/34Y;

.field public final synthetic $imeInsets:LX/2uk;

.field public final synthetic $lifecycleOwner:LX/07p;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

.field public final synthetic $view:Landroid/view/View;

.field public final synthetic $viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

.field public label:I


# direct methods
.method public constructor <init>(LX/07p;Lcom/facebook/aura/announcements/AnnouncementViewModel;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;Landroid/view/View;Lcom/facebook/aura/navigation/HatchSidePanelController;LX/2uk;LX/34Y;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/07p;",
            "Lcom/facebook/aura/announcements/AnnouncementViewModel;",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "Landroid/view/View;",
            "Lcom/facebook/aura/navigation/HatchSidePanelController;",
            "LX/2uk;",
            "LX/34Y;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$lifecycleOwner:LX/07p;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$view:Landroid/view/View;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$imeInsets:LX/2uk;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$density:LX/34Y;

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0, p9}, LX/DRu;-><init>(ILX/2M4;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$lifecycleOwner:LX/07p;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$view:Landroid/view/View;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$imeInsets:LX/2uk;

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$density:LX/34Y;

    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;

    .line 17
    .line 18
    move-object p1, p2

    .line 19
    invoke-direct/range {v0 .. v9}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;-><init>(LX/07p;Lcom/facebook/aura/announcements/AnnouncementViewModel;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;Landroid/view/View;Lcom/facebook/aura/navigation/HatchSidePanelController;LX/2uk;LX/34Y;LX/2M4;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->label:I

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    if-eqz v1, :cond_1

    .line 6
    .line 7
    if-ne v1, v0, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v2

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v7, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$lifecycleOwner:LX/07p;

    .line 19
    .line 20
    sget-object v1, LX/15h;->A06:LX/15h;

    .line 21
    .line 22
    iget-object v4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 23
    .line 24
    iget-object v5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$context:Landroid/content/Context;

    .line 25
    .line 26
    iget-object v6, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 27
    .line 28
    iget-object v8, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$view:Landroid/view/View;

    .line 29
    .line 30
    iget-object v9, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 31
    .line 32
    iget-object v10, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$imeInsets:LX/2uk;

    .line 33
    .line 34
    iget-object v11, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->$density:LX/34Y;

    .line 35
    .line 36
    const/4 v12, 0x0

    .line 37
    new-instance v3, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;

    .line 38
    .line 39
    invoke-direct/range {v3 .. v12}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;-><init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/07p;Landroid/view/View;Lcom/facebook/aura/navigation/HatchSidePanelController;LX/2uk;LX/34Y;LX/2M4;)V

    .line 40
    .line 41
    .line 42
    iput v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1;->label:I

    .line 43
    .line 44
    invoke-interface {v7}, LX/07p;->getLifecycle()LX/AaB;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v1, v0, p0, v3}, LX/2Ze;->A00(LX/15h;LX/AaB;LX/2M4;LX/JDN;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    if-ne v0, v2, :cond_0

    .line 53
    .line 54
    return-object v2

    .line 55
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    throw v0
.end method
