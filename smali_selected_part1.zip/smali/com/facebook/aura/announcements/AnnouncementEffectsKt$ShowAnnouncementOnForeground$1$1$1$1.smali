.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-interface {p0, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->currentKey(Z)Lcom/facebook/aura/navigation/AuraNavKey;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    sget-object v0, Lcom/facebook/aura/navigation/key/ConversationTabScreenKey;->INSTANCE:Lcom/facebook/aura/navigation/key/ConversationTabScreenKey;

    .line 8
    .line 9
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
