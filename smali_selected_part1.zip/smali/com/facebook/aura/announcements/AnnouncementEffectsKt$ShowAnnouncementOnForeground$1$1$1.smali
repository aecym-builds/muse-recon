.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.announcements.AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1"
    f = "AnnouncementEffects.kt"
    l = {
        0x2f,
        0x30
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $density:LX/34Y;

.field public final synthetic $imeInsets:LX/2uk;

.field public final synthetic $lifecycleOwner:LX/07p;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

.field public final synthetic $view:Landroid/view/View;

.field public final synthetic $viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/07p;Landroid/view/View;Lcom/facebook/aura/navigation/HatchSidePanelController;LX/2uk;LX/34Y;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/announcements/AnnouncementViewModel;",
            "Landroid/content/Context;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "LX/07p;",
            "Landroid/view/View;",
            "Lcom/facebook/aura/navigation/HatchSidePanelController;",
            "LX/2uk;",
            "LX/34Y;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$lifecycleOwner:LX/07p;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$view:Landroid/view/View;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$imeInsets:LX/2uk;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$density:LX/34Y;

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0, p9}, LX/DRu;-><init>(ILX/2M4;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$lifecycleOwner:LX/07p;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$view:Landroid/view/View;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$imeInsets:LX/2uk;

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$density:LX/34Y;

    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;

    .line 17
    .line 18
    move-object p1, p2

    .line 19
    invoke-direct/range {v0 .. v9}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;-><init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/07p;Landroid/view/View;Lcom/facebook/aura/navigation/HatchSidePanelController;LX/2uk;LX/34Y;LX/2M4;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    const/4 v3, 0x2

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v0, :cond_3

    .line 8
    .line 9
    if-eq v0, v2, :cond_5

    .line 10
    .line 11
    if-ne v0, v3, :cond_7

    .line 12
    .line 13
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast p1, Lcom/facebook/aura/announcements/repo/Announcement;

    .line 17
    .line 18
    if-eqz p1, :cond_1

    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 21
    .line 22
    invoke-interface {v0, v2}, Lcom/facebook/aura/navigation/AuraNavigator;->currentKey(Z)Lcom/facebook/aura/navigation/AuraNavKey;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    sget-object v0, Lcom/facebook/aura/navigation/key/ConversationTabScreenKey;->INSTANCE:Lcom/facebook/aura/navigation/key/ConversationTabScreenKey;

    .line 27
    .line 28
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_4

    .line 33
    .line 34
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$lifecycleOwner:LX/07p;

    .line 35
    .line 36
    invoke-static {v0}, LX/07p;->A00(LX/07p;)LX/15h;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    sget-object v0, LX/15h;->A05:LX/15h;

    .line 41
    .line 42
    invoke-virtual {v1, v0}, LX/15h;->A00(LX/15h;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$view:Landroid/view/View;

    .line 49
    .line 50
    invoke-virtual {v0}, Landroid/view/View;->hasWindowFocus()Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_2

    .line 55
    .line 56
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 57
    .line 58
    invoke-virtual {v0}, Lcom/facebook/aura/navigation/HatchSidePanelController;->getContentKey()Lcom/facebook/aura/navigation/HatchSidePanelContentKey;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-nez v0, :cond_2

    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$sidePanel:Lcom/facebook/aura/navigation/HatchSidePanelController;

    .line 65
    .line 66
    invoke-virtual {v0}, Lcom/facebook/aura/navigation/HatchSidePanelController;->getOpenDragContentKey()Lcom/facebook/aura/navigation/HatchSidePanelContentKey;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    if-nez v0, :cond_2

    .line 71
    .line 72
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$imeInsets:LX/2uk;

    .line 73
    .line 74
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$density:LX/34Y;

    .line 75
    .line 76
    invoke-interface {v1, v0}, LX/2uk;->AD7(LX/34Y;)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-nez v0, :cond_2

    .line 81
    .line 82
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 83
    .line 84
    invoke-virtual {v0, p1, v2}, Lcom/facebook/aura/announcements/AnnouncementViewModel;->onSheetDue(Lcom/facebook/aura/announcements/repo/Announcement;Z)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_1

    .line 89
    .line 90
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 91
    .line 92
    iget-object v0, p1, Lcom/facebook/aura/announcements/repo/Announcement;->type:Ljava/lang/String;

    .line 93
    .line 94
    new-instance v1, Lcom/facebook/aura/announcements/keys/AnnouncementSheetKey;

    .line 95
    .line 96
    invoke-direct {v1, v0}, Lcom/facebook/aura/announcements/keys/AnnouncementSheetKey;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    const/4 v0, 0x0

    .line 100
    invoke-interface {v2, v1, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 101
    .line 102
    .line 103
    :cond_1
    :goto_1
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 104
    .line 105
    return-object v5

    .line 106
    :cond_2
    const/4 v2, 0x0

    .line 107
    goto :goto_0

    .line 108
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 112
    .line 113
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$context:Landroid/content/Context;

    .line 114
    .line 115
    invoke-static {v0}, Lcom/facebook/aura/utils/HatchNotificationPermissionLauncherKt;->isFirstNotificationPromptPending(Landroid/content/Context;)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    invoke-virtual {v1, v0}, Lcom/facebook/aura/announcements/AnnouncementViewModel;->onForeground(Z)Z

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    if-nez v0, :cond_4

    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_4
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 127
    .line 128
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;

    .line 129
    .line 130
    invoke-direct {v0, v1}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v0}, LX/3Ll;->A01(Lkotlin/jvm/functions/Function0;)LX/EOK;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;

    .line 138
    .line 139
    invoke-direct {v0, v4}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1$2;-><init>(LX/2M4;)V

    .line 140
    .line 141
    .line 142
    iput v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->label:I

    .line 143
    .line 144
    invoke-static {p0, v0, v1}, LX/IxD;->A00(LX/2M4;LX/JDN;LX/2Lw;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    if-ne v0, v5, :cond_6

    .line 149
    .line 150
    return-object v5

    .line 151
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    :cond_6
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 155
    .line 156
    iput v3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$ShowAnnouncementOnForeground$1$1$1;->label:I

    .line 157
    .line 158
    invoke-virtual {v0, p0}, Lcom/facebook/aura/announcements/AnnouncementViewModel;->awaitAnnouncement(LX/2M4;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    if-ne p1, v5, :cond_0

    .line 163
    .line 164
    return-object v5

    .line 165
    :cond_7
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    throw v0
.end method
