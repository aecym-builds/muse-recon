.class public final Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;LX/AHE;Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$userSession:LX/AHE;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$context:Landroid/content/Context;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->emit(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final emit(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1$1;->INSTANCE:Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1$1;

    .line 3
    .line 4
    invoke-interface {v1, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->popAll(LX/JDM;)V

    .line 5
    .line 6
    .line 7
    move-object v1, p1

    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$userSession:LX/AHE;

    .line 11
    .line 12
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$context:Landroid/content/Context;

    .line 13
    .line 14
    iget-object p0, p0, Lcom/facebook/aura/announcements/AnnouncementEffectsKt$AnnouncementActions$1$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    move-object p2, p1

    .line 18
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/conversation/links/HatchUrlClickHandlerKt;->handleUrlClick(LX/AHE;Ljava/lang/String;Landroid/content/Context;Lcom/facebook/aura/navigation/AuraNavigator;LX/JDN;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 22
    .line 23
    return-object v0
.end method
