.class public final Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $sheetState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;->$sheetState$delegate:LX/16A;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;->$sheetState$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;

    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;->isSettled()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    :cond_0
    invoke-static {p0}, LX/001;->A0n(Z)Ljava/lang/Boolean;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
