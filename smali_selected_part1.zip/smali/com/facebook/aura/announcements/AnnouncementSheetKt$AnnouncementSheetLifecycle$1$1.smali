.class public final Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.announcements.AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1"
    f = "AnnouncementSheet.kt"
    l = {
        0x4e
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $sheetState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $type:Ljava/lang/String;

.field public final synthetic $viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Ljava/lang/String;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/announcements/AnnouncementViewModel;",
            "Ljava/lang/String;",
            "LX/16A<",
            "Lcom/facebook/aura/vds/compose/bottomsheet/state/AuraSheetState;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$type:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$sheetState$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$type:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$sheetState$delegate:LX/16A;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;-><init>(Lcom/facebook/aura/announcements/AnnouncementViewModel;Ljava/lang/String;LX/16A;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$viewModel:Lcom/facebook/aura/announcements/AnnouncementViewModel;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$type:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Lcom/facebook/aura/announcements/AnnouncementViewModel;->onSheetShown(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->$sheetState$delegate:LX/16A;

    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$1;-><init>(LX/16A;)V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-static {v0}, LX/3Ll;->A01(Lkotlin/jvm/functions/Function0;)LX/EOK;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    new-instance v0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$2;

    .line 38
    .line 39
    invoke-direct {v0, v2}, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1$2;-><init>(LX/2M4;)V

    .line 40
    .line 41
    .line 42
    iput v3, p0, Lcom/facebook/aura/announcements/AnnouncementSheetKt$AnnouncementSheetLifecycle$1$1;->label:I

    .line 43
    .line 44
    invoke-static {p0, v0, v1}, LX/IxD;->A00(LX/2M4;LX/JDN;LX/2Lw;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    if-ne v0, v4, :cond_0

    .line 49
    .line 50
    return-object v4

    .line 51
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    throw v0
.end method
