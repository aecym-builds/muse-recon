.class public final Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearanceMode;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;->INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearanceMode;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarBackgroundRow$2$1;->invoke(Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearanceMode;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearanceMode;)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 9
    .line 10
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->APPEARANCE:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 11
    .line 12
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AVATAR_BACKGROUND_OPTION:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 13
    .line 14
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->APPEARANCE_MODE:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0}, LX/001;->A0v(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 29
    .line 30
    .line 31
    move-result-object v8

    .line 32
    const/4 v7, 0x0

    .line 33
    move-object p0, v7

    .line 34
    invoke-virtual/range {v2 .. v9}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    sget-object v0, Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;->INSTANCE:Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;->setMode(Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearanceMode;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method
