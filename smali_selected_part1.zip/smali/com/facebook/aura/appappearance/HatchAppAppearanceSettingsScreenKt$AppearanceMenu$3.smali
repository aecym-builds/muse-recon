.class public final Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $expanded:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "TT;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $optionTitleRes:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "TT;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $sections:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "LX/Ddn<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field public final synthetic $selected:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Ddn;Ljava/lang/Enum;LX/JDM;ZLkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "LX/Ddn<",
            "+TT;>;>;TT;",
            "LX/JDM<",
            "-TT;",
            "Ljava/lang/Integer;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-TT;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$sections:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$selected:Ljava/lang/Enum;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$optionTitleRes:LX/JDM;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$expanded:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$onSelect:LX/JDM;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$modifier:LX/3C1;

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$$changed:I

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$$default:I

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$sections:LX/Ddn;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$selected:Ljava/lang/Enum;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$optionTitleRes:LX/JDM;

    .line 5
    .line 6
    iget-boolean v4, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$expanded:Z

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$onDismiss:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$onSelect:LX/JDM;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$modifier:LX/3C1;

    .line 13
    .line 14
    iget v0, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$$changed:I

    .line 15
    .line 16
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 17
    .line 18
    .line 19
    move-result v9

    .line 20
    iget p0, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$3;->$$default:I

    .line 21
    .line 22
    move-object v8, p1

    .line 23
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt;->AppearanceMenu(LX/Ddn;Ljava/lang/Enum;LX/JDM;ZLkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
