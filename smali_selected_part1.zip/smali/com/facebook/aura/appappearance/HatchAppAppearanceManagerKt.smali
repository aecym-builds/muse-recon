.class public abstract Lcom/facebook/aura/appappearance/HatchAppAppearanceManagerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final PREF_FILE:Ljava/lang/String; = "slv_settings"

.field public static final PREF_KEY:Ljava/lang/String; = "slv_app_appearance_settings_key"

.field public static final VALUE_AUTOMATIC:I = -0x1

.field public static final VALUE_DARK:I = 0x2

.field public static final VALUE_LIGHT:I = 0x1
