.class public final Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;->INSTANCE:Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$-826394870$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    invoke-static {p0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    if-eqz p0, :cond_0

    .line 9
    .line 10
    const p0, 0x7f1207c3

    .line 11
    .line 12
    .line 13
    invoke-static {p1, p0}, LX/18b;->A0B(LX/2d4;I)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 18
    .line 19
    .line 20
    return-void
.end method
