.class public final Lcom/facebook/aura/appappearance/AppAppearanceRegistrationImpl;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/appappearance/api/AppAppearanceRegistration;


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/appappearance/AppAppearanceRegistrationImpl;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/AppAppearanceRegistrationImpl;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/AppAppearanceRegistrationImpl;->INSTANCE:Lcom/facebook/aura/appappearance/AppAppearanceRegistrationImpl;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public applySavedAppearance(Landroid/content/Context;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;->INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;->applySavedAppearance(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public setAppearance(Landroid/content/Context;I)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;->INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/appappearance/HatchAppAppearanceManager;->setAppearance(Landroid/content/Context;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
