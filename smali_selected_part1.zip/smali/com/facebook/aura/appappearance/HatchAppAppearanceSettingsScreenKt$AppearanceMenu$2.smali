.class public final Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $checkmark:LX/2l9;

.field public final synthetic $optionTitleRes:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "TT;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $sections:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "LX/Ddn<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field public final synthetic $selected:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Ddn;LX/JDM;Ljava/lang/Enum;LX/2l9;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "LX/Ddn<",
            "+TT;>;>;",
            "LX/JDM<",
            "-TT;",
            "Ljava/lang/Integer;",
            ">;TT;",
            "LX/2l9;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$sections:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$optionTitleRes:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$selected:Ljava/lang/Enum;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$checkmark:LX/2l9;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/Ddn;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, -0x3f093e69

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 6
    .line 7
    .line 8
    move-object/from16 v0, p0

    .line 9
    .line 10
    iget-object v6, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$sections:LX/Ddn;

    .line 11
    .line 12
    iget-object v4, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$optionTitleRes:LX/JDM;

    .line 13
    .line 14
    iget-object v3, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$selected:Ljava/lang/Enum;

    .line 15
    .line 16
    iget-object v5, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->$checkmark:LX/2l9;

    .line 17
    .line 18
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const v2, 0x5e4cbf41

    .line 23
    .line 24
    .line 25
    invoke-static {v1, v6, v2}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object v10

    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v7, 0x0

    .line 31
    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v6

    .line 35
    if-eqz v6, :cond_4

    .line 36
    .line 37
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v6

    .line 41
    add-int/lit8 v9, v7, 0x1

    .line 42
    .line 43
    if-gez v7, :cond_0

    .line 44
    .line 45
    invoke-static {}, LX/B8B;->A1A()V

    .line 46
    .line 47
    .line 48
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    throw v0

    .line 53
    :cond_0
    check-cast v6, Ljava/util/List;

    .line 54
    .line 55
    if-lez v7, :cond_1

    .line 56
    .line 57
    const/4 v14, 0x0

    .line 58
    const-string v13, ""

    .line 59
    .line 60
    const/4 v12, -0x1

    .line 61
    const/16 v19, 0x1

    .line 62
    .line 63
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    new-instance v11, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 66
    .line 67
    move-object v15, v14

    .line 68
    move-object/from16 v16, v14

    .line 69
    .line 70
    move-object/from16 v17, v14

    .line 71
    .line 72
    move/from16 v18, v2

    .line 73
    .line 74
    move/from16 v20, v2

    .line 75
    .line 76
    move/from16 v21, v19

    .line 77
    .line 78
    move/from16 v22, v2

    .line 79
    .line 80
    move/from16 p1, v19

    .line 81
    .line 82
    move/from16 p2, v19

    .line 83
    .line 84
    invoke-direct/range {v11 .. v25}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0, v11}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    :cond_1
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 91
    .line 92
    .line 93
    move-result-object v8

    .line 94
    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 95
    .line 96
    .line 97
    move-result v6

    .line 98
    if-eqz v6, :cond_3

    .line 99
    .line 100
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v7

    .line 104
    check-cast v7, Ljava/lang/Enum;

    .line 105
    .line 106
    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    .line 107
    .line 108
    .line 109
    move-result v12

    .line 110
    invoke-interface {v4, v7}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    invoke-static {v6}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 115
    .line 116
    .line 117
    move-result v6

    .line 118
    invoke-static {v1, v6}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v13

    .line 122
    invoke-virtual {v7, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v18

    .line 126
    move-object/from16 v17, v5

    .line 127
    .line 128
    if-nez v18, :cond_2

    .line 129
    .line 130
    const/16 v17, 0x0

    .line 131
    .line 132
    :cond_2
    const/4 v14, 0x0

    .line 133
    const/16 v21, 0x1

    .line 134
    .line 135
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 136
    .line 137
    new-instance v11, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 138
    .line 139
    move-object v15, v14

    .line 140
    move-object/from16 v16, v14

    .line 141
    .line 142
    move/from16 v19, v2

    .line 143
    .line 144
    move/from16 v20, v2

    .line 145
    .line 146
    move/from16 v22, v2

    .line 147
    .line 148
    move/from16 p1, v21

    .line 149
    .line 150
    move/from16 p2, v21

    .line 151
    .line 152
    invoke-direct/range {v11 .. v25}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v0, v11}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    goto :goto_1

    .line 159
    :cond_3
    move v7, v9

    .line 160
    goto/16 :goto_0

    .line 161
    .line 162
    :cond_4
    invoke-static {v1}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    invoke-static {v0}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-static {v1, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 175
    .line 176
    .line 177
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenu$2;->invoke(LX/2d4;I)LX/Ddn;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
