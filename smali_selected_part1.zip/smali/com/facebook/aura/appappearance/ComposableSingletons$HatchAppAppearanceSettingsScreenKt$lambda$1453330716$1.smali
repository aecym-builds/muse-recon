.class public final Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;->INSTANCE:Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt$lambda$1453330716$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 1

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 p0, 0x0

    .line 12
    const/4 v0, 0x1

    .line 13
    invoke-static {p1, p2, p0, v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt;->AvatarBackgroundRow(LX/3C1;LX/2d4;II)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 18
    .line 19
    .line 20
    return-void
.end method
