.class public final Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/ui/HatchSectionScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;->INSTANCE:Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/ui/HatchSectionScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AvatarAppearanceSection$1$1$1;->invoke(Lcom/facebook/aura/ui/HatchSectionScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/ui/HatchSectionScope;)V
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object p0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt;->lambda$861209239:LX/JDQ;

    .line 5
    .line 6
    invoke-interface {p1, p0}, Lcom/facebook/aura/ui/HatchSectionScope;->item(LX/JDQ;)V

    .line 7
    .line 8
    .line 9
    sget-object p0, Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;->INSTANCE:Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;

    .line 10
    .line 11
    invoke-virtual {p0}, Lcom/facebook/aura/avatarassets/api/HatchAvatarAppearance;->isDarkAvatarEnabled()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    sget-object p0, Lcom/facebook/aura/appappearance/ComposableSingletons$HatchAppAppearanceSettingsScreenKt;->lambda$1453330716:LX/JDQ;

    .line 18
    .line 19
    invoke-interface {p1, p0}, Lcom/facebook/aura/ui/HatchSectionScope;->item(LX/JDQ;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method
