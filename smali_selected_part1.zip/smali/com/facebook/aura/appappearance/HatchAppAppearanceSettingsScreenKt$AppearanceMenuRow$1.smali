.class public final Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Zv;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $expanded$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "TT;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $optionTitleRes:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "TT;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $sections:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "LX/Ddn<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field public final synthetic $selected:Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Ddn;Ljava/lang/Enum;LX/JDM;LX/JDM;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "LX/Ddn<",
            "+TT;>;>;TT;",
            "LX/JDM<",
            "-TT;",
            "Ljava/lang/Integer;",
            ">;",
            "LX/JDM<",
            "-TT;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$sections:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$selected:Ljava/lang/Enum;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$optionTitleRes:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$onSelect:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$expanded$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    const/4 v0, 0x3

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/1Zv;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->invoke(LX/1Zv;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/1Zv;LX/2d4;I)V
    .locals 22

    .line 0
    const/4 v9, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v2, p3

    .line 4
    .line 5
    invoke-static {v0, v9, v2}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object/from16 v1, p2

    .line 10
    .line 11
    invoke-static {v0, v1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    move-object/from16 v0, p0

    .line 18
    .line 19
    iget-object v10, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$sections:LX/Ddn;

    .line 20
    .line 21
    iget-object v11, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$selected:Ljava/lang/Enum;

    .line 22
    .line 23
    iget-object v12, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$optionTitleRes:LX/JDM;

    .line 24
    .line 25
    iget-object v15, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$onSelect:LX/JDM;

    .line 26
    .line 27
    iget-object v4, v0, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1;->$expanded$delegate:Landroidx/compose/runtime/MutableState;

    .line 28
    .line 29
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 30
    .line 31
    invoke-static {v9}, LX/001;->A0g(Z)LX/3BI;

    .line 32
    .line 33
    .line 34
    move-result-object v8

    .line 35
    move-object v0, v1

    .line 36
    check-cast v0, LX/J7I;

    .line 37
    .line 38
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 43
    .line 44
    .line 45
    move-result-object v6

    .line 46
    invoke-static {v1, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    sget-object v3, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 51
    .line 52
    iget-object v2, v0, LX/J7I;->A0V:LX/3DJ;

    .line 53
    .line 54
    if-nez v2, :cond_0

    .line 55
    .line 56
    invoke-static {}, LX/1VY;->A00()V

    .line 57
    .line 58
    .line 59
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    throw v0

    .line 64
    :cond_0
    invoke-static {v1, v0, v3}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 65
    .line 66
    .line 67
    invoke-static {v1, v8, v6, v5, v7}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 68
    .line 69
    .line 70
    const v2, 0x7f0800e9

    .line 71
    .line 72
    .line 73
    invoke-static {v1, v2, v9}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 74
    .line 75
    .line 76
    move-result-object v17

    .line 77
    sget-object v18, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 78
    .line 79
    invoke-static {v1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    iget-object v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 84
    .line 85
    iget-wide v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 86
    .line 87
    invoke-static {}, LX/2l9;->A04()I

    .line 88
    .line 89
    .line 90
    move-result p2

    .line 91
    const/16 p3, 0x21

    .line 92
    .line 93
    const/16 v16, 0x0

    .line 94
    .line 95
    move-object/from16 v19, v16

    .line 96
    .line 97
    move-wide/from16 v20, v2

    .line 98
    .line 99
    move-object/from16 p0, v16

    .line 100
    .line 101
    move-object/from16 p1, v1

    .line 102
    .line 103
    invoke-static/range {v16 .. v25}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 104
    .line 105
    .line 106
    invoke-static {v4}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 107
    .line 108
    .line 109
    move-result v13

    .line 110
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v14

    .line 114
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 115
    .line 116
    if-ne v14, v2, :cond_1

    .line 117
    .line 118
    new-instance v14, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1$1$1$1;

    .line 119
    .line 120
    invoke-direct {v14, v4}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt$AppearanceMenuRow$1$1$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 121
    .line 122
    .line 123
    invoke-interface {v1, v14}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_1
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 127
    .line 128
    const/16 v18, 0x6000

    .line 129
    .line 130
    const/16 v19, 0x40

    .line 131
    .line 132
    move-object/from16 v17, v1

    .line 133
    .line 134
    invoke-static/range {v10 .. v19}, Lcom/facebook/aura/appappearance/HatchAppAppearanceSettingsScreenKt;->AppearanceMenu(LX/Ddn;Ljava/lang/Enum;LX/JDM;ZLkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 135
    .line 136
    .line 137
    const/4 v1, 0x1

    .line 138
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :cond_2
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 143
    .line 144
    .line 145
    return-void
.end method
