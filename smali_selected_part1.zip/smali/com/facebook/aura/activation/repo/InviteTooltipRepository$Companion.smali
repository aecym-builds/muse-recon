.class public final Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/InviteTooltipRepository;
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;

    .line 5
    .line 6
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;-><init>(LX/AHE;)V

    .line 7
    .line 8
    .line 9
    const-class v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 10
    .line 11
    invoke-virtual {p1, v0, p0}, LX/0HF;->A03(Ljava/lang/Class;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 16
    .line 17
    return-object v0
.end method
