.class public final Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/facebook/aura/activation/repo/InviteTooltipRepository;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Lcom/facebook/aura/activation/repo/InviteTooltipRepository;
    .locals 1

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;->$userSession:LX/AHE;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 3
    .line 4
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;-><init>(LX/AHE;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 268435456
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository$Companion$getInstance$1;->$userSession:LX/AHE;

    .line 268435457
    .line 268435458
    new-instance v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 268435459
    .line 268435460
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;-><init>(LX/AHE;)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object v0
.end method
