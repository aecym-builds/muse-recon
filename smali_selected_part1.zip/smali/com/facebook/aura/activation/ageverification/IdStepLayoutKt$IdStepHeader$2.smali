.class public final Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $body:Ljava/lang/String;

.field public final synthetic $link:Ljava/lang/String;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $title:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$body:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$modifier:LX/3C1;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$link:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$onLinkClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$$changed:I

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$$default:I

    .line 13
    .line 14
    const/4 v0, 0x2

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 8

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$body:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$modifier:LX/3C1;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$link:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$onLinkClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$$changed:I

    .line 11
    .line 12
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 13
    .line 14
    .line 15
    move-result v7

    .line 16
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;->$$default:I

    .line 17
    .line 18
    move-object v6, p1

    .line 19
    invoke-static/range {v1 .. v8}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
