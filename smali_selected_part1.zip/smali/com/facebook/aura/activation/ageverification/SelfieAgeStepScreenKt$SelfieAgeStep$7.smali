.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $current:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

.field public final synthetic $picked:Z

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Z)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$current:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$picked:Z

    .line 5
    .line 6
    const/4 v0, 0x4

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 6

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move-object v5, p3

    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    invoke-static {p3, p1}, LX/004;->A09(LX/2d4;F)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    or-int v1, p4, v0

    .line 10
    .line 11
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-static {p3, p2}, LX/004;->A0A(LX/2d4;F)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    or-int/2addr v1, v0

    .line 20
    :cond_0
    invoke-static {v1}, LX/005;->A1I(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0, p3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$current:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 31
    .line 32
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 33
    .line 34
    iget-boolean v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;->$picked:Z

    .line 35
    .line 36
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 37
    .line 38
    invoke-static {v0, p1, p2}, LX/2pj;->A08(LX/3C1;FF)LX/3C1;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    sget v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->$stable:I

    .line 43
    .line 44
    shl-int/lit8 p0, v0, 0x3

    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->SelfieAgeStepContent(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_1
    move v1, p4

    .line 52
    goto :goto_0

    .line 53
    :cond_2
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    return-void
.end method
