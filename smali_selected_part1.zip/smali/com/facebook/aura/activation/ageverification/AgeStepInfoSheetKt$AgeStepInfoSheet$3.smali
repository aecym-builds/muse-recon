.class public final Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $info:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/AgeStepInfo;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;->$info:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 2

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;->$info:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->getRows()Ljava/util/List;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 31
    .line 32
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 33
    .line 34
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 35
    .line 36
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const/4 v0, 0x0

    .line 41
    invoke-static {p0, v1, p2, v0, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt;->AgeStepInfoRowContent(Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;LX/3C1;LX/2d4;II)V

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 46
    .line 47
    .line 48
    :cond_1
    return-void
.end method
