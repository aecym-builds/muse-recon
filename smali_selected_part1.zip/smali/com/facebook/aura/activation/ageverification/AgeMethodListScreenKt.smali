.class public abstract Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final AGE_METHODS_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public static final LEARN_MORE_LINK_TAG:Ljava/lang/String; = "learn_more"

.field public static final ROW_ICON_SIZE:F = 24.0f


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_METHODS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AGE_METHODS_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 3
    .line 4
    return-void
.end method

.method public static final AgeMethodAccounts(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 36
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p3

    .line 1
    .line 2
    const v0, -0x2e5e3ece

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p4

    .line 6
    .line 7
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 v15, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v15, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, LX/003;->A06(I)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    or-int v6, v6, p5

    .line 27
    .line 28
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 29
    .line 30
    move-object/from16 v35, p1

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static/range {v35 .. v35}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v4, v0}, LX/004;->A0F(LX/2d4;I)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v6, v0

    .line 43
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 44
    .line 45
    move-object/from16 v8, p2

    .line 46
    .line 47
    if-nez v0, :cond_1

    .line 48
    .line 49
    invoke-static {v4, v8}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    or-int/2addr v6, v0

    .line 54
    :cond_1
    and-int/lit8 v9, p6, 0x8

    .line 55
    .line 56
    if-eqz v9, :cond_4

    .line 57
    .line 58
    or-int/lit16 v6, v6, 0xc00

    .line 59
    .line 60
    :cond_2
    :goto_1
    and-int/lit16 v1, v6, 0x493

    .line 61
    .line 62
    const/16 v0, 0x492

    .line 63
    .line 64
    const/4 v7, 0x0

    .line 65
    const/4 v2, 0x1

    .line 66
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    invoke-static {v0, v4, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_9

    .line 75
    .line 76
    if-eqz v9, :cond_3

    .line 77
    .line 78
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 79
    .line 80
    :cond_3
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 81
    .line 82
    invoke-interface {v5, v1}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v9

    .line 86
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 87
    .line 88
    invoke-static {v4, v0, v7}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 89
    .line 90
    .line 91
    move-result-object v14

    .line 92
    move-object v0, v4

    .line 93
    check-cast v0, LX/J7I;

    .line 94
    .line 95
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 96
    .line 97
    .line 98
    move-result v13

    .line 99
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 100
    .line 101
    .line 102
    move-result-object v12

    .line 103
    invoke-static {v4, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 104
    .line 105
    .line 106
    move-result-object v11

    .line 107
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 108
    .line 109
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 110
    .line 111
    if-nez v9, :cond_6

    .line 112
    .line 113
    invoke-static {}, LX/1VY;->A00()V

    .line 114
    .line 115
    .line 116
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    throw v0

    .line 121
    :cond_4
    and-int/lit16 v0, v3, 0xc00

    .line 122
    .line 123
    if-nez v0, :cond_2

    .line 124
    .line 125
    invoke-static {v4, v5}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    or-int/2addr v6, v0

    .line 130
    goto :goto_1

    .line 131
    :cond_5
    move v6, v3

    .line 132
    goto :goto_0

    .line 133
    :cond_6
    invoke-static {v4, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v4, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 137
    .line 138
    .line 139
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 140
    .line 141
    .line 142
    move-result v9

    .line 143
    if-le v9, v2, :cond_8

    .line 144
    .line 145
    const v11, 0x7f12007b

    .line 146
    .line 147
    .line 148
    :cond_7
    :goto_2
    invoke-static {v4, v11}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v16

    .line 152
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 153
    .line 154
    invoke-static {v4, v9}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 155
    .line 156
    .line 157
    move-result-object v20

    .line 158
    invoke-static {v4, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 159
    .line 160
    .line 161
    move-result-wide v18

    .line 162
    invoke-static {}, LX/2wS;->A00()LX/2wS;

    .line 163
    .line 164
    .line 165
    move-result-object v23

    .line 166
    const/16 v34, 0x3fb0

    .line 167
    .line 168
    const/16 v21, 0x0

    .line 169
    .line 170
    const/16 v32, 0x30

    .line 171
    .line 172
    move-object/from16 v22, v21

    .line 173
    .line 174
    move/from16 v24, v7

    .line 175
    .line 176
    move/from16 v25, v7

    .line 177
    .line 178
    move/from16 v26, v7

    .line 179
    .line 180
    move/from16 v27, v7

    .line 181
    .line 182
    move-object/from16 v28, v21

    .line 183
    .line 184
    move-object/from16 v29, v21

    .line 185
    .line 186
    move-object/from16 v30, v21

    .line 187
    .line 188
    move-object/from16 v31, v4

    .line 189
    .line 190
    move/from16 v33, v7

    .line 191
    .line 192
    move-object/from16 v17, v1

    .line 193
    .line 194
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 195
    .line 196
    .line 197
    and-int/lit16 v1, v6, 0x3fe

    .line 198
    .line 199
    const/16 p4, 0x8

    .line 200
    .line 201
    move-object/from16 v34, v15

    .line 202
    .line 203
    move-object/from16 p0, v8

    .line 204
    .line 205
    move-object/from16 p1, v21

    .line 206
    .line 207
    move-object/from16 p2, v4

    .line 208
    .line 209
    move/from16 p3, v1

    .line 210
    .line 211
    invoke-static/range {v34 .. v40}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodRows(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 212
    .line 213
    .line 214
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 215
    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_8
    invoke-static {v15}, LX/B89;->A0X(Ljava/util/List;)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v10

    .line 222
    sget-object v9, Lcom/facebook/aura/user/provider/AgeCheckMethod;->INSTAGRAM:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 223
    .line 224
    const v11, 0x7f12007c

    .line 225
    .line 226
    .line 227
    if-ne v10, v9, :cond_7

    .line 228
    .line 229
    const v11, 0x7f12007d

    .line 230
    .line 231
    .line 232
    goto :goto_2

    .line 233
    :cond_9
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 234
    .line 235
    .line 236
    :goto_3
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    if-eqz v1, :cond_a

    .line 241
    .line 242
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodAccounts$2;

    .line 243
    .line 244
    move-object/from16 p0, v0

    .line 245
    .line 246
    move-object/from16 p1, v15

    .line 247
    .line 248
    move-object/from16 p3, v8

    .line 249
    .line 250
    move-object/from16 p4, v5

    .line 251
    .line 252
    move-object/from16 p2, v35

    .line 253
    .line 254
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodAccounts$2;-><init>(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;II)V

    .line 255
    .line 256
    .line 257
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 258
    .line 259
    :cond_a
    return-void
.end method

.method public static final AgeMethodIcon(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/3C1;LX/2d4;II)V
    .locals 12

    .line 0
    move-object v7, p2

    .line 1
    const v0, -0x13093e9b

    .line 2
    .line 3
    .line 4
    move-object p2, p3

    .line 5
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v1, p4

    .line 9
    .line 10
    and-int/lit8 v0, p4, 0x6

    .line 11
    .line 12
    move-object v2, p0

    .line 13
    if-nez v0, :cond_6

    .line 14
    .line 15
    invoke-static {p3, p0}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    or-int v3, v3, p4

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 22
    .line 23
    move-object v9, p1

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    invoke-static {p3, p1}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    or-int/2addr v3, v0

    .line 31
    :cond_0
    and-int/lit8 v6, p5, 0x4

    .line 32
    .line 33
    if-eqz v6, :cond_5

    .line 34
    .line 35
    or-int/lit16 v3, v3, 0x180

    .line 36
    .line 37
    :cond_1
    :goto_1
    and-int/lit16 v5, v3, 0x93

    .line 38
    .line 39
    const/16 v0, 0x92

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-static {v0, p3, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_4

    .line 51
    .line 52
    if-eqz v6, :cond_2

    .line 53
    .line 54
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    :cond_2
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->getIconRes(Lcom/facebook/aura/user/provider/AgeCheckMethod;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    invoke-static {p3, v0, v4}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 61
    .line 62
    .line 63
    move-result-object v8

    .line 64
    invoke-static {p3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 69
    .line 70
    iget-wide v11, v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 71
    .line 72
    shr-int/lit8 v0, v3, 0x6

    .line 73
    .line 74
    and-int/lit8 p3, v0, 0xe

    .line 75
    .line 76
    sget v0, LX/2l9;->$stable:I

    .line 77
    .line 78
    shl-int/lit8 v0, v0, 0x3

    .line 79
    .line 80
    or-int/2addr p3, v0

    .line 81
    shl-int/lit8 v0, v3, 0x3

    .line 82
    .line 83
    and-int/lit16 v0, v0, 0x380

    .line 84
    .line 85
    or-int/2addr p3, v0

    .line 86
    const/16 p4, 0x28

    .line 87
    .line 88
    const/4 v10, 0x0

    .line 89
    move-object p1, v10

    .line 90
    invoke-static/range {v7 .. v16}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 91
    .line 92
    .line 93
    :goto_2
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    if-eqz v0, :cond_3

    .line 98
    .line 99
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodIcon$1;

    .line 100
    .line 101
    move-object p2, v9

    .line 102
    move-object p3, v7

    .line 103
    move/from16 p4, v1

    .line 104
    .line 105
    move-object p1, v2

    .line 106
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodIcon$1;-><init>(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/3C1;II)V

    .line 107
    .line 108
    .line 109
    iput-object p0, v0, LX/J7V;->A06:LX/JDN;

    .line 110
    .line 111
    :cond_3
    return-void

    .line 112
    :cond_4
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 113
    .line 114
    .line 115
    goto :goto_2

    .line 116
    :cond_5
    and-int/lit16 v0, v1, 0x180

    .line 117
    .line 118
    if-nez v0, :cond_1

    .line 119
    .line 120
    invoke-static {p3, v7}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    or-int/2addr v3, v0

    .line 125
    goto :goto_1

    .line 126
    :cond_6
    move v3, v1

    .line 127
    goto :goto_0
.end method

.method public static final AgeMethodListHeader(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 41
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v22, p1

    .line 1
    .line 2
    const v1, 0x65cc77ba

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p2

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v15, p3

    .line 11
    .line 12
    and-int/lit8 v1, p3, 0x6

    .line 13
    .line 14
    move-object/from16 p3, p0

    .line 15
    .line 16
    if-nez v1, :cond_5

    .line 17
    .line 18
    move-object/from16 v1, p3

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v7

    .line 24
    or-int/2addr v7, v15

    .line 25
    :goto_0
    move/from16 v21, p4

    .line 26
    .line 27
    and-int/lit8 v3, p4, 0x2

    .line 28
    .line 29
    if-eqz v3, :cond_4

    .line 30
    .line 31
    or-int/lit8 v7, v7, 0x30

    .line 32
    .line 33
    :cond_0
    :goto_1
    and-int/lit8 v2, v7, 0x13

    .line 34
    .line 35
    const/16 v1, 0x12

    .line 36
    .line 37
    const/4 v14, 0x1

    .line 38
    const/16 v20, 0x0

    .line 39
    .line 40
    invoke-static {v2, v1}, LX/003;->A1H(II)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    invoke-static {v1, v0, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_6

    .line 49
    .line 50
    if-eqz v3, :cond_1

    .line 51
    .line 52
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 53
    .line 54
    :cond_1
    const v1, 0x7f1204c4

    .line 55
    .line 56
    .line 57
    invoke-static {v0, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 62
    .line 63
    invoke-static {v0, v2}, LX/07H;->A07(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 64
    .line 65
    .line 66
    move-result-wide v4

    .line 67
    invoke-interface {v0, v6}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-static {v0, v4, v5, v1}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    invoke-static {v7}, LX/008;->A1X(I)Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    or-int/2addr v1, v3

    .line 80
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    if-nez v1, :cond_2

    .line 85
    .line 86
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 87
    .line 88
    if-ne v3, v1, :cond_3

    .line 89
    .line 90
    :cond_2
    const-string v10, "learn_more"

    .line 91
    .line 92
    move-object v7, v6

    .line 93
    move-wide v8, v4

    .line 94
    move-object/from16 v11, p3

    .line 95
    .line 96
    invoke-static/range {v6 .. v11}, Lcom/facebook/aura/linktext/HatchInlineLinkTextKt;->buildInlineLinkText-XO-JAsU(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Lkotlin/jvm/functions/Function0;)LX/2iK;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :cond_3
    check-cast v3, LX/2iK;

    .line 104
    .line 105
    const/16 v19, 0x0

    .line 106
    .line 107
    invoke-static/range {v22 .. v22}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 108
    .line 109
    .line 110
    move-result-object v7

    .line 111
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 112
    .line 113
    invoke-static {v11}, LX/Dn6;->A00(F)LX/CP5;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    sget-object v10, LX/2Id;->A00:LX/2sS;

    .line 118
    .line 119
    const/16 v9, 0x30

    .line 120
    .line 121
    invoke-static {v1, v0, v10, v9}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    move-object v1, v0

    .line 126
    check-cast v1, LX/J7I;

    .line 127
    .line 128
    iget-wide v4, v1, LX/J7I;->A06:J

    .line 129
    .line 130
    invoke-static {v4, v5}, LX/001;->A0A(J)I

    .line 131
    .line 132
    .line 133
    move-result v12

    .line 134
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 135
    .line 136
    .line 137
    move-result-object v5

    .line 138
    invoke-static {v0, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 139
    .line 140
    .line 141
    move-result-object v4

    .line 142
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 143
    .line 144
    iget-object v7, v1, LX/J7I;->A0V:LX/3DJ;

    .line 145
    .line 146
    if-nez v7, :cond_7

    .line 147
    .line 148
    invoke-static {}, LX/1VY;->A00()V

    .line 149
    .line 150
    .line 151
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    throw v0

    .line 156
    :cond_4
    and-int/lit8 v1, v15, 0x30

    .line 157
    .line 158
    if-nez v1, :cond_0

    .line 159
    .line 160
    move-object/from16 v1, v22

    .line 161
    .line 162
    invoke-static {v0, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    or-int/2addr v7, v1

    .line 167
    goto/16 :goto_1

    .line 168
    .line 169
    :cond_5
    move v7, v15

    .line 170
    goto/16 :goto_0

    .line 171
    .line 172
    :cond_6
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 173
    .line 174
    .line 175
    goto/16 :goto_2

    .line 176
    .line 177
    :cond_7
    invoke-static {v0, v1, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 178
    .line 179
    .line 180
    sget-object v7, LX/3Cl;->A04:LX/JDN;

    .line 181
    .line 182
    invoke-static {v0, v6, v7}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 183
    .line 184
    .line 185
    move-result-object v6

    .line 186
    invoke-static {v0, v5, v6, v12}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 187
    .line 188
    .line 189
    move-result-object v18

    .line 190
    sget-object v5, LX/3Cl;->A02:LX/JDM;

    .line 191
    .line 192
    invoke-static {v0, v4, v5}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 193
    .line 194
    .line 195
    move-result-object v17

    .line 196
    move-object/from16 v12, v19

    .line 197
    .line 198
    move/from16 v4, v20

    .line 199
    .line 200
    invoke-static {v12, v0, v4, v14}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt;->AgeStepLogo(LX/3C1;LX/2d4;II)V

    .line 201
    .line 202
    .line 203
    const v4, 0x7f120083

    .line 204
    .line 205
    .line 206
    invoke-static {v0, v4}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v23

    .line 210
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 211
    .line 212
    invoke-static {v4, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v4

    .line 216
    check-cast v4, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 217
    .line 218
    iget-object v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Medium:LX/2hg;

    .line 219
    .line 220
    move-object/from16 v27, v4

    .line 221
    .line 222
    invoke-static {v0, v2}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 223
    .line 224
    .line 225
    move-result-wide v25

    .line 226
    const/16 v16, 0x3

    .line 227
    .line 228
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 229
    .line 230
    invoke-static {v4, v11}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 231
    .line 232
    .line 233
    move-result-object v13

    .line 234
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v12

    .line 238
    sget-object v11, LX/2d6;->A00:Ljava/lang/Object;

    .line 239
    .line 240
    if-ne v12, v11, :cond_8

    .line 241
    .line 242
    sget-object v12, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListHeader$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListHeader$1$1$1;

    .line 243
    .line 244
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_8
    move/from16 v11, v20

    .line 248
    .line 249
    invoke-static {v13, v12, v11}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 250
    .line 251
    .line 252
    move-result-object v24

    .line 253
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 254
    .line 255
    .line 256
    move-result-object v30

    .line 257
    const/16 p0, 0x3fb0

    .line 258
    .line 259
    move-object/from16 v28, v19

    .line 260
    .line 261
    move-object/from16 v29, v19

    .line 262
    .line 263
    move/from16 v31, v11

    .line 264
    .line 265
    move/from16 v32, v11

    .line 266
    .line 267
    move/from16 v33, v11

    .line 268
    .line 269
    move/from16 v34, v11

    .line 270
    .line 271
    move-object/from16 v35, v19

    .line 272
    .line 273
    move-object/from16 v36, v19

    .line 274
    .line 275
    move-object/from16 v37, v19

    .line 276
    .line 277
    move-object/from16 v38, v0

    .line 278
    .line 279
    move/from16 v39, v11

    .line 280
    .line 281
    move/from16 v40, v11

    .line 282
    .line 283
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 284
    .line 285
    .line 286
    sget-object v11, LX/Dn6;->A06:LX/Dps;

    .line 287
    .line 288
    invoke-static {v11, v0, v10, v9}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 289
    .line 290
    .line 291
    move-result-object v12

    .line 292
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 293
    .line 294
    .line 295
    move-result v11

    .line 296
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 297
    .line 298
    .line 299
    move-result-object v10

    .line 300
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 301
    .line 302
    .line 303
    move-result-object v9

    .line 304
    invoke-static {v0, v1, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 305
    .line 306
    .line 307
    invoke-static {v0, v12, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 308
    .line 309
    .line 310
    invoke-static {v0, v10, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 311
    .line 312
    .line 313
    move-object/from16 v4, v18

    .line 314
    .line 315
    invoke-static {v5, v4, v0, v11}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 316
    .line 317
    .line 318
    move-object/from16 v4, v17

    .line 319
    .line 320
    invoke-static {v0, v9, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 321
    .line 322
    .line 323
    const v4, 0x7f120082

    .line 324
    .line 325
    .line 326
    invoke-static {v0, v4}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object v23

    .line 330
    invoke-static {v0, v2}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 331
    .line 332
    .line 333
    move-result-object v27

    .line 334
    invoke-static {v0, v2}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 335
    .line 336
    .line 337
    move-result-wide v25

    .line 338
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 339
    .line 340
    .line 341
    move-result-object v30

    .line 342
    const/16 p0, 0x3fb2

    .line 343
    .line 344
    move-object/from16 v24, v19

    .line 345
    .line 346
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 347
    .line 348
    .line 349
    invoke-static {v0, v2}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 350
    .line 351
    .line 352
    move-result-object v27

    .line 353
    invoke-static/range {v16 .. v16}, LX/2wS;->A01(I)LX/2wS;

    .line 354
    .line 355
    .line 356
    move-result-object v30

    .line 357
    const/16 p2, 0x7fb6

    .line 358
    .line 359
    const-wide/16 v25, 0x0

    .line 360
    .line 361
    move-object/from16 v23, v3

    .line 362
    .line 363
    move-wide/from16 v31, v25

    .line 364
    .line 365
    move/from16 v35, v20

    .line 366
    .line 367
    move/from16 v36, v20

    .line 368
    .line 369
    move-object/from16 v38, v19

    .line 370
    .line 371
    move-object/from16 v39, v19

    .line 372
    .line 373
    move-object/from16 v40, v0

    .line 374
    .line 375
    move/from16 p0, v20

    .line 376
    .line 377
    move/from16 p1, v20

    .line 378
    .line 379
    invoke-static/range {v23 .. v43}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 380
    .line 381
    .line 382
    invoke-static {v1, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 383
    .line 384
    .line 385
    invoke-static {v1, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 386
    .line 387
    .line 388
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 389
    .line 390
    .line 391
    move-result-object v4

    .line 392
    if-eqz v4, :cond_9

    .line 393
    .line 394
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListHeader$2;

    .line 395
    .line 396
    move-object/from16 v2, p3

    .line 397
    .line 398
    move-object/from16 v1, v22

    .line 399
    .line 400
    move/from16 v0, v21

    .line 401
    .line 402
    invoke-direct {v3, v2, v1, v15, v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListHeader$2;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 403
    .line 404
    .line 405
    iput-object v3, v4, LX/J7V;->A06:LX/JDN;

    .line 406
    .line 407
    :cond_9
    return-void
.end method

.method public static final AgeMethodListScreen(LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 55
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p8

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    move-object/from16 v6, p0

    .line 4
    .line 5
    invoke-static {v6, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const/4 v14, 0x1

    .line 9
    move-object/from16 v5, p1

    .line 10
    .line 11
    move-object/from16 p1, p3

    .line 12
    .line 13
    move-object/from16 v0, p1

    .line 14
    .line 15
    invoke-static {v5, v14, v0}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    const/4 v2, 0x4

    .line 19
    move-object/from16 p3, p4

    .line 20
    .line 21
    move-object/from16 v0, p3

    .line 22
    .line 23
    invoke-static {v0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 24
    .line 25
    .line 26
    const/4 v0, 0x6

    .line 27
    move-object/from16 v8, p6

    .line 28
    .line 29
    move-object/from16 v4, p7

    .line 30
    .line 31
    invoke-static {v8, v0, v4}, LX/003;->A12(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    const v0, -0x4ac8e237

    .line 35
    .line 36
    .line 37
    move-object/from16 v3, p9

    .line 38
    .line 39
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 40
    .line 41
    .line 42
    move/from16 v2, p10

    .line 43
    .line 44
    and-int/lit8 v0, p10, 0x6

    .line 45
    .line 46
    if-nez v0, :cond_12

    .line 47
    .line 48
    invoke-static {v3, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v9

    .line 52
    or-int v9, v9, p10

    .line 53
    .line 54
    :goto_0
    and-int/lit8 v0, p10, 0x30

    .line 55
    .line 56
    if-nez v0, :cond_0

    .line 57
    .line 58
    invoke-static {v3, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    or-int/2addr v9, v0

    .line 63
    :cond_0
    and-int/lit16 v0, v2, 0x180

    .line 64
    .line 65
    move-object/from16 v54, p2

    .line 66
    .line 67
    if-nez v0, :cond_1

    .line 68
    .line 69
    invoke-static/range {v54 .. v54}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-static {v3, v0}, LX/004;->A0G(LX/2d4;I)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    or-int/2addr v9, v0

    .line 78
    :cond_1
    and-int/lit16 v0, v2, 0xc00

    .line 79
    .line 80
    if-nez v0, :cond_2

    .line 81
    .line 82
    move-object/from16 v0, p1

    .line 83
    .line 84
    invoke-static {v3, v0}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    or-int/2addr v9, v0

    .line 89
    :cond_2
    and-int/lit16 v0, v2, 0x6000

    .line 90
    .line 91
    if-nez v0, :cond_3

    .line 92
    .line 93
    move-object/from16 v0, p3

    .line 94
    .line 95
    invoke-static {v3, v0}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    or-int/2addr v9, v0

    .line 100
    :cond_3
    const/high16 v0, 0x30000

    .line 101
    .line 102
    and-int v0, v0, p10

    .line 103
    .line 104
    move/from16 v15, p5

    .line 105
    .line 106
    if-nez v0, :cond_4

    .line 107
    .line 108
    invoke-static {v3, v15}, LX/004;->A0n(LX/2d4;Z)I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    or-int/2addr v9, v0

    .line 113
    :cond_4
    const/high16 v0, 0x180000

    .line 114
    .line 115
    and-int v0, v0, p10

    .line 116
    .line 117
    if-nez v0, :cond_5

    .line 118
    .line 119
    invoke-static {v3, v8}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    or-int/2addr v9, v0

    .line 124
    :cond_5
    const/high16 v0, 0xc00000

    .line 125
    .line 126
    and-int v0, v0, p10

    .line 127
    .line 128
    if-nez v0, :cond_6

    .line 129
    .line 130
    invoke-static {v3, v4}, LX/004;->A0W(LX/2d4;Ljava/lang/Object;)I

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    or-int/2addr v9, v0

    .line 135
    :cond_6
    move/from16 p7, p11

    .line 136
    .line 137
    move/from16 v0, p7

    .line 138
    .line 139
    and-int/lit16 v10, v0, 0x100

    .line 140
    .line 141
    const/high16 v0, 0x6000000

    .line 142
    .line 143
    if-nez v10, :cond_7

    .line 144
    .line 145
    and-int v0, p10, v0

    .line 146
    .line 147
    if-nez v0, :cond_8

    .line 148
    .line 149
    invoke-static {v3, v7}, LX/004;->A0h(LX/2d4;Ljava/lang/Object;)I

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    :cond_7
    or-int/2addr v9, v0

    .line 154
    :cond_8
    invoke-static {v9}, LX/009;->A1K(I)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    invoke-static {v0, v3, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    if-eqz v0, :cond_11

    .line 163
    .line 164
    if-eqz v10, :cond_9

    .line 165
    .line 166
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 167
    .line 168
    :cond_9
    invoke-static {v3}, LX/005;->A0d(Ljava/lang/Object;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 169
    .line 170
    .line 171
    move-result-object v12

    .line 172
    const/high16 v0, 0x1c00000

    .line 173
    .line 174
    invoke-static {v0, v9}, LX/009;->A1O(II)Z

    .line 175
    .line 176
    .line 177
    move-result v10

    .line 178
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    if-nez v10, :cond_a

    .line 183
    .line 184
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 185
    .line 186
    if-ne v0, v10, :cond_b

    .line 187
    .line 188
    :cond_a
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;

    .line 189
    .line 190
    invoke-direct {v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 191
    .line 192
    .line 193
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 194
    .line 195
    .line 196
    :cond_b
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 197
    .line 198
    invoke-interface {v3, v12}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    move-result v10

    .line 202
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v11

    .line 206
    if-nez v10, :cond_c

    .line 207
    .line 208
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 209
    .line 210
    if-ne v11, v10, :cond_d

    .line 211
    .line 212
    :cond_c
    new-instance v11, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onWhyConfirm$1$1;

    .line 213
    .line 214
    invoke-direct {v11, v12}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onWhyConfirm$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 215
    .line 216
    .line 217
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 218
    .line 219
    .line 220
    :cond_d
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 221
    .line 222
    invoke-static {v9}, LX/008;->A1X(I)Z

    .line 223
    .line 224
    .line 225
    move-result v12

    .line 226
    invoke-static {v9}, LX/005;->A1H(I)Z

    .line 227
    .line 228
    .line 229
    move-result v10

    .line 230
    or-int/2addr v12, v10

    .line 231
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v10

    .line 235
    if-nez v12, :cond_e

    .line 236
    .line 237
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 238
    .line 239
    if-ne v10, v12, :cond_f

    .line 240
    .line 241
    :cond_e
    new-instance v10, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;

    .line 242
    .line 243
    invoke-direct {v10, v6, v5}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;-><init>(LX/Ddn;LX/Ddn;)V

    .line 244
    .line 245
    .line 246
    invoke-interface {v3, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    :cond_f
    check-cast v10, LX/JDM;

    .line 250
    .line 251
    shr-int/lit8 v12, v9, 0xf

    .line 252
    .line 253
    and-int/lit8 v13, v12, 0xe

    .line 254
    .line 255
    or-int/lit8 v20, v13, 0x30

    .line 256
    .line 257
    shr-int/lit8 v12, v9, 0xc

    .line 258
    .line 259
    and-int/lit16 v12, v12, 0x380

    .line 260
    .line 261
    or-int v20, v20, v12

    .line 262
    .line 263
    move-object/from16 v19, v3

    .line 264
    .line 265
    move/from16 v16, v14

    .line 266
    .line 267
    move-object/from16 v17, v8

    .line 268
    .line 269
    move-object/from16 v18, v11

    .line 270
    .line 271
    invoke-static/range {v15 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->rememberAgeStepHeaderActions(ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/Ddn;

    .line 272
    .line 273
    .line 274
    move-result-object v32

    .line 275
    invoke-static {v15, v0, v3, v13, v1}, Lcom/facebook/aura/navigation/AuraTerminalBackHandlerKt;->AuraTerminalBackHandler(ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 276
    .line 277
    .line 278
    sget-object v16, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 279
    .line 280
    const/16 v39, 0x0

    .line 281
    .line 282
    new-instance v12, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;

    .line 283
    .line 284
    move-object/from16 v51, v12

    .line 285
    .line 286
    move-object/from16 v52, v11

    .line 287
    .line 288
    move-object/from16 v53, v6

    .line 289
    .line 290
    move-object/from16 p0, v10

    .line 291
    .line 292
    move-object/from16 p2, v5

    .line 293
    .line 294
    invoke-direct/range {v51 .. v58}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;-><init>(Lkotlin/jvm/functions/Function0;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/JDN;LX/Ddn;LX/JDN;)V

    .line 295
    .line 296
    .line 297
    const v10, -0x329f5a1c

    .line 298
    .line 299
    .line 300
    invoke-static {v3, v12, v10}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 301
    .line 302
    .line 303
    move-result-object v48

    .line 304
    shr-int/lit8 v10, v9, 0x15

    .line 305
    .line 306
    and-int/lit8 v10, v10, 0x70

    .line 307
    .line 308
    or-int/lit8 v50, v10, 0x6

    .line 309
    .line 310
    const/high16 v10, 0x70000000

    .line 311
    .line 312
    shl-int/lit8 v9, v9, 0xc

    .line 313
    .line 314
    and-int/2addr v10, v9

    .line 315
    or-int v50, v50, v10

    .line 316
    .line 317
    const v52, 0x30000006

    .line 318
    .line 319
    .line 320
    const v53, 0x1fef7dbc

    .line 321
    .line 322
    .line 323
    const/16 v18, 0x0

    .line 324
    .line 325
    const-wide/16 v19, 0x0

    .line 326
    .line 327
    move-object/from16 v21, v18

    .line 328
    .line 329
    move-object/from16 v22, v18

    .line 330
    .line 331
    move-object/from16 v24, v18

    .line 332
    .line 333
    move/from16 v27, v1

    .line 334
    .line 335
    move-object/from16 v28, v18

    .line 336
    .line 337
    move-object/from16 v29, v18

    .line 338
    .line 339
    move-object/from16 v30, v18

    .line 340
    .line 341
    move-object/from16 v31, v18

    .line 342
    .line 343
    move-object/from16 v33, v18

    .line 344
    .line 345
    move-wide/from16 v34, v19

    .line 346
    .line 347
    move-wide/from16 v36, v19

    .line 348
    .line 349
    move-object/from16 v38, v18

    .line 350
    .line 351
    move-object/from16 v40, v18

    .line 352
    .line 353
    move-object/from16 v41, v18

    .line 354
    .line 355
    move-object/from16 v42, v18

    .line 356
    .line 357
    move/from16 v43, v1

    .line 358
    .line 359
    move-object/from16 v44, v18

    .line 360
    .line 361
    move-object/from16 v45, v18

    .line 362
    .line 363
    move-object/from16 v46, v18

    .line 364
    .line 365
    move/from16 v47, v1

    .line 366
    .line 367
    move-object/from16 v49, v3

    .line 368
    .line 369
    move/from16 v51, v1

    .line 370
    .line 371
    move-object/from16 v23, v0

    .line 372
    .line 373
    move/from16 v25, v1

    .line 374
    .line 375
    move/from16 v26, v15

    .line 376
    .line 377
    move-object/from16 v17, v7

    .line 378
    .line 379
    invoke-static/range {v16 .. v53}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 380
    .line 381
    .line 382
    :goto_1
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 383
    .line 384
    .line 385
    move-result-object v1

    .line 386
    if-eqz v1, :cond_10

    .line 387
    .line 388
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$2;

    .line 389
    .line 390
    move-object/from16 v51, v0

    .line 391
    .line 392
    move-object/from16 v52, v6

    .line 393
    .line 394
    move-object/from16 v53, v5

    .line 395
    .line 396
    move-object/from16 p0, p1

    .line 397
    .line 398
    move-object/from16 p1, p3

    .line 399
    .line 400
    move/from16 p2, v15

    .line 401
    .line 402
    move-object/from16 p3, v8

    .line 403
    .line 404
    move-object/from16 p4, v4

    .line 405
    .line 406
    move-object/from16 p5, v7

    .line 407
    .line 408
    move/from16 p6, v2

    .line 409
    .line 410
    invoke-direct/range {v51 .. v62}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$2;-><init>(LX/Ddn;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDN;LX/JDN;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 411
    .line 412
    .line 413
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 414
    .line 415
    :cond_10
    return-void

    .line 416
    :cond_11
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 417
    .line 418
    .line 419
    goto :goto_1

    .line 420
    :cond_12
    move v9, v2

    .line 421
    goto/16 :goto_0
.end method

.method public static final AgeMethodResolvingSpinner(LX/3C1;LX/2d4;II)V
    .locals 4

    .line 0
    const v0, 0x28803b81

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v3, p3, 0x1

    .line 7
    .line 8
    const/4 v2, 0x2

    .line 9
    if-eqz v3, :cond_5

    .line 10
    .line 11
    or-int/lit8 v0, p2, 0x6

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v1, v0, 0x3

    .line 14
    .line 15
    invoke-static {v1, v2}, LX/003;->A1H(II)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    invoke-static {v1, p1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 28
    .line 29
    :cond_0
    const v0, 0x7f1202bb

    .line 30
    .line 31
    .line 32
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-interface {p1, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-nez v1, :cond_1

    .line 45
    .line 46
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 47
    .line 48
    if-ne v0, v1, :cond_2

    .line 49
    .line 50
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodResolvingSpinner$1$1;

    .line 51
    .line 52
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodResolvingSpinner$1$1;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    check-cast v0, LX/JDM;

    .line 59
    .line 60
    invoke-static {p1, p0, v0}, LX/009;->A0x(LX/2d4;LX/3C1;LX/JDM;)V

    .line 61
    .line 62
    .line 63
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    if-eqz v1, :cond_3

    .line 68
    .line 69
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodResolvingSpinner$2;

    .line 70
    .line 71
    invoke-direct {v0, p0, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodResolvingSpinner$2;-><init>(LX/3C1;II)V

    .line 72
    .line 73
    .line 74
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 75
    .line 76
    :cond_3
    return-void

    .line 77
    :cond_4
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 78
    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_5
    and-int/lit8 v0, p2, 0x6

    .line 82
    .line 83
    if-nez v0, :cond_6

    .line 84
    .line 85
    invoke-static {p1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    or-int/2addr v0, p2

    .line 90
    goto :goto_0

    .line 91
    :cond_6
    move v0, p2

    .line 92
    goto :goto_0
.end method

.method public static final AgeMethodRows(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 40
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v22, p3

    .line 1
    .line 2
    const v0, 0x3c59fd9f

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p4

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p5

    .line 11
    .line 12
    and-int/lit8 v0, p5, 0x6

    .line 13
    .line 14
    move-object/from16 p5, p0

    .line 15
    .line 16
    if-nez v0, :cond_b

    .line 17
    .line 18
    move-object/from16 v0, p5

    .line 19
    .line 20
    invoke-static {v0, v6, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, LX/003;->A06(I)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    or-int/2addr v4, v5

    .line 29
    :goto_0
    and-int/lit8 v0, v5, 0x30

    .line 30
    .line 31
    move-object/from16 p4, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static/range {p4 .. p4}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {v6, v0}, LX/004;->A0F(LX/2d4;I)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    or-int/2addr v4, v0

    .line 44
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 45
    .line 46
    move-object/from16 p3, p2

    .line 47
    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    move-object/from16 v0, p3

    .line 51
    .line 52
    invoke-static {v6, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    or-int/2addr v4, v0

    .line 57
    :cond_1
    move/from16 p2, p6

    .line 58
    .line 59
    and-int/lit8 v2, p6, 0x8

    .line 60
    .line 61
    if-eqz v2, :cond_a

    .line 62
    .line 63
    or-int/lit16 v4, v4, 0xc00

    .line 64
    .line 65
    :cond_2
    :goto_1
    and-int/lit16 v1, v4, 0x493

    .line 66
    .line 67
    const/16 v0, 0x492

    .line 68
    .line 69
    const/4 v3, 0x0

    .line 70
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-static {v0, v6, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_c

    .line 79
    .line 80
    if-eqz v2, :cond_3

    .line 81
    .line 82
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 83
    .line 84
    :cond_3
    const/16 v21, 0x0

    .line 85
    .line 86
    sget-object v15, LX/2sI;->A02:LX/2wD;

    .line 87
    .line 88
    move-object/from16 v0, v22

    .line 89
    .line 90
    invoke-interface {v0, v15}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-static {v0, v6, v3}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->outlined(LX/3C1;LX/2d4;I)LX/3C1;

    .line 95
    .line 96
    .line 97
    move-result-object v8

    .line 98
    invoke-static {v6}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 99
    .line 100
    .line 101
    move-result-object v7

    .line 102
    move-object v2, v6

    .line 103
    check-cast v2, LX/J7I;

    .line 104
    .line 105
    iget-wide v0, v2, LX/J7I;->A06:J

    .line 106
    .line 107
    invoke-static {v0, v1}, LX/001;->A0A(J)I

    .line 108
    .line 109
    .line 110
    move-result v10

    .line 111
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-static {v6, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 116
    .line 117
    .line 118
    move-result-object v8

    .line 119
    sget-object v11, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 120
    .line 121
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 122
    .line 123
    if-nez v0, :cond_4

    .line 124
    .line 125
    invoke-static {}, LX/1VY;->A00()V

    .line 126
    .line 127
    .line 128
    :goto_2
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    throw v0

    .line 133
    :cond_4
    invoke-static {v6, v2, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 134
    .line 135
    .line 136
    sget-object v9, LX/3Cl;->A04:LX/JDN;

    .line 137
    .line 138
    invoke-static {v6, v7, v9}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 139
    .line 140
    .line 141
    move-result-object v7

    .line 142
    invoke-static {v6, v1, v7, v10}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 143
    .line 144
    .line 145
    move-result-object v20

    .line 146
    sget-object v1, LX/3Cl;->A02:LX/JDM;

    .line 147
    .line 148
    invoke-static {v6, v8, v1}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 149
    .line 150
    .line 151
    move-result-object v19

    .line 152
    const v8, 0x7e3816a5

    .line 153
    .line 154
    .line 155
    move-object/from16 v0, p5

    .line 156
    .line 157
    invoke-static {v6, v0, v8}, LX/006;->A1A(LX/2d4;Ljava/util/List;I)Ljava/util/Iterator;

    .line 158
    .line 159
    .line 160
    move-result-object v18

    .line 161
    const/4 v8, 0x0

    .line 162
    :goto_3
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-eqz v0, :cond_d

    .line 167
    .line 168
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    add-int/lit8 v17, v8, 0x1

    .line 173
    .line 174
    if-gez v8, :cond_5

    .line 175
    .line 176
    invoke-static {}, LX/B8B;->A1A()V

    .line 177
    .line 178
    .line 179
    goto :goto_2

    .line 180
    :cond_5
    check-cast v0, Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 181
    .line 182
    if-lez v8, :cond_9

    .line 183
    .line 184
    const v8, -0x21428cd6

    .line 185
    .line 186
    .line 187
    invoke-static {v6, v8}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 188
    .line 189
    .line 190
    move-result-object v12

    .line 191
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 192
    .line 193
    sget v8, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->ROW_ICON_SIZE:F

    .line 194
    .line 195
    add-float/2addr v8, v10

    .line 196
    add-float/2addr v8, v10

    .line 197
    invoke-static {v12, v8, v10}, LX/2pj;->A09(LX/3C1;FF)LX/3C1;

    .line 198
    .line 199
    .line 200
    move-result-object v8

    .line 201
    invoke-static {v8, v6, v3, v3}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 202
    .line 203
    .line 204
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 205
    .line 206
    .line 207
    :goto_4
    sget-object v16, LX/3C1;->A00:LX/3Cb;

    .line 208
    .line 209
    invoke-static/range {p4 .. p4}, LX/003;->A1R(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    move-result v13

    .line 213
    invoke-static {v3}, LX/1Y9;->A01(I)LX/1Y9;

    .line 214
    .line 215
    .line 216
    move-result-object v12

    .line 217
    invoke-static {v4}, LX/005;->A1J(I)Z

    .line 218
    .line 219
    .line 220
    move-result v14

    .line 221
    invoke-static {v6, v0}, LX/002;->A1V(LX/2d4;Ljava/lang/Enum;)Z

    .line 222
    .line 223
    .line 224
    move-result v8

    .line 225
    or-int/2addr v14, v8

    .line 226
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v10

    .line 230
    if-nez v14, :cond_6

    .line 231
    .line 232
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 233
    .line 234
    if-ne v10, v8, :cond_7

    .line 235
    .line 236
    :cond_6
    new-instance v10, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodRows$1$1$1$1;

    .line 237
    .line 238
    move-object/from16 v8, p3

    .line 239
    .line 240
    invoke-direct {v10, v8, v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodRows$1$1$1$1;-><init>(LX/JDM;Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 241
    .line 242
    .line 243
    invoke-interface {v6, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    :cond_7
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 247
    .line 248
    move-object/from16 v8, v21

    .line 249
    .line 250
    invoke-static {v15, v12, v8, v10, v13}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 251
    .line 252
    .line 253
    move-result-object v12

    .line 254
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 255
    .line 256
    sget v8, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 257
    .line 258
    invoke-static {v12, v10, v8}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 259
    .line 260
    .line 261
    move-result-object v8

    .line 262
    invoke-static {v10}, LX/Dn6;->A00(F)LX/CP5;

    .line 263
    .line 264
    .line 265
    move-result-object v13

    .line 266
    sget-object v10, LX/2Id;->A04:LX/2rU;

    .line 267
    .line 268
    const/16 v12, 0x30

    .line 269
    .line 270
    invoke-static {v13, v6, v10, v12}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 271
    .line 272
    .line 273
    move-result-object v14

    .line 274
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 275
    .line 276
    .line 277
    move-result v13

    .line 278
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 279
    .line 280
    .line 281
    move-result-object v10

    .line 282
    invoke-static {v6, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 283
    .line 284
    .line 285
    move-result-object v8

    .line 286
    invoke-static {v6, v2, v11}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 287
    .line 288
    .line 289
    invoke-static {v6, v14, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 290
    .line 291
    .line 292
    invoke-static {v6, v10, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 293
    .line 294
    .line 295
    move-object/from16 v10, v20

    .line 296
    .line 297
    invoke-static {v1, v10, v6, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 298
    .line 299
    .line 300
    move-object/from16 v10, v19

    .line 301
    .line 302
    invoke-static {v6, v8, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 303
    .line 304
    .line 305
    sget-object v13, LX/CgK;->A00:LX/CgK;

    .line 306
    .line 307
    sget-object v24, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 308
    .line 309
    const/16 v28, 0x4

    .line 310
    .line 311
    move-object/from16 v23, v0

    .line 312
    .line 313
    move-object/from16 v25, v21

    .line 314
    .line 315
    move-object/from16 v26, v6

    .line 316
    .line 317
    move/from16 v27, v12

    .line 318
    .line 319
    invoke-static/range {v23 .. v28}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodIcon(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/3C1;LX/2d4;II)V

    .line 320
    .line 321
    .line 322
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->getLabelRes(Lcom/facebook/aura/user/provider/AgeCheckMethod;)I

    .line 323
    .line 324
    .line 325
    move-result v8

    .line 326
    invoke-static {v6, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object v23

    .line 330
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 331
    .line 332
    invoke-static {v6, v8}, LX/07H;->A0M(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 333
    .line 334
    .line 335
    move-result-object v27

    .line 336
    invoke-static {v6, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 337
    .line 338
    .line 339
    move-result-wide v25

    .line 340
    const/high16 v12, 0x3f800000    # 1.0f

    .line 341
    .line 342
    const/4 v8, 0x1

    .line 343
    move-object/from16 v10, v16

    .line 344
    .line 345
    invoke-virtual {v13, v10, v12, v8}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 346
    .line 347
    .line 348
    move-result-object v24

    .line 349
    const/16 p1, 0x3ff0

    .line 350
    .line 351
    move-object/from16 v28, v21

    .line 352
    .line 353
    move-object/from16 v29, v21

    .line 354
    .line 355
    move-object/from16 v30, v21

    .line 356
    .line 357
    move/from16 v31, v3

    .line 358
    .line 359
    move/from16 v32, v3

    .line 360
    .line 361
    move/from16 v33, v3

    .line 362
    .line 363
    move/from16 v34, v3

    .line 364
    .line 365
    move-object/from16 v35, v21

    .line 366
    .line 367
    move-object/from16 v36, v21

    .line 368
    .line 369
    move-object/from16 v37, v21

    .line 370
    .line 371
    move-object/from16 v38, v6

    .line 372
    .line 373
    move/from16 v39, v3

    .line 374
    .line 375
    move/from16 p0, v3

    .line 376
    .line 377
    invoke-static/range {v23 .. v41}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 378
    .line 379
    .line 380
    move-object/from16 v10, p4

    .line 381
    .line 382
    if-ne v0, v10, :cond_8

    .line 383
    .line 384
    const v0, -0x17d25d8d

    .line 385
    .line 386
    .line 387
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 388
    .line 389
    .line 390
    move-object/from16 v0, v21

    .line 391
    .line 392
    invoke-static {v0, v6, v3, v8}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodResolvingSpinner(LX/3C1;LX/2d4;II)V

    .line 393
    .line 394
    .line 395
    :goto_5
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 396
    .line 397
    .line 398
    invoke-static {v2, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 399
    .line 400
    .line 401
    move/from16 v8, v17

    .line 402
    .line 403
    goto/16 :goto_3

    .line 404
    .line 405
    :cond_8
    const v0, 0x1d87114a

    .line 406
    .line 407
    .line 408
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 409
    .line 410
    .line 411
    goto :goto_5

    .line 412
    :cond_9
    const v8, -0x213f52fa

    .line 413
    .line 414
    .line 415
    invoke-interface {v6, v8}, LX/2d4;->Agj(I)V

    .line 416
    .line 417
    .line 418
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 419
    .line 420
    .line 421
    goto/16 :goto_4

    .line 422
    .line 423
    :cond_a
    and-int/lit16 v0, v5, 0xc00

    .line 424
    .line 425
    if-nez v0, :cond_2

    .line 426
    .line 427
    move-object/from16 v0, v22

    .line 428
    .line 429
    invoke-static {v6, v0}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 430
    .line 431
    .line 432
    move-result v0

    .line 433
    or-int/2addr v4, v0

    .line 434
    goto/16 :goto_1

    .line 435
    .line 436
    :cond_b
    move v4, v5

    .line 437
    goto/16 :goto_0

    .line 438
    .line 439
    :cond_c
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 440
    .line 441
    .line 442
    goto :goto_6

    .line 443
    :cond_d
    invoke-static {v2}, LX/003;->A0u(LX/J7I;)V

    .line 444
    .line 445
    .line 446
    :goto_6
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 447
    .line 448
    .line 449
    move-result-object v1

    .line 450
    if-eqz v1, :cond_e

    .line 451
    .line 452
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodRows$2;

    .line 453
    .line 454
    move-object/from16 v36, v0

    .line 455
    .line 456
    move-object/from16 v37, p5

    .line 457
    .line 458
    move-object/from16 v38, p4

    .line 459
    .line 460
    move-object/from16 v39, p3

    .line 461
    .line 462
    move-object/from16 p0, v22

    .line 463
    .line 464
    move/from16 p1, v5

    .line 465
    .line 466
    invoke-direct/range {v36 .. v42}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodRows$2;-><init>(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;II)V

    .line 467
    .line 468
    .line 469
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 470
    .line 471
    :cond_e
    return-void
.end method

.method public static final synthetic access$AgeMethodAccounts(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodAccounts(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgeMethodIcon(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodIcon(Lcom/facebook/aura/user/provider/AgeCheckMethod;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgeMethodListHeader(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodListHeader(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgeMethodResolvingSpinner(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodResolvingSpinner(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$AgeMethodRows(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodRows(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getAGE_METHODS_SCREEN$p()Lcom/facebook/aura/analytics/hatch/HatchScreen;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AGE_METHODS_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getPickComponent(Lcom/facebook/aura/user/provider/AgeCheckMethod;)Lcom/facebook/aura/analytics/hatch/HatchComponent;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->getPickComponent(Lcom/facebook/aura/user/provider/AgeCheckMethod;)Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final getIconRes(Lcom/facebook/aura/user/provider/AgeCheckMethod;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_4

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_3

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_2

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-eq p0, v0, :cond_1

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-ne p0, v0, :cond_0

    .line 18
    .line 19
    const v0, 0x7f08021e

    .line 20
    .line 21
    .line 22
    return v0

    .line 23
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    throw v0

    .line 28
    :cond_1
    const v0, 0x7f080131

    .line 29
    .line 30
    .line 31
    return v0

    .line 32
    :cond_2
    const v0, 0x7f080114

    .line 33
    .line 34
    .line 35
    return v0

    .line 36
    :cond_3
    const v0, 0x7f0802d6

    .line 37
    .line 38
    .line 39
    return v0

    .line 40
    :cond_4
    const v0, 0x7f080194

    .line 41
    .line 42
    .line 43
    return v0
.end method

.method public static final getLabelRes(Lcom/facebook/aura/user/provider/AgeCheckMethod;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_4

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_3

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_2

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-eq p0, v0, :cond_1

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-ne p0, v0, :cond_0

    .line 18
    .line 19
    const v0, 0x7f120081

    .line 20
    .line 21
    .line 22
    return v0

    .line 23
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    throw v0

    .line 28
    :cond_1
    const v0, 0x7f12007f

    .line 29
    .line 30
    .line 31
    return v0

    .line 32
    :cond_2
    const v0, 0x7f12007e

    .line 33
    .line 34
    .line 35
    return v0

    .line 36
    :cond_3
    const v0, 0x7f120080

    .line 37
    .line 38
    .line 39
    return v0

    .line 40
    :cond_4
    const v0, 0x7f120084

    .line 41
    .line 42
    .line 43
    return v0
.end method

.method public static final getPickComponent(Lcom/facebook/aura/user/provider/AgeCheckMethod;)Lcom/facebook/aura/analytics/hatch/HatchComponent;
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_4

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_3

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_2

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-eq p0, v0, :cond_1

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-ne p0, v0, :cond_0

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CONTINUE_WITH_INSTAGRAM:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    throw v0

    .line 27
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CONTINUE_WITH_FACEBOOK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 28
    .line 29
    return-object v0

    .line 30
    :cond_2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->USE_CREDIT_CARD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_3
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->USE_ID:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 34
    .line 35
    return-object v0

    .line 36
    :cond_4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CONTINUE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 37
    .line 38
    return-object v0
.end method

.method public static final outlined(LX/3C1;LX/2d4;I)LX/3C1;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 5
    .line 6
    invoke-static {p1, v0}, LX/07H;->A0H(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2bW;

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    invoke-static {p0, v4}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    const/high16 v2, 0x3f800000    # 1.0f

    .line 15
    .line 16
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 17
    .line 18
    invoke-static {v0, p1}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 23
    .line 24
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevatedBorder:J

    .line 25
    .line 26
    invoke-static {v3, v4, v2, v0, v1}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0
.end method
