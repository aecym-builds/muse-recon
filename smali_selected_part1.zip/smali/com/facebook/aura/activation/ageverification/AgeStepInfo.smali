.class public final enum Lcom/facebook/aura/activation/ageverification/AgeStepInfo;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/facebook/aura/activation/ageverification/AgeStepInfo;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic $ENTRIES:LX/0vk;

.field public static final synthetic $VALUES:[Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

.field public static final enum HOW_ID_WORKS:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

.field public static final enum HOW_SELFIES_WORK:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

.field public static final enum WHY_CONFIRM:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;


# instance fields
.field public final rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;",
            ">;"
        }
    .end annotation
.end field

.field public final subtitleRes:Ljava/lang/Integer;

.field public final titleRes:I


# direct methods
.method public static constructor <clinit>()V
    .locals 17

    .line 0
    const v6, 0x7f12005a

    .line 1
    .line 2
    .line 3
    const v0, 0x7f120059

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v7

    .line 10
    const/4 v5, 0x0

    .line 11
    const v1, 0x7f0800f4

    .line 12
    .line 13
    .line 14
    const v0, 0x7f120058

    .line 15
    .line 16
    .line 17
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 18
    .line 19
    invoke-direct {v4, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 20
    .line 21
    .line 22
    const v1, 0x7f08028f

    .line 23
    .line 24
    .line 25
    const v0, 0x7f120057

    .line 26
    .line 27
    .line 28
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 29
    .line 30
    invoke-direct {v3, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 31
    .line 32
    .line 33
    const/4 v9, 0x1

    .line 34
    const v2, 0x7f08029b

    .line 35
    .line 36
    .line 37
    const v1, 0x7f120056

    .line 38
    .line 39
    .line 40
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 41
    .line 42
    invoke-direct {v0, v2, v1, v9}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 43
    .line 44
    .line 45
    const/4 v13, 0x2

    .line 46
    filled-new-array {v4, v3, v0}, [Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    const-string v4, "HOW_SELFIES_WORK"

    .line 55
    .line 56
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 57
    .line 58
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;-><init>(Ljava/lang/String;IILjava/lang/Integer;Ljava/util/List;)V

    .line 59
    .line 60
    .line 61
    sput-object v3, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->HOW_SELFIES_WORK:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 62
    .line 63
    const v10, 0x7f120055

    .line 64
    .line 65
    .line 66
    const v0, 0x7f120054

    .line 67
    .line 68
    .line 69
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object v11

    .line 73
    const/4 v15, 0x0

    .line 74
    const v1, 0x7f0802d6

    .line 75
    .line 76
    .line 77
    const v0, 0x7f120053

    .line 78
    .line 79
    .line 80
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 81
    .line 82
    invoke-direct {v4, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 83
    .line 84
    .line 85
    const v1, 0x7f08012e

    .line 86
    .line 87
    .line 88
    const v0, 0x7f120051

    .line 89
    .line 90
    .line 91
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 92
    .line 93
    invoke-direct {v3, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 94
    .line 95
    .line 96
    const v2, 0x7f0802cb

    .line 97
    .line 98
    .line 99
    const v1, 0x7f120052

    .line 100
    .line 101
    .line 102
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 103
    .line 104
    invoke-direct {v0, v2, v1, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 105
    .line 106
    .line 107
    filled-new-array {v4, v3, v0}, [Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 112
    .line 113
    .line 114
    move-result-object v12

    .line 115
    const-string v8, "HOW_ID_WORKS"

    .line 116
    .line 117
    new-instance v7, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 118
    .line 119
    invoke-direct/range {v7 .. v12}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;-><init>(Ljava/lang/String;IILjava/lang/Integer;Ljava/util/List;)V

    .line 120
    .line 121
    .line 122
    sput-object v7, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->HOW_ID_WORKS:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 123
    .line 124
    const v14, 0x7f1200a5

    .line 125
    .line 126
    .line 127
    const v1, 0x7f0800f4

    .line 128
    .line 129
    .line 130
    const v0, 0x7f1200a3

    .line 131
    .line 132
    .line 133
    new-instance v3, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 134
    .line 135
    invoke-direct {v3, v1, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 136
    .line 137
    .line 138
    const v2, 0x7f08029b

    .line 139
    .line 140
    .line 141
    const v1, 0x7f1200a4

    .line 142
    .line 143
    .line 144
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 145
    .line 146
    invoke-direct {v0, v2, v1, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 147
    .line 148
    .line 149
    filled-new-array {v3, v0}, [Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 154
    .line 155
    .line 156
    move-result-object v16

    .line 157
    const-string v12, "WHY_CONFIRM"

    .line 158
    .line 159
    new-instance v11, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 160
    .line 161
    invoke-direct/range {v11 .. v16}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;-><init>(Ljava/lang/String;IILjava/lang/Integer;Ljava/util/List;)V

    .line 162
    .line 163
    .line 164
    sput-object v11, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->WHY_CONFIRM:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 165
    .line 166
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->HOW_SELFIES_WORK:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 167
    .line 168
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->HOW_ID_WORKS:Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 169
    .line 170
    filled-new-array {v1, v0, v11}, [Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 175
    .line 176
    invoke-static {v0}, LX/0wf;->A00([Ljava/lang/Enum;)LX/DvM;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->$ENTRIES:LX/0vk;

    .line 181
    .line 182
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IILjava/lang/Integer;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1
    .line 2
    .line 3
    iput p3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->titleRes:I

    .line 4
    .line 5
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->subtitleRes:Ljava/lang/Integer;

    .line 6
    .line 7
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->rows:Ljava/util/List;

    .line 8
    .line 9
    return-void
.end method

.method public static getEntries()LX/0vk;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0vk<",
            "Lcom/facebook/aura/activation/ageverification/AgeStepInfo;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->$ENTRIES:LX/0vk;

    .line 1
    .line 2
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/AgeStepInfo;
    .locals 1

    .line 0
    const-class v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 1
    .line 2
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 7
    .line 8
    return-object v0
.end method

.method public static values()[Lcom/facebook/aura/activation/ageverification/AgeStepInfo;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->$VALUES:[Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, [Lcom/facebook/aura/activation/ageverification/AgeStepInfo;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final getRows()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->rows:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitleRes()Ljava/lang/Integer;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->subtitleRes:Ljava/lang/Integer;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitleRes()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->titleRes:I

    .line 1
    .line 2
    return p0
.end method
