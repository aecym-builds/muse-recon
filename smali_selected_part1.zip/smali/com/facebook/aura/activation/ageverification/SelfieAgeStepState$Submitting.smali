.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final sinceMs:J


# direct methods
.method public constructor <init>(J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 4
    .line 5
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;JILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-wide p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 5
    .line 6
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 7
    .line 8
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;-><init>(J)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method


# virtual methods
.method public final component1()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final copy(J)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;-><init>(J)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 9
    .line 10
    iget-wide v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 11
    .line 12
    iget-wide v1, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 13
    .line 14
    cmp-long v0, v3, v1

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    :cond_0
    return v5

    .line 19
    :cond_1
    return v6
.end method

.method public final getSinceMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public hashCode()I
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 1
    .line 2
    invoke-static {v0, p0}, LX/002;->A0H(J)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
