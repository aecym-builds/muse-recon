.class public abstract Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final IdDocumentRow(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 32
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v16, p3

    .line 1
    .line 2
    const v1, -0x460f1b3f

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p5

    .line 11
    .line 12
    and-int/lit8 v3, p5, 0x6

    .line 13
    .line 14
    const/4 v14, 0x4

    .line 15
    move-object/from16 v2, p0

    .line 16
    .line 17
    if-nez v3, :cond_7

    .line 18
    .line 19
    invoke-static {v0, v2}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    or-int v4, v4, p5

    .line 24
    .line 25
    :goto_0
    and-int/lit8 v3, p5, 0x30

    .line 26
    .line 27
    move-object/from16 p5, p1

    .line 28
    .line 29
    if-nez v3, :cond_0

    .line 30
    .line 31
    invoke-static/range {p5 .. p5}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    invoke-static {v0, v3}, LX/004;->A0F(LX/2d4;I)I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    or-int/2addr v4, v3

    .line 40
    :cond_0
    and-int/lit16 v3, v1, 0x180

    .line 41
    .line 42
    const/16 v8, 0x100

    .line 43
    .line 44
    move-object/from16 v15, p2

    .line 45
    .line 46
    if-nez v3, :cond_1

    .line 47
    .line 48
    invoke-static {v0, v15}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    or-int/2addr v4, v3

    .line 53
    :cond_1
    move/from16 p4, p6

    .line 54
    .line 55
    and-int/lit8 v5, p6, 0x8

    .line 56
    .line 57
    if-eqz v5, :cond_6

    .line 58
    .line 59
    or-int/lit16 v4, v4, 0xc00

    .line 60
    .line 61
    :cond_2
    :goto_1
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    invoke-static {v3, v0, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 66
    .line 67
    .line 68
    move-result v3

    .line 69
    if-eqz v3, :cond_8

    .line 70
    .line 71
    if-eqz v5, :cond_3

    .line 72
    .line 73
    sget-object v16, LX/3C1;->A00:LX/3Cb;

    .line 74
    .line 75
    :cond_3
    const/16 v22, 0x0

    .line 76
    .line 77
    invoke-static/range {v16 .. v16}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    move-object/from16 v3, p5

    .line 82
    .line 83
    invoke-static {v2, v3}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v10

    .line 87
    const/4 v3, 0x3

    .line 88
    invoke-static {v3}, LX/1Y9;->A01(I)LX/1Y9;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    and-int/lit16 v7, v4, 0x380

    .line 93
    .line 94
    invoke-static {v7, v8}, LX/003;->A1I(II)Z

    .line 95
    .line 96
    .line 97
    move-result v11

    .line 98
    and-int/lit8 v6, v4, 0xe

    .line 99
    .line 100
    invoke-static {v6, v14}, LX/003;->A1I(II)Z

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    or-int/2addr v11, v3

    .line 105
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    if-nez v11, :cond_4

    .line 110
    .line 111
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 112
    .line 113
    if-ne v3, v4, :cond_5

    .line 114
    .line 115
    :cond_4
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$1$1;

    .line 116
    .line 117
    invoke-direct {v3, v15, v2}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$1$1;-><init>(LX/JDM;Lcom/facebook/aura/activation/ageverification/IdDocument;)V

    .line 118
    .line 119
    .line 120
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    :cond_5
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 124
    .line 125
    const/4 v4, 0x1

    .line 126
    invoke-static {v9, v5, v3, v10, v4}, LX/3GS;->A01(LX/3C1;LX/1Y9;Lkotlin/jvm/functions/Function0;ZZ)LX/3C1;

    .line 127
    .line 128
    .line 129
    move-result-object v5

    .line 130
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 131
    .line 132
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 133
    .line 134
    invoke-static {v5, v9, v3}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 135
    .line 136
    .line 137
    move-result-object v5

    .line 138
    invoke-static {v0, v9}, LX/008;->A0l(LX/2d4;F)LX/3BI;

    .line 139
    .line 140
    .line 141
    move-result-object v13

    .line 142
    move-object v3, v0

    .line 143
    check-cast v3, LX/J7I;

    .line 144
    .line 145
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 146
    .line 147
    .line 148
    move-result v12

    .line 149
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 150
    .line 151
    .line 152
    move-result-object v11

    .line 153
    invoke-static {v0, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 154
    .line 155
    .line 156
    move-result-object v10

    .line 157
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 158
    .line 159
    iget-object v5, v3, LX/J7I;->A0V:LX/3DJ;

    .line 160
    .line 161
    if-nez v5, :cond_9

    .line 162
    .line 163
    invoke-static {}, LX/1VY;->A00()V

    .line 164
    .line 165
    .line 166
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    throw v0

    .line 171
    :cond_6
    and-int/lit16 v3, v1, 0xc00

    .line 172
    .line 173
    if-nez v3, :cond_2

    .line 174
    .line 175
    move-object/from16 v3, v16

    .line 176
    .line 177
    invoke-static {v0, v3}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 178
    .line 179
    .line 180
    move-result v3

    .line 181
    or-int/2addr v4, v3

    .line 182
    goto :goto_1

    .line 183
    :cond_7
    move v4, v1

    .line 184
    goto/16 :goto_0

    .line 185
    .line 186
    :cond_8
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 187
    .line 188
    .line 189
    goto/16 :goto_2

    .line 190
    .line 191
    :cond_9
    invoke-static {v0, v3, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 192
    .line 193
    .line 194
    invoke-static {v0, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 195
    .line 196
    .line 197
    sget-object v9, LX/CgK;->A00:LX/CgK;

    .line 198
    .line 199
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;->getIconRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    const/4 v11, 0x0

    .line 204
    invoke-static {v0, v5, v11}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 205
    .line 206
    .line 207
    move-result-object v23

    .line 208
    sget-object v24, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 209
    .line 210
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 211
    .line 212
    invoke-static {v0, v5}, LX/07H;->A02(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 213
    .line 214
    .line 215
    move-result-wide v26

    .line 216
    invoke-static {}, LX/2l9;->A03()I

    .line 217
    .line 218
    .line 219
    move-result v30

    .line 220
    const/16 v31, 0x29

    .line 221
    .line 222
    const/4 v13, 0x1

    .line 223
    move-object/from16 v25, v22

    .line 224
    .line 225
    move-object/from16 v28, v22

    .line 226
    .line 227
    move-object/from16 v29, v0

    .line 228
    .line 229
    invoke-static/range {v22 .. v31}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 230
    .line 231
    .line 232
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;->getLabelRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I

    .line 233
    .line 234
    .line 235
    move-result v10

    .line 236
    invoke-static {v0, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v17

    .line 240
    invoke-static {v0, v5}, LX/07H;->A0M(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 241
    .line 242
    .line 243
    move-result-object v21

    .line 244
    invoke-static {v0, v5}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 245
    .line 246
    .line 247
    move-result-wide v19

    .line 248
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 249
    .line 250
    invoke-static {v9, v5, v4}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 251
    .line 252
    .line 253
    move-result-object v18

    .line 254
    const/16 p3, 0x3ff0

    .line 255
    .line 256
    const/4 v12, 0x0

    .line 257
    move-object/from16 v23, v22

    .line 258
    .line 259
    move-object/from16 v24, v22

    .line 260
    .line 261
    move/from16 v25, v11

    .line 262
    .line 263
    move/from16 v26, v11

    .line 264
    .line 265
    move/from16 v27, v11

    .line 266
    .line 267
    move/from16 v28, v11

    .line 268
    .line 269
    move-object/from16 v29, v22

    .line 270
    .line 271
    move-object/from16 v30, v22

    .line 272
    .line 273
    move-object/from16 v31, v22

    .line 274
    .line 275
    move-object/from16 p0, v0

    .line 276
    .line 277
    move/from16 p1, v11

    .line 278
    .line 279
    move/from16 p2, v11

    .line 280
    .line 281
    invoke-static/range {v17 .. v35}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 282
    .line 283
    .line 284
    move-object/from16 v9, p5

    .line 285
    .line 286
    invoke-static {v2, v9}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v20

    .line 290
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v10

    .line 294
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 295
    .line 296
    if-ne v10, v9, :cond_a

    .line 297
    .line 298
    sget-object v10, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$1$1;

    .line 299
    .line 300
    invoke-interface {v0, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 301
    .line 302
    .line 303
    :cond_a
    invoke-static {v5, v10}, LX/001;->A0Y(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 304
    .line 305
    .line 306
    move-result-object v18

    .line 307
    if-ne v7, v8, :cond_b

    .line 308
    .line 309
    const/4 v12, 0x1

    .line 310
    :cond_b
    if-eq v6, v14, :cond_c

    .line 311
    .line 312
    const/4 v13, 0x0

    .line 313
    :cond_c
    or-int/2addr v12, v13

    .line 314
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v5

    .line 318
    if-nez v12, :cond_d

    .line 319
    .line 320
    if-ne v5, v9, :cond_e

    .line 321
    .line 322
    :cond_d
    new-instance v5, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;

    .line 323
    .line 324
    invoke-direct {v5, v15, v2}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;-><init>(LX/JDM;Lcom/facebook/aura/activation/ageverification/IdDocument;)V

    .line 325
    .line 326
    .line 327
    invoke-interface {v0, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 328
    .line 329
    .line 330
    :cond_e
    check-cast v5, LX/JDM;

    .line 331
    .line 332
    const/16 v27, 0x32

    .line 333
    .line 334
    const-wide/16 v23, 0x0

    .line 335
    .line 336
    move/from16 v19, v11

    .line 337
    .line 338
    move-object/from16 v21, v5

    .line 339
    .line 340
    move-object/from16 v25, v0

    .line 341
    .line 342
    invoke-static/range {v18 .. v27}, Lcom/facebook/aura/vds/compose/controls/AuraRadioKt;->AuraRadio-V-9fs2A(LX/3C1;ZZLX/JDM;LX/3Gw;JLX/2d4;II)V

    .line 343
    .line 344
    .line 345
    invoke-static {v3, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 346
    .line 347
    .line 348
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 349
    .line 350
    .line 351
    move-result-object v3

    .line 352
    if-eqz v3, :cond_f

    .line 353
    .line 354
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$3;

    .line 355
    .line 356
    move-object/from16 v30, v0

    .line 357
    .line 358
    move-object/from16 v31, v2

    .line 359
    .line 360
    move-object/from16 p0, p5

    .line 361
    .line 362
    move-object/from16 p1, v15

    .line 363
    .line 364
    move-object/from16 p2, v16

    .line 365
    .line 366
    move/from16 p3, v1

    .line 367
    .line 368
    invoke-direct/range {v30 .. v36}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$3;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;LX/3C1;II)V

    .line 369
    .line 370
    .line 371
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 372
    .line 373
    :cond_f
    return-void
.end method

.method public static final IdDocumentTypeContent(Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v8, p4

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    move-object/from16 v7, p3

    .line 8
    .line 9
    invoke-static {v5, v6, v7, v0}, LX/005;->A10(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 10
    .line 11
    .line 12
    const v0, -0xa4bfe00

    .line 13
    .line 14
    .line 15
    move-object/from16 v15, p5

    .line 16
    .line 17
    invoke-interface {v15, v0}, LX/2d4;->Agl(I)V

    .line 18
    .line 19
    .line 20
    move/from16 v9, p6

    .line 21
    .line 22
    and-int/lit8 v0, p6, 0x6

    .line 23
    .line 24
    move-object/from16 v4, p0

    .line 25
    .line 26
    if-nez v0, :cond_8

    .line 27
    .line 28
    invoke-static {v4}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-static {v15, v0}, LX/004;->A0E(LX/2d4;I)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    or-int v2, v2, p6

    .line 37
    .line 38
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 39
    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    invoke-static {v15, v5}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    or-int/2addr v2, v0

    .line 47
    :cond_0
    and-int/lit16 v0, v9, 0x180

    .line 48
    .line 49
    if-nez v0, :cond_1

    .line 50
    .line 51
    invoke-static {v15, v6}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    or-int/2addr v2, v0

    .line 56
    :cond_1
    and-int/lit16 v0, v9, 0xc00

    .line 57
    .line 58
    if-nez v0, :cond_2

    .line 59
    .line 60
    invoke-static {v15, v7}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    or-int/2addr v2, v0

    .line 65
    :cond_2
    move/from16 v10, p7

    .line 66
    .line 67
    and-int/lit8 v3, p7, 0x10

    .line 68
    .line 69
    if-eqz v3, :cond_7

    .line 70
    .line 71
    or-int/lit16 v2, v2, 0x6000

    .line 72
    .line 73
    :cond_3
    :goto_1
    and-int/lit16 v1, v2, 0x2493

    .line 74
    .line 75
    const/16 v0, 0x2492

    .line 76
    .line 77
    const/16 p1, 0x0

    .line 78
    .line 79
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    invoke-static {v0, v15, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_6

    .line 88
    .line 89
    if-eqz v3, :cond_4

    .line 90
    .line 91
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 92
    .line 93
    :cond_4
    invoke-static {v15}, LX/005;->A0d(Ljava/lang/Object;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 94
    .line 95
    .line 96
    move-result-object p5

    .line 97
    const v0, 0x7f1204c4

    .line 98
    .line 99
    .line 100
    invoke-static {v15, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p3

    .line 104
    invoke-static {v4}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v11

    .line 108
    new-instance v1, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;

    .line 109
    .line 110
    move-object/from16 p2, v1

    .line 111
    .line 112
    move-object/from16 p4, v7

    .line 113
    .line 114
    move-object/from16 p6, v4

    .line 115
    .line 116
    move-object/from16 p7, v5

    .line 117
    .line 118
    invoke-direct/range {p2 .. p7}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;)V

    .line 119
    .line 120
    .line 121
    const v0, -0x6a214e73

    .line 122
    .line 123
    .line 124
    invoke-static {v15, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 125
    .line 126
    .line 127
    move-result-object v14

    .line 128
    shr-int/lit8 v0, v2, 0x3

    .line 129
    .line 130
    and-int/lit8 v0, v0, 0x70

    .line 131
    .line 132
    or-int/lit16 v1, v0, 0xc00

    .line 133
    .line 134
    shr-int/lit8 v0, v2, 0x6

    .line 135
    .line 136
    and-int/lit16 v0, v0, 0x380

    .line 137
    .line 138
    or-int/2addr v1, v0

    .line 139
    move-object v12, v6

    .line 140
    move-object v13, v8

    .line 141
    move/from16 p0, v1

    .line 142
    .line 143
    invoke-static/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepColumn(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/JDN;LX/2d4;II)V

    .line 144
    .line 145
    .line 146
    :goto_2
    invoke-interface {v15}, LX/2d4;->AAg()LX/J7V;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    if-eqz v0, :cond_5

    .line 151
    .line 152
    new-instance v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$2;

    .line 153
    .line 154
    invoke-direct/range {v3 .. v10}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$2;-><init>(Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 155
    .line 156
    .line 157
    iput-object v3, v0, LX/J7V;->A06:LX/JDN;

    .line 158
    .line 159
    :cond_5
    return-void

    .line 160
    :cond_6
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 161
    .line 162
    .line 163
    goto :goto_2

    .line 164
    :cond_7
    and-int/lit16 v0, v9, 0x6000

    .line 165
    .line 166
    if-nez v0, :cond_3

    .line 167
    .line 168
    invoke-static {v15, v8}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    or-int/2addr v2, v0

    .line 173
    goto :goto_1

    .line 174
    :cond_8
    move v2, v9

    .line 175
    goto/16 :goto_0
.end method

.method public static final synthetic access$IdDocumentRow(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;->IdDocumentRow(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final getIconRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_3

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_2

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_1

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-ne p0, v0, :cond_0

    .line 15
    .line 16
    const v0, 0x7f0802d5

    .line 17
    .line 18
    .line 19
    return v0

    .line 20
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    throw v0

    .line 25
    :cond_1
    const v0, 0x7f0801ef

    .line 26
    .line 27
    .line 28
    return v0

    .line 29
    :cond_2
    const v0, 0x7f0802d7

    .line 30
    .line 31
    .line 32
    return v0

    .line 33
    :cond_3
    const v0, 0x7f0802d4

    .line 34
    .line 35
    .line 36
    return v0
.end method

.method public static final getLabelRes(Lcom/facebook/aura/activation/ageverification/IdDocument;)I
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_3

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_2

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-eq p0, v0, :cond_1

    .line 12
    .line 13
    const/4 v0, 0x3

    .line 14
    if-ne p0, v0, :cond_0

    .line 15
    .line 16
    const v0, 0x7f120079

    .line 17
    .line 18
    .line 19
    return v0

    .line 20
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    throw v0

    .line 25
    :cond_1
    const v0, 0x7f120078

    .line 26
    .line 27
    .line 28
    return v0

    .line 29
    :cond_2
    const v0, 0x7f120077

    .line 30
    .line 31
    .line 32
    return v0

    .line 33
    :cond_3
    const v0, 0x7f120076

    .line 34
    .line 35
    .line 36
    return v0
.end method
