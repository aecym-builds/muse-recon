.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.SelfieAgeStepReviewingKt$rememberDrawnFill$1$1"
    f = "SelfieAgeStepReviewing.kt"
    l = {
        0x7d,
        0x7f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $current$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $drawn:LX/2ss;

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/2ss;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2ss;",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$drawn:LX/2ss;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$current$delegate:LX/16A;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$drawn:LX/2ss;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$current$delegate:LX/16A;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;-><init>(LX/2ss;LX/16A;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x2

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    if-eq v0, v1, :cond_3

    .line 9
    .line 10
    if-ne v0, v4, :cond_5

    .line 11
    .line 12
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$0:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, LX/1AM;

    .line 15
    .line 16
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$drawn:LX/2ss;

    .line 20
    .line 21
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/high16 v0, 0x3f800000    # 1.0f

    .line 26
    .line 27
    cmpg-float v0, v1, v0

    .line 28
    .line 29
    if-gez v0, :cond_4

    .line 30
    .line 31
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$drawn:LX/2ss;

    .line 32
    .line 33
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->$current$delegate:LX/16A;

    .line 34
    .line 35
    new-instance v1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;

    .line 36
    .line 37
    invoke-direct {v1, v2, v3, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;-><init>(LX/1AM;LX/2ss;LX/16A;)V

    .line 38
    .line 39
    .line 40
    iput-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$0:Ljava/lang/Object;

    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$1:Ljava/lang/Object;

    .line 44
    .line 45
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->label:I

    .line 46
    .line 47
    invoke-static {v1, p0}, LX/39q;->A01(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-ne v0, v5, :cond_0

    .line 52
    .line 53
    :cond_1
    return-object v5

    .line 54
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    new-instance v3, LX/1AM;

    .line 58
    .line 59
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 60
    .line 61
    .line 62
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;

    .line 63
    .line 64
    iput-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$0:Ljava/lang/Object;

    .line 65
    .line 66
    iput-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$1:Ljava/lang/Object;

    .line 67
    .line 68
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->label:I

    .line 69
    .line 70
    invoke-static {v0, p0}, LX/39q;->A01(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    if-eq p1, v5, :cond_1

    .line 75
    .line 76
    move-object v2, v3

    .line 77
    goto :goto_1

    .line 78
    :cond_3
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$1:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v3, LX/1AM;

    .line 81
    .line 82
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;->L$0:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v2, LX/1AM;

    .line 85
    .line 86
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :goto_1
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 90
    .line 91
    .line 92
    move-result-wide v0

    .line 93
    iput-wide v0, v3, LX/1AM;->element:J

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_4
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 97
    .line 98
    return-object v5

    .line 99
    :cond_5
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    throw v0
.end method
