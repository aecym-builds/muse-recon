.class public final Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;

.field public static lambda$-1452433275:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationWhyConfirmSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public static lambda$2099004224:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationHowSelfiesWorkSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public static lambda$614631779:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationHowIdWorksSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public static lambda$718351902:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationIdTipsSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$2099004224$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$2099004224$1;

    .line 8
    .line 9
    const v0, 0x7d1c4340

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$2099004224:LX/JDQ;

    .line 18
    .line 19
    const v1, 0x2ad12e1e

    .line 20
    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$718351902$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$718351902$1;

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$718351902:LX/JDQ;

    .line 29
    .line 30
    const v1, 0x24a28963

    .line 31
    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$614631779$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$614631779$1;

    .line 34
    .line 35
    invoke-static {v0, v1, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$614631779:LX/JDQ;

    .line 40
    .line 41
    const v1, -0x56925f7b

    .line 42
    .line 43
    .line 44
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$-1452433275$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt$lambda$-1452433275$1;

    .line 45
    .line 46
    invoke-static {v0, v1, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$-1452433275:LX/JDQ;

    .line 51
    .line 52
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getLambda$-1452433275$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl()LX/JDQ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationWhyConfirmSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$-1452433275:LX/JDQ;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLambda$2099004224$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl()LX/JDQ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationHowSelfiesWorkSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$2099004224:LX/JDQ;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLambda$614631779$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl()LX/JDQ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationHowIdWorksSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$614631779:LX/JDQ;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLambda$718351902$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_impl_impl()LX/JDQ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDQ<",
            "Lcom/facebook/aura/navigation/key/AgeVerificationIdTipsSheetKey;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$AgeStepInfoSheetKt;->lambda$718351902:LX/JDQ;

    .line 1
    .line 2
    return-object p0
.end method
