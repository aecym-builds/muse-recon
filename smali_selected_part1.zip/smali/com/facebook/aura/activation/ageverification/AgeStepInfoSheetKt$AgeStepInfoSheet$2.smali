.class public final Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 33

    .line 0
    move/from16 v4, p2

    .line 1
    .line 2
    and-int/lit8 v1, p2, 0x3

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v11, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    move-object/from16 v3, p1

    .line 12
    .line 13
    invoke-static {v0, v3, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    const v0, 0x7f120095

    .line 20
    .line 21
    .line 22
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    sget-object v1, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 27
    .line 28
    const/16 v0, 0x30

    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    invoke-virtual {v1, v4, v3, v0, v2}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 32
    .line 33
    .line 34
    move-result-object v8

    .line 35
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 36
    .line 37
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 38
    .line 39
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 40
    .line 41
    invoke-static {v2, v1, v0}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 42
    .line 43
    .line 44
    move-result-object v7

    .line 45
    move-object/from16 v2, p0

    .line 46
    .line 47
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 48
    .line 49
    invoke-interface {v3, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    iget-object v2, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 54
    .line 55
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-nez v1, :cond_0

    .line 60
    .line 61
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 62
    .line 63
    if-ne v0, v1, :cond_1

    .line 64
    .line 65
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2$1$1;

    .line 66
    .line 67
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 68
    .line 69
    .line 70
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    :cond_1
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 74
    .line 75
    const p2, 0x7ffbfe5

    .line 76
    .line 77
    .line 78
    move-object v6, v4

    .line 79
    move-object v9, v4

    .line 80
    move-object v10, v4

    .line 81
    move v12, v11

    .line 82
    move v13, v11

    .line 83
    move v14, v11

    .line 84
    move v15, v11

    .line 85
    move-object/from16 v16, v4

    .line 86
    .line 87
    move-object/from16 v17, v4

    .line 88
    .line 89
    move-object/from16 v18, v0

    .line 90
    .line 91
    move-object/from16 v19, v4

    .line 92
    .line 93
    move-object/from16 v20, v4

    .line 94
    .line 95
    move-object/from16 v21, v4

    .line 96
    .line 97
    move-object/from16 v22, v4

    .line 98
    .line 99
    move-object/from16 v23, v4

    .line 100
    .line 101
    move-object/from16 v24, v4

    .line 102
    .line 103
    move-object/from16 v25, v4

    .line 104
    .line 105
    move-object/from16 v26, v4

    .line 106
    .line 107
    move/from16 v27, v11

    .line 108
    .line 109
    move/from16 v28, v11

    .line 110
    .line 111
    move/from16 v29, v11

    .line 112
    .line 113
    move/from16 v30, v11

    .line 114
    .line 115
    move-object/from16 v31, v3

    .line 116
    .line 117
    move/from16 v32, v11

    .line 118
    .line 119
    move/from16 p0, v11

    .line 120
    .line 121
    move/from16 p1, v11

    .line 122
    .line 123
    invoke-static/range {v4 .. v35}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_2
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 128
    .line 129
    .line 130
    return-void
.end method
