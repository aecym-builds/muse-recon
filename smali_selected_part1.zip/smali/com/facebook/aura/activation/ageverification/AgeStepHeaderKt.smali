.class public abstract Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final AGE_STEP_LINK_TAG:Ljava/lang/String; = "age_step_link"


# direct methods
.method public static final AgeStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2hg;LX/2hg;LX/2d4;II)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "LX/2hg;",
            "LX/2hg;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v21, p2

    .line 1
    .line 2
    move-object/from16 v20, p3

    .line 3
    .line 4
    move/from16 v19, p5

    .line 5
    .line 6
    move-object/from16 p5, p6

    .line 7
    .line 8
    move-object/from16 v18, p7

    .line 9
    .line 10
    move-object/from16 v3, p4

    .line 11
    .line 12
    const/4 v9, 0x0

    .line 13
    move-object/from16 p7, p0

    .line 14
    .line 15
    move-object/from16 p6, p1

    .line 16
    .line 17
    move-object/from16 v1, p7

    .line 18
    .line 19
    move-object/from16 v0, p6

    .line 20
    .line 21
    invoke-static {v1, v0}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v17

    .line 25
    const v0, -0x1c9793ca

    .line 26
    .line 27
    .line 28
    move-object/from16 v1, p8

    .line 29
    .line 30
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 31
    .line 32
    .line 33
    move/from16 v2, p9

    .line 34
    .line 35
    and-int/lit8 v0, p9, 0x6

    .line 36
    .line 37
    if-nez v0, :cond_1b

    .line 38
    .line 39
    move-object/from16 v0, p7

    .line 40
    .line 41
    invoke-static {v1, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    or-int v7, v7, p9

    .line 46
    .line 47
    :goto_0
    and-int/lit8 v0, p9, 0x30

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    move-object/from16 v0, p6

    .line 52
    .line 53
    invoke-static {v1, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    or-int/2addr v7, v0

    .line 58
    :cond_0
    move/from16 v0, p10

    .line 59
    .line 60
    and-int/lit8 v12, p10, 0x4

    .line 61
    .line 62
    if-eqz v12, :cond_1a

    .line 63
    .line 64
    or-int/lit16 v7, v7, 0x180

    .line 65
    .line 66
    :cond_1
    :goto_1
    and-int/lit8 v11, p10, 0x8

    .line 67
    .line 68
    if-eqz v11, :cond_19

    .line 69
    .line 70
    or-int/lit16 v7, v7, 0xc00

    .line 71
    .line 72
    :cond_2
    :goto_2
    and-int/lit8 v10, p10, 0x10

    .line 73
    .line 74
    if-eqz v10, :cond_18

    .line 75
    .line 76
    or-int/lit16 v7, v7, 0x6000

    .line 77
    .line 78
    :cond_3
    :goto_3
    and-int/lit8 v8, p10, 0x20

    .line 79
    .line 80
    const/high16 v4, 0x30000

    .line 81
    .line 82
    if-nez v8, :cond_4

    .line 83
    .line 84
    and-int v4, p9, v4

    .line 85
    .line 86
    if-nez v4, :cond_5

    .line 87
    .line 88
    move/from16 v4, v19

    .line 89
    .line 90
    invoke-static {v1, v4}, LX/004;->A0n(LX/2d4;Z)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    :cond_4
    or-int/2addr v7, v4

    .line 95
    :cond_5
    const/high16 v4, 0x180000

    .line 96
    .line 97
    and-int v4, p9, v4

    .line 98
    .line 99
    if-nez v4, :cond_8

    .line 100
    .line 101
    and-int/lit8 v4, p10, 0x40

    .line 102
    .line 103
    if-nez v4, :cond_6

    .line 104
    .line 105
    move-object/from16 v4, p5

    .line 106
    .line 107
    invoke-interface {v1, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v5

    .line 111
    const/high16 v4, 0x100000

    .line 112
    .line 113
    if-nez v5, :cond_7

    .line 114
    .line 115
    :cond_6
    const/high16 v4, 0x80000

    .line 116
    .line 117
    :cond_7
    or-int/2addr v7, v4

    .line 118
    :cond_8
    const/high16 v4, 0xc00000

    .line 119
    .line 120
    and-int v4, p9, v4

    .line 121
    .line 122
    if-nez v4, :cond_b

    .line 123
    .line 124
    and-int/lit16 v4, v0, 0x80

    .line 125
    .line 126
    if-nez v4, :cond_9

    .line 127
    .line 128
    move-object/from16 v4, v18

    .line 129
    .line 130
    invoke-interface {v1, v4}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v5

    .line 134
    const/high16 v4, 0x800000

    .line 135
    .line 136
    if-nez v5, :cond_a

    .line 137
    .line 138
    :cond_9
    const/high16 v4, 0x400000

    .line 139
    .line 140
    :cond_a
    or-int/2addr v7, v4

    .line 141
    :cond_b
    invoke-static {v7}, LX/009;->A1J(I)Z

    .line 142
    .line 143
    .line 144
    move-result v4

    .line 145
    invoke-static {v4, v1, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 146
    .line 147
    .line 148
    move-result v4

    .line 149
    if-eqz v4, :cond_1c

    .line 150
    .line 151
    invoke-interface {v1}, LX/2d4;->AgT()V

    .line 152
    .line 153
    .line 154
    and-int/lit8 v4, p9, 0x1

    .line 155
    .line 156
    const v6, -0x380001

    .line 157
    .line 158
    .line 159
    const v5, -0x1c00001

    .line 160
    .line 161
    .line 162
    if-eqz v4, :cond_11

    .line 163
    .line 164
    invoke-interface {v1}, LX/2d4;->AEs()Z

    .line 165
    .line 166
    .line 167
    move-result v4

    .line 168
    if-nez v4, :cond_11

    .line 169
    .line 170
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 171
    .line 172
    .line 173
    and-int/lit8 v4, p10, 0x40

    .line 174
    .line 175
    if-eqz v4, :cond_c

    .line 176
    .line 177
    and-int/2addr v7, v6

    .line 178
    :cond_c
    and-int/lit16 v4, v0, 0x80

    .line 179
    .line 180
    if-eqz v4, :cond_d

    .line 181
    .line 182
    :goto_4
    and-int/2addr v7, v5

    .line 183
    :cond_d
    invoke-interface {v1}, LX/2d4;->AAf()V

    .line 184
    .line 185
    .line 186
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 187
    .line 188
    invoke-static {v1, v8}, LX/07H;->A07(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 189
    .line 190
    .line 191
    move-result-wide v5

    .line 192
    shr-int/lit8 v16, v7, 0xc

    .line 193
    .line 194
    invoke-static {v1, v3}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 195
    .line 196
    .line 197
    move-result-object v11

    .line 198
    invoke-static {v7}, LX/005;->A1H(I)Z

    .line 199
    .line 200
    .line 201
    move-result v10

    .line 202
    invoke-static {v7}, LX/005;->A1L(I)Z

    .line 203
    .line 204
    .line 205
    move-result v4

    .line 206
    or-int/2addr v4, v10

    .line 207
    invoke-static {v1, v5, v6, v4}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 208
    .line 209
    .line 210
    move-result v10

    .line 211
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v4

    .line 215
    if-nez v10, :cond_e

    .line 216
    .line 217
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 218
    .line 219
    if-ne v4, v10, :cond_f

    .line 220
    .line 221
    :cond_e
    if-nez v20, :cond_10

    .line 222
    .line 223
    invoke-static/range {p6 .. p6}, LX/002;->A0e(Ljava/lang/String;)LX/2iK;

    .line 224
    .line 225
    .line 226
    move-result-object v4

    .line 227
    :goto_5
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    :cond_f
    check-cast v4, LX/2iK;

    .line 231
    .line 232
    invoke-static/range {v21 .. v21}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 233
    .line 234
    .line 235
    move-result-object v10

    .line 236
    sget v12, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 237
    .line 238
    invoke-static {v12}, LX/Dn6;->A00(F)LX/CP5;

    .line 239
    .line 240
    .line 241
    move-result-object v6

    .line 242
    sget-object v5, LX/2Id;->A00:LX/2sS;

    .line 243
    .line 244
    invoke-static {v6, v1, v5}, LX/002;->A0d(LX/Dps;LX/2d4;LX/2sS;)LX/3BI;

    .line 245
    .line 246
    .line 247
    move-result-object v15

    .line 248
    move-object v5, v1

    .line 249
    check-cast v5, LX/J7I;

    .line 250
    .line 251
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 252
    .line 253
    .line 254
    move-result v14

    .line 255
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 256
    .line 257
    .line 258
    move-result-object v13

    .line 259
    invoke-static {v1, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 260
    .line 261
    .line 262
    move-result-object v11

    .line 263
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 264
    .line 265
    iget-object v6, v5, LX/J7I;->A0V:LX/3DJ;

    .line 266
    .line 267
    if-nez v6, :cond_1d

    .line 268
    .line 269
    invoke-static {}, LX/1VY;->A00()V

    .line 270
    .line 271
    .line 272
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    throw v0

    .line 277
    :cond_10
    new-instance v4, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$bodyText$1$1;

    .line 278
    .line 279
    invoke-direct {v4, v11}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$bodyText$1$1;-><init>(LX/16A;)V

    .line 280
    .line 281
    .line 282
    const-string v14, "age_step_link"

    .line 283
    .line 284
    move-object/from16 v10, p6

    .line 285
    .line 286
    move-object/from16 v11, v20

    .line 287
    .line 288
    move-wide v12, v5

    .line 289
    move-object v15, v4

    .line 290
    invoke-static/range {v10 .. v15}, Lcom/facebook/aura/linktext/HatchInlineLinkTextKt;->buildInlineLinkText-XO-JAsU(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Lkotlin/jvm/functions/Function0;)LX/2iK;

    .line 291
    .line 292
    .line 293
    move-result-object v4

    .line 294
    goto :goto_5

    .line 295
    :cond_11
    if-eqz v12, :cond_12

    .line 296
    .line 297
    sget-object v21, LX/3C1;->A00:LX/3Cb;

    .line 298
    .line 299
    :cond_12
    if-eqz v11, :cond_13

    .line 300
    .line 301
    const/16 v20, 0x0

    .line 302
    .line 303
    :cond_13
    if-eqz v10, :cond_15

    .line 304
    .line 305
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object v3

    .line 309
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 310
    .line 311
    if-ne v3, v4, :cond_14

    .line 312
    .line 313
    sget-object v3, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$1$1;

    .line 314
    .line 315
    invoke-interface {v1, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    :cond_14
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 319
    .line 320
    :cond_15
    if-eqz v8, :cond_16

    .line 321
    .line 322
    const/16 v19, 0x0

    .line 323
    .line 324
    :cond_16
    and-int/lit8 v4, p10, 0x40

    .line 325
    .line 326
    if-eqz v4, :cond_17

    .line 327
    .line 328
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 329
    .line 330
    invoke-static {v4, v1}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v4

    .line 334
    check-cast v4, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 335
    .line 336
    iget-object v4, v4, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 337
    .line 338
    move-object/from16 p5, v4

    .line 339
    .line 340
    and-int/2addr v7, v6

    .line 341
    :cond_17
    and-int/lit16 v4, v0, 0x80

    .line 342
    .line 343
    if-eqz v4, :cond_d

    .line 344
    .line 345
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 346
    .line 347
    invoke-static {v1, v4}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 348
    .line 349
    .line 350
    move-result-object v18

    .line 351
    goto/16 :goto_4

    .line 352
    .line 353
    :cond_18
    and-int/lit16 v4, v2, 0x6000

    .line 354
    .line 355
    if-nez v4, :cond_3

    .line 356
    .line 357
    invoke-static {v1, v3}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 358
    .line 359
    .line 360
    move-result v4

    .line 361
    or-int/2addr v7, v4

    .line 362
    goto/16 :goto_3

    .line 363
    .line 364
    :cond_19
    and-int/lit16 v4, v2, 0xc00

    .line 365
    .line 366
    if-nez v4, :cond_2

    .line 367
    .line 368
    move-object/from16 v4, v20

    .line 369
    .line 370
    invoke-static {v1, v4}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 371
    .line 372
    .line 373
    move-result v4

    .line 374
    or-int/2addr v7, v4

    .line 375
    goto/16 :goto_2

    .line 376
    .line 377
    :cond_1a
    and-int/lit16 v4, v2, 0x180

    .line 378
    .line 379
    if-nez v4, :cond_1

    .line 380
    .line 381
    move-object/from16 v4, v21

    .line 382
    .line 383
    invoke-static {v1, v4}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 384
    .line 385
    .line 386
    move-result v4

    .line 387
    or-int/2addr v7, v4

    .line 388
    goto/16 :goto_1

    .line 389
    .line 390
    :cond_1b
    move v7, v2

    .line 391
    goto/16 :goto_0

    .line 392
    .line 393
    :cond_1c
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 394
    .line 395
    .line 396
    goto/16 :goto_7

    .line 397
    .line 398
    :cond_1d
    invoke-static {v1, v5, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 399
    .line 400
    .line 401
    invoke-static {v1, v15, v13, v11, v14}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 402
    .line 403
    .line 404
    if-eqz v19, :cond_20

    .line 405
    .line 406
    const v6, 0xcd43780

    .line 407
    .line 408
    .line 409
    invoke-static {v1, v6}, LX/001;->A0V(LX/2d4;I)LX/3Cb;

    .line 410
    .line 411
    .line 412
    move-result-object v10

    .line 413
    const/4 v6, 0x0

    .line 414
    invoke-static {v10, v6, v6, v6, v12}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 415
    .line 416
    .line 417
    move-result-object v6

    .line 418
    invoke-static {v6, v1, v9, v9}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt;->AgeStepLogo(LX/3C1;LX/2d4;II)V

    .line 419
    .line 420
    .line 421
    :goto_6
    invoke-static {v5, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 422
    .line 423
    .line 424
    invoke-static {v1, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 425
    .line 426
    .line 427
    move-result-wide v26

    .line 428
    const/4 v12, 0x3

    .line 429
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 430
    .line 431
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    move-result-object v10

    .line 435
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 436
    .line 437
    if-ne v10, v6, :cond_1e

    .line 438
    .line 439
    sget-object v10, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$2$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$2$1$1;

    .line 440
    .line 441
    invoke-interface {v1, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 442
    .line 443
    .line 444
    :cond_1e
    check-cast v10, LX/JDM;

    .line 445
    .line 446
    const/16 v23, 0x0

    .line 447
    .line 448
    invoke-static {v11, v10, v9}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 449
    .line 450
    .line 451
    move-result-object v25

    .line 452
    invoke-static {v12}, LX/2wS;->A01(I)LX/2wS;

    .line 453
    .line 454
    .line 455
    move-result-object v31

    .line 456
    and-int/lit8 p2, v7, 0xe

    .line 457
    .line 458
    shr-int/lit8 v6, v7, 0x9

    .line 459
    .line 460
    and-int/lit16 v6, v6, 0x1c00

    .line 461
    .line 462
    or-int p2, p2, v6

    .line 463
    .line 464
    const/16 p4, 0x3fb0

    .line 465
    .line 466
    move-object/from16 v24, p7

    .line 467
    .line 468
    move-object/from16 v28, p5

    .line 469
    .line 470
    move-object/from16 v29, v23

    .line 471
    .line 472
    move-object/from16 v30, v23

    .line 473
    .line 474
    move/from16 v32, v9

    .line 475
    .line 476
    move/from16 v33, v9

    .line 477
    .line 478
    move/from16 v34, v9

    .line 479
    .line 480
    move/from16 v35, v9

    .line 481
    .line 482
    move-object/from16 v36, v23

    .line 483
    .line 484
    move-object/from16 v37, v23

    .line 485
    .line 486
    move-object/from16 p0, v23

    .line 487
    .line 488
    move-object/from16 p1, v1

    .line 489
    .line 490
    move/from16 p3, v9

    .line 491
    .line 492
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 493
    .line 494
    .line 495
    invoke-static {v1, v8}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 496
    .line 497
    .line 498
    move-result-wide v24

    .line 499
    invoke-static {v12}, LX/2wS;->A01(I)LX/2wS;

    .line 500
    .line 501
    .line 502
    move-result-object v29

    .line 503
    move/from16 v6, v16

    .line 504
    .line 505
    and-int/lit16 v6, v6, 0x1c00

    .line 506
    .line 507
    const/16 p4, 0x7fb2

    .line 508
    .line 509
    const-wide/16 v30, 0x0

    .line 510
    .line 511
    move-object/from16 v26, v18

    .line 512
    .line 513
    move-object/from16 v27, v23

    .line 514
    .line 515
    move-object/from16 v28, v23

    .line 516
    .line 517
    move/from16 p2, v6

    .line 518
    .line 519
    move-object/from16 v22, v4

    .line 520
    .line 521
    invoke-static/range {v22 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 522
    .line 523
    .line 524
    move/from16 v4, v17

    .line 525
    .line 526
    invoke-static {v5, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 527
    .line 528
    .line 529
    :goto_7
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 530
    .line 531
    .line 532
    move-result-object v4

    .line 533
    if-eqz v4, :cond_1f

    .line 534
    .line 535
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$3;

    .line 536
    .line 537
    move-object v5, v1

    .line 538
    move-object/from16 v6, p7

    .line 539
    .line 540
    move-object/from16 v7, p6

    .line 541
    .line 542
    move-object/from16 v8, v21

    .line 543
    .line 544
    move-object/from16 v9, v20

    .line 545
    .line 546
    move-object v10, v3

    .line 547
    move/from16 v11, v19

    .line 548
    .line 549
    move-object/from16 v12, p5

    .line 550
    .line 551
    move-object/from16 v13, v18

    .line 552
    .line 553
    move v14, v2

    .line 554
    move v15, v0

    .line 555
    invoke-direct/range {v5 .. v15}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepHeader$3;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2hg;LX/2hg;II)V

    .line 556
    .line 557
    .line 558
    iput-object v1, v4, LX/J7V;->A06:LX/JDN;

    .line 559
    .line 560
    :cond_1f
    return-void

    .line 561
    :cond_20
    const v6, -0x724c844a

    .line 562
    .line 563
    .line 564
    invoke-interface {v1, v6}, LX/2d4;->Agj(I)V

    .line 565
    .line 566
    .line 567
    goto/16 :goto_6
.end method

.method public static final AgeStepHeader$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final AgeStepLogo(LX/3C1;LX/2d4;II)V
    .locals 5

    .line 0
    const v0, 0x4a86d70d    # 4418438.5f

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v4, p3, 0x1

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    if-eqz v4, :cond_3

    .line 10
    .line 11
    or-int/lit8 v0, p2, 0x6

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v1, v0, 0x3

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-static {v1, v3}, LX/003;->A1H(II)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-static {v1, p1, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    if-eqz v4, :cond_0

    .line 27
    .line 28
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 29
    .line 30
    :cond_0
    const v0, 0x7f0801e0

    .line 31
    .line 32
    .line 33
    invoke-static {p1, v0, v2}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    const/high16 v0, 0x42800000    # 64.0f

    .line 38
    .line 39
    invoke-static {p0, v0}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sget v0, LX/2l9;->$stable:I

    .line 44
    .line 45
    or-int/lit8 v0, v0, 0x30

    .line 46
    .line 47
    invoke-static {p1, v1, v2, v0}, LX/1oV;->A02(LX/2d4;LX/3C1;LX/2l9;I)V

    .line 48
    .line 49
    .line 50
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    if-eqz v1, :cond_1

    .line 55
    .line 56
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepLogo$1;

    .line 57
    .line 58
    invoke-direct {v0, p0, p2, p3}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt$AgeStepLogo$1;-><init>(LX/3C1;II)V

    .line 59
    .line 60
    .line 61
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 62
    .line 63
    :cond_1
    return-void

    .line 64
    :cond_2
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 69
    .line 70
    if-nez v0, :cond_4

    .line 71
    .line 72
    invoke-static {p1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    or-int/2addr v0, p2

    .line 77
    goto :goto_0

    .line 78
    :cond_4
    move v0, p2

    .line 79
    goto :goto_0
.end method

.method public static final synthetic access$AgeStepHeader$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
