.class public final Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.SelfieOverlayKt$completionFlash$1$1"
    f = "SelfieOverlay.kt"
    l = {
        0x54,
        0x55
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $flash:LX/Dvf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(LX/Dvf;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Dvf<",
            "Ljava/lang/Float;",
            "LX/DwT;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->$flash:LX/Dvf;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->$flash:LX/Dvf;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;-><init>(LX/Dvf;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->$flash:LX/Dvf;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;-><init>(LX/Dvf;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->label:I

    .line 3
    .line 4
    const/4 v5, 0x2

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-eq v1, v0, :cond_2

    .line 9
    .line 10
    if-ne v1, v5, :cond_4

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 16
    .line 17
    return-object v6

    .line 18
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->label:I

    .line 22
    .line 23
    const-wide/16 v0, 0x190

    .line 24
    .line 25
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    if-ne v0, v6, :cond_3

    .line 30
    .line 31
    return-object v6

    .line 32
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_3
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->$flash:LX/Dvf;

    .line 36
    .line 37
    invoke-static {}, LX/007;->A0q()Ljava/lang/Float;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    const/4 v2, 0x0

    .line 42
    const/16 v1, 0xc8

    .line 43
    .line 44
    const/4 v0, 0x0

    .line 45
    invoke-static {v1, v0}, LX/002;->A0T(II)LX/E1b;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    iput v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;->label:I

    .line 50
    .line 51
    invoke-static {v4, v0, v3, p0, v2}, LX/002;->A0s(LX/Dvf;LX/DwJ;Ljava/lang/Object;LX/2M4;LX/JDM;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    if-ne v0, v6, :cond_0

    .line 56
    .line 57
    return-object v6

    .line 58
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    throw v0
.end method
