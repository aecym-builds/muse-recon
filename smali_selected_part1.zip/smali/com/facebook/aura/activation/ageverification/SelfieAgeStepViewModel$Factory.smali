.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final context:Landroid/content/Context;

.field public final userId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;->context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;->userId:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;->create()Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;->context:Landroid/content/Context;

    .line 1
    .line 2
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;->userId:Ljava/lang/String;

    .line 10
    .line 11
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 12
    .line 13
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method
