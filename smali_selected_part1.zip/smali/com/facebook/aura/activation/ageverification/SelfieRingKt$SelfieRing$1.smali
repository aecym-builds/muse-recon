.class public final Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $current$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $flashes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $progress:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $view:LX/FCr;


# direct methods
.method public constructor <init>(LX/FCr;LX/16A;LX/Ddn;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/FCr;",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$view:LX/FCr;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$progress:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$flashes:LX/Ddn;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$current$delegate:LX/16A;

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/33K;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->invoke(LX/33K;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 18

    .line 0
    const/4 v9, 0x0

    .line 1
    move-object/from16 v14, p1

    .line 2
    .line 3
    invoke-static {v14, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    and-int/lit8 v0, p3, 0x6

    .line 7
    .line 8
    move-object/from16 v11, p2

    .line 9
    .line 10
    if-nez v0, :cond_6

    .line 11
    .line 12
    invoke-static {v11, v14}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    or-int v0, v0, p3

    .line 17
    .line 18
    :goto_0
    invoke-static {v0}, LX/005;->A1G(I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-static {v1, v11, v0}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_9

    .line 27
    .line 28
    move-object/from16 v1, p0

    .line 29
    .line 30
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$view:LX/FCr;

    .line 31
    .line 32
    invoke-interface {v11, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    iget-object v4, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$view:LX/FCr;

    .line 37
    .line 38
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    if-nez v2, :cond_0

    .line 43
    .line 44
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 45
    .line 46
    if-ne v3, v2, :cond_1

    .line 47
    .line 48
    :cond_0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$1$1;

    .line 49
    .line 50
    invoke-direct {v3, v4}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$1$1;-><init>(LX/FCr;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {v11, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :cond_1
    check-cast v3, LX/JDM;

    .line 57
    .line 58
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    const/4 v10, 0x0

    .line 61
    sget-object v8, LX/2sI;->A01:LX/2wD;

    .line 62
    .line 63
    const/16 v13, 0x30

    .line 64
    .line 65
    const/16 p3, 0x4

    .line 66
    .line 67
    move-object v15, v11

    .line 68
    move-object/from16 v16, v8

    .line 69
    .line 70
    move-object/from16 v17, v3

    .line 71
    .line 72
    move-object/from16 p0, v10

    .line 73
    .line 74
    move/from16 p1, v13

    .line 75
    .line 76
    move/from16 p2, p3

    .line 77
    .line 78
    invoke-static/range {v15 .. v20}, LX/39N;->A03(LX/2d4;LX/3C1;LX/JDM;LX/JDM;II)V

    .line 79
    .line 80
    .line 81
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$current$delegate:LX/16A;

    .line 82
    .line 83
    invoke-interface {v3}, LX/16A;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    check-cast v5, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 88
    .line 89
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$progress:LX/16A;

    .line 90
    .line 91
    invoke-interface {v11, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v3

    .line 95
    iget-object v4, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$progress:LX/16A;

    .line 96
    .line 97
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v6

    .line 101
    if-nez v3, :cond_2

    .line 102
    .line 103
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 104
    .line 105
    if-ne v6, v3, :cond_3

    .line 106
    .line 107
    :cond_2
    new-instance v6, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$2$1;

    .line 108
    .line 109
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$2$1;-><init>(LX/16A;)V

    .line 110
    .line 111
    .line 112
    invoke-interface {v11, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :cond_3
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    iget-object v7, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$flashes:LX/Ddn;

    .line 118
    .line 119
    sget v3, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->$stable:I

    .line 120
    .line 121
    shl-int/lit8 v3, v3, 0x6

    .line 122
    .line 123
    or-int/lit16 v12, v3, 0xc00

    .line 124
    .line 125
    invoke-static/range {v5 .. v13}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SelfieMovementOverlay(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 126
    .line 127
    .line 128
    const v3, 0x6908a1c8

    .line 129
    .line 130
    .line 131
    invoke-interface {v11, v3}, LX/2d4;->Agj(I)V

    .line 132
    .line 133
    .line 134
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$flashes:LX/Ddn;

    .line 135
    .line 136
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 137
    .line 138
    .line 139
    move-result-object v6

    .line 140
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 141
    .line 142
    .line 143
    move-result v3

    .line 144
    if-eqz v3, :cond_7

    .line 145
    .line 146
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v5

    .line 150
    check-cast v5, Lcom/facebook/aura/activation/ageverification/CompletionFlash;

    .line 151
    .line 152
    iget-object v15, v5, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->direction:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 153
    .line 154
    invoke-interface {v11, v5}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v4

    .line 158
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v3

    .line 162
    if-nez v4, :cond_4

    .line 163
    .line 164
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 165
    .line 166
    if-ne v3, v4, :cond_5

    .line 167
    .line 168
    :cond_4
    new-instance v3, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$3$1$1;

    .line 169
    .line 170
    invoke-direct {v3, v5}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1$3$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/CompletionFlash;)V

    .line 171
    .line 172
    .line 173
    invoke-interface {v11, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    :cond_5
    invoke-static {v2, v3}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 177
    .line 178
    .line 179
    move-result-object v17

    .line 180
    and-int/lit8 v3, v0, 0xe

    .line 181
    .line 182
    or-int/lit16 v3, v3, 0x180

    .line 183
    .line 184
    const/16 v16, 0x1

    .line 185
    .line 186
    move-object/from16 p0, v11

    .line 187
    .line 188
    move/from16 p1, v3

    .line 189
    .line 190
    move/from16 p2, v9

    .line 191
    .line 192
    invoke-static/range {v14 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieMovementChipKt;->SelfieMovementChip(LX/33K;Lcom/facebook/aura/activation/ageverification/HeadMovement;ZLX/3C1;LX/2d4;II)V

    .line 193
    .line 194
    .line 195
    goto :goto_1

    .line 196
    :cond_6
    move/from16 v0, p3

    .line 197
    .line 198
    goto/16 :goto_0

    .line 199
    .line 200
    :cond_7
    invoke-static {v11}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;->$current$delegate:LX/16A;

    .line 205
    .line 206
    invoke-interface {v1}, LX/16A;->getValue()Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v16

    .line 210
    check-cast v16, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 211
    .line 212
    if-nez v16, :cond_8

    .line 213
    .line 214
    const v0, -0x47f19c44

    .line 215
    .line 216
    .line 217
    invoke-interface {v11, v0}, LX/2d4;->Agj(I)V

    .line 218
    .line 219
    .line 220
    :goto_2
    invoke-static {v2, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 221
    .line 222
    .line 223
    return-void

    .line 224
    :cond_8
    const v1, -0x47f19c43

    .line 225
    .line 226
    .line 227
    invoke-interface {v11, v1}, LX/2d4;->Agj(I)V

    .line 228
    .line 229
    .line 230
    and-int/lit8 v0, v0, 0xe

    .line 231
    .line 232
    or-int/lit16 v0, v0, 0x180

    .line 233
    .line 234
    move-object v15, v14

    .line 235
    move/from16 v17, v9

    .line 236
    .line 237
    move-object/from16 p0, v10

    .line 238
    .line 239
    move-object/from16 p1, v11

    .line 240
    .line 241
    move/from16 p2, v0

    .line 242
    .line 243
    invoke-static/range {v15 .. v21}, Lcom/facebook/aura/activation/ageverification/SelfieMovementChipKt;->SelfieMovementChip(LX/33K;Lcom/facebook/aura/activation/ageverification/HeadMovement;ZLX/3C1;LX/2d4;II)V

    .line 244
    .line 245
    .line 246
    goto :goto_2

    .line 247
    :cond_9
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 248
    .line 249
    .line 250
    return-void
.end method
