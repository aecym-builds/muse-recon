.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public final sinceMs:J

.field public final takingLonger:Z


# direct methods
.method public constructor <init>(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-wide p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 8
    .line 9
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 10
    .line 11
    iput-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;ZILX/04f;)V
    .locals 1

    .line 268435456
    invoke-static {p5, p4}, LX/006;->A1X(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-direct {p0, p1, p2, p3, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;-><init>(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;ZILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-wide p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->copy(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method


# virtual methods
.method public final component1()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final component2()Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;
    .locals 0

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p3, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;-><init>(JLcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;Z)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    .line 0
    const/4 v6, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 9
    .line 10
    iget-wide v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 11
    .line 12
    iget-wide v1, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 13
    .line 14
    cmp-long v0, v3, v1

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 19
    .line 20
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 21
    .line 22
    if-ne v1, v0, :cond_0

    .line 23
    .line 24
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 25
    .line 26
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 27
    .line 28
    if-eq v1, v0, :cond_1

    .line 29
    .line 30
    :cond_0
    return v5

    .line 31
    :cond_1
    return v6
.end method

.method public final getMethod()Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSinceMs()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getTakingLonger()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 1
    .line 2
    invoke-static {v0, v1}, LX/002;->A0H(J)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 15
    .line 16
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
