.class public final Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $learnMore:Ljava/lang/String;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $onLearnMore:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $selected:Lcom/facebook/aura/activation/ageverification/IdDocument;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$learnMore:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$onLearnMore:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$onSelect:LX/JDM;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 20

    .line 0
    move/from16 v3, p2

    .line 1
    .line 2
    and-int/lit8 v1, p2, 0x3

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v15, 0x0

    .line 7
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    move-object/from16 v14, p1

    .line 12
    .line 13
    invoke-static {v0, v14, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_6

    .line 18
    .line 19
    const v0, 0x7f12007a

    .line 20
    .line 21
    .line 22
    invoke-static {v14, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v9

    .line 26
    const v1, 0x7f120075

    .line 27
    .line 28
    .line 29
    move-object/from16 v3, p0

    .line 30
    .line 31
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$learnMore:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v14, v0, v1}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v10

    .line 37
    iget-object v12, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$learnMore:Ljava/lang/String;

    .line 38
    .line 39
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$onLearnMore:Lkotlin/jvm/functions/Function0;

    .line 40
    .line 41
    invoke-interface {v14, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    iget-object v0, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 46
    .line 47
    invoke-static {v14, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    iget-object v4, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$onLearnMore:Lkotlin/jvm/functions/Function0;

    .line 52
    .line 53
    iget-object v1, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 54
    .line 55
    invoke-interface {v14}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v13

    .line 59
    if-nez v0, :cond_0

    .line 60
    .line 61
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 62
    .line 63
    if-ne v13, v0, :cond_1

    .line 64
    .line 65
    :cond_0
    new-instance v13, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1$1$1;

    .line 66
    .line 67
    invoke-direct {v13, v4, v1}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 68
    .line 69
    .line 70
    invoke-interface {v14, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    :cond_1
    check-cast v13, Lkotlin/jvm/functions/Function0;

    .line 74
    .line 75
    const/16 v16, 0x4

    .line 76
    .line 77
    const/4 v11, 0x0

    .line 78
    invoke-static/range {v9 .. v16}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 79
    .line 80
    .line 81
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 82
    .line 83
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 84
    .line 85
    const/4 v0, 0x6

    .line 86
    invoke-static {v1, v14, v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->outlined(LX/3C1;LX/2d4;I)LX/3C1;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-static {v0}, LX/6Ck;->A00(LX/3C1;)LX/3C1;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    iget-object v5, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$selected:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 95
    .line 96
    iget-object v4, v3, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentTypeContent$1;->$onSelect:LX/JDM;

    .line 97
    .line 98
    invoke-static {v14}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 99
    .line 100
    .line 101
    move-result-object v10

    .line 102
    move-object v3, v14

    .line 103
    check-cast v3, LX/J7I;

    .line 104
    .line 105
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 106
    .line 107
    .line 108
    move-result v9

    .line 109
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 110
    .line 111
    .line 112
    move-result-object v8

    .line 113
    invoke-static {v14, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 114
    .line 115
    .line 116
    move-result-object v7

    .line 117
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 118
    .line 119
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 120
    .line 121
    if-nez v0, :cond_2

    .line 122
    .line 123
    invoke-static {}, LX/1VY;->A00()V

    .line 124
    .line 125
    .line 126
    :goto_0
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    throw v0

    .line 131
    :cond_2
    invoke-static {v14, v3, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v14, v10, v8, v7, v9}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 135
    .line 136
    .line 137
    const v0, -0x39fe13e3

    .line 138
    .line 139
    .line 140
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 141
    .line 142
    .line 143
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/IdDocument;->getEntries()LX/0vk;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 148
    .line 149
    .line 150
    move-result-object v8

    .line 151
    const/4 v1, 0x0

    .line 152
    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-eqz v0, :cond_5

    .line 157
    .line 158
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v16

    .line 162
    add-int/lit8 v7, v1, 0x1

    .line 163
    .line 164
    if-gez v1, :cond_3

    .line 165
    .line 166
    invoke-static {}, LX/B8B;->A1A()V

    .line 167
    .line 168
    .line 169
    goto :goto_0

    .line 170
    :cond_3
    check-cast v16, Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 171
    .line 172
    if-lez v1, :cond_4

    .line 173
    .line 174
    const v0, 0x51cf969c

    .line 175
    .line 176
    .line 177
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 178
    .line 179
    .line 180
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 181
    .line 182
    const/high16 v0, 0x41c00000    # 24.0f

    .line 183
    .line 184
    add-float/2addr v0, v1

    .line 185
    add-float/2addr v0, v1

    .line 186
    invoke-static {v6, v0, v1}, LX/2pj;->A09(LX/3C1;FF)LX/3C1;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    invoke-static {v0, v14, v15, v15}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraRowDivider(LX/3C1;LX/2d4;II)V

    .line 191
    .line 192
    .line 193
    :goto_2
    invoke-static {v3, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 194
    .line 195
    .line 196
    const/16 p2, 0x8

    .line 197
    .line 198
    move-object/from16 v18, v4

    .line 199
    .line 200
    move-object/from16 v19, v11

    .line 201
    .line 202
    move-object/from16 p0, v14

    .line 203
    .line 204
    move/from16 p1, v15

    .line 205
    .line 206
    move-object/from16 v17, v5

    .line 207
    .line 208
    invoke-static/range {v16 .. v22}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt;->IdDocumentRow(Lcom/facebook/aura/activation/ageverification/IdDocument;Lcom/facebook/aura/activation/ageverification/IdDocument;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 209
    .line 210
    .line 211
    move v1, v7

    .line 212
    goto :goto_1

    .line 213
    :cond_4
    const v0, 0x51d2e6fe

    .line 214
    .line 215
    .line 216
    invoke-interface {v14, v0}, LX/2d4;->Agj(I)V

    .line 217
    .line 218
    .line 219
    goto :goto_2

    .line 220
    :cond_5
    invoke-static {v3, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 221
    .line 222
    .line 223
    invoke-static {v3, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 224
    .line 225
    .line 226
    return-void

    .line 227
    :cond_6
    invoke-interface {v14}, LX/2d4;->AgJ()V

    .line 228
    .line 229
    .line 230
    return-void
.end method
