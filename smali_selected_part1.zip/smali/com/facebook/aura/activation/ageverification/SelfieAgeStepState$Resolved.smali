.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final afterConfirmed:Z

.field public final afterFinalFailure:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 536870912
    const/4 v0, 0x0

    .line 536870913
    invoke-direct {p0, v0, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;-><init>(ZZ)V

    .line 536870914
    .line 536870915
    .line 536870916
    return-void
.end method

.method public constructor <init>(ZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 4
    .line 5
    iput-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ZZILX/04f;)V
    .locals 2

    .line 268435456
    invoke-static {p3, p1}, LX/002;->A1U(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    and-int/lit8 v0, p3, 0x2

    .line 268435461
    .line 268435462
    if-eqz v0, :cond_0

    .line 268435463
    .line 268435464
    const/4 p2, 0x0

    .line 268435465
    :cond_0
    invoke-direct {p0, v1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;-><init>(ZZ)V

    .line 268435466
    .line 268435467
    .line 268435468
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;ZZILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 11
    .line 12
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 13
    .line 14
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;-><init>(ZZ)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component2()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(ZZ)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;-><init>(ZZ)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 17
    .line 18
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 19
    .line 20
    if-eq v1, v0, :cond_1

    .line 21
    .line 22
    :cond_0
    return v2

    .line 23
    :cond_1
    return v3
.end method

.method public final getAfterConfirmed()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getAfterFinalFailure()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 1
    .line 2
    invoke-static {v0}, LX/07F;->A02(Z)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
