.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieHeadPoseKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEAD_ZONE:F = 0.019444445f

.field public static final FAST_MOVEMENT_ALPHA:F = 0.8f

.field public static final FAST_MOVEMENT_THRESHOLD:F = 0.04f

.field public static final HALF_ROTATION_DEGREES:F = 180.0f

.field public static final MAX_ABSOLUTE_ANGLE:F = 0.5f

.field public static final MAX_HEAD_ANGLE_DEGREES:F = 90.0f

.field public static final NEUTRAL_POSE_THRESHOLD:F = 0.016666668f

.field public static final STABLE_ALPHA:F = 0.35f

.field public static final YAW_OFFSET:F = 0.0055555557f
