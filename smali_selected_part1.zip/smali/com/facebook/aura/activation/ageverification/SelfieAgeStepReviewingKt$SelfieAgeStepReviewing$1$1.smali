.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $fill:LX/2sw;


# direct methods
.method public constructor <init>(LX/2sw;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;->$fill:LX/2sw;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/33K;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;->invoke(LX/33K;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 9

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object p1, p2

    .line 5
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_3

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    sget-object v7, LX/2sI;->A01:LX/2wD;

    .line 13
    .line 14
    const/4 v3, 0x6

    .line 15
    const/4 p3, 0x0

    .line 16
    invoke-static {v7, p2, v3, p3}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->SelfieReviewShimmer(LX/3C1;LX/2d4;II)V

    .line 17
    .line 18
    .line 19
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 24
    .line 25
    if-ne v5, v2, :cond_0

    .line 26
    .line 27
    sget-object v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1$1$1;

    .line 28
    .line 29
    invoke-interface {p2, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 33
    .line 34
    sget-object v6, LX/Dwg;->A01:LX/Dwg;

    .line 35
    .line 36
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;->$fill:LX/2sw;

    .line 37
    .line 38
    invoke-interface {p2, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;->$fill:LX/2sw;

    .line 43
    .line 44
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    if-nez v1, :cond_1

    .line 49
    .line 50
    if-ne p0, v2, :cond_2

    .line 51
    .line 52
    :cond_1
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1$2$1;

    .line 53
    .line 54
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1$2$1;-><init>(LX/2sw;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {p2, p0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_2
    check-cast p0, Lkotlin/jvm/functions/Function0;

    .line 61
    .line 62
    sget v0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->$stable:I

    .line 63
    .line 64
    shl-int/2addr v0, v3

    .line 65
    or-int/lit16 p2, v0, 0x6db6

    .line 66
    .line 67
    const/4 v8, 0x1

    .line 68
    invoke-static/range {v4 .. v12}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SelfieMovementOverlay(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 73
    .line 74
    .line 75
    return-void
.end method
