.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieMovementChipKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final SelfieMovementChip(LX/33K;Lcom/facebook/aura/activation/ageverification/HeadMovement;ZLX/3C1;LX/2d4;II)V
    .locals 16

    .line 0
    move-object/from16 v2, p3

    .line 1
    .line 2
    const/4 v8, 0x0

    .line 3
    move-object/from16 v7, p0

    .line 4
    .line 5
    move-object/from16 v6, p1

    .line 6
    .line 7
    invoke-static {v7, v6}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v9

    .line 11
    const v0, -0x1cb03e0d

    .line 12
    .line 13
    .line 14
    move-object/from16 v4, p4

    .line 15
    .line 16
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 17
    .line 18
    .line 19
    move/from16 v3, p5

    .line 20
    .line 21
    and-int/lit8 v0, p5, 0x6

    .line 22
    .line 23
    const/4 v1, 0x2

    .line 24
    if-nez v0, :cond_f

    .line 25
    .line 26
    invoke-static {v4, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v11

    .line 30
    or-int v11, v11, p5

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {v4, v6}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v11, v0

    .line 41
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 42
    .line 43
    move/from16 v5, p2

    .line 44
    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    invoke-static {v4, v5}, LX/004;->A0k(LX/2d4;Z)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v11, v0

    .line 52
    :cond_1
    and-int/lit8 v10, p6, 0x4

    .line 53
    .line 54
    if-eqz v10, :cond_e

    .line 55
    .line 56
    or-int/lit16 v11, v11, 0xc00

    .line 57
    .line 58
    :cond_2
    :goto_1
    invoke-static {v11}, LX/005;->A1K(I)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0, v4, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_d

    .line 67
    .line 68
    if-eqz v10, :cond_3

    .line 69
    .line 70
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 71
    .line 72
    :cond_3
    const/high16 v10, 0x41e00000    # 28.0f

    .line 73
    .line 74
    const/high16 v0, 0x40000000    # 2.0f

    .line 75
    .line 76
    div-float v11, v10, v0

    .line 77
    .line 78
    sget v0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SELFIE_RING_INSET:F

    .line 79
    .line 80
    sub-float/2addr v11, v0

    .line 81
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const/4 v15, 0x3

    .line 86
    if-eq v0, v8, :cond_c

    .line 87
    .line 88
    if-eq v0, v9, :cond_b

    .line 89
    .line 90
    if-ne v0, v1, :cond_10

    .line 91
    .line 92
    sget-object v0, LX/2Jo;->A02:Landroidx/compose/ui/Alignment;

    .line 93
    .line 94
    invoke-interface {v7, v0, v2}, LX/33K;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    neg-float v11, v11

    .line 99
    :goto_2
    const/4 v0, 0x0

    .line 100
    invoke-static {v1, v11, v0}, LX/7mL;->A00(LX/3C1;FF)LX/3C1;

    .line 101
    .line 102
    .line 103
    move-result-object v12

    .line 104
    :goto_3
    if-eqz p2, :cond_a

    .line 105
    .line 106
    const v0, 0x4e675bfa    # 9.703912E8f

    .line 107
    .line 108
    .line 109
    invoke-static {v4, v0}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 110
    .line 111
    .line 112
    move-result-object v11

    .line 113
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 114
    .line 115
    invoke-static {v0, v4}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 120
    .line 121
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->success:J

    .line 122
    .line 123
    :goto_4
    invoke-static {v4}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 124
    .line 125
    .line 126
    move-result-object v9

    .line 127
    invoke-static {v12, v10}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 128
    .line 129
    .line 130
    move-result-object v10

    .line 131
    sget-object v13, LX/2bA;->A00:LX/2bC;

    .line 132
    .line 133
    invoke-static {v10, v13, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 134
    .line 135
    .line 136
    move-result-object v12

    .line 137
    const/high16 v10, 0x3f800000    # 1.0f

    .line 138
    .line 139
    if-eqz p2, :cond_9

    .line 140
    .line 141
    const v14, 0x4e6774fa    # 9.708008E8f

    .line 142
    .line 143
    .line 144
    invoke-interface {v4, v14}, LX/2d4;->Agj(I)V

    .line 145
    .line 146
    .line 147
    :goto_5
    invoke-static {v9, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 148
    .line 149
    .line 150
    invoke-static {v12, v13, v10, v0, v1}, LX/1XO;->A02(LX/3C1;LX/2bW;FJ)LX/3C1;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicroPlusNano:F

    .line 155
    .line 156
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 157
    .line 158
    .line 159
    move-result-object v12

    .line 160
    if-eqz p2, :cond_7

    .line 161
    .line 162
    const v1, 0x7f0800e5

    .line 163
    .line 164
    .line 165
    :cond_4
    :goto_6
    invoke-static {v4, v1, v8}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 166
    .line 167
    .line 168
    move-result-object v13

    .line 169
    sget-object v14, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->TINY:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 170
    .line 171
    if-eqz p2, :cond_6

    .line 172
    .line 173
    const v0, 0x4e67ba9d    # 9.719417E8f

    .line 174
    .line 175
    .line 176
    invoke-static {v4, v11, v0}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->background:J

    .line 181
    .line 182
    :goto_7
    invoke-static {v9, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 183
    .line 184
    .line 185
    sget v8, LX/2l9;->$stable:I

    .line 186
    .line 187
    shl-int/2addr v8, v15

    .line 188
    or-int/lit16 v8, v8, 0x180

    .line 189
    .line 190
    const/16 p5, 0x28

    .line 191
    .line 192
    const/4 v15, 0x0

    .line 193
    move-object/from16 p2, v15

    .line 194
    .line 195
    move-object/from16 p3, v4

    .line 196
    .line 197
    move/from16 p4, v8

    .line 198
    .line 199
    move-wide/from16 p0, v0

    .line 200
    .line 201
    invoke-static/range {v12 .. v21}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 202
    .line 203
    .line 204
    :goto_8
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 205
    .line 206
    .line 207
    move-result-object v1

    .line 208
    if-eqz v1, :cond_5

    .line 209
    .line 210
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieMovementChipKt$SelfieMovementChip$1;

    .line 211
    .line 212
    move-object/from16 p1, v7

    .line 213
    .line 214
    move-object/from16 p2, v6

    .line 215
    .line 216
    move/from16 p3, v5

    .line 217
    .line 218
    move-object/from16 p4, v2

    .line 219
    .line 220
    move/from16 p5, v3

    .line 221
    .line 222
    move-object/from16 p0, v0

    .line 223
    .line 224
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieMovementChipKt$SelfieMovementChip$1;-><init>(LX/33K;Lcom/facebook/aura/activation/ageverification/HeadMovement;ZLX/3C1;II)V

    .line 225
    .line 226
    .line 227
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 228
    .line 229
    :cond_5
    return-void

    .line 230
    :cond_6
    const v0, 0x4e67beba    # 9.720091E8f

    .line 231
    .line 232
    .line 233
    invoke-static {v4, v11, v0}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->onLight:J

    .line 238
    .line 239
    goto :goto_7

    .line 240
    :cond_7
    sget-object v0, Lcom/facebook/aura/activation/ageverification/HeadMovement;->RIGHT:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 241
    .line 242
    if-ne v6, v0, :cond_8

    .line 243
    .line 244
    const v1, 0x7f08008c

    .line 245
    .line 246
    .line 247
    goto :goto_6

    .line 248
    :cond_8
    sget-object v0, Lcom/facebook/aura/activation/ageverification/HeadMovement;->UP:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 249
    .line 250
    const v1, 0x7f08008b

    .line 251
    .line 252
    .line 253
    if-ne v6, v0, :cond_4

    .line 254
    .line 255
    const v1, 0x7f08008e

    .line 256
    .line 257
    .line 258
    goto :goto_6

    .line 259
    :cond_9
    const v0, 0x4e6778c1    # 9.7086266E8f

    .line 260
    .line 261
    .line 262
    invoke-static {v4, v11, v0}, LX/002;->A0g(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevatedBorder:J

    .line 267
    .line 268
    goto :goto_5

    .line 269
    :cond_a
    const v0, 0x4e675fba    # 9.704526E8f

    .line 270
    .line 271
    .line 272
    invoke-static {v4, v0}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 273
    .line 274
    .line 275
    move-result-object v11

    .line 276
    invoke-static {v4, v11}, LX/07H;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 277
    .line 278
    .line 279
    move-result-wide v0

    .line 280
    goto/16 :goto_4

    .line 281
    .line 282
    :cond_b
    sget-object v0, LX/2Id;->A0C:Landroidx/compose/ui/Alignment;

    .line 283
    .line 284
    invoke-interface {v7, v0, v2}, LX/33K;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 285
    .line 286
    .line 287
    move-result-object v9

    .line 288
    neg-float v1, v11

    .line 289
    const/4 v0, 0x0

    .line 290
    invoke-static {v9, v0, v1}, LX/7mL;->A00(LX/3C1;FF)LX/3C1;

    .line 291
    .line 292
    .line 293
    move-result-object v12

    .line 294
    goto/16 :goto_3

    .line 295
    .line 296
    :cond_c
    sget-object v0, LX/2Jo;->A03:Landroidx/compose/ui/Alignment;

    .line 297
    .line 298
    invoke-interface {v7, v0, v2}, LX/33K;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    goto/16 :goto_2

    .line 303
    .line 304
    :cond_d
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 305
    .line 306
    .line 307
    goto :goto_8

    .line 308
    :cond_e
    and-int/lit16 v0, v3, 0xc00

    .line 309
    .line 310
    if-nez v0, :cond_2

    .line 311
    .line 312
    invoke-static {v4, v2}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 313
    .line 314
    .line 315
    move-result v0

    .line 316
    or-int/2addr v11, v0

    .line 317
    goto/16 :goto_1

    .line 318
    .line 319
    :cond_f
    move v11, v3

    .line 320
    goto/16 :goto_0

    .line 321
    .line 322
    :cond_10
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 323
    .line 324
    .line 325
    move-result-object v0

    .line 326
    throw v0
.end method
