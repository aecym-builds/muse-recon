.class public final Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2la;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $color:J


# direct methods
.method public constructor <init>(J)V
    .locals 1

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;->$color:J

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2la;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;->invoke(LX/2la;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2la;)V
    .locals 18

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v5, p1

    .line 2
    .line 3
    invoke-static {v5, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/high16 v2, 0x40800000    # 4.0f

    .line 7
    .line 8
    invoke-interface {v5, v2}, LX/34Y;->AhZ(F)F

    .line 9
    .line 10
    .line 11
    move-result v16

    .line 12
    move-object/from16 v1, p0

    .line 13
    .line 14
    iget-wide v11, v1, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;->$color:J

    .line 15
    .line 16
    invoke-static {v5}, LX/2RQ;->A02(LX/2la;)F

    .line 17
    .line 18
    .line 19
    move-result v8

    .line 20
    const/high16 v3, 0x40000000    # 2.0f

    .line 21
    .line 22
    div-float/2addr v8, v3

    .line 23
    div-float v0, v16, v3

    .line 24
    .line 25
    sub-float/2addr v8, v0

    .line 26
    const/4 v6, 0x0

    .line 27
    new-instance v7, LX/2RO;

    .line 28
    .line 29
    move-object v14, v7

    .line 30
    move-object v15, v6

    .line 31
    move/from16 v17, v2

    .line 32
    .line 33
    move/from16 p0, v4

    .line 34
    .line 35
    move/from16 p1, v4

    .line 36
    .line 37
    invoke-direct/range {v14 .. v19}, LX/2RO;-><init>(LX/2RU;FFII)V

    .line 38
    .line 39
    .line 40
    invoke-interface {v5}, LX/2la;->ADd()J

    .line 41
    .line 42
    .line 43
    move-result-wide v13

    .line 44
    const/high16 v9, 0x3f800000    # 1.0f

    .line 45
    .line 46
    const/4 v10, 0x3

    .line 47
    const/4 v15, 0x3

    .line 48
    invoke-interface/range {v5 .. v14}, LX/2la;->A9S(LX/2hc;LX/2Qt;FFIJJ)V

    .line 49
    .line 50
    .line 51
    iget-wide v0, v1, Lcom/facebook/aura/activation/ageverification/IdCameraContentKt$IdShutterButton$2$1;->$color:J

    .line 52
    .line 53
    invoke-static {v5}, LX/2RQ;->A02(LX/2la;)F

    .line 54
    .line 55
    .line 56
    move-result v13

    .line 57
    div-float/2addr v13, v3

    .line 58
    sub-float v13, v13, v16

    .line 59
    .line 60
    invoke-interface {v5, v2}, LX/34Y;->AhZ(F)F

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    sub-float/2addr v13, v2

    .line 65
    invoke-interface {v5}, LX/2la;->ADd()J

    .line 66
    .line 67
    .line 68
    move-result-wide p0

    .line 69
    sget-object v12, LX/2RH;->A00:LX/2RH;

    .line 70
    .line 71
    move-object v10, v5

    .line 72
    move-object v11, v6

    .line 73
    move v14, v9

    .line 74
    move-wide/from16 v16, v0

    .line 75
    .line 76
    invoke-interface/range {v10 .. v19}, LX/2la;->A9S(LX/2hc;LX/2Qt;FFIJJ)V

    .line 77
    .line 78
    .line 79
    return-void
.end method
