.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $failedRefreshes:I

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;I)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;->$failedRefreshes:I

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;->$failedRefreshes:I

    .line 3
    .line 4
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->onFailedRefreshes(I)V

    .line 5
    .line 6
    .line 7
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1$invoke$$inlined$onDispose$1;

    .line 8
    .line 9
    invoke-direct {p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
