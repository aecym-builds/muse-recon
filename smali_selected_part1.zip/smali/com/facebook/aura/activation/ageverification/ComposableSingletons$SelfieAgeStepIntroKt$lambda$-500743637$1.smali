.class public final Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/33K;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1;->invoke(LX/33K;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 8

    .line 0
    and-int/lit8 v1, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v7, 0x1

    .line 6
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    move-object p1, p2

    .line 11
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    sget-object v6, LX/2sI;->A01:LX/2wD;

    .line 19
    .line 20
    const/4 v1, 0x6

    .line 21
    invoke-static {v6, p2, v1, v2}, Lcom/facebook/aura/activation/ageverification/SelfieMascotKt;->SelfieMascot(LX/3C1;LX/2d4;II)V

    .line 22
    .line 23
    .line 24
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 29
    .line 30
    if-ne v4, v0, :cond_0

    .line 31
    .line 32
    sget-object v4, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt$lambda$-500743637$1$1$1;

    .line 33
    .line 34
    invoke-interface {p2, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 38
    .line 39
    sget-object v5, LX/Dwg;->A01:LX/Dwg;

    .line 40
    .line 41
    sget v0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->$stable:I

    .line 42
    .line 43
    shl-int/2addr v0, v1

    .line 44
    or-int/lit16 p2, v0, 0x6db6

    .line 45
    .line 46
    const/16 p3, 0x20

    .line 47
    .line 48
    move-object p0, v3

    .line 49
    invoke-static/range {v3 .. v11}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SelfieMovementOverlay(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    return-void
.end method
