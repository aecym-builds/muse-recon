.class public interface abstract Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;
.super Ljava/lang/Object;
.source ""
