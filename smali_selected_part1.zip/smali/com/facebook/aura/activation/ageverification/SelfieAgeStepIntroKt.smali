.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final SelfieAgeStepIntro(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 51

    .line 0
    move-object/from16 v22, p2

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v4, p0

    .line 4
    .line 5
    invoke-static {v4, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, 0x7c9a5502

    .line 9
    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v15, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_4

    .line 21
    .line 22
    invoke-static {v4, v3, v15}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-static {v0}, LX/003;->A06(I)I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    or-int v5, v5, p4

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 33
    .line 34
    move/from16 v23, p1

    .line 35
    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    move/from16 v0, v23

    .line 39
    .line 40
    invoke-static {v3, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    or-int/2addr v5, v0

    .line 45
    :cond_0
    and-int/lit8 v1, p5, 0x4

    .line 46
    .line 47
    if-eqz v1, :cond_3

    .line 48
    .line 49
    or-int/lit16 v5, v5, 0x180

    .line 50
    .line 51
    :cond_1
    :goto_1
    invoke-static {v5}, LX/005;->A1I(I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v3, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_5

    .line 60
    .line 61
    if-eqz v1, :cond_2

    .line 62
    .line 63
    sget-object v22, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    invoke-static/range {v22 .. v22}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    sget-object v16, LX/2Id;->A00:LX/2sS;

    .line 70
    .line 71
    sget-object v14, LX/Dn6;->A06:LX/Dps;

    .line 72
    .line 73
    const/16 v21, 0x30

    .line 74
    .line 75
    move/from16 v1, v21

    .line 76
    .line 77
    move-object/from16 v0, v16

    .line 78
    .line 79
    invoke-static {v14, v3, v0, v1}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    move-object v1, v3

    .line 84
    check-cast v1, LX/J7I;

    .line 85
    .line 86
    iget-wide v6, v1, LX/J7I;->A06:J

    .line 87
    .line 88
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 89
    .line 90
    .line 91
    move-result v11

    .line 92
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 93
    .line 94
    .line 95
    move-result-object v7

    .line 96
    invoke-static {v3, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 101
    .line 102
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 103
    .line 104
    if-nez v0, :cond_6

    .line 105
    .line 106
    invoke-static {}, LX/1VY;->A00()V

    .line 107
    .line 108
    .line 109
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    throw v0

    .line 114
    :cond_3
    and-int/lit16 v0, v15, 0x180

    .line 115
    .line 116
    if-nez v0, :cond_1

    .line 117
    .line 118
    move-object/from16 v0, v22

    .line 119
    .line 120
    invoke-static {v3, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    or-int/2addr v5, v0

    .line 125
    goto :goto_1

    .line 126
    :cond_4
    move v5, v15

    .line 127
    goto :goto_0

    .line 128
    :cond_5
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 129
    .line 130
    .line 131
    goto/16 :goto_4

    .line 132
    .line 133
    :cond_6
    invoke-static {v3, v1, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 134
    .line 135
    .line 136
    sget-object v9, LX/3Cl;->A04:LX/JDN;

    .line 137
    .line 138
    invoke-static {v3, v8, v9}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 139
    .line 140
    .line 141
    move-result-object v8

    .line 142
    invoke-static {v3, v7, v8, v11}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 143
    .line 144
    .line 145
    move-result-object v20

    .line 146
    sget-object v7, LX/3Cl;->A02:LX/JDM;

    .line 147
    .line 148
    invoke-static {v3, v7}, LX/2d5;->A0C(LX/2d4;LX/JDM;)V

    .line 149
    .line 150
    .line 151
    sget-object v13, LX/3Cl;->A05:LX/JDN;

    .line 152
    .line 153
    move-object/from16 v30, v13

    .line 154
    .line 155
    invoke-static {v3, v6, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 156
    .line 157
    .line 158
    sget-object v19, LX/CgJ;->A00:LX/CgJ;

    .line 159
    .line 160
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 161
    .line 162
    const/16 v17, 0x0

    .line 163
    .line 164
    const/high16 v6, 0x3f800000    # 1.0f

    .line 165
    .line 166
    const/4 v0, 0x1

    .line 167
    move v12, v6

    .line 168
    move-object/from16 v11, v19

    .line 169
    .line 170
    move-object/from16 v6, v18

    .line 171
    .line 172
    invoke-virtual {v11, v6, v12, v0}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 173
    .line 174
    .line 175
    move-result-object v12

    .line 176
    move/from16 v11, v21

    .line 177
    .line 178
    move-object/from16 v6, v16

    .line 179
    .line 180
    invoke-static {v14, v3, v6, v11}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 181
    .line 182
    .line 183
    move-result-object v16

    .line 184
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 185
    .line 186
    .line 187
    move-result v14

    .line 188
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 189
    .line 190
    .line 191
    move-result-object v11

    .line 192
    invoke-static {v3, v12}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 193
    .line 194
    .line 195
    move-result-object v12

    .line 196
    invoke-static {v3, v1, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 197
    .line 198
    .line 199
    move-object/from16 v6, v16

    .line 200
    .line 201
    invoke-static {v3, v6, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 202
    .line 203
    .line 204
    invoke-static {v3, v11, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 205
    .line 206
    .line 207
    move-object/from16 v11, v20

    .line 208
    .line 209
    invoke-static {v7, v11, v3, v14}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 210
    .line 211
    .line 212
    invoke-static {v3, v12, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 213
    .line 214
    .line 215
    sget-object v26, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$SelfieAgeStepIntroKt;->lambda$-500743637:LX/JDQ;

    .line 216
    .line 217
    const/16 v28, 0x186

    .line 218
    .line 219
    move-object/from16 v24, v19

    .line 220
    .line 221
    move-object/from16 v25, v17

    .line 222
    .line 223
    move-object/from16 v27, v3

    .line 224
    .line 225
    move/from16 v29, v0

    .line 226
    .line 227
    invoke-static/range {v24 .. v29}, Lcom/facebook/aura/activation/ageverification/SelfieCircleKt;->SelfieCircle(LX/3dS;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 228
    .line 229
    .line 230
    const/high16 v12, 0x3f000000    # 0.5f

    .line 231
    .line 232
    move-object/from16 v11, v19

    .line 233
    .line 234
    move-object/from16 v6, v18

    .line 235
    .line 236
    invoke-virtual {v11, v6, v12, v2}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 237
    .line 238
    .line 239
    move-result-object v6

    .line 240
    invoke-static {v3, v6}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 241
    .line 242
    .line 243
    move-result-object v26

    .line 244
    sget v28, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->$stable:I

    .line 245
    .line 246
    and-int/lit8 v6, v5, 0xe

    .line 247
    .line 248
    or-int v28, v28, v6

    .line 249
    .line 250
    and-int/lit8 v11, v5, 0x70

    .line 251
    .line 252
    or-int v28, v28, v11

    .line 253
    .line 254
    move-object/from16 v24, v4

    .line 255
    .line 256
    move/from16 v25, v23

    .line 257
    .line 258
    move/from16 v29, v2

    .line 259
    .line 260
    invoke-static/range {v24 .. v29}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt;->SelfieIntroText(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 261
    .line 262
    .line 263
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 264
    .line 265
    .line 266
    sget-object v16, LX/2sI;->A02:LX/2wD;

    .line 267
    .line 268
    sget v12, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 269
    .line 270
    move-object/from16 v11, v16

    .line 271
    .line 272
    invoke-static {v11, v12}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 273
    .line 274
    .line 275
    move-result-object v11

    .line 276
    sget v12, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 277
    .line 278
    invoke-static {v3, v12, v2}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 279
    .line 280
    .line 281
    move-result-object v14

    .line 282
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 283
    .line 284
    .line 285
    move-result v13

    .line 286
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 287
    .line 288
    .line 289
    move-result-object v12

    .line 290
    invoke-static {v3, v11}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 291
    .line 292
    .line 293
    move-result-object v11

    .line 294
    invoke-static {v3, v1, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 295
    .line 296
    .line 297
    invoke-static {v3, v14, v9}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 298
    .line 299
    .line 300
    invoke-static {v3, v12, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 301
    .line 302
    .line 303
    move-object/from16 v8, v20

    .line 304
    .line 305
    invoke-static {v7, v8, v3, v13}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 306
    .line 307
    .line 308
    move-object/from16 v7, v30

    .line 309
    .line 310
    invoke-static {v3, v11, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 311
    .line 312
    .line 313
    const v7, 0x7f12009b

    .line 314
    .line 315
    .line 316
    invoke-static {v3, v7}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v25

    .line 320
    const/4 v8, 0x4

    .line 321
    if-eq v6, v8, :cond_7

    .line 322
    .line 323
    and-int/lit8 v7, v5, 0x8

    .line 324
    .line 325
    if-eqz v7, :cond_10

    .line 326
    .line 327
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 328
    .line 329
    .line 330
    move-result v7

    .line 331
    if-eqz v7, :cond_10

    .line 332
    .line 333
    :cond_7
    const/4 v9, 0x1

    .line 334
    :goto_2
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v7

    .line 338
    if-nez v9, :cond_8

    .line 339
    .line 340
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 341
    .line 342
    if-ne v7, v9, :cond_9

    .line 343
    .line 344
    :cond_8
    new-instance v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$1$2$1$1;

    .line 345
    .line 346
    invoke-direct {v7, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$1$2$1$1;-><init>(Ljava/lang/Object;)V

    .line 347
    .line 348
    .line 349
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    :cond_9
    check-cast v7, LX/DqV;

    .line 353
    .line 354
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 355
    .line 356
    const p4, 0x7ffbff5

    .line 357
    .line 358
    .line 359
    const/4 v11, 0x0

    .line 360
    const/16 p1, 0xc00

    .line 361
    .line 362
    move-object/from16 v24, v17

    .line 363
    .line 364
    move-object/from16 v26, v17

    .line 365
    .line 366
    move-object/from16 v27, v16

    .line 367
    .line 368
    move-object/from16 v28, v17

    .line 369
    .line 370
    move-object/from16 v29, v17

    .line 371
    .line 372
    move-object/from16 v30, v17

    .line 373
    .line 374
    move/from16 v31, v2

    .line 375
    .line 376
    move/from16 v32, v2

    .line 377
    .line 378
    move/from16 v33, v2

    .line 379
    .line 380
    move/from16 v34, v2

    .line 381
    .line 382
    move/from16 v35, v2

    .line 383
    .line 384
    move-object/from16 v36, v17

    .line 385
    .line 386
    move-object/from16 v37, v17

    .line 387
    .line 388
    move-object/from16 v38, v7

    .line 389
    .line 390
    move-object/from16 v39, v17

    .line 391
    .line 392
    move-object/from16 v40, v17

    .line 393
    .line 394
    move-object/from16 v41, v17

    .line 395
    .line 396
    move-object/from16 v42, v17

    .line 397
    .line 398
    move-object/from16 v43, v17

    .line 399
    .line 400
    move-object/from16 v44, v17

    .line 401
    .line 402
    move-object/from16 v45, v17

    .line 403
    .line 404
    move-object/from16 v46, v17

    .line 405
    .line 406
    move/from16 v47, v2

    .line 407
    .line 408
    move/from16 v48, v2

    .line 409
    .line 410
    move/from16 v49, v2

    .line 411
    .line 412
    move/from16 v50, v2

    .line 413
    .line 414
    move-object/from16 p0, v3

    .line 415
    .line 416
    move/from16 p2, v2

    .line 417
    .line 418
    move/from16 p3, v2

    .line 419
    .line 420
    invoke-static/range {v24 .. v55}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 421
    .line 422
    .line 423
    if-nez v23, :cond_f

    .line 424
    .line 425
    const v7, 0x5e41c67b

    .line 426
    .line 427
    .line 428
    invoke-interface {v3, v7}, LX/2d4;->Agj(I)V

    .line 429
    .line 430
    .line 431
    const v7, 0x7f1200a2

    .line 432
    .line 433
    .line 434
    invoke-static {v3, v7}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 435
    .line 436
    .line 437
    move-result-object v25

    .line 438
    sget-object v10, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 439
    .line 440
    move-object/from16 v9, v17

    .line 441
    .line 442
    move/from16 v7, v21

    .line 443
    .line 444
    invoke-virtual {v10, v9, v3, v7, v0}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 445
    .line 446
    .line 447
    move-result-object v28

    .line 448
    if-eq v6, v8, :cond_a

    .line 449
    .line 450
    and-int/lit8 v5, v5, 0x8

    .line 451
    .line 452
    if-eqz v5, :cond_b

    .line 453
    .line 454
    invoke-interface {v3, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 455
    .line 456
    .line 457
    move-result v5

    .line 458
    if-eqz v5, :cond_b

    .line 459
    .line 460
    :cond_a
    const/4 v11, 0x1

    .line 461
    :cond_b
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    move-result-object v6

    .line 465
    if-nez v11, :cond_c

    .line 466
    .line 467
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 468
    .line 469
    if-ne v6, v5, :cond_d

    .line 470
    .line 471
    :cond_c
    new-instance v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$1$2$2$1;

    .line 472
    .line 473
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$1$2$2$1;-><init>(Ljava/lang/Object;)V

    .line 474
    .line 475
    .line 476
    invoke-interface {v3, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 477
    .line 478
    .line 479
    :cond_d
    check-cast v6, LX/DqV;

    .line 480
    .line 481
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 482
    .line 483
    const p4, 0x7ffbfe5

    .line 484
    .line 485
    .line 486
    move-object/from16 v38, v6

    .line 487
    .line 488
    invoke-static/range {v24 .. v55}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 489
    .line 490
    .line 491
    :goto_3
    invoke-static {v1, v2, v0}, LX/003;->A0v(LX/J7I;ZZ)V

    .line 492
    .line 493
    .line 494
    :goto_4
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 495
    .line 496
    .line 497
    move-result-object v1

    .line 498
    if-eqz v1, :cond_e

    .line 499
    .line 500
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$2;

    .line 501
    .line 502
    move-object/from16 p0, v0

    .line 503
    .line 504
    move-object/from16 p1, v4

    .line 505
    .line 506
    move/from16 p2, v23

    .line 507
    .line 508
    move-object/from16 p3, v22

    .line 509
    .line 510
    move/from16 p4, v15

    .line 511
    .line 512
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieAgeStepIntro$2;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;II)V

    .line 513
    .line 514
    .line 515
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 516
    .line 517
    :cond_e
    return-void

    .line 518
    :cond_f
    const v5, 0x5e45adfd

    .line 519
    .line 520
    .line 521
    invoke-interface {v3, v5}, LX/2d4;->Agj(I)V

    .line 522
    .line 523
    .line 524
    goto :goto_3

    .line 525
    :cond_10
    const/4 v9, 0x0

    .line 526
    goto/16 :goto_2
.end method

.method public static final SelfieIntroText(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 18

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    const v0, 0x2a477336

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p3

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    const/4 v11, 0x4

    .line 15
    move-object/from16 v8, p0

    .line 16
    .line 17
    if-nez v0, :cond_c

    .line 18
    .line 19
    invoke-static {v8, v6, v5}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0}, LX/003;->A06(I)I

    .line 24
    .line 25
    .line 26
    move-result v9

    .line 27
    or-int v9, v9, p4

    .line 28
    .line 29
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 30
    .line 31
    move/from16 v7, p1

    .line 32
    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    invoke-static {v6, v7}, LX/004;->A0j(LX/2d4;Z)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    or-int/2addr v9, v0

    .line 40
    :cond_0
    and-int/lit8 v2, p5, 0x4

    .line 41
    .line 42
    if-eqz v2, :cond_b

    .line 43
    .line 44
    or-int/lit16 v9, v9, 0x180

    .line 45
    .line 46
    :cond_1
    :goto_1
    and-int/lit16 v1, v9, 0x93

    .line 47
    .line 48
    const/16 v0, 0x92

    .line 49
    .line 50
    const/4 v4, 0x0

    .line 51
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    invoke-static {v0, v6, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_a

    .line 60
    .line 61
    if-eqz v2, :cond_2

    .line 62
    .line 63
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 64
    .line 65
    :cond_2
    sget-object v0, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 66
    .line 67
    move-object v1, v6

    .line 68
    check-cast v1, LX/J7I;

    .line 69
    .line 70
    invoke-static {v0, v1}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    const v0, 0x7f12009a

    .line 75
    .line 76
    .line 77
    if-eqz p1, :cond_3

    .line 78
    .line 79
    const v0, 0x7f1204c4

    .line 80
    .line 81
    .line 82
    :cond_3
    invoke-static {v6, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v15

    .line 86
    if-eqz p1, :cond_9

    .line 87
    .line 88
    const v0, -0x49c858b2

    .line 89
    .line 90
    .line 91
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 92
    .line 93
    .line 94
    const v10, 0x7f12009d

    .line 95
    .line 96
    .line 97
    const-string v0, "Muse"

    .line 98
    .line 99
    invoke-static {v6, v0, v15, v10}, LX/18b;->A09(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v13

    .line 103
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 104
    .line 105
    .line 106
    const v0, 0x7f12009e

    .line 107
    .line 108
    .line 109
    :goto_2
    invoke-static {v6, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v12

    .line 113
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 114
    .line 115
    const/16 p0, 0x0

    .line 116
    .line 117
    const/4 v1, 0x0

    .line 118
    invoke-static {v3, v10, v1}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-static {v0, v1, v10, v1, v1}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 123
    .line 124
    .line 125
    move-result-object v14

    .line 126
    and-int/lit8 v0, v9, 0xe

    .line 127
    .line 128
    if-eq v0, v11, :cond_4

    .line 129
    .line 130
    and-int/lit8 v0, v9, 0x8

    .line 131
    .line 132
    if-eqz v0, :cond_8

    .line 133
    .line 134
    invoke-interface {v6, v8}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_8

    .line 139
    .line 140
    :cond_4
    const/4 v0, 0x1

    .line 141
    :goto_3
    invoke-static {v6, v2, v0}, LX/006;->A1Y(LX/2d4;Ljava/lang/Object;Z)Z

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    if-nez v1, :cond_5

    .line 150
    .line 151
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 152
    .line 153
    if-ne v0, v1, :cond_6

    .line 154
    .line 155
    :cond_5
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieIntroText$1$1;

    .line 156
    .line 157
    invoke-direct {v0, v8, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieIntroText$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 158
    .line 159
    .line 160
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :cond_6
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 164
    .line 165
    const/16 p4, 0xe0

    .line 166
    .line 167
    move-object/from16 p1, p0

    .line 168
    .line 169
    move/from16 p3, v4

    .line 170
    .line 171
    move-object/from16 p2, v6

    .line 172
    .line 173
    move/from16 v17, v4

    .line 174
    .line 175
    move-object/from16 v16, v0

    .line 176
    .line 177
    invoke-static/range {v12 .. v22}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt;->AgeStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2hg;LX/2hg;LX/2d4;II)V

    .line 178
    .line 179
    .line 180
    :goto_4
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    if-eqz v1, :cond_7

    .line 185
    .line 186
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieIntroText$2;

    .line 187
    .line 188
    move-object/from16 p0, v0

    .line 189
    .line 190
    move-object/from16 p1, v8

    .line 191
    .line 192
    move/from16 p2, v7

    .line 193
    .line 194
    move-object/from16 p3, v3

    .line 195
    .line 196
    move/from16 p4, v5

    .line 197
    .line 198
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt$SelfieIntroText$2;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;II)V

    .line 199
    .line 200
    .line 201
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 202
    .line 203
    :cond_7
    return-void

    .line 204
    :cond_8
    const/4 v0, 0x0

    .line 205
    goto :goto_3

    .line 206
    :cond_9
    const v0, -0x49c84c47

    .line 207
    .line 208
    .line 209
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 210
    .line 211
    .line 212
    const v0, 0x7f120099

    .line 213
    .line 214
    .line 215
    invoke-static {v6, v15, v0}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v13

    .line 219
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 220
    .line 221
    .line 222
    const v0, 0x7f12009c

    .line 223
    .line 224
    .line 225
    goto :goto_2

    .line 226
    :cond_a
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 227
    .line 228
    .line 229
    goto :goto_4

    .line 230
    :cond_b
    and-int/lit16 v0, v5, 0x180

    .line 231
    .line 232
    if-nez v0, :cond_1

    .line 233
    .line 234
    invoke-static {v6, v3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    or-int/2addr v9, v0

    .line 239
    goto/16 :goto_1

    .line 240
    .line 241
    :cond_c
    move v9, v5

    .line 242
    goto/16 :goto_0
.end method

.method public static final synthetic access$SelfieIntroText(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt;->SelfieIntroText(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
