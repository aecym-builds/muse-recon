.class public final Lcom/facebook/aura/activation/ageverification/CompletionFlash;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final direction:Lcom/facebook/aura/activation/ageverification/HeadMovement;

.field public final strength:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/HeadMovement;LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->direction:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->strength:LX/16A;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getDirection()Lcom/facebook/aura/activation/ageverification/HeadMovement;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->direction:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStrength()LX/16A;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->strength:LX/16A;

    .line 1
    .line 2
    return-object p0
.end method
