.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CATCH_UP_MS:F = 300.0f

.field public static final EXPECTED_REVIEW_END:F = 0.9f

.field public static final EXPECTED_REVIEW_MS:F = 20000.0f

.field public static final FULL_ENOUGH:F = 0.999f

.field public static final NANOS_PER_MS:F = 1000000.0f

.field public static final OVERRUN_TIME_CONSTANT_MS:F = 10000.0f

.field public static final STREAK_SWEEP_MS:J = 0x578L

.field public static final STREAK_TILT_RADIANS:F = 0.5235988f

.field public static final STREAK_WIDTH:F = 0.6f

.field public static final UPLOADED:F = 0.25f

.field public static final UPLOAD_TIME_CONSTANT_MS:F = 3000.0f


# direct methods
.method public static final SelfieAgeStepReviewing(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/3C1;LX/2d4;II)V
    .locals 17

    .line 0
    move-object/from16 v1, p1

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object/from16 v5, p0

    .line 4
    .line 5
    invoke-static {v5, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x42c87c49

    .line 9
    .line 10
    .line 11
    move-object/from16 v4, p2

    .line 12
    .line 13
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v3, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_3

    .line 21
    .line 22
    invoke-static {v5, v4, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-static {v0}, LX/003;->A06(I)I

    .line 27
    .line 28
    .line 29
    move-result v10

    .line 30
    or-int v10, v10, p3

    .line 31
    .line 32
    :goto_0
    move/from16 v7, p4

    .line 33
    .line 34
    and-int/lit8 v9, p4, 0x2

    .line 35
    .line 36
    if-eqz v9, :cond_2

    .line 37
    .line 38
    or-int/lit8 v10, v10, 0x30

    .line 39
    .line 40
    :cond_0
    :goto_1
    and-int/lit8 v8, v10, 0x13

    .line 41
    .line 42
    const/16 v0, 0x12

    .line 43
    .line 44
    const/4 v6, 0x1

    .line 45
    invoke-static {v8, v0}, LX/003;->A1H(II)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v4, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_4

    .line 54
    .line 55
    if-eqz v9, :cond_1

    .line 56
    .line 57
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_1
    and-int/lit8 v0, v10, 0xe

    .line 60
    .line 61
    invoke-static {v5, v4, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->rememberDrawnFill(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/2d4;I)LX/2sw;

    .line 62
    .line 63
    .line 64
    move-result-object v13

    .line 65
    invoke-static {v1}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    sget-object v0, LX/2Id;->A00:LX/2sS;

    .line 70
    .line 71
    invoke-static {v4, v0}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 72
    .line 73
    .line 74
    move-result-object v14

    .line 75
    move-object v0, v4

    .line 76
    check-cast v0, LX/J7I;

    .line 77
    .line 78
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 79
    .line 80
    .line 81
    move-result v12

    .line 82
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 83
    .line 84
    .line 85
    move-result-object v11

    .line 86
    invoke-static {v4, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 87
    .line 88
    .line 89
    move-result-object v10

    .line 90
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 91
    .line 92
    iget-object v8, v0, LX/J7I;->A0V:LX/3DJ;

    .line 93
    .line 94
    if-nez v8, :cond_5

    .line 95
    .line 96
    invoke-static {}, LX/1VY;->A00()V

    .line 97
    .line 98
    .line 99
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    throw v0

    .line 104
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 105
    .line 106
    if-nez v0, :cond_0

    .line 107
    .line 108
    invoke-static {v4, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    or-int/2addr v10, v0

    .line 113
    goto :goto_1

    .line 114
    :cond_3
    move v10, v3

    .line 115
    goto :goto_0

    .line 116
    :cond_4
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_5
    invoke-static {v4, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v4, v14, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 124
    .line 125
    .line 126
    sget-object v14, LX/CgJ;->A00:LX/CgJ;

    .line 127
    .line 128
    new-instance v9, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;

    .line 129
    .line 130
    invoke-direct {v9, v13}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$1;-><init>(LX/2sw;)V

    .line 131
    .line 132
    .line 133
    const v8, -0x1dda6f16

    .line 134
    .line 135
    .line 136
    invoke-static {v4, v9, v8}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 137
    .line 138
    .line 139
    move-result-object v16

    .line 140
    const/16 p1, 0x186

    .line 141
    .line 142
    const/4 v15, 0x0

    .line 143
    move-object/from16 p0, v4

    .line 144
    .line 145
    move/from16 p2, v6

    .line 146
    .line 147
    invoke-static/range {v14 .. v19}, Lcom/facebook/aura/activation/ageverification/SelfieCircleKt;->SelfieCircle(LX/3dS;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 148
    .line 149
    .line 150
    const v8, 0x7f1200a1

    .line 151
    .line 152
    .line 153
    invoke-static {v4, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v12

    .line 157
    const v8, 0x7f1200a0

    .line 158
    .line 159
    .line 160
    invoke-static {v4, v8}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v13

    .line 164
    invoke-static {v4}, LX/007;->A0j(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 165
    .line 166
    .line 167
    move-result-object v8

    .line 168
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title3Medium:LX/2hg;

    .line 169
    .line 170
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 171
    .line 172
    const/high16 v9, 0x3f000000    # 0.5f

    .line 173
    .line 174
    invoke-virtual {v14, v10, v9, v2}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 175
    .line 176
    .line 177
    move-result-object v9

    .line 178
    invoke-static {v4, v9}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 179
    .line 180
    .line 181
    move-result-object v9

    .line 182
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 183
    .line 184
    const/4 v10, 0x0

    .line 185
    invoke-static {v9, v11, v10}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 186
    .line 187
    .line 188
    move-result-object v9

    .line 189
    invoke-static {v9, v10, v11, v10, v10}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 190
    .line 191
    .line 192
    move-result-object v11

    .line 193
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v10

    .line 197
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 198
    .line 199
    if-ne v10, v9, :cond_6

    .line 200
    .line 201
    sget-object v10, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$1$2$1;

    .line 202
    .line 203
    invoke-interface {v4, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    :cond_6
    invoke-static {v11, v10, v2}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 207
    .line 208
    .line 209
    move-result-object v14

    .line 210
    const/16 p4, 0x18

    .line 211
    .line 212
    const-wide/16 v16, 0x0

    .line 213
    .line 214
    move-object/from16 p2, v4

    .line 215
    .line 216
    move/from16 p3, v2

    .line 217
    .line 218
    move-object/from16 p1, v8

    .line 219
    .line 220
    invoke-static/range {v12 .. v21}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepText-FHprtrg(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;LX/2d4;II)V

    .line 221
    .line 222
    .line 223
    invoke-static {v0, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 224
    .line 225
    .line 226
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    if-eqz v2, :cond_7

    .line 231
    .line 232
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$2;

    .line 233
    .line 234
    invoke-direct {v0, v5, v1, v3, v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieAgeStepReviewing$2;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/3C1;II)V

    .line 235
    .line 236
    .line 237
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 238
    .line 239
    :cond_7
    return-void
.end method

.method public static final SelfieReviewShimmer(LX/3C1;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v12, p0

    .line 1
    .line 2
    const v0, 0x601948cd

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p1

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v21, p3

    .line 11
    .line 12
    and-int/lit8 v3, p3, 0x1

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    move/from16 v5, p2

    .line 16
    .line 17
    if-eqz v3, :cond_11

    .line 18
    .line 19
    or-int/lit8 v1, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, v1, 0x3

    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    const/4 v13, 0x1

    .line 25
    invoke-static {v0, v2}, LX/003;->A1H(II)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0, v6, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_10

    .line 34
    .line 35
    if-eqz v3, :cond_0

    .line 36
    .line 37
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 38
    .line 39
    :cond_0
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 40
    .line 41
    const/4 v11, 0x6

    .line 42
    invoke-static {v6, v0}, LX/07H;->A03(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 43
    .line 44
    .line 45
    move-result-wide v0

    .line 46
    invoke-interface {v6, v0, v1}, LX/2d4;->A68(J)Z

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v9

    .line 54
    if-nez v2, :cond_1

    .line 55
    .line 56
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 57
    .line 58
    if-ne v9, v2, :cond_3

    .line 59
    .line 60
    :cond_1
    const/4 v10, 0x5

    .line 61
    new-array v9, v10, [F

    .line 62
    .line 63
    fill-array-data v9, :array_0

    .line 64
    .line 65
    .line 66
    invoke-static {v10}, LX/001;->A12(I)Ljava/util/ArrayList;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    const/4 v7, 0x0

    .line 71
    :cond_2
    aget v2, v9, v7

    .line 72
    .line 73
    invoke-static {v0, v1, v2}, LX/JOw;->A04(JF)J

    .line 74
    .line 75
    .line 76
    move-result-wide v2

    .line 77
    invoke-static {v8, v2, v3}, LX/007;->A1Q(Ljava/util/AbstractCollection;J)V

    .line 78
    .line 79
    .line 80
    add-int/lit8 v7, v7, 0x1

    .line 81
    .line 82
    if-lt v7, v10, :cond_2

    .line 83
    .line 84
    invoke-static {v6, v8}, LX/002;->A1F(LX/2d4;Ljava/lang/Iterable;)LX/Ddn;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    :cond_3
    check-cast v9, LX/Ddn;

    .line 89
    .line 90
    invoke-static {v13, v6, v11, v4}, Lcom/facebook/aura/vds/compose/accessibility/ReducedMotionKt;->rememberAnimatorDurationScale(ZLX/2d4;II)F

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    const/16 v20, 0x0

    .line 95
    .line 96
    cmpg-float v0, v0, v20

    .line 97
    .line 98
    invoke-static {v0}, LX/003;->A1C(I)Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    invoke-static {v0}, LX/001;->A0n(Z)Ljava/lang/Boolean;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-static {v6, v0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 107
    .line 108
    .line 109
    move-result-object v13

    .line 110
    sget-object v0, LX/39S;->A00:LX/Ip3;

    .line 111
    .line 112
    move-object v1, v6

    .line 113
    check-cast v1, LX/J7I;

    .line 114
    .line 115
    invoke-static {v0, v1}, LX/002;->A0u(LX/Iow;LX/J7I;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    check-cast v0, LX/07p;

    .line 120
    .line 121
    invoke-interface {v0}, LX/07p;->getLifecycle()LX/AaB;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-static {v6, v0}, LX/2cu;->A00(LX/2d4;LX/AaB;)LX/16A;

    .line 126
    .line 127
    .line 128
    move-result-object v7

    .line 129
    invoke-static {v1}, LX/004;->A13(LX/J7I;)LX/34Y;

    .line 130
    .line 131
    .line 132
    move-result-object v14

    .line 133
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v3

    .line 137
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 138
    .line 139
    if-ne v3, v2, :cond_4

    .line 140
    .line 141
    invoke-static/range {v20 .. v20}, LX/1Ot;->A02(F)LX/1Ot;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-static {v6, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    :cond_4
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .line 150
    .line 151
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    iget v1, v0, LX/1Ot;->A00:F

    .line 156
    .line 157
    const v0, 0x3f19999a    # 0.6f

    .line 158
    .line 159
    .line 160
    mul-float/2addr v1, v0

    .line 161
    invoke-static {v1}, LX/1Ot;->A02(F)LX/1Ot;

    .line 162
    .line 163
    .line 164
    move-result-object v8

    .line 165
    const/high16 v0, 0x42c00000    # 96.0f

    .line 166
    .line 167
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    invoke-virtual {v8, v1}, LX/1Ot;->compareTo(Ljava/lang/Object;)I

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    if-gez v0, :cond_5

    .line 176
    .line 177
    move-object v8, v1

    .line 178
    :cond_5
    iget v8, v8, LX/1Ot;->A00:F

    .line 179
    .line 180
    const-wide v18, 0x3fe0c15240000000L    # 0.5235987901687622

    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->cos(D)D

    .line 186
    .line 187
    .line 188
    move-result-wide v0

    .line 189
    double-to-float v11, v0

    .line 190
    mul-float v17, v11, v8

    .line 191
    .line 192
    invoke-static {v3}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    iget v10, v0, LX/1Ot;->A00:F

    .line 197
    .line 198
    const/high16 v16, 0x3f800000    # 1.0f

    .line 199
    .line 200
    add-float v16, v16, v11

    .line 201
    .line 202
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->sin(D)D

    .line 203
    .line 204
    .line 205
    move-result-wide v0

    .line 206
    double-to-float v15, v0

    .line 207
    add-float v16, v16, v15

    .line 208
    .line 209
    mul-float v10, v10, v16

    .line 210
    .line 211
    const/high16 v16, 0x40000000    # 2.0f

    .line 212
    .line 213
    mul-float v11, v11, v16

    .line 214
    .line 215
    div-float/2addr v10, v11

    .line 216
    mul-float/2addr v8, v15

    .line 217
    invoke-static {v6, v13, v7}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    move-result v0

    .line 221
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v11

    .line 225
    if-nez v0, :cond_6

    .line 226
    .line 227
    if-ne v11, v2, :cond_7

    .line 228
    .line 229
    :cond_6
    new-instance v11, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;

    .line 230
    .line 231
    invoke-direct {v11, v13, v3, v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;-><init>(LX/16A;Landroidx/compose/runtime/MutableState;LX/16A;)V

    .line 232
    .line 233
    .line 234
    invoke-interface {v6, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    :cond_7
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 238
    .line 239
    invoke-static {v9, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 240
    .line 241
    .line 242
    const-wide/16 p2, 0x578

    .line 243
    .line 244
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v1

    .line 248
    if-ne v1, v2, :cond_8

    .line 249
    .line 250
    invoke-static/range {v20 .. v20}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-static {v6, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    :cond_8
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 259
    .line 260
    invoke-interface {v6, v11}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    move-result v0

    .line 264
    invoke-static {v0}, LX/003;->A1G(I)Z

    .line 265
    .line 266
    .line 267
    move-result v13

    .line 268
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    if-nez v13, :cond_9

    .line 273
    .line 274
    if-ne v0, v2, :cond_a

    .line 275
    .line 276
    :cond_9
    const/16 p0, 0x0

    .line 277
    .line 278
    const/16 p1, 0x5

    .line 279
    .line 280
    new-instance v0, LX/0lX;

    .line 281
    .line 282
    move-object/from16 v22, v0

    .line 283
    .line 284
    move-object/from16 v23, v1

    .line 285
    .line 286
    move-object/from16 v24, v11

    .line 287
    .line 288
    invoke-direct/range {v22 .. v28}, LX/0lX;-><init>(Ljava/lang/Object;Ljava/lang/Object;LX/2M4;IJ)V

    .line 289
    .line 290
    .line 291
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    :cond_a
    invoke-static {v6, v0, v7}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 295
    .line 296
    .line 297
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v7

    .line 301
    if-ne v7, v2, :cond_b

    .line 302
    .line 303
    const/16 v7, 0x1a

    .line 304
    .line 305
    new-instance v0, LX/1X9;

    .line 306
    .line 307
    invoke-direct {v0, v1, v7}, LX/1X9;-><init>(Ljava/lang/Object;I)V

    .line 308
    .line 309
    .line 310
    new-instance v7, LX/2pO;

    .line 311
    .line 312
    move/from16 p3, v8

    .line 313
    .line 314
    move-object/from16 v22, v7

    .line 315
    .line 316
    move-object/from16 v23, v0

    .line 317
    .line 318
    move-object/from16 v24, v11

    .line 319
    .line 320
    move-object/from16 p0, v9

    .line 321
    .line 322
    move/from16 p1, v17

    .line 323
    .line 324
    move/from16 p2, v10

    .line 325
    .line 326
    invoke-direct/range {v22 .. v28}, LX/2pO;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/Ddn;FFF)V

    .line 327
    .line 328
    .line 329
    invoke-interface {v6, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 330
    .line 331
    .line 332
    :cond_b
    check-cast v7, LX/2pO;

    .line 333
    .line 334
    iput-object v9, v7, LX/2pO;->A04:LX/Ddn;

    .line 335
    .line 336
    move/from16 v0, v17

    .line 337
    .line 338
    iput v0, v7, LX/2pO;->A00:F

    .line 339
    .line 340
    iput v10, v7, LX/2pO;->A02:F

    .line 341
    .line 342
    iput v8, v7, LX/2pO;->A01:F

    .line 343
    .line 344
    invoke-static {v11, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 345
    .line 346
    .line 347
    iput-object v11, v7, LX/2pO;->A03:Lkotlin/jvm/functions/Function0;

    .line 348
    .line 349
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 350
    .line 351
    invoke-static {v9, v6}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 356
    .line 357
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryElevated:J

    .line 358
    .line 359
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 360
    .line 361
    .line 362
    move-result-object v8

    .line 363
    invoke-static {v9, v6}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 368
    .line 369
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevatedBorder:J

    .line 370
    .line 371
    invoke-static {v8, v0, v1}, LX/005;->A0p(LX/JOw;J)Ljava/util/List;

    .line 372
    .line 373
    .line 374
    move-result-object v23

    .line 375
    const-wide p2, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    const/high16 p0, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 381
    .line 382
    const/16 v24, 0x0

    .line 383
    .line 384
    new-instance v0, LX/2hV;

    .line 385
    .line 386
    move/from16 p1, v4

    .line 387
    .line 388
    move-object/from16 v22, v0

    .line 389
    .line 390
    invoke-direct/range {v22 .. v28}, LX/2hV;-><init>(Ljava/util/List;Ljava/util/List;FIJ)V

    .line 391
    .line 392
    .line 393
    sget-object v9, LX/2oZ;->A00:LX/2bW;

    .line 394
    .line 395
    invoke-static {v12, v0, v9}, LX/2pC;->A02(LX/3C1;LX/2hZ;LX/2bW;)LX/3C1;

    .line 396
    .line 397
    .line 398
    move-result-object v1

    .line 399
    sget v0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SELFIE_RING_INSET:F

    .line 400
    .line 401
    mul-float v0, v0, v16

    .line 402
    .line 403
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 404
    .line 405
    .line 406
    move-result-object v8

    .line 407
    invoke-interface {v6, v14}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result v1

    .line 411
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    move-result-object v0

    .line 415
    if-nez v1, :cond_c

    .line 416
    .line 417
    if-ne v0, v2, :cond_d

    .line 418
    .line 419
    :cond_c
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;

    .line 420
    .line 421
    invoke-direct {v0, v14, v3}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;-><init>(LX/34Y;Landroidx/compose/runtime/MutableState;)V

    .line 422
    .line 423
    .line 424
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    :cond_d
    check-cast v0, LX/JDM;

    .line 428
    .line 429
    invoke-static {v8, v0}, LX/3N4;->A00(LX/3C1;LX/JDM;)LX/3C1;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    invoke-static {v0, v9, v7}, LX/2pL;->A00(LX/3C1;LX/2bW;LX/2pO;)LX/3C1;

    .line 434
    .line 435
    .line 436
    move-result-object v1

    .line 437
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v0

    .line 441
    if-ne v0, v2, :cond_e

    .line 442
    .line 443
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$2$1;

    .line 444
    .line 445
    invoke-interface {v6, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 446
    .line 447
    .line 448
    :cond_e
    invoke-static {v1, v0, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    invoke-static {v0, v6, v4}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 453
    .line 454
    .line 455
    :goto_1
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 456
    .line 457
    .line 458
    move-result-object v2

    .line 459
    if-eqz v2, :cond_f

    .line 460
    .line 461
    new-instance v1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$3;

    .line 462
    .line 463
    move/from16 v0, v21

    .line 464
    .line 465
    invoke-direct {v1, v12, v5, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$3;-><init>(LX/3C1;II)V

    .line 466
    .line 467
    .line 468
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 469
    .line 470
    :cond_f
    return-void

    .line 471
    :cond_10
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 472
    .line 473
    .line 474
    goto :goto_1

    .line 475
    :cond_11
    and-int/lit8 v0, p2, 0x6

    .line 476
    .line 477
    if-nez v0, :cond_12

    .line 478
    .line 479
    invoke-static {v6, v12}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 480
    .line 481
    .line 482
    move-result v1

    .line 483
    or-int v1, v1, p2

    .line 484
    .line 485
    goto/16 :goto_0

    .line 486
    .line 487
    :cond_12
    move v1, v5

    .line 488
    goto/16 :goto_0

    .line 489
    .line 490
    :array_0
    .array-data 4
        0x0
        0x3df5c28f    # 0.12f
        0x3f333333    # 0.7f
        0x3df5c28f    # 0.12f
        0x0
    .end array-data
.end method

.method public static final SelfieReviewShimmer$lambda$1(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final SelfieReviewShimmer$lambda$2(LX/16A;)LX/15h;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/15h;",
            ">;)",
            "LX/15h;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/15h;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SelfieReviewShimmer$lambda$4(Landroidx/compose/runtime/MutableState;)F
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, LX/1Ot;->A00:F

    .line 5
    .line 6
    return p0
.end method

.method public static final SelfieReviewShimmer$lambda$5(Landroidx/compose/runtime/MutableState;F)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;F)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0L(FLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$SelfieReviewShimmer(LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->SelfieReviewShimmer(LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$SelfieReviewShimmer$lambda$1(LX/16A;)Z
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$SelfieReviewShimmer$lambda$2(LX/16A;)LX/15h;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/15h;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$SelfieReviewShimmer$lambda$4(Landroidx/compose/runtime/MutableState;)F
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    iget p0, p0, LX/1Ot;->A00:F

    .line 5
    .line 6
    return p0
.end method

.method public static final synthetic access$SelfieReviewShimmer$lambda$5(Landroidx/compose/runtime/MutableState;F)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0L(FLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$rememberDrawnFill$lambda$1(LX/16A;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$reviewFraction(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;J)F
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->reviewFraction(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;J)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final rememberDrawnFill(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/2d4;I)LX/2sw;
    .locals 6

    .line 0
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 5
    .line 6
    if-ne v4, v5, :cond_0

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    new-instance v4, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 10
    .line 11
    invoke-direct {v4, v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 12
    .line 13
    .line 14
    invoke-interface {p1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    check-cast v4, LX/2ss;

    .line 18
    .line 19
    invoke-static {p1, p0}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    .line 25
    invoke-interface {p1, v3}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-nez v1, :cond_1

    .line 34
    .line 35
    if-ne v0, v5, :cond_2

    .line 36
    .line 37
    :cond_1
    const/4 v1, 0x0

    .line 38
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;

    .line 39
    .line 40
    invoke-direct {v0, v4, v3, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1;-><init>(LX/2ss;LX/16A;LX/2M4;)V

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_2
    invoke-static {p1, v0, v2}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    return-object v4
.end method

.method public static final rememberDrawnFill$lambda$1(LX/16A;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final reviewFraction(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;J)F
    .locals 6

    .line 0
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 1
    .line 2
    const/high16 v5, 0x3e800000    # 0.25f

    .line 3
    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    const/high16 v2, 0x3f800000    # 1.0f

    .line 7
    .line 8
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 9
    .line 10
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;->sinceMs:J

    .line 11
    .line 12
    sub-long/2addr p1, v0

    .line 13
    neg-long v3, p1

    .line 14
    long-to-float v1, v3

    .line 15
    const v0, 0x453b8000    # 3000.0f

    .line 16
    .line 17
    .line 18
    div-float/2addr v1, v0

    .line 19
    float-to-double v0, v1

    .line 20
    invoke-static {v0, v1}, Ljava/lang/Math;->exp(D)D

    .line 21
    .line 22
    .line 23
    move-result-wide v3

    .line 24
    double-to-float v0, v3

    .line 25
    sub-float/2addr v2, v0

    .line 26
    mul-float/2addr v2, v5

    .line 27
    :cond_0
    return v2

    .line 28
    :cond_1
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 29
    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 33
    .line 34
    iget-wide v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->sinceMs:J

    .line 35
    .line 36
    sub-long/2addr p1, v0

    .line 37
    long-to-float v2, p1

    .line 38
    const v1, 0x469c4000    # 20000.0f

    .line 39
    .line 40
    .line 41
    cmpg-float v0, v2, v1

    .line 42
    .line 43
    if-gtz v0, :cond_4

    .line 44
    .line 45
    const v0, 0x3f266666    # 0.65f

    .line 46
    .line 47
    .line 48
    mul-float/2addr v2, v0

    .line 49
    div-float/2addr v2, v1

    .line 50
    add-float/2addr v2, v5

    .line 51
    return v2

    .line 52
    :cond_2
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 53
    .line 54
    const/4 v2, 0x0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 58
    .line 59
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 60
    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    const/high16 v2, 0x3f800000    # 1.0f

    .line 64
    .line 65
    return v2

    .line 66
    :cond_3
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;

    .line 67
    .line 68
    invoke-static {p0, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-nez v0, :cond_0

    .line 73
    .line 74
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 75
    .line 76
    if-nez v0, :cond_0

    .line 77
    .line 78
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 79
    .line 80
    if-nez v0, :cond_0

    .line 81
    .line 82
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Recapture;

    .line 83
    .line 84
    if-nez v0, :cond_0

    .line 85
    .line 86
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;

    .line 87
    .line 88
    if-nez v0, :cond_0

    .line 89
    .line 90
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    throw v0

    .line 95
    :cond_4
    const/high16 v4, 0x3f800000    # 1.0f

    .line 96
    .line 97
    sub-float/2addr v2, v1

    .line 98
    neg-float v1, v2

    .line 99
    const v0, 0x461c4000    # 10000.0f

    .line 100
    .line 101
    .line 102
    div-float/2addr v1, v0

    .line 103
    float-to-double v0, v1

    .line 104
    invoke-static {v0, v1}, Ljava/lang/Math;->exp(D)D

    .line 105
    .line 106
    .line 107
    move-result-wide v2

    .line 108
    double-to-float v1, v2

    .line 109
    const v0, 0x3dccccd0    # 0.100000024f

    .line 110
    .line 111
    .line 112
    mul-float/2addr v1, v0

    .line 113
    sub-float v2, v4, v1

    .line 114
    .line 115
    return v2
.end method
