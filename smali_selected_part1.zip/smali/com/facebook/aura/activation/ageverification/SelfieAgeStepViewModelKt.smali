.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final MIN_REVIEW_MS:J = 0x7d0L

.field public static final NOT_STARTED:J = -0x1L


# direct methods
.method public static final getShowsBack(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)Z
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 9
    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    instance-of v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 17
    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 19
    .line 20
    if-nez v0, :cond_1

    .line 21
    .line 22
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterFinalFailure:Z

    .line 23
    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    :cond_0
    const/4 v1, 0x1

    .line 27
    :cond_1
    return v1
.end method

.method public static final getShowsHelp(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)Z
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    xor-int/lit8 v0, v0, 0x1

    .line 11
    .line 12
    return v0
.end method
