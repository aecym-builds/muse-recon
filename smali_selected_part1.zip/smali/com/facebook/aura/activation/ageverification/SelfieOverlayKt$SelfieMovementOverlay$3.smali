.class public final Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

.field public final synthetic $flashes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $progress:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reviewFill:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $withBottomArc:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;",
            "LX/3C1;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$progress:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$flashes:LX/Ddn;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$modifier:LX/3C1;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$withBottomArc:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$reviewFill:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$$changed:I

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$$default:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$progress:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$flashes:LX/Ddn;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$modifier:LX/3C1;

    .line 7
    .line 8
    iget-boolean v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$withBottomArc:Z

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$reviewFill:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$$changed:I

    .line 13
    .line 14
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 15
    .line 16
    .line 17
    move-result v8

    .line 18
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;->$$default:I

    .line 19
    .line 20
    move-object v7, p1

    .line 21
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SelfieMovementOverlay(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
