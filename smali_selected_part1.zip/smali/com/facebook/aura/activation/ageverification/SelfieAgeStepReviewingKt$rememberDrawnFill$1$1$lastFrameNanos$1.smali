.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Long;",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$lastFrameNanos$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(J)Ljava/lang/Long;
    .locals 0

    .line 268435456
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 1
    .line 2
    .line 3
    move-result-wide p0

    .line 4
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method
