.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $failedRefreshes:I

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onBack:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onOtherMethods:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onResolved:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelfieUnavailable:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $picked:Z


# direct methods
.method public constructor <init>(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$picked:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onOtherMethods:LX/JDN;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onSelfieUnavailable:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onResolved:LX/JDN;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$failedRefreshes:I

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$modifier:LX/3C1;

    .line 15
    .line 16
    iput p9, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$$changed:I

    .line 17
    .line 18
    iput p10, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$$default:I

    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 11

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$picked:Z

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onOtherMethods:LX/JDN;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onSelfieUnavailable:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onResolved:LX/JDN;

    .line 7
    .line 8
    iget v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$failedRefreshes:I

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$modifier:LX/3C1;

    .line 15
    .line 16
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$$changed:I

    .line 17
    .line 18
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 19
    .line 20
    .line 21
    move-result v10

    .line 22
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;->$$default:I

    .line 23
    .line 24
    move-object v9, p1

    .line 25
    invoke-static/range {v1 .. v11}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->SelfieAgeStep(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
