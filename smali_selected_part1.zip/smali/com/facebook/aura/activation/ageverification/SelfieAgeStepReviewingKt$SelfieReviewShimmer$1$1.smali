.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2cF;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $density:LX/34Y;

.field public final synthetic $side$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/34Y;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/34Y;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;->$density:LX/34Y;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;->$side$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2cF;

    .line 1
    .line 2
    iget-wide v0, p1, LX/2cF;->A00:J

    .line 3
    .line 4
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;->invoke-ozmzZPI(J)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke-ozmzZPI(J)V
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;->$side$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$1$1;->$density:LX/34Y;

    .line 3
    .line 4
    invoke-static {p1, p2}, LX/001;->A09(J)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-interface {v1, v0}, LX/34Y;->AhT(I)F

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-static {v0, v2}, Landroidx/compose/runtime/MutableState;->A0L(FLandroidx/compose/runtime/MutableState;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
