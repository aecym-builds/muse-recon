.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final captureKey:I

.field public final headMovements:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILX/Ddn;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 10
    .line 11
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;ILX/Ddn;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p3, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 11
    .line 12
    :cond_1
    const/4 v0, 0x1

    .line 13
    invoke-static {p2, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 17
    .line 18
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;-><init>(ILX/Ddn;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 1
    .line 2
    return p0
.end method

.method public final component2()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(ILX/Ddn;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x1

    .line 1
    invoke-static {p2, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;-><init>(ILX/Ddn;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 9
    .line 10
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 11
    .line 12
    iget v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    :cond_0
    return v2

    .line 27
    :cond_1
    return v3
.end method

.method public final getCaptureKey()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 1
    .line 2
    return p0
.end method

.method public final getHeadMovements()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 1
    .line 2
    mul-int/lit8 v1, v0, 0x1f

    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 5
    .line 6
    invoke-static {v0, v1}, LX/006;->A0H(Ljava/lang/Object;I)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
