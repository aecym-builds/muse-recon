.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $animates$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $lifecycleState$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/15h;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $side$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;Landroidx/compose/runtime/MutableState;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "LX/1Ot;",
            ">;",
            "LX/16A<",
            "+",
            "LX/15h;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$animates$delegate:LX/16A;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$side$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$lifecycleState$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$animates$delegate:LX/16A;

    .line 1
    .line 2
    invoke-static {v0}, LX/16A;->A0C(LX/16A;)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$side$delegate:Landroidx/compose/runtime/MutableState;

    .line 10
    .line 11
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0F(Landroidx/compose/runtime/MutableState;)LX/1Ot;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget v1, v0, LX/1Ot;->A00:F

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-static {v1, v0}, LX/1Ot;->A00(FF)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-lez v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->$lifecycleState$delegate:LX/16A;

    .line 25
    .line 26
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, LX/15h;

    .line 31
    .line 32
    sget-object v0, LX/15h;->A06:LX/15h;

    .line 33
    .line 34
    invoke-virtual {v1, v0}, LX/15h;->A00(LX/15h;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    const/4 v2, 0x1

    .line 41
    :cond_0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$SelfieReviewShimmer$shimmer$1$1;->invoke()Ljava/lang/Boolean;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method
