.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final BOTTOM_ARC_CENTER:F = 90.0f

.field public static final COMPLETION_FLASH_FADE_MS:I = 0xc8

.field public static final COMPLETION_FLASH_HOLD_MS:J = 0x190L

.field public static final LEFT_ARC_CENTER:F = 180.0f

.field public static final QUARTER_DEGREES:F = 90.0f

.field public static final RIGHT_ARC_CENTER:F = 0.0f

.field public static final RING_ARC_COUNT:I = 0x4

.field public static final RING_ARC_SPAN_DEGREES:F = 86.0f

.field public static final SELFIE_RING_INSET:F = 12.0f

.field public static final TOP_ARC_CENTER:F = 270.0f


# direct methods
.method public static final SelfieMovementOverlay(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;",
            "LX/3C1;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v25, p1

    .line 1
    .line 2
    move-object/from16 v14, p3

    .line 3
    .line 4
    move-object/from16 v13, p5

    .line 5
    .line 6
    move/from16 v9, p4

    .line 7
    .line 8
    move-object/from16 v1, v25

    .line 9
    .line 10
    move-object/from16 v0, p2

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const v0, -0x785b49b

    .line 16
    .line 17
    .line 18
    move-object/from16 v12, p6

    .line 19
    .line 20
    invoke-interface {v12, v0}, LX/2d4;->Agl(I)V

    .line 21
    .line 22
    .line 23
    move/from16 v11, p7

    .line 24
    .line 25
    and-int/lit8 v0, p7, 0x6

    .line 26
    .line 27
    move-object/from16 v22, p0

    .line 28
    .line 29
    if-nez v0, :cond_10

    .line 30
    .line 31
    invoke-static/range {v22 .. v22}, LX/003;->A0G(Ljava/lang/Enum;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v12, v0}, LX/004;->A0E(LX/2d4;I)I

    .line 36
    .line 37
    .line 38
    move-result v10

    .line 39
    or-int v10, v10, p7

    .line 40
    .line 41
    :goto_0
    and-int/lit8 v0, p7, 0x30

    .line 42
    .line 43
    if-nez v0, :cond_0

    .line 44
    .line 45
    invoke-static {v12, v1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v10, v0

    .line 50
    :cond_0
    and-int/lit16 v0, v11, 0x180

    .line 51
    .line 52
    if-nez v0, :cond_1

    .line 53
    .line 54
    move-object/from16 v0, p2

    .line 55
    .line 56
    invoke-static {v12, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    or-int/2addr v10, v0

    .line 61
    :cond_1
    move/from16 p1, p8

    .line 62
    .line 63
    and-int/lit8 v4, p8, 0x8

    .line 64
    .line 65
    if-eqz v4, :cond_f

    .line 66
    .line 67
    or-int/lit16 v10, v10, 0xc00

    .line 68
    .line 69
    :cond_2
    :goto_1
    and-int/lit8 v1, p8, 0x10

    .line 70
    .line 71
    if-eqz v1, :cond_e

    .line 72
    .line 73
    or-int/lit16 v10, v10, 0x6000

    .line 74
    .line 75
    :cond_3
    :goto_2
    and-int/lit8 v3, p8, 0x20

    .line 76
    .line 77
    const/high16 v0, 0x30000

    .line 78
    .line 79
    if-nez v3, :cond_4

    .line 80
    .line 81
    and-int v0, p7, v0

    .line 82
    .line 83
    if-nez v0, :cond_5

    .line 84
    .line 85
    invoke-static {v12, v13}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    :cond_4
    or-int/2addr v10, v0

    .line 90
    :cond_5
    const v0, 0x12493

    .line 91
    .line 92
    .line 93
    and-int v2, v10, v0

    .line 94
    .line 95
    const v0, 0x12492

    .line 96
    .line 97
    .line 98
    const/16 v17, 0x1

    .line 99
    .line 100
    invoke-static {v2, v0}, LX/003;->A1H(II)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    invoke-static {v0, v12, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_d

    .line 109
    .line 110
    if-eqz v4, :cond_6

    .line 111
    .line 112
    sget-object v14, LX/3C1;->A00:LX/3Cb;

    .line 113
    .line 114
    :cond_6
    invoke-static {v1, v9}, LX/001;->A1P(IZ)Z

    .line 115
    .line 116
    .line 117
    move-result v9

    .line 118
    if-eqz v3, :cond_8

    .line 119
    .line 120
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v13

    .line 124
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 125
    .line 126
    if-ne v13, v0, :cond_7

    .line 127
    .line 128
    sget-object v13, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$1$1;

    .line 129
    .line 130
    invoke-interface {v12, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_7
    check-cast v13, Lkotlin/jvm/functions/Function0;

    .line 134
    .line 135
    :cond_8
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 136
    .line 137
    invoke-static {v12, v0}, LX/07H;->A04(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 138
    .line 139
    .line 140
    move-result-wide v6

    .line 141
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 142
    .line 143
    invoke-static {v1, v12}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 148
    .line 149
    iget-wide v4, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->elevatedBorder:J

    .line 150
    .line 151
    invoke-static {v1, v12}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 156
    .line 157
    iget-wide v2, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->accent:J

    .line 158
    .line 159
    invoke-static {v1, v12}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 164
    .line 165
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->success:J

    .line 166
    .line 167
    invoke-interface {v12, v6, v7}, LX/2d4;->A68(J)Z

    .line 168
    .line 169
    .line 170
    move-result v8

    .line 171
    invoke-static {v12, v4, v5, v8}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 172
    .line 173
    .line 174
    move-result v15

    .line 175
    invoke-static {v10}, LX/009;->A1M(I)Z

    .line 176
    .line 177
    .line 178
    move-result v8

    .line 179
    or-int/2addr v8, v15

    .line 180
    invoke-static {v10}, LX/005;->A1J(I)Z

    .line 181
    .line 182
    .line 183
    move-result v15

    .line 184
    or-int/2addr v8, v15

    .line 185
    invoke-static {v12, v0, v1, v8}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 186
    .line 187
    .line 188
    move-result v8

    .line 189
    invoke-static {v10}, LX/005;->A1E(I)Z

    .line 190
    .line 191
    .line 192
    move-result v15

    .line 193
    or-int/2addr v8, v15

    .line 194
    invoke-static {v12, v2, v3, v8}, LX/001;->A1T(LX/2d4;JZ)Z

    .line 195
    .line 196
    .line 197
    move-result v16

    .line 198
    invoke-static {v10}, LX/005;->A1H(I)Z

    .line 199
    .line 200
    .line 201
    move-result v8

    .line 202
    or-int v16, v16, v8

    .line 203
    .line 204
    const/high16 v8, 0x70000

    .line 205
    .line 206
    and-int/2addr v8, v10

    .line 207
    const/high16 v15, 0x20000

    .line 208
    .line 209
    if-eq v8, v15, :cond_9

    .line 210
    .line 211
    const/16 v17, 0x0

    .line 212
    .line 213
    :cond_9
    or-int v16, v16, v17

    .line 214
    .line 215
    invoke-interface {v12}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v8

    .line 219
    if-nez v16, :cond_a

    .line 220
    .line 221
    sget-object v15, LX/2d6;->A00:Ljava/lang/Object;

    .line 222
    .line 223
    if-ne v8, v15, :cond_b

    .line 224
    .line 225
    :cond_a
    new-instance v8, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;

    .line 226
    .line 227
    move-wide/from16 v27, v0

    .line 228
    .line 229
    move-wide/from16 v23, v2

    .line 230
    .line 231
    move-object/from16 v26, v13

    .line 232
    .line 233
    move-wide/from16 v18, v4

    .line 234
    .line 235
    move/from16 v20, v9

    .line 236
    .line 237
    move-object/from16 v21, p2

    .line 238
    .line 239
    move-object v15, v8

    .line 240
    move-wide/from16 v16, v6

    .line 241
    .line 242
    invoke-direct/range {v15 .. v28}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;-><init>(JJZLX/Ddn;Lcom/facebook/aura/activation/ageverification/HeadMovement;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;J)V

    .line 243
    .line 244
    .line 245
    invoke-interface {v12, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    :cond_b
    check-cast v8, LX/JDM;

    .line 249
    .line 250
    shr-int/lit8 v0, v10, 0x9

    .line 251
    .line 252
    and-int/lit8 v0, v0, 0xe

    .line 253
    .line 254
    invoke-static {v14, v8, v12, v0}, LX/1vS;->A00(LX/3C1;LX/JDM;LX/2d4;I)V

    .line 255
    .line 256
    .line 257
    :goto_3
    invoke-interface {v12}, LX/2d4;->AAg()LX/J7V;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    if-eqz v1, :cond_c

    .line 262
    .line 263
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;

    .line 264
    .line 265
    move-object/from16 v21, v0

    .line 266
    .line 267
    move-object/from16 v23, v25

    .line 268
    .line 269
    move-object/from16 v24, p2

    .line 270
    .line 271
    move-object/from16 v25, v14

    .line 272
    .line 273
    move/from16 v26, v9

    .line 274
    .line 275
    move-object/from16 v27, v13

    .line 276
    .line 277
    move/from16 p0, v11

    .line 278
    .line 279
    invoke-direct/range {v21 .. v29}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$3;-><init>(Lcom/facebook/aura/activation/ageverification/HeadMovement;Lkotlin/jvm/functions/Function0;LX/Ddn;LX/3C1;ZLkotlin/jvm/functions/Function0;II)V

    .line 280
    .line 281
    .line 282
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 283
    .line 284
    :cond_c
    return-void

    .line 285
    :cond_d
    invoke-interface {v12}, LX/2d4;->AgJ()V

    .line 286
    .line 287
    .line 288
    goto :goto_3

    .line 289
    :cond_e
    and-int/lit16 v0, v11, 0x6000

    .line 290
    .line 291
    if-nez v0, :cond_3

    .line 292
    .line 293
    invoke-static {v12, v9}, LX/004;->A0m(LX/2d4;Z)I

    .line 294
    .line 295
    .line 296
    move-result v0

    .line 297
    or-int/2addr v10, v0

    .line 298
    goto/16 :goto_2

    .line 299
    .line 300
    :cond_f
    and-int/lit16 v0, v11, 0xc00

    .line 301
    .line 302
    if-nez v0, :cond_2

    .line 303
    .line 304
    invoke-static {v12, v14}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 305
    .line 306
    .line 307
    move-result v0

    .line 308
    or-int/2addr v10, v0

    .line 309
    goto/16 :goto_1

    .line 310
    .line 311
    :cond_10
    move v10, v11

    .line 312
    goto/16 :goto_0
.end method

.method public static final synthetic access$drawReviewFill-iJQMabo(LX/2la;JLX/2RO;FF)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawReviewFill-iJQMabo(LX/2la;JLX/2RO;FF)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$drawSelfieFrame-1wkBAMs(LX/2la;JJLX/2RO;Z)F
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawSelfieFrame-1wkBAMs(LX/2la;JJLX/2RO;Z)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final completionFlash(LX/2d4;I)LX/16A;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/16A<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object v0

    .line 4
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    invoke-static {p0, v0, v4}, LX/005;->A0i(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    check-cast v2, LX/Dvf;

    .line 12
    .line 13
    invoke-interface {p0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    if-nez v1, :cond_0

    .line 22
    .line 23
    if-ne v0, v4, :cond_1

    .line 24
    .line 25
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;

    .line 26
    .line 27
    invoke-direct {v0, v2, v3}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$completionFlash$1$1;-><init>(LX/Dvf;LX/2M4;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p0, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    invoke-static {p0, v0, v2}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object v0, v2, LX/Dvf;->A04:LX/Dvh;

    .line 37
    .line 38
    return-object v0
.end method

.method public static final drawArcFromStart-3IgeMak(LX/2la;JLX/2RO;FFF)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    cmpg-float v0, p6, v0

    .line 2
    .line 3
    if-lez v0, :cond_1

    .line 4
    .line 5
    const/high16 v0, 0x422c0000    # 43.0f

    .line 6
    .line 7
    sub-float/2addr p5, v0

    .line 8
    const/high16 v0, 0x3f800000    # 1.0f

    .line 9
    .line 10
    cmpl-float v0, p6, v0

    .line 11
    .line 12
    if-lez v0, :cond_0

    .line 13
    .line 14
    const/high16 p6, 0x3f800000    # 1.0f

    .line 15
    .line 16
    :cond_0
    const/high16 v0, 0x42ac0000    # 86.0f

    .line 17
    .line 18
    mul-float/2addr p6, v0

    .line 19
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingSweep-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 20
    .line 21
    .line 22
    :cond_1
    return-void
.end method

.method public static final drawReviewFill-iJQMabo(LX/2la;JLX/2RO;FF)V
    .locals 12

    .line 0
    const/4 v4, 0x4

    .line 1
    const/high16 v3, 0x40800000    # 4.0f

    .line 2
    .line 3
    mul-float v3, v3, p5

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :cond_0
    int-to-float v1, v2

    .line 7
    const/high16 v10, 0x42b40000    # 90.0f

    .line 8
    .line 9
    mul-float/2addr v10, v1

    .line 10
    const/high16 v0, 0x43870000    # 270.0f

    .line 11
    .line 12
    add-float/2addr v10, v0

    .line 13
    sub-float v11, v3, v1

    .line 14
    .line 15
    move-object v5, p0

    .line 16
    move-wide v6, p1

    .line 17
    move-object v8, p3

    .line 18
    move/from16 v9, p4

    .line 19
    .line 20
    invoke-static/range {v5 .. v11}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawArcFromStart-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 21
    .line 22
    .line 23
    add-int/lit8 v2, v2, 0x1

    .line 24
    .line 25
    if-lt v2, v4, :cond_0

    .line 26
    .line 27
    return-void
.end method

.method public static final drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    cmpg-float v0, p6, v1

    .line 2
    .line 3
    if-lez v0, :cond_0

    .line 4
    .line 5
    const/high16 v0, 0x3f800000    # 1.0f

    .line 6
    .line 7
    invoke-static {p6, v1, v0}, LX/34j;->A04(FFF)F

    .line 8
    .line 9
    .line 10
    move-result p6

    .line 11
    const/high16 v0, 0x42ac0000    # 86.0f

    .line 12
    .line 13
    mul-float/2addr p6, v0

    .line 14
    const/high16 v0, 0x40000000    # 2.0f

    .line 15
    .line 16
    div-float v0, p6, v0

    .line 17
    .line 18
    sub-float/2addr p5, v0

    .line 19
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingSweep-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public static final drawRingSweep-3IgeMak(LX/2la;JLX/2RO;FFF)V
    .locals 21

    .line 0
    move-object/from16 v8, p0

    .line 1
    .line 2
    invoke-interface {v8}, LX/2la;->ADd()J

    .line 3
    .line 4
    .line 5
    move-result-wide v4

    .line 6
    invoke-static/range {p4 .. p4}, LX/001;->A0F(F)J

    .line 7
    .line 8
    .line 9
    move-result-wide v6

    .line 10
    const/16 v0, 0x20

    .line 11
    .line 12
    shl-long v2, v6, v0

    .line 13
    .line 14
    const-wide v0, 0xffffffffL

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    and-long/2addr v6, v0

    .line 20
    or-long/2addr v2, v6

    .line 21
    invoke-static {v4, v5, v2, v3}, LX/2qg;->A03(JJ)J

    .line 22
    .line 23
    .line 24
    move-result-wide v17

    .line 25
    const/high16 v0, 0x40000000    # 2.0f

    .line 26
    .line 27
    mul-float v0, v0, p4

    .line 28
    .line 29
    invoke-static {v0}, LX/004;->A0t(F)J

    .line 30
    .line 31
    .line 32
    move-result-wide v19

    .line 33
    const/4 v9, 0x0

    .line 34
    const/16 p0, 0x0

    .line 35
    .line 36
    const/high16 v13, 0x3f800000    # 1.0f

    .line 37
    .line 38
    const/4 v14, 0x3

    .line 39
    move-wide/from16 v15, p1

    .line 40
    .line 41
    move-object/from16 v10, p3

    .line 42
    .line 43
    move/from16 v11, p5

    .line 44
    .line 45
    move/from16 v12, p6

    .line 46
    .line 47
    invoke-interface/range {v8 .. v21}, LX/2la;->A9P(LX/2hc;LX/2Qt;FFFIJJJZ)V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public static final drawSelfieFrame-1wkBAMs(LX/2la;JJLX/2RO;Z)F
    .locals 18

    .line 0
    move-object/from16 v9, p0

    .line 1
    .line 2
    invoke-static {v9}, LX/2RQ;->A02(LX/2la;)F

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    const/high16 v0, 0x40000000    # 2.0f

    .line 7
    .line 8
    div-float p0, p0, v0

    .line 9
    .line 10
    sget v5, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SELFIE_RING_INSET:F

    .line 11
    .line 12
    mul-float/2addr v0, v5

    .line 13
    invoke-interface {v9, v0}, LX/34Y;->AhZ(F)F

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    sub-float p0, p0, v0

    .line 18
    .line 19
    invoke-static {}, LX/2ak;->A00()LX/2bQ;

    .line 20
    .line 21
    .line 22
    move-result-object v7

    .line 23
    invoke-interface {v9}, LX/2la;->ADd()J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    invoke-static {v0, v1}, LX/004;->A03(J)F

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    sub-float v2, v3, p0

    .line 32
    .line 33
    invoke-static {v0, v1}, LX/004;->A02(J)F

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    sub-float v0, v1, p0

    .line 38
    .line 39
    add-float v3, v3, p0

    .line 40
    .line 41
    add-float v1, v1, p0

    .line 42
    .line 43
    invoke-static {v2, v0, v3, v1}, LX/001;->A0c(FFFF)LX/36Z;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const/4 v8, 0x0

    .line 48
    invoke-virtual {v7, v0}, LX/2bQ;->A00(LX/36Z;)V

    .line 49
    .line 50
    .line 51
    const/4 v6, 0x0

    .line 52
    invoke-interface {v9}, LX/2la;->AEy()LX/2lC;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    move-object v2, v4

    .line 57
    check-cast v2, LX/2kf;

    .line 58
    .line 59
    iget-object v0, v2, LX/2kf;->A02:LX/2kc;

    .line 60
    .line 61
    iget-object v3, v0, LX/2kc;->A02:LX/2kt;

    .line 62
    .line 63
    invoke-static {v3}, LX/2kd;->A00(LX/2kt;)J

    .line 64
    .line 65
    .line 66
    move-result-wide v0

    .line 67
    :try_start_0
    iget-object v2, v2, LX/2kf;->A01:LX/2lA;

    .line 68
    .line 69
    invoke-interface {v2, v7, v6}, LX/2lA;->A6Q(LX/2lV;I)V

    .line 70
    .line 71
    .line 72
    const/16 v11, 0x7e

    .line 73
    .line 74
    const-wide/16 v14, 0x0

    .line 75
    .line 76
    const/4 v10, 0x0

    .line 77
    move-wide/from16 v12, p1

    .line 78
    .line 79
    move-wide/from16 v16, v14

    .line 80
    .line 81
    invoke-static/range {v8 .. v17}, LX/2lb;->A01(LX/2hc;LX/2la;FIJJJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 82
    .line 83
    .line 84
    invoke-static {v3, v4, v0, v1}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 85
    .line 86
    .line 87
    invoke-interface {v9, v5}, LX/34Y;->AhZ(F)F

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    add-float p0, p0, v0

    .line 92
    .line 93
    invoke-static {}, Lcom/facebook/aura/activation/ageverification/HeadMovement;->getEntries()LX/0vk;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    move-wide/from16 v15, p3

    .line 106
    .line 107
    move-object/from16 v17, p5

    .line 108
    .line 109
    if-eqz v0, :cond_0

    .line 110
    .line 111
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 116
    .line 117
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    const/high16 p2, 0x3f800000    # 1.0f

    .line 122
    .line 123
    move-object v14, v9

    .line 124
    invoke-static/range {v14 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 125
    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_0
    if-eqz p6, :cond_1

    .line 129
    .line 130
    const/high16 p1, 0x42b40000    # 90.0f

    .line 131
    .line 132
    const/high16 p2, 0x3f800000    # 1.0f

    .line 133
    .line 134
    move-object v14, v9

    .line 135
    invoke-static/range {v14 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 136
    .line 137
    .line 138
    :cond_1
    return p0

    .line 139
    :catchall_0
    move-exception v2

    .line 140
    invoke-static {v3, v4, v0, v1}, LX/2kd;->A01(LX/2kt;LX/2lC;J)V

    .line 141
    .line 142
    .line 143
    throw v2
.end method

.method public static final getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F
    .locals 1

    .line 0
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq p0, v0, :cond_2

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq p0, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    if-ne p0, v0, :cond_0

    .line 12
    .line 13
    const/high16 v0, 0x43340000    # 180.0f

    .line 14
    .line 15
    return v0

    .line 16
    :cond_0
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    throw v0

    .line 21
    :cond_1
    const/high16 v0, 0x43870000    # 270.0f

    .line 22
    .line 23
    return v0

    .line 24
    :cond_2
    const/4 v0, 0x0

    .line 25
    return v0
.end method

.method public static final getSELFIE_RING_INSET()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->SELFIE_RING_INSET:F

    .line 1
    .line 2
    return v0
.end method

.method public static final rememberCompletionFlashes(LX/Ddn;LX/2d4;I)LX/Ddn;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v7, 0x0

    .line 1
    invoke-static {p0, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const v0, -0x15bc0d72

    .line 5
    .line 6
    .line 7
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 8
    .line 9
    .line 10
    invoke-static {p0}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 11
    .line 12
    .line 13
    move-result-object v6

    .line 14
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    const/4 v4, 0x0

    .line 19
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    add-int/lit8 v2, v4, 0x1

    .line 30
    .line 31
    if-gez v4, :cond_0

    .line 32
    .line 33
    invoke-static {}, LX/B8B;->A1A()V

    .line 34
    .line 35
    .line 36
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    throw v0

    .line 41
    :cond_0
    check-cast v3, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 42
    .line 43
    const v1, -0x6365a601

    .line 44
    .line 45
    .line 46
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-interface {p1, v1, v0}, LX/2d4;->Agd(ILjava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1, v7}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->completionFlash(LX/2d4;I)LX/16A;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CompletionFlash;

    .line 58
    .line 59
    invoke-direct {v0, v3, v1}, Lcom/facebook/aura/activation/ageverification/CompletionFlash;-><init>(Lcom/facebook/aura/activation/ageverification/HeadMovement;LX/16A;)V

    .line 60
    .line 61
    .line 62
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move v4, v2

    .line 69
    goto :goto_0

    .line 70
    :cond_1
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    invoke-static {v6}, LX/Dwp;->A00(Ljava/lang/Iterable;)LX/Ddn;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    return-object v0
.end method
