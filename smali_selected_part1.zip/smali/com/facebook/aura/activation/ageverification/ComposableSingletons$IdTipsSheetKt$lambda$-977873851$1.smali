.class public final Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt$lambda$-977873851$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 2

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object p1, p2

    .line 5
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    const v0, 0x7f120071

    .line 13
    .line 14
    .line 15
    const v1, 0x7f120070

    .line 16
    .line 17
    .line 18
    const/4 p2, 0x0

    .line 19
    const/4 p3, 0x4

    .line 20
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt;->CaptureTip(IILX/3C1;LX/2d4;II)V

    .line 21
    .line 22
    .line 23
    const v0, 0x7f120073

    .line 24
    .line 25
    .line 26
    const v1, 0x7f120072

    .line 27
    .line 28
    .line 29
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt;->CaptureTip(IILX/3C1;LX/2d4;II)V

    .line 30
    .line 31
    .line 32
    const v0, 0x7f12006f

    .line 33
    .line 34
    .line 35
    const v1, 0x7f12006e

    .line 36
    .line 37
    .line 38
    invoke-static/range {v0 .. v5}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt;->CaptureTip(IILX/3C1;LX/2d4;II)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 43
    .line 44
    .line 45
    return-void
.end method
