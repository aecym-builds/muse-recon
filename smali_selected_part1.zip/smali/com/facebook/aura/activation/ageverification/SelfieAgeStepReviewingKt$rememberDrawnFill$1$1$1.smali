.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Long;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $current$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $drawn:LX/2ss;

.field public final synthetic $lastFrameNanos:LX/1AM;


# direct methods
.method public constructor <init>(LX/1AM;LX/2ss;LX/16A;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1AM;",
            "LX/2ss;",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$lastFrameNanos:LX/1AM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$drawn:LX/2ss;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$current$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-wide v0

    .line 268435460
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->invoke(J)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(J)V
    .locals 7

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$current$delegate:LX/16A;

    .line 1
    .line 2
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    check-cast v2, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 7
    .line 8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    invoke-static {v2, v0, v1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->reviewFraction(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;J)F

    .line 13
    .line 14
    .line 15
    move-result v6

    .line 16
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$lastFrameNanos:LX/1AM;

    .line 17
    .line 18
    iget-wide v0, v4, LX/1AM;->element:J

    .line 19
    .line 20
    sub-long v2, p1, v0

    .line 21
    .line 22
    long-to-float v1, v2

    .line 23
    const v0, 0x49742400    # 1000000.0f

    .line 24
    .line 25
    .line 26
    div-float/2addr v1, v0

    .line 27
    iput-wide p1, v4, LX/1AM;->element:J

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$drawn:LX/2ss;

    .line 30
    .line 31
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$drawn:LX/2ss;

    .line 36
    .line 37
    invoke-interface {v0}, LX/2ss;->AFu()F

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    sub-float v5, v6, v0

    .line 42
    .line 43
    const/4 v0, 0x0

    .line 44
    cmpg-float v0, v5, v0

    .line 45
    .line 46
    if-gez v0, :cond_0

    .line 47
    .line 48
    const/4 v5, 0x0

    .line 49
    :cond_0
    const/high16 v3, 0x3f800000    # 1.0f

    .line 50
    .line 51
    neg-float v1, v1

    .line 52
    const/high16 v0, 0x43960000    # 300.0f

    .line 53
    .line 54
    div-float/2addr v1, v0

    .line 55
    float-to-double v0, v1

    .line 56
    invoke-static {v0, v1}, Ljava/lang/Math;->exp(D)D

    .line 57
    .line 58
    .line 59
    move-result-wide v1

    .line 60
    double-to-float v0, v1

    .line 61
    sub-float v0, v3, v0

    .line 62
    .line 63
    mul-float/2addr v5, v0

    .line 64
    add-float/2addr v4, v5

    .line 65
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt$rememberDrawnFill$1$1$1;->$drawn:LX/2ss;

    .line 66
    .line 67
    cmpl-float v0, v6, v3

    .line 68
    .line 69
    if-ltz v0, :cond_1

    .line 70
    .line 71
    const v0, 0x3f7fbe77    # 0.999f

    .line 72
    .line 73
    .line 74
    cmpl-float v0, v4, v0

    .line 75
    .line 76
    if-lez v0, :cond_1

    .line 77
    .line 78
    const/high16 v4, 0x3f800000    # 1.0f

    .line 79
    .line 80
    :cond_1
    invoke-interface {v1, v4}, LX/2ss;->Adw(F)V

    .line 81
    .line 82
    .line 83
    return-void
.end method
