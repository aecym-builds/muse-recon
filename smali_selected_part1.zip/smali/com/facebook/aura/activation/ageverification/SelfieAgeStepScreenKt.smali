.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final SETTINGS_ACTION_KEY:Ljava/lang/String; = "age-check-settings"


# direct methods
.method public static final SelfieAgeStep(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 61
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v19, p7

    .line 1
    .line 2
    const/4 v13, 0x1

    .line 3
    move-object/from16 v60, p1

    .line 4
    .line 5
    move-object/from16 v0, v60

    .line 6
    .line 7
    invoke-static {v0, v13}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/4 v12, 0x2

    .line 11
    move-object/from16 v59, p2

    .line 12
    .line 13
    move-object/from16 v15, p3

    .line 14
    .line 15
    move-object/from16 v57, p5

    .line 16
    .line 17
    move-object/from16 v1, v59

    .line 18
    .line 19
    move-object/from16 v0, v57

    .line 20
    .line 21
    invoke-static {v1, v15, v0, v12}, LX/009;->A14(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x6

    .line 25
    move-object/from16 v3, p6

    .line 26
    .line 27
    invoke-static {v3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 28
    .line 29
    .line 30
    const v0, -0x28c02a56

    .line 31
    .line 32
    .line 33
    move-object/from16 v1, p8

    .line 34
    .line 35
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 36
    .line 37
    .line 38
    move/from16 v0, p9

    .line 39
    .line 40
    and-int/lit8 v2, p9, 0x6

    .line 41
    .line 42
    if-nez v2, :cond_19

    .line 43
    .line 44
    move/from16 v2, p0

    .line 45
    .line 46
    invoke-static {v1, v2}, LX/004;->A0i(LX/2d4;Z)I

    .line 47
    .line 48
    .line 49
    move-result v11

    .line 50
    or-int v11, v11, p9

    .line 51
    .line 52
    :goto_0
    and-int/lit8 v2, p9, 0x30

    .line 53
    .line 54
    if-nez v2, :cond_0

    .line 55
    .line 56
    move-object/from16 v2, v60

    .line 57
    .line 58
    invoke-static {v1, v2}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    or-int/2addr v11, v2

    .line 63
    :cond_0
    and-int/lit16 v2, v0, 0x180

    .line 64
    .line 65
    if-nez v2, :cond_1

    .line 66
    .line 67
    move-object/from16 v2, v59

    .line 68
    .line 69
    invoke-static {v1, v2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    or-int/2addr v11, v2

    .line 74
    :cond_1
    and-int/lit16 v2, v0, 0xc00

    .line 75
    .line 76
    if-nez v2, :cond_2

    .line 77
    .line 78
    invoke-static {v1, v15}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    or-int/2addr v11, v2

    .line 83
    :cond_2
    and-int/lit16 v2, v0, 0x6000

    .line 84
    .line 85
    move/from16 v58, p4

    .line 86
    .line 87
    if-nez v2, :cond_3

    .line 88
    .line 89
    move/from16 v2, v58

    .line 90
    .line 91
    invoke-static {v1, v2}, LX/004;->A0H(LX/2d4;I)I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    or-int/2addr v11, v2

    .line 96
    :cond_3
    const/high16 v2, 0x30000

    .line 97
    .line 98
    and-int v2, v2, p9

    .line 99
    .line 100
    if-nez v2, :cond_4

    .line 101
    .line 102
    move-object/from16 v2, v57

    .line 103
    .line 104
    invoke-static {v1, v2}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    or-int/2addr v11, v2

    .line 109
    :cond_4
    const/high16 v2, 0x180000

    .line 110
    .line 111
    and-int v2, v2, p9

    .line 112
    .line 113
    if-nez v2, :cond_5

    .line 114
    .line 115
    invoke-static {v1, v3}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    or-int/2addr v11, v2

    .line 120
    :cond_5
    move/from16 v56, p10

    .line 121
    .line 122
    move/from16 v2, v56

    .line 123
    .line 124
    and-int/lit16 v5, v2, 0x80

    .line 125
    .line 126
    const/high16 v2, 0xc00000

    .line 127
    .line 128
    if-nez v5, :cond_6

    .line 129
    .line 130
    and-int v2, v2, p9

    .line 131
    .line 132
    if-nez v2, :cond_7

    .line 133
    .line 134
    move-object/from16 v2, v19

    .line 135
    .line 136
    invoke-static {v1, v2}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    :cond_6
    or-int/2addr v11, v2

    .line 141
    :cond_7
    const v4, 0x492493

    .line 142
    .line 143
    .line 144
    and-int/2addr v4, v11

    .line 145
    const v2, 0x492492

    .line 146
    .line 147
    .line 148
    invoke-static {v4, v2}, LX/003;->A1H(II)Z

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    invoke-static {v2, v1, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 153
    .line 154
    .line 155
    move-result v2

    .line 156
    if-eqz v2, :cond_18

    .line 157
    .line 158
    if-eqz v5, :cond_8

    .line 159
    .line 160
    sget-object v19, LX/3C1;->A00:LX/3Cb;

    .line 161
    .line 162
    :cond_8
    sget-object v2, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->A01:LX/Ip3;

    .line 163
    .line 164
    move-object v10, v1

    .line 165
    check-cast v10, LX/J7I;

    .line 166
    .line 167
    invoke-static {v2, v10}, LX/004;->A0w(LX/Iow;LX/J7I;)Landroid/content/Context;

    .line 168
    .line 169
    .line 170
    move-result-object v5

    .line 171
    invoke-static {v10}, LX/005;->A0f(LX/J7I;)LX/AHE;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    check-cast v2, LX/AHu;

    .line 176
    .line 177
    iget-object v4, v2, LX/AHu;->A01:Ljava/lang/String;

    .line 178
    .line 179
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 180
    .line 181
    .line 182
    move-result-object v2

    .line 183
    invoke-static {v2}, LX/I1c;->A0b(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    new-instance v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;

    .line 187
    .line 188
    invoke-direct {v7, v2, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel$Factory;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-static {v1}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 192
    .line 193
    .line 194
    move-result-object v6

    .line 195
    if-eqz v6, :cond_1a

    .line 196
    .line 197
    invoke-static {v6}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 198
    .line 199
    .line 200
    move-result-object v5

    .line 201
    const-class v2, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 202
    .line 203
    invoke-static {v2}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 204
    .line 205
    .line 206
    move-result-object v4

    .line 207
    const/4 v2, 0x0

    .line 208
    const/16 v20, 0x0

    .line 209
    .line 210
    invoke-static {v7, v6, v5, v4}, LX/13Z;->A00(LX/15L;LX/13Z;LX/13i;LX/DVF;)LX/1EJ;

    .line 211
    .line 212
    .line 213
    move-result-object v6

    .line 214
    check-cast v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 215
    .line 216
    iget-object v4, v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->state:LX/2J3;

    .line 217
    .line 218
    invoke-static {v1, v4, v2}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 219
    .line 220
    .line 221
    move-result-object v18

    .line 222
    move-object/from16 v4, v60

    .line 223
    .line 224
    invoke-static {v1, v4}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 225
    .line 226
    .line 227
    move-result-object v14

    .line 228
    move-object/from16 v4, v59

    .line 229
    .line 230
    invoke-static {v1, v4}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 231
    .line 232
    .line 233
    move-result-object v9

    .line 234
    shr-int/lit8 v17, v11, 0x9

    .line 235
    .line 236
    invoke-static {v1, v15}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 237
    .line 238
    .line 239
    move-result-object v8

    .line 240
    shr-int/lit8 v16, v11, 0x12

    .line 241
    .line 242
    invoke-static {v1, v3}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 243
    .line 244
    .line 245
    move-result-object v7

    .line 246
    invoke-interface {v1, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v4

    .line 250
    invoke-static {v1, v14, v9, v8, v4}, LX/005;->A1S(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 251
    .line 252
    .line 253
    move-result v4

    .line 254
    invoke-static {v1, v7, v4}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 255
    .line 256
    .line 257
    move-result v5

    .line 258
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v4

    .line 262
    if-nez v5, :cond_9

    .line 263
    .line 264
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 265
    .line 266
    if-ne v4, v5, :cond_a

    .line 267
    .line 268
    :cond_9
    new-instance v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1;

    .line 269
    .line 270
    move-object/from16 v26, v7

    .line 271
    .line 272
    move-object/from16 v27, v20

    .line 273
    .line 274
    move-object/from16 v21, v4

    .line 275
    .line 276
    move-object/from16 v22, v6

    .line 277
    .line 278
    move-object/from16 v23, v14

    .line 279
    .line 280
    move-object/from16 v24, v9

    .line 281
    .line 282
    move-object/from16 v25, v8

    .line 283
    .line 284
    invoke-direct/range {v21 .. v27}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;LX/2M4;)V

    .line 285
    .line 286
    .line 287
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 288
    .line 289
    .line 290
    :cond_a
    check-cast v4, LX/JDN;

    .line 291
    .line 292
    sget v25, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->$stable:I

    .line 293
    .line 294
    invoke-static {v1, v6, v4}, LX/CdB;->A06(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 295
    .line 296
    .line 297
    sget-object v4, LX/3J2;->A00:LX/Ip3;

    .line 298
    .line 299
    invoke-static {v4, v10}, LX/002;->A0u(LX/Iow;LX/J7I;)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v7

    .line 303
    check-cast v7, Landroid/app/Activity;

    .line 304
    .line 305
    invoke-static {v1, v6, v7}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move-result v5

    .line 309
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v4

    .line 313
    if-nez v5, :cond_b

    .line 314
    .line 315
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 316
    .line 317
    if-ne v4, v5, :cond_c

    .line 318
    .line 319
    :cond_b
    new-instance v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$2$1;

    .line 320
    .line 321
    invoke-direct {v4, v6, v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$2$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Landroid/app/Activity;)V

    .line 322
    .line 323
    .line 324
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 325
    .line 326
    .line 327
    :cond_c
    invoke-static {v1, v4, v6}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 328
    .line 329
    .line 330
    invoke-static/range {v58 .. v58}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 331
    .line 332
    .line 333
    move-result-object v7

    .line 334
    invoke-interface {v1, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 335
    .line 336
    .line 337
    move-result v8

    .line 338
    invoke-static {v11}, LX/009;->A1M(I)Z

    .line 339
    .line 340
    .line 341
    move-result v4

    .line 342
    or-int/2addr v8, v4

    .line 343
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v5

    .line 347
    if-nez v8, :cond_d

    .line 348
    .line 349
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 350
    .line 351
    if-ne v5, v4, :cond_e

    .line 352
    .line 353
    :cond_d
    new-instance v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;

    .line 354
    .line 355
    move/from16 v4, v58

    .line 356
    .line 357
    invoke-direct {v5, v6, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$3$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;I)V

    .line 358
    .line 359
    .line 360
    invoke-interface {v1, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 361
    .line 362
    .line 363
    :cond_e
    invoke-static {v1, v5, v6, v7}, LX/001;->A1I(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 364
    .line 365
    .line 366
    invoke-interface {v1, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 367
    .line 368
    .line 369
    move-result v5

    .line 370
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v4

    .line 374
    if-nez v5, :cond_f

    .line 375
    .line 376
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 377
    .line 378
    if-ne v4, v5, :cond_10

    .line 379
    .line 380
    :cond_f
    new-instance v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$4$1;

    .line 381
    .line 382
    invoke-direct {v4, v6}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$4$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;)V

    .line 383
    .line 384
    .line 385
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 386
    .line 387
    .line 388
    :cond_10
    check-cast v4, LX/JDM;

    .line 389
    .line 390
    move-object/from16 v21, v1

    .line 391
    .line 392
    move-object/from16 v22, v20

    .line 393
    .line 394
    move-object/from16 v23, v6

    .line 395
    .line 396
    move-object/from16 v24, v4

    .line 397
    .line 398
    move/from16 v26, v12

    .line 399
    .line 400
    invoke-static/range {v21 .. v26}, LX/CcX;->A05(LX/2d4;LX/07p;Ljava/lang/Object;LX/JDM;II)V

    .line 401
    .line 402
    .line 403
    invoke-interface {v1, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 404
    .line 405
    .line 406
    move-result v5

    .line 407
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v4

    .line 411
    if-nez v5, :cond_11

    .line 412
    .line 413
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 414
    .line 415
    if-ne v4, v5, :cond_12

    .line 416
    .line 417
    :cond_11
    new-instance v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$5$1;

    .line 418
    .line 419
    invoke-direct {v4, v6}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$5$1;-><init>(Ljava/lang/Object;)V

    .line 420
    .line 421
    .line 422
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 423
    .line 424
    .line 425
    :cond_12
    check-cast v4, LX/DqV;

    .line 426
    .line 427
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 428
    .line 429
    invoke-static {v2, v4, v1, v2, v13}, Lcom/facebook/aura/navigation/AuraTerminalBackHandlerKt;->AuraTerminalBackHandler(ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 430
    .line 431
    .line 432
    invoke-interface/range {v18 .. v18}, LX/16A;->getValue()Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v5

    .line 436
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 437
    .line 438
    sget-object v4, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 439
    .line 440
    invoke-static {v4, v10}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 441
    .line 442
    .line 443
    move-result-object v8

    .line 444
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModelKt;->getShowsBack(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)Z

    .line 445
    .line 446
    .line 447
    move-result v9

    .line 448
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModelKt;->getShowsHelp(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)Z

    .line 449
    .line 450
    .line 451
    move-result v10

    .line 452
    invoke-static {v1, v6, v8}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 453
    .line 454
    .line 455
    move-result v4

    .line 456
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v7

    .line 460
    if-nez v4, :cond_13

    .line 461
    .line 462
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 463
    .line 464
    if-ne v7, v4, :cond_14

    .line 465
    .line 466
    :cond_13
    new-instance v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$headerActions$1$1;

    .line 467
    .line 468
    invoke-direct {v7, v6, v8}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$headerActions$1$1;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 469
    .line 470
    .line 471
    invoke-interface {v1, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 472
    .line 473
    .line 474
    :cond_14
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 475
    .line 476
    move/from16 v4, v17

    .line 477
    .line 478
    and-int/lit16 v4, v4, 0x380

    .line 479
    .line 480
    move-object/from16 v11, v57

    .line 481
    .line 482
    move-object v12, v7

    .line 483
    move-object v13, v1

    .line 484
    move v14, v4

    .line 485
    invoke-static/range {v9 .. v14}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->rememberAgeStepHeaderActions(ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/Ddn;

    .line 486
    .line 487
    .line 488
    move-result-object v34

    .line 489
    sget-object v18, Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraContainer$PrimaryScreen;

    .line 490
    .line 491
    invoke-interface {v1, v6}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 492
    .line 493
    .line 494
    move-result v7

    .line 495
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v4

    .line 499
    if-nez v7, :cond_15

    .line 500
    .line 501
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 502
    .line 503
    if-ne v4, v7, :cond_16

    .line 504
    .line 505
    :cond_15
    new-instance v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$6$1;

    .line 506
    .line 507
    invoke-direct {v4, v6}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$6$1;-><init>(Ljava/lang/Object;)V

    .line 508
    .line 509
    .line 510
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 511
    .line 512
    .line 513
    :cond_16
    check-cast v4, LX/DqV;

    .line 514
    .line 515
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 516
    .line 517
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModelKt;->getShowsBack(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;)Z

    .line 518
    .line 519
    .line 520
    move-result v28

    .line 521
    const/16 v41, 0x0

    .line 522
    .line 523
    new-instance v8, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;

    .line 524
    .line 525
    move/from16 v7, p0

    .line 526
    .line 527
    invoke-direct {v8, v5, v6, v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$7;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;Z)V

    .line 528
    .line 529
    .line 530
    const v5, -0x1cf5f091

    .line 531
    .line 532
    .line 533
    invoke-static {v1, v8, v5}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 534
    .line 535
    .line 536
    move-result-object v50

    .line 537
    and-int/lit8 v5, v16, 0x70

    .line 538
    .line 539
    or-int/lit8 v52, v5, 0x6

    .line 540
    .line 541
    const v54, 0x30000006

    .line 542
    .line 543
    .line 544
    const v55, 0x1fef7dbc

    .line 545
    .line 546
    .line 547
    const-wide/16 v21, 0x0

    .line 548
    .line 549
    move-object/from16 v23, v20

    .line 550
    .line 551
    move-object/from16 v24, v20

    .line 552
    .line 553
    move-object/from16 v26, v20

    .line 554
    .line 555
    move/from16 v27, v2

    .line 556
    .line 557
    move/from16 v29, v2

    .line 558
    .line 559
    move-object/from16 v30, v20

    .line 560
    .line 561
    move-object/from16 v31, v20

    .line 562
    .line 563
    move-object/from16 v32, v20

    .line 564
    .line 565
    move-object/from16 v33, v20

    .line 566
    .line 567
    move-object/from16 v35, v20

    .line 568
    .line 569
    move-wide/from16 v36, v21

    .line 570
    .line 571
    move-wide/from16 v38, v21

    .line 572
    .line 573
    move-object/from16 v40, v20

    .line 574
    .line 575
    move-object/from16 v42, v20

    .line 576
    .line 577
    move-object/from16 v43, v20

    .line 578
    .line 579
    move-object/from16 v44, v20

    .line 580
    .line 581
    move/from16 v45, v2

    .line 582
    .line 583
    move-object/from16 v46, v20

    .line 584
    .line 585
    move-object/from16 v47, v20

    .line 586
    .line 587
    move-object/from16 v48, v20

    .line 588
    .line 589
    move/from16 v49, v2

    .line 590
    .line 591
    move-object/from16 v51, v1

    .line 592
    .line 593
    move/from16 v53, v2

    .line 594
    .line 595
    move-object/from16 v25, v4

    .line 596
    .line 597
    invoke-static/range {v18 .. v55}, Lcom/facebook/aura/header/view/HatchPageScreenKt;->HatchPageScreen-ZOc-clw(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraScreen;LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;JLjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/header/view/HatchHeaderTitleAlignment;ZZILjava/lang/String;LX/JDN;LX/Ddn;LX/JDM;LX/Ddn;LX/JDN;JJLX/2hg;FLcom/facebook/aura/header/view/ScrimConfig;LX/3C1;LX/3C1;ILX/JDN;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Lcom/facebook/aura/header/view/HatchBackClickAnalytics;ZLX/JDO;LX/2d4;IIII)V

    .line 598
    .line 599
    .line 600
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 601
    .line 602
    .line 603
    move-result-object v2

    .line 604
    if-eqz v2, :cond_17

    .line 605
    .line 606
    new-instance v1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;

    .line 607
    .line 608
    move-object v4, v1

    .line 609
    move/from16 v5, p0

    .line 610
    .line 611
    move-object/from16 v6, v60

    .line 612
    .line 613
    move-object/from16 v7, v59

    .line 614
    .line 615
    move-object v8, v15

    .line 616
    move/from16 v9, v58

    .line 617
    .line 618
    move-object/from16 v10, v57

    .line 619
    .line 620
    move-object v11, v3

    .line 621
    move-object/from16 v12, v19

    .line 622
    .line 623
    move v13, v0

    .line 624
    move/from16 v14, v56

    .line 625
    .line 626
    invoke-direct/range {v4 .. v14}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$8;-><init>(ZLX/JDN;Lkotlin/jvm/functions/Function0;LX/JDN;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 627
    .line 628
    .line 629
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 630
    .line 631
    :cond_17
    return-void

    .line 632
    :cond_18
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 633
    .line 634
    .line 635
    goto :goto_1

    .line 636
    :cond_19
    move v11, v0

    .line 637
    goto/16 :goto_0

    .line 638
    .line 639
    :cond_1a
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 640
    .line 641
    .line 642
    move-result-object v0

    .line 643
    throw v0
.end method

.method public static final SelfieAgeStep$lambda$0(LX/16A;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SelfieAgeStep$lambda$1(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final SelfieAgeStep$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final SelfieAgeStep$lambda$3(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final SelfieAgeStep$lambda$4(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final SelfieAgeStepContent(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 15

    .line 0
    move-object/from16 v11, p3

    .line 1
    .line 2
    const v1, 0x9c2eeeb

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p4

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p5

    .line 11
    .line 12
    and-int/lit8 v2, p5, 0x6

    .line 13
    .line 14
    move-object v1, p0

    .line 15
    if-nez v2, :cond_2c

    .line 16
    .line 17
    invoke-static {p0, v0, v3}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    invoke-static {v2}, LX/003;->A06(I)I

    .line 22
    .line 23
    .line 24
    move-result v8

    .line 25
    or-int v8, v8, p5

    .line 26
    .line 27
    :goto_0
    and-int/lit8 v4, p5, 0x30

    .line 28
    .line 29
    const/16 v7, 0x20

    .line 30
    .line 31
    move-object/from16 v2, p1

    .line 32
    .line 33
    if-nez v4, :cond_0

    .line 34
    .line 35
    invoke-static {v2, v0, v3}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    invoke-static {v4}, LX/003;->A07(I)I

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    or-int/2addr v8, v4

    .line 44
    :cond_0
    and-int/lit16 v4, v3, 0x180

    .line 45
    .line 46
    move/from16 v10, p2

    .line 47
    .line 48
    if-nez v4, :cond_1

    .line 49
    .line 50
    invoke-static {v0, v10}, LX/004;->A0k(LX/2d4;Z)I

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    or-int/2addr v8, v4

    .line 55
    :cond_1
    and-int/lit8 v9, p6, 0x8

    .line 56
    .line 57
    if-eqz v9, :cond_2b

    .line 58
    .line 59
    or-int/lit16 v8, v8, 0xc00

    .line 60
    .line 61
    :cond_2
    :goto_1
    and-int/lit16 v6, v8, 0x493

    .line 62
    .line 63
    const/16 v5, 0x492

    .line 64
    .line 65
    const/4 v14, 0x1

    .line 66
    const/4 v4, 0x0

    .line 67
    invoke-static {v6, v5}, LX/003;->A1H(II)Z

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    invoke-static {v5, v0, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    if-eqz v5, :cond_2a

    .line 76
    .line 77
    if-eqz v9, :cond_3

    .line 78
    .line 79
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 80
    .line 81
    :cond_3
    sget-object v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;->INSTANCE:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolving;

    .line 82
    .line 83
    invoke-static {p0, v5}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v5

    .line 87
    if-eqz v5, :cond_5

    .line 88
    .line 89
    const v4, -0x5b3d057e

    .line 90
    .line 91
    .line 92
    invoke-static {v4, v0, v8}, LX/002;->A0F(ILX/2d4;I)I

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    or-int/lit16 v4, v4, 0xc00

    .line 97
    .line 98
    const/16 p5, 0x76

    .line 99
    .line 100
    const/4 v12, 0x0

    .line 101
    move-object v13, v12

    .line 102
    move-object p0, v12

    .line 103
    move-object/from16 p1, v12

    .line 104
    .line 105
    move-object/from16 p2, v12

    .line 106
    .line 107
    move-object/from16 p3, v0

    .line 108
    .line 109
    move/from16 p4, v4

    .line 110
    .line 111
    invoke-static/range {v11 .. v20}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepMessage(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;LX/2d4;II)V

    .line 112
    .line 113
    .line 114
    :goto_2
    invoke-static {v0}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    if-eqz v4, :cond_4

    .line 122
    .line 123
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$8;

    .line 124
    .line 125
    move-object p0, v0

    .line 126
    move-object/from16 p1, v1

    .line 127
    .line 128
    move-object/from16 p2, v2

    .line 129
    .line 130
    move/from16 p3, v10

    .line 131
    .line 132
    move-object/from16 p4, v11

    .line 133
    .line 134
    move/from16 p5, v3

    .line 135
    .line 136
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$8;-><init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;II)V

    .line 137
    .line 138
    .line 139
    iput-object v0, v4, LX/J7V;->A06:LX/JDN;

    .line 140
    .line 141
    :cond_4
    return-void

    .line 142
    :cond_5
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Submitting;

    .line 143
    .line 144
    if-nez v5, :cond_7

    .line 145
    .line 146
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 147
    .line 148
    if-nez v5, :cond_7

    .line 149
    .line 150
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 151
    .line 152
    if-nez v5, :cond_7

    .line 153
    .line 154
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 155
    .line 156
    if-eqz v5, :cond_e

    .line 157
    .line 158
    const v5, -0x5b3ca80c

    .line 159
    .line 160
    .line 161
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 162
    .line 163
    .line 164
    move-object v5, v1

    .line 165
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 166
    .line 167
    iget-boolean v5, v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 168
    .line 169
    if-eqz v5, :cond_6

    .line 170
    .line 171
    const v4, -0x5b3ca5be

    .line 172
    .line 173
    .line 174
    invoke-static {v4, v0, v8}, LX/002;->A0F(ILX/2d4;I)I

    .line 175
    .line 176
    .line 177
    move-result v4

    .line 178
    or-int/lit16 v4, v4, 0xc00

    .line 179
    .line 180
    const/16 p5, 0x76

    .line 181
    .line 182
    :goto_4
    const/4 v12, 0x0

    .line 183
    move-object v13, v12

    .line 184
    move-object p0, v12

    .line 185
    move-object/from16 p1, v12

    .line 186
    .line 187
    move-object/from16 p2, v12

    .line 188
    .line 189
    move-object/from16 p3, v0

    .line 190
    .line 191
    move/from16 p4, v4

    .line 192
    .line 193
    invoke-static/range {v11 .. v20}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepMessage(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;LX/2d4;II)V

    .line 194
    .line 195
    .line 196
    :goto_5
    invoke-static {v0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 197
    .line 198
    .line 199
    goto :goto_2

    .line 200
    :cond_6
    const v5, -0x5b3c9d26

    .line 201
    .line 202
    .line 203
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 204
    .line 205
    .line 206
    sget v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->$stable:I

    .line 207
    .line 208
    shr-int/lit8 v6, v8, 0x3

    .line 209
    .line 210
    and-int/lit8 v5, v6, 0xe

    .line 211
    .line 212
    or-int/2addr v7, v5

    .line 213
    invoke-static {v6, v7}, LX/002;->A0B(II)I

    .line 214
    .line 215
    .line 216
    move-result v13

    .line 217
    move-object v9, v2

    .line 218
    move-object v12, v0

    .line 219
    move v14, v4

    .line 220
    invoke-static/range {v9 .. v14}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepIntroKt;->SelfieAgeStepIntro(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 221
    .line 222
    .line 223
    goto :goto_5

    .line 224
    :cond_7
    const v5, -0x5b3ced6a

    .line 225
    .line 226
    .line 227
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 228
    .line 229
    .line 230
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 231
    .line 232
    if-eqz v5, :cond_c

    .line 233
    .line 234
    move-object v9, v1

    .line 235
    check-cast v9, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;

    .line 236
    .line 237
    iget-object v6, v9, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 238
    .line 239
    sget-object v5, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 240
    .line 241
    if-ne v6, v5, :cond_c

    .line 242
    .line 243
    const v5, -0x5b3ce014

    .line 244
    .line 245
    .line 246
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 247
    .line 248
    .line 249
    iget-object v12, v9, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 250
    .line 251
    iget-boolean v6, v9, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Confirming;->takingLonger:Z

    .line 252
    .line 253
    and-int/lit8 v5, v8, 0x70

    .line 254
    .line 255
    if-eq v5, v7, :cond_8

    .line 256
    .line 257
    and-int/lit8 v5, v8, 0x40

    .line 258
    .line 259
    if-eqz v5, :cond_b

    .line 260
    .line 261
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v5

    .line 265
    if-eqz v5, :cond_b

    .line 266
    .line 267
    :cond_8
    :goto_6
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    move-result-object v7

    .line 271
    if-nez v14, :cond_9

    .line 272
    .line 273
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 274
    .line 275
    if-ne v7, v5, :cond_a

    .line 276
    .line 277
    :cond_9
    new-instance v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$1$1;

    .line 278
    .line 279
    invoke-direct {v7, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$1$1;-><init>(Ljava/lang/Object;)V

    .line 280
    .line 281
    .line 282
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    :cond_a
    check-cast v7, LX/DqV;

    .line 286
    .line 287
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 288
    .line 289
    shr-int/lit8 v5, v8, 0x6

    .line 290
    .line 291
    and-int/lit8 p2, v5, 0x70

    .line 292
    .line 293
    move-object v13, v11

    .line 294
    move v14, v6

    .line 295
    move-object p0, v7

    .line 296
    move-object/from16 p1, v0

    .line 297
    .line 298
    move/from16 p3, v4

    .line 299
    .line 300
    invoke-static/range {v12 .. v18}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->AgeStepReviewing(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 301
    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_b
    const/4 v14, 0x0

    .line 305
    goto :goto_6

    .line 306
    :cond_c
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 307
    .line 308
    if-eqz v5, :cond_d

    .line 309
    .line 310
    move-object v5, v1

    .line 311
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;

    .line 312
    .line 313
    iget-boolean v5, v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Resolved;->afterConfirmed:Z

    .line 314
    .line 315
    if-nez v5, :cond_d

    .line 316
    .line 317
    const v4, -0x5b3cbd3e

    .line 318
    .line 319
    .line 320
    invoke-static {v4, v0, v8}, LX/002;->A0F(ILX/2d4;I)I

    .line 321
    .line 322
    .line 323
    move-result v4

    .line 324
    or-int/lit16 v4, v4, 0xc00

    .line 325
    .line 326
    const/16 p5, 0x76

    .line 327
    .line 328
    goto/16 :goto_4

    .line 329
    .line 330
    :cond_d
    const v5, -0x5b3cb40e

    .line 331
    .line 332
    .line 333
    invoke-static {v5, v0, v8}, LX/008;->A0B(ILX/2d4;I)I

    .line 334
    .line 335
    .line 336
    move-result v5

    .line 337
    invoke-static {p0, v11, v0, v5, v4}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepReviewingKt;->SelfieAgeStepReviewing(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;LX/3C1;LX/2d4;II)V

    .line 338
    .line 339
    .line 340
    goto/16 :goto_5

    .line 341
    .line 342
    :cond_e
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 343
    .line 344
    const p4, 0xe000

    .line 345
    .line 346
    .line 347
    if-eqz v5, :cond_17

    .line 348
    .line 349
    const v4, -0x5b3c90b8

    .line 350
    .line 351
    .line 352
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 353
    .line 354
    .line 355
    move-object v4, v1

    .line 356
    check-cast v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;

    .line 357
    .line 358
    iget v12, v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->captureKey:I

    .line 359
    .line 360
    iget-object v13, v4, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Capturing;->headMovements:LX/Ddn;

    .line 361
    .line 362
    and-int/lit8 v6, v8, 0x70

    .line 363
    .line 364
    if-eq v6, v7, :cond_f

    .line 365
    .line 366
    and-int/lit8 v4, v8, 0x40

    .line 367
    .line 368
    if-eqz v4, :cond_16

    .line 369
    .line 370
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v4

    .line 374
    if-eqz v4, :cond_16

    .line 375
    .line 376
    :cond_f
    const/4 v4, 0x1

    .line 377
    :goto_7
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v5

    .line 381
    if-nez v4, :cond_10

    .line 382
    .line 383
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 384
    .line 385
    if-ne v5, v4, :cond_11

    .line 386
    .line 387
    :cond_10
    new-instance v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$2$1;

    .line 388
    .line 389
    invoke-direct {v5, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$2$1;-><init>(Ljava/lang/Object;)V

    .line 390
    .line 391
    .line 392
    invoke-interface {v0, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 393
    .line 394
    .line 395
    :cond_11
    check-cast v5, LX/DqV;

    .line 396
    .line 397
    check-cast v5, LX/JDM;

    .line 398
    .line 399
    if-eq v6, v7, :cond_12

    .line 400
    .line 401
    and-int/lit8 v4, v8, 0x40

    .line 402
    .line 403
    if-eqz v4, :cond_15

    .line 404
    .line 405
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 406
    .line 407
    .line 408
    move-result v4

    .line 409
    if-eqz v4, :cond_15

    .line 410
    .line 411
    :cond_12
    :goto_8
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    move-result-object v6

    .line 415
    if-nez v14, :cond_13

    .line 416
    .line 417
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 418
    .line 419
    if-ne v6, v4, :cond_14

    .line 420
    .line 421
    :cond_13
    new-instance v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$3$1;

    .line 422
    .line 423
    invoke-direct {v6, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$3$1;-><init>(Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    :cond_14
    check-cast v6, LX/DqV;

    .line 430
    .line 431
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 432
    .line 433
    shl-int/lit8 v4, v8, 0x3

    .line 434
    .line 435
    and-int p4, p4, v4

    .line 436
    .line 437
    const/16 v4, 0x20

    .line 438
    .line 439
    const/16 p2, 0x0

    .line 440
    .line 441
    :goto_9
    move-object p0, v6

    .line 442
    move-object/from16 p1, v11

    .line 443
    .line 444
    move-object/from16 p3, v0

    .line 445
    .line 446
    move/from16 p5, v4

    .line 447
    .line 448
    move-object v14, v5

    .line 449
    invoke-static/range {v12 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieCaptureKt;->SelfieCapture(ILX/Ddn;LX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/2d4;II)V

    .line 450
    .line 451
    .line 452
    goto/16 :goto_2

    .line 453
    .line 454
    :cond_15
    const/4 v14, 0x0

    .line 455
    goto :goto_8

    .line 456
    :cond_16
    const/4 v4, 0x0

    .line 457
    goto :goto_7

    .line 458
    :cond_17
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Recapture;

    .line 459
    .line 460
    if-eqz v5, :cond_20

    .line 461
    .line 462
    const v5, -0x5b3c72fa

    .line 463
    .line 464
    .line 465
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 466
    .line 467
    .line 468
    move-object v5, v1

    .line 469
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Recapture;

    .line 470
    .line 471
    iget v12, v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Recapture;->captureKey:I

    .line 472
    .line 473
    iget-object v13, v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Recapture;->headMovements:LX/Ddn;

    .line 474
    .line 475
    and-int/lit8 v9, v8, 0x70

    .line 476
    .line 477
    if-eq v9, v7, :cond_18

    .line 478
    .line 479
    and-int/lit8 v5, v8, 0x40

    .line 480
    .line 481
    if-eqz v5, :cond_1f

    .line 482
    .line 483
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 484
    .line 485
    .line 486
    move-result v5

    .line 487
    if-eqz v5, :cond_1f

    .line 488
    .line 489
    :cond_18
    const/4 v6, 0x1

    .line 490
    :goto_a
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v5

    .line 494
    if-nez v6, :cond_19

    .line 495
    .line 496
    sget-object v6, LX/2d6;->A00:Ljava/lang/Object;

    .line 497
    .line 498
    if-ne v5, v6, :cond_1a

    .line 499
    .line 500
    :cond_19
    new-instance v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$4$1;

    .line 501
    .line 502
    invoke-direct {v5, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$4$1;-><init>(Ljava/lang/Object;)V

    .line 503
    .line 504
    .line 505
    invoke-interface {v0, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 506
    .line 507
    .line 508
    :cond_1a
    check-cast v5, LX/DqV;

    .line 509
    .line 510
    check-cast v5, LX/JDM;

    .line 511
    .line 512
    if-eq v9, v7, :cond_1b

    .line 513
    .line 514
    and-int/lit8 v6, v8, 0x40

    .line 515
    .line 516
    if-eqz v6, :cond_1e

    .line 517
    .line 518
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 519
    .line 520
    .line 521
    move-result v6

    .line 522
    if-eqz v6, :cond_1e

    .line 523
    .line 524
    :cond_1b
    :goto_b
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v6

    .line 528
    if-nez v14, :cond_1c

    .line 529
    .line 530
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 531
    .line 532
    if-ne v6, v7, :cond_1d

    .line 533
    .line 534
    :cond_1c
    new-instance v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$5$1;

    .line 535
    .line 536
    invoke-direct {v6, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$5$1;-><init>(Ljava/lang/Object;)V

    .line 537
    .line 538
    .line 539
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 540
    .line 541
    .line 542
    :cond_1d
    check-cast v6, LX/DqV;

    .line 543
    .line 544
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 545
    .line 546
    shl-int/lit8 v7, v8, 0x3

    .line 547
    .line 548
    and-int p4, p4, v7

    .line 549
    .line 550
    const/high16 v7, 0x30000

    .line 551
    .line 552
    or-int p4, p4, v7

    .line 553
    .line 554
    const/16 p2, 0x1

    .line 555
    .line 556
    goto :goto_9

    .line 557
    :cond_1e
    const/4 v14, 0x0

    .line 558
    goto :goto_b

    .line 559
    :cond_1f
    const/4 v6, 0x0

    .line 560
    goto :goto_a

    .line 561
    :cond_20
    instance-of v5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;

    .line 562
    .line 563
    if-eqz v5, :cond_2d

    .line 564
    .line 565
    const v5, -0x5b3c5234

    .line 566
    .line 567
    .line 568
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 569
    .line 570
    .line 571
    and-int/lit8 v9, v8, 0x70

    .line 572
    .line 573
    if-eq v9, v7, :cond_21

    .line 574
    .line 575
    and-int/lit8 v5, v8, 0x40

    .line 576
    .line 577
    if-eqz v5, :cond_29

    .line 578
    .line 579
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 580
    .line 581
    .line 582
    move-result v5

    .line 583
    if-eqz v5, :cond_29

    .line 584
    .line 585
    :cond_21
    const/4 v5, 0x1

    .line 586
    :goto_c
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 587
    .line 588
    .line 589
    move-result-object v6

    .line 590
    if-nez v5, :cond_22

    .line 591
    .line 592
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 593
    .line 594
    if-ne v6, v5, :cond_23

    .line 595
    .line 596
    :cond_22
    new-instance v6, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$6$1;

    .line 597
    .line 598
    invoke-direct {v6, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$6$1;-><init>(Ljava/lang/Object;)V

    .line 599
    .line 600
    .line 601
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 602
    .line 603
    .line 604
    :cond_23
    check-cast v6, LX/DqV;

    .line 605
    .line 606
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 607
    .line 608
    move-object v5, v1

    .line 609
    check-cast v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;

    .line 610
    .line 611
    iget-object v5, v5, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Error;->retry:Lcom/facebook/aura/activation/ageverification/RetryAction;

    .line 612
    .line 613
    if-eqz v5, :cond_28

    .line 614
    .line 615
    const v5, -0xc4bb4bb

    .line 616
    .line 617
    .line 618
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 619
    .line 620
    .line 621
    if-eq v9, v7, :cond_24

    .line 622
    .line 623
    and-int/lit8 v5, v8, 0x40

    .line 624
    .line 625
    if-eqz v5, :cond_27

    .line 626
    .line 627
    invoke-interface {v0, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 628
    .line 629
    .line 630
    move-result v5

    .line 631
    if-eqz v5, :cond_27

    .line 632
    .line 633
    :cond_24
    :goto_d
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 634
    .line 635
    .line 636
    move-result-object v7

    .line 637
    if-nez v14, :cond_25

    .line 638
    .line 639
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 640
    .line 641
    if-ne v7, v5, :cond_26

    .line 642
    .line 643
    :cond_25
    new-instance v7, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$7$1;

    .line 644
    .line 645
    invoke-direct {v7, v2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStepContent$7$1;-><init>(Ljava/lang/Object;)V

    .line 646
    .line 647
    .line 648
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 649
    .line 650
    .line 651
    :cond_26
    check-cast v7, LX/DqV;

    .line 652
    .line 653
    invoke-static {v0}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 654
    .line 655
    .line 656
    :goto_e
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 657
    .line 658
    shr-int/lit8 v5, v8, 0x6

    .line 659
    .line 660
    and-int/lit8 p2, v5, 0x70

    .line 661
    .line 662
    const/16 p3, 0x8

    .line 663
    .line 664
    move-object v12, v6

    .line 665
    move-object v13, v11

    .line 666
    move-object v14, v7

    .line 667
    move p0, v4

    .line 668
    move-object/from16 p1, v0

    .line 669
    .line 670
    invoke-static/range {v12 .. v18}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepErrorCard(Lkotlin/jvm/functions/Function0;LX/3C1;Lkotlin/jvm/functions/Function0;ILX/2d4;II)V

    .line 671
    .line 672
    .line 673
    goto/16 :goto_2

    .line 674
    .line 675
    :cond_27
    const/4 v14, 0x0

    .line 676
    goto :goto_d

    .line 677
    :cond_28
    const v5, -0xc4b596e

    .line 678
    .line 679
    .line 680
    invoke-static {v0, v5}, LX/003;->A0q(LX/2d4;I)V

    .line 681
    .line 682
    .line 683
    const/4 v7, 0x0

    .line 684
    goto :goto_e

    .line 685
    :cond_29
    const/4 v5, 0x0

    .line 686
    goto :goto_c

    .line 687
    :cond_2a
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 688
    .line 689
    .line 690
    goto/16 :goto_3

    .line 691
    .line 692
    :cond_2b
    and-int/lit16 v4, v3, 0xc00

    .line 693
    .line 694
    if-nez v4, :cond_2

    .line 695
    .line 696
    invoke-static {v0, v11}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 697
    .line 698
    .line 699
    move-result v4

    .line 700
    or-int/2addr v8, v4

    .line 701
    goto/16 :goto_1

    .line 702
    .line 703
    :cond_2c
    move v8, v3

    .line 704
    goto/16 :goto_0

    .line 705
    .line 706
    :cond_2d
    const v1, -0x5b3d0587

    .line 707
    .line 708
    .line 709
    invoke-static {v0, v1}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 710
    .line 711
    .line 712
    move-result-object v0

    .line 713
    throw v0
.end method

.method public static final synthetic access$SelfieAgeStep$lambda$1(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$SelfieAgeStep$lambda$2(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$SelfieAgeStep$lambda$3(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$SelfieAgeStep$lambda$4(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$SelfieAgeStepContent(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt;->SelfieAgeStepContent(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;ZLX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$rememberAgeStepHeaderActions$lambda$0(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rememberAgeStepHeaderActions$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final rememberAgeStepHeaderActions(ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)LX/Ddn;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/header/api/HeaderAction;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    move-object/from16 v3, p2

    .line 2
    .line 3
    move-object/from16 v2, p3

    .line 4
    .line 5
    invoke-static {v3, v0, v2}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p4

    .line 9
    .line 10
    invoke-static {v1, v3}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 11
    .line 12
    .line 13
    move-result-object v7

    .line 14
    invoke-static {v1, v2}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    and-int/lit8 v0, p5, 0xe

    .line 19
    .line 20
    xor-int/lit8 v0, v0, 0x6

    .line 21
    .line 22
    const/4 v3, 0x4

    .line 23
    const/4 v2, 0x0

    .line 24
    const/4 v14, 0x1

    .line 25
    move/from16 v4, p0

    .line 26
    .line 27
    if-le v0, v3, :cond_0

    .line 28
    .line 29
    invoke-interface {v1, v4}, LX/2d4;->A6A(Z)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    :cond_0
    and-int/lit8 v0, p5, 0x6

    .line 36
    .line 37
    const/4 v9, 0x0

    .line 38
    if-ne v0, v3, :cond_2

    .line 39
    .line 40
    :cond_1
    const/4 v9, 0x1

    .line 41
    :cond_2
    and-int/lit8 v0, p5, 0x70

    .line 42
    .line 43
    xor-int/lit8 v0, v0, 0x30

    .line 44
    .line 45
    const/16 v8, 0x20

    .line 46
    .line 47
    move/from16 v3, p1

    .line 48
    .line 49
    if-le v0, v8, :cond_3

    .line 50
    .line 51
    invoke-interface {v1, v3}, LX/2d4;->A6A(Z)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-nez v0, :cond_4

    .line 56
    .line 57
    :cond_3
    and-int/lit8 v6, p5, 0x30

    .line 58
    .line 59
    const/4 v0, 0x0

    .line 60
    if-ne v6, v8, :cond_5

    .line 61
    .line 62
    :cond_4
    const/4 v0, 0x1

    .line 63
    :cond_5
    or-int/2addr v0, v9

    .line 64
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    if-nez v0, :cond_6

    .line 69
    .line 70
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 71
    .line 72
    if-ne v6, v0, :cond_9

    .line 73
    .line 74
    :cond_6
    const/4 v15, 0x0

    .line 75
    const v6, 0x7f080296

    .line 76
    .line 77
    .line 78
    const v0, 0x7f120673

    .line 79
    .line 80
    .line 81
    new-instance v10, Lcom/facebook/aura/header/api/HeaderActionIcon;

    .line 82
    .line 83
    invoke-direct {v10, v6, v0, v2, v14}, Lcom/facebook/aura/header/api/HeaderActionIcon;-><init>(IIZZ)V

    .line 84
    .line 85
    .line 86
    new-instance v12, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$rememberAgeStepHeaderActions$1$1;

    .line 87
    .line 88
    invoke-direct {v12, v7}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$rememberAgeStepHeaderActions$1$1;-><init>(LX/16A;)V

    .line 89
    .line 90
    .line 91
    const-string v9, "age-check-settings"

    .line 92
    .line 93
    const-string v11, "hatch-settings-button"

    .line 94
    .line 95
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 96
    .line 97
    new-instance v8, Lcom/facebook/aura/header/api/HeaderAction;

    .line 98
    .line 99
    move-object/from16 v16, v15

    .line 100
    .line 101
    move-object/from16 v17, v15

    .line 102
    .line 103
    move-object/from16 v18, v15

    .line 104
    .line 105
    move/from16 v19, v2

    .line 106
    .line 107
    invoke-direct/range {v8 .. v19}, Lcom/facebook/aura/header/api/HeaderAction;-><init>(Ljava/lang/Object;Lcom/facebook/aura/header/api/HeaderActionIcon;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/JDQ;LX/JDO;LX/JDM;Ljava/lang/Integer;Z)V

    .line 108
    .line 109
    .line 110
    const/4 v7, 0x0

    .line 111
    if-nez p0, :cond_7

    .line 112
    .line 113
    move-object v8, v15

    .line 114
    :cond_7
    sget-object v17, Lcom/facebook/aura/navigation/key/AgeVerificationWhyConfirmSheetKey;->INSTANCE:Lcom/facebook/aura/navigation/key/AgeVerificationWhyConfirmSheetKey;

    .line 115
    .line 116
    const v6, 0x7f0800f7

    .line 117
    .line 118
    .line 119
    const v0, 0x7f1200a5

    .line 120
    .line 121
    .line 122
    new-instance v4, Lcom/facebook/aura/header/api/HeaderActionIcon;

    .line 123
    .line 124
    invoke-direct {v4, v6, v0, v2, v14}, Lcom/facebook/aura/header/api/HeaderActionIcon;-><init>(IIZZ)V

    .line 125
    .line 126
    .line 127
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$rememberAgeStepHeaderActions$1$3;

    .line 128
    .line 129
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$rememberAgeStepHeaderActions$1$3;-><init>(LX/16A;)V

    .line 130
    .line 131
    .line 132
    const-string v19, "age-verification-help-button"

    .line 133
    .line 134
    new-instance v16, Lcom/facebook/aura/header/api/HeaderAction;

    .line 135
    .line 136
    move-object/from16 v18, v4

    .line 137
    .line 138
    move-object/from16 v20, v0

    .line 139
    .line 140
    move-object/from16 v21, v13

    .line 141
    .line 142
    move/from16 p0, v14

    .line 143
    .line 144
    move-object/from16 p1, v15

    .line 145
    .line 146
    move-object/from16 p2, v15

    .line 147
    .line 148
    move-object/from16 p3, v15

    .line 149
    .line 150
    move-object/from16 p4, v15

    .line 151
    .line 152
    move/from16 p5, v2

    .line 153
    .line 154
    invoke-direct/range {v16 .. v27}, Lcom/facebook/aura/header/api/HeaderAction;-><init>(Ljava/lang/Object;Lcom/facebook/aura/header/api/HeaderActionIcon;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZLX/JDQ;LX/JDO;LX/JDM;Ljava/lang/Integer;Z)V

    .line 155
    .line 156
    .line 157
    if-eqz v3, :cond_8

    .line 158
    .line 159
    move-object/from16 v7, v16

    .line 160
    .line 161
    :cond_8
    filled-new-array {v8, v7}, [Lcom/facebook/aura/header/api/HeaderAction;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-static {v0}, LX/B82;->A0C([Ljava/lang/Object;)Ljava/util/List;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    invoke-static {v1, v0}, LX/002;->A1F(LX/2d4;Ljava/lang/Iterable;)LX/Ddn;

    .line 170
    .line 171
    .line 172
    move-result-object v6

    .line 173
    :cond_9
    check-cast v6, LX/Ddn;

    .line 174
    .line 175
    return-object v6
.end method

.method public static final rememberAgeStepHeaderActions$lambda$0(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final rememberAgeStepHeaderActions$lambda$1(LX/16A;)Lkotlin/jvm/functions/Function0;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A06(LX/16A;)Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
