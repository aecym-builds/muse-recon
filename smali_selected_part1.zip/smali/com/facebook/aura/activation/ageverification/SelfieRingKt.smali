.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieRingKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final SelfieRing(LX/3dS;LX/FCr;Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/3C1;LX/2d4;II)V
    .locals 14

    .line 0
    move-object/from16 v12, p3

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    move-object v9, p0

    .line 4
    move-object v10, p1

    .line 5
    move-object/from16 v11, p2

    .line 6
    .line 7
    invoke-static {p0, p1, v11}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const v0, -0x34364584    # -2.6440952E7f

    .line 11
    .line 12
    .line 13
    move-object/from16 v3, p4

    .line 14
    .line 15
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v13, p5

    .line 19
    .line 20
    and-int/lit8 v0, p5, 0x6

    .line 21
    .line 22
    if-nez v0, :cond_9

    .line 23
    .line 24
    invoke-static {v3, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    or-int v4, v4, p5

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-static {v3, p1}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    or-int/2addr v4, v0

    .line 39
    :cond_0
    and-int/lit16 v0, v13, 0x180

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v11, v3, v13}, LX/005;->A1Y(Ljava/lang/Object;LX/2d4;I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0}, LX/003;->A08(I)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    or-int/2addr v4, v0

    .line 52
    :cond_1
    move/from16 p0, p6

    .line 53
    .line 54
    and-int/lit8 v1, p6, 0x4

    .line 55
    .line 56
    if-eqz v1, :cond_8

    .line 57
    .line 58
    or-int/lit16 v4, v4, 0xc00

    .line 59
    .line 60
    :cond_2
    :goto_1
    invoke-static {v4}, LX/005;->A1K(I)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    invoke-static {v0, v3, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_7

    .line 69
    .line 70
    if-eqz v1, :cond_3

    .line 71
    .line 72
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 73
    .line 74
    :cond_3
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->state:LX/2J3;

    .line 75
    .line 76
    const/4 v8, 0x0

    .line 77
    invoke-static {v3, v0, v2}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    iget-object v0, v11, Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;->progress:LX/2J3;

    .line 82
    .line 83
    invoke-static {v3, v0, v2}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 92
    .line 93
    if-ne v5, v1, :cond_4

    .line 94
    .line 95
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$current$2$1;

    .line 96
    .line 97
    invoke-direct {v0, v7}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$current$2$1;-><init>(LX/16A;)V

    .line 98
    .line 99
    .line 100
    new-instance v5, LX/J75;

    .line 101
    .line 102
    invoke-direct {v5, v8, v0}, LX/J75;-><init>(LX/DxE;Lkotlin/jvm/functions/Function0;)V

    .line 103
    .line 104
    .line 105
    invoke-interface {v3, v5}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    :cond_4
    check-cast v5, LX/16A;

    .line 109
    .line 110
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    if-ne v0, v1, :cond_5

    .line 115
    .line 116
    new-instance v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$completed$2$1;

    .line 117
    .line 118
    invoke-direct {v1, v7}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$completed$2$1;-><init>(LX/16A;)V

    .line 119
    .line 120
    .line 121
    new-instance v0, LX/J75;

    .line 122
    .line 123
    invoke-direct {v0, v8, v1}, LX/J75;-><init>(LX/DxE;Lkotlin/jvm/functions/Function0;)V

    .line 124
    .line 125
    .line 126
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    :cond_5
    check-cast v0, LX/16A;

    .line 130
    .line 131
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, LX/Ddn;

    .line 136
    .line 137
    invoke-static {v0, v3, v2}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->rememberCompletionFlashes(LX/Ddn;LX/2d4;I)LX/Ddn;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    new-instance v1, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;

    .line 142
    .line 143
    invoke-direct {v1, p1, v6, v0, v5}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$1;-><init>(LX/FCr;LX/16A;LX/Ddn;LX/16A;)V

    .line 144
    .line 145
    .line 146
    const v0, 0x2a7715b9

    .line 147
    .line 148
    .line 149
    invoke-static {v3, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 150
    .line 151
    .line 152
    move-result-object p3

    .line 153
    and-int/lit8 v0, v4, 0xe

    .line 154
    .line 155
    or-int/lit16 v1, v0, 0x180

    .line 156
    .line 157
    shr-int/lit8 v0, v4, 0x6

    .line 158
    .line 159
    and-int/lit8 v0, v0, 0x70

    .line 160
    .line 161
    or-int/2addr v1, v0

    .line 162
    move-object p1, v9

    .line 163
    move-object/from16 p2, v12

    .line 164
    .line 165
    move/from16 p5, v1

    .line 166
    .line 167
    move/from16 p6, v2

    .line 168
    .line 169
    invoke-static/range {p1 .. p6}, Lcom/facebook/aura/activation/ageverification/SelfieCircleKt;->SelfieCircle(LX/3dS;LX/3C1;LX/JDQ;LX/2d4;II)V

    .line 170
    .line 171
    .line 172
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    if-eqz v0, :cond_6

    .line 177
    .line 178
    new-instance v8, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$2;

    .line 179
    .line 180
    invoke-direct/range {v8 .. v14}, Lcom/facebook/aura/activation/ageverification/SelfieRingKt$SelfieRing$2;-><init>(LX/3dS;LX/FCr;Lcom/facebook/aura/activation/ageverification/SelfieCaptureViewModel;LX/3C1;II)V

    .line 181
    .line 182
    .line 183
    iput-object v8, v0, LX/J7V;->A06:LX/JDN;

    .line 184
    .line 185
    :cond_6
    return-void

    .line 186
    :cond_7
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 187
    .line 188
    .line 189
    goto :goto_2

    .line 190
    :cond_8
    and-int/lit16 v0, v13, 0xc00

    .line 191
    .line 192
    if-nez v0, :cond_2

    .line 193
    .line 194
    invoke-static {v3, v12}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 195
    .line 196
    .line 197
    move-result v0

    .line 198
    or-int/2addr v4, v0

    .line 199
    goto/16 :goto_1

    .line 200
    .line 201
    :cond_9
    move v4, v13

    .line 202
    goto/16 :goto_0
.end method

.method public static final SelfieRing$lambda$1(LX/16A;)Lcom/facebook/aura/activation/ageverification/HeadMovement;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;)",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final SelfieRing$lambda$3(LX/16A;)LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;>;)",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, LX/Ddn;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$SelfieRing$lambda$1(LX/16A;)Lcom/facebook/aura/activation/ageverification/HeadMovement;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 5
    .line 6
    return-object p0
.end method
