.class public final Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/JDN<",
        "-",
        "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
        "-",
        "Ljava/lang/Integer;",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "LX/JDM<",
        "-",
        "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
        "+",
        "Lkotlin/Unit;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $accounts:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $primary:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Ddn;LX/Ddn;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;->$primary:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;->$accounts:LX/Ddn;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/JDN;)LX/JDM;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)",
            "LX/JDM<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;->$primary:LX/Ddn;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;->$accounts:LX/Ddn;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;

    .line 9
    .line 10
    invoke-direct {v0, p1, v2, v1}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;-><init>(LX/JDN;LX/Ddn;LX/Ddn;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/JDN;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1;->invoke(LX/JDN;)LX/JDM;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
