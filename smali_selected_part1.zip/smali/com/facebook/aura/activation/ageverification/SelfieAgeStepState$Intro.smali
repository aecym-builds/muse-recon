.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;
.super LX/07H;
.source ""

# interfaces
.implements Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState;


# static fields
.field public static final $stable:I


# instance fields
.field public final preparing:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 536870912
    const/4 v0, 0x0

    .line 536870913
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;-><init>(Z)V

    .line 536870914
    .line 536870915
    .line 536870916
    return-void
.end method

.method public constructor <init>(Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 4
    .line 5
    return-void
.end method

.method public synthetic constructor <init>(ZILX/04f;)V
    .locals 1

    .line 268435456
    invoke-static {p2, p1}, LX/002;->A1U(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;-><init>(Z)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;ZILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;
    .locals 1

    .line 0
    and-int/lit8 v0, p2, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 5
    .line 6
    :cond_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;-><init>(Z)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Z)Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 1
    .line 2
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;-><init>(Z)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;

    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 13
    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    :cond_0
    return v2

    .line 17
    :cond_1
    return v3
.end method

.method public final getPreparing()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 1
    .line 2
    return p0
.end method

.method public hashCode()I
    .locals 1

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepState$Intro;->preparing:Z

    .line 1
    .line 2
    const/16 v0, 0x4d5

    .line 3
    .line 4
    if-eqz p0, :cond_0

    .line 5
    .line 6
    const/16 v0, 0x4cf

    .line 7
    .line 8
    :cond_0
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
