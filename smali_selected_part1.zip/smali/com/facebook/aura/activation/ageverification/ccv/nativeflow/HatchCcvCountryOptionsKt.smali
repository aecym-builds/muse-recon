.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final COUNTRY_CA:Ljava/lang/String; = "CA"

.field public static final COUNTRY_US:Ljava/lang/String; = "US"
