.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;
.super LX/07H;
.source ""


# instance fields
.field public final country:Ljava/lang/String;

.field public final label:Ljava/lang/String;

.field public final postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p4, 0x2

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p2, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p4, 0x4

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p3, v1

    .line 268435467
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)V

    .line 268435468
    .line 268435469
    .line 268435470
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->copy(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getCountry()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPostalField()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->postalField:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvPostalFieldConfig;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    add-int/2addr v1, v0

    .line 22
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
