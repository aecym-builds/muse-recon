.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $countries:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $selectedCountry:Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/Ddn;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$countries:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$selectedCountry:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/Ddn;
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, -0x618d6e34

    .line 1
    .line 2
    .line 3
    move-object/from16 v6, p1

    .line 4
    .line 5
    invoke-interface {v6, v0}, LX/2d4;->Agj(I)V

    .line 6
    .line 7
    .line 8
    const v0, 0x7f0800e6

    .line 9
    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    invoke-static {v6, v0, v5}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    move-object/from16 v2, p0

    .line 17
    .line 18
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$countries:LX/Ddn;

    .line 19
    .line 20
    invoke-interface {v6, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$selectedCountry:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v6, v0, v4, v1}, LX/004;->A1W(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iget-object v7, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$countries:LX/Ddn;

    .line 31
    .line 32
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->$selectedCountry:Ljava/lang/String;

    .line 33
    .line 34
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 41
    .line 42
    if-ne v1, v0, :cond_5

    .line 43
    .line 44
    :cond_0
    invoke-static {v7}, LX/0BR;->A03(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v8

    .line 52
    const/4 v10, 0x0

    .line 53
    :goto_0
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_4

    .line 58
    .line 59
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v7

    .line 63
    add-int/lit8 v1, v10, 0x1

    .line 64
    .line 65
    if-gez v10, :cond_1

    .line 66
    .line 67
    invoke-static {}, LX/B8B;->A1A()V

    .line 68
    .line 69
    .line 70
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    throw v0

    .line 75
    :cond_1
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;

    .line 76
    .line 77
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 78
    .line 79
    invoke-static {v0, v3}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v16

    .line 83
    iget-object v11, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->label:Ljava/lang/String;

    .line 84
    .line 85
    if-nez v11, :cond_2

    .line 86
    .line 87
    iget-object v0, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryConfig;->country:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt;->countryDisplayName(Ljava/lang/String;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v11

    .line 93
    :cond_2
    move-object v15, v4

    .line 94
    if-nez v16, :cond_3

    .line 95
    .line 96
    const/4 v15, 0x0

    .line 97
    :cond_3
    const/4 v12, 0x0

    .line 98
    const/16 v19, 0x1

    .line 99
    .line 100
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 101
    .line 102
    new-instance v9, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 103
    .line 104
    move-object v13, v12

    .line 105
    move-object v14, v12

    .line 106
    move/from16 v18, v5

    .line 107
    .line 108
    move/from16 v20, v5

    .line 109
    .line 110
    move/from16 p1, v19

    .line 111
    .line 112
    move/from16 p2, v19

    .line 113
    .line 114
    move/from16 v17, v5

    .line 115
    .line 116
    invoke-direct/range {v9 .. v23}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v2, v9}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move v10, v1

    .line 123
    goto :goto_0

    .line 124
    :cond_4
    invoke-static {v6, v2}, LX/002;->A1F(LX/2d4;Ljava/lang/Iterable;)LX/Ddn;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    :cond_5
    check-cast v1, LX/Ddn;

    .line 129
    .line 130
    invoke-static {v6}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    return-object v1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/HatchCcvCardEntryScreenKt$CcvCountryField$2$6;->invoke(LX/2d4;I)LX/Ddn;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
