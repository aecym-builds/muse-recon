.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/ui/ComposableSingletons$HatchCcvCardEntryScreenKt$lambda$692108522$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 3

    .line 0
    and-int/lit8 v0, p2, 0x3

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-static {v0}, LX/004;->A1P(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    const v0, 0x7f0800e9

    .line 14
    .line 15
    .line 16
    invoke-static {p1, v0, v1}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    sget-object v2, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 21
    .line 22
    invoke-static {p1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 27
    .line 28
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 29
    .line 30
    invoke-static {p1, p0, v2, v0, v1}, LX/2l9;->A08(LX/2d4;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;J)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 35
    .line 36
    .line 37
    return-void
.end method
