.class public abstract Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final CaptureTip(IILX/3C1;LX/2d4;II)V
    .locals 40

    .line 0
    move-object/from16 v2, p2

    .line 1
    .line 2
    const v0, -0x46ded208

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move/from16 v6, p0

    .line 15
    .line 16
    if-nez v0, :cond_4

    .line 17
    .line 18
    invoke-static {v1, v6}, LX/004;->A0E(LX/2d4;I)I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    or-int v8, v8, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move/from16 v5, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v5}, LX/004;->A0F(LX/2d4;I)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v8, v0

    .line 35
    :cond_0
    and-int/lit8 v7, p5, 0x4

    .line 36
    .line 37
    if-eqz v7, :cond_3

    .line 38
    .line 39
    or-int/lit16 v8, v8, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v4, v8, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v15, 0x0

    .line 46
    invoke-static {v4, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, v1, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_6

    .line 55
    .line 56
    if-eqz v7, :cond_2

    .line 57
    .line 58
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 61
    .line 62
    invoke-static {v2, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    invoke-static {v1}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 67
    .line 68
    .line 69
    move-result-object v11

    .line 70
    move-object v0, v1

    .line 71
    check-cast v0, LX/J7I;

    .line 72
    .line 73
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 74
    .line 75
    .line 76
    move-result v10

    .line 77
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    invoke-static {v1, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 86
    .line 87
    iget-object v4, v0, LX/J7I;->A0V:LX/3DJ;

    .line 88
    .line 89
    if-nez v4, :cond_5

    .line 90
    .line 91
    invoke-static {}, LX/1VY;->A00()V

    .line 92
    .line 93
    .line 94
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    throw v0

    .line 99
    :cond_3
    and-int/lit16 v0, v3, 0x180

    .line 100
    .line 101
    if-nez v0, :cond_1

    .line 102
    .line 103
    invoke-static {v1, v2}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    or-int/2addr v8, v0

    .line 108
    goto :goto_1

    .line 109
    :cond_4
    move v8, v3

    .line 110
    goto :goto_0

    .line 111
    :cond_5
    invoke-static {v1, v0, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v1, v11, v9, v8, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 115
    .line 116
    .line 117
    invoke-static {v1, v6}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    sget-object v4, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 122
    .line 123
    invoke-static {v1, v4}, LX/07H;->A0N(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 124
    .line 125
    .line 126
    move-result-object v11

    .line 127
    invoke-static {v1, v4}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 128
    .line 129
    .line 130
    move-result-wide v9

    .line 131
    const/16 v25, 0x3ff2

    .line 132
    .line 133
    const/4 v8, 0x0

    .line 134
    const/16 v27, 0x0

    .line 135
    .line 136
    move-object v12, v8

    .line 137
    move-object v13, v8

    .line 138
    move-object v14, v8

    .line 139
    move/from16 v16, v15

    .line 140
    .line 141
    move/from16 v17, v15

    .line 142
    .line 143
    move/from16 v18, v15

    .line 144
    .line 145
    move-object/from16 v19, v8

    .line 146
    .line 147
    move-object/from16 v20, v8

    .line 148
    .line 149
    move-object/from16 v21, v8

    .line 150
    .line 151
    move-object/from16 v22, v1

    .line 152
    .line 153
    move/from16 v23, v15

    .line 154
    .line 155
    move/from16 v24, v15

    .line 156
    .line 157
    invoke-static/range {v7 .. v25}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 158
    .line 159
    .line 160
    invoke-static {v1, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v26

    .line 164
    invoke-static {v1, v4}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 165
    .line 166
    .line 167
    move-result-object v30

    .line 168
    invoke-static {v1, v4}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 169
    .line 170
    .line 171
    move-result-wide v28

    .line 172
    move-object/from16 v31, v8

    .line 173
    .line 174
    move-object/from16 v32, v8

    .line 175
    .line 176
    move-object/from16 v33, v8

    .line 177
    .line 178
    move/from16 v34, v15

    .line 179
    .line 180
    move/from16 v35, v15

    .line 181
    .line 182
    move/from16 v36, v15

    .line 183
    .line 184
    move/from16 v37, v15

    .line 185
    .line 186
    move-object/from16 v38, v8

    .line 187
    .line 188
    move-object/from16 v39, v8

    .line 189
    .line 190
    move-object/from16 p0, v8

    .line 191
    .line 192
    move-object/from16 p1, v1

    .line 193
    .line 194
    move/from16 p2, v15

    .line 195
    .line 196
    move/from16 p3, v15

    .line 197
    .line 198
    move/from16 p4, v25

    .line 199
    .line 200
    invoke-static/range {v26 .. v44}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 201
    .line 202
    .line 203
    invoke-static {v0, v2}, LX/002;->A0Y(LX/J7I;LX/3C1;)LX/3C1;

    .line 204
    .line 205
    .line 206
    move-result-object v2

    .line 207
    goto :goto_2

    .line 208
    :cond_6
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 209
    .line 210
    .line 211
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 212
    .line 213
    .line 214
    move-result-object v1

    .line 215
    if-eqz v1, :cond_7

    .line 216
    .line 217
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt$CaptureTip$2;

    .line 218
    .line 219
    move-object/from16 p0, v0

    .line 220
    .line 221
    move/from16 p1, v6

    .line 222
    .line 223
    move/from16 p2, v5

    .line 224
    .line 225
    move-object/from16 p3, v2

    .line 226
    .line 227
    move/from16 p4, v3

    .line 228
    .line 229
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt$CaptureTip$2;-><init>(IILX/3C1;II)V

    .line 230
    .line 231
    .line 232
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 233
    .line 234
    :cond_7
    return-void
.end method

.method public static final IdTipsSheet(LX/3C1;LX/2d4;II)V
    .locals 19

    .line 0
    move-object/from16 v7, p0

    .line 1
    .line 2
    const v0, 0x279ebd83

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p1

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v6, p3, 0x1

    .line 13
    .line 14
    const/4 v5, 0x2

    .line 15
    move/from16 v3, p2

    .line 16
    .line 17
    if-eqz v6, :cond_3

    .line 18
    .line 19
    or-int/lit8 v4, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v0, v4, 0x3

    .line 22
    .line 23
    const/4 v13, 0x0

    .line 24
    invoke-static {v0, v5}, LX/003;->A1H(II)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0, v1, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    if-eqz v6, :cond_0

    .line 35
    .line 36
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 37
    .line 38
    :cond_0
    const v0, 0x7f120074

    .line 39
    .line 40
    .line 41
    invoke-static {v1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v15

    .line 45
    const/4 v6, 0x0

    .line 46
    sget-object p1, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;->DEFAULT:Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;

    .line 47
    .line 48
    const p3, 0x7fffffff

    .line 49
    .line 50
    .line 51
    new-instance v9, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;

    .line 52
    .line 53
    move-object v14, v9

    .line 54
    move-object/from16 v16, v6

    .line 55
    .line 56
    move-object/from16 v17, v6

    .line 57
    .line 58
    move-object/from16 v18, v6

    .line 59
    .line 60
    move-object/from16 p0, v6

    .line 61
    .line 62
    move-object/from16 p2, v6

    .line 63
    .line 64
    invoke-direct/range {v14 .. v22}, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;I)V

    .line 65
    .line 66
    .line 67
    sget-object v18, Lcom/facebook/aura/activation/ageverification/ComposableSingletons$IdTipsSheetKt;->lambda$-977873851:LX/JDQ;

    .line 68
    .line 69
    shl-int/lit8 v0, v4, 0x3

    .line 70
    .line 71
    and-int/lit8 p1, v0, 0x70

    .line 72
    .line 73
    const/16 p2, 0x180

    .line 74
    .line 75
    const/16 p3, 0xff5

    .line 76
    .line 77
    move-object v8, v6

    .line 78
    move-object v10, v6

    .line 79
    move-object v11, v6

    .line 80
    move-object v12, v6

    .line 81
    move v14, v13

    .line 82
    move v15, v13

    .line 83
    move-object/from16 p0, v1

    .line 84
    .line 85
    invoke-static/range {v6 .. v22}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 86
    .line 87
    .line 88
    :goto_1
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    if-eqz v1, :cond_1

    .line 93
    .line 94
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt$IdTipsSheet$1;

    .line 95
    .line 96
    invoke-direct {v0, v7, v3, v2}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt$IdTipsSheet$1;-><init>(LX/3C1;II)V

    .line 97
    .line 98
    .line 99
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 100
    .line 101
    :cond_1
    return-void

    .line 102
    :cond_2
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 103
    .line 104
    .line 105
    goto :goto_1

    .line 106
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 107
    .line 108
    if-nez v0, :cond_4

    .line 109
    .line 110
    invoke-static {v1, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    or-int v4, v4, p2

    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_4
    move v4, v3

    .line 118
    goto :goto_0
.end method

.method public static final synthetic access$CaptureTip(IILX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/IdTipsSheetKt;->CaptureTip(IILX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
