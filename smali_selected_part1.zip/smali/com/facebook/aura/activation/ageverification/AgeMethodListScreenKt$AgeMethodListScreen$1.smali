.class public final Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/1Ot;",
        "LX/1Ot;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $accounts:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $loggedPick:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $onAccountPick:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onPick:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onWhyConfirm:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $primary:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;LX/Ddn;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/JDN;LX/Ddn;LX/JDN;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "LX/JDM<",
            "-",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;+",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onWhyConfirm:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$primary:LX/Ddn;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$loggedPick:LX/JDM;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onPick:LX/JDN;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$accounts:LX/Ddn;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onAccountPick:LX/JDN;

    .line 13
    .line 14
    const/4 v0, 0x4

    .line 15
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    check-cast p1, LX/1Ot;

    .line 1
    .line 2
    iget v2, p1, LX/1Ot;->A00:F

    .line 3
    .line 4
    check-cast p2, LX/1Ot;

    .line 5
    .line 6
    iget v1, p2, LX/1Ot;->A00:F

    .line 7
    .line 8
    check-cast p3, LX/2d4;

    .line 9
    .line 10
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v2, v1, p3, v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->invoke-i1RSzL4(FFLX/2d4;I)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke-i1RSzL4(FFLX/2d4;I)V
    .locals 14

    .line 0
    and-int/lit8 v0, p4, 0x6

    .line 1
    .line 2
    move-object/from16 v2, p3

    .line 3
    .line 4
    if-nez v0, :cond_1

    .line 5
    .line 6
    invoke-static {v2, p1}, LX/004;->A09(LX/2d4;F)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    or-int v5, p4, v0

    .line 11
    .line 12
    :goto_0
    const/16 v13, 0x30

    .line 13
    .line 14
    and-int/lit8 v0, p4, 0x30

    .line 15
    .line 16
    move/from16 v7, p2

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    invoke-static {v2, v7}, LX/004;->A0A(LX/2d4;F)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int/2addr v5, v0

    .line 25
    :cond_0
    and-int/lit16 v4, v5, 0x93

    .line 26
    .line 27
    const/16 v0, 0x92

    .line 28
    .line 29
    const/4 v3, 0x1

    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-static {v4, v0}, LX/003;->A1H(II)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-static {v0, v2, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    sget-object v0, LX/2sI;->A01:LX/2wD;

    .line 43
    .line 44
    invoke-static {v0, p1, v7}, LX/2pj;->A08(LX/3C1;FF)LX/3C1;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v2, v0}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 53
    .line 54
    invoke-static {v5, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 55
    .line 56
    .line 57
    move-result-object v9

    .line 58
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 59
    .line 60
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    sget-object v5, LX/2Id;->A00:LX/2sS;

    .line 65
    .line 66
    iget-object v12, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onWhyConfirm:Lkotlin/jvm/functions/Function0;

    .line 67
    .line 68
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$primary:LX/Ddn;

    .line 69
    .line 70
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$resolvingMethod:Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 71
    .line 72
    move-object/from16 p3, v0

    .line 73
    .line 74
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$loggedPick:LX/JDM;

    .line 75
    .line 76
    iget-object v11, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onPick:LX/JDN;

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$accounts:LX/Ddn;

    .line 79
    .line 80
    move-object/from16 p2, v0

    .line 81
    .line 82
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$1;->$onAccountPick:LX/JDN;

    .line 83
    .line 84
    invoke-static {v10, v2, v5, v13}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    move-object v5, v2

    .line 89
    check-cast v5, LX/J7I;

    .line 90
    .line 91
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 92
    .line 93
    .line 94
    move-result p0

    .line 95
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 96
    .line 97
    .line 98
    move-result-object v13

    .line 99
    invoke-static {v2, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 100
    .line 101
    .line 102
    move-result-object v10

    .line 103
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 104
    .line 105
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 106
    .line 107
    if-nez v0, :cond_2

    .line 108
    .line 109
    invoke-static {}, LX/1VY;->A00()V

    .line 110
    .line 111
    .line 112
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    throw v0

    .line 117
    :cond_1
    move/from16 v5, p4

    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    invoke-static {v2, v5, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v2, p1, v13, v10, p0}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 124
    .line 125
    .line 126
    const/4 v0, 0x2

    .line 127
    invoke-static {v12, v4, v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodListHeader(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 128
    .line 129
    .line 130
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-nez v0, :cond_4

    .line 135
    .line 136
    const v0, 0x773884a9

    .line 137
    .line 138
    .line 139
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 140
    .line 141
    .line 142
    invoke-interface {v6, v11}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v10

    .line 146
    check-cast v10, LX/JDM;

    .line 147
    .line 148
    const/16 p0, 0x8

    .line 149
    .line 150
    move-object v12, v2

    .line 151
    move v13, v1

    .line 152
    move-object/from16 v9, p3

    .line 153
    .line 154
    move-object v11, v4

    .line 155
    invoke-static/range {v8 .. v14}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodRows(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 156
    .line 157
    .line 158
    :goto_1
    invoke-static {v5, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 159
    .line 160
    .line 161
    invoke-interface/range {p2 .. p2}, Ljava/util/List;->isEmpty()Z

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    if-nez v0, :cond_3

    .line 166
    .line 167
    const v0, 0x6fd97c7b

    .line 168
    .line 169
    .line 170
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 171
    .line 172
    .line 173
    invoke-interface {v6, v7}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v8

    .line 177
    check-cast v8, LX/JDM;

    .line 178
    .line 179
    const/16 v12, 0x8

    .line 180
    .line 181
    move-object/from16 v6, p2

    .line 182
    .line 183
    move-object/from16 v7, p3

    .line 184
    .line 185
    move-object v9, v4

    .line 186
    move-object v10, v2

    .line 187
    move v11, v1

    .line 188
    invoke-static/range {v6 .. v12}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AgeMethodAccounts(Ljava/util/List;Lcom/facebook/aura/user/provider/AgeCheckMethod;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 189
    .line 190
    .line 191
    :goto_2
    invoke-static {v5, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 192
    .line 193
    .line 194
    invoke-static {v5, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 195
    .line 196
    .line 197
    return-void

    .line 198
    :cond_3
    const v0, 0x6fdaca94

    .line 199
    .line 200
    .line 201
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 202
    .line 203
    .line 204
    goto :goto_2

    .line 205
    :cond_4
    const v0, 0x6fd8edf4

    .line 206
    .line 207
    .line 208
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 209
    .line 210
    .line 211
    goto :goto_1

    .line 212
    :cond_5
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 213
    .line 214
    .line 215
    return-void
.end method
