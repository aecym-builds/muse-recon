.class public abstract Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final IdStepColumn(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/JDN;LX/2d4;II)V
    .locals 42
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/JDN<",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p2

    .line 1
    .line 2
    const/4 v5, 0x1

    .line 3
    move-object/from16 v14, p1

    .line 4
    .line 5
    move-object/from16 v8, p3

    .line 6
    .line 7
    invoke-static {v14, v5, v8}, LX/003;->A0y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const v0, 0x197f52c4    # 1.31999054E-23f

    .line 11
    .line 12
    .line 13
    move-object/from16 v7, p4

    .line 14
    .line 15
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 16
    .line 17
    .line 18
    move/from16 v6, p5

    .line 19
    .line 20
    and-int/lit8 v0, p5, 0x6

    .line 21
    .line 22
    move/from16 v15, p0

    .line 23
    .line 24
    if-nez v0, :cond_5

    .line 25
    .line 26
    invoke-static {v7, v15}, LX/004;->A0i(LX/2d4;Z)I

    .line 27
    .line 28
    .line 29
    move-result v11

    .line 30
    or-int v11, v11, p5

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {v7, v14}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v11, v0

    .line 41
    :cond_0
    and-int/lit8 v2, p6, 0x4

    .line 42
    .line 43
    if-eqz v2, :cond_4

    .line 44
    .line 45
    or-int/lit16 v11, v11, 0x180

    .line 46
    .line 47
    :cond_1
    :goto_1
    and-int/lit16 v0, v6, 0xc00

    .line 48
    .line 49
    if-nez v0, :cond_2

    .line 50
    .line 51
    invoke-static {v7, v8}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    or-int/2addr v11, v0

    .line 56
    :cond_2
    and-int/lit16 v1, v11, 0x493

    .line 57
    .line 58
    const/16 v0, 0x492

    .line 59
    .line 60
    const/4 v4, 0x0

    .line 61
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0, v7, v11}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_6

    .line 70
    .line 71
    if-eqz v2, :cond_3

    .line 72
    .line 73
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 74
    .line 75
    :cond_3
    invoke-static {v4, v7, v4, v5}, LX/3J3;->A00(ILX/2d4;II)LX/3Lr;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    const/16 v16, 0x0

    .line 80
    .line 81
    invoke-static {v0, v9, v5}, LX/3J3;->A02(LX/3Lr;LX/3C1;Z)LX/3C1;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 86
    .line 87
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 92
    .line 93
    invoke-static {v1}, LX/Dn6;->A00(F)LX/CP5;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    sget-object v1, LX/2Id;->A00:LX/2sS;

    .line 98
    .line 99
    invoke-static {v2, v7, v1}, LX/002;->A0d(LX/Dps;LX/2d4;LX/2sS;)LX/3BI;

    .line 100
    .line 101
    .line 102
    move-result-object v13

    .line 103
    move-object v3, v7

    .line 104
    check-cast v3, LX/J7I;

    .line 105
    .line 106
    invoke-static {v3}, LX/003;->A0F(LX/J7I;)I

    .line 107
    .line 108
    .line 109
    move-result v12

    .line 110
    invoke-static {v3}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 111
    .line 112
    .line 113
    move-result-object v10

    .line 114
    invoke-static {v7, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 119
    .line 120
    iget-object v0, v3, LX/J7I;->A0V:LX/3DJ;

    .line 121
    .line 122
    if-nez v0, :cond_7

    .line 123
    .line 124
    invoke-static {}, LX/1VY;->A00()V

    .line 125
    .line 126
    .line 127
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    throw v0

    .line 132
    :cond_4
    and-int/lit16 v0, v6, 0x180

    .line 133
    .line 134
    if-nez v0, :cond_1

    .line 135
    .line 136
    invoke-static {v7, v9}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    or-int/2addr v11, v0

    .line 141
    goto :goto_1

    .line 142
    :cond_5
    move v11, v6

    .line 143
    goto :goto_0

    .line 144
    :cond_6
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 145
    .line 146
    .line 147
    goto :goto_2

    .line 148
    :cond_7
    invoke-static {v7, v3, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 149
    .line 150
    .line 151
    invoke-static {v7, v13, v10, v2, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 152
    .line 153
    .line 154
    shr-int/lit8 v0, v11, 0x9

    .line 155
    .line 156
    invoke-static {v7, v8, v0}, LX/003;->A19(Ljava/lang/Object;LX/JDN;I)V

    .line 157
    .line 158
    .line 159
    const v0, 0x7f1202b8

    .line 160
    .line 161
    .line 162
    invoke-static {v7, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v17

    .line 166
    sget-object v19, LX/2sI;->A02:LX/2wD;

    .line 167
    .line 168
    shl-int/lit8 v1, v11, 0x1b

    .line 169
    .line 170
    const/high16 v0, 0x70000000

    .line 171
    .line 172
    and-int/2addr v1, v0

    .line 173
    or-int/lit16 v0, v1, 0xc00

    .line 174
    .line 175
    const v1, 0xe000

    .line 176
    .line 177
    .line 178
    shl-int/lit8 p3, v11, 0x9

    .line 179
    .line 180
    and-int p3, p3, v1

    .line 181
    .line 182
    const p5, 0x7ffbdf5

    .line 183
    .line 184
    .line 185
    move-object/from16 v18, v16

    .line 186
    .line 187
    move-object/from16 v20, v16

    .line 188
    .line 189
    move-object/from16 v21, v16

    .line 190
    .line 191
    move-object/from16 v22, v16

    .line 192
    .line 193
    move/from16 v23, v4

    .line 194
    .line 195
    move/from16 v24, v4

    .line 196
    .line 197
    move/from16 v25, v15

    .line 198
    .line 199
    move/from16 v26, v4

    .line 200
    .line 201
    move/from16 v27, v4

    .line 202
    .line 203
    move-object/from16 v28, v16

    .line 204
    .line 205
    move-object/from16 v29, v16

    .line 206
    .line 207
    move-object/from16 v30, v14

    .line 208
    .line 209
    move-object/from16 v31, v16

    .line 210
    .line 211
    move-object/from16 v32, v16

    .line 212
    .line 213
    move-object/from16 v33, v16

    .line 214
    .line 215
    move-object/from16 v34, v16

    .line 216
    .line 217
    move-object/from16 v35, v16

    .line 218
    .line 219
    move-object/from16 v36, v16

    .line 220
    .line 221
    move-object/from16 v37, v16

    .line 222
    .line 223
    move-object/from16 v38, v16

    .line 224
    .line 225
    move/from16 v39, v4

    .line 226
    .line 227
    move/from16 v40, v4

    .line 228
    .line 229
    move/from16 v41, v4

    .line 230
    .line 231
    move/from16 p0, v4

    .line 232
    .line 233
    move-object/from16 p1, v7

    .line 234
    .line 235
    move/from16 p2, v0

    .line 236
    .line 237
    move/from16 p4, v4

    .line 238
    .line 239
    invoke-static/range {v16 .. v47}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 240
    .line 241
    .line 242
    invoke-static {v3, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 243
    .line 244
    .line 245
    :goto_2
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 246
    .line 247
    .line 248
    move-result-object v1

    .line 249
    if-eqz v1, :cond_8

    .line 250
    .line 251
    new-instance v0, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepColumn$2;

    .line 252
    .line 253
    move-object/from16 p4, v8

    .line 254
    .line 255
    move/from16 p5, v6

    .line 256
    .line 257
    move-object/from16 p0, v0

    .line 258
    .line 259
    move/from16 p1, v15

    .line 260
    .line 261
    move-object/from16 p2, v14

    .line 262
    .line 263
    move-object/from16 p3, v9

    .line 264
    .line 265
    invoke-direct/range {p0 .. p6}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepColumn$2;-><init>(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/JDN;II)V

    .line 266
    .line 267
    .line 268
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 269
    .line 270
    :cond_8
    return-void
.end method

.method public static final IdStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v9, p3

    .line 1
    move-object v8, p2

    .line 2
    move-object/from16 v10, p4

    .line 3
    .line 4
    const/16 p4, 0x0

    .line 5
    .line 6
    move-object v6, p0

    .line 7
    move-object v7, p1

    .line 8
    invoke-static {p0, p1}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v11

    .line 12
    const v0, 0x51542a3

    .line 13
    .line 14
    .line 15
    move-object/from16 p2, p5

    .line 16
    .line 17
    invoke-interface {p2, v0}, LX/2d4;->Agl(I)V

    .line 18
    .line 19
    .line 20
    move/from16 v1, p6

    .line 21
    .line 22
    and-int/lit8 v0, p6, 0x6

    .line 23
    .line 24
    if-nez v0, :cond_d

    .line 25
    .line 26
    invoke-static {p2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    or-int v2, v2, p6

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    or-int/2addr v2, v0

    .line 41
    :cond_0
    move/from16 p6, p7

    .line 42
    .line 43
    and-int/lit8 v5, p7, 0x4

    .line 44
    .line 45
    if-eqz v5, :cond_c

    .line 46
    .line 47
    or-int/lit16 v2, v2, 0x180

    .line 48
    .line 49
    :cond_1
    :goto_1
    and-int/lit8 v4, p7, 0x8

    .line 50
    .line 51
    if-eqz v4, :cond_b

    .line 52
    .line 53
    or-int/lit16 v2, v2, 0xc00

    .line 54
    .line 55
    :cond_2
    :goto_2
    and-int/lit8 v3, p7, 0x10

    .line 56
    .line 57
    if-eqz v3, :cond_a

    .line 58
    .line 59
    or-int/lit16 v2, v2, 0x6000

    .line 60
    .line 61
    :cond_3
    :goto_3
    invoke-static {v2}, LX/009;->A1I(I)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0, p2, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_9

    .line 70
    .line 71
    if-eqz v5, :cond_4

    .line 72
    .line 73
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 74
    .line 75
    :cond_4
    if-eqz v4, :cond_5

    .line 76
    .line 77
    const/4 v9, 0x0

    .line 78
    :cond_5
    if-eqz v3, :cond_7

    .line 79
    .line 80
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 85
    .line 86
    if-ne v10, v0, :cond_6

    .line 87
    .line 88
    sget-object v10, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$1$1;

    .line 89
    .line 90
    invoke-interface {p2, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    :cond_6
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 94
    .line 95
    :cond_7
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 96
    .line 97
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 98
    .line 99
    invoke-static {v0, p2}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 104
    .line 105
    iget-object p0, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title1Medium:LX/2hg;

    .line 106
    .line 107
    invoke-static {p2, v3}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    and-int/lit8 v3, v2, 0xe

    .line 112
    .line 113
    const/high16 v0, 0x30000

    .line 114
    .line 115
    or-int/2addr v3, v0

    .line 116
    invoke-static {v2, v3}, LX/004;->A05(II)I

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    invoke-static {v2, v0}, LX/002;->A09(II)I

    .line 121
    .line 122
    .line 123
    move-result p3

    .line 124
    invoke-static/range {v6 .. v16}, Lcom/facebook/aura/activation/ageverification/AgeStepHeaderKt;->AgeStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLX/2hg;LX/2hg;LX/2d4;II)V

    .line 125
    .line 126
    .line 127
    :goto_4
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    if-eqz v0, :cond_8

    .line 132
    .line 133
    new-instance v11, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;

    .line 134
    .line 135
    move-object p0, v6

    .line 136
    move-object p1, v7

    .line 137
    move-object p2, v8

    .line 138
    move-object p3, v9

    .line 139
    move-object/from16 p4, v10

    .line 140
    .line 141
    move/from16 p5, v1

    .line 142
    .line 143
    invoke-direct/range {v11 .. v18}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt$IdStepHeader$2;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;II)V

    .line 144
    .line 145
    .line 146
    iput-object v11, v0, LX/J7V;->A06:LX/JDN;

    .line 147
    .line 148
    :cond_8
    return-void

    .line 149
    :cond_9
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 150
    .line 151
    .line 152
    goto :goto_4

    .line 153
    :cond_a
    and-int/lit16 v0, v1, 0x6000

    .line 154
    .line 155
    if-nez v0, :cond_3

    .line 156
    .line 157
    invoke-static {p2, v10}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    or-int/2addr v2, v0

    .line 162
    goto :goto_3

    .line 163
    :cond_b
    and-int/lit16 v0, v1, 0xc00

    .line 164
    .line 165
    if-nez v0, :cond_2

    .line 166
    .line 167
    invoke-static {p2, p3}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    or-int/2addr v2, v0

    .line 172
    goto :goto_2

    .line 173
    :cond_c
    and-int/lit16 v0, v1, 0x180

    .line 174
    .line 175
    if-nez v0, :cond_1

    .line 176
    .line 177
    invoke-static {p2, v8}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    or-int/2addr v2, v0

    .line 182
    goto/16 :goto_1

    .line 183
    .line 184
    :cond_d
    move v2, v1

    .line 185
    goto/16 :goto_0
.end method
