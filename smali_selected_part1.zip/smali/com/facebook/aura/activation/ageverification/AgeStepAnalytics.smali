.class public final Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static synthetic logClick$default(Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;ILjava/lang/Object;)V
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p2, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_AGE_CONFIRMATION:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V
    .locals 5

    .line 0
    move-object v4, p1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    move-object p0, v2

    .line 11
    move-object p1, v2

    .line 12
    move-object p2, v2

    .line 13
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
