.class public final Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $accounts:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $handler:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $primary:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDN;LX/Ddn;LX/Ddn;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/user/provider/AgeCheckMethod;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$handler:LX/JDN;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$primary:LX/Ddn;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$accounts:LX/Ddn;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/user/provider/AgeCheckMethod;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->invoke(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/user/provider/AgeCheckMethod;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;

    .line 5
    .line 6
    invoke-static {p1}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->getPickComponent(Lcom/facebook/aura/user/provider/AgeCheckMethod;)Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AGE_METHODS_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 11
    .line 12
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$handler:LX/JDN;

    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$primary:LX/Ddn;

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$loggedPick$1$1$1;->$accounts:LX/Ddn;

    .line 20
    .line 21
    invoke-static {v0, v1}, LX/B89;->A0c(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0, p1}, Ljava/util/AbstractList;->indexOf(Ljava/lang/Object;)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    add-int/lit8 v0, v0, 0x1

    .line 30
    .line 31
    invoke-static {p1, v2, v0}, LX/002;->A1N(Ljava/lang/Object;LX/JDN;I)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
