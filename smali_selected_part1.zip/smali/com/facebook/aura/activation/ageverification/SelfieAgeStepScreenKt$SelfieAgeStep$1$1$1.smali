.class public final Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $currentOnBack$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnOtherMethods$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnResolved$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $currentOnSelfieUnavailable$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;LX/16A;LX/16A;LX/16A;LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/16A<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnSelfieUnavailable$delegate:LX/16A;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnBack$delegate:LX/16A;

    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepEffect;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/SelfieAgeStepEffect;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 1
    .line 2
    .line 3
    move-result v2

    .line 4
    const/4 v0, 0x0

    .line 5
    if-eq v2, v0, :cond_2

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eq v2, v0, :cond_1

    .line 9
    .line 10
    const/4 v1, 0x2

    .line 11
    if-eq v2, v1, :cond_0

    .line 12
    .line 13
    const/4 v1, 0x3

    .line 14
    if-eq v2, v1, :cond_3

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    if-ne v2, v0, :cond_4

    .line 18
    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnBack$delegate:LX/16A;

    .line 20
    .line 21
    invoke-static {v0}, LX/16A;->A09(LX/16A;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->onShown()V

    .line 27
    .line 28
    .line 29
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 33
    .line 34
    invoke-static {v0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 39
    .line 40
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    goto :goto_1

    .line 44
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnSelfieUnavailable$delegate:LX/16A;

    .line 45
    .line 46
    invoke-static {v0}, LX/16A;->A09(LX/16A;)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnOtherMethods$delegate:LX/16A;

    .line 51
    .line 52
    invoke-static {v0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    sget-object v1, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->SELFIE:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 57
    .line 58
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 59
    .line 60
    iget-boolean v0, v0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->leftReviewPending:Z

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$currentOnResolved$delegate:LX/16A;

    .line 64
    .line 65
    invoke-static {v1}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->$viewModel:Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;

    .line 70
    .line 71
    iget-object v1, v1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepViewModel;->resolvedMethod:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 72
    .line 73
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-interface {v2, v1, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_4
    invoke-static {}, LX/001;->A1A()Lkotlin/NoWhenBranchMatchedException;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    throw v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepEffect;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/SelfieAgeStepScreenKt$SelfieAgeStep$1$1$1;->emit(Lcom/facebook/aura/activation/ageverification/SelfieAgeStepEffect;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
