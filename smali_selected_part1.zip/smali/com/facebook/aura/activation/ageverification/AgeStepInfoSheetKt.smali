.class public abstract Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgeStepInfoRowContent(Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;LX/3C1;LX/2d4;II)V
    .locals 24

    .line 0
    move-object/from16 v7, p1

    .line 1
    .line 2
    const v0, -0x1da084aa

    .line 3
    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    invoke-static {v1, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v10

    .line 22
    or-int v10, v10, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v9, p4

    .line 25
    .line 26
    and-int/lit8 v8, p4, 0x2

    .line 27
    .line 28
    if-eqz v8, :cond_2

    .line 29
    .line 30
    or-int/lit8 v10, v10, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v6, v10, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v5, 0x1

    .line 37
    const/4 v4, 0x0

    .line 38
    invoke-static {v6, v0}, LX/003;->A1H(II)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    invoke-static {v0, v1, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_6

    .line 47
    .line 48
    if-eqz v8, :cond_1

    .line 49
    .line 50
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 51
    .line 52
    :cond_1
    invoke-static {v7}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 57
    .line 58
    invoke-static {v1, v0}, LX/008;->A0l(LX/2d4;F)LX/3BI;

    .line 59
    .line 60
    .line 61
    move-result-object v13

    .line 62
    move-object v0, v1

    .line 63
    check-cast v0, LX/J7I;

    .line 64
    .line 65
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 66
    .line 67
    .line 68
    move-result v12

    .line 69
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 70
    .line 71
    .line 72
    move-result-object v11

    .line 73
    invoke-static {v1, v6}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 78
    .line 79
    iget-object v6, v0, LX/J7I;->A0V:LX/3DJ;

    .line 80
    .line 81
    if-nez v6, :cond_4

    .line 82
    .line 83
    invoke-static {}, LX/1VY;->A00()V

    .line 84
    .line 85
    .line 86
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    throw v0

    .line 91
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 92
    .line 93
    if-nez v0, :cond_0

    .line 94
    .line 95
    invoke-static {v1, v7}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    or-int/2addr v10, v0

    .line 100
    goto :goto_1

    .line 101
    :cond_3
    move v10, v3

    .line 102
    goto :goto_0

    .line 103
    :cond_4
    invoke-static {v1, v0, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v1, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 107
    .line 108
    .line 109
    sget-object v8, LX/CgK;->A00:LX/CgK;

    .line 110
    .line 111
    iget v6, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->iconRes:I

    .line 112
    .line 113
    invoke-static {v1, v6, v4}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 114
    .line 115
    .line 116
    move-result-object v13

    .line 117
    sget-object v14, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 118
    .line 119
    sget-object v6, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 120
    .line 121
    invoke-static {v1, v6}, LX/07H;->A02(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 122
    .line 123
    .line 124
    move-result-wide v16

    .line 125
    invoke-static {}, LX/2l9;->A03()I

    .line 126
    .line 127
    .line 128
    move-result v20

    .line 129
    const/16 v21, 0x29

    .line 130
    .line 131
    const/4 v15, 0x0

    .line 132
    move-object v12, v15

    .line 133
    move-object/from16 v18, v15

    .line 134
    .line 135
    move-object/from16 v19, v1

    .line 136
    .line 137
    invoke-static/range {v12 .. v21}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 138
    .line 139
    .line 140
    iget-boolean v10, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->namesApp:Z

    .line 141
    .line 142
    if-eqz v10, :cond_5

    .line 143
    .line 144
    const v10, -0x1c7a2dfb

    .line 145
    .line 146
    .line 147
    invoke-interface {v1, v10}, LX/2d4;->Agj(I)V

    .line 148
    .line 149
    .line 150
    iget v10, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->textRes:I

    .line 151
    .line 152
    invoke-static {v1, v10}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v10

    .line 156
    :goto_2
    invoke-static {v0, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 157
    .line 158
    .line 159
    invoke-static {v1, v6}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 160
    .line 161
    .line 162
    move-result-object v14

    .line 163
    invoke-static {v1, v6}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 164
    .line 165
    .line 166
    move-result-wide v12

    .line 167
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 168
    .line 169
    invoke-static {v8, v6, v5}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 170
    .line 171
    .line 172
    move-result-object v11

    .line 173
    const/16 p4, 0x3ff0

    .line 174
    .line 175
    move-object/from16 v16, v15

    .line 176
    .line 177
    move-object/from16 v17, v15

    .line 178
    .line 179
    move/from16 v19, v4

    .line 180
    .line 181
    move/from16 v20, v4

    .line 182
    .line 183
    move/from16 v21, v4

    .line 184
    .line 185
    move-object/from16 v22, v15

    .line 186
    .line 187
    move-object/from16 v23, v15

    .line 188
    .line 189
    move-object/from16 p0, v15

    .line 190
    .line 191
    move-object/from16 p1, v1

    .line 192
    .line 193
    move/from16 p2, v4

    .line 194
    .line 195
    move/from16 p3, v4

    .line 196
    .line 197
    move/from16 v18, v4

    .line 198
    .line 199
    invoke-static/range {v10 .. v28}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 200
    .line 201
    .line 202
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 203
    .line 204
    .line 205
    goto :goto_3

    .line 206
    :cond_5
    const v10, -0x1c7a256f

    .line 207
    .line 208
    .line 209
    invoke-interface {v1, v10}, LX/2d4;->Agj(I)V

    .line 210
    .line 211
    .line 212
    iget v10, v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->textRes:I

    .line 213
    .line 214
    invoke-static {v1, v10}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v10

    .line 218
    goto :goto_2

    .line 219
    :cond_6
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 220
    .line 221
    .line 222
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    if-eqz v1, :cond_7

    .line 227
    .line 228
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoRowContent$2;

    .line 229
    .line 230
    invoke-direct {v0, v2, v7, v3, v9}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoRowContent$2;-><init>(Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;LX/3C1;II)V

    .line 231
    .line 232
    .line 233
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 234
    .line 235
    :cond_7
    return-void
.end method

.method public static final AgeStepInfoSheet(Lcom/facebook/aura/activation/ageverification/AgeStepInfo;LX/3C1;LX/2d4;II)V
    .locals 20

    .line 0
    move-object/from16 v9, p1

    .line 1
    .line 2
    const/4 v15, 0x0

    .line 3
    move-object/from16 v3, p0

    .line 4
    .line 5
    invoke-static {v3, v15}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x379e3ee4

    .line 9
    .line 10
    .line 11
    move-object/from16 v2, p2

    .line 12
    .line 13
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v1, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_6

    .line 21
    .line 22
    invoke-static {v2, v3}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    or-int v5, v5, p3

    .line 27
    .line 28
    :goto_0
    move/from16 v0, p4

    .line 29
    .line 30
    and-int/lit8 v6, p4, 0x2

    .line 31
    .line 32
    if-eqz v6, :cond_5

    .line 33
    .line 34
    or-int/lit8 v5, v5, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    invoke-static {v5}, LX/005;->A1G(I)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    invoke-static {v4, v2, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_4

    .line 45
    .line 46
    if-eqz v6, :cond_1

    .line 47
    .line 48
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 49
    .line 50
    :cond_1
    sget-object v4, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 51
    .line 52
    move-object v8, v2

    .line 53
    check-cast v8, LX/J7I;

    .line 54
    .line 55
    invoke-static {v4, v8}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 56
    .line 57
    .line 58
    move-result-object v7

    .line 59
    invoke-virtual {v3}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->getTitleRes()I

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    invoke-static {v2, v4}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v17

    .line 67
    invoke-virtual {v3}, Lcom/facebook/aura/activation/ageverification/AgeStepInfo;->getSubtitleRes()Ljava/lang/Integer;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    if-nez v6, :cond_3

    .line 72
    .line 73
    const v4, -0x5833c719

    .line 74
    .line 75
    .line 76
    invoke-interface {v2, v4}, LX/2d4;->Agj(I)V

    .line 77
    .line 78
    .line 79
    invoke-static {v8, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 80
    .line 81
    .line 82
    const/16 v18, 0x0

    .line 83
    .line 84
    :goto_2
    const/4 v8, 0x0

    .line 85
    sget-object p2, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;->DEFAULT:Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;

    .line 86
    .line 87
    const p4, 0x7fffffff

    .line 88
    .line 89
    .line 90
    new-instance v11, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;

    .line 91
    .line 92
    move-object/from16 v16, v11

    .line 93
    .line 94
    move-object/from16 v19, v8

    .line 95
    .line 96
    move-object/from16 p0, v8

    .line 97
    .line 98
    move-object/from16 p1, v8

    .line 99
    .line 100
    move-object/from16 p3, v8

    .line 101
    .line 102
    invoke-direct/range {v16 .. v24}, Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$AccessoryButton;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$Style;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig$LabeledAccessoryButton;I)V

    .line 103
    .line 104
    .line 105
    new-instance v6, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;

    .line 106
    .line 107
    invoke-direct {v6, v7}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$2;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 108
    .line 109
    .line 110
    const v4, 0x5b74e003

    .line 111
    .line 112
    .line 113
    invoke-static {v2, v6, v4}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 114
    .line 115
    .line 116
    move-result-object v12

    .line 117
    new-instance v6, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;

    .line 118
    .line 119
    invoke-direct {v6, v3}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$3;-><init>(Lcom/facebook/aura/activation/ageverification/AgeStepInfo;)V

    .line 120
    .line 121
    .line 122
    const v4, -0x3ec485a2

    .line 123
    .line 124
    .line 125
    invoke-static {v2, v6, v4}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 126
    .line 127
    .line 128
    move-result-object p0

    .line 129
    and-int/lit8 v4, v5, 0x70

    .line 130
    .line 131
    or-int/lit16 v4, v4, 0x6000

    .line 132
    .line 133
    const/16 p3, 0x180

    .line 134
    .line 135
    const/16 p4, 0xfe5

    .line 136
    .line 137
    move-object v10, v8

    .line 138
    move-object v13, v8

    .line 139
    move-object v14, v8

    .line 140
    move/from16 v16, v15

    .line 141
    .line 142
    move/from16 v17, v15

    .line 143
    .line 144
    move-object/from16 v18, v8

    .line 145
    .line 146
    move-object/from16 p1, v2

    .line 147
    .line 148
    move/from16 p2, v4

    .line 149
    .line 150
    invoke-static/range {v8 .. v24}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 151
    .line 152
    .line 153
    :goto_3
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    if-eqz v4, :cond_2

    .line 158
    .line 159
    new-instance v2, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$4;

    .line 160
    .line 161
    invoke-direct {v2, v3, v9, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt$AgeStepInfoSheet$4;-><init>(Lcom/facebook/aura/activation/ageverification/AgeStepInfo;LX/3C1;II)V

    .line 162
    .line 163
    .line 164
    iput-object v2, v4, LX/J7V;->A06:LX/JDN;

    .line 165
    .line 166
    :cond_2
    return-void

    .line 167
    :cond_3
    const v4, -0x5833c718

    .line 168
    .line 169
    .line 170
    invoke-static {v2, v6, v4}, LX/18b;->A07(LX/2d4;Ljava/lang/Number;I)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v18

    .line 174
    invoke-static {v8, v15}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 175
    .line 176
    .line 177
    goto :goto_2

    .line 178
    :cond_4
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 179
    .line 180
    .line 181
    goto :goto_3

    .line 182
    :cond_5
    and-int/lit8 v4, p3, 0x30

    .line 183
    .line 184
    if-nez v4, :cond_0

    .line 185
    .line 186
    invoke-static {v2, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 187
    .line 188
    .line 189
    move-result v4

    .line 190
    or-int/2addr v5, v4

    .line 191
    goto/16 :goto_1

    .line 192
    .line 193
    :cond_6
    move v5, v1

    .line 194
    goto/16 :goto_0
.end method

.method public static final synthetic access$AgeStepInfoRowContent(Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoSheetKt;->AgeStepInfoRowContent(Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
