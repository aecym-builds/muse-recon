.class public final Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Boolean;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $document:Lcom/facebook/aura/activation/ageverification/IdDocument;

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDM;Lcom/facebook/aura/activation/ageverification/IdDocument;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/IdDocument;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;->$onSelect:LX/JDM;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;->$document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;->invoke(Z)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(Z)V
    .locals 0

    .line 268435456
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;->$onSelect:LX/JDM;

    .line 268435457
    .line 268435458
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/IdDocumentTypeContentKt$IdDocumentRow$2$2$1;->$document:Lcom/facebook/aura/activation/ageverification/IdDocument;

    .line 268435459
    .line 268435460
    invoke-interface {p1, p0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method
