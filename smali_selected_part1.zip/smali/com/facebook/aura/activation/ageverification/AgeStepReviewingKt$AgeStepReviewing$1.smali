.class public final Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onOtherMethods:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $takingLonger:Z


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "LX/3C1;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$modifier:LX/3C1;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$takingLonger:Z

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$onOtherMethods:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput p5, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$$changed:I

    .line 9
    .line 10
    iput p6, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$$default:I

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 7

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$method:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$modifier:LX/3C1;

    .line 3
    .line 4
    iget-boolean v3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$takingLonger:Z

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$onOtherMethods:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$$changed:I

    .line 9
    .line 10
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 11
    .line 12
    .line 13
    move-result v6

    .line 14
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;->$$default:I

    .line 15
    .line 16
    move-object v5, p1

    .line 17
    invoke-static/range {v1 .. v7}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->AgeStepReviewing(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
