.class public final Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onBack:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchComponent;->BACK_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt;->AGE_METHODS_SCREEN:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    invoke-virtual {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepAnalytics;->logClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/AgeMethodListScreenKt$AgeMethodListScreen$onBackClick$1$1;->$onBack:Lkotlin/jvm/functions/Function0;

    .line 10
    .line 11
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    return-void
.end method
