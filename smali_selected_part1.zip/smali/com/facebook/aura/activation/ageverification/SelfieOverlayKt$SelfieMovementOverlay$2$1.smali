.class public final Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2la;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $complete:J

.field public final synthetic $current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

.field public final synthetic $fill:J

.field public final synthetic $flashes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $mask:J

.field public final synthetic $progress:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reviewFill:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $track:J

.field public final synthetic $withBottomArc:Z


# direct methods
.method public constructor <init>(JJZLX/Ddn;Lcom/facebook/aura/activation/ageverification/HeadMovement;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;J)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJZ",
            "LX/Ddn<",
            "Lcom/facebook/aura/activation/ageverification/CompletionFlash;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/HeadMovement;",
            "J",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;J)V"
        }
    .end annotation

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$mask:J

    .line 1
    .line 2
    iput-wide p3, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$track:J

    .line 3
    .line 4
    iput-boolean p5, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$withBottomArc:Z

    .line 5
    .line 6
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$flashes:LX/Ddn;

    .line 7
    .line 8
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 9
    .line 10
    iput-wide p8, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$fill:J

    .line 11
    .line 12
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$progress:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput-object p11, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$reviewFill:Lkotlin/jvm/functions/Function0;

    .line 15
    .line 16
    iput-wide p12, p0, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$complete:J

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2la;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->invoke(LX/2la;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2la;)V
    .locals 20

    .line 0
    const/4 v14, 0x0

    .line 1
    move-object/from16 v15, p1

    .line 2
    .line 3
    invoke-static {v15, v14}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const/high16 v12, 0x40800000    # 4.0f

    .line 7
    .line 8
    invoke-interface {v15, v12}, LX/34Y;->AhZ(F)F

    .line 9
    .line 10
    .line 11
    move-result v11

    .line 12
    const/4 v13, 0x1

    .line 13
    const/4 v10, 0x0

    .line 14
    new-instance v9, LX/2RO;

    .line 15
    .line 16
    invoke-direct/range {v9 .. v14}, LX/2RO;-><init>(LX/2RU;FFII)V

    .line 17
    .line 18
    .line 19
    move-object/from16 v4, p0

    .line 20
    .line 21
    iget-wide v5, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$mask:J

    .line 22
    .line 23
    iget-wide v1, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$track:J

    .line 24
    .line 25
    iget-boolean v0, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$withBottomArc:Z

    .line 26
    .line 27
    move-wide/from16 v16, v5

    .line 28
    .line 29
    move-wide/from16 v18, v1

    .line 30
    .line 31
    move-object/from16 p0, v9

    .line 32
    .line 33
    move/from16 p1, v0

    .line 34
    .line 35
    invoke-static/range {v15 .. v21}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawSelfieFrame-1wkBAMs(LX/2la;JJLX/2RO;Z)F

    .line 36
    .line 37
    .line 38
    move-result v19

    .line 39
    iget-object v5, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$flashes:LX/Ddn;

    .line 40
    .line 41
    iget-wide v2, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$track:J

    .line 42
    .line 43
    iget-wide v0, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$complete:J

    .line 44
    .line 45
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object v8

    .line 49
    :cond_0
    :goto_0
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    if-eqz v5, :cond_1

    .line 54
    .line 55
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v7

    .line 59
    check-cast v7, Lcom/facebook/aura/activation/ageverification/CompletionFlash;

    .line 60
    .line 61
    iget-object v5, v7, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->strength:LX/16A;

    .line 62
    .line 63
    invoke-static {v5}, LX/16A;->A00(LX/16A;)F

    .line 64
    .line 65
    .line 66
    move-result v6

    .line 67
    const/4 v5, 0x0

    .line 68
    cmpl-float v5, v6, v5

    .line 69
    .line 70
    if-lez v5, :cond_0

    .line 71
    .line 72
    invoke-static {v2, v3, v0, v1, v6}, LX/JOv;->A03(JJF)J

    .line 73
    .line 74
    .line 75
    move-result-wide v16

    .line 76
    iget-object v5, v7, Lcom/facebook/aura/activation/ageverification/CompletionFlash;->direction:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 77
    .line 78
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F

    .line 79
    .line 80
    .line 81
    move-result p0

    .line 82
    const/high16 p1, 0x3f800000    # 1.0f

    .line 83
    .line 84
    move-object/from16 v18, v9

    .line 85
    .line 86
    invoke-static/range {v15 .. v21}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 87
    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_1
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$current:Lcom/facebook/aura/activation/ageverification/HeadMovement;

    .line 91
    .line 92
    if-eqz v2, :cond_2

    .line 93
    .line 94
    iget-wide v0, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$fill:J

    .line 95
    .line 96
    invoke-static {v2}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->getArcCenter(Lcom/facebook/aura/activation/ageverification/HeadMovement;)F

    .line 97
    .line 98
    .line 99
    move-result p0

    .line 100
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$progress:Lkotlin/jvm/functions/Function0;

    .line 101
    .line 102
    invoke-static {v2}, LX/003;->A01(Lkotlin/jvm/functions/Function0;)F

    .line 103
    .line 104
    .line 105
    move-result p1

    .line 106
    move-object/from16 v18, v9

    .line 107
    .line 108
    move-wide/from16 v16, v0

    .line 109
    .line 110
    invoke-static/range {v15 .. v21}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawRingArc-3IgeMak(LX/2la;JLX/2RO;FFF)V

    .line 111
    .line 112
    .line 113
    :cond_2
    iget-wide v0, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$fill:J

    .line 114
    .line 115
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt$SelfieMovementOverlay$2$1;->$reviewFill:Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    invoke-static {v2}, LX/003;->A01(Lkotlin/jvm/functions/Function0;)F

    .line 118
    .line 119
    .line 120
    move-result p0

    .line 121
    move-object/from16 v18, v9

    .line 122
    .line 123
    move-wide/from16 v16, v0

    .line 124
    .line 125
    invoke-static/range {v15 .. v20}, Lcom/facebook/aura/activation/ageverification/SelfieOverlayKt;->drawReviewFill-iJQMabo(LX/2la;JLX/2RO;FF)V

    .line 126
    .line 127
    .line 128
    return-void
.end method
