.class public abstract Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgeStepErrorCard(Lkotlin/jvm/functions/Function0;LX/3C1;Lkotlin/jvm/functions/Function0;ILX/2d4;II)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;I",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    move/from16 v3, p3

    .line 3
    .line 4
    move-object/from16 v11, p1

    .line 5
    .line 6
    const/4 v14, 0x0

    .line 7
    move-object v5, p0

    .line 8
    invoke-static {p0, v14}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 9
    .line 10
    .line 11
    const v0, 0xac2c11d

    .line 12
    .line 13
    .line 14
    move-object/from16 v6, p4

    .line 15
    .line 16
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 17
    .line 18
    .line 19
    move/from16 v2, p5

    .line 20
    .line 21
    and-int/lit8 v0, p5, 0x6

    .line 22
    .line 23
    if-nez v0, :cond_e

    .line 24
    .line 25
    invoke-static {v6, p0}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 26
    .line 27
    .line 28
    move-result v7

    .line 29
    or-int v7, v7, p5

    .line 30
    .line 31
    :goto_0
    move/from16 v1, p6

    .line 32
    .line 33
    and-int/lit8 v10, p6, 0x2

    .line 34
    .line 35
    if-eqz v10, :cond_d

    .line 36
    .line 37
    or-int/lit8 v7, v7, 0x30

    .line 38
    .line 39
    :cond_0
    :goto_1
    and-int/lit8 v9, p6, 0x4

    .line 40
    .line 41
    if-eqz v9, :cond_c

    .line 42
    .line 43
    or-int/lit16 v7, v7, 0x180

    .line 44
    .line 45
    :cond_1
    :goto_2
    and-int/lit16 v0, v2, 0xc00

    .line 46
    .line 47
    if-nez v0, :cond_4

    .line 48
    .line 49
    and-int/lit8 v0, p6, 0x8

    .line 50
    .line 51
    if-nez v0, :cond_2

    .line 52
    .line 53
    invoke-interface {v6, v3}, LX/2d4;->A67(I)Z

    .line 54
    .line 55
    .line 56
    move-result v8

    .line 57
    const/16 v0, 0x800

    .line 58
    .line 59
    if-nez v8, :cond_3

    .line 60
    .line 61
    :cond_2
    const/16 v0, 0x400

    .line 62
    .line 63
    :cond_3
    or-int/2addr v7, v0

    .line 64
    :cond_4
    invoke-static {v7}, LX/005;->A1K(I)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v0, v6, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_b

    .line 73
    .line 74
    invoke-interface {v6}, LX/2d4;->AgT()V

    .line 75
    .line 76
    .line 77
    and-int/lit8 v0, p5, 0x1

    .line 78
    .line 79
    const/4 p0, 0x0

    .line 80
    if-eqz v0, :cond_8

    .line 81
    .line 82
    invoke-interface {v6}, LX/2d4;->AEs()Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-nez v0, :cond_8

    .line 87
    .line 88
    invoke-static {v1, v6, v7}, LX/003;->A0A(ILX/2d4;I)I

    .line 89
    .line 90
    .line 91
    move-result v7

    .line 92
    :cond_5
    :goto_3
    invoke-interface {v6}, LX/2d4;->AAf()V

    .line 93
    .line 94
    .line 95
    const v10, 0x7f120098

    .line 96
    .line 97
    .line 98
    const v9, 0x7f08012c

    .line 99
    .line 100
    .line 101
    if-eqz v4, :cond_6

    .line 102
    .line 103
    const v0, 0x7f1202bd

    .line 104
    .line 105
    .line 106
    new-instance p0, Lcom/facebook/aura/activation/ageverification/AgeStepAction;

    .line 107
    .line 108
    invoke-direct {p0, v0, v4}, Lcom/facebook/aura/activation/ageverification/AgeStepAction;-><init>(ILkotlin/jvm/functions/Function0;)V

    .line 109
    .line 110
    .line 111
    :cond_6
    const v0, 0x7f1200a2

    .line 112
    .line 113
    .line 114
    new-instance v8, Lcom/facebook/aura/activation/ageverification/AgeStepAction;

    .line 115
    .line 116
    invoke-direct {v8, v0, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepAction;-><init>(ILkotlin/jvm/functions/Function0;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v12

    .line 123
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 124
    .line 125
    .line 126
    move-result-object v13

    .line 127
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 128
    .line 129
    .line 130
    move-result-object p2

    .line 131
    shr-int/lit8 v0, v7, 0x3

    .line 132
    .line 133
    and-int/lit16 v0, v0, 0x38e

    .line 134
    .line 135
    const/16 p5, 0x8

    .line 136
    .line 137
    move-object/from16 p3, v6

    .line 138
    .line 139
    move/from16 p4, v0

    .line 140
    .line 141
    move-object/from16 p1, v8

    .line 142
    .line 143
    invoke-static/range {v11 .. v20}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepMessage(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;LX/2d4;II)V

    .line 144
    .line 145
    .line 146
    :goto_4
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    if-eqz v0, :cond_7

    .line 151
    .line 152
    new-instance v6, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepErrorCard$2;

    .line 153
    .line 154
    move-object v8, v11

    .line 155
    move-object v9, v4

    .line 156
    move v10, v3

    .line 157
    move v11, v2

    .line 158
    move v12, v1

    .line 159
    move-object v7, v5

    .line 160
    invoke-direct/range {v6 .. v12}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepErrorCard$2;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;Lkotlin/jvm/functions/Function0;III)V

    .line 161
    .line 162
    .line 163
    iput-object v6, v0, LX/J7V;->A06:LX/JDN;

    .line 164
    .line 165
    :cond_7
    return-void

    .line 166
    :cond_8
    if-eqz v10, :cond_9

    .line 167
    .line 168
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 169
    .line 170
    :cond_9
    if-eqz v9, :cond_a

    .line 171
    .line 172
    move-object v4, p0

    .line 173
    :cond_a
    and-int/lit8 v0, p6, 0x8

    .line 174
    .line 175
    if-eqz v0, :cond_5

    .line 176
    .line 177
    const v3, 0x7f120097

    .line 178
    .line 179
    .line 180
    and-int/lit16 v7, v7, -0x1c01

    .line 181
    .line 182
    goto :goto_3

    .line 183
    :cond_b
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 184
    .line 185
    .line 186
    goto :goto_4

    .line 187
    :cond_c
    and-int/lit16 v0, v2, 0x180

    .line 188
    .line 189
    if-nez v0, :cond_1

    .line 190
    .line 191
    invoke-static {v6, v4}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    or-int/2addr v7, v0

    .line 196
    goto/16 :goto_2

    .line 197
    .line 198
    :cond_d
    and-int/lit8 v0, p5, 0x30

    .line 199
    .line 200
    if-nez v0, :cond_0

    .line 201
    .line 202
    invoke-static {v6, v11}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    or-int/2addr v7, v0

    .line 207
    goto/16 :goto_1

    .line 208
    .line 209
    :cond_e
    move v7, v2

    .line 210
    goto/16 :goto_0
.end method

.method public static final AgeStepMessage(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;LX/2d4;II)V
    .locals 41

    .line 0
    move-object/from16 v13, p0

    .line 1
    .line 2
    move-object/from16 v17, p1

    .line 3
    .line 4
    move-object/from16 v16, p2

    .line 5
    .line 6
    move-object/from16 v12, p4

    .line 7
    .line 8
    move-object/from16 v9, p5

    .line 9
    .line 10
    move-object/from16 v10, p6

    .line 11
    .line 12
    move/from16 v6, p3

    .line 13
    .line 14
    const v1, -0x271e63a0

    .line 15
    .line 16
    .line 17
    move-object/from16 v0, p7

    .line 18
    .line 19
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 20
    .line 21
    .line 22
    and-int/lit8 v15, p9, 0x1

    .line 23
    .line 24
    move/from16 v3, p8

    .line 25
    .line 26
    if-eqz v15, :cond_12

    .line 27
    .line 28
    or-int/lit8 v8, p8, 0x6

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v14, p9, 0x2

    .line 31
    .line 32
    if-eqz v14, :cond_11

    .line 33
    .line 34
    or-int/lit8 v8, v8, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v11, p9, 0x4

    .line 37
    .line 38
    if-eqz v11, :cond_10

    .line 39
    .line 40
    or-int/lit16 v8, v8, 0x180

    .line 41
    .line 42
    :cond_1
    :goto_2
    and-int/lit8 v2, p9, 0x8

    .line 43
    .line 44
    if-eqz v2, :cond_f

    .line 45
    .line 46
    or-int/lit16 v8, v8, 0xc00

    .line 47
    .line 48
    :cond_2
    :goto_3
    and-int/lit8 v7, p9, 0x10

    .line 49
    .line 50
    if-eqz v7, :cond_e

    .line 51
    .line 52
    or-int/lit16 v8, v8, 0x6000

    .line 53
    .line 54
    :cond_3
    :goto_4
    and-int/lit8 v5, p9, 0x20

    .line 55
    .line 56
    const/high16 v1, 0x30000

    .line 57
    .line 58
    if-nez v5, :cond_4

    .line 59
    .line 60
    and-int v1, p8, v1

    .line 61
    .line 62
    if-nez v1, :cond_5

    .line 63
    .line 64
    invoke-static {v0, v9}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    :cond_4
    or-int/2addr v8, v1

    .line 69
    :cond_5
    and-int/lit8 v4, p9, 0x40

    .line 70
    .line 71
    const/high16 v1, 0x180000

    .line 72
    .line 73
    if-nez v4, :cond_6

    .line 74
    .line 75
    and-int v1, p8, v1

    .line 76
    .line 77
    if-nez v1, :cond_7

    .line 78
    .line 79
    invoke-static {v0, v10}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    :cond_6
    or-int/2addr v8, v1

    .line 84
    :cond_7
    const v1, 0x92493

    .line 85
    .line 86
    .line 87
    invoke-static {v8, v1}, LX/005;->A1O(II)Z

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    invoke-static {v1, v0, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-eqz v1, :cond_14

    .line 96
    .line 97
    if-eqz v15, :cond_8

    .line 98
    .line 99
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 100
    .line 101
    :cond_8
    const/16 v21, 0x0

    .line 102
    .line 103
    if-eqz v14, :cond_9

    .line 104
    .line 105
    move-object/from16 v17, v21

    .line 106
    .line 107
    :cond_9
    if-eqz v11, :cond_a

    .line 108
    .line 109
    move-object/from16 v16, v21

    .line 110
    .line 111
    :cond_a
    invoke-static {v2, v6}, LX/001;->A1P(IZ)Z

    .line 112
    .line 113
    .line 114
    move-result v6

    .line 115
    if-eqz v7, :cond_b

    .line 116
    .line 117
    move-object/from16 v12, v21

    .line 118
    .line 119
    :cond_b
    if-eqz v5, :cond_c

    .line 120
    .line 121
    move-object/from16 v9, v21

    .line 122
    .line 123
    :cond_c
    if-nez v4, :cond_d

    .line 124
    .line 125
    move-object/from16 v21, v10

    .line 126
    .line 127
    :cond_d
    invoke-static {v13}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 128
    .line 129
    .line 130
    move-result-object v4

    .line 131
    sget v2, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 132
    .line 133
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 134
    .line 135
    invoke-static {v4, v2, v1}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 136
    .line 137
    .line 138
    move-result-object v4

    .line 139
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 140
    .line 141
    invoke-static {v1}, LX/Dn6;->A00(F)LX/CP5;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    sget-object v1, LX/2Id;->A00:LX/2sS;

    .line 146
    .line 147
    const/16 v15, 0x30

    .line 148
    .line 149
    invoke-static {v2, v0, v1, v15}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 150
    .line 151
    .line 152
    move-result-object v11

    .line 153
    move-object v2, v0

    .line 154
    check-cast v2, LX/J7I;

    .line 155
    .line 156
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 157
    .line 158
    .line 159
    move-result v10

    .line 160
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 161
    .line 162
    .line 163
    move-result-object v7

    .line 164
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 165
    .line 166
    .line 167
    move-result-object v5

    .line 168
    sget-object v4, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 169
    .line 170
    iget-object v1, v2, LX/J7I;->A0V:LX/3DJ;

    .line 171
    .line 172
    if-nez v1, :cond_15

    .line 173
    .line 174
    invoke-static {}, LX/1VY;->A00()V

    .line 175
    .line 176
    .line 177
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    throw v0

    .line 182
    :cond_e
    and-int/lit16 v1, v3, 0x6000

    .line 183
    .line 184
    if-nez v1, :cond_3

    .line 185
    .line 186
    invoke-static {v0, v12}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 187
    .line 188
    .line 189
    move-result v1

    .line 190
    or-int/2addr v8, v1

    .line 191
    goto/16 :goto_4

    .line 192
    .line 193
    :cond_f
    and-int/lit16 v1, v3, 0xc00

    .line 194
    .line 195
    if-nez v1, :cond_2

    .line 196
    .line 197
    invoke-static {v0, v6}, LX/004;->A0l(LX/2d4;Z)I

    .line 198
    .line 199
    .line 200
    move-result v1

    .line 201
    or-int/2addr v8, v1

    .line 202
    goto/16 :goto_3

    .line 203
    .line 204
    :cond_10
    and-int/lit16 v1, v3, 0x180

    .line 205
    .line 206
    if-nez v1, :cond_1

    .line 207
    .line 208
    move-object/from16 v1, v16

    .line 209
    .line 210
    invoke-static {v0, v1}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    or-int/2addr v8, v1

    .line 215
    goto/16 :goto_2

    .line 216
    .line 217
    :cond_11
    and-int/lit8 v1, p8, 0x30

    .line 218
    .line 219
    if-nez v1, :cond_0

    .line 220
    .line 221
    move-object/from16 v1, v17

    .line 222
    .line 223
    invoke-static {v0, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    or-int/2addr v8, v1

    .line 228
    goto/16 :goto_1

    .line 229
    .line 230
    :cond_12
    and-int/lit8 v1, p8, 0x6

    .line 231
    .line 232
    if-nez v1, :cond_13

    .line 233
    .line 234
    invoke-static {v0, v13}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 235
    .line 236
    .line 237
    move-result v8

    .line 238
    or-int v8, v8, p8

    .line 239
    .line 240
    goto/16 :goto_0

    .line 241
    .line 242
    :cond_13
    move v8, v3

    .line 243
    goto/16 :goto_0

    .line 244
    .line 245
    :cond_14
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 246
    .line 247
    .line 248
    goto :goto_8

    .line 249
    :cond_15
    invoke-static {v0, v2, v4}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 250
    .line 251
    .line 252
    invoke-static {v0, v11, v7, v5, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 253
    .line 254
    .line 255
    sget-object v10, LX/CgJ;->A00:LX/CgJ;

    .line 256
    .line 257
    if-eqz v6, :cond_1b

    .line 258
    .line 259
    const v1, -0x1b54a97f

    .line 260
    .line 261
    .line 262
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 263
    .line 264
    .line 265
    const v1, 0x7f1202bb

    .line 266
    .line 267
    .line 268
    const/4 v7, 0x0

    .line 269
    invoke-static {v0, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object v11

    .line 273
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 274
    .line 275
    const/4 v14, 0x0

    .line 276
    const/high16 v1, 0x3f800000    # 1.0f

    .line 277
    .line 278
    const/4 v4, 0x1

    .line 279
    invoke-virtual {v10, v5, v1, v4}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 284
    .line 285
    invoke-interface {v1, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 286
    .line 287
    .line 288
    move-result-object v1

    .line 289
    invoke-static {v1, v7}, LX/001;->A0b(LX/3C1;Z)LX/3C1;

    .line 290
    .line 291
    .line 292
    move-result-object v10

    .line 293
    invoke-interface {v0, v11}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    move-result v8

    .line 297
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    if-nez v8, :cond_16

    .line 302
    .line 303
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 304
    .line 305
    if-ne v1, v8, :cond_17

    .line 306
    .line 307
    :cond_16
    new-instance v1, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$1$1$1;

    .line 308
    .line 309
    invoke-direct {v1, v11}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$1$1$1;-><init>(Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 313
    .line 314
    .line 315
    :cond_17
    invoke-static {v10, v1, v7}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 316
    .line 317
    .line 318
    move-result-object v22

    .line 319
    const-wide/16 v24, 0x0

    .line 320
    .line 321
    const/16 v28, 0x6

    .line 322
    .line 323
    move-object/from16 v23, v14

    .line 324
    .line 325
    move-object/from16 v26, v0

    .line 326
    .line 327
    move/from16 v27, v7

    .line 328
    .line 329
    invoke-static/range {v22 .. v28}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerKt;->AuraSpinner-FNF3uiM(LX/3C1;Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;JLX/2d4;II)V

    .line 330
    .line 331
    .line 332
    const/4 v1, 0x0

    .line 333
    invoke-static {v2, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 334
    .line 335
    .line 336
    move-object/from16 v10, v21

    .line 337
    .line 338
    :goto_5
    if-nez v12, :cond_1a

    .line 339
    .line 340
    const v7, -0x1b47656d

    .line 341
    .line 342
    .line 343
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 344
    .line 345
    .line 346
    :goto_6
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 347
    .line 348
    .line 349
    if-nez v9, :cond_19

    .line 350
    .line 351
    const v5, -0x1b44a61d

    .line 352
    .line 353
    .line 354
    invoke-interface {v0, v5}, LX/2d4;->Agj(I)V

    .line 355
    .line 356
    .line 357
    :goto_7
    invoke-static {v2, v13, v1, v4}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 358
    .line 359
    .line 360
    move-result-object v13

    .line 361
    :goto_8
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 362
    .line 363
    .line 364
    move-result-object v1

    .line 365
    if-eqz v1, :cond_18

    .line 366
    .line 367
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$2;

    .line 368
    .line 369
    move-object/from16 p3, v16

    .line 370
    .line 371
    move/from16 p4, v6

    .line 372
    .line 373
    move-object/from16 p5, v12

    .line 374
    .line 375
    move-object/from16 p6, v9

    .line 376
    .line 377
    move-object/from16 p7, v10

    .line 378
    .line 379
    move/from16 p8, v3

    .line 380
    .line 381
    move-object/from16 p0, v0

    .line 382
    .line 383
    move-object/from16 p1, v13

    .line 384
    .line 385
    move-object/from16 p2, v17

    .line 386
    .line 387
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$2;-><init>(LX/3C1;Ljava/lang/Integer;Ljava/lang/Integer;ZLcom/facebook/aura/activation/ageverification/AgeStepAction;Lcom/facebook/aura/activation/ageverification/AgeStepAction;Ljava/lang/Integer;II)V

    .line 388
    .line 389
    .line 390
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 391
    .line 392
    :cond_18
    return-void

    .line 393
    :cond_19
    const v7, -0x1b44a61c

    .line 394
    .line 395
    .line 396
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 397
    .line 398
    .line 399
    iget v7, v9, Lcom/facebook/aura/activation/ageverification/AgeStepAction;->textRes:I

    .line 400
    .line 401
    invoke-static {v0, v7}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v19

    .line 405
    sget-object v7, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 406
    .line 407
    invoke-virtual {v7, v14, v0, v15, v4}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 408
    .line 409
    .line 410
    move-result-object v22

    .line 411
    iget-object v7, v9, Lcom/facebook/aura/activation/ageverification/AgeStepAction;->onClick:Lkotlin/jvm/functions/Function0;

    .line 412
    .line 413
    const p8, 0x7ffbfe5

    .line 414
    .line 415
    .line 416
    const/16 p5, 0xc00

    .line 417
    .line 418
    move-object/from16 v20, v14

    .line 419
    .line 420
    move-object/from16 v23, v14

    .line 421
    .line 422
    move-object/from16 v24, v14

    .line 423
    .line 424
    move/from16 v25, v1

    .line 425
    .line 426
    move/from16 v26, v1

    .line 427
    .line 428
    move/from16 v28, v1

    .line 429
    .line 430
    move/from16 v29, v1

    .line 431
    .line 432
    move-object/from16 v30, v14

    .line 433
    .line 434
    move-object/from16 v31, v14

    .line 435
    .line 436
    move-object/from16 v32, v7

    .line 437
    .line 438
    move-object/from16 v33, v14

    .line 439
    .line 440
    move-object/from16 v34, v14

    .line 441
    .line 442
    move-object/from16 v35, v14

    .line 443
    .line 444
    move-object/from16 v36, v14

    .line 445
    .line 446
    move-object/from16 v37, v14

    .line 447
    .line 448
    move-object/from16 v38, v14

    .line 449
    .line 450
    move-object/from16 v39, v14

    .line 451
    .line 452
    move-object/from16 v40, v14

    .line 453
    .line 454
    move/from16 p0, v1

    .line 455
    .line 456
    move/from16 p1, v1

    .line 457
    .line 458
    move/from16 p2, v1

    .line 459
    .line 460
    move/from16 p3, v1

    .line 461
    .line 462
    move-object/from16 p4, v0

    .line 463
    .line 464
    move/from16 p6, v1

    .line 465
    .line 466
    move/from16 p7, v1

    .line 467
    .line 468
    move-object/from16 v21, v5

    .line 469
    .line 470
    move-object/from16 v18, v14

    .line 471
    .line 472
    invoke-static/range {v18 .. v49}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 473
    .line 474
    .line 475
    goto :goto_7

    .line 476
    :cond_1a
    const v7, -0x1b47656c

    .line 477
    .line 478
    .line 479
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 480
    .line 481
    .line 482
    iget v7, v12, Lcom/facebook/aura/activation/ageverification/AgeStepAction;->textRes:I

    .line 483
    .line 484
    invoke-static {v0, v7}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 485
    .line 486
    .line 487
    move-result-object v19

    .line 488
    iget-object v7, v12, Lcom/facebook/aura/activation/ageverification/AgeStepAction;->onClick:Lkotlin/jvm/functions/Function0;

    .line 489
    .line 490
    const p8, 0x7ffbff5

    .line 491
    .line 492
    .line 493
    const/16 p5, 0xc00

    .line 494
    .line 495
    move-object/from16 v18, v14

    .line 496
    .line 497
    move-object/from16 v20, v14

    .line 498
    .line 499
    move-object/from16 v21, v5

    .line 500
    .line 501
    move-object/from16 v22, v14

    .line 502
    .line 503
    move-object/from16 v23, v14

    .line 504
    .line 505
    move-object/from16 v24, v14

    .line 506
    .line 507
    move/from16 v25, v1

    .line 508
    .line 509
    move/from16 v26, v1

    .line 510
    .line 511
    move/from16 v28, v1

    .line 512
    .line 513
    move/from16 v29, v1

    .line 514
    .line 515
    move-object/from16 v30, v14

    .line 516
    .line 517
    move-object/from16 v31, v14

    .line 518
    .line 519
    move-object/from16 v32, v7

    .line 520
    .line 521
    move-object/from16 v33, v14

    .line 522
    .line 523
    move-object/from16 v34, v14

    .line 524
    .line 525
    move-object/from16 v35, v14

    .line 526
    .line 527
    move-object/from16 v36, v14

    .line 528
    .line 529
    move-object/from16 v37, v14

    .line 530
    .line 531
    move-object/from16 v38, v14

    .line 532
    .line 533
    move-object/from16 v39, v14

    .line 534
    .line 535
    move-object/from16 v40, v14

    .line 536
    .line 537
    move/from16 p0, v1

    .line 538
    .line 539
    move/from16 p1, v1

    .line 540
    .line 541
    move/from16 p2, v1

    .line 542
    .line 543
    move/from16 p3, v1

    .line 544
    .line 545
    move-object/from16 p4, v0

    .line 546
    .line 547
    move/from16 p6, v1

    .line 548
    .line 549
    move/from16 p7, v1

    .line 550
    .line 551
    invoke-static/range {v18 .. v49}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 552
    .line 553
    .line 554
    goto/16 :goto_6

    .line 555
    .line 556
    :cond_1b
    const v1, -0x1b50348d

    .line 557
    .line 558
    .line 559
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 560
    .line 561
    .line 562
    if-nez v17, :cond_1e

    .line 563
    .line 564
    const v1, -0x1b4fb967

    .line 565
    .line 566
    .line 567
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 568
    .line 569
    .line 570
    const/4 v1, 0x0

    .line 571
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 572
    .line 573
    .line 574
    const/16 v18, 0x0

    .line 575
    .line 576
    :goto_9
    if-nez v16, :cond_1d

    .line 577
    .line 578
    const v4, -0x1b4ed8a7

    .line 579
    .line 580
    .line 581
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 582
    .line 583
    .line 584
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 585
    .line 586
    .line 587
    const/16 v19, 0x0

    .line 588
    .line 589
    :goto_a
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 590
    .line 591
    const/4 v14, 0x0

    .line 592
    const/high16 v5, 0x3f800000    # 1.0f

    .line 593
    .line 594
    const/4 v4, 0x1

    .line 595
    invoke-virtual {v10, v7, v5, v4}, LX/CgJ;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 596
    .line 597
    .line 598
    move-result-object v7

    .line 599
    sget-object v5, LX/2sI;->A02:LX/2wD;

    .line 600
    .line 601
    invoke-interface {v7, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 602
    .line 603
    .line 604
    move-result-object v11

    .line 605
    const v10, -0x41666666    # -0.3f

    .line 606
    .line 607
    .line 608
    new-instance v7, LX/2If;

    .line 609
    .line 610
    invoke-direct {v7, v10}, LX/2If;-><init>(F)V

    .line 611
    .line 612
    .line 613
    invoke-static {v7, v11, v1}, LX/2sI;->A01(LX/2rU;LX/3C1;Z)LX/3C1;

    .line 614
    .line 615
    .line 616
    move-result-object v7

    .line 617
    invoke-static {v0, v7}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 618
    .line 619
    .line 620
    move-result-object v11

    .line 621
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 622
    .line 623
    .line 624
    move-result-object v10

    .line 625
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 626
    .line 627
    if-ne v10, v7, :cond_1c

    .line 628
    .line 629
    sget-object v10, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$1$4$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepMessage$1$4$1;

    .line 630
    .line 631
    invoke-interface {v0, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 632
    .line 633
    .line 634
    :cond_1c
    invoke-static {v11, v10, v1}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 635
    .line 636
    .line 637
    move-result-object v20

    .line 638
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 639
    .line 640
    invoke-static {v0, v7}, LX/07H;->A02(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 641
    .line 642
    .line 643
    move-result-wide v22

    .line 644
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 645
    .line 646
    invoke-static {v7, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 647
    .line 648
    .line 649
    move-result-object v7

    .line 650
    check-cast v7, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 651
    .line 652
    iget-object v10, v7, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Medium:LX/2hg;

    .line 653
    .line 654
    shr-int/lit8 v7, v8, 0x9

    .line 655
    .line 656
    and-int/lit16 v7, v7, 0x1c00

    .line 657
    .line 658
    move-object/from16 v24, v10

    .line 659
    .line 660
    move-object/from16 v25, v0

    .line 661
    .line 662
    move/from16 v26, v7

    .line 663
    .line 664
    move/from16 v27, v1

    .line 665
    .line 666
    invoke-static/range {v18 .. v27}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepText-FHprtrg(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;LX/2d4;II)V

    .line 667
    .line 668
    .line 669
    move-object/from16 v10, v21

    .line 670
    .line 671
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 672
    .line 673
    .line 674
    goto/16 :goto_5

    .line 675
    .line 676
    :cond_1d
    const v5, -0x1b4ed8a6

    .line 677
    .line 678
    .line 679
    move-object/from16 v4, v16

    .line 680
    .line 681
    invoke-static {v0, v4, v5}, LX/18b;->A07(LX/2d4;Ljava/lang/Number;I)Ljava/lang/String;

    .line 682
    .line 683
    .line 684
    move-result-object v19

    .line 685
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 686
    .line 687
    .line 688
    goto :goto_a

    .line 689
    :cond_1e
    const v1, -0x1b4fb966

    .line 690
    .line 691
    .line 692
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 693
    .line 694
    .line 695
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 696
    .line 697
    .line 698
    move-result v1

    .line 699
    const/4 v4, 0x0

    .line 700
    invoke-static {v0, v1}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 701
    .line 702
    .line 703
    move-result-object v18

    .line 704
    const/4 v1, 0x0

    .line 705
    invoke-static {v2, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 706
    .line 707
    .line 708
    goto/16 :goto_9
.end method

.method public static final AgeStepText-FHprtrg(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;LX/2d4;II)V
    .locals 30

    .line 0
    move-object/from16 v3, p2

    .line 1
    .line 2
    move-object/from16 v17, p3

    .line 3
    .line 4
    move-wide/from16 v9, p4

    .line 5
    .line 6
    move-object/from16 v15, p6

    .line 7
    .line 8
    const v1, 0x585295d

    .line 9
    .line 10
    .line 11
    move-object/from16 v0, p7

    .line 12
    .line 13
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p8

    .line 17
    .line 18
    and-int/lit8 v1, p8, 0x6

    .line 19
    .line 20
    move-object/from16 v19, p0

    .line 21
    .line 22
    if-nez v1, :cond_12

    .line 23
    .line 24
    move-object/from16 v1, v19

    .line 25
    .line 26
    invoke-static {v0, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    or-int v6, v6, p8

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v1, p8, 0x30

    .line 33
    .line 34
    move-object/from16 v18, p1

    .line 35
    .line 36
    if-nez v1, :cond_0

    .line 37
    .line 38
    move-object/from16 v1, v18

    .line 39
    .line 40
    invoke-static {v0, v1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    or-int/2addr v6, v1

    .line 45
    :cond_0
    and-int/lit8 v12, p9, 0x4

    .line 46
    .line 47
    if-eqz v12, :cond_11

    .line 48
    .line 49
    or-int/lit16 v6, v6, 0x180

    .line 50
    .line 51
    :cond_1
    :goto_1
    and-int/lit8 v11, p9, 0x8

    .line 52
    .line 53
    if-eqz v11, :cond_10

    .line 54
    .line 55
    or-int/lit16 v6, v6, 0xc00

    .line 56
    .line 57
    :cond_2
    :goto_2
    and-int/lit16 v1, v2, 0x6000

    .line 58
    .line 59
    if-nez v1, :cond_5

    .line 60
    .line 61
    and-int/lit8 v1, p9, 0x10

    .line 62
    .line 63
    if-nez v1, :cond_3

    .line 64
    .line 65
    invoke-interface {v0, v9, v10}, LX/2d4;->A68(J)Z

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    const/16 v1, 0x4000

    .line 70
    .line 71
    if-nez v4, :cond_4

    .line 72
    .line 73
    :cond_3
    const/16 v1, 0x2000

    .line 74
    .line 75
    :cond_4
    or-int/2addr v6, v1

    .line 76
    :cond_5
    const/high16 v1, 0x30000

    .line 77
    .line 78
    and-int v1, v1, p8

    .line 79
    .line 80
    if-nez v1, :cond_8

    .line 81
    .line 82
    and-int/lit8 v1, p9, 0x20

    .line 83
    .line 84
    if-nez v1, :cond_6

    .line 85
    .line 86
    invoke-interface {v0, v15}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    const/high16 v1, 0x20000

    .line 91
    .line 92
    if-nez v4, :cond_7

    .line 93
    .line 94
    :cond_6
    const/high16 v1, 0x10000

    .line 95
    .line 96
    :cond_7
    or-int/2addr v6, v1

    .line 97
    :cond_8
    const v4, 0x12493

    .line 98
    .line 99
    .line 100
    and-int/2addr v4, v6

    .line 101
    const v1, 0x12492

    .line 102
    .line 103
    .line 104
    const/4 v5, 0x1

    .line 105
    invoke-static {v4, v1}, LX/003;->A1H(II)Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    invoke-static {v1, v0, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    if-eqz v1, :cond_13

    .line 114
    .line 115
    invoke-interface {v0}, LX/2d4;->AgT()V

    .line 116
    .line 117
    .line 118
    and-int/lit8 v1, p8, 0x1

    .line 119
    .line 120
    const v8, -0xe001

    .line 121
    .line 122
    .line 123
    const v7, -0x70001

    .line 124
    .line 125
    .line 126
    const/4 v4, 0x0

    .line 127
    const/16 v16, 0x6

    .line 128
    .line 129
    if-eqz v1, :cond_c

    .line 130
    .line 131
    invoke-interface {v0}, LX/2d4;->AEs()Z

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    if-nez v1, :cond_c

    .line 136
    .line 137
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 138
    .line 139
    .line 140
    and-int/lit8 v1, p9, 0x10

    .line 141
    .line 142
    if-eqz v1, :cond_9

    .line 143
    .line 144
    and-int/2addr v6, v8

    .line 145
    :cond_9
    and-int/lit8 v1, p9, 0x20

    .line 146
    .line 147
    if-eqz v1, :cond_a

    .line 148
    .line 149
    :goto_3
    and-int/2addr v6, v7

    .line 150
    :cond_a
    invoke-interface {v0}, LX/2d4;->AAf()V

    .line 151
    .line 152
    .line 153
    invoke-static {v3}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 162
    .line 163
    if-ne v1, v8, :cond_b

    .line 164
    .line 165
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$1$1;

    .line 166
    .line 167
    invoke-interface {v0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    :cond_b
    invoke-static {v4, v1, v5}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 171
    .line 172
    .line 173
    move-result-object v4

    .line 174
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 175
    .line 176
    invoke-static {v1}, LX/Dn6;->A00(F)LX/CP5;

    .line 177
    .line 178
    .line 179
    move-result-object v7

    .line 180
    sget-object v1, LX/2Id;->A00:LX/2sS;

    .line 181
    .line 182
    invoke-static {v7, v0, v1}, LX/002;->A0d(LX/Dps;LX/2d4;LX/2sS;)LX/3BI;

    .line 183
    .line 184
    .line 185
    move-result-object v14

    .line 186
    move-object v1, v0

    .line 187
    check-cast v1, LX/J7I;

    .line 188
    .line 189
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 190
    .line 191
    .line 192
    move-result v13

    .line 193
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 194
    .line 195
    .line 196
    move-result-object v12

    .line 197
    invoke-static {v0, v4}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 198
    .line 199
    .line 200
    move-result-object v11

    .line 201
    sget-object v7, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 202
    .line 203
    iget-object v4, v1, LX/J7I;->A0V:LX/3DJ;

    .line 204
    .line 205
    if-nez v4, :cond_14

    .line 206
    .line 207
    invoke-static {}, LX/1VY;->A00()V

    .line 208
    .line 209
    .line 210
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    throw v0

    .line 215
    :cond_c
    if-eqz v12, :cond_d

    .line 216
    .line 217
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 218
    .line 219
    :cond_d
    if-eqz v11, :cond_e

    .line 220
    .line 221
    move-object/from16 v17, v4

    .line 222
    .line 223
    :cond_e
    and-int/lit8 v1, p9, 0x10

    .line 224
    .line 225
    if-eqz v1, :cond_f

    .line 226
    .line 227
    invoke-static {v0}, LX/001;->A0k(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    iget-wide v9, v1, Lcom/facebook/aura/vds/compose/theme/AuraColors;->success:J

    .line 232
    .line 233
    and-int/2addr v6, v8

    .line 234
    :cond_f
    and-int/lit8 v1, p9, 0x20

    .line 235
    .line 236
    if-eqz v1, :cond_a

    .line 237
    .line 238
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 239
    .line 240
    invoke-static {v1, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v1

    .line 244
    check-cast v1, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 245
    .line 246
    iget-object v15, v1, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 247
    .line 248
    goto :goto_3

    .line 249
    :cond_10
    and-int/lit16 v1, v2, 0xc00

    .line 250
    .line 251
    if-nez v1, :cond_2

    .line 252
    .line 253
    move-object/from16 v1, v17

    .line 254
    .line 255
    invoke-static {v0, v1}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 256
    .line 257
    .line 258
    move-result v1

    .line 259
    or-int/2addr v6, v1

    .line 260
    goto/16 :goto_2

    .line 261
    .line 262
    :cond_11
    and-int/lit16 v1, v2, 0x180

    .line 263
    .line 264
    if-nez v1, :cond_1

    .line 265
    .line 266
    invoke-static {v0, v3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 267
    .line 268
    .line 269
    move-result v1

    .line 270
    or-int/2addr v6, v1

    .line 271
    goto/16 :goto_1

    .line 272
    .line 273
    :cond_12
    move v6, v2

    .line 274
    goto/16 :goto_0

    .line 275
    .line 276
    :cond_13
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 277
    .line 278
    .line 279
    goto :goto_7

    .line 280
    :cond_14
    invoke-static {v0, v1, v7}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 281
    .line 282
    .line 283
    invoke-static {v0, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 284
    .line 285
    .line 286
    if-nez v17, :cond_19

    .line 287
    .line 288
    const v4, -0x2a0b0da2

    .line 289
    .line 290
    .line 291
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 292
    .line 293
    .line 294
    const/4 v4, 0x0

    .line 295
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 296
    .line 297
    .line 298
    :goto_4
    if-nez p0, :cond_17

    .line 299
    .line 300
    const v6, -0x2a08a6d7

    .line 301
    .line 302
    .line 303
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 304
    .line 305
    .line 306
    :goto_5
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 307
    .line 308
    .line 309
    if-nez v18, :cond_16

    .line 310
    .line 311
    const v6, -0x2a050898

    .line 312
    .line 313
    .line 314
    invoke-interface {v0, v6}, LX/2d4;->Agj(I)V

    .line 315
    .line 316
    .line 317
    :goto_6
    invoke-static {v1, v3, v4, v5}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 318
    .line 319
    .line 320
    move-result-object v3

    .line 321
    :goto_7
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    if-eqz v1, :cond_15

    .line 326
    .line 327
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;

    .line 328
    .line 329
    move-object/from16 p0, v0

    .line 330
    .line 331
    move-object/from16 p1, v19

    .line 332
    .line 333
    move-object/from16 p2, v18

    .line 334
    .line 335
    move-object/from16 p3, v3

    .line 336
    .line 337
    move-object/from16 p4, v17

    .line 338
    .line 339
    move-wide/from16 p5, v9

    .line 340
    .line 341
    move-object/from16 p7, v15

    .line 342
    .line 343
    move/from16 p8, v2

    .line 344
    .line 345
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;-><init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;II)V

    .line 346
    .line 347
    .line 348
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 349
    .line 350
    :cond_15
    return-void

    .line 351
    :cond_16
    const v6, -0x2a050897

    .line 352
    .line 353
    .line 354
    invoke-static {v0, v6}, LX/001;->A0l(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 355
    .line 356
    .line 357
    move-result-object v6

    .line 358
    invoke-static {v0, v6}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 359
    .line 360
    .line 361
    move-result-object v24

    .line 362
    invoke-static {v0, v6}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 363
    .line 364
    .line 365
    move-result-wide v22

    .line 366
    invoke-static {}, LX/2wS;->A00()LX/2wS;

    .line 367
    .line 368
    .line 369
    move-result-object v27

    .line 370
    const/16 p8, 0x3fb2

    .line 371
    .line 372
    const/16 v21, 0x0

    .line 373
    .line 374
    move-object/from16 v25, v21

    .line 375
    .line 376
    move-object/from16 v26, v21

    .line 377
    .line 378
    move/from16 v28, v4

    .line 379
    .line 380
    move/from16 v29, v4

    .line 381
    .line 382
    move/from16 p0, v4

    .line 383
    .line 384
    move/from16 p1, v4

    .line 385
    .line 386
    move-object/from16 p2, v21

    .line 387
    .line 388
    move-object/from16 p3, v21

    .line 389
    .line 390
    move-object/from16 p4, v21

    .line 391
    .line 392
    move-object/from16 p5, v0

    .line 393
    .line 394
    move/from16 p6, v4

    .line 395
    .line 396
    move/from16 p7, v4

    .line 397
    .line 398
    move-object/from16 v20, v18

    .line 399
    .line 400
    invoke-static/range {v20 .. v38}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 401
    .line 402
    .line 403
    goto :goto_6

    .line 404
    :cond_17
    const v7, -0x2a08a6d6

    .line 405
    .line 406
    .line 407
    invoke-static {v0, v7}, LX/003;->A0c(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 408
    .line 409
    .line 410
    move-result-object v7

    .line 411
    iget-wide v11, v7, Lcom/facebook/aura/vds/compose/theme/AuraColors;->primaryText:J

    .line 412
    .line 413
    const/4 v14, 0x3

    .line 414
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 415
    .line 416
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 417
    .line 418
    .line 419
    move-result-object v7

    .line 420
    if-ne v7, v8, :cond_18

    .line 421
    .line 422
    sget-object v7, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$2$2$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$2$2$1$1;

    .line 423
    .line 424
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    :cond_18
    check-cast v7, LX/JDM;

    .line 428
    .line 429
    const/16 v24, 0x0

    .line 430
    .line 431
    invoke-static {v13, v7, v4}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 432
    .line 433
    .line 434
    move-result-object v20

    .line 435
    invoke-static {v14}, LX/2wS;->A01(I)LX/2wS;

    .line 436
    .line 437
    .line 438
    move-result-object v26

    .line 439
    shr-int v6, v6, v16

    .line 440
    .line 441
    and-int/lit16 v6, v6, 0x1c00

    .line 442
    .line 443
    const/16 p7, 0x3fb0

    .line 444
    .line 445
    move-wide/from16 v21, v11

    .line 446
    .line 447
    move-object/from16 v23, v15

    .line 448
    .line 449
    move-object/from16 v25, v24

    .line 450
    .line 451
    move/from16 v27, v4

    .line 452
    .line 453
    move/from16 v28, v4

    .line 454
    .line 455
    move/from16 v29, v4

    .line 456
    .line 457
    move/from16 p0, v4

    .line 458
    .line 459
    move-object/from16 p1, v24

    .line 460
    .line 461
    move-object/from16 p2, v24

    .line 462
    .line 463
    move-object/from16 p3, v24

    .line 464
    .line 465
    move-object/from16 p4, v0

    .line 466
    .line 467
    move/from16 p5, v6

    .line 468
    .line 469
    move/from16 p6, v4

    .line 470
    .line 471
    invoke-static/range {v19 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 472
    .line 473
    .line 474
    goto/16 :goto_5

    .line 475
    .line 476
    :cond_19
    const v4, -0x2a0b0da1

    .line 477
    .line 478
    .line 479
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 480
    .line 481
    .line 482
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 483
    .line 484
    .line 485
    move-result v4

    .line 486
    const/4 v7, 0x0

    .line 487
    invoke-static {v0, v4, v7}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 488
    .line 489
    .line 490
    move-result-object v21

    .line 491
    sget-object v22, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->LARGE:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 492
    .line 493
    invoke-static {}, LX/2l9;->A03()I

    .line 494
    .line 495
    .line 496
    move-result v4

    .line 497
    invoke-static {v6, v4}, LX/002;->A08(II)I

    .line 498
    .line 499
    .line 500
    move-result v28

    .line 501
    const/16 v29, 0x29

    .line 502
    .line 503
    const/16 v20, 0x0

    .line 504
    .line 505
    move-object/from16 v23, v20

    .line 506
    .line 507
    move-wide/from16 v24, v9

    .line 508
    .line 509
    move-object/from16 v26, v20

    .line 510
    .line 511
    move-object/from16 v27, v0

    .line 512
    .line 513
    invoke-static/range {v20 .. v29}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 514
    .line 515
    .line 516
    const/4 v4, 0x0

    .line 517
    invoke-static {v1, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 518
    .line 519
    .line 520
    goto/16 :goto_4
.end method
