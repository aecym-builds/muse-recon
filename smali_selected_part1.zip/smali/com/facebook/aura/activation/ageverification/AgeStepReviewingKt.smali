.class public abstract Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgeStepReviewing(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;",
            "LX/3C1;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object v4, p3

    .line 1
    move-object v1, p1

    .line 2
    move v0, p2

    .line 3
    const/4 p3, 0x0

    .line 4
    move-object v3, p0

    .line 5
    invoke-static {p0, p3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v2, -0x1aaca1ea

    .line 9
    .line 10
    .line 11
    move-object/from16 p2, p4

    .line 12
    .line 13
    invoke-interface {p2, v2}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p5

    .line 17
    .line 18
    and-int/lit8 v5, p5, 0x6

    .line 19
    .line 20
    if-nez v5, :cond_b

    .line 21
    .line 22
    invoke-static {p2, p0}, LX/005;->A09(LX/2d4;Ljava/lang/Enum;)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    or-int v6, v6, p5

    .line 27
    .line 28
    :goto_0
    move/from16 p5, p6

    .line 29
    .line 30
    and-int/lit8 v9, p6, 0x2

    .line 31
    .line 32
    if-eqz v9, :cond_a

    .line 33
    .line 34
    or-int/lit8 v6, v6, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v7, p6, 0x4

    .line 37
    .line 38
    if-eqz v7, :cond_9

    .line 39
    .line 40
    or-int/lit16 v6, v6, 0x180

    .line 41
    .line 42
    :cond_1
    :goto_2
    and-int/lit8 v8, p6, 0x8

    .line 43
    .line 44
    if-eqz v8, :cond_8

    .line 45
    .line 46
    or-int/lit16 v6, v6, 0xc00

    .line 47
    .line 48
    :cond_2
    :goto_3
    invoke-static {v6}, LX/005;->A1K(I)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    invoke-static {v5, p2, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_7

    .line 57
    .line 58
    if-eqz v9, :cond_3

    .line 59
    .line 60
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 61
    .line 62
    :cond_3
    invoke-static {v7, v0}, LX/001;->A1P(IZ)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v8, :cond_4

    .line 67
    .line 68
    const/4 v4, 0x0

    .line 69
    :cond_4
    sget-object v5, Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;->ID:Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;

    .line 70
    .line 71
    if-ne p0, v5, :cond_6

    .line 72
    .line 73
    const v5, -0x1f6ad551

    .line 74
    .line 75
    .line 76
    invoke-interface {p2, v5}, LX/2d4;->Agj(I)V

    .line 77
    .line 78
    .line 79
    shr-int/lit8 v5, v6, 0x6

    .line 80
    .line 81
    and-int/lit8 v9, v5, 0x7e

    .line 82
    .line 83
    shl-int/lit8 v5, v6, 0x3

    .line 84
    .line 85
    and-int/lit16 v5, v5, 0x380

    .line 86
    .line 87
    or-int/2addr v9, v5

    .line 88
    move v5, v0

    .line 89
    move-object v6, v4

    .line 90
    move-object v7, v1

    .line 91
    move-object v8, p2

    .line 92
    move v10, p3

    .line 93
    invoke-static/range {v5 .. v10}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->IdReviewing(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 94
    .line 95
    .line 96
    :goto_4
    invoke-static {p2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :goto_5
    invoke-interface {p2}, LX/2d4;->AAg()LX/J7V;

    .line 100
    .line 101
    .line 102
    move-result-object v5

    .line 103
    if-eqz v5, :cond_5

    .line 104
    .line 105
    new-instance v11, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;

    .line 106
    .line 107
    move/from16 p4, v2

    .line 108
    .line 109
    move-object p3, v4

    .line 110
    move p2, v0

    .line 111
    move-object p1, v1

    .line 112
    move-object p0, v3

    .line 113
    invoke-direct/range {v11 .. v17}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$AgeStepReviewing$1;-><init>(Lcom/facebook/aura/activation/ageverification/intf/AgeVerificationMethod;LX/3C1;ZLkotlin/jvm/functions/Function0;II)V

    .line 114
    .line 115
    .line 116
    iput-object v11, v5, LX/J7V;->A06:LX/JDN;

    .line 117
    .line 118
    :cond_5
    return-void

    .line 119
    :cond_6
    const v5, -0x1f699ed5

    .line 120
    .line 121
    .line 122
    invoke-interface {p2, v5}, LX/2d4;->Agj(I)V

    .line 123
    .line 124
    .line 125
    const v5, 0x7f1200a1

    .line 126
    .line 127
    .line 128
    invoke-static {p2, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    const v5, 0x7f1200a0

    .line 133
    .line 134
    .line 135
    invoke-static {p2, v5}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v8

    .line 139
    invoke-static {p2}, LX/007;->A0j(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 140
    .line 141
    .line 142
    move-result-object v5

    .line 143
    iget-object p1, v5, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 144
    .line 145
    shr-int/lit8 v5, v6, 0x3

    .line 146
    .line 147
    and-int/lit8 v5, v5, 0xe

    .line 148
    .line 149
    invoke-static {v1, p2, v5}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->reviewingText(LX/3C1;LX/2d4;I)LX/3C1;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    const/16 p4, 0x18

    .line 154
    .line 155
    const/4 v10, 0x0

    .line 156
    const-wide/16 v11, 0x0

    .line 157
    .line 158
    invoke-static/range {v7 .. v16}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepText-FHprtrg(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;LX/2d4;II)V

    .line 159
    .line 160
    .line 161
    goto :goto_4

    .line 162
    :cond_7
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 163
    .line 164
    .line 165
    goto :goto_5

    .line 166
    :cond_8
    and-int/lit16 v5, v2, 0xc00

    .line 167
    .line 168
    if-nez v5, :cond_2

    .line 169
    .line 170
    invoke-static {p2, v4}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 171
    .line 172
    .line 173
    move-result v5

    .line 174
    or-int/2addr v6, v5

    .line 175
    goto :goto_3

    .line 176
    :cond_9
    and-int/lit16 v5, v2, 0x180

    .line 177
    .line 178
    if-nez v5, :cond_1

    .line 179
    .line 180
    invoke-static {p2, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 181
    .line 182
    .line 183
    move-result v5

    .line 184
    or-int/2addr v6, v5

    .line 185
    goto/16 :goto_2

    .line 186
    .line 187
    :cond_a
    and-int/lit8 v5, v2, 0x30

    .line 188
    .line 189
    if-nez v5, :cond_0

    .line 190
    .line 191
    invoke-static {p2, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 192
    .line 193
    .line 194
    move-result v5

    .line 195
    or-int/2addr v6, v5

    .line 196
    goto/16 :goto_1

    .line 197
    .line 198
    :cond_b
    move v6, v2

    .line 199
    goto/16 :goto_0
.end method

.method public static final IdReviewing(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    const v0, 0x78d8ae6b

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p3

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p4

    .line 11
    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    move/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_4

    .line 17
    .line 18
    invoke-static {v3, v7}, LX/004;->A0i(LX/2d4;Z)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    or-int v6, v6, p4

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 25
    .line 26
    move-object/from16 v8, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v3, v8}, LX/004;->A0Q(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v6, v0

    .line 35
    :cond_0
    and-int/lit8 v10, p5, 0x4

    .line 36
    .line 37
    if-eqz v10, :cond_3

    .line 38
    .line 39
    or-int/lit16 v6, v6, 0x180

    .line 40
    .line 41
    :cond_1
    :goto_1
    and-int/lit16 v9, v6, 0x93

    .line 42
    .line 43
    const/16 v0, 0x92

    .line 44
    .line 45
    const/4 v5, 0x1

    .line 46
    const/4 v1, 0x0

    .line 47
    invoke-static {v9, v0}, LX/003;->A1H(II)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0, v3, v6}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_5

    .line 56
    .line 57
    if-eqz v10, :cond_2

    .line 58
    .line 59
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 60
    .line 61
    :cond_2
    invoke-static {v4}, LX/001;->A0X(LX/3C1;)LX/3C1;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    invoke-static {v3}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 66
    .line 67
    .line 68
    move-result-object v14

    .line 69
    move-object v0, v3

    .line 70
    check-cast v0, LX/J7I;

    .line 71
    .line 72
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 73
    .line 74
    .line 75
    move-result v13

    .line 76
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 77
    .line 78
    .line 79
    move-result-object v12

    .line 80
    invoke-static {v3, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v11

    .line 84
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 85
    .line 86
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 87
    .line 88
    if-nez v9, :cond_6

    .line 89
    .line 90
    invoke-static {}, LX/1VY;->A00()V

    .line 91
    .line 92
    .line 93
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    throw v0

    .line 98
    :cond_3
    and-int/lit16 v0, v2, 0x180

    .line 99
    .line 100
    if-nez v0, :cond_1

    .line 101
    .line 102
    invoke-static {v3, v4}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    or-int/2addr v6, v0

    .line 107
    goto :goto_1

    .line 108
    :cond_4
    move v6, v2

    .line 109
    goto :goto_0

    .line 110
    :cond_5
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 111
    .line 112
    .line 113
    goto/16 :goto_4

    .line 114
    .line 115
    :cond_6
    invoke-static {v3, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 116
    .line 117
    .line 118
    invoke-static {v3, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 119
    .line 120
    .line 121
    sget-object v10, LX/CgJ;->A00:LX/CgJ;

    .line 122
    .line 123
    const v9, 0x7f120068

    .line 124
    .line 125
    .line 126
    invoke-static {v3, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v12

    .line 130
    if-eqz p0, :cond_9

    .line 131
    .line 132
    const v9, -0x644aafd3    # -2.999575E-22f

    .line 133
    .line 134
    .line 135
    invoke-interface {v3, v9}, LX/2d4;->Agj(I)V

    .line 136
    .line 137
    .line 138
    const v9, 0x7f120085

    .line 139
    .line 140
    .line 141
    invoke-static {v3, v9}, LX/18b;->A04(LX/2d4;I)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v13

    .line 145
    :goto_2
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 146
    .line 147
    .line 148
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 149
    .line 150
    const/4 v11, 0x0

    .line 151
    invoke-static {v10, v9, v5}, LX/002;->A0X(LX/CgJ;LX/3C1;Z)LX/3C1;

    .line 152
    .line 153
    .line 154
    move-result-object v9

    .line 155
    invoke-static {v9, v3, v1}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->reviewingText(LX/3C1;LX/2d4;I)LX/3C1;

    .line 156
    .line 157
    .line 158
    move-result-object v14

    .line 159
    const/16 v19, 0x18

    .line 160
    .line 161
    move-object v15, v11

    .line 162
    move-object/from16 v16, v11

    .line 163
    .line 164
    move-object/from16 v17, v3

    .line 165
    .line 166
    move/from16 v18, v1

    .line 167
    .line 168
    invoke-static/range {v12 .. v19}, Lcom/facebook/aura/activation/ageverification/IdStepLayoutKt;->IdStepHeader(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V

    .line 169
    .line 170
    .line 171
    if-eqz p0, :cond_8

    .line 172
    .line 173
    if-eqz p1, :cond_8

    .line 174
    .line 175
    const v9, -0x64458c62

    .line 176
    .line 177
    .line 178
    invoke-interface {v3, v9}, LX/2d4;->Agj(I)V

    .line 179
    .line 180
    .line 181
    const v9, 0x7f1200a2

    .line 182
    .line 183
    .line 184
    invoke-static {v3, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v12

    .line 188
    invoke-static {v3}, LX/007;->A0h(LX/2d4;)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 189
    .line 190
    .line 191
    move-result-object v15

    .line 192
    sget-object v10, LX/2sI;->A02:LX/2wD;

    .line 193
    .line 194
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 195
    .line 196
    invoke-static {v10, v9}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 197
    .line 198
    .line 199
    move-result-object v14

    .line 200
    shl-int/lit8 p2, v6, 0x9

    .line 201
    .line 202
    const v6, 0xe000

    .line 203
    .line 204
    .line 205
    and-int p2, p2, v6

    .line 206
    .line 207
    const p4, 0x7ffbfe5

    .line 208
    .line 209
    .line 210
    move-object v13, v11

    .line 211
    move-object/from16 v17, v11

    .line 212
    .line 213
    move/from16 v19, v1

    .line 214
    .line 215
    move/from16 v20, v1

    .line 216
    .line 217
    move/from16 v21, v1

    .line 218
    .line 219
    move/from16 v22, v1

    .line 220
    .line 221
    move-object/from16 v23, v11

    .line 222
    .line 223
    move-object/from16 v24, v11

    .line 224
    .line 225
    move-object/from16 v25, v8

    .line 226
    .line 227
    move-object/from16 v26, v11

    .line 228
    .line 229
    move-object/from16 v27, v11

    .line 230
    .line 231
    move-object/from16 v28, v11

    .line 232
    .line 233
    move-object/from16 v29, v11

    .line 234
    .line 235
    move-object/from16 v30, v11

    .line 236
    .line 237
    move-object/from16 v31, v11

    .line 238
    .line 239
    move-object/from16 v32, v11

    .line 240
    .line 241
    move-object/from16 v33, v11

    .line 242
    .line 243
    move/from16 v34, v1

    .line 244
    .line 245
    move/from16 v35, v1

    .line 246
    .line 247
    move/from16 v36, v1

    .line 248
    .line 249
    move/from16 v37, v1

    .line 250
    .line 251
    move-object/from16 p0, v3

    .line 252
    .line 253
    move/from16 p1, v1

    .line 254
    .line 255
    move/from16 p3, v1

    .line 256
    .line 257
    invoke-static/range {v11 .. v42}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 258
    .line 259
    .line 260
    :goto_3
    invoke-static {v0, v4, v1, v5}, LX/006;->A0Y(LX/J7I;LX/3C1;ZZ)LX/3C1;

    .line 261
    .line 262
    .line 263
    move-result-object v4

    .line 264
    :goto_4
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    if-eqz v1, :cond_7

    .line 269
    .line 270
    new-instance v0, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$IdReviewing$2;

    .line 271
    .line 272
    move-object/from16 p0, v0

    .line 273
    .line 274
    move/from16 p1, v7

    .line 275
    .line 276
    move-object/from16 p2, v8

    .line 277
    .line 278
    move-object/from16 p3, v4

    .line 279
    .line 280
    move/from16 p4, v2

    .line 281
    .line 282
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$IdReviewing$2;-><init>(ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 283
    .line 284
    .line 285
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 286
    .line 287
    :cond_7
    return-void

    .line 288
    :cond_8
    const v6, -0x6441a8df

    .line 289
    .line 290
    .line 291
    invoke-interface {v3, v6}, LX/2d4;->Agj(I)V

    .line 292
    .line 293
    .line 294
    goto :goto_3

    .line 295
    :cond_9
    const v9, -0x6448d9dc

    .line 296
    .line 297
    .line 298
    invoke-interface {v3, v9}, LX/2d4;->Agj(I)V

    .line 299
    .line 300
    .line 301
    const v9, 0x7f120067

    .line 302
    .line 303
    .line 304
    invoke-static {v3, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 305
    .line 306
    .line 307
    move-result-object v13

    .line 308
    goto/16 :goto_2
.end method

.method public static final synthetic access$IdReviewing(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt;->IdReviewing(ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final reviewingText(LX/3C1;LX/2d4;I)LX/3C1;
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, p0}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 6
    .line 7
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-interface {p1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 16
    .line 17
    if-ne v1, v0, :cond_0

    .line 18
    .line 19
    sget-object v1, Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$reviewingText$1$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/AgeStepReviewingKt$reviewingText$1$1;

    .line 20
    .line 21
    invoke-interface {p1, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-static {v2, v1, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0
.end method
