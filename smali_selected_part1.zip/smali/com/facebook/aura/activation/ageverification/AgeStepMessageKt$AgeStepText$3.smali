.class public final Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $body:Ljava/lang/String;

.field public final synthetic $iconRes:Ljava/lang/Integer;

.field public final synthetic $iconTint:J

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $title:Ljava/lang/String;

.field public final synthetic $titleStyle:LX/2hg;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;II)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$body:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$modifier:LX/3C1;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$iconRes:Ljava/lang/Integer;

    .line 7
    .line 8
    iput-wide p5, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$iconTint:J

    .line 9
    .line 10
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$titleStyle:LX/2hg;

    .line 11
    .line 12
    iput p8, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$$changed:I

    .line 13
    .line 14
    iput p9, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$$default:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 10

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$body:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$modifier:LX/3C1;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$iconRes:Ljava/lang/Integer;

    .line 7
    .line 8
    iget-wide v5, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$iconTint:J

    .line 9
    .line 10
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$titleStyle:LX/2hg;

    .line 11
    .line 12
    iget v0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$$changed:I

    .line 13
    .line 14
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 15
    .line 16
    .line 17
    move-result v9

    .line 18
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt$AgeStepText$3;->$$default:I

    .line 19
    .line 20
    move-object v8, p1

    .line 21
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/activation/ageverification/AgeStepMessageKt;->AgeStepText-FHprtrg(Ljava/lang/String;Ljava/lang/String;LX/3C1;Ljava/lang/Integer;JLX/2hg;LX/2d4;II)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
