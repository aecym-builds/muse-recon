.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieCircleKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final SelfieCircle(LX/3dS;LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3dS;",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/33K;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    const/4 v5, 0x0

    .line 1
    invoke-static {p0, v5, p2}, LX/003;->A0x(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const v0, 0x3b6aafdf

    .line 5
    .line 6
    .line 7
    move-object v4, p3

    .line 8
    invoke-interface {p3, v0}, LX/2d4;->Agl(I)V

    .line 9
    .line 10
    .line 11
    move p3, p4

    .line 12
    and-int/lit8 v0, p4, 0x6

    .line 13
    .line 14
    if-nez v0, :cond_4

    .line 15
    .line 16
    invoke-static {v4, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v7

    .line 20
    or-int/2addr v7, p4

    .line 21
    :goto_0
    move p4, p5

    .line 22
    and-int/lit8 v2, p5, 0x1

    .line 23
    .line 24
    if-eqz v2, :cond_3

    .line 25
    .line 26
    or-int/lit8 v7, v7, 0x30

    .line 27
    .line 28
    :cond_0
    :goto_1
    and-int/lit16 v0, p3, 0x180

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    invoke-static {v4, p2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v7, v0

    .line 37
    :cond_1
    and-int/lit16 v1, v7, 0x93

    .line 38
    .line 39
    const/16 v0, 0x92

    .line 40
    .line 41
    const/4 v6, 0x1

    .line 42
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-static {v0, v4, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_6

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    sget-object p1, LX/3C1;->A00:LX/3Cb;

    .line 55
    .line 56
    :cond_2
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXlarge:F

    .line 57
    .line 58
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 59
    .line 60
    add-float/2addr v1, v0

    .line 61
    invoke-static {p1, v1}, LX/2pj;->A04(LX/3C1;F)LX/3C1;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    const/high16 v8, 0x3f800000    # 1.0f

    .line 66
    .line 67
    invoke-interface {p0, v0, v8, v5}, LX/3dS;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const v0, 0x3f570a3d    # 0.84f

    .line 72
    .line 73
    .line 74
    invoke-static {v1, v0}, LX/2sI;->A03(LX/3C1;F)LX/3C1;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    const/4 v3, 0x3

    .line 79
    sget-object v2, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 80
    .line 81
    invoke-static {v2, v0, v5}, LX/2sI;->A02(Landroidx/compose/ui/Alignment;LX/3C1;Z)LX/3C1;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-static {v0, v8, v6}, LX/7b5;->A00(LX/3C1;FZ)LX/3C1;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    shl-int/2addr v7, v3

    .line 90
    and-int/lit16 v0, v7, 0x1c00

    .line 91
    .line 92
    or-int/lit8 v9, v0, 0x30

    .line 93
    .line 94
    invoke-static {v2, v5}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 95
    .line 96
    .line 97
    move-result-object v8

    .line 98
    move-object v5, v4

    .line 99
    check-cast v5, LX/J7I;

    .line 100
    .line 101
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 102
    .line 103
    .line 104
    move-result v7

    .line 105
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    invoke-static {v4, v1}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 114
    .line 115
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 116
    .line 117
    if-nez v0, :cond_5

    .line 118
    .line 119
    invoke-static {}, LX/1VY;->A00()V

    .line 120
    .line 121
    .line 122
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    throw v0

    .line 127
    :cond_3
    and-int/lit8 v0, p3, 0x30

    .line 128
    .line 129
    if-nez v0, :cond_0

    .line 130
    .line 131
    invoke-static {v4, p1}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    or-int/2addr v7, v0

    .line 136
    goto :goto_1

    .line 137
    :cond_4
    move v7, p4

    .line 138
    goto :goto_0

    .line 139
    :cond_5
    invoke-static {v4, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 140
    .line 141
    .line 142
    invoke-static {v4, v8, v3, v2, v7}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 143
    .line 144
    .line 145
    sget-object v1, LX/3Jn;->A00:LX/3Jn;

    .line 146
    .line 147
    shr-int/lit8 v0, v9, 0x6

    .line 148
    .line 149
    and-int/lit8 v0, v0, 0x70

    .line 150
    .line 151
    or-int/lit8 v0, v0, 0x6

    .line 152
    .line 153
    invoke-static {v1, v4, p2, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 154
    .line 155
    .line 156
    invoke-static {v5, v6}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 157
    .line 158
    .line 159
    goto :goto_2

    .line 160
    :cond_6
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 161
    .line 162
    .line 163
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    if-eqz v0, :cond_7

    .line 168
    .line 169
    new-instance v9, Lcom/facebook/aura/activation/ageverification/SelfieCircleKt$SelfieCircle$1;

    .line 170
    .line 171
    invoke-direct/range {v9 .. v14}, Lcom/facebook/aura/activation/ageverification/SelfieCircleKt$SelfieCircle$1;-><init>(LX/3dS;LX/3C1;LX/JDQ;II)V

    .line 172
    .line 173
    .line 174
    iput-object v9, v0, LX/J7V;->A06:LX/JDN;

    .line 175
    .line 176
    :cond_7
    return-void
.end method
