.class public final Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final iconRes:I

.field public final namesApp:Z

.field public final textRes:I


# direct methods
.method public constructor <init>(IIZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput p1, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->iconRes:I

    .line 4
    .line 5
    iput p2, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->textRes:I

    .line 6
    .line 7
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->namesApp:Z

    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(IIZILX/04f;)V
    .locals 1

    .line 268435456
    invoke-static {p4, p3}, LX/006;->A1X(IZ)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-direct {p0, p1, p2, v0}, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;-><init>(IIZ)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method


# virtual methods
.method public final getIconRes()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->iconRes:I

    .line 1
    .line 2
    return p0
.end method

.method public final getNamesApp()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->namesApp:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getTextRes()I
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/ageverification/AgeStepInfoRow;->textRes:I

    .line 1
    .line 2
    return p0
.end method
