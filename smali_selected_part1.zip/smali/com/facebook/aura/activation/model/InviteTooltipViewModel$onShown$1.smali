.class public final Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.InviteTooltipViewModel$onShown$1"
    f = "InviteTooltipViewModel.kt"
    l = {
        0x26
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $seconds:I

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;


# direct methods
.method public constructor <init>(ILcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/facebook/aura/activation/model/InviteTooltipViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->$seconds:I

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->$seconds:I

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;-><init>(ILcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v4, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->dismiss()V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object v0

    .line 20
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->$seconds:I

    .line 24
    .line 25
    int-to-long v2, v0

    .line 26
    const-wide/16 v0, 0x3e8

    .line 27
    .line 28
    mul-long/2addr v2, v0

    .line 29
    iput v4, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;->label:I

    .line 30
    .line 31
    invoke-static {v2, v3, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-ne v0, v5, :cond_0

    .line 36
    .line 37
    return-object v5

    .line 38
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    throw v0
.end method
