.class public final Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.InviteTooltipViewModel$1"
    f = "InviteTooltipViewModel.kt"
    l = {
        0x19
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/InviteTooltipViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    if-eq v0, v3, :cond_1

    .line 8
    .line 9
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    throw v0

    .line 14
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 18
    .line 19
    iget-object v0, v2, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 20
    .line 21
    iget-object v1, v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->seen:LX/2J3;

    .line 22
    .line 23
    new-instance v0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;

    .line 24
    .line 25
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;)V

    .line 26
    .line 27
    .line 28
    iput v3, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;->label:I

    .line 29
    .line 30
    invoke-interface {v1, v0, p0}, LX/2QV;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-ne v0, v4, :cond_2

    .line 35
    .line 36
    return-object v4

    .line 37
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_2
    invoke-static {}, LX/001;->A19()Lkotlin/KotlinNothingValueException;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    throw v0
.end method
