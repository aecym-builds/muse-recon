.class public interface abstract Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$ViewEffect;
.super Ljava/lang/Object;
.source ""
