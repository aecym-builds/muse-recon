.class public final Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0, p2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;->emit(ZLX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    return-object v0
.end method

.method public final emit(ZLX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1$1;->this$0:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->onHidden()V

    .line 5
    .line 6
    .line 7
    :cond_0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object p0
.end method
