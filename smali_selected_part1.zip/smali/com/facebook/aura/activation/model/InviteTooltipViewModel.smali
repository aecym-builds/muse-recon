.class public final Lcom/facebook/aura/activation/model/InviteTooltipViewModel;
.super LX/1EJ;
.source ""


# instance fields
.field public final _visible:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public dismissJob:LX/Cbu;

.field public final repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

.field public final visible:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/repo/InviteTooltipRepository;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 8
    .line 9
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    new-instance v1, LX/Ddv;

    .line 14
    .line 15
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iput-object v1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->_visible:LX/2J2;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    new-instance v0, LX/ERk;

    .line 22
    .line 23
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->visible:LX/2J3;

    .line 27
    .line 28
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    new-instance v0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;

    .line 33
    .line 34
    invoke-direct {v0, p0, v2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V

    .line 35
    .line 36
    .line 37
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public static final synthetic access$getRepository$p(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;)Lcom/facebook/aura/activation/repo/InviteTooltipRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 1
    .line 2
    return-object p0
.end method


# virtual methods
.method public final dismiss()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->_visible:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->markSeen()V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->onHidden()V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final getVisible()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->visible:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final onHidden()V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->dismissJob:LX/Cbu;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0, v2}, LX/Cbu;->A5z(Ljava/util/concurrent/CancellationException;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    iput-object v2, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->dismissJob:LX/Cbu;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->_visible:LX/2J2;

    .line 11
    .line 12
    invoke-static {}, LX/002;->A0i()Ljava/lang/Boolean;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v1, v2, v0}, LX/001;->A1N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final onShown(Z)V
    .locals 4

    .line 0
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->onHidden()V

    .line 1
    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->repository:Lcom/facebook/aura/activation/repo/InviteTooltipRepository;

    .line 6
    .line 7
    iget-object v0, v0, Lcom/facebook/aura/activation/repo/InviteTooltipRepository;->seen:LX/2J3;

    .line 8
    .line 9
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    sget-object v0, Lcom/facebook/aura/utils/HatchUtils;->INSTANCE:Lcom/facebook/aura/utils/HatchUtils;

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtils;->getInviteButtonToolTipSecs()I

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    if-lez v3, :cond_0

    .line 26
    .line 27
    iget-object v1, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->_visible:LX/2J2;

    .line 28
    .line 29
    invoke-static {}, LX/002;->A0j()Ljava/lang/Boolean;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v1, LX/Ddv;

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    invoke-static {v2, v0, v1}, LX/Ddv;->A00(Ljava/lang/Object;Ljava/lang/Object;LX/Ddv;)Z

    .line 37
    .line 38
    .line 39
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    new-instance v0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;

    .line 44
    .line 45
    invoke-direct {v0, v3, p0, v2}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$onShown$1;-><init>(ILcom/facebook/aura/activation/model/InviteTooltipViewModel;LX/2M4;)V

    .line 46
    .line 47
    .line 48
    invoke-static {v0, v1}, LX/006;->A1I(LX/JDN;LX/1EL;)LX/ESp;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, p0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->dismissJob:LX/Cbu;

    .line 53
    .line 54
    :cond_0
    return-void
.end method
