.class public interface abstract Lcom/facebook/aura/activation/model/AuraNdaViewModel$ViewEffect;
.super Ljava/lang/Object;
.source ""
