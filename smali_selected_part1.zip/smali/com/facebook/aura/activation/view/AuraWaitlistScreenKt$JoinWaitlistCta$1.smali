.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "Ljava/lang/Boolean;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $isAlreadyJoined:Z

.field public final synthetic $isJoiningWaitlist:Z

.field public final synthetic $joinWaitlistLabel:Ljava/lang/String;

.field public final synthetic $joinedLabel:Ljava/lang/String;

.field public final synthetic $onClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$joinedLabel:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$joinWaitlistLabel:Ljava/lang/String;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$isAlreadyJoined:Z

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$isJoiningWaitlist:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$onClick:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    const/4 v0, 0x3

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    check-cast p2, LX/2d4;

    .line 268435461
    .line 268435462
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435463
    .line 268435464
    .line 268435465
    move-result v0

    .line 268435466
    invoke-virtual {p0, v1, p2, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->invoke(ZLX/2d4;I)V

    .line 268435467
    .line 268435468
    .line 268435469
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435470
    .line 268435471
    return-object v0
.end method

.method public final invoke(ZLX/2d4;I)V
    .locals 33

    .line 0
    move/from16 v1, p3

    .line 1
    .line 2
    and-int/lit8 v0, p3, 0x6

    .line 3
    .line 4
    move/from16 v2, p1

    .line 5
    .line 6
    move-object/from16 v3, p2

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-static {v3, v2}, LX/004;->A0i(LX/2d4;Z)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    or-int v1, p3, v0

    .line 15
    .line 16
    :cond_0
    invoke-static {v1}, LX/005;->A1G(I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_6

    .line 25
    .line 26
    move-object/from16 v4, p0

    .line 27
    .line 28
    if-eqz p1, :cond_5

    .line 29
    .line 30
    iget-object v6, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$joinedLabel:Ljava/lang/String;

    .line 31
    .line 32
    :goto_0
    sget-object v10, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->MEDIUM:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 33
    .line 34
    iget-boolean v1, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$isAlreadyJoined:Z

    .line 35
    .line 36
    xor-int/lit8 v14, v1, 0x1

    .line 37
    .line 38
    iget-boolean v0, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$isJoiningWaitlist:Z

    .line 39
    .line 40
    if-eqz v0, :cond_1

    .line 41
    .line 42
    const/4 v15, 0x1

    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    :cond_1
    const/4 v15, 0x0

    .line 46
    :cond_2
    const/4 v5, 0x0

    .line 47
    sget-object v8, LX/2sI;->A02:LX/2wD;

    .line 48
    .line 49
    iget-object v0, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$onClick:Lkotlin/jvm/functions/Function0;

    .line 50
    .line 51
    invoke-interface {v3, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    iget-object v2, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$onClick:Lkotlin/jvm/functions/Function0;

    .line 56
    .line 57
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-nez v1, :cond_3

    .line 62
    .line 63
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v0, v1, :cond_4

    .line 66
    .line 67
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1$1$1;

    .line 68
    .line 69
    invoke-direct {v0, v2}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_4
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 76
    .line 77
    const/4 v12, 0x0

    .line 78
    const p3, 0x7ffb9d5

    .line 79
    .line 80
    .line 81
    const p0, 0x30c00

    .line 82
    .line 83
    .line 84
    move-object v7, v5

    .line 85
    move-object v9, v5

    .line 86
    move-object v11, v5

    .line 87
    move v13, v12

    .line 88
    move/from16 v16, v12

    .line 89
    .line 90
    move-object/from16 v17, v5

    .line 91
    .line 92
    move-object/from16 v18, v5

    .line 93
    .line 94
    move-object/from16 v19, v0

    .line 95
    .line 96
    move-object/from16 v20, v5

    .line 97
    .line 98
    move-object/from16 v21, v5

    .line 99
    .line 100
    move-object/from16 v22, v5

    .line 101
    .line 102
    move-object/from16 v23, v5

    .line 103
    .line 104
    move-object/from16 v24, v5

    .line 105
    .line 106
    move-object/from16 v25, v5

    .line 107
    .line 108
    move-object/from16 v26, v5

    .line 109
    .line 110
    move-object/from16 v27, v5

    .line 111
    .line 112
    move/from16 v28, v12

    .line 113
    .line 114
    move/from16 v29, v12

    .line 115
    .line 116
    move/from16 v30, v12

    .line 117
    .line 118
    move/from16 v31, v12

    .line 119
    .line 120
    move-object/from16 v32, v3

    .line 121
    .line 122
    move/from16 p1, v12

    .line 123
    .line 124
    move/from16 p2, v12

    .line 125
    .line 126
    invoke-static/range {v5 .. v36}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :cond_5
    iget-object v6, v4, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$JoinWaitlistCta$1;->$joinWaitlistLabel:Ljava/lang/String;

    .line 131
    .line 132
    goto :goto_0

    .line 133
    :cond_6
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 134
    .line 135
    .line 136
    return-void
.end method
