.class public abstract Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AuraDisclosureInfoSheet(LX/3C1;LX/2d4;II)V
    .locals 24

    .line 0
    move-object/from16 v12, p0

    .line 1
    .line 2
    const v0, 0x4669da76

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p1

    .line 6
    .line 7
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v1, p3, 0x1

    .line 13
    .line 14
    move/from16 v3, p2

    .line 15
    .line 16
    if-eqz v1, :cond_6

    .line 17
    .line 18
    or-int/lit8 v8, p2, 0x6

    .line 19
    .line 20
    :goto_0
    invoke-static {v8}, LX/004;->A1R(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0, v4, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_5

    .line 29
    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 33
    .line 34
    :cond_0
    sget-object v0, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 35
    .line 36
    move-object v9, v4

    .line 37
    check-cast v9, LX/J7I;

    .line 38
    .line 39
    invoke-static {v0, v9}, LX/004;->A16(LX/Iow;LX/J7I;)LX/AHE;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sget-object v0, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 44
    .line 45
    invoke-static {v0, v9}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 46
    .line 47
    .line 48
    move-result-object v7

    .line 49
    new-instance v10, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;

    .line 50
    .line 51
    invoke-direct {v10, v1}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;-><init>(LX/AHE;)V

    .line 52
    .line 53
    .line 54
    invoke-static {v9}, LX/005;->A0V(LX/J7I;)Landroidx/activity/ComponentActivity;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    invoke-static {v6}, LX/004;->A14(LX/15O;)LX/13i;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    const-class v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 63
    .line 64
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    const/4 v5, 0x0

    .line 69
    const/4 v11, 0x0

    .line 70
    invoke-static {v10, v6, v1, v0}, LX/13Z;->A00(LX/15L;LX/13Z;LX/13i;LX/DVF;)LX/1EJ;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 75
    .line 76
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->uiState:LX/2J3;

    .line 77
    .line 78
    invoke-static {v4, v0, v5}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-interface {v0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    check-cast v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 87
    .line 88
    iget-object v6, v0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 89
    .line 90
    if-nez v6, :cond_4

    .line 91
    .line 92
    const v0, 0x184b5d4f

    .line 93
    .line 94
    .line 95
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 96
    .line 97
    .line 98
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 99
    .line 100
    invoke-interface {v4, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    if-nez v1, :cond_1

    .line 109
    .line 110
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 111
    .line 112
    if-ne v0, v1, :cond_2

    .line 113
    .line 114
    :cond_1
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;

    .line 115
    .line 116
    invoke-direct {v0, v7}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;-><init>(Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {v4, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :cond_2
    invoke-static {v4, v0, v5}, LX/001;->A1G(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-static {v4, v9}, LX/002;->A0V(LX/2d4;LX/J7I;)LX/J7V;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    if-eqz v1, :cond_3

    .line 130
    .line 131
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$2;

    .line 132
    .line 133
    invoke-direct {v0, v12, v3, v2}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$2;-><init>(LX/3C1;II)V

    .line 134
    .line 135
    .line 136
    :goto_1
    invoke-static {v1, v0}, LX/001;->A1K(LX/J7V;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    :cond_3
    return-void

    .line 140
    :cond_4
    const v0, 0x184d328c

    .line 141
    .line 142
    .line 143
    invoke-interface {v4, v0}, LX/2d4;->Agj(I)V

    .line 144
    .line 145
    .line 146
    invoke-static {v9, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 147
    .line 148
    .line 149
    new-instance v1, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;

    .line 150
    .line 151
    invoke-direct {v1, v6, v7}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 152
    .line 153
    .line 154
    const v0, 0x6a180baf

    .line 155
    .line 156
    .line 157
    invoke-static {v4, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 158
    .line 159
    .line 160
    move-result-object v15

    .line 161
    new-instance v1, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;

    .line 162
    .line 163
    invoke-direct {v1, v6}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;)V

    .line 164
    .line 165
    .line 166
    const v0, -0x7747b10c

    .line 167
    .line 168
    .line 169
    invoke-static {v4, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 170
    .line 171
    .line 172
    move-result-object v23

    .line 173
    shl-int/lit8 v0, v8, 0x3

    .line 174
    .line 175
    and-int/lit8 v0, v0, 0x70

    .line 176
    .line 177
    or-int/lit16 v0, v0, 0x6000

    .line 178
    .line 179
    const/16 p2, 0x180

    .line 180
    .line 181
    const/16 p3, 0xfed

    .line 182
    .line 183
    move-object v13, v11

    .line 184
    move-object v14, v11

    .line 185
    move-object/from16 v16, v11

    .line 186
    .line 187
    move-object/from16 v17, v11

    .line 188
    .line 189
    move/from16 v19, v5

    .line 190
    .line 191
    move/from16 v20, v5

    .line 192
    .line 193
    move-object/from16 v21, v11

    .line 194
    .line 195
    move-object/from16 v22, v11

    .line 196
    .line 197
    move-object/from16 p0, v4

    .line 198
    .line 199
    move/from16 p1, v0

    .line 200
    .line 201
    move/from16 v18, v5

    .line 202
    .line 203
    invoke-static/range {v11 .. v27}, Lcom/facebook/aura/vds/compose/bottomsheet/AuraBottomSheetContentKt;->AuraBottomSheetContent--luiLJQ(Lcom/facebook/aura/vds/compose/theme/AuraContainer$AuraBottomSheet;LX/3C1;LX/3Lr;Lcom/facebook/aura/vds/compose/bottomsheet/model/AuraBottomSheetHeaderConfig;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;ZZZLcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/1Ot;LX/JDQ;LX/2d4;III)V

    .line 204
    .line 205
    .line 206
    goto :goto_2

    .line 207
    :cond_5
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 208
    .line 209
    .line 210
    :goto_2
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    if-eqz v1, :cond_3

    .line 215
    .line 216
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$5;

    .line 217
    .line 218
    invoke-direct {v0, v12, v3, v2}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$5;-><init>(LX/3C1;II)V

    .line 219
    .line 220
    .line 221
    goto :goto_1

    .line 222
    :cond_6
    and-int/lit8 v0, p2, 0x6

    .line 223
    .line 224
    if-nez v0, :cond_7

    .line 225
    .line 226
    invoke-static {v4, v12}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 227
    .line 228
    .line 229
    move-result v8

    .line 230
    or-int v8, v8, p2

    .line 231
    .line 232
    goto/16 :goto_0

    .line 233
    .line 234
    :cond_7
    move v8, v3

    .line 235
    goto/16 :goto_0
.end method

.method public static final AuraDisclosureInfoSheet$lambda$0(LX/16A;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final InfoSheetSectionContent(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;LX/3C1;LX/2d4;II)V
    .locals 25

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    const v0, 0x5ecb5c44

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v1, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v3, p0

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    invoke-static {v2, v3}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v9

    .line 22
    or-int v9, v9, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v6, p4

    .line 25
    .line 26
    and-int/lit8 v8, p4, 0x2

    .line 27
    .line 28
    if-eqz v8, :cond_2

    .line 29
    .line 30
    or-int/lit8 v9, v9, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v7, v9, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v2, v9}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_6

    .line 46
    .line 47
    if-eqz v8, :cond_1

    .line 48
    .line 49
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 50
    .line 51
    :cond_1
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 52
    .line 53
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    const/16 v16, 0x0

    .line 58
    .line 59
    invoke-static {v5}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 60
    .line 61
    .line 62
    move-result-object v7

    .line 63
    invoke-static {v0, v2, v4}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 64
    .line 65
    .line 66
    move-result-object v12

    .line 67
    move-object v0, v2

    .line 68
    check-cast v0, LX/J7I;

    .line 69
    .line 70
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 71
    .line 72
    .line 73
    move-result v11

    .line 74
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 75
    .line 76
    .line 77
    move-result-object v10

    .line 78
    invoke-static {v2, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 79
    .line 80
    .line 81
    move-result-object v9

    .line 82
    sget-object v8, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 83
    .line 84
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 85
    .line 86
    if-nez v7, :cond_4

    .line 87
    .line 88
    invoke-static {}, LX/1VY;->A00()V

    .line 89
    .line 90
    .line 91
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    throw v0

    .line 96
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 97
    .line 98
    if-nez v0, :cond_0

    .line 99
    .line 100
    invoke-static {v2, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    or-int/2addr v9, v0

    .line 105
    goto :goto_1

    .line 106
    :cond_3
    move v9, v1

    .line 107
    goto :goto_0

    .line 108
    :cond_4
    invoke-static {v2, v0, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 109
    .line 110
    .line 111
    invoke-static {v2, v12, v10, v9, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 112
    .line 113
    .line 114
    iget-object v11, v3, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;->title:Ljava/lang/String;

    .line 115
    .line 116
    sget-object v7, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 117
    .line 118
    invoke-static {v2, v7}, LX/07H;->A0M(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 119
    .line 120
    .line 121
    move-result-object v15

    .line 122
    invoke-static {v2, v7}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 123
    .line 124
    .line 125
    move-result-wide v13

    .line 126
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 127
    .line 128
    invoke-interface {v2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v9

    .line 132
    sget-object v8, LX/2d6;->A00:Ljava/lang/Object;

    .line 133
    .line 134
    if-ne v9, v8, :cond_5

    .line 135
    .line 136
    sget-object v9, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$InfoSheetSectionContent$1$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$InfoSheetSectionContent$1$1$1;

    .line 137
    .line 138
    invoke-interface {v2, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    :cond_5
    invoke-static {v10, v9, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 142
    .line 143
    .line 144
    move-result-object v12

    .line 145
    const/16 p4, 0x3ff0

    .line 146
    .line 147
    move-object/from16 v17, v16

    .line 148
    .line 149
    move-object/from16 v18, v16

    .line 150
    .line 151
    move/from16 v20, v4

    .line 152
    .line 153
    move/from16 v21, v4

    .line 154
    .line 155
    move/from16 v22, v4

    .line 156
    .line 157
    move-object/from16 v23, v16

    .line 158
    .line 159
    move-object/from16 v24, v16

    .line 160
    .line 161
    move-object/from16 p0, v16

    .line 162
    .line 163
    move-object/from16 p1, v2

    .line 164
    .line 165
    move/from16 p2, v4

    .line 166
    .line 167
    move/from16 p3, v4

    .line 168
    .line 169
    move/from16 v19, v4

    .line 170
    .line 171
    invoke-static/range {v11 .. v29}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 172
    .line 173
    .line 174
    iget-object v8, v3, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;->body:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;

    .line 175
    .line 176
    iget-object v9, v8, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;->text:Ljava/lang/String;

    .line 177
    .line 178
    iget-object v8, v8, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$SubscriptionLegalText;->links:LX/Ddn;

    .line 179
    .line 180
    sget-object v10, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 181
    .line 182
    invoke-static {v10, v2}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v10

    .line 186
    check-cast v10, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 187
    .line 188
    invoke-virtual {v10}, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->getSubheadlineCompactRegular()LX/2hg;

    .line 189
    .line 190
    .line 191
    move-result-object v10

    .line 192
    invoke-static {v2, v7}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 193
    .line 194
    .line 195
    move-result-wide v11

    .line 196
    sget v7, Lcom/facebook/aura/linktext/HatchTextLink;->$stable:I

    .line 197
    .line 198
    shl-int/lit8 v18, v7, 0x3

    .line 199
    .line 200
    const/16 v19, 0x1e4

    .line 201
    .line 202
    move-object v7, v9

    .line 203
    move-object/from16 v9, v16

    .line 204
    .line 205
    move-object v13, v9

    .line 206
    move-object v14, v9

    .line 207
    move v15, v4

    .line 208
    move-object/from16 v17, v2

    .line 209
    .line 210
    invoke-static/range {v7 .. v19}, Lcom/facebook/aura/linktext/HatchLinkTextKt;->HatchLinkText-fHcc2WU(Ljava/lang/String;Ljava/util/List;LX/3C1;LX/2hg;JLX/2wS;LX/2W8;ZLX/JDM;LX/2d4;II)V

    .line 211
    .line 212
    .line 213
    const/4 v4, 0x1

    .line 214
    invoke-static {v0, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 215
    .line 216
    .line 217
    goto :goto_2

    .line 218
    :cond_6
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 219
    .line 220
    .line 221
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    if-eqz v2, :cond_7

    .line 226
    .line 227
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$InfoSheetSectionContent$2;

    .line 228
    .line 229
    invoke-direct {v0, v3, v5, v1, v6}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$InfoSheetSectionContent$2;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;LX/3C1;II)V

    .line 230
    .line 231
    .line 232
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 233
    .line 234
    :cond_7
    return-void
.end method

.method public static final synthetic access$InfoSheetSectionContent(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt;->InfoSheetSectionContent(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
