.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2pH;",
        "LX/2pT;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $color:J


# direct methods
.method public constructor <init>(J)V
    .locals 1

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;->$color:J

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/2pH;)LX/2pT;
    .locals 10

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x42000000    # 32.0f

    .line 5
    .line 6
    invoke-static {p1, v0}, LX/2pH;->A02(LX/2pH;F)F

    .line 7
    .line 8
    .line 9
    move-result v7

    .line 10
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;->$color:J

    .line 11
    .line 12
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-static {v0, v1, v2}, LX/JOw;->A04(JF)J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    invoke-static {v3, v0, v1}, LX/005;->A0p(LX/JOw;J)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    invoke-static {v5, v2, v7}, LX/2hZ;->A02(Ljava/util/List;FF)LX/2hU;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    invoke-static {v5}, LX/B89;->A0h(Ljava/lang/Iterable;)Ljava/util/List;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    invoke-static {p1}, LX/2pH;->A03(LX/2pH;)J

    .line 34
    .line 35
    .line 36
    move-result-wide v2

    .line 37
    const-wide v0, 0xffffffffL

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v2, v3, v0, v1}, LX/002;->A02(JJ)F

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    sub-float/2addr v1, v7

    .line 47
    invoke-static {p1}, LX/2pH;->A00(LX/2pH;)F

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v4, v1, v0}, LX/2hZ;->A02(Ljava/util/List;FF)LX/2hU;

    .line 52
    .line 53
    .line 54
    move-result-object v8

    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-static {v5, v0, v7}, LX/2hZ;->A01(Ljava/util/List;FF)LX/2hU;

    .line 57
    .line 58
    .line 59
    move-result-object v9

    .line 60
    invoke-static {v5}, LX/B89;->A0h(Ljava/lang/Iterable;)Ljava/util/List;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    invoke-static {p1}, LX/2pH;->A01(LX/2pH;)F

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    sub-float/2addr v1, v7

    .line 69
    invoke-static {p1}, LX/2pH;->A01(LX/2pH;)F

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-static {v2, v1, v0}, LX/2hZ;->A01(Ljava/util/List;FF)LX/2hU;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    new-instance v5, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;

    .line 78
    .line 79
    invoke-direct/range {v5 .. v10}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;-><init>(LX/2hZ;FLX/2hZ;LX/2hZ;LX/2hZ;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p1, v5}, LX/2pH;->A05(LX/JDM;)LX/2pT;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2pH;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1;->invoke(LX/2pH;)LX/2pT;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
