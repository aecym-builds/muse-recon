.class public final Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDR;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDR<",
        "Ljava/lang/Boolean;",
        "LX/3C1;",
        "LX/JDQ<",
        "-",
        "Lkotlin/jvm/functions/Function0<",
        "+",
        "Lkotlin/Unit;",
        ">;-",
        "LX/2d4;",
        "-",
        "Ljava/lang/Integer;",
        "+",
        "Lkotlin/Unit;",
        ">;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x5

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p1

    .line 268435460
    check-cast p2, LX/3C1;

    .line 268435461
    .line 268435462
    check-cast p3, LX/JDQ;

    .line 268435463
    .line 268435464
    check-cast p4, LX/2d4;

    .line 268435465
    .line 268435466
    invoke-static {p5}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435467
    .line 268435468
    .line 268435469
    move-result p5

    .line 268435470
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/view/ComposableSingletons$InviteHeaderButtonDecorationKt$lambda$-1159193538$1;->invoke(ZLX/3C1;LX/JDQ;LX/2d4;I)V

    .line 268435471
    .line 268435472
    .line 268435473
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435474
    .line 268435475
    return-object p0
.end method

.method public final invoke(ZLX/3C1;LX/JDQ;LX/2d4;I)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    move-object v3, p2

    .line 1
    move-object p0, p3

    .line 2
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    and-int/lit8 v0, p5, 0x6

    .line 6
    .line 7
    move v2, p1

    .line 8
    move-object p1, p4

    .line 9
    if-nez v0, :cond_2

    .line 10
    .line 11
    invoke-static {p4, v2}, LX/004;->A0i(LX/2d4;Z)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    or-int/2addr v1, p5

    .line 16
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 17
    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    invoke-static {p4, p2}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    or-int/2addr v1, v0

    .line 25
    :cond_0
    and-int/lit16 v0, p5, 0x180

    .line 26
    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    invoke-static {p4, p3}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    or-int/2addr v1, v0

    .line 34
    :cond_1
    invoke-static {v1}, LX/005;->A1K(I)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v0, p4, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_3

    .line 43
    .line 44
    and-int/lit16 p2, v1, 0x3fe

    .line 45
    .line 46
    const/4 p3, 0x0

    .line 47
    invoke-static/range {v2 .. v7}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;->HatchInviteButtonTooltip(ZLX/3C1;LX/JDQ;LX/2d4;II)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_2
    move v1, p5

    .line 52
    goto :goto_0

    .line 53
    :cond_3
    invoke-interface {p4}, LX/2d4;->AgJ()V

    .line 54
    .line 55
    .line 56
    return-void
.end method
