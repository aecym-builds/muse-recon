.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/367;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onReveal:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $revealLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->$revealLabel:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/367;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->invoke(LX/367;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/367;)V
    .locals 3

    .line 0
    invoke-static {p1}, LX/35e;->A03(LX/367;)V

    .line 1
    .line 2
    .line 3
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->$revealLabel:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p1, v0}, LX/35e;->A09(LX/367;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->$revealLabel:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1$1;

    .line 13
    .line 14
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 15
    .line 16
    .line 17
    invoke-static {p1, v2, v0}, LX/35e;->A0C(LX/367;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
