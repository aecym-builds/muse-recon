.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic $debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

.field public final synthetic $onReveal:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onScratchTick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reduceMotion:Z

.field public final synthetic $scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scratchedCells:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLjava/util/Set;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;",
            "Z",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 3
    .line 4
    iput-boolean p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$reduceMotion:Z

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$scratchedCells:Ljava/util/Set;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final invoke(LX/32h;LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/32h;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchCoverageRadius:F

    .line 1
    .line 2
    move-object v6, p1

    .line 3
    invoke-interface {p1, v0}, LX/34Y;->AhZ(F)F

    .line 4
    .line 5
    .line 6
    move-result v7

    .line 7
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSampleSpacing:F

    .line 8
    .line 9
    invoke-interface {p1, v0}, LX/34Y;->AhZ(F)F

    .line 10
    .line 11
    .line 12
    move-result v12

    .line 13
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchHapticSpacing:F

    .line 14
    .line 15
    invoke-interface {p1, v0}, LX/34Y;->AhZ(F)F

    .line 16
    .line 17
    .line 18
    move-result v10

    .line 19
    new-instance v1, LX/0Rg;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 25
    .line 26
    iget-object v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 27
    .line 28
    iget-boolean v4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$reduceMotion:Z

    .line 29
    .line 30
    iget-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$scratchedCells:Ljava/util/Set;

    .line 31
    .line 32
    iget-object v9, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 33
    .line 34
    const v8, 0x4301999a    # 129.6f

    .line 35
    .line 36
    .line 37
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;

    .line 38
    .line 39
    invoke-direct/range {v0 .. v9}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;-><init>(LX/0Rg;Landroidx/compose/runtime/snapshots/SnapshotStateList;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLjava/util/Set;LX/32h;FFLkotlin/jvm/functions/Function0;)V

    .line 40
    .line 41
    .line 42
    iget-object v11, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 43
    .line 44
    const/4 p0, 0x0

    .line 45
    new-instance v8, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;

    .line 46
    .line 47
    move-object v9, v0

    .line 48
    invoke-direct/range {v8 .. v13}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;-><init>(LX/JDM;FLkotlin/jvm/functions/Function0;FLX/2M4;)V

    .line 49
    .line 50
    .line 51
    invoke-static {p1, p2, v8}, LX/008;->A0z(LX/32h;LX/2M4;LX/JDN;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    return-object v0
.end method
