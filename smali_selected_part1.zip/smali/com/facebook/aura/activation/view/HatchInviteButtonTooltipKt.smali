.class public abstract Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final TooltipPointer:LX/2ay;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;->INSTANCE:Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;

    .line 1
    .line 2
    new-instance v0, LX/2ay;

    .line 3
    .line 4
    invoke-direct {v0, v1}, LX/2ay;-><init>(LX/JDQ;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;->TooltipPointer:LX/2ay;

    .line 8
    .line 9
    return-void
.end method

.method public static final HatchInviteButtonTooltip(ZLX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p1

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    move-object/from16 v8, p2

    .line 4
    .line 5
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, 0x1d06dc70

    .line 9
    .line 10
    .line 11
    move-object/from16 v7, p3

    .line 12
    .line 13
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v6, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    move/from16 v11, p0

    .line 21
    .line 22
    if-nez v0, :cond_8

    .line 23
    .line 24
    invoke-static {v7, v11}, LX/004;->A0i(LX/2d4;Z)I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    or-int v2, v2, p4

    .line 29
    .line 30
    :goto_0
    and-int/lit8 v1, p5, 0x2

    .line 31
    .line 32
    if-eqz v1, :cond_7

    .line 33
    .line 34
    or-int/lit8 v2, v2, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit16 v0, v6, 0x180

    .line 37
    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    invoke-static {v7, v8}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    or-int/2addr v2, v0

    .line 45
    :cond_1
    invoke-static {v2}, LX/005;->A1I(I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-static {v0, v7, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_a

    .line 54
    .line 55
    if-eqz v1, :cond_2

    .line 56
    .line 57
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    :cond_2
    sget-object v0, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 60
    .line 61
    move-object v5, v7

    .line 62
    check-cast v5, LX/J7I;

    .line 63
    .line 64
    invoke-static {v0, v5}, LX/004;->A16(LX/Iow;LX/J7I;)LX/AHE;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    new-instance v10, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$Factory;

    .line 69
    .line 70
    invoke-direct {v10, v0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel$Factory;-><init>(LX/AHE;)V

    .line 71
    .line 72
    .line 73
    invoke-static {v7}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    if-eqz v3, :cond_9

    .line 78
    .line 79
    invoke-static {v3}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    const-class v0, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 84
    .line 85
    invoke-static {v0}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    const/16 p0, 0x20

    .line 90
    .line 91
    const/4 v4, 0x0

    .line 92
    invoke-static {v10, v3, v1, v0}, LX/13Z;->A00(LX/15L;LX/13Z;LX/13i;LX/DVF;)LX/1EJ;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    check-cast v3, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 97
    .line 98
    iget-object v0, v3, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->visible:LX/2J3;

    .line 99
    .line 100
    invoke-static {v7, v0, v4}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 101
    .line 102
    .line 103
    move-result-object v15

    .line 104
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 105
    .line 106
    .line 107
    move-result-object v10

    .line 108
    invoke-interface {v7, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    invoke-static {v2}, LX/008;->A1X(I)Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    or-int/2addr v1, v0

    .line 117
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    if-nez v1, :cond_3

    .line 122
    .line 123
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 124
    .line 125
    if-ne v0, v1, :cond_4

    .line 126
    .line 127
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;

    .line 128
    .line 129
    invoke-direct {v0, v3, v11}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;Z)V

    .line 130
    .line 131
    .line 132
    invoke-interface {v7, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    :cond_4
    invoke-static {v7, v0, v3, v10}, LX/001;->A1I(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    invoke-interface {v7, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v10

    .line 146
    if-nez v0, :cond_5

    .line 147
    .line 148
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 149
    .line 150
    if-ne v10, v0, :cond_6

    .line 151
    .line 152
    :cond_5
    new-instance v10, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$dismiss$1$1;

    .line 153
    .line 154
    invoke-direct {v10, v3}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$dismiss$1$1;-><init>(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    invoke-interface {v7, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    :cond_6
    check-cast v10, LX/DqV;

    .line 161
    .line 162
    shr-int/lit8 v14, v2, 0x3

    .line 163
    .line 164
    invoke-static {v4}, LX/001;->A0g(Z)LX/3BI;

    .line 165
    .line 166
    .line 167
    move-result-object v13

    .line 168
    invoke-static {v5}, LX/002;->A0J(LX/J7I;)I

    .line 169
    .line 170
    .line 171
    move-result v12

    .line 172
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    invoke-static {v7, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 181
    .line 182
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 183
    .line 184
    if-nez v0, :cond_b

    .line 185
    .line 186
    invoke-static {}, LX/1VY;->A00()V

    .line 187
    .line 188
    .line 189
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    throw v0

    .line 194
    :cond_7
    and-int/lit8 v0, p4, 0x30

    .line 195
    .line 196
    if-nez v0, :cond_0

    .line 197
    .line 198
    invoke-static {v7, v9}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 199
    .line 200
    .line 201
    move-result v0

    .line 202
    or-int/2addr v2, v0

    .line 203
    goto/16 :goto_1

    .line 204
    .line 205
    :cond_8
    move v2, v6

    .line 206
    goto/16 :goto_0

    .line 207
    .line 208
    :cond_9
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    throw v0

    .line 213
    :cond_a
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 214
    .line 215
    .line 216
    goto :goto_3

    .line 217
    :cond_b
    invoke-static {v7, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 218
    .line 219
    .line 220
    invoke-static {v7, v13, v3, v2, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 221
    .line 222
    .line 223
    and-int/lit8 v0, v14, 0x70

    .line 224
    .line 225
    invoke-static {v10, v7, v8, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 226
    .line 227
    .line 228
    invoke-static {v15}, LX/16A;->A0C(LX/16A;)Z

    .line 229
    .line 230
    .line 231
    move-result v0

    .line 232
    if-eqz v0, :cond_d

    .line 233
    .line 234
    const v0, -0x34f1dc55    # -9315243.0f

    .line 235
    .line 236
    .line 237
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 238
    .line 239
    .line 240
    sget-object v13, LX/2Id;->A0D:Landroidx/compose/ui/Alignment;

    .line 241
    .line 242
    invoke-static {v5}, LX/004;->A13(LX/J7I;)LX/34Y;

    .line 243
    .line 244
    .line 245
    move-result-object v1

    .line 246
    sget v0, Lcom/facebook/aura/header/view/HeaderButtonKt;->PillIconTouchTarget:F

    .line 247
    .line 248
    invoke-interface {v1, v0}, LX/34Y;->AcK(F)I

    .line 249
    .line 250
    .line 251
    move-result v0

    .line 252
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    const-wide/16 v2, 0x0

    .line 261
    .line 262
    shl-long v2, v2, p0

    .line 263
    .line 264
    int-to-long v0, v0

    .line 265
    invoke-static {v0, v1, v2, v3}, LX/003;->A0O(JJ)J

    .line 266
    .line 267
    .line 268
    move-result-wide p3

    .line 269
    move-object v15, v10

    .line 270
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 271
    .line 272
    new-instance v0, LX/1AV;

    .line 273
    .line 274
    invoke-direct {v0, v4}, LX/1AV;-><init>(Z)V

    .line 275
    .line 276
    .line 277
    new-instance v2, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;

    .line 278
    .line 279
    invoke-direct {v2, v10}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;-><init>(LX/DqV;)V

    .line 280
    .line 281
    .line 282
    const v1, 0x5a9a3cce    # 2.1707E16f

    .line 283
    .line 284
    .line 285
    invoke-static {v7, v2, v1}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 286
    .line 287
    .line 288
    move-result-object p0

    .line 289
    const/16 p1, 0x6c06

    .line 290
    .line 291
    move/from16 p2, v4

    .line 292
    .line 293
    move-object v12, v7

    .line 294
    move-object v14, v0

    .line 295
    invoke-static/range {v12 .. v20}, LX/1VZ;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/1AV;Lkotlin/jvm/functions/Function0;LX/JDN;IIJ)V

    .line 296
    .line 297
    .line 298
    :goto_2
    invoke-static {v5}, LX/003;->A0u(LX/J7I;)V

    .line 299
    .line 300
    .line 301
    :goto_3
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 302
    .line 303
    .line 304
    move-result-object v1

    .line 305
    if-eqz v1, :cond_c

    .line 306
    .line 307
    new-instance v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$3;

    .line 308
    .line 309
    move-object/from16 p0, v0

    .line 310
    .line 311
    move/from16 p1, v11

    .line 312
    .line 313
    move-object/from16 p2, v9

    .line 314
    .line 315
    move-object/from16 p3, v8

    .line 316
    .line 317
    move/from16 p4, v6

    .line 318
    .line 319
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$3;-><init>(ZLX/3C1;LX/JDQ;II)V

    .line 320
    .line 321
    .line 322
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 323
    .line 324
    :cond_c
    return-void

    .line 325
    :cond_d
    const v0, -0x34ed2754    # -9623724.0f

    .line 326
    .line 327
    .line 328
    invoke-interface {v7, v0}, LX/2d4;->Agj(I)V

    .line 329
    .line 330
    .line 331
    goto :goto_2
.end method

.method public static final HatchInviteButtonTooltip$lambda$0(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final InviteTooltipBubble(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 32
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p1

    .line 1
    .line 2
    const v0, 0x3f6ba1be

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v0, :cond_4

    .line 17
    .line 18
    invoke-static {v6, v8}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    or-int v3, v3, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v17, p4

    .line 25
    .line 26
    and-int/lit8 v2, p4, 0x2

    .line 27
    .line 28
    if-eqz v2, :cond_3

    .line 29
    .line 30
    or-int/lit8 v3, v3, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v1, v3, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v6, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    if-eqz v2, :cond_1

    .line 48
    .line 49
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 50
    .line 51
    :cond_1
    sget-object v13, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 52
    .line 53
    invoke-static {v6, v13}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    const-string v2, "hatch-invite-button-tooltip"

    .line 58
    .line 59
    invoke-static {v7, v2}, LX/Ccq;->A00(LX/3C1;Ljava/lang/String;)LX/3C1;

    .line 60
    .line 61
    .line 62
    move-result-object v9

    .line 63
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 68
    .line 69
    if-ne v3, v2, :cond_2

    .line 70
    .line 71
    sget-object v3, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$InviteTooltipBubble$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$InviteTooltipBubble$1$1;

    .line 72
    .line 73
    invoke-interface {v6, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_2
    check-cast v3, LX/JDM;

    .line 77
    .line 78
    const/16 v16, 0x0

    .line 79
    .line 80
    invoke-static {v9, v3, v4}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    invoke-static {v4}, LX/1Y9;->A01(I)LX/1Y9;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    const/4 v3, 0x1

    .line 89
    move-object/from16 v2, v16

    .line 90
    .line 91
    invoke-static {v10, v9, v2, v8, v3}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 92
    .line 93
    .line 94
    move-result-object v9

    .line 95
    sget-object v2, LX/2Id;->A01:LX/2sS;

    .line 96
    .line 97
    invoke-static {v6, v2}, LX/003;->A0Y(LX/2d4;LX/2sS;)LX/3BI;

    .line 98
    .line 99
    .line 100
    move-result-object v15

    .line 101
    move-object v2, v6

    .line 102
    check-cast v2, LX/J7I;

    .line 103
    .line 104
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 105
    .line 106
    .line 107
    move-result v14

    .line 108
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 109
    .line 110
    .line 111
    move-result-object v12

    .line 112
    invoke-static {v6, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 113
    .line 114
    .line 115
    move-result-object v11

    .line 116
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 117
    .line 118
    iget-object v9, v2, LX/J7I;->A0V:LX/3DJ;

    .line 119
    .line 120
    if-nez v9, :cond_6

    .line 121
    .line 122
    invoke-static {}, LX/1VY;->A00()V

    .line 123
    .line 124
    .line 125
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    throw v0

    .line 130
    :cond_3
    and-int/lit8 v0, p3, 0x30

    .line 131
    .line 132
    if-nez v0, :cond_0

    .line 133
    .line 134
    invoke-static {v6, v7}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    or-int/2addr v3, v0

    .line 139
    goto :goto_1

    .line 140
    :cond_4
    move v3, v5

    .line 141
    goto :goto_0

    .line 142
    :cond_5
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 143
    .line 144
    .line 145
    goto/16 :goto_2

    .line 146
    .line 147
    :cond_6
    invoke-static {v6, v2, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 148
    .line 149
    .line 150
    invoke-static {v6, v15, v12, v11, v14}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 151
    .line 152
    .line 153
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 154
    .line 155
    sget v9, Lcom/facebook/aura/header/view/HeaderButtonKt;->PillIconTouchTarget:F

    .line 156
    .line 157
    sget v10, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 158
    .line 159
    invoke-static {v9, v10}, LX/002;->A00(FF)F

    .line 160
    .line 161
    .line 162
    move-result v11

    .line 163
    const/4 v9, 0x0

    .line 164
    invoke-static {v12, v9, v9, v11, v9}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    sget v11, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicroPlusNano:F

    .line 169
    .line 170
    invoke-static {v9, v10, v11}, LX/2sI;->A0C(LX/3C1;FF)LX/3C1;

    .line 171
    .line 172
    .line 173
    move-result-object v14

    .line 174
    sget-object v9, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;->TooltipPointer:LX/2ay;

    .line 175
    .line 176
    invoke-static {v14, v9, v0, v1}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 177
    .line 178
    .line 179
    move-result-object v9

    .line 180
    invoke-static {v9, v6, v4}, LX/3Jj;->A04(LX/3C1;LX/2d4;I)V

    .line 181
    .line 182
    .line 183
    const v9, 0x7f1204bb

    .line 184
    .line 185
    .line 186
    invoke-static {v6, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object v18

    .line 190
    invoke-static {v6, v13}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 191
    .line 192
    .line 193
    move-result-object v22

    .line 194
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 195
    .line 196
    invoke-static {v9, v6}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v9

    .line 200
    check-cast v9, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 201
    .line 202
    iget-wide v14, v9, Lcom/facebook/aura/vds/compose/theme/AuraColors;->invertedText:J

    .line 203
    .line 204
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraShapesKt;->LocalAuraShapes:LX/Ip3;

    .line 205
    .line 206
    invoke-static {v9, v6}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v13

    .line 210
    check-cast v13, Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 211
    .line 212
    iget-object v13, v13, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->tooltip:LX/2bW;

    .line 213
    .line 214
    const/16 v26, 0x1c

    .line 215
    .line 216
    const-wide/16 v27, 0x0

    .line 217
    .line 218
    move-object/from16 v23, v12

    .line 219
    .line 220
    move-object/from16 v24, v13

    .line 221
    .line 222
    move/from16 v25, v11

    .line 223
    .line 224
    move-wide/from16 v29, v27

    .line 225
    .line 226
    invoke-static/range {v23 .. v30}, LX/1ps;->A00(LX/3C1;LX/2bW;FIJJ)LX/3C1;

    .line 227
    .line 228
    .line 229
    move-result-object v11

    .line 230
    invoke-static {v9, v6}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v9

    .line 234
    check-cast v9, Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 235
    .line 236
    iget-object v9, v9, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->tooltip:LX/2bW;

    .line 237
    .line 238
    invoke-static {v11, v9}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 239
    .line 240
    .line 241
    move-result-object v9

    .line 242
    invoke-static {v9, v0, v1}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 243
    .line 244
    .line 245
    move-result-object v1

    .line 246
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 247
    .line 248
    invoke-static {v1, v10, v0}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 249
    .line 250
    .line 251
    move-result-object v19

    .line 252
    const/16 p4, 0x3ff0

    .line 253
    .line 254
    move-object/from16 v23, v16

    .line 255
    .line 256
    move-object/from16 v24, v16

    .line 257
    .line 258
    move-object/from16 v25, v16

    .line 259
    .line 260
    move/from16 v26, v4

    .line 261
    .line 262
    move/from16 v27, v4

    .line 263
    .line 264
    move/from16 v28, v4

    .line 265
    .line 266
    move/from16 v29, v4

    .line 267
    .line 268
    move-object/from16 v30, v16

    .line 269
    .line 270
    move-object/from16 v31, v16

    .line 271
    .line 272
    move-object/from16 p0, v16

    .line 273
    .line 274
    move-object/from16 p1, v6

    .line 275
    .line 276
    move/from16 p2, v4

    .line 277
    .line 278
    move/from16 p3, v4

    .line 279
    .line 280
    move-wide/from16 v20, v14

    .line 281
    .line 282
    invoke-static/range {v18 .. v36}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 283
    .line 284
    .line 285
    invoke-static {v2, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 286
    .line 287
    .line 288
    :goto_2
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 289
    .line 290
    .line 291
    move-result-object v2

    .line 292
    if-eqz v2, :cond_7

    .line 293
    .line 294
    new-instance v1, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$InviteTooltipBubble$3;

    .line 295
    .line 296
    move/from16 v0, v17

    .line 297
    .line 298
    invoke-direct {v1, v8, v7, v5, v0}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$InviteTooltipBubble$3;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 299
    .line 300
    .line 301
    iput-object v1, v2, LX/J7V;->A06:LX/JDN;

    .line 302
    .line 303
    :cond_7
    return-void
.end method

.method public static final synthetic access$InviteTooltipBubble(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;->InviteTooltipBubble(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
