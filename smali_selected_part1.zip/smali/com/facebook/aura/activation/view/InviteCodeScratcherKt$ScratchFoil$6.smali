.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $alpha:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $code:Ljava/lang/String;

.field public final synthetic $debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

.field public final synthetic $onReveal:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onScratchTick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reduceMotion:Z

.field public final synthetic $this_ScratchFoil:LX/33K;


# direct methods
.method public constructor <init>(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/33K;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;I)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$this_ScratchFoil:LX/33K;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$code:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$alpha:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 7
    .line 8
    iput-boolean p5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$reduceMotion:Z

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p7, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$$changed:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$this_ScratchFoil:LX/33K;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$code:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$alpha:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 7
    .line 8
    iget-boolean v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$reduceMotion:Z

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iget-object v7, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iget v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;->$$changed:I

    .line 15
    .line 16
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    move-object v8, p1

    .line 21
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchFoil(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
