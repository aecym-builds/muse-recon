.class public abstract Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AuraDisclosureInfoBanner(LX/3C1;LX/2d4;II)V
    .locals 52

    .line 0
    move-object/from16 v4, p0

    .line 1
    .line 2
    const v1, -0x3e2f8eb8

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p1

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v8, p3

    .line 11
    .line 12
    and-int/lit8 v9, p3, 0x1

    .line 13
    .line 14
    const/4 v5, 0x2

    .line 15
    move/from16 v3, p2

    .line 16
    .line 17
    if-eqz v9, :cond_6

    .line 18
    .line 19
    or-int/lit8 v1, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v2, v1, 0x3

    .line 22
    .line 23
    const/4 v7, 0x0

    .line 24
    const/4 v6, 0x1

    .line 25
    invoke-static {v2, v5}, LX/003;->A1H(II)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_5

    .line 34
    .line 35
    if-eqz v9, :cond_0

    .line 36
    .line 37
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 38
    .line 39
    :cond_0
    sget-object v2, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 40
    .line 41
    move-object v9, v0

    .line 42
    check-cast v9, LX/J7I;

    .line 43
    .line 44
    invoke-static {v2, v9}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    invoke-static {v9}, LX/005;->A0f(LX/J7I;)LX/AHE;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    new-instance v11, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;

    .line 53
    .line 54
    invoke-direct {v11, v2}, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$Factory;-><init>(LX/AHE;)V

    .line 55
    .line 56
    .line 57
    invoke-static {v9}, LX/005;->A0V(LX/J7I;)Landroidx/activity/ComponentActivity;

    .line 58
    .line 59
    .line 60
    move-result-object v10

    .line 61
    invoke-static {v10}, LX/004;->A14(LX/15O;)LX/13i;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    const-class v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 66
    .line 67
    invoke-static {v2}, LX/001;->A1D(Ljava/lang/Class;)LX/Ddf;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    const/4 v15, 0x0

    .line 72
    invoke-static {v11, v10, v9, v2}, LX/13Z;->A00(LX/15L;LX/13Z;LX/13i;LX/DVF;)LX/1EJ;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    check-cast v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;

    .line 77
    .line 78
    iget-object v9, v2, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;->uiState:LX/2J3;

    .line 79
    .line 80
    invoke-static {v0, v9, v7}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 81
    .line 82
    .line 83
    move-result-object v11

    .line 84
    invoke-interface {v11}, LX/16A;->getValue()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    check-cast v9, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 89
    .line 90
    iget-object v10, v9, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->infoBanner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 91
    .line 92
    if-nez v10, :cond_2

    .line 93
    .line 94
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    if-eqz v1, :cond_1

    .line 99
    .line 100
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$banner$1;

    .line 101
    .line 102
    invoke-direct {v0, v4, v3, v8}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$banner$1;-><init>(LX/3C1;II)V

    .line 103
    .line 104
    .line 105
    :goto_1
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 106
    .line 107
    :cond_1
    return-void

    .line 108
    :cond_2
    invoke-static {v15, v0, v7, v6}, Lcom/facebook/aura/vds/compose/card/SettingsKt;->cardStyleForSettings(LX/2rU;LX/2d4;II)Lcom/facebook/aura/vds/compose/card/AuraCardStyle;

    .line 109
    .line 110
    .line 111
    move-result-object v34

    .line 112
    invoke-static {v15}, LX/005;->A0e(Ljava/lang/String;)Lcom/facebook/aura/vds/compose/card/AuraCardType$ChevronNavigation;

    .line 113
    .line 114
    .line 115
    move-result-object v36

    .line 116
    invoke-interface {v11}, LX/16A;->getValue()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v9

    .line 120
    check-cast v9, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 121
    .line 122
    iget-boolean v9, v9, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;->isLoading:Z

    .line 123
    .line 124
    xor-int/lit8 v43, v9, 0x1

    .line 125
    .line 126
    iget-object v11, v10, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;->text:Ljava/lang/String;

    .line 127
    .line 128
    sget-object v12, Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;->B2:Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;

    .line 129
    .line 130
    invoke-static {v0}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 131
    .line 132
    .line 133
    move-result-object v9

    .line 134
    iget-wide v9, v9, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryText:J

    .line 135
    .line 136
    invoke-static {v9, v10}, LX/001;->A0d(J)LX/JOw;

    .line 137
    .line 138
    .line 139
    move-result-object v14

    .line 140
    const-wide/16 v47, 0x0

    .line 141
    .line 142
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 143
    .line 144
    .line 145
    move-result-object v13

    .line 146
    const v21, 0x7fffffff

    .line 147
    .line 148
    .line 149
    sget-wide v29, LX/JOw;->A07:J

    .line 150
    .line 151
    new-instance v10, Lcom/facebook/aura/vds/compose/card/AuraCardContent;

    .line 152
    .line 153
    move-object/from16 v16, v15

    .line 154
    .line 155
    move-object/from16 v17, v15

    .line 156
    .line 157
    move-object/from16 v18, v15

    .line 158
    .line 159
    move-object/from16 v19, v15

    .line 160
    .line 161
    move-object/from16 v20, v15

    .line 162
    .line 163
    move/from16 v22, v21

    .line 164
    .line 165
    move/from16 v23, v21

    .line 166
    .line 167
    move-object/from16 v24, v15

    .line 168
    .line 169
    move/from16 v25, v6

    .line 170
    .line 171
    move/from16 v26, v7

    .line 172
    .line 173
    move-object/from16 v27, v15

    .line 174
    .line 175
    move-object/from16 v28, v15

    .line 176
    .line 177
    move-wide/from16 v31, v29

    .line 178
    .line 179
    move-object/from16 v33, v15

    .line 180
    .line 181
    invoke-direct/range {v10 .. v33}, Lcom/facebook/aura/vds/compose/card/AuraCardContent;-><init>(Ljava/lang/String;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndHeadlineStyle;LX/0Xl;LX/JOw;LX/2iK;LX/JDM;Lcom/facebook/aura/vds/compose/typegroup/AuraIconAndBodyStyle;LX/JOw;Ljava/lang/String;LX/2hg;IIILjava/lang/String;ZZLjava/lang/String;LX/2hg;JJLX/2wS;)V

    .line 182
    .line 183
    .line 184
    sget-object v37, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;->lambda$-1032673300:LX/JDN;

    .line 185
    .line 186
    invoke-static {v0, v2, v5}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v9

    .line 190
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v6

    .line 194
    if-nez v9, :cond_3

    .line 195
    .line 196
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 197
    .line 198
    if-ne v6, v9, :cond_4

    .line 199
    .line 200
    :cond_3
    new-instance v6, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$1$1;

    .line 201
    .line 202
    invoke-direct {v6, v2, v5}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$1$1;-><init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 203
    .line 204
    .line 205
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    :cond_4
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 209
    .line 210
    and-int/lit8 v1, v1, 0xe

    .line 211
    .line 212
    or-int/lit16 v1, v1, 0x6c00

    .line 213
    .line 214
    const p3, 0x3fba0

    .line 215
    .line 216
    .line 217
    move-object/from16 v33, v4

    .line 218
    .line 219
    move-object/from16 v35, v10

    .line 220
    .line 221
    move-object/from16 v38, v15

    .line 222
    .line 223
    move-object/from16 v39, v6

    .line 224
    .line 225
    move-object/from16 v40, v15

    .line 226
    .line 227
    move-object/from16 v41, v15

    .line 228
    .line 229
    move-object/from16 v42, v15

    .line 230
    .line 231
    move/from16 v44, v7

    .line 232
    .line 233
    move-object/from16 v45, v15

    .line 234
    .line 235
    move-object/from16 v46, v15

    .line 236
    .line 237
    move/from16 v49, v7

    .line 238
    .line 239
    move-object/from16 v50, v15

    .line 240
    .line 241
    move-object/from16 v51, v15

    .line 242
    .line 243
    move-object/from16 p0, v0

    .line 244
    .line 245
    move/from16 p1, v1

    .line 246
    .line 247
    move/from16 p2, v7

    .line 248
    .line 249
    invoke-static/range {v33 .. v55}, Lcom/facebook/aura/vds/compose/card/AuraCardKt;->AuraCard-jQVUvHA(LX/3C1;Lcom/facebook/aura/vds/compose/card/AuraCardStyle;Lcom/facebook/aura/vds/compose/card/AuraCardContent;Lcom/facebook/aura/vds/compose/card/AuraCardType;LX/JDN;LX/JDQ;Lkotlin/jvm/functions/Function0;Ljava/lang/Boolean;LX/JDM;LX/JDM;ZZLX/346;LX/2bW;JZLX/JDQ;LX/JDQ;LX/2d4;III)V

    .line 250
    .line 251
    .line 252
    goto :goto_2

    .line 253
    :cond_5
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 254
    .line 255
    .line 256
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 257
    .line 258
    .line 259
    move-result-object v1

    .line 260
    if-eqz v1, :cond_1

    .line 261
    .line 262
    new-instance v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$2;

    .line 263
    .line 264
    invoke-direct {v0, v4, v3, v8}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoBannerKt$AuraDisclosureInfoBanner$2;-><init>(LX/3C1;II)V

    .line 265
    .line 266
    .line 267
    goto/16 :goto_1

    .line 268
    .line 269
    :cond_6
    and-int/lit8 v1, p2, 0x6

    .line 270
    .line 271
    if-nez v1, :cond_7

    .line 272
    .line 273
    invoke-static {v0, v4}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 274
    .line 275
    .line 276
    move-result v1

    .line 277
    or-int v1, v1, p2

    .line 278
    .line 279
    goto/16 :goto_0

    .line 280
    .line 281
    :cond_7
    move v1, v3

    .line 282
    goto/16 :goto_0
.end method

.method public static final AuraDisclosureInfoBanner$lambda$0(LX/16A;)Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;",
            ">;)",
            "Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$UiState;

    .line 5
    .line 6
    return-object p0
.end method
