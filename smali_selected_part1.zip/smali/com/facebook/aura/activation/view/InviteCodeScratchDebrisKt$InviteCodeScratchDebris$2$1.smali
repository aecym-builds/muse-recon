.class public final Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2la;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $frameTick$delegate:LX/CR1;

.field public final synthetic $state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

.field public final synthetic $tint:J


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;JLX/CR1;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$tint:J

    .line 3
    .line 4
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$frameTick$delegate:LX/CR1;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2la;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->invoke(LX/2la;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2la;)V
    .locals 3

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$frameTick$delegate:LX/CR1;

    .line 5
    .line 6
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 7
    .line 8
    .line 9
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 10
    .line 11
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;->$tint:J

    .line 12
    .line 13
    invoke-virtual {v2, p1, v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->draw-4WTKRHQ(LX/2la;J)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
