.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "Lcom/facebook/aura/vds/compose/button/IconContext;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $ctaIcon:LX/2l9;


# direct methods
.method public constructor <init>(LX/2l9;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;->$ctaIcon:LX/2l9;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/button/IconContext;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;->invoke(Lcom/facebook/aura/vds/compose/button/IconContext;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/button/IconContext;LX/2d4;I)V
    .locals 2

    .line 0
    invoke-static {p1, p3}, LX/002;->A0L(Ljava/lang/Object;I)I

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    invoke-static {p2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    or-int/2addr p3, v0

    .line 11
    :cond_0
    invoke-static {p3}, LX/005;->A1G(I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    sget-object v1, Lcom/facebook/aura/vds/compose/button/AuraButtonDefaults;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonDefaults;

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$NotificationOptInCta$2;->$ctaIcon:LX/2l9;

    .line 24
    .line 25
    invoke-static {p2, v0, v1, p1, p3}, LX/2l9;->A05(LX/2d4;LX/2l9;Lcom/facebook/aura/vds/compose/button/AuraButtonDefaults;Lcom/facebook/aura/vds/compose/button/IconContext;I)V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 30
    .line 31
    .line 32
    return-void
.end method
