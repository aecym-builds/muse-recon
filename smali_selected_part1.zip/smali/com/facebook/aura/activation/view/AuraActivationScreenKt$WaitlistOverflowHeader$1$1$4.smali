.class public final Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $menuItems:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/Dwf;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Dwf<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;->$menuItems:LX/Dwf;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/Ddn;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, 0x1d12aff0

    .line 1
    .line 2
    .line 3
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;->$menuItems:LX/Dwf;

    .line 7
    .line 8
    invoke-static {p1}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;->invoke(LX/2d4;I)LX/Ddn;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
