.class public final Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $enabled:Z

.field public final synthetic $viewModel:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;Z)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->$viewModel:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->$enabled:Z

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 2

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->$viewModel:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 1
    .line 2
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->$enabled:Z

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/model/InviteTooltipViewModel;->onShown(Z)V

    .line 5
    .line 6
    .line 7
    iget-object v1, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->$viewModel:Lcom/facebook/aura/activation/model/InviteTooltipViewModel;

    .line 8
    .line 9
    new-instance v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1$invoke$$inlined$onDispose$1;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1$invoke$$inlined$onDispose$1;-><init>(Lcom/facebook/aura/activation/model/InviteTooltipViewModel;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
