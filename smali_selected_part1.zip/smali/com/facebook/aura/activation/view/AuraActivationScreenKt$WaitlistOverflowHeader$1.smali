.class public final Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $menuItems:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRefreshClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $showContextMenu$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;LX/Dwf;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/Dwf<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$onRefreshClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$menuItems:LX/Dwf;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 27

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    and-int/lit8 v0, p2, 0x3

    .line 3
    .line 4
    const/4 v9, 0x0

    .line 5
    invoke-static {v0}, LX/004;->A1P(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object/from16 v3, p1

    .line 10
    .line 11
    invoke-static {v0, v3, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_5

    .line 16
    .line 17
    move-object/from16 v0, p0

    .line 18
    .line 19
    iget-object v5, v0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$onRefreshClick:Lkotlin/jvm/functions/Function0;

    .line 20
    .line 21
    iget-object v4, v0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 22
    .line 23
    iget-object v2, v0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 24
    .line 25
    iget-object v8, v0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1;->$menuItems:LX/Dwf;

    .line 26
    .line 27
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 28
    .line 29
    invoke-static {v9}, LX/001;->A0g(Z)LX/3BI;

    .line 30
    .line 31
    .line 32
    move-result-object v13

    .line 33
    move-object v1, v3

    .line 34
    check-cast v1, LX/J7I;

    .line 35
    .line 36
    iget-wide v6, v1, LX/J7I;->A06:J

    .line 37
    .line 38
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 39
    .line 40
    .line 41
    move-result v12

    .line 42
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 43
    .line 44
    .line 45
    move-result-object v11

    .line 46
    invoke-static {v3, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 47
    .line 48
    .line 49
    move-result-object v7

    .line 50
    sget-object v6, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 51
    .line 52
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 53
    .line 54
    if-nez v0, :cond_0

    .line 55
    .line 56
    invoke-static {}, LX/1VY;->A00()V

    .line 57
    .line 58
    .line 59
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    throw v0

    .line 64
    :cond_0
    invoke-static {v3, v1, v6}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 65
    .line 66
    .line 67
    invoke-static {v3, v13, v11, v7, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 68
    .line 69
    .line 70
    sget-object v11, LX/3Jn;->A00:LX/3Jn;

    .line 71
    .line 72
    const v0, 0x7f080124

    .line 73
    .line 74
    .line 75
    invoke-static {v3, v0, v9}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 76
    .line 77
    .line 78
    move-result-object v15

    .line 79
    const v0, 0x7f12081d

    .line 80
    .line 81
    .line 82
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v16

    .line 86
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 91
    .line 92
    if-ne v7, v0, :cond_1

    .line 93
    .line 94
    new-instance v7, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;

    .line 95
    .line 96
    invoke-direct {v7, v2}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 97
    .line 98
    .line 99
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_1
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 103
    .line 104
    sget v6, LX/2l9;->$stable:I

    .line 105
    .line 106
    or-int/lit16 v12, v6, 0x180

    .line 107
    .line 108
    const/16 p2, 0x7f8

    .line 109
    .line 110
    const/4 v14, 0x0

    .line 111
    const/4 v6, 0x0

    .line 112
    move-object/from16 v17, v7

    .line 113
    .line 114
    move-object/from16 v18, v14

    .line 115
    .line 116
    move/from16 v19, v9

    .line 117
    .line 118
    move/from16 v20, v6

    .line 119
    .line 120
    move-object/from16 v21, v14

    .line 121
    .line 122
    move-object/from16 v22, v14

    .line 123
    .line 124
    move-object/from16 v23, v14

    .line 125
    .line 126
    move/from16 v24, v9

    .line 127
    .line 128
    move/from16 v25, v9

    .line 129
    .line 130
    move-object/from16 v26, v3

    .line 131
    .line 132
    move/from16 p0, v12

    .line 133
    .line 134
    move/from16 p1, v9

    .line 135
    .line 136
    invoke-static/range {v15 .. v29}, Lcom/facebook/aura/vds/compose/button/AuraElevatedButtonKt;->AuraElevatedIconButton-Xjqr6CI(LX/2l9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;ZFLcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;LX/3C1;ZZLX/2d4;III)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v11, v10}, LX/3Jn;->AQU(LX/3C1;)LX/3C1;

    .line 140
    .line 141
    .line 142
    move-result-object v10

    .line 143
    invoke-static {v2}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 144
    .line 145
    .line 146
    move-result v13

    .line 147
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 148
    .line 149
    invoke-static {v6, v7}, LX/005;->A0G(FF)J

    .line 150
    .line 151
    .line 152
    move-result-wide v15

    .line 153
    invoke-static {v3, v5, v4}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v6

    .line 157
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v11

    .line 161
    if-nez v6, :cond_2

    .line 162
    .line 163
    if-ne v11, v0, :cond_3

    .line 164
    .line 165
    :cond_2
    new-instance v11, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;

    .line 166
    .line 167
    invoke-direct {v11, v5, v4, v2}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 168
    .line 169
    .line 170
    invoke-interface {v3, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_3
    check-cast v11, LX/JDM;

    .line 174
    .line 175
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v12

    .line 179
    if-ne v12, v0, :cond_4

    .line 180
    .line 181
    new-instance v12, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$3$1;

    .line 182
    .line 183
    invoke-direct {v12, v2}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$3$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 184
    .line 185
    .line 186
    invoke-interface {v3, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    :cond_4
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 190
    .line 191
    new-instance v0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;

    .line 192
    .line 193
    invoke-direct {v0, v8}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$4;-><init>(LX/Dwf;)V

    .line 194
    .line 195
    .line 196
    const/16 p2, 0x7ed0

    .line 197
    .line 198
    const/16 p0, 0x180

    .line 199
    .line 200
    move-object/from16 v17, v14

    .line 201
    .line 202
    move/from16 v18, v9

    .line 203
    .line 204
    move-object/from16 v19, v0

    .line 205
    .line 206
    move/from16 v20, v9

    .line 207
    .line 208
    move/from16 v21, v9

    .line 209
    .line 210
    move-object/from16 v24, v14

    .line 211
    .line 212
    invoke-static/range {v10 .. v29}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuKt;->AuraContextMenu-Q3lI2Mc(LX/3C1;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuStyle;JLX/3Lr;ZLX/JDN;ZZLX/Ddn;LX/1Ot;LX/JDM;ZLX/2d4;III)V

    .line 213
    .line 214
    .line 215
    const/4 v0, 0x1

    .line 216
    invoke-static {v1, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 217
    .line 218
    .line 219
    return-void

    .line 220
    :cond_5
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 221
    .line 222
    .line 223
    return-void
.end method
