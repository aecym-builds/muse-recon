.class public final Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $annotatedString:LX/2iK;

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $sixLineHeight:F

.field public final synthetic $textStyle:LX/2hg;


# direct methods
.method public constructor <init>(LX/2iK;LX/3C1;FLX/2hg;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$annotatedString:LX/2iK;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$modifier:LX/3C1;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$sixLineHeight:F

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$textStyle:LX/2hg;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 14

    .line 0
    move/from16 v2, p2

    .line 1
    .line 2
    and-int/lit8 v1, p2, 0x3

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v10, 0x0

    .line 6
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    move-object v3, p1

    .line 11
    invoke-static {v0, p1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget-object v6, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$annotatedString:LX/2iK;

    .line 18
    .line 19
    iget-object v2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$modifier:LX/3C1;

    .line 20
    .line 21
    iget v1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$sixLineHeight:F

    .line 22
    .line 23
    const/4 v5, 0x0

    .line 24
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 25
    .line 26
    invoke-static {v2, v0, v1}, LX/2sI;->A0A(LX/3C1;FF)LX/3C1;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {p1, v0}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraDisclosureScreenKt$ScrollableLinkText$1;->$textStyle:LX/2hg;

    .line 35
    .line 36
    const/16 p1, 0x7f8

    .line 37
    .line 38
    move-object v8, v5

    .line 39
    move-object v9, v5

    .line 40
    move v11, v10

    .line 41
    move v12, v10

    .line 42
    move v13, v10

    .line 43
    move p0, v10

    .line 44
    move/from16 p2, v10

    .line 45
    .line 46
    invoke-static/range {v3 .. v16}, LX/2sZ;->A04(LX/2d4;LX/3C1;LX/2pa;LX/2iK;LX/2hg;Ljava/util/Map;LX/JDM;IIIIIIZ)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 51
    .line 52
    .line 53
    return-void
.end method
