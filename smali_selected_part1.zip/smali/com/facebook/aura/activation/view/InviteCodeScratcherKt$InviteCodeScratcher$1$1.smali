.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.InviteCodeScratcherKt$InviteCodeScratcher$1$1"
    f = "InviteCodeScratcher.kt"
    l = {
        0x86
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $haptics:LX/1sR;

.field public final synthetic $isCodeVisible:Z

.field public final synthetic $reduceMotion:Z

.field public final synthetic $revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public label:I


# direct methods
.method public constructor <init>(ZZLX/1sR;Landroidx/compose/runtime/MutableState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "LX/1sR;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$isCodeVisible:Z

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$reduceMotion:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$haptics:LX/1sR;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$isCodeVisible:Z

    .line 1
    .line 2
    iget-boolean v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$reduceMotion:Z

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$haptics:LX/1sR;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;-><init>(ZZLX/1sR;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->label:I

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-ne v0, v2, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$haptics:LX/1sR;

    .line 13
    .line 14
    sget v0, Lcom/facebook/aura/vds/compose/accessibility/AuraHaptics;->SUCCESS:I

    .line 15
    .line 16
    invoke-interface {v1, v0}, LX/1sR;->AYC(I)V

    .line 17
    .line 18
    .line 19
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->COVERAGE_COLUMNS:I

    .line 23
    .line 24
    invoke-static {v1, v2}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 25
    .line 26
    .line 27
    :cond_1
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 28
    .line 29
    return-object v3

    .line 30
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$isCodeVisible:Z

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 38
    .line 39
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->COVERAGE_COLUMNS:I

    .line 40
    .line 41
    invoke-static {v1}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->$reduceMotion:Z

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    iput v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;->label:I

    .line 52
    .line 53
    const-wide/16 v0, 0x208

    .line 54
    .line 55
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-ne v0, v3, :cond_0

    .line 60
    .line 61
    return-object v3

    .line 62
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    throw v0
.end method
