.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;
.super LX/DRt;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRt;",
        "LX/JDN<",
        "LX/3Hm;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.InviteCodeScratcherKt$claimTouches$1$1"
    f = "InviteCodeScratcher.kt"
    l = {
        0xde,
        0xe1
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRt;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$0:Ljava/lang/Object;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/3Hm;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3Hm;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;

    .line 1
    .line 2
    invoke-direct {p0, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$0:Ljava/lang/Object;

    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/3Hm;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->invoke(LX/3Hm;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v5, LX/3Hm;

    .line 3
    .line 4
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->label:I

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    const/4 v0, 0x1

    .line 10
    if-eqz v1, :cond_5

    .line 11
    .line 12
    if-eq v1, v0, :cond_6

    .line 13
    .line 14
    if-ne v1, v3, :cond_8

    .line 15
    .line 16
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    check-cast p1, LX/3BA;

    .line 20
    .line 21
    iget-object v2, p1, LX/3BA;->A05:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    invoke-static {v1}, LX/3CH;->A00(Ljava/util/Iterator;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    instance-of v0, v2, Ljava/util/Collection;

    .line 38
    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_3

    .line 46
    .line 47
    :cond_2
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 48
    .line 49
    return-object v4

    .line 50
    :cond_3
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    :cond_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_2

    .line 59
    .line 60
    invoke-static {v1}, LX/3CH;->A02(Ljava/util/Iterator;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_4

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_5
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iput-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$0:Ljava/lang/Object;

    .line 71
    .line 72
    iput v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->label:I

    .line 73
    .line 74
    const/4 v1, 0x0

    .line 75
    sget-object v0, LX/3ID;->A04:LX/3ID;

    .line 76
    .line 77
    invoke-static {v5, v0, p0, v1}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->A04(LX/3Hm;LX/3ID;LX/2M4;Z)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    if-ne p1, v4, :cond_7

    .line 82
    .line 83
    return-object v4

    .line 84
    :cond_6
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    :cond_7
    check-cast p1, LX/3CH;

    .line 88
    .line 89
    invoke-virtual {p1}, LX/3CH;->A04()V

    .line 90
    .line 91
    .line 92
    :goto_1
    iput-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$0:Ljava/lang/Object;

    .line 93
    .line 94
    const/4 v0, 0x0

    .line 95
    iput-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->L$1:Ljava/lang/Object;

    .line 96
    .line 97
    iput v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;->label:I

    .line 98
    .line 99
    invoke-static {v5, p0}, LX/3Hm;->A00(LX/3Hm;LX/2M4;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    if-ne p1, v4, :cond_0

    .line 104
    .line 105
    return-object v4

    .line 106
    :cond_8
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    throw v0
.end method
