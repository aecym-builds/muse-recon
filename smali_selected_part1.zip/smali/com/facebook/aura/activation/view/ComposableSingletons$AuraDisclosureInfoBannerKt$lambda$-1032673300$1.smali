.class public final Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 6

    .line 0
    and-int/lit8 v0, p2, 0x3

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-static {v0}, LX/004;->A1P(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    move-object p0, p1

    .line 8
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    sget-object v2, Lcom/facebook/aura/vds/compose/card/AuraCardDefaults;->INSTANCE:Lcom/facebook/aura/vds/compose/card/AuraCardDefaults;

    .line 15
    .line 16
    const v0, 0x7f0800f4

    .line 17
    .line 18
    .line 19
    invoke-static {p1, v0, v1}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-static {p1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iget-object v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryIcon:Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;

    .line 28
    .line 29
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColorsIconTint;->enabled:J

    .line 30
    .line 31
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    sget v0, LX/2l9;->$stable:I

    .line 36
    .line 37
    shl-int/lit8 v0, v0, 0x3

    .line 38
    .line 39
    or-int/lit16 p1, v0, 0xc00

    .line 40
    .line 41
    const/4 p2, 0x1

    .line 42
    const/4 v3, 0x0

    .line 43
    invoke-virtual/range {v2 .. v8}, Lcom/facebook/aura/vds/compose/card/AuraCardDefaults;->LeadingIcon-gKt5lHk(LX/3C1;LX/2l9;LX/JOw;LX/2d4;II)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 48
    .line 49
    .line 50
    return-void
.end method
