.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2pH;",
        "LX/2pT;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $colors:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/JOw;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $progress:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LX/JOw;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;->$colors:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;->$progress:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/2pH;)LX/2pT;
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LX/2pH;->A03(LX/2pH;)J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    invoke-static {v0, v1}, LX/004;->A03(J)F

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    const v0, 0x3f333333    # 0.7f

    .line 13
    .line 14
    .line 15
    mul-float/2addr v3, v0

    .line 16
    const/high16 v0, 0x3f800000    # 1.0f

    .line 17
    .line 18
    cmpg-float v0, v3, v0

    .line 19
    .line 20
    if-gez v0, :cond_0

    .line 21
    .line 22
    const/high16 v3, 0x3f800000    # 1.0f

    .line 23
    .line 24
    :cond_0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;->$colors:Ljava/util/List;

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    invoke-static {v1, v0, v3}, LX/2hZ;->A01(Ljava/util/List;FF)LX/2hU;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;->$progress:Lkotlin/jvm/functions/Function0;

    .line 32
    .line 33
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;

    .line 34
    .line 35
    invoke-direct {v0, v3, v1, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;-><init>(FLkotlin/jvm/functions/Function0;LX/2hZ;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0}, LX/2pH;->A05(LX/JDM;)LX/2pT;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2pH;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;->invoke(LX/2pH;)LX/2pT;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
