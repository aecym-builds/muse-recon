.class public final Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;->$banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 37

    .line 0
    move/from16 v2, p2

    .line 1
    .line 2
    and-int/lit8 v1, p2, 0x3

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v15, 0x0

    .line 6
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    move-object/from16 v5, p1

    .line 11
    .line 12
    invoke-static {v0, v5, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_3

    .line 17
    .line 18
    move-object/from16 v0, p0

    .line 19
    .line 20
    iget-object v9, v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;->$banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 21
    .line 22
    iget-object v7, v0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 23
    .line 24
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 25
    .line 26
    invoke-static {v5}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 27
    .line 28
    .line 29
    move-result-object v8

    .line 30
    move-object v4, v5

    .line 31
    check-cast v4, LX/J7I;

    .line 32
    .line 33
    invoke-static {v4}, LX/003;->A0F(LX/J7I;)I

    .line 34
    .line 35
    .line 36
    move-result v6

    .line 37
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    invoke-static {v5, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 46
    .line 47
    iget-object v0, v4, LX/J7I;->A0V:LX/3DJ;

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    invoke-static {}, LX/1VY;->A00()V

    .line 52
    .line 53
    .line 54
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    throw v0

    .line 59
    :cond_0
    invoke-static {v5, v4, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 60
    .line 61
    .line 62
    invoke-static {v5, v8, v3, v2, v6}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 63
    .line 64
    .line 65
    const/16 v16, 0x7

    .line 66
    .line 67
    const/4 v8, 0x0

    .line 68
    move-object v11, v8

    .line 69
    move-object v12, v8

    .line 70
    move v13, v15

    .line 71
    move-object v14, v5

    .line 72
    invoke-static/range {v11 .. v16}, Lcom/facebook/aura/vds/compose/divider/AuraDividerKt;->AuraDivider(LX/3C1;Lcom/facebook/aura/vds/compose/divider/AuraDividerStyle;ZLX/2d4;II)V

    .line 73
    .line 74
    .line 75
    iget-object v9, v9, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;->closeText:Ljava/lang/String;

    .line 76
    .line 77
    sget-object v13, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->LARGE:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 78
    .line 79
    invoke-interface {v5, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    invoke-interface {v5}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    if-nez v0, :cond_1

    .line 88
    .line 89
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 90
    .line 91
    if-ne v3, v0, :cond_2

    .line 92
    .line 93
    :cond_1
    new-instance v3, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3$1$1$1;

    .line 94
    .line 95
    invoke-direct {v3, v7}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3$1$1$1;-><init>(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    invoke-interface {v5, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :cond_2
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 102
    .line 103
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 104
    .line 105
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 106
    .line 107
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 108
    .line 109
    invoke-static {v2, v1, v0}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 110
    .line 111
    .line 112
    move-result-object v11

    .line 113
    const p2, 0x7ffbfd5

    .line 114
    .line 115
    .line 116
    const/high16 v36, 0x30000

    .line 117
    .line 118
    move-object v10, v8

    .line 119
    move-object v14, v8

    .line 120
    move/from16 v16, v15

    .line 121
    .line 122
    move/from16 v17, v15

    .line 123
    .line 124
    move/from16 v18, v15

    .line 125
    .line 126
    move/from16 v19, v15

    .line 127
    .line 128
    move-object/from16 v20, v8

    .line 129
    .line 130
    move-object/from16 v21, v8

    .line 131
    .line 132
    move-object/from16 v22, v3

    .line 133
    .line 134
    move-object/from16 v23, v8

    .line 135
    .line 136
    move-object/from16 v24, v8

    .line 137
    .line 138
    move-object/from16 v25, v8

    .line 139
    .line 140
    move-object/from16 v26, v8

    .line 141
    .line 142
    move-object/from16 v27, v8

    .line 143
    .line 144
    move-object/from16 v28, v8

    .line 145
    .line 146
    move-object/from16 v29, v8

    .line 147
    .line 148
    move-object/from16 v30, v8

    .line 149
    .line 150
    move/from16 v31, v15

    .line 151
    .line 152
    move/from16 v32, v15

    .line 153
    .line 154
    move/from16 v33, v15

    .line 155
    .line 156
    move/from16 v34, v15

    .line 157
    .line 158
    move-object/from16 v35, v5

    .line 159
    .line 160
    move/from16 p0, v15

    .line 161
    .line 162
    move/from16 p1, v15

    .line 163
    .line 164
    invoke-static/range {v8 .. v39}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 165
    .line 166
    .line 167
    const/4 v0, 0x1

    .line 168
    invoke-static {v4, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 169
    .line 170
    .line 171
    return-void

    .line 172
    :cond_3
    invoke-interface {v5}, LX/2d4;->AgJ()V

    .line 173
    .line 174
    .line 175
    return-void
.end method
