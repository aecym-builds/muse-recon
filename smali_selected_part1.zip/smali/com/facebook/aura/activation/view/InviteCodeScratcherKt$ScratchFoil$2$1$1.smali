.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2RG;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $brush:LX/2hZ;

.field public final synthetic $radiusPx:F

.field public final synthetic $scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/2hZ;Landroidx/compose/runtime/snapshots/SnapshotStateList;F)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2hZ;",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;F)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$brush:LX/2hZ;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 3
    .line 4
    iput p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$radiusPx:F

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2RG;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->invoke(LX/2RG;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2RG;)V
    .locals 17

    .line 0
    const/4 v2, 0x0

    .line 1
    move-object/from16 v4, p1

    .line 2
    .line 3
    invoke-static {v4, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v3, p0

    .line 7
    .line 8
    iget-object v5, v3, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$brush:LX/2hZ;

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    const-wide/16 v10, 0x0

    .line 12
    .line 13
    invoke-interface {v4}, LX/2la;->AKf()J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    invoke-static {v0, v1, v10, v11}, LX/2lb;->A00(JJ)J

    .line 18
    .line 19
    .line 20
    move-result-wide v12

    .line 21
    const/high16 v8, 0x3f800000    # 1.0f

    .line 22
    .line 23
    sget-object v7, LX/2RH;->A00:LX/2RH;

    .line 24
    .line 25
    const/4 v9, 0x3

    .line 26
    invoke-interface/range {v4 .. v13}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V

    .line 27
    .line 28
    .line 29
    invoke-interface {v4}, LX/2RG;->A9T()V

    .line 30
    .line 31
    .line 32
    iget-object v0, v3, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 33
    .line 34
    iget v12, v3, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;->$radiusPx:F

    .line 35
    .line 36
    invoke-virtual {v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, LX/2qg;

    .line 51
    .line 52
    iget-wide v0, v0, LX/2qg;->A00:J

    .line 53
    .line 54
    sget-wide v15, LX/JOw;->A06:J

    .line 55
    .line 56
    move-object v9, v4

    .line 57
    move-object v10, v6

    .line 58
    move-object v11, v7

    .line 59
    move v13, v8

    .line 60
    move v14, v2

    .line 61
    move-wide/from16 p0, v0

    .line 62
    .line 63
    invoke-interface/range {v9 .. v18}, LX/2la;->A9S(LX/2hc;LX/2Qt;FFIJJ)V

    .line 64
    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_0
    return-void
.end method
