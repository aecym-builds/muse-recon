.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $haptics:LX/1sR;

.field public final synthetic $isCodeVisible:Z

.field public final synthetic $onRevealed:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ZLX/1sR;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "LX/1sR;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$isCodeVisible:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$haptics:LX/1sR;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$onRevealed:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 2

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$isCodeVisible:Z

    .line 1
    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->COVERAGE_COLUMNS:I

    .line 7
    .line 8
    invoke-static {v1}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$revealFeedbackPending$delegate:Landroidx/compose/runtime/MutableState;

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 18
    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$haptics:LX/1sR;

    .line 21
    .line 22
    sget v0, Lcom/facebook/aura/vds/compose/accessibility/AuraHaptics;->GESTURE_THRESHOLD:I

    .line 23
    .line 24
    invoke-interface {v1, v0}, LX/1sR;->AYC(I)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;->$onRevealed:Lkotlin/jvm/functions/Function0;

    .line 28
    .line 29
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void
.end method
