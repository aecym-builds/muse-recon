.class public final Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onRefreshClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSettingsClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $showContextMenu$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$onRefreshClick:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->invoke(Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;)V
    .locals 8

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-static {v1, v0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 7
    .line 8
    .line 9
    iget v1, p1, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;->id:I

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    if-eq v1, v0, :cond_1

    .line 15
    .line 16
    const-string v0, "Unhandled overflow menu item: "

    .line 17
    .line 18
    invoke-static {v0, v1}, LX/Gi8;->A0X(Ljava/lang/String;I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v0, "AuraActivationScreen"

    .line 23
    .line 24
    invoke-static {v0, v1}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 29
    .line 30
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 31
    .line 32
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DOT_MENU:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 33
    .line 34
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 35
    .line 36
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchComponent;->ACTIVATION_STATUS_CHECK:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 37
    .line 38
    const-string v1, "trigger"

    .line 39
    .line 40
    const-string v0, "overflow_menu"

    .line 41
    .line 42
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 43
    .line 44
    .line 45
    move-result-object v7

    .line 46
    invoke-virtual/range {v2 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logStatusCheck(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/util/Map;)V

    .line 47
    .line 48
    .line 49
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$onRefreshClick:Lkotlin/jvm/functions/Function0;

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 53
    .line 54
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 55
    .line 56
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->DOT_MENU:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 57
    .line 58
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 59
    .line 60
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->TAB_SETTINGS:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 61
    .line 62
    const/4 v5, 0x0

    .line 63
    move-object v6, v5

    .line 64
    move-object v7, v5

    .line 65
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$2$1;->$onSettingsClick:Lkotlin/jvm/functions/Function0;

    .line 69
    .line 70
    :goto_0
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    return-void
.end method
