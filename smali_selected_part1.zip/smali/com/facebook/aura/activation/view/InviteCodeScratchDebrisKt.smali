.class public abstract Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ANIMATION_SCALE_OFF_THRESHOLD:F = 0.01f

.field public static final CRUMBLE_PARTICLES_PER_CELL:I = 0x2

.field public static final CrumbleVelocityXRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final CrumbleVelocityYRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final PARTICLE_GROWTH_PER_SECOND:F = 0.3f

.field public static final PARTICLE_LIFETIME_SECONDS:F = 1.05f

.field public static final ParticleGravity:F = 430.0f

.field public static final ParticleSizeRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final REVEAL_BURST_COUNT:I = 0x2a

.field public static final REVEAL_PARTICLE_LIMIT:I = 0x1a4

.field public static final RevealBurstInset:F = 24.0f

.field public static final RevealBurstYRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final RevealParticleSizeRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final RevealVelocityXRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final RevealVelocityYRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final SCRATCH_PARTICLES_PER_SAMPLE:I = 0x7

.field public static final SCRATCH_PARTICLE_LIMIT:I = 0xf0

.field public static final ScratchVelocityXRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field

.field public static final ScratchVelocityYRange:LX/34c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/34c<",
            "LX/1Ot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/high16 v0, 0x3f800000    # 1.0f

    .line 1
    .line 2
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const v0, 0x40266666    # 2.6f

    .line 7
    .line 8
    .line 9
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleSizeRange:LX/34c;

    .line 14
    .line 15
    const v0, 0x3f99999a    # 1.2f

    .line 16
    .line 17
    .line 18
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const v0, 0x404ccccd    # 3.2f

    .line 23
    .line 24
    .line 25
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealParticleSizeRange:LX/34c;

    .line 30
    .line 31
    const/high16 v0, -0x3df80000    # -34.0f

    .line 32
    .line 33
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const/high16 v0, 0x42080000    # 34.0f

    .line 38
    .line 39
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityXRange:LX/34c;

    .line 44
    .line 45
    const/high16 v0, -0x3d740000    # -70.0f

    .line 46
    .line 47
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const/high16 v0, -0x3f600000    # -5.0f

    .line 52
    .line 53
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityYRange:LX/34c;

    .line 58
    .line 59
    const/high16 v0, -0x3d880000    # -62.0f

    .line 60
    .line 61
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const/high16 v0, 0x42780000    # 62.0f

    .line 66
    .line 67
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityXRange:LX/34c;

    .line 72
    .line 73
    const/high16 v0, -0x3d1a0000    # -115.0f

    .line 74
    .line 75
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    const/high16 v0, -0x3df40000    # -35.0f

    .line 80
    .line 81
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityYRange:LX/34c;

    .line 86
    .line 87
    const/high16 v0, -0x3e100000    # -30.0f

    .line 88
    .line 89
    invoke-static {v0}, LX/1Ot;->A02(F)LX/1Ot;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    const/high16 v0, 0x41f00000    # 30.0f

    .line 94
    .line 95
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityXRange:LX/34c;

    .line 100
    .line 101
    const/high16 v2, 0x41400000    # 12.0f

    .line 102
    .line 103
    invoke-static {v2}, LX/1Ot;->A02(F)LX/1Ot;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    const/high16 v0, 0x42880000    # 68.0f

    .line 108
    .line 109
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityYRange:LX/34c;

    .line 114
    .line 115
    invoke-static {v2}, LX/1Ot;->A02(F)LX/1Ot;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    const/high16 v0, 0x42280000    # 42.0f

    .line 120
    .line 121
    invoke-static {v1, v0}, LX/1Ot;->A04(Ljava/lang/Comparable;F)LX/34b;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealBurstYRange:LX/34c;

    .line 126
    .line 127
    return-void
.end method

.method public static final InviteCodeScratchDebris-3IgeMak(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;JLX/3C1;LX/2d4;II)V
    .locals 11

    .line 0
    move-object v10, p3

    .line 1
    const/4 v1, 0x0

    .line 2
    move-object v7, p0

    .line 3
    invoke-static {p0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    const v0, 0x3e8208c1

    .line 7
    .line 8
    .line 9
    invoke-interface {p4, v0}, LX/2d4;->Agl(I)V

    .line 10
    .line 11
    .line 12
    move/from16 p0, p5

    .line 13
    .line 14
    and-int/lit8 v0, p5, 0x6

    .line 15
    .line 16
    if-nez v0, :cond_b

    .line 17
    .line 18
    invoke-static {p4, v7}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    or-int v4, v4, p5

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p5, 0x30

    .line 25
    .line 26
    move-wide v8, p1

    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    invoke-static {p4, p1, p2}, LX/008;->A0N(LX/2d4;J)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    or-int/2addr v4, v0

    .line 34
    :cond_0
    move/from16 p1, p6

    .line 35
    .line 36
    and-int/lit8 v5, p6, 0x4

    .line 37
    .line 38
    if-eqz v5, :cond_a

    .line 39
    .line 40
    or-int/lit16 v4, v4, 0x180

    .line 41
    .line 42
    :cond_1
    :goto_1
    and-int/lit16 v2, v4, 0x93

    .line 43
    .line 44
    const/16 v0, 0x92

    .line 45
    .line 46
    invoke-static {v2, v0}, LX/003;->A1H(II)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0, p4, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_9

    .line 55
    .line 56
    if-eqz v5, :cond_2

    .line 57
    .line 58
    sget-object v10, LX/3C1;->A00:LX/3Cb;

    .line 59
    .line 60
    :cond_2
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 65
    .line 66
    if-ne v6, v5, :cond_3

    .line 67
    .line 68
    invoke-static {p4, v1}, LX/007;->A0c(LX/2d4;I)Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    :cond_3
    check-cast v6, LX/CR1;

    .line 73
    .line 74
    invoke-interface {p4, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-nez v1, :cond_4

    .line 83
    .line 84
    if-ne v0, v5, :cond_5

    .line 85
    .line 86
    :cond_4
    const/4 v1, 0x0

    .line 87
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;

    .line 88
    .line 89
    invoke-direct {v0, v7, v6, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;-><init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;LX/CR1;LX/2M4;)V

    .line 90
    .line 91
    .line 92
    invoke-interface {p4, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :cond_5
    invoke-static {p4, v0, v7}, LX/001;->A1H(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    invoke-interface {p4, v7}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    invoke-static {v4}, LX/002;->A1T(I)Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    or-int/2addr v2, v0

    .line 107
    invoke-interface {p4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    if-nez v2, :cond_6

    .line 112
    .line 113
    if-ne v1, v5, :cond_7

    .line 114
    .line 115
    :cond_6
    new-instance v1, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;

    .line 116
    .line 117
    invoke-direct {v1, v7, v8, v9, v6}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$2$1;-><init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;JLX/CR1;)V

    .line 118
    .line 119
    .line 120
    invoke-interface {p4, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    :cond_7
    check-cast v1, LX/JDM;

    .line 124
    .line 125
    shr-int/lit8 v0, v4, 0x6

    .line 126
    .line 127
    and-int/lit8 v0, v0, 0xe

    .line 128
    .line 129
    invoke-static {v10, v1, p4, v0}, LX/1vS;->A00(LX/3C1;LX/JDM;LX/2d4;I)V

    .line 130
    .line 131
    .line 132
    :goto_2
    invoke-interface {p4}, LX/2d4;->AAg()LX/J7V;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    if-eqz v0, :cond_8

    .line 137
    .line 138
    new-instance v6, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$3;

    .line 139
    .line 140
    invoke-direct/range {v6 .. v12}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$3;-><init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;JLX/3C1;II)V

    .line 141
    .line 142
    .line 143
    iput-object v6, v0, LX/J7V;->A06:LX/JDN;

    .line 144
    .line 145
    :cond_8
    return-void

    .line 146
    :cond_9
    invoke-interface {p4}, LX/2d4;->AgJ()V

    .line 147
    .line 148
    .line 149
    goto :goto_2

    .line 150
    :cond_a
    and-int/lit16 v0, p0, 0x180

    .line 151
    .line 152
    if-nez v0, :cond_1

    .line 153
    .line 154
    invoke-static {p4, p3}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    or-int/2addr v4, v0

    .line 159
    goto :goto_1

    .line 160
    :cond_b
    move v4, p0

    .line 161
    goto/16 :goto_0
.end method

.method public static final InviteCodeScratchDebris_3IgeMak$lambda$1(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final InviteCodeScratchDebris_3IgeMak$lambda$2(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$InviteCodeScratchDebris_3IgeMak$lambda$1(LX/CR1;)I
    .locals 0

    .line 0
    invoke-interface {p0}, LX/CR1;->AGk()I

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$InviteCodeScratchDebris_3IgeMak$lambda$2(LX/CR1;I)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, LX/CR1;->Ae1(I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$getCrumbleVelocityXRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityXRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getCrumbleVelocityYRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityYRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getParticleGravity$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleGravity:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getParticleSizeRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleSizeRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getRevealBurstInset$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealBurstInset:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getRevealBurstYRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealBurstYRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getRevealParticleSizeRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealParticleSizeRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getRevealVelocityXRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityXRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getRevealVelocityYRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityYRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getScratchVelocityXRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityXRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$getScratchVelocityYRange$p()LX/34c;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityYRange:LX/34c;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final synthetic access$randomFloat(LX/34i;)F
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->randomFloat(LX/34i;)F

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final randomFloat(LX/34i;)F
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/34i<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/34c;->AKx()Ljava/lang/Comparable;

    .line 1
    .line 2
    .line 3
    move-result-object v4

    .line 4
    check-cast v4, Ljava/lang/Number;

    .line 5
    .line 6
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 7
    .line 8
    .line 9
    move-result v3

    .line 10
    sget-object v0, LX/Fqh;->A01:LX/Fqh;

    .line 11
    .line 12
    invoke-virtual {v0}, LX/Fqh;->A02()F

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    invoke-interface {p0}, LX/34c;->AFG()Ljava/lang/Comparable;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, LX/001;->A04(Ljava/lang/Object;)F

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    sub-float/2addr v1, v0

    .line 29
    mul-float/2addr v2, v1

    .line 30
    add-float/2addr v3, v2

    .line 31
    return v3
.end method

.method public static final rememberInviteCodeScratchDebrisState(LX/2d4;I)Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;
    .locals 3

    .line 0
    invoke-static {p0}, LX/005;->A0a(Ljava/lang/Object;)LX/34Y;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    invoke-interface {p0, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 15
    .line 16
    if-ne v1, v0, :cond_1

    .line 17
    .line 18
    :cond_0
    new-instance v1, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 19
    .line 20
    invoke-direct {v1, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;-><init>(LX/34Y;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p0, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_1
    check-cast v1, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 27
    .line 28
    return-object v1
.end method

.method public static final rememberScratchReduceMotionEnabled(LX/2d4;I)Z
    .locals 3

    .line 0
    invoke-static {p0}, LX/005;->A0Q(Ljava/lang/Object;)Landroid/content/Context;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    invoke-interface {p0, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-interface {p0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 15
    .line 16
    if-ne v1, v0, :cond_1

    .line 17
    .line 18
    :cond_0
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    const-string v1, "animator_duration_scale"

    .line 23
    .line 24
    const/high16 v0, 0x3f800000    # 1.0f

    .line 25
    .line 26
    invoke-static {v2, v1, v0}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    const v0, 0x3c23d70a    # 0.01f

    .line 31
    .line 32
    .line 33
    cmpg-float v0, v1, v0

    .line 34
    .line 35
    invoke-static {v0}, LX/007;->A1S(I)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-static {p0, v0}, LX/002;->A0k(LX/2d4;Z)Ljava/lang/Boolean;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :cond_1
    invoke-static {v1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    return v0
.end method
