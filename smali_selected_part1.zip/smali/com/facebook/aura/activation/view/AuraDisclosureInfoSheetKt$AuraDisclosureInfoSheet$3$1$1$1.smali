.class public final synthetic Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3$1$1$1;
.super LX/DRw;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRw;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 0
    const-class v3, Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const-string v5, "back()Z"

    .line 3
    .line 4
    const/16 v6, 0x8

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    const-string v4, "back"

    .line 8
    .line 9
    move-object v0, p0

    .line 10
    move-object v2, p1

    .line 11
    invoke-direct/range {v0 .. v6}, LX/DRw;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$3$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 0

    .line 0
    iget-object p0, p0, LX/DRw;->receiver:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast p0, Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    invoke-interface {p0}, Lcom/facebook/aura/navigation/AuraNavigator;->back()Z

    .line 5
    .line 6
    .line 7
    return-void
.end method
