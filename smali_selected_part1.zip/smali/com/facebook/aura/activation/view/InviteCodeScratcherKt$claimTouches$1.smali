.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final invoke(LX/32h;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/32h;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1$1;-><init>(LX/2M4;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1, p2, v0}, LX/008;->A0z(LX/32h;LX/2M4;LX/JDN;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method
