.class public final Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;

.field public static lambda$262492019:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public static lambda$748256670:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "LX/1Xg;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;

    .line 6
    .line 7
    sget-object v1, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt$lambda$748256670$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt$lambda$748256670$1;

    .line 8
    .line 9
    const v0, 0x2c997d9e

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$748256670:LX/JDQ;

    .line 18
    .line 19
    const v1, 0xfa54f73

    .line 20
    .line 21
    .line 22
    sget-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt$lambda$262492019$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt$lambda$262492019$1;

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$262492019:LX/JDN;

    .line 29
    .line 30
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getLambda$262492019$fbandroid_express_aura_java_com_facebook_aura_activation_view_view()LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$262492019:LX/JDN;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLambda$748256670$fbandroid_express_aura_java_com_facebook_aura_activation_view_view()LX/JDQ;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDQ<",
            "LX/1Xg;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraInviteFriendSheetKt;->lambda$748256670:LX/JDQ;

    .line 1
    .line 2
    return-object p0
.end method
