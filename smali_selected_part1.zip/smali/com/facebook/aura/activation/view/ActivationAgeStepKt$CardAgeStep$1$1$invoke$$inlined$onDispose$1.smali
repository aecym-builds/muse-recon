.class public final Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1$invoke$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/CdD;


# instance fields
.field public final synthetic $presentation$inlined:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1$invoke$$inlined$onDispose$1;->$presentation$inlined:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 2

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1$invoke$$inlined$onDispose$1;->$presentation$inlined:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->release(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
