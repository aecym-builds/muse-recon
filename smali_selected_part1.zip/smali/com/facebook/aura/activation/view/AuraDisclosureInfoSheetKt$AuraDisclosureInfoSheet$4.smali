.class public final Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;->$banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 8

    .line 0
    and-int/lit8 v1, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    const/4 v6, 0x0

    .line 5
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLargePlusMicro:F

    .line 16
    .line 17
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMicro:F

    .line 18
    .line 19
    add-float/2addr v1, v0

    .line 20
    invoke-static {v1}, LX/Dn6;->A00(F)LX/CP5;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/4 v7, 0x0

    .line 25
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 26
    .line 27
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 28
    .line 29
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$4;->$banner:Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;

    .line 34
    .line 35
    invoke-static {v2, p2, v6}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    move-object v5, p2

    .line 40
    check-cast v5, LX/J7I;

    .line 41
    .line 42
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    invoke-static {p2, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 55
    .line 56
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 57
    .line 58
    if-nez v0, :cond_0

    .line 59
    .line 60
    invoke-static {}, LX/1VY;->A00()V

    .line 61
    .line 62
    .line 63
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    throw v0

    .line 68
    :cond_0
    invoke-static {p2, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 69
    .line 70
    .line 71
    invoke-static {p2, p0, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 72
    .line 73
    .line 74
    const v0, 0x1e4b476f

    .line 75
    .line 76
    .line 77
    invoke-interface {p2, v0}, LX/2d4;->Agj(I)V

    .line 78
    .line 79
    .line 80
    iget-object v0, p1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoBanner;->sections:LX/Ddn;

    .line 81
    .line 82
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_1

    .line 91
    .line 92
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    check-cast v1, Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;

    .line 97
    .line 98
    const/4 v0, 0x2

    .line 99
    invoke-static {v1, v7, p2, v6, v0}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt;->InfoSheetSectionContent(Lcom/facebook/aura/activation/model/AuraDisclosureViewModel$InfoSheetSection;LX/3C1;LX/2d4;II)V

    .line 100
    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_1
    invoke-static {v5}, LX/003;->A0u(LX/J7I;)V

    .line 104
    .line 105
    .line 106
    return-void

    .line 107
    :cond_2
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 108
    .line 109
    .line 110
    return-void
.end method
