.class public abstract Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CODE_SEPARATOR:Ljava/lang/String; = " "

.field public static final COVERAGE_COLUMNS:I = 0x24

.field public static final COVERAGE_ROWS:I = 0x6

.field public static final CopyButtonReservedWidth:F

.field public static final CopyIconEndInset:F

.field public static final CopyIconSize:F

.field public static final CopyTapTarget:F

.field public static final REVEAL_COVERAGE:F = 0.6f

.field public static final REVEAL_DURATION_MS:I = 0x208

.field public static final RevealDrop:F

.field public static final SCRATCH_LABEL_SHIMMER_DURATION_MS:I = 0x578

.field public static final ScratchCoverageRadius:F

.field public static final ScratchHapticSpacing:F

.field public static final ScratchLabelShimmer:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LX/JOw;",
            ">;"
        }
    .end annotation
.end field

.field public static final ScratchRadius:F

.field public static final ScratchSampleSpacing:F

.field public static final ScratchSheenDark:J

.field public static final ScratchSheenLight:J

.field public static final ScratcherHeight:F


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 0
    const/high16 v0, 0x42580000    # 54.0f

    .line 1
    .line 2
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratcherHeight:F

    .line 3
    .line 4
    const/high16 v0, 0x41900000    # 18.0f

    .line 5
    .line 6
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchRadius:F

    .line 7
    .line 8
    const v0, 0x419e6666    # 19.8f

    .line 9
    .line 10
    .line 11
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchCoverageRadius:F

    .line 12
    .line 13
    const/high16 v0, 0x40800000    # 4.0f

    .line 14
    .line 15
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSampleSpacing:F

    .line 16
    .line 17
    const/high16 v0, 0x41400000    # 12.0f

    .line 18
    .line 19
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchHapticSpacing:F

    .line 20
    .line 21
    const/high16 v0, 0x41200000    # 10.0f

    .line 22
    .line 23
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->RevealDrop:F

    .line 24
    .line 25
    const/high16 v2, 0x42400000    # 48.0f

    .line 26
    .line 27
    sput v2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyTapTarget:F

    .line 28
    .line 29
    const/high16 v0, 0x41a00000    # 20.0f

    .line 30
    .line 31
    sput v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyIconSize:F

    .line 32
    .line 33
    const/high16 v1, 0x41800000    # 16.0f

    .line 34
    .line 35
    sput v1, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyIconEndInset:F

    .line 36
    .line 37
    add-float/2addr v1, v2

    .line 38
    invoke-static {v2, v0}, LX/002;->A00(FF)F

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    sub-float/2addr v1, v0

    .line 43
    sput v1, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyButtonReservedWidth:F

    .line 44
    .line 45
    const-wide v3, 0xfff7f7f7L

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    const/16 v2, 0x20

    .line 51
    .line 52
    shl-long/2addr v3, v2

    .line 53
    sget-wide v0, LX/JOw;->A01:J

    .line 54
    .line 55
    sput-wide v3, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSheenLight:J

    .line 56
    .line 57
    const-wide/32 v0, 0x1fffffff

    .line 58
    .line 59
    .line 60
    shl-long/2addr v0, v2

    .line 61
    sput-wide v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSheenDark:J

    .line 62
    .line 63
    const-wide/32 v7, 0xd8ecff

    .line 64
    .line 65
    .line 66
    shl-long/2addr v7, v2

    .line 67
    invoke-static {v7, v8}, LX/001;->A0d(J)LX/JOw;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    const-wide/32 v4, 0x22d8ecff

    .line 72
    .line 73
    .line 74
    shl-long/2addr v4, v2

    .line 75
    invoke-static {v4, v5}, LX/001;->A0d(J)LX/JOw;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    const-wide v0, 0x88eff8ffL

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    invoke-static {v0, v1}, LX/002;->A0c(J)LX/JOw;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-static {v4, v5}, LX/001;->A0d(J)LX/JOw;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-static {v7, v8}, LX/001;->A0d(J)LX/JOw;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    filled-new-array {v6, v3, v2, v1, v0}, [LX/JOw;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    sput-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchLabelShimmer:Ljava/util/List;

    .line 105
    .line 106
    return-void
.end method

.method public static final CopyCodeButton(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    const v0, -0x2e09f43f

    .line 3
    .line 4
    .line 5
    move-object/from16 v8, p2

    .line 6
    .line 7
    invoke-interface {v8, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v4, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v6, p0

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    invoke-static {v8, v6}, LX/004;->A0P(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v7

    .line 22
    or-int v7, v7, p3

    .line 23
    .line 24
    :goto_0
    move/from16 v3, p4

    .line 25
    .line 26
    and-int/lit8 v2, p4, 0x2

    .line 27
    .line 28
    if-eqz v2, :cond_2

    .line 29
    .line 30
    or-int/lit8 v7, v7, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    and-int/lit8 v1, v7, 0x13

    .line 33
    .line 34
    const/16 v0, 0x12

    .line 35
    .line 36
    const/4 v13, 0x0

    .line 37
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, v8, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_4

    .line 46
    .line 47
    if-eqz v2, :cond_1

    .line 48
    .line 49
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 50
    .line 51
    :cond_1
    sget v2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyIconEndInset:F

    .line 52
    .line 53
    sget v1, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyTapTarget:F

    .line 54
    .line 55
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyIconSize:F

    .line 56
    .line 57
    invoke-static {v1, v0}, LX/002;->A00(FF)F

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    sub-float/2addr v2, v0

    .line 62
    const/4 v14, 0x0

    .line 63
    const/4 v0, 0x0

    .line 64
    invoke-static {v5, v0, v0, v2, v0}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v0, v1, v1}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-static {v13}, LX/1Y9;->A01(I)LX/1Y9;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    const/4 v7, 0x1

    .line 77
    invoke-static {v1, v0, v14, v6, v7}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 82
    .line 83
    .line 84
    move-result-object v12

    .line 85
    move-object v2, v8

    .line 86
    check-cast v2, LX/J7I;

    .line 87
    .line 88
    invoke-static {v2}, LX/003;->A0F(LX/J7I;)I

    .line 89
    .line 90
    .line 91
    move-result v11

    .line 92
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 93
    .line 94
    .line 95
    move-result-object v10

    .line 96
    invoke-static {v8, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 97
    .line 98
    .line 99
    move-result-object v9

    .line 100
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 101
    .line 102
    iget-object v0, v2, LX/J7I;->A0V:LX/3DJ;

    .line 103
    .line 104
    if-nez v0, :cond_5

    .line 105
    .line 106
    invoke-static {}, LX/1VY;->A00()V

    .line 107
    .line 108
    .line 109
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    throw v0

    .line 114
    :cond_2
    and-int/lit8 v0, p3, 0x30

    .line 115
    .line 116
    if-nez v0, :cond_0

    .line 117
    .line 118
    invoke-static {v8, v5}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    or-int/2addr v7, v0

    .line 123
    goto :goto_1

    .line 124
    :cond_3
    move v7, v4

    .line 125
    goto :goto_0

    .line 126
    :cond_4
    invoke-interface {v8}, LX/2d4;->AgJ()V

    .line 127
    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_5
    invoke-static {v8, v2, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v8, v12, v10, v9, v11}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 134
    .line 135
    .line 136
    const v0, 0x7f080113

    .line 137
    .line 138
    .line 139
    invoke-static {v8, v0, v13}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 140
    .line 141
    .line 142
    move-result-object v15

    .line 143
    sget-object v16, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 144
    .line 145
    const v0, 0x7f1209cc

    .line 146
    .line 147
    .line 148
    invoke-static {v8, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v17

    .line 152
    invoke-static {v8}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    iget-wide v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->link:J

    .line 157
    .line 158
    invoke-static {}, LX/2l9;->A03()I

    .line 159
    .line 160
    .line 161
    move-result p3

    .line 162
    const/16 p4, 0x21

    .line 163
    .line 164
    move-object/from16 p1, v14

    .line 165
    .line 166
    move-wide/from16 v18, v0

    .line 167
    .line 168
    invoke-static/range {v14 .. v23}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 169
    .line 170
    .line 171
    invoke-static {v2, v7}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 172
    .line 173
    .line 174
    :goto_2
    invoke-interface {v8}, LX/2d4;->AAg()LX/J7V;

    .line 175
    .line 176
    .line 177
    move-result-object v1

    .line 178
    if-eqz v1, :cond_6

    .line 179
    .line 180
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$CopyCodeButton$2;

    .line 181
    .line 182
    invoke-direct {v0, v6, v5, v4, v3}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$CopyCodeButton$2;-><init>(Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 183
    .line 184
    .line 185
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 186
    .line 187
    :cond_6
    return-void
.end method

.method public static final InviteCodeScratcher(Ljava/lang/String;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 61
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v29, p4

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    move-object/from16 v59, p2

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    move-object/from16 v0, v59

    .line 8
    .line 9
    invoke-static {v2, v0, v1}, LX/003;->A0J(Ljava/lang/Object;Ljava/lang/Object;I)I

    .line 10
    .line 11
    .line 12
    move-result v42

    .line 13
    const/16 v30, 0x3

    .line 14
    .line 15
    move-object/from16 v58, p3

    .line 16
    .line 17
    move/from16 v2, v30

    .line 18
    .line 19
    move-object/from16 v0, v58

    .line 20
    .line 21
    invoke-static {v0, v2}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 22
    .line 23
    .line 24
    const v2, -0x11db1166

    .line 25
    .line 26
    .line 27
    move-object/from16 v0, p5

    .line 28
    .line 29
    invoke-interface {v0, v2}, LX/2d4;->Agl(I)V

    .line 30
    .line 31
    .line 32
    move/from16 v31, p6

    .line 33
    .line 34
    and-int/lit8 v2, p6, 0x6

    .line 35
    .line 36
    const/4 v6, 0x4

    .line 37
    if-nez v2, :cond_e

    .line 38
    .line 39
    move-object/from16 v2, p0

    .line 40
    .line 41
    invoke-static {v0, v2}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    or-int v5, v5, p6

    .line 46
    .line 47
    :goto_0
    and-int/lit8 v2, p6, 0x30

    .line 48
    .line 49
    move/from16 v60, p1

    .line 50
    .line 51
    if-nez v2, :cond_0

    .line 52
    .line 53
    move/from16 v2, v60

    .line 54
    .line 55
    invoke-static {v0, v2}, LX/004;->A0j(LX/2d4;Z)I

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    or-int/2addr v5, v2

    .line 60
    :cond_0
    move/from16 v2, v31

    .line 61
    .line 62
    and-int/lit16 v2, v2, 0x180

    .line 63
    .line 64
    if-nez v2, :cond_1

    .line 65
    .line 66
    move-object/from16 v2, v59

    .line 67
    .line 68
    invoke-static {v0, v2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    or-int/2addr v5, v2

    .line 73
    :cond_1
    move/from16 v2, v31

    .line 74
    .line 75
    and-int/lit16 v2, v2, 0xc00

    .line 76
    .line 77
    if-nez v2, :cond_2

    .line 78
    .line 79
    move-object/from16 v2, v58

    .line 80
    .line 81
    invoke-static {v0, v2}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    or-int/2addr v5, v2

    .line 86
    :cond_2
    move/from16 v57, p7

    .line 87
    .line 88
    and-int/lit8 v3, p7, 0x10

    .line 89
    .line 90
    if-eqz v3, :cond_d

    .line 91
    .line 92
    or-int/lit16 v5, v5, 0x6000

    .line 93
    .line 94
    :cond_3
    :goto_1
    invoke-static {v5}, LX/009;->A1I(I)Z

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    invoke-static {v2, v0, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    if-eqz v2, :cond_20

    .line 103
    .line 104
    if-eqz v3, :cond_4

    .line 105
    .line 106
    sget-object v29, LX/3C1;->A00:LX/3Cb;

    .line 107
    .line 108
    :cond_4
    and-int/lit8 v28, v5, 0xe

    .line 109
    .line 110
    and-int/lit8 v4, v5, 0x7e

    .line 111
    .line 112
    move-object/from16 v3, p0

    .line 113
    .line 114
    move/from16 v2, v60

    .line 115
    .line 116
    invoke-static {v3, v2, v0, v4}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->isInviteCodeFoilCovering(Ljava/lang/String;ZLX/2d4;I)Z

    .line 117
    .line 118
    .line 119
    move-result v27

    .line 120
    xor-int/lit8 v8, v27, 0x1

    .line 121
    .line 122
    sget-object v26, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 123
    .line 124
    const/16 v49, 0x6

    .line 125
    .line 126
    sget-object v2, LX/3Fe;->A08:LX/Ip3;

    .line 127
    .line 128
    invoke-static {v2, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v4

    .line 132
    check-cast v4, LX/1sR;

    .line 133
    .line 134
    invoke-static {v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->rememberScratchReduceMotionEnabled(LX/2d4;I)Z

    .line 135
    .line 136
    .line 137
    move-result v25

    .line 138
    invoke-static {v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->rememberInviteCodeScratchDebrisState(LX/2d4;I)Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 139
    .line 140
    .line 141
    move-result-object v51

    .line 142
    move/from16 v2, v28

    .line 143
    .line 144
    invoke-static {v2, v6}, LX/003;->A1I(II)Z

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v9

    .line 152
    const/16 v24, 0x0

    .line 153
    .line 154
    if-nez v2, :cond_5

    .line 155
    .line 156
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 157
    .line 158
    if-ne v9, v2, :cond_6

    .line 159
    .line 160
    :cond_5
    invoke-static {v0, v1}, LX/005;->A0Y(LX/2d4;Z)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 161
    .line 162
    .line 163
    move-result-object v9

    .line 164
    :cond_6
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .line 165
    .line 166
    const/high16 v7, 0x3f800000    # 1.0f

    .line 167
    .line 168
    if-nez v27, :cond_7

    .line 169
    .line 170
    const/4 v7, 0x0

    .line 171
    :cond_7
    sget-object v3, LX/33X;->A00:LX/1V8;

    .line 172
    .line 173
    const/16 v2, 0x208

    .line 174
    .line 175
    invoke-static {v3, v2, v1}, LX/001;->A0S(LX/1V8;II)LX/E1b;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    const/16 v3, 0xc00

    .line 180
    .line 181
    const/16 v2, 0x14

    .line 182
    .line 183
    const/16 v23, 0x0

    .line 184
    .line 185
    invoke-static {v6, v0, v7, v3, v2}, LX/34R;->A01(LX/DwJ;LX/2d4;FII)LX/16A;

    .line 186
    .line 187
    .line 188
    move-result-object v22

    .line 189
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    sget-object v3, LX/2d6;->A00:Ljava/lang/Object;

    .line 194
    .line 195
    if-ne v6, v3, :cond_8

    .line 196
    .line 197
    new-instance v7, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$isFoilVisible$2$1;

    .line 198
    .line 199
    move-object/from16 v2, v22

    .line 200
    .line 201
    invoke-direct {v7, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$isFoilVisible$2$1;-><init>(LX/16A;)V

    .line 202
    .line 203
    .line 204
    new-instance v6, LX/J75;

    .line 205
    .line 206
    move-object/from16 v2, v24

    .line 207
    .line 208
    invoke-direct {v6, v2, v7}, LX/J75;-><init>(LX/DxE;Lkotlin/jvm/functions/Function0;)V

    .line 209
    .line 210
    .line 211
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_8
    check-cast v6, LX/16A;

    .line 215
    .line 216
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 217
    .line 218
    .line 219
    move-result-object v10

    .line 220
    invoke-static {v9}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 221
    .line 222
    .line 223
    move-result v2

    .line 224
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 225
    .line 226
    .line 227
    move-result-object v7

    .line 228
    invoke-interface {v0, v8}, LX/2d4;->A6A(Z)Z

    .line 229
    .line 230
    .line 231
    move-result v2

    .line 232
    invoke-static {v0, v9, v2}, LX/001;->A1V(LX/2d4;Ljava/lang/Object;Z)Z

    .line 233
    .line 234
    .line 235
    move-result v11

    .line 236
    move/from16 v2, v25

    .line 237
    .line 238
    invoke-interface {v0, v2}, LX/2d4;->A6A(Z)Z

    .line 239
    .line 240
    .line 241
    move-result v2

    .line 242
    invoke-static {v0, v4, v11, v2}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 243
    .line 244
    .line 245
    move-result v11

    .line 246
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v2

    .line 250
    if-nez v11, :cond_9

    .line 251
    .line 252
    if-ne v2, v3, :cond_a

    .line 253
    .line 254
    :cond_9
    new-instance v2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;

    .line 255
    .line 256
    move-object v11, v2

    .line 257
    move v12, v8

    .line 258
    move/from16 v13, v25

    .line 259
    .line 260
    move-object v14, v4

    .line 261
    move-object v15, v9

    .line 262
    move-object/from16 v16, v24

    .line 263
    .line 264
    invoke-direct/range {v11 .. v16}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$1$1;-><init>(ZZLX/1sR;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 265
    .line 266
    .line 267
    invoke-interface {v0, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    :cond_a
    invoke-static {v0, v2, v10, v7}, LX/001;->A1J(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    invoke-interface {v0, v8}, LX/2d4;->A6A(Z)Z

    .line 274
    .line 275
    .line 276
    move-result v2

    .line 277
    invoke-static {v0, v9, v4, v2}, LX/004;->A1X(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 278
    .line 279
    .line 280
    move-result v10

    .line 281
    invoke-static {v5}, LX/005;->A1L(I)Z

    .line 282
    .line 283
    .line 284
    move-result v2

    .line 285
    or-int/2addr v10, v2

    .line 286
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v7

    .line 290
    if-nez v10, :cond_b

    .line 291
    .line 292
    if-ne v7, v3, :cond_c

    .line 293
    .line 294
    :cond_b
    new-instance v7, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;

    .line 295
    .line 296
    move-object/from16 v2, v58

    .line 297
    .line 298
    invoke-direct {v7, v8, v4, v2, v9}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$reveal$1$1;-><init>(ZLX/1sR;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 299
    .line 300
    .line 301
    invoke-interface {v0, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 302
    .line 303
    .line 304
    :cond_c
    check-cast v7, Lkotlin/jvm/functions/Function0;

    .line 305
    .line 306
    sget-object v11, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 307
    .line 308
    invoke-static {v11, v1}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 309
    .line 310
    .line 311
    move-result-object v13

    .line 312
    move-object v2, v0

    .line 313
    check-cast v2, LX/J7I;

    .line 314
    .line 315
    iget-wide v8, v2, LX/J7I;->A06:J

    .line 316
    .line 317
    invoke-static {v8, v9}, LX/001;->A0A(J)I

    .line 318
    .line 319
    .line 320
    move-result v10

    .line 321
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 322
    .line 323
    .line 324
    move-result-object v9

    .line 325
    move-object/from16 v8, v29

    .line 326
    .line 327
    invoke-static {v0, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 328
    .line 329
    .line 330
    move-result-object v12

    .line 331
    sget-object v21, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 332
    .line 333
    iget-object v8, v2, LX/J7I;->A0V:LX/3DJ;

    .line 334
    .line 335
    if-nez v8, :cond_f

    .line 336
    .line 337
    invoke-static {}, LX/1VY;->A00()V

    .line 338
    .line 339
    .line 340
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    throw v0

    .line 345
    :cond_d
    move/from16 v2, v31

    .line 346
    .line 347
    and-int/lit16 v2, v2, 0x6000

    .line 348
    .line 349
    if-nez v2, :cond_3

    .line 350
    .line 351
    move-object/from16 v2, v29

    .line 352
    .line 353
    invoke-static {v0, v2}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 354
    .line 355
    .line 356
    move-result v2

    .line 357
    or-int/2addr v5, v2

    .line 358
    goto/16 :goto_1

    .line 359
    .line 360
    :cond_e
    move/from16 v5, v31

    .line 361
    .line 362
    goto/16 :goto_0

    .line 363
    .line 364
    :cond_f
    move-object/from16 v8, v21

    .line 365
    .line 366
    invoke-static {v0, v2, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 367
    .line 368
    .line 369
    sget-object v15, LX/3Cl;->A04:LX/JDN;

    .line 370
    .line 371
    invoke-static {v0, v13, v15}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 372
    .line 373
    .line 374
    move-result-object v14

    .line 375
    invoke-static {v0, v9, v14, v10}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 376
    .line 377
    .line 378
    move-result-object v17

    .line 379
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 380
    .line 381
    invoke-static {v0, v12, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 382
    .line 383
    .line 384
    move-result-object v16

    .line 385
    sget-object v20, LX/3Jn;->A00:LX/3Jn;

    .line 386
    .line 387
    sget-object v19, LX/3C1;->A00:LX/3Cb;

    .line 388
    .line 389
    sget-object v18, LX/2sI;->A02:LX/2wD;

    .line 390
    .line 391
    sget v9, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratcherHeight:F

    .line 392
    .line 393
    move-object/from16 v8, v18

    .line 394
    .line 395
    invoke-static {v8, v9}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 396
    .line 397
    .line 398
    move-result-object v9

    .line 399
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraShapesKt;->LocalAuraShapes:LX/Ip3;

    .line 400
    .line 401
    invoke-static {v8, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 402
    .line 403
    .line 404
    move-result-object v8

    .line 405
    check-cast v8, Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 406
    .line 407
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->large:LX/2bW;

    .line 408
    .line 409
    invoke-static {v9, v8}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 410
    .line 411
    .line 412
    move-result-object v12

    .line 413
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 414
    .line 415
    invoke-static {v8, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 416
    .line 417
    .line 418
    move-result-object v8

    .line 419
    check-cast v8, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 420
    .line 421
    iget-wide v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryElevated:J

    .line 422
    .line 423
    invoke-static {v12, v8, v9}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 424
    .line 425
    .line 426
    move-result-object v8

    .line 427
    invoke-static {v11, v1}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 428
    .line 429
    .line 430
    move-result-object v13

    .line 431
    invoke-static {v2}, LX/002;->A0J(LX/J7I;)I

    .line 432
    .line 433
    .line 434
    move-result v12

    .line 435
    invoke-static {v2}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 436
    .line 437
    .line 438
    move-result-object v11

    .line 439
    invoke-static {v0, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 440
    .line 441
    .line 442
    move-result-object v9

    .line 443
    move-object/from16 v8, v21

    .line 444
    .line 445
    invoke-static {v0, v2, v8}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 446
    .line 447
    .line 448
    invoke-static {v0, v13, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 449
    .line 450
    .line 451
    invoke-static {v0, v11, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 452
    .line 453
    .line 454
    move-object/from16 v8, v17

    .line 455
    .line 456
    invoke-static {v10, v8, v0, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 457
    .line 458
    .line 459
    move-object/from16 v8, v16

    .line 460
    .line 461
    invoke-static {v0, v9, v8}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 462
    .line 463
    .line 464
    invoke-static/range {v28 .. v28}, LX/004;->A1Q(I)Z

    .line 465
    .line 466
    .line 467
    move-result v8

    .line 468
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 469
    .line 470
    .line 471
    move-result-object v10

    .line 472
    if-nez v8, :cond_10

    .line 473
    .line 474
    if-ne v10, v3, :cond_13

    .line 475
    .line 476
    :cond_10
    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->toCharArray()[C

    .line 477
    .line 478
    .line 479
    move-result-object v13

    .line 480
    const-string v17, " "

    .line 481
    .line 482
    const-string v12, ""

    .line 483
    .line 484
    invoke-static {}, LX/001;->A0x()Ljava/lang/StringBuilder;

    .line 485
    .line 486
    .line 487
    move-result-object v11

    .line 488
    const/16 v16, 0x1

    .line 489
    .line 490
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 491
    .line 492
    .line 493
    array-length v15, v13

    .line 494
    const/4 v10, 0x0

    .line 495
    const/4 v9, 0x0

    .line 496
    :goto_2
    if-ge v10, v15, :cond_12

    .line 497
    .line 498
    aget-char v14, v13, v10

    .line 499
    .line 500
    add-int/lit8 v9, v9, 0x1

    .line 501
    .line 502
    move/from16 v8, v16

    .line 503
    .line 504
    if-le v9, v8, :cond_11

    .line 505
    .line 506
    move-object/from16 v8, v17

    .line 507
    .line 508
    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 509
    .line 510
    .line 511
    :cond_11
    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    .line 512
    .line 513
    .line 514
    add-int/lit8 v10, v10, 0x1

    .line 515
    .line 516
    goto :goto_2

    .line 517
    :cond_12
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 518
    .line 519
    .line 520
    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 521
    .line 522
    .line 523
    move-result-object v10

    .line 524
    invoke-interface {v0, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 525
    .line 526
    .line 527
    :cond_13
    check-cast v10, Ljava/lang/String;

    .line 528
    .line 529
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 530
    .line 531
    invoke-static {v8, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 532
    .line 533
    .line 534
    move-result-object v8

    .line 535
    check-cast v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 536
    .line 537
    iget-object v13, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->title2Emphasized:LX/2hg;

    .line 538
    .line 539
    move-object/from16 v8, v26

    .line 540
    .line 541
    invoke-static {v0, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 542
    .line 543
    .line 544
    move-result-wide v34

    .line 545
    const/4 v12, 0x1

    .line 546
    sget v11, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyButtonReservedWidth:F

    .line 547
    .line 548
    move/from16 v9, v23

    .line 549
    .line 550
    move-object/from16 v8, v18

    .line 551
    .line 552
    invoke-static {v8, v11, v9}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 553
    .line 554
    .line 555
    move-result-object v11

    .line 556
    if-nez v27, :cond_1e

    .line 557
    .line 558
    const v8, -0x7c45c55c

    .line 559
    .line 560
    .line 561
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 562
    .line 563
    .line 564
    const v9, 0x7f1204b8

    .line 565
    .line 566
    .line 567
    move-object/from16 v8, p0

    .line 568
    .line 569
    invoke-static {v0, v8, v9}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 570
    .line 571
    .line 572
    move-result-object v8

    .line 573
    invoke-interface {v0, v8}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 574
    .line 575
    .line 576
    move-result v14

    .line 577
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 578
    .line 579
    .line 580
    move-result-object v9

    .line 581
    if-nez v14, :cond_14

    .line 582
    .line 583
    if-ne v9, v3, :cond_15

    .line 584
    .line 585
    :cond_14
    new-instance v9, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$2$1;

    .line 586
    .line 587
    invoke-direct {v9, v8}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$2$1;-><init>(Ljava/lang/String;)V

    .line 588
    .line 589
    .line 590
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 591
    .line 592
    .line 593
    :cond_15
    move-object/from16 v8, v19

    .line 594
    .line 595
    invoke-static {v8, v9, v1}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 596
    .line 597
    .line 598
    move-result-object v8

    .line 599
    :goto_3
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 600
    .line 601
    .line 602
    invoke-interface {v11, v8}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 603
    .line 604
    .line 605
    move-result-object v33

    .line 606
    invoke-static/range {v30 .. v30}, LX/2wS;->A01(I)LX/2wS;

    .line 607
    .line 608
    .line 609
    move-result-object v39

    .line 610
    const/16 v50, 0x39b0

    .line 611
    .line 612
    const/high16 v48, 0x30000000

    .line 613
    .line 614
    move-object/from16 v32, v10

    .line 615
    .line 616
    move-object/from16 v36, v13

    .line 617
    .line 618
    move-object/from16 v37, v24

    .line 619
    .line 620
    move-object/from16 v38, v24

    .line 621
    .line 622
    move/from16 v40, v1

    .line 623
    .line 624
    move/from16 v41, v1

    .line 625
    .line 626
    move/from16 v43, v42

    .line 627
    .line 628
    move-object/from16 v44, v24

    .line 629
    .line 630
    move-object/from16 v45, v24

    .line 631
    .line 632
    move-object/from16 v46, v24

    .line 633
    .line 634
    move-object/from16 v47, v0

    .line 635
    .line 636
    invoke-static/range {v32 .. v50}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 637
    .line 638
    .line 639
    if-nez v27, :cond_1d

    .line 640
    .line 641
    const v8, -0x7c400178

    .line 642
    .line 643
    .line 644
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 645
    .line 646
    .line 647
    invoke-static {v5}, LX/005;->A1J(I)Z

    .line 648
    .line 649
    .line 650
    move-result v9

    .line 651
    invoke-static/range {v28 .. v28}, LX/004;->A1Q(I)Z

    .line 652
    .line 653
    .line 654
    move-result v8

    .line 655
    or-int/2addr v9, v8

    .line 656
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 657
    .line 658
    .line 659
    move-result-object v10

    .line 660
    if-nez v9, :cond_16

    .line 661
    .line 662
    if-ne v10, v3, :cond_17

    .line 663
    .line 664
    :cond_16
    new-instance v10, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$4$1;

    .line 665
    .line 666
    move-object/from16 v9, v59

    .line 667
    .line 668
    move-object/from16 v8, p0

    .line 669
    .line 670
    invoke-direct {v10, v9, v8}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$4$1;-><init>(LX/JDM;Ljava/lang/String;)V

    .line 671
    .line 672
    .line 673
    invoke-interface {v0, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 674
    .line 675
    .line 676
    :cond_17
    check-cast v10, Lkotlin/jvm/functions/Function0;

    .line 677
    .line 678
    sget-object v11, LX/2Id;->A0A:Landroidx/compose/ui/Alignment;

    .line 679
    .line 680
    move-object/from16 v9, v20

    .line 681
    .line 682
    move-object/from16 v8, v19

    .line 683
    .line 684
    invoke-virtual {v9, v11, v8}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 685
    .line 686
    .line 687
    move-result-object v8

    .line 688
    invoke-static {v10, v8, v0, v1, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyCodeButton(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 689
    .line 690
    .line 691
    :goto_4
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 692
    .line 693
    .line 694
    invoke-static {v6}, LX/16A;->A0C(LX/16A;)Z

    .line 695
    .line 696
    .line 697
    move-result v6

    .line 698
    if-eqz v6, :cond_1c

    .line 699
    .line 700
    const v8, -0x7c3ddafa

    .line 701
    .line 702
    .line 703
    move-object/from16 v6, v22

    .line 704
    .line 705
    invoke-static {v6, v0, v8}, LX/002;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 706
    .line 707
    .line 708
    move-result v6

    .line 709
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 710
    .line 711
    .line 712
    move-result-object v8

    .line 713
    if-nez v6, :cond_18

    .line 714
    .line 715
    if-ne v8, v3, :cond_19

    .line 716
    .line 717
    :cond_18
    new-instance v8, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$5$1;

    .line 718
    .line 719
    move-object/from16 v6, v22

    .line 720
    .line 721
    invoke-direct {v8, v6}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$5$1;-><init>(LX/16A;)V

    .line 722
    .line 723
    .line 724
    invoke-interface {v0, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 725
    .line 726
    .line 727
    :cond_19
    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 728
    .line 729
    invoke-interface {v0, v4}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 730
    .line 731
    .line 732
    move-result v9

    .line 733
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 734
    .line 735
    .line 736
    move-result-object v6

    .line 737
    if-nez v9, :cond_1a

    .line 738
    .line 739
    if-ne v6, v3, :cond_1b

    .line 740
    .line 741
    :cond_1a
    new-instance v6, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$6$1;

    .line 742
    .line 743
    invoke-direct {v6, v4}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$6$1;-><init>(LX/1sR;)V

    .line 744
    .line 745
    .line 746
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 747
    .line 748
    .line 749
    :cond_1b
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 750
    .line 751
    shl-int/lit8 v3, v5, 0x3

    .line 752
    .line 753
    and-int/lit8 v3, v3, 0x70

    .line 754
    .line 755
    or-int/lit8 v56, v3, 0x6

    .line 756
    .line 757
    sget v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->$stable:I

    .line 758
    .line 759
    shl-int/lit8 v3, v3, 0x9

    .line 760
    .line 761
    or-int v56, v56, v3

    .line 762
    .line 763
    move-object/from16 v48, v20

    .line 764
    .line 765
    move-object/from16 v49, p0

    .line 766
    .line 767
    move-object/from16 v50, v8

    .line 768
    .line 769
    move/from16 v52, v25

    .line 770
    .line 771
    move-object/from16 v53, v6

    .line 772
    .line 773
    move-object/from16 v54, v7

    .line 774
    .line 775
    move-object/from16 v55, v0

    .line 776
    .line 777
    invoke-static/range {v48 .. v56}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchFoil(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 778
    .line 779
    .line 780
    :goto_5
    invoke-static {v2, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 781
    .line 782
    .line 783
    invoke-static {v2, v12}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 784
    .line 785
    .line 786
    move-object/from16 v3, v26

    .line 787
    .line 788
    invoke-static {v0, v3}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 789
    .line 790
    .line 791
    move-result-wide v5

    .line 792
    move-object/from16 v4, v20

    .line 793
    .line 794
    move-object/from16 v3, v19

    .line 795
    .line 796
    invoke-virtual {v4, v3}, LX/3Jn;->AQU(LX/3C1;)LX/3C1;

    .line 797
    .line 798
    .line 799
    move-result-object v7

    .line 800
    sget v9, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->$stable:I

    .line 801
    .line 802
    move-object v8, v0

    .line 803
    move v10, v1

    .line 804
    move-object/from16 v4, v51

    .line 805
    .line 806
    invoke-static/range {v4 .. v10}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->InviteCodeScratchDebris-3IgeMak(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;JLX/3C1;LX/2d4;II)V

    .line 807
    .line 808
    .line 809
    invoke-static {v2, v12}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 810
    .line 811
    .line 812
    goto :goto_6

    .line 813
    :cond_1c
    const v3, -0x7c38f52c

    .line 814
    .line 815
    .line 816
    invoke-interface {v0, v3}, LX/2d4;->Agj(I)V

    .line 817
    .line 818
    .line 819
    goto :goto_5

    .line 820
    :cond_1d
    const v8, -0x7c3e6c0c

    .line 821
    .line 822
    .line 823
    invoke-interface {v0, v8}, LX/2d4;->Agj(I)V

    .line 824
    .line 825
    .line 826
    goto/16 :goto_4

    .line 827
    .line 828
    :cond_1e
    const v8, -0x7c421f3e

    .line 829
    .line 830
    .line 831
    invoke-static {v0, v8}, LX/002;->A0t(LX/2d4;I)Ljava/lang/Object;

    .line 832
    .line 833
    .line 834
    move-result-object v9

    .line 835
    if-ne v9, v3, :cond_1f

    .line 836
    .line 837
    sget-object v9, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$3$1;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$2$1$3$1;

    .line 838
    .line 839
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 840
    .line 841
    .line 842
    :cond_1f
    move-object/from16 v8, v19

    .line 843
    .line 844
    invoke-static {v8, v9}, LX/001;->A0Y(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 845
    .line 846
    .line 847
    move-result-object v8

    .line 848
    goto/16 :goto_3

    .line 849
    .line 850
    :cond_20
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 851
    .line 852
    .line 853
    :goto_6
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 854
    .line 855
    .line 856
    move-result-object v1

    .line 857
    if-eqz v1, :cond_21

    .line 858
    .line 859
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$3;

    .line 860
    .line 861
    move-object/from16 v50, v0

    .line 862
    .line 863
    move-object/from16 v51, p0

    .line 864
    .line 865
    move/from16 v52, v60

    .line 866
    .line 867
    move-object/from16 v53, v59

    .line 868
    .line 869
    move-object/from16 v54, v58

    .line 870
    .line 871
    move-object/from16 v55, v29

    .line 872
    .line 873
    move/from16 v56, v31

    .line 874
    .line 875
    invoke-direct/range {v50 .. v57}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$InviteCodeScratcher$3;-><init>(Ljava/lang/String;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 876
    .line 877
    .line 878
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 879
    .line 880
    :cond_21
    return-void
.end method

.method public static final InviteCodeScratcher$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final InviteCodeScratcher$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final InviteCodeScratcher$lambda$4(LX/16A;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A0C(LX/16A;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final ScratchFoil(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/33K;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)V"
        }
    .end annotation

    .line 0
    const v0, -0x336082aa    # -8.361848E7f

    .line 1
    .line 2
    .line 3
    move-object/from16 v7, p7

    .line 4
    .line 5
    invoke-interface {v7, v0}, LX/2d4;->Agl(I)V

    .line 6
    .line 7
    .line 8
    move/from16 v6, p8

    .line 9
    .line 10
    and-int/lit8 v0, p8, 0x6

    .line 11
    .line 12
    if-nez v0, :cond_15

    .line 13
    .line 14
    move-object/from16 v0, p0

    .line 15
    .line 16
    invoke-static {v7, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    move-result v10

    .line 20
    or-int v10, v10, p8

    .line 21
    .line 22
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 23
    .line 24
    const/16 v2, 0x20

    .line 25
    .line 26
    move-object/from16 v42, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move-object/from16 v0, v42

    .line 31
    .line 32
    invoke-static {v7, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v10, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v6, 0x180

    .line 38
    .line 39
    move-object/from16 v41, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    move-object/from16 v0, v41

    .line 44
    .line 45
    invoke-static {v7, v0}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v10, v0

    .line 50
    :cond_1
    and-int/lit16 v0, v6, 0xc00

    .line 51
    .line 52
    move-object/from16 v40, p3

    .line 53
    .line 54
    if-nez v0, :cond_2

    .line 55
    .line 56
    move-object/from16 v0, v40

    .line 57
    .line 58
    invoke-static {v0, v7, v6}, LX/005;->A1Z(Ljava/lang/Object;LX/2d4;I)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0}, LX/003;->A02(I)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    or-int/2addr v10, v0

    .line 67
    :cond_2
    and-int/lit16 v0, v6, 0x6000

    .line 68
    .line 69
    move/from16 v39, p4

    .line 70
    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    move/from16 v0, v39

    .line 74
    .line 75
    invoke-static {v7, v0}, LX/004;->A0m(LX/2d4;Z)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    or-int/2addr v10, v0

    .line 80
    :cond_3
    const/high16 v0, 0x30000

    .line 81
    .line 82
    and-int v0, v0, p8

    .line 83
    .line 84
    move-object/from16 v38, p5

    .line 85
    .line 86
    if-nez v0, :cond_4

    .line 87
    .line 88
    move-object/from16 v0, v38

    .line 89
    .line 90
    invoke-static {v7, v0}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    or-int/2addr v10, v0

    .line 95
    :cond_4
    const/high16 v0, 0x180000

    .line 96
    .line 97
    and-int v0, p8, v0

    .line 98
    .line 99
    move-object/from16 v37, p6

    .line 100
    .line 101
    if-nez v0, :cond_5

    .line 102
    .line 103
    move-object/from16 v0, v37

    .line 104
    .line 105
    invoke-static {v7, v0}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    or-int/2addr v10, v0

    .line 110
    :cond_5
    const v0, 0x92493

    .line 111
    .line 112
    .line 113
    and-int v1, v10, v0

    .line 114
    .line 115
    const v0, 0x92492

    .line 116
    .line 117
    .line 118
    const/16 v17, 0x0

    .line 119
    .line 120
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    invoke-static {v0, v7, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_19

    .line 129
    .line 130
    and-int/lit8 v1, v10, 0x70

    .line 131
    .line 132
    invoke-static {v1, v2}, LX/003;->A1I(II)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v9

    .line 140
    if-nez v0, :cond_6

    .line 141
    .line 142
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 143
    .line 144
    if-ne v9, v0, :cond_7

    .line 145
    .line 146
    :cond_6
    new-instance v9, Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 147
    .line 148
    invoke-direct {v9}, Landroidx/compose/runtime/snapshots/SnapshotStateList;-><init>()V

    .line 149
    .line 150
    .line 151
    invoke-interface {v7, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    :cond_7
    check-cast v9, Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 155
    .line 156
    invoke-static {v1, v2}, LX/003;->A1I(II)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v8

    .line 164
    if-nez v0, :cond_8

    .line 165
    .line 166
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 167
    .line 168
    if-ne v8, v0, :cond_9

    .line 169
    .line 170
    :cond_8
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 171
    .line 172
    .line 173
    move-result-object v8

    .line 174
    invoke-interface {v7, v8}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_9
    check-cast v8, Ljava/util/Set;

    .line 178
    .line 179
    const v0, 0x7f1204b5

    .line 180
    .line 181
    .line 182
    invoke-static {v7, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v11

    .line 186
    sget-object v16, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 187
    .line 188
    sget-object v1, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 189
    .line 190
    invoke-static {v1, v7}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 195
    .line 196
    iget-wide v4, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryElevated:J

    .line 197
    .line 198
    invoke-static {v1, v7}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    check-cast v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 203
    .line 204
    iget-boolean v0, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->isLight:Z

    .line 205
    .line 206
    if-eqz v0, :cond_14

    .line 207
    .line 208
    sget-wide v2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSheenLight:J

    .line 209
    .line 210
    :goto_1
    invoke-static {v7}, LX/2fr;->A01(LX/2d4;)LX/2oh;

    .line 211
    .line 212
    .line 213
    move-result-object v15

    .line 214
    sget-object v12, LX/33X;->A02:LX/1V8;

    .line 215
    .line 216
    const/16 v1, 0x578

    .line 217
    .line 218
    move/from16 v0, v17

    .line 219
    .line 220
    invoke-static {v12, v1, v0}, LX/001;->A0S(LX/1V8;II)LX/E1b;

    .line 221
    .line 222
    .line 223
    move-result-object v14

    .line 224
    const/16 v23, 0x0

    .line 225
    .line 226
    sget-object v13, LX/FkO;->A00:Ljava/lang/Integer;

    .line 227
    .line 228
    const-wide/16 v0, 0x0

    .line 229
    .line 230
    new-instance v12, LX/E1X;

    .line 231
    .line 232
    invoke-direct {v12, v14, v13, v0, v1}, LX/E1X;-><init>(LX/E1d;Ljava/lang/Integer;J)V

    .line 233
    .line 234
    .line 235
    const/4 v1, 0x0

    .line 236
    const/high16 v0, 0x3f800000    # 1.0f

    .line 237
    .line 238
    invoke-static {v12, v15, v7, v1, v0}, LX/2fr;->A00(LX/E1X;LX/2oh;LX/2d4;FF)LX/2pp;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 243
    .line 244
    move-object/from16 v12, p0

    .line 245
    .line 246
    invoke-interface {v12, v0}, LX/33K;->AQU(LX/3C1;)LX/3C1;

    .line 247
    .line 248
    .line 249
    move-result-object v14

    .line 250
    invoke-static {v10}, LX/008;->A1Y(I)Z

    .line 251
    .line 252
    .line 253
    move-result v12

    .line 254
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v13

    .line 258
    if-nez v12, :cond_a

    .line 259
    .line 260
    sget-object v12, LX/2d6;->A00:Ljava/lang/Object;

    .line 261
    .line 262
    if-ne v13, v12, :cond_b

    .line 263
    .line 264
    :cond_a
    new-instance v13, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$1$1;

    .line 265
    .line 266
    move-object/from16 v12, v41

    .line 267
    .line 268
    invoke-direct {v13, v12}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$1$1;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 269
    .line 270
    .line 271
    invoke-interface {v7, v13}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 272
    .line 273
    .line 274
    :cond_b
    invoke-static {v14, v13}, LX/2uT;->A00(LX/3C1;Ljava/lang/Object;)LX/3C1;

    .line 275
    .line 276
    .line 277
    move-result-object v14

    .line 278
    invoke-interface {v7, v4, v5}, LX/2d4;->A68(J)Z

    .line 279
    .line 280
    .line 281
    move-result v13

    .line 282
    invoke-interface {v7, v2, v3}, LX/2d4;->A68(J)Z

    .line 283
    .line 284
    .line 285
    move-result v12

    .line 286
    invoke-static {v7, v9, v13, v12}, LX/002;->A1X(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 287
    .line 288
    .line 289
    move-result v13

    .line 290
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v12

    .line 294
    if-nez v13, :cond_c

    .line 295
    .line 296
    sget-object v13, LX/2d6;->A00:Ljava/lang/Object;

    .line 297
    .line 298
    if-ne v12, v13, :cond_d

    .line 299
    .line 300
    :cond_c
    new-instance v12, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;

    .line 301
    .line 302
    move-object/from16 v24, v12

    .line 303
    .line 304
    move-wide/from16 v25, v4

    .line 305
    .line 306
    move-wide/from16 v27, v2

    .line 307
    .line 308
    move-object/from16 v29, v9

    .line 309
    .line 310
    invoke-direct/range {v24 .. v29}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;-><init>(JJLandroidx/compose/runtime/snapshots/SnapshotStateList;)V

    .line 311
    .line 312
    .line 313
    invoke-interface {v7, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    :cond_d
    check-cast v12, LX/JDM;

    .line 317
    .line 318
    invoke-static {v14, v12}, LX/2pJ;->A02(LX/3C1;LX/JDM;)LX/3C1;

    .line 319
    .line 320
    .line 321
    move-result-object v5

    .line 322
    invoke-interface {v7, v9}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 323
    .line 324
    .line 325
    move-result v3

    .line 326
    and-int/lit16 v4, v10, 0x1c00

    .line 327
    .line 328
    const/16 v2, 0x800

    .line 329
    .line 330
    if-eq v4, v2, :cond_e

    .line 331
    .line 332
    and-int/lit16 v2, v10, 0x1000

    .line 333
    .line 334
    if-eqz v2, :cond_13

    .line 335
    .line 336
    move-object/from16 v2, v40

    .line 337
    .line 338
    invoke-interface {v7, v2}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 339
    .line 340
    .line 341
    move-result v2

    .line 342
    if-eqz v2, :cond_13

    .line 343
    .line 344
    :cond_e
    const/4 v2, 0x1

    .line 345
    :goto_2
    or-int/2addr v3, v2

    .line 346
    invoke-static {v10}, LX/005;->A1N(I)Z

    .line 347
    .line 348
    .line 349
    move-result v2

    .line 350
    invoke-static {v7, v8, v3, v2}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 351
    .line 352
    .line 353
    move-result v13

    .line 354
    const/high16 v2, 0x380000

    .line 355
    .line 356
    and-int v12, v10, v2

    .line 357
    .line 358
    const/high16 v4, 0x100000

    .line 359
    .line 360
    invoke-static {v12, v4}, LX/003;->A1I(II)Z

    .line 361
    .line 362
    .line 363
    move-result v2

    .line 364
    or-int/2addr v13, v2

    .line 365
    const/high16 v2, 0x70000

    .line 366
    .line 367
    and-int/2addr v10, v2

    .line 368
    const/high16 v2, 0x20000

    .line 369
    .line 370
    invoke-static {v10, v2}, LX/003;->A1I(II)Z

    .line 371
    .line 372
    .line 373
    move-result v2

    .line 374
    or-int/2addr v13, v2

    .line 375
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v3

    .line 379
    if-nez v13, :cond_f

    .line 380
    .line 381
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 382
    .line 383
    if-ne v3, v2, :cond_10

    .line 384
    .line 385
    :cond_f
    new-instance v3, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;

    .line 386
    .line 387
    move-object/from16 v24, v3

    .line 388
    .line 389
    move-object/from16 v25, v9

    .line 390
    .line 391
    move-object/from16 v26, v40

    .line 392
    .line 393
    move/from16 v27, v39

    .line 394
    .line 395
    move-object/from16 v28, v8

    .line 396
    .line 397
    move-object/from16 v29, v37

    .line 398
    .line 399
    move-object/from16 v30, v38

    .line 400
    .line 401
    invoke-direct/range {v24 .. v30}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1;-><init>(Landroidx/compose/runtime/snapshots/SnapshotStateList;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLjava/util/Set;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 402
    .line 403
    .line 404
    invoke-interface {v7, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    :cond_10
    move-object/from16 v2, v42

    .line 408
    .line 409
    invoke-static {v5, v3, v2}, LX/001;->A0Z(LX/3C1;Ljava/lang/Object;Ljava/lang/Object;)LX/3C1;

    .line 410
    .line 411
    .line 412
    move-result-object v5

    .line 413
    invoke-interface {v7, v11}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 414
    .line 415
    .line 416
    move-result v3

    .line 417
    invoke-static {v12, v4}, LX/003;->A1I(II)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    or-int/2addr v3, v2

    .line 422
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v4

    .line 426
    if-nez v3, :cond_11

    .line 427
    .line 428
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 429
    .line 430
    if-ne v4, v2, :cond_12

    .line 431
    .line 432
    :cond_11
    new-instance v4, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;

    .line 433
    .line 434
    move-object/from16 v2, v37

    .line 435
    .line 436
    invoke-direct {v4, v11, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$4$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 437
    .line 438
    .line 439
    invoke-interface {v7, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 440
    .line 441
    .line 442
    :cond_12
    check-cast v4, LX/JDM;

    .line 443
    .line 444
    const/4 v3, 0x1

    .line 445
    invoke-static {v5, v4, v3}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 446
    .line 447
    .line 448
    move-result-object v5

    .line 449
    sget-object v4, LX/2Id;->A09:Landroidx/compose/ui/Alignment;

    .line 450
    .line 451
    move/from16 v2, v17

    .line 452
    .line 453
    invoke-static {v4, v2}, LX/3Jj;->A01(Landroidx/compose/ui/Alignment;Z)LX/3BI;

    .line 454
    .line 455
    .line 456
    move-result-object v11

    .line 457
    move-object v4, v7

    .line 458
    check-cast v4, LX/J7I;

    .line 459
    .line 460
    invoke-static {v4}, LX/003;->A0F(LX/J7I;)I

    .line 461
    .line 462
    .line 463
    move-result v10

    .line 464
    invoke-static {v4}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 465
    .line 466
    .line 467
    move-result-object v9

    .line 468
    invoke-static {v7, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 469
    .line 470
    .line 471
    move-result-object v8

    .line 472
    sget-object v5, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 473
    .line 474
    iget-object v2, v4, LX/J7I;->A0V:LX/3DJ;

    .line 475
    .line 476
    if-nez v2, :cond_16

    .line 477
    .line 478
    invoke-static {}, LX/1VY;->A00()V

    .line 479
    .line 480
    .line 481
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 482
    .line 483
    .line 484
    move-result-object v0

    .line 485
    throw v0

    .line 486
    :cond_13
    const/4 v2, 0x0

    .line 487
    goto/16 :goto_2

    .line 488
    .line 489
    :cond_14
    sget-wide v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSheenDark:J

    .line 490
    .line 491
    invoke-static {v0, v1, v4, v5}, LX/JOv;->A02(JJ)J

    .line 492
    .line 493
    .line 494
    move-result-wide v2

    .line 495
    goto/16 :goto_1

    .line 496
    .line 497
    :cond_15
    move v10, v6

    .line 498
    goto/16 :goto_0

    .line 499
    .line 500
    :cond_16
    invoke-static {v7, v4, v5}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 501
    .line 502
    .line 503
    invoke-static {v7, v11, v9, v8, v10}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 504
    .line 505
    .line 506
    const v2, 0x7f1204b6

    .line 507
    .line 508
    .line 509
    invoke-static {v7, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 510
    .line 511
    .line 512
    move-result-object v18

    .line 513
    move-object/from16 v2, v16

    .line 514
    .line 515
    invoke-static {v7, v2}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 516
    .line 517
    .line 518
    move-result-object v22

    .line 519
    invoke-static {v7, v2}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 520
    .line 521
    .line 522
    move-result-wide v20

    .line 523
    const/4 v9, 0x3

    .line 524
    sget-object v8, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchLabelShimmer:Ljava/util/List;

    .line 525
    .line 526
    invoke-interface {v7, v1}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 527
    .line 528
    .line 529
    move-result v5

    .line 530
    invoke-interface {v7}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 531
    .line 532
    .line 533
    move-result-object v2

    .line 534
    if-nez v5, :cond_17

    .line 535
    .line 536
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 537
    .line 538
    if-ne v2, v5, :cond_18

    .line 539
    .line 540
    :cond_17
    new-instance v2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$5$1$1;

    .line 541
    .line 542
    invoke-direct {v2, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$5$1$1;-><init>(LX/16A;)V

    .line 543
    .line 544
    .line 545
    invoke-interface {v7, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 546
    .line 547
    .line 548
    :cond_18
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 549
    .line 550
    invoke-static {v0, v8, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->shimmerHighlight(LX/3C1;Ljava/util/List;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 551
    .line 552
    .line 553
    move-result-object v19

    .line 554
    invoke-static {v9}, LX/2wS;->A01(I)LX/2wS;

    .line 555
    .line 556
    .line 557
    move-result-object v25

    .line 558
    const/16 v36, 0x3fb0

    .line 559
    .line 560
    move-object/from16 v24, v23

    .line 561
    .line 562
    move/from16 v26, v17

    .line 563
    .line 564
    move/from16 v27, v17

    .line 565
    .line 566
    move/from16 v28, v17

    .line 567
    .line 568
    move/from16 v29, v17

    .line 569
    .line 570
    move-object/from16 v30, v23

    .line 571
    .line 572
    move-object/from16 v31, v23

    .line 573
    .line 574
    move-object/from16 v32, v23

    .line 575
    .line 576
    move-object/from16 v33, v7

    .line 577
    .line 578
    move/from16 v34, v17

    .line 579
    .line 580
    move/from16 v35, v17

    .line 581
    .line 582
    invoke-static/range {v18 .. v36}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 583
    .line 584
    .line 585
    invoke-static {v4, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 586
    .line 587
    .line 588
    goto :goto_3

    .line 589
    :cond_19
    invoke-interface {v7}, LX/2d4;->AgJ()V

    .line 590
    .line 591
    .line 592
    :goto_3
    invoke-interface {v7}, LX/2d4;->AAg()LX/J7V;

    .line 593
    .line 594
    .line 595
    move-result-object v1

    .line 596
    if-eqz v1, :cond_1a

    .line 597
    .line 598
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;

    .line 599
    .line 600
    move-object v7, v0

    .line 601
    move-object/from16 v8, p0

    .line 602
    .line 603
    move-object/from16 v9, v42

    .line 604
    .line 605
    move-object/from16 v10, v41

    .line 606
    .line 607
    move-object/from16 v11, v40

    .line 608
    .line 609
    move/from16 v12, v39

    .line 610
    .line 611
    move-object/from16 v13, v38

    .line 612
    .line 613
    move-object/from16 v14, v37

    .line 614
    .line 615
    move v15, v6

    .line 616
    invoke-direct/range {v7 .. v15}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$6;-><init>(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 617
    .line 618
    .line 619
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 620
    .line 621
    :cond_1a
    return-void
.end method

.method public static final synthetic access$CopyCodeButton(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->CopyCodeButton(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$InviteCodeScratcher$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$InviteCodeScratcher$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ScratchFoil(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchFoil(LX/33K;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/2d4;I)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$addCellsAround-OXOWCTw(Ljava/util/Set;JJF)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p5}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->addCellsAround-OXOWCTw(Ljava/util/Set;JJF)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$coverageCellSize-ozmzZPI(J)J
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->coverageCellSize-ozmzZPI(J)J

    .line 1
    .line 2
    .line 3
    move-result-wide p0

    .line 4
    return-wide p0
.end method

.method public static final synthetic access$getRevealDrop$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->RevealDrop:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getScratchCoverageRadius$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchCoverageRadius:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getScratchHapticSpacing$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchHapticSpacing:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getScratchRadius$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchRadius:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$getScratchSampleSpacing$p()F
    .locals 1

    .line 0
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchSampleSpacing:F

    .line 1
    .line 2
    return v0
.end method

.method public static final synthetic access$uncoveredCellCenters-O0kMr_c(Ljava/util/Set;J)Ljava/util/List;
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->uncoveredCellCenters-O0kMr_c(Ljava/util/Set;J)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final addCellsAround-OXOWCTw(Ljava/util/Set;JJF)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;JJF)V"
        }
    .end annotation

    .line 0
    const/16 v0, 0x20

    .line 1
    .line 2
    shr-long v0, p3, v0

    .line 3
    .line 4
    long-to-int v2, v0

    .line 5
    if-eqz v2, :cond_2

    .line 6
    .line 7
    const-wide v0, 0xffffffffL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    and-long/2addr p3, v0

    .line 13
    long-to-int v3, p3

    .line 14
    if-eqz v3, :cond_2

    .line 15
    .line 16
    int-to-float v9, v2

    .line 17
    const/16 v11, 0x24

    .line 18
    .line 19
    const/high16 v2, 0x42100000    # 36.0f

    .line 20
    .line 21
    div-float/2addr v9, v2

    .line 22
    int-to-float v8, v3

    .line 23
    const/4 v10, 0x6

    .line 24
    const/high16 v2, 0x40c00000    # 6.0f

    .line 25
    .line 26
    div-float/2addr v8, v2

    .line 27
    const/4 v7, 0x0

    .line 28
    :goto_0
    const/4 v6, 0x0

    .line 29
    :cond_0
    int-to-float v4, v6

    .line 30
    const/high16 v2, 0x3f000000    # 0.5f

    .line 31
    .line 32
    add-float/2addr v4, v2

    .line 33
    mul-float/2addr v4, v9

    .line 34
    int-to-float v3, v7

    .line 35
    add-float/2addr v3, v2

    .line 36
    mul-float/2addr v3, v8

    .line 37
    invoke-static {p1, p2}, LX/002;->A01(J)F

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sub-float/2addr v4, v2

    .line 42
    invoke-static {p1, p2, v0, v1}, LX/002;->A02(JJ)F

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    sub-float/2addr v3, v2

    .line 47
    float-to-double v4, v4

    .line 48
    float-to-double v2, v3

    .line 49
    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    .line 50
    .line 51
    .line 52
    move-result-wide v2

    .line 53
    double-to-float v4, v2

    .line 54
    cmpg-float v2, v4, p5

    .line 55
    .line 56
    if-gtz v2, :cond_1

    .line 57
    .line 58
    mul-int/lit8 v2, v7, 0x24

    .line 59
    .line 60
    add-int/2addr v2, v6

    .line 61
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-interface {p0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    :cond_1
    add-int/lit8 v6, v6, 0x1

    .line 69
    .line 70
    if-lt v6, v11, :cond_0

    .line 71
    .line 72
    add-int/lit8 v7, v7, 0x1

    .line 73
    .line 74
    if-ge v7, v10, :cond_2

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_2
    return-void
.end method

.method public static final claimTouches(LX/3C1;Z)LX/3C1;
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$claimTouches$1;

    .line 9
    .line 10
    invoke-static {p0, v0, v1}, LX/3BV;->A00(LX/3C1;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;Ljava/lang/Object;)LX/3C1;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    :cond_0
    return-object p0
.end method

.method public static final coverageCellSize-ozmzZPI(J)J
    .locals 3

    .line 0
    const/16 v0, 0x20

    .line 1
    .line 2
    shr-long v1, p0, v0

    .line 3
    .line 4
    long-to-int v0, v1

    .line 5
    int-to-float v2, v0

    .line 6
    const/high16 v0, 0x42100000    # 36.0f

    .line 7
    .line 8
    div-float/2addr v2, v0

    .line 9
    const-wide v0, 0xffffffffL

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    and-long/2addr p0, v0

    .line 15
    long-to-int v0, p0

    .line 16
    int-to-float v1, v0

    .line 17
    const/high16 v0, 0x40c00000    # 6.0f

    .line 18
    .line 19
    div-float/2addr v1, v0

    .line 20
    invoke-static {v2, v1}, LX/005;->A0I(FF)J

    .line 21
    .line 22
    .line 23
    move-result-wide v0

    .line 24
    return-wide v0
.end method

.method public static final forEachSample-jyLRC_s(JJFLX/JDM;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJF",
            "LX/JDM<",
            "-",
            "LX/2qg;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    invoke-static {p2, p3, p0, p1}, LX/2qg;->A03(JJ)J

    .line 1
    .line 2
    .line 3
    move-result-wide v2

    .line 4
    invoke-static {v2, v3}, LX/2qg;->A00(J)F

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    div-float/2addr v0, p4

    .line 9
    invoke-static {v0}, LX/002;->A03(F)I

    .line 10
    .line 11
    .line 12
    move-result v5

    .line 13
    const/4 v4, 0x1

    .line 14
    if-ge v5, v4, :cond_0

    .line 15
    .line 16
    const/4 v5, 0x1

    .line 17
    :cond_0
    :goto_0
    int-to-float v1, v4

    .line 18
    int-to-float v0, v5

    .line 19
    div-float/2addr v1, v0

    .line 20
    invoke-static {v2, v3, v1, p0, p1}, LX/2qg;->A02(JFJ)J

    .line 21
    .line 22
    .line 23
    move-result-wide v0

    .line 24
    invoke-static {p5, v0, v1}, LX/2qg;->A0A(LX/JDM;J)V

    .line 25
    .line 26
    .line 27
    if-eq v4, v5, :cond_1

    .line 28
    .line 29
    add-int/lit8 v4, v4, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    return-void
.end method

.method public static final isInviteCodeFoilCovering(Ljava/lang/String;ZLX/2d4;I)Z
    .locals 3

    .line 0
    invoke-static {p2}, LX/005;->A0Q(Ljava/lang/Object;)Landroid/content/Context;

    .line 1
    .line 2
    .line 3
    move-result-object v2

    .line 4
    invoke-interface {p2, v2}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 15
    .line 16
    if-ne v1, v0, :cond_1

    .line 17
    .line 18
    :cond_0
    invoke-static {v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->isTouchExplorationEnabled(Landroid/content/Context;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {p2, v0}, LX/002;->A0k(LX/2d4;Z)Ljava/lang/Boolean;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    :cond_1
    invoke-static {v1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz p0, :cond_2

    .line 31
    .line 32
    if-nez p1, :cond_2

    .line 33
    .line 34
    if-nez v0, :cond_2

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/utils/HatchUtil;->INSTANCE:Lcom/facebook/aura/utils/HatchUtil;

    .line 37
    .line 38
    invoke-virtual {v0}, Lcom/facebook/aura/utils/HatchUtil;->isScratchToRevealCodeEnabled()Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    const/4 v0, 0x1

    .line 43
    if-nez v1, :cond_3

    .line 44
    .line 45
    :cond_2
    const/4 v0, 0x0

    .line 46
    :cond_3
    return v0
.end method

.method public static final isTouchExplorationEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 0
    const-string v0, "accessibility"

    .line 1
    .line 2
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    instance-of v0, v1, Landroid/view/accessibility/AccessibilityManager;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v1, Landroid/view/accessibility/AccessibilityManager;

    .line 11
    .line 12
    :goto_0
    const/4 p0, 0x0

    .line 13
    if-eqz v1, :cond_1

    .line 14
    .line 15
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    const/4 v0, 0x1

    .line 20
    if-ne v1, v0, :cond_1

    .line 21
    .line 22
    return v0

    .line 23
    :cond_0
    const/4 v1, 0x0

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    return p0
.end method

.method public static final shimmerHighlight(LX/3C1;Ljava/util/List;Lkotlin/jvm/functions/Function0;)LX/3C1;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Ljava/util/List<",
            "LX/JOw;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;)",
            "LX/3C1;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$2;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$2;

    .line 1
    .line 2
    invoke-static {p0, v0}, LX/2uT;->A01(LX/3C1;LX/JDM;)LX/3C1;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;

    .line 7
    .line 8
    invoke-direct {v0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3;-><init>(Ljava/util/List;Lkotlin/jvm/functions/Function0;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v0}, LX/2pJ;->A02(LX/3C1;LX/JDM;)LX/3C1;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public static synthetic shimmerHighlight$default(LX/3C1;Ljava/util/List;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)LX/3C1;
    .locals 1

    .line 0
    and-int/lit8 v0, p3, 0x2

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    sget-object p2, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$1;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$1;

    .line 5
    .line 6
    :cond_0
    invoke-static {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->shimmerHighlight(LX/3C1;Ljava/util/List;Lkotlin/jvm/functions/Function0;)LX/3C1;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public static final uncoveredCellCenters-O0kMr_c(Ljava/util/Set;J)Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;J)",
            "Ljava/util/List<",
            "LX/2qg;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->coverageCellSize-ozmzZPI(J)J

    .line 1
    .line 2
    .line 3
    move-result-wide v1

    .line 4
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 5
    .line 6
    .line 7
    move-result-object v7

    .line 8
    const/4 v6, 0x0

    .line 9
    :cond_0
    const/4 v8, 0x0

    .line 10
    :cond_1
    mul-int/lit8 v0, v6, 0x24

    .line 11
    .line 12
    add-int/2addr v0, v8

    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_2

    .line 22
    .line 23
    int-to-float v9, v8

    .line 24
    const/high16 v3, 0x3f000000    # 0.5f

    .line 25
    .line 26
    add-float/2addr v9, v3

    .line 27
    invoke-static {v1, v2}, LX/002;->A01(J)F

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    mul-float/2addr v9, v0

    .line 32
    int-to-float v5, v6

    .line 33
    add-float/2addr v5, v3

    .line 34
    const-wide v3, 0xffffffffL

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    invoke-static {v1, v2, v3, v4}, LX/002;->A02(JJ)F

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    mul-float/2addr v5, v0

    .line 44
    invoke-static {v9, v5}, LX/005;->A0H(FF)J

    .line 45
    .line 46
    .line 47
    move-result-wide v3

    .line 48
    invoke-static {v3, v4}, LX/2qg;->A06(J)LX/2qg;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    :cond_2
    add-int/lit8 v8, v8, 0x1

    .line 56
    .line 57
    const/16 v0, 0x24

    .line 58
    .line 59
    if-lt v8, v0, :cond_1

    .line 60
    .line 61
    add-int/lit8 v6, v6, 0x1

    .line 62
    .line 63
    const/4 v0, 0x6

    .line 64
    if-lt v6, v0, :cond_0

    .line 65
    .line 66
    invoke-static {v7}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    return-object v0
.end method
