.class public final Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;->INSTANCE:Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 0

    .line 0
    sget-object p1, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;

    .line 1
    .line 2
    const/4 p0, 0x1

    .line 3
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope;->bind(Z)Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    new-instance p0, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1$invoke$$inlined$onDispose$1;

    .line 8
    .line 9
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1$invoke$$inlined$onDispose$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/relay/HatchPostConsolidationPresentationScope$Presentation;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/ActivationAgeStepKt$CardAgeStep$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
