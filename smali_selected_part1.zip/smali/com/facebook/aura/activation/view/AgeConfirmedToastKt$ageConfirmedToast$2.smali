.class public final Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $iconTint:LX/1AM;

.field public final synthetic $title:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;LX/1AM;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;->$title:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;->$iconTint:LX/1AM;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 21

    .line 0
    sget-object v2, Lcom/facebook/aura/toast/api/ToastApi;->INSTANCE:Lcom/facebook/aura/toast/api/ToastApi;

    .line 1
    .line 2
    move-object/from16 v1, p0

    .line 3
    .line 4
    iget-object v4, v1, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;->$title:Ljava/lang/String;

    .line 5
    .line 6
    sget-object v6, Lcom/facebook/aura/vds/toast/AuraToast$Duration;->CUSTOMIZED:Lcom/facebook/aura/vds/toast/AuraToast$Duration;

    .line 7
    .line 8
    const v0, 0x7f0800ef

    .line 9
    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v7

    .line 15
    const/16 v0, 0x1388

    .line 16
    .line 17
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object v13

    .line 21
    sget-object v20, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 22
    .line 23
    iget-object v0, v1, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;->$iconTint:LX/1AM;

    .line 24
    .line 25
    iget-wide v0, v0, LX/1AM;->element:J

    .line 26
    .line 27
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    const/4 v5, 0x0

    .line 32
    sget-object v8, Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;->INSTANCE:Lcom/facebook/aura/vds/compose/toast/AuraToastOption$None;

    .line 33
    .line 34
    const/4 v10, 0x0

    .line 35
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;->DEFAULT:Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 36
    .line 37
    const/16 v16, 0x1

    .line 38
    .line 39
    new-instance v3, Lcom/facebook/aura/vds/toast/AuraToast$ToastArgs;

    .line 40
    .line 41
    move-object v9, v5

    .line 42
    move-object v11, v5

    .line 43
    move-object v14, v5

    .line 44
    move v15, v10

    .line 45
    move-object/from16 v17, v5

    .line 46
    .line 47
    move-object/from16 v18, v5

    .line 48
    .line 49
    move-object/from16 v19, v5

    .line 50
    .line 51
    invoke-direct/range {v3 .. v21}, Lcom/facebook/aura/vds/toast/AuraToast$ToastArgs;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/vds/toast/AuraToast$Duration;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/toast/AuraToastOption;Landroid/view/View$OnClickListener;ZLjava/lang/Boolean;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;Ljava/lang/Integer;Landroid/view/View;ZZLkotlin/jvm/functions/Function0;Ljava/lang/Float;Ljava/lang/Integer;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;LX/JOw;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, v3}, Lcom/facebook/aura/toast/api/ToastApi;->showToast(Lcom/facebook/aura/vds/toast/AuraToast$ToastArgs;)Lcom/facebook/aura/toast/api/ToastHandle;

    .line 55
    .line 56
    .line 57
    return-void
.end method
