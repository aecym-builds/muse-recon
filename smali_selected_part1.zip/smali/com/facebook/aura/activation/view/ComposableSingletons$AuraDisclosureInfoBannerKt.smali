.class public final Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;

.field public static lambda$-1032673300:LX/JDN;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    sget-object v1, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt$lambda$-1032673300$1;

    .line 9
    .line 10
    const v0, -0x3d8d5814

    .line 11
    .line 12
    .line 13
    invoke-static {v1, v0, v2}, LX/Ddp;->A01(Ljava/lang/Object;IZ)LX/Ddo;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;->lambda$-1032673300:LX/JDN;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getLambda$-1032673300$fbandroid_express_aura_java_com_facebook_aura_activation_view_view()LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/JDN<",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraDisclosureInfoBannerKt;->lambda$-1032673300:LX/JDN;

    .line 1
    .line 2
    return-object p0
.end method
