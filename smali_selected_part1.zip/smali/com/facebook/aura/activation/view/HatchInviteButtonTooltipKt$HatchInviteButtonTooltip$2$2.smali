.class public final Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $dismiss:LX/DqV;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/DqV<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/DqV;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/DqV<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;->$dismiss:LX/DqV;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 0
    and-int/lit8 v0, p2, 0x3

    .line 1
    .line 2
    const/4 v3, 0x2

    .line 3
    invoke-static {v0, v3}, LX/003;->A1H(II)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v2, p0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$HatchInviteButtonTooltip$2$2;->$dismiss:LX/DqV;

    .line 14
    .line 15
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    const/4 v0, 0x0

    .line 19
    invoke-static {v2, v1, p1, v0, v3}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt;->InviteTooltipBubble(Lkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 24
    .line 25
    .line 26
    return-void
.end method
