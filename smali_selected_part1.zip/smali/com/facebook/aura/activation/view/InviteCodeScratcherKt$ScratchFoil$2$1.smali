.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2pH;",
        "LX/2pT;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $plate:J

.field public final synthetic $scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $sheen:J


# direct methods
.method public constructor <init>(JJLandroidx/compose/runtime/snapshots/SnapshotStateList;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$plate:J

    .line 1
    .line 2
    iput-wide p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$sheen:J

    .line 3
    .line 4
    iput-object p5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(LX/2pH;)LX/2pT;
    .locals 5

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-wide v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$plate:J

    .line 5
    .line 6
    invoke-static {v3, v4}, LX/001;->A0d(J)LX/JOw;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$sheen:J

    .line 11
    .line 12
    invoke-static {v0, v1}, LX/001;->A0d(J)LX/JOw;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-static {v3, v4}, LX/001;->A0d(J)LX/JOw;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    filled-new-array {v2, v1, v0}, [LX/JOw;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    const/4 v1, 0x0

    .line 29
    const/high16 v0, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 30
    .line 31
    invoke-static {v2, v1, v0}, LX/2hZ;->A01(Ljava/util/List;FF)LX/2hU;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->ScratchRadius:F

    .line 36
    .line 37
    invoke-static {p1, v0}, LX/2pH;->A02(LX/2pH;F)F

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 42
    .line 43
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;

    .line 44
    .line 45
    invoke-direct {v0, v3, v1, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1$1;-><init>(LX/2hZ;Landroidx/compose/runtime/snapshots/SnapshotStateList;F)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1, v0}, LX/2pH;->A05(LX/JDM;)LX/2pT;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2pH;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$2$1;->invoke(LX/2pH;)LX/2pT;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
