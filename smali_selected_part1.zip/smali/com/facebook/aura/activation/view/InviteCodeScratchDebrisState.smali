.class public final Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final animationWakeups:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final density:LX/34Y;

.field public frameTimeNanos:J

.field public final particles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/view/ScratchParticle;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/34Y;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->density:LX/34Y;

    .line 8
    .line 9
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 14
    .line 15
    const/4 v1, -0x1

    .line 16
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-static {v0, v1}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->animationWakeups:LX/EYl;

    .line 23
    .line 24
    return-void
.end method

.method private final append(Lcom/facebook/aura/activation/view/ScratchParticle;I)V
    .locals 2

    .line 0
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 7
    .line 8
    if-lt v0, p2, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    invoke-interface {v1, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method private final randomPx(LX/34c;)F
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/34c<",
            "LX/1Ot;",
            ">;)F"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->density:LX/34Y;

    .line 1
    .line 2
    invoke-interface {p1}, LX/34c;->AKx()Ljava/lang/Comparable;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, LX/1Ot;

    .line 7
    .line 8
    iget v2, v0, LX/1Ot;->A00:F

    .line 9
    .line 10
    invoke-interface {p1}, LX/34c;->AFG()Ljava/lang/Comparable;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, LX/1Ot;

    .line 15
    .line 16
    iget v1, v0, LX/1Ot;->A00:F

    .line 17
    .line 18
    new-instance v0, LX/0YR;

    .line 19
    .line 20
    invoke-direct {v0, v2, v1}, LX/0YR;-><init>(FF)V

    .line 21
    .line 22
    .line 23
    invoke-static {v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->randomFloat(LX/34i;)F

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-interface {p0, v0}, LX/34Y;->AhZ(F)F

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    return v0
.end method


# virtual methods
.method public final advance(J)Z
    .locals 3

    .line 0
    iput-wide p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->frameTimeNanos:J

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 3
    .line 4
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/facebook/aura/activation/view/ScratchParticle;

    .line 19
    .line 20
    invoke-virtual {v0, p1, p2}, Lcom/facebook/aura/activation/view/ScratchParticle;->ageSeconds(J)F

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const v0, 0x3f866666    # 1.05f

    .line 25
    .line 26
    .line 27
    cmpl-float v0, v1, v0

    .line 28
    .line 29
    if-ltz v0, :cond_0

    .line 30
    .line 31
    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    .line 32
    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 36
    .line 37
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    xor-int/lit8 v0, v0, 0x1

    .line 42
    .line 43
    return v0
.end method

.method public final awaitEmission(LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->animationWakeups:LX/EYl;

    .line 1
    .line 2
    invoke-interface {p0, p1}, LX/DpP;->Aa4(LX/2M4;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {p0}, LX/002;->A0w(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final draw-4WTKRHQ(LX/2la;J)V
    .locals 21

    .line 0
    const/4 v0, 0x0

    .line 1
    move-object/from16 v13, p1

    .line 2
    .line 3
    invoke-static {v13, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v4, p0

    .line 7
    .line 8
    iget-object v0, v4, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->particles:Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v12

    .line 14
    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v9

    .line 24
    check-cast v9, Lcom/facebook/aura/activation/view/ScratchParticle;

    .line 25
    .line 26
    iget-wide v0, v4, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->frameTimeNanos:J

    .line 27
    .line 28
    invoke-virtual {v9, v0, v1}, Lcom/facebook/aura/activation/view/ScratchParticle;->ageSeconds(J)F

    .line 29
    .line 30
    .line 31
    move-result v8

    .line 32
    const/4 v1, 0x0

    .line 33
    cmpg-float v0, v8, v1

    .line 34
    .line 35
    if-gez v0, :cond_0

    .line 36
    .line 37
    const/4 v8, 0x0

    .line 38
    :cond_0
    const v0, 0x3f866666    # 1.05f

    .line 39
    .line 40
    .line 41
    div-float v0, v8, v0

    .line 42
    .line 43
    const/high16 v7, 0x3f800000    # 1.0f

    .line 44
    .line 45
    invoke-static {v0, v1, v7}, LX/34j;->A04(FFF)F

    .line 46
    .line 47
    .line 48
    move-result v11

    .line 49
    iget-wide v5, v9, Lcom/facebook/aura/activation/view/ScratchParticle;->origin:J

    .line 50
    .line 51
    invoke-static {v5, v6}, LX/002;->A01(J)F

    .line 52
    .line 53
    .line 54
    move-result v10

    .line 55
    iget-wide v2, v9, Lcom/facebook/aura/activation/view/ScratchParticle;->velocity:J

    .line 56
    .line 57
    invoke-static {v2, v3, v8}, LX/007;->A03(JF)F

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    add-float/2addr v10, v0

    .line 62
    const-wide v0, 0xffffffffL

    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    invoke-static {v5, v6, v0, v1}, LX/002;->A02(JJ)F

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    invoke-static {v2, v3, v0, v1}, LX/002;->A02(JJ)F

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    mul-float/2addr v0, v8

    .line 76
    add-float/2addr v5, v0

    .line 77
    invoke-interface {v13}, LX/34Y;->AEu()F

    .line 78
    .line 79
    .line 80
    sget v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleGravity:F

    .line 81
    .line 82
    invoke-interface {v13, v0}, LX/34Y;->AhZ(F)F

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    mul-float/2addr v0, v8

    .line 87
    mul-float/2addr v0, v8

    .line 88
    const/high16 v2, 0x40000000    # 2.0f

    .line 89
    .line 90
    div-float/2addr v0, v2

    .line 91
    add-float/2addr v5, v0

    .line 92
    invoke-static {v10, v5}, LX/005;->A0I(FF)J

    .line 93
    .line 94
    .line 95
    move-result-wide p0

    .line 96
    iget v1, v9, Lcom/facebook/aura/activation/view/ScratchParticle;->diameterPx:F

    .line 97
    .line 98
    const v0, 0x3e99999a    # 0.3f

    .line 99
    .line 100
    .line 101
    mul-float/2addr v8, v0

    .line 102
    add-float/2addr v8, v7

    .line 103
    mul-float/2addr v1, v8

    .line 104
    div-float/2addr v1, v2

    .line 105
    iget-boolean v0, v9, Lcom/facebook/aura/activation/view/ScratchParticle;->isBright:Z

    .line 106
    .line 107
    const v17, 0x3f47ae14    # 0.78f

    .line 108
    .line 109
    .line 110
    if-eqz v0, :cond_1

    .line 111
    .line 112
    const v17, 0x3f733333    # 0.95f

    .line 113
    .line 114
    .line 115
    :cond_1
    sub-float/2addr v7, v11

    .line 116
    mul-float v17, v17, v7

    .line 117
    .line 118
    const/4 v14, 0x0

    .line 119
    sget-object v15, LX/2RH;->A00:LX/2RH;

    .line 120
    .line 121
    const/16 v18, 0x3

    .line 122
    .line 123
    move-wide/from16 v19, p2

    .line 124
    .line 125
    move/from16 v16, v1

    .line 126
    .line 127
    invoke-interface/range {v13 .. v22}, LX/2la;->A9S(LX/2hc;LX/2Qt;FFIJJ)V

    .line 128
    .line 129
    .line 130
    goto :goto_0

    .line 131
    :cond_2
    return-void
.end method

.method public final emitReveal-XnVDows(JLjava/util/List;JZ)V
    .locals 26
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/List<",
            "LX/2qg;",
            ">;JZ)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x1

    .line 1
    move-object/from16 v1, p3

    .line 2
    .line 3
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    if-nez p6, :cond_5

    .line 7
    .line 8
    move-wide/from16 v13, p1

    .line 9
    .line 10
    invoke-static {v13, v14}, LX/2RQ;->A05(J)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_5

    .line 15
    .line 16
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 17
    .line 18
    .line 19
    move-result-wide v22

    .line 20
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v16

    .line 24
    :cond_0
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    const/16 v8, 0x1a4

    .line 29
    .line 30
    const-wide v1, 0xffffffffL

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    move-object/from16 v0, p0

    .line 36
    .line 37
    if-eqz v3, :cond_1

    .line 38
    .line 39
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, LX/2qg;

    .line 44
    .line 45
    iget-wide v3, v3, LX/2qg;->A00:J

    .line 46
    .line 47
    const/4 v7, 0x0

    .line 48
    :goto_0
    invoke-static {v3, v4}, LX/002;->A01(J)F

    .line 49
    .line 50
    .line 51
    move-result v12

    .line 52
    move-wide/from16 v5, p4

    .line 53
    .line 54
    invoke-static {v5, v6}, LX/002;->A01(J)F

    .line 55
    .line 56
    .line 57
    move-result v11

    .line 58
    neg-float v10, v11

    .line 59
    const v15, 0x3ee66666    # 0.45f

    .line 60
    .line 61
    .line 62
    mul-float/2addr v10, v15

    .line 63
    mul-float/2addr v11, v15

    .line 64
    new-instance v9, LX/0YR;

    .line 65
    .line 66
    invoke-direct {v9, v10, v11}, LX/0YR;-><init>(FF)V

    .line 67
    .line 68
    .line 69
    invoke-static {v9}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->randomFloat(LX/34i;)F

    .line 70
    .line 71
    .line 72
    move-result v9

    .line 73
    add-float/2addr v12, v9

    .line 74
    invoke-static {v3, v4, v1, v2}, LX/002;->A02(JJ)F

    .line 75
    .line 76
    .line 77
    move-result v9

    .line 78
    invoke-static {v5, v6, v1, v2}, LX/002;->A02(JJ)F

    .line 79
    .line 80
    .line 81
    move-result v10

    .line 82
    neg-float v6, v10

    .line 83
    mul-float/2addr v6, v15

    .line 84
    mul-float/2addr v10, v15

    .line 85
    new-instance v5, LX/0YR;

    .line 86
    .line 87
    invoke-direct {v5, v6, v10}, LX/0YR;-><init>(FF)V

    .line 88
    .line 89
    .line 90
    invoke-static {v5}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->randomFloat(LX/34i;)F

    .line 91
    .line 92
    .line 93
    move-result v5

    .line 94
    add-float/2addr v9, v5

    .line 95
    invoke-static {v12, v9}, LX/005;->A0I(FF)J

    .line 96
    .line 97
    .line 98
    move-result-wide v18

    .line 99
    sget-object v5, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityXRange:LX/34c;

    .line 100
    .line 101
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 102
    .line 103
    .line 104
    move-result v6

    .line 105
    sget-object v5, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->CrumbleVelocityYRange:LX/34c;

    .line 106
    .line 107
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 108
    .line 109
    .line 110
    move-result v5

    .line 111
    invoke-static {v6, v5}, LX/005;->A0H(FF)J

    .line 112
    .line 113
    .line 114
    move-result-wide v20

    .line 115
    sget-object v5, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleSizeRange:LX/34c;

    .line 116
    .line 117
    invoke-direct {v0, v5}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 118
    .line 119
    .line 120
    move-result v24

    .line 121
    sget-object v5, LX/Fqh;->A01:LX/Fqh;

    .line 122
    .line 123
    invoke-virtual {v5}, LX/Fqh;->A09()Z

    .line 124
    .line 125
    .line 126
    move-result v25

    .line 127
    new-instance v5, Lcom/facebook/aura/activation/view/ScratchParticle;

    .line 128
    .line 129
    move-object/from16 v17, v5

    .line 130
    .line 131
    invoke-direct/range {v17 .. v25}, Lcom/facebook/aura/activation/view/ScratchParticle;-><init>(JJJFZ)V

    .line 132
    .line 133
    .line 134
    invoke-direct {v0, v5, v8}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->append(Lcom/facebook/aura/activation/view/ScratchParticle;I)V

    .line 135
    .line 136
    .line 137
    add-int/lit8 v7, v7, 0x1

    .line 138
    .line 139
    const/4 v5, 0x2

    .line 140
    if-ge v7, v5, :cond_0

    .line 141
    .line 142
    goto :goto_0

    .line 143
    :cond_1
    iget-object v4, v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->density:LX/34Y;

    .line 144
    .line 145
    sget v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealBurstInset:F

    .line 146
    .line 147
    invoke-interface {v4, v3}, LX/34Y;->AhZ(F)F

    .line 148
    .line 149
    .line 150
    move-result v5

    .line 151
    invoke-static {v13, v14}, LX/002;->A01(J)F

    .line 152
    .line 153
    .line 154
    move-result v4

    .line 155
    cmpl-float v3, v5, v4

    .line 156
    .line 157
    move v6, v5

    .line 158
    if-lez v3, :cond_2

    .line 159
    .line 160
    move v6, v4

    .line 161
    :cond_2
    const/high16 v3, 0x3f800000    # 1.0f

    .line 162
    .line 163
    add-float/2addr v3, v6

    .line 164
    invoke-static {v4, v5, v3}, LX/001;->A02(FFF)F

    .line 165
    .line 166
    .line 167
    move-result v5

    .line 168
    const/4 v4, 0x0

    .line 169
    :cond_3
    new-instance v3, LX/0YR;

    .line 170
    .line 171
    invoke-direct {v3, v6, v5}, LX/0YR;-><init>(FF)V

    .line 172
    .line 173
    .line 174
    invoke-static {v3}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->randomFloat(LX/34i;)F

    .line 175
    .line 176
    .line 177
    move-result v10

    .line 178
    sget-object v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealBurstYRange:LX/34c;

    .line 179
    .line 180
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 181
    .line 182
    .line 183
    move-result v9

    .line 184
    invoke-static {v13, v14, v1, v2}, LX/002;->A02(JJ)F

    .line 185
    .line 186
    .line 187
    move-result v7

    .line 188
    cmpl-float v3, v9, v7

    .line 189
    .line 190
    if-lez v3, :cond_4

    .line 191
    .line 192
    move v9, v7

    .line 193
    :cond_4
    invoke-static {v10, v9}, LX/005;->A0I(FF)J

    .line 194
    .line 195
    .line 196
    move-result-wide v18

    .line 197
    sget-object v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityXRange:LX/34c;

    .line 198
    .line 199
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 200
    .line 201
    .line 202
    move-result v7

    .line 203
    sget-object v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealVelocityYRange:LX/34c;

    .line 204
    .line 205
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 206
    .line 207
    .line 208
    move-result v3

    .line 209
    invoke-static {v7, v3}, LX/005;->A0I(FF)J

    .line 210
    .line 211
    .line 212
    move-result-wide v20

    .line 213
    sget-object v3, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->RevealParticleSizeRange:LX/34c;

    .line 214
    .line 215
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 216
    .line 217
    .line 218
    move-result v24

    .line 219
    sget-object v3, LX/Fqh;->A01:LX/Fqh;

    .line 220
    .line 221
    invoke-virtual {v3}, LX/Fqh;->A09()Z

    .line 222
    .line 223
    .line 224
    move-result v25

    .line 225
    new-instance v3, Lcom/facebook/aura/activation/view/ScratchParticle;

    .line 226
    .line 227
    move-object/from16 v17, v3

    .line 228
    .line 229
    invoke-direct/range {v17 .. v25}, Lcom/facebook/aura/activation/view/ScratchParticle;-><init>(JJJFZ)V

    .line 230
    .line 231
    .line 232
    invoke-direct {v0, v3, v8}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->append(Lcom/facebook/aura/activation/view/ScratchParticle;I)V

    .line 233
    .line 234
    .line 235
    add-int/lit8 v4, v4, 0x1

    .line 236
    .line 237
    const/16 v3, 0x2a

    .line 238
    .line 239
    if-lt v4, v3, :cond_3

    .line 240
    .line 241
    iget-object v1, v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->animationWakeups:LX/EYl;

    .line 242
    .line 243
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 244
    .line 245
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    :cond_5
    return-void
.end method

.method public final emitScratch-3MmeM6k(JZ)V
    .locals 13

    .line 0
    const/4 v2, 0x7

    .line 1
    if-eqz p3, :cond_0

    .line 2
    .line 3
    const/4 v2, 0x1

    .line 4
    :cond_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 5
    .line 6
    .line 7
    move-result-wide v9

    .line 8
    const/4 v3, 0x0

    .line 9
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityXRange:LX/34c;

    .line 10
    .line 11
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ScratchVelocityYRange:LX/34c;

    .line 16
    .line 17
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v1, v0}, LX/005;->A0F(FF)J

    .line 22
    .line 23
    .line 24
    move-result-wide v7

    .line 25
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt;->ParticleSizeRange:LX/34c;

    .line 26
    .line 27
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->randomPx(LX/34c;)F

    .line 28
    .line 29
    .line 30
    move-result v11

    .line 31
    sget-object v0, LX/Fqh;->A01:LX/Fqh;

    .line 32
    .line 33
    invoke-virtual {v0}, LX/Fqh;->A09()Z

    .line 34
    .line 35
    .line 36
    move-result v12

    .line 37
    new-instance v4, Lcom/facebook/aura/activation/view/ScratchParticle;

    .line 38
    .line 39
    move-wide v5, p1

    .line 40
    invoke-direct/range {v4 .. v12}, Lcom/facebook/aura/activation/view/ScratchParticle;-><init>(JJJFZ)V

    .line 41
    .line 42
    .line 43
    const/16 v0, 0xf0

    .line 44
    .line 45
    invoke-direct {p0, v4, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->append(Lcom/facebook/aura/activation/view/ScratchParticle;I)V

    .line 46
    .line 47
    .line 48
    add-int/lit8 v3, v3, 0x1

    .line 49
    .line 50
    if-lt v3, v2, :cond_1

    .line 51
    .line 52
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->animationWakeups:LX/EYl;

    .line 53
    .line 54
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 55
    .line 56
    invoke-interface {v1, v0}, LX/Dn5;->Ai4(Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    return-void
.end method
