.class public final Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1a6;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $content:LX/JDQ;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDQ<",
            "LX/3dS;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $verticalArrangement:LX/Dps;


# direct methods
.method public constructor <init>(LX/Dps;LX/JDQ;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Dps;",
            "LX/JDQ<",
            "-",
            "LX/3dS;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;->$verticalArrangement:LX/Dps;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;->$content:LX/JDQ;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/1a6;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;->invoke(LX/1a6;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/1a6;LX/2d4;I)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    and-int/lit8 v0, p3, 0x6

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {p2, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    or-int/2addr p3, v0

    .line 13
    :cond_0
    and-int/lit8 v1, p3, 0x13

    .line 14
    .line 15
    const/16 v0, 0x12

    .line 16
    .line 17
    const/4 v8, 0x1

    .line 18
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 29
    .line 30
    invoke-static {p2, v0}, LX/3J3;->A04(LX/2d4;LX/3C1;)LX/3C1;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-interface {p1}, LX/1a6;->AHW()F

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v1, v0}, LX/002;->A0a(LX/3C1;F)LX/3C1;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    sget-object v0, Lcom/facebook/aura/ui/adaptive/AuraContentRole;->Focused:Lcom/facebook/aura/ui/adaptive/AuraContentRole;

    .line 49
    .line 50
    const/16 v3, 0x30

    .line 51
    .line 52
    invoke-static {v1, v0, p2, v3}, Lcom/facebook/aura/ui/adaptive/AuraContentFrameKt;->auraContentWidth(LX/3C1;Lcom/facebook/aura/ui/adaptive/AuraContentRole;LX/2d4;I)LX/3C1;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    sget-object v1, LX/2Id;->A00:LX/2sS;

    .line 57
    .line 58
    iget-object v0, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;->$verticalArrangement:LX/Dps;

    .line 59
    .line 60
    iget-object v7, p0, Lcom/facebook/aura/activation/view/AuraWaitlistScreenKt$WaitlistSurface$1;->$content:LX/JDQ;

    .line 61
    .line 62
    invoke-static {v0, p2, v1, v3}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    move-object v5, p2

    .line 67
    check-cast v5, LX/J7I;

    .line 68
    .line 69
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    invoke-static {p2, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 82
    .line 83
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 84
    .line 85
    if-nez v0, :cond_1

    .line 86
    .line 87
    invoke-static {}, LX/1VY;->A00()V

    .line 88
    .line 89
    .line 90
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    throw v0

    .line 95
    :cond_1
    invoke-static {p2, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 96
    .line 97
    .line 98
    invoke-static {p2, v6, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 99
    .line 100
    .line 101
    sget-object v1, LX/CgJ;->A00:LX/CgJ;

    .line 102
    .line 103
    const/4 v0, 0x6

    .line 104
    invoke-static {v1, p2, v7, v0}, LX/002;->A1L(Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 105
    .line 106
    .line 107
    invoke-static {v5, v8}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :cond_2
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 112
    .line 113
    .line 114
    return-void
.end method
