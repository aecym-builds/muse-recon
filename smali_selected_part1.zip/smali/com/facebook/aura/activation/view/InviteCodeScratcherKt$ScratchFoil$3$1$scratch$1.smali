.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2qg;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $coverageRadiusPx:F

.field public final synthetic $debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

.field public final synthetic $onReveal:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $reduceMotion:Z

.field public final synthetic $revealAt:F

.field public final synthetic $revealTriggered:LX/0Rg;

.field public final synthetic $scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scratchedCells:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $this_pointerInput:LX/32h;


# direct methods
.method public constructor <init>(LX/0Rg;Landroidx/compose/runtime/snapshots/SnapshotStateList;Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;ZLjava/util/Set;LX/32h;FFLkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/0Rg;",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "LX/2qg;",
            ">;",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;",
            "Z",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "LX/32h;",
            "FF",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$revealTriggered:LX/0Rg;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 5
    .line 6
    iput-boolean p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$reduceMotion:Z

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchedCells:Ljava/util/Set;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$this_pointerInput:LX/32h;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$coverageRadiusPx:F

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$revealAt:F

    .line 15
    .line 16
    iput-object p9, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2qg;

    .line 1
    .line 2
    iget-wide v0, p1, LX/2qg;->A00:J

    .line 3
    .line 4
    invoke-virtual {p0, v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->invoke-k-4lQ0M(J)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke-k-4lQ0M(J)V
    .locals 15

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$revealTriggered:LX/0Rg;

    .line 1
    .line 2
    iget-boolean v0, v0, LX/0Rg;->element:Z

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchPoints:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 7
    .line 8
    move-wide/from16 v2, p1

    .line 9
    .line 10
    invoke-static {v2, v3}, LX/2qg;->A06(J)LX/2qg;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v1, v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->add(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 18
    .line 19
    iget-boolean v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$reduceMotion:Z

    .line 20
    .line 21
    invoke-virtual {v1, v2, v3, v0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->emitScratch-3MmeM6k(JZ)V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchedCells:Ljava/util/Set;

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$this_pointerInput:LX/32h;

    .line 27
    .line 28
    check-cast v0, LX/3Gh;

    .line 29
    .line 30
    iget-wide v4, v0, LX/3Gh;->A00:J

    .line 31
    .line 32
    iget v6, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$coverageRadiusPx:F

    .line 33
    .line 34
    invoke-static/range {v1 .. v6}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->addCellsAround-OXOWCTw(Ljava/util/Set;JJF)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchedCells:Ljava/util/Set;

    .line 38
    .line 39
    invoke-interface {v0}, Ljava/util/Set;->size()I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    int-to-float v1, v0

    .line 44
    iget v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$revealAt:F

    .line 45
    .line 46
    cmpl-float v0, v1, v0

    .line 47
    .line 48
    if-ltz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$revealTriggered:LX/0Rg;

    .line 51
    .line 52
    const/4 v0, 0x1

    .line 53
    iput-boolean v0, v1, LX/0Rg;->element:Z

    .line 54
    .line 55
    iget-object v8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$debrisState:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$this_pointerInput:LX/32h;

    .line 58
    .line 59
    check-cast v0, LX/3Gh;

    .line 60
    .line 61
    iget-wide v1, v0, LX/3Gh;->A00:J

    .line 62
    .line 63
    const/16 v0, 0x20

    .line 64
    .line 65
    shr-long v3, v1, v0

    .line 66
    .line 67
    long-to-int v0, v3

    .line 68
    int-to-float v7, v0

    .line 69
    const-wide v5, 0xffffffffL

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    and-long v3, v1, v5

    .line 75
    .line 76
    long-to-int v0, v3

    .line 77
    int-to-float v0, v0

    .line 78
    invoke-static {v7, v0}, LX/005;->A0I(FF)J

    .line 79
    .line 80
    .line 81
    move-result-wide v9

    .line 82
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$scratchedCells:Ljava/util/Set;

    .line 83
    .line 84
    invoke-static {v0, v1, v2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->uncoveredCellCenters-O0kMr_c(Ljava/util/Set;J)Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object v11

    .line 88
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$this_pointerInput:LX/32h;

    .line 89
    .line 90
    check-cast v0, LX/3Gh;

    .line 91
    .line 92
    iget-wide v0, v0, LX/3Gh;->A00:J

    .line 93
    .line 94
    invoke-static {v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt;->coverageCellSize-ozmzZPI(J)J

    .line 95
    .line 96
    .line 97
    move-result-wide v12

    .line 98
    iget-boolean v14, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$reduceMotion:Z

    .line 99
    .line 100
    invoke-virtual/range {v8 .. v14}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->emitReveal-XnVDows(JLjava/util/List;JZ)V

    .line 101
    .line 102
    .line 103
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$scratch$1;->$onReveal:Lkotlin/jvm/functions/Function0;

    .line 104
    .line 105
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    :cond_0
    return-void
.end method
