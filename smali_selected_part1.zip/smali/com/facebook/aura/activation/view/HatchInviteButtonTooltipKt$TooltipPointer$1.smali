.class public final Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/2lV;",
        "LX/2RQ;",
        "LX/2i3;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;->INSTANCE:Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    check-cast p1, LX/2lV;

    .line 1
    .line 2
    check-cast p2, LX/2RQ;

    .line 3
    .line 4
    iget-wide v0, p2, LX/2RQ;->A00:J

    .line 5
    .line 6
    check-cast p3, LX/2i3;

    .line 7
    .line 8
    invoke-virtual {p0, p1, v0, v1, p3}, Lcom/facebook/aura/activation/view/HatchInviteButtonTooltipKt$TooltipPointer$1;->invoke-12SF9DM(LX/2lV;JLX/2i3;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    return-object v0
.end method

.method public final invoke-12SF9DM(LX/2lV;JLX/2i3;)V
    .locals 4

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-static {p2, p3}, LX/008;->A01(J)F

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    const/4 v3, 0x0

    .line 9
    check-cast p1, LX/2bQ;

    .line 10
    .line 11
    iget-object v2, p1, LX/2bQ;->A03:Landroid/graphics/Path;

    .line 12
    .line 13
    invoke-virtual {v2, v3, p0}, Landroid/graphics/Path;->moveTo(FF)V

    .line 14
    .line 15
    .line 16
    invoke-static {p2, p3}, LX/004;->A03(J)F

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/high16 v0, 0x40000000    # 2.0f

    .line 21
    .line 22
    div-float v0, v1, v0

    .line 23
    .line 24
    invoke-virtual {v2, v0, v3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2, v1, p0}, Landroid/graphics/Path;->lineTo(FF)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, Landroid/graphics/Path;->close()V

    .line 31
    .line 32
    .line 33
    return-void
.end method
