.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;
.super LX/DRt;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRt;",
        "LX/JDN<",
        "LX/3Hm;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.InviteCodeScratcherKt$ScratchFoil$3$1$1"
    f = "InviteCodeScratcher.kt"
    l = {
        0x13c,
        0x13f
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $hapticSpacingPx:F

.field public final synthetic $onScratchTick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scratch:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "LX/2qg;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $spacingPx:F

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/JDM;FLkotlin/jvm/functions/Function0;FLX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDM<",
            "-",
            "LX/2qg;",
            "Lkotlin/Unit;",
            ">;F",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;F",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$scratch:LX/JDM;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$hapticSpacingPx:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$spacingPx:F

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRt;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$scratch:LX/JDM;

    .line 1
    .line 2
    iget v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$hapticSpacingPx:F

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iget v4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$spacingPx:F

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;

    .line 9
    .line 10
    move-object p0, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;-><init>(LX/JDM;FLkotlin/jvm/functions/Function0;FLX/2M4;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, v0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$0:Ljava/lang/Object;

    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/3Hm;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3Hm;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/3Hm;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->invoke(LX/3Hm;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    iget-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v5, LX/3Hm;

    .line 3
    .line 4
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 5
    .line 6
    iget v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->label:I

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    const/4 v0, 0x1

    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    if-eq v1, v0, :cond_2

    .line 13
    .line 14
    if-ne v1, v3, :cond_4

    .line 15
    .line 16
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    .line 21
    return-object v4

    .line 22
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    new-instance v7, LX/2aZ;

    .line 26
    .line 27
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object v5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$0:Ljava/lang/Object;

    .line 31
    .line 32
    iput-object v7, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$1:Ljava/lang/Object;

    .line 33
    .line 34
    iput v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->label:I

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    sget-object v0, LX/3ID;->A04:LX/3ID;

    .line 38
    .line 39
    invoke-static {v5, v0, p0, v1}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->A04(LX/3Hm;LX/3ID;LX/2M4;Z)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    if-ne p1, v4, :cond_3

    .line 44
    .line 45
    return-object v4

    .line 46
    :cond_2
    iget-object v7, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$1:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v7, LX/2aZ;

    .line 49
    .line 50
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_3
    check-cast p1, LX/3CH;

    .line 54
    .line 55
    invoke-virtual {p1}, LX/3CH;->A04()V

    .line 56
    .line 57
    .line 58
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$scratch:LX/JDM;

    .line 59
    .line 60
    iget-wide v0, p1, LX/3CH;->A0A:J

    .line 61
    .line 62
    invoke-static {v2, v0, v1}, LX/2qg;->A0A(LX/JDM;J)V

    .line 63
    .line 64
    .line 65
    iget-wide v0, p1, LX/3CH;->A08:J

    .line 66
    .line 67
    iget v8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$hapticSpacingPx:F

    .line 68
    .line 69
    iget-object v9, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 70
    .line 71
    iget v10, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$spacingPx:F

    .line 72
    .line 73
    iget-object v11, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->$scratch:LX/JDM;

    .line 74
    .line 75
    new-instance v6, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;

    .line 76
    .line 77
    invoke-direct/range {v6 .. v11}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;-><init>(LX/2aZ;FLkotlin/jvm/functions/Function0;FLX/JDM;)V

    .line 78
    .line 79
    .line 80
    const/4 v2, 0x0

    .line 81
    iput-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$0:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$1:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->L$2:Ljava/lang/Object;

    .line 86
    .line 87
    iput v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1;->label:I

    .line 88
    .line 89
    invoke-static {v5, p0, v6, v0, v1}, Landroidx/compose/foundation/gestures/DragGestureDetectorKt;->A06(LX/3Hm;LX/2M4;LX/JDM;J)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    if-ne v0, v4, :cond_0

    .line 94
    .line 95
    return-object v4

    .line 96
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    throw v0
.end method
