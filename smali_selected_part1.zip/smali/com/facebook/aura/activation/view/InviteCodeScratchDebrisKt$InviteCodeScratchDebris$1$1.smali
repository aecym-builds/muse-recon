.class public final Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.view.InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1"
    f = "InviteCodeScratchDebris.kt"
    l = {
        0xc8,
        0xca
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $frameTick$delegate:LX/CR1;

.field public final synthetic $state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;LX/CR1;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;",
            "LX/CR1;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$frameTick$delegate:LX/CR1;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$frameTick$delegate:LX/CR1;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;-><init>(Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;LX/CR1;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    if-eq v0, v3, :cond_1

    .line 9
    .line 10
    if-ne v0, v4, :cond_4

    .line 11
    .line 12
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->L$0:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 15
    .line 16
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    invoke-static {p1}, LX/001;->A0I(Ljava/lang/Object;)J

    .line 20
    .line 21
    .line 22
    move-result-wide v0

    .line 23
    invoke-virtual {v2, v0, v1}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->advance(J)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$frameTick$delegate:LX/CR1;

    .line 28
    .line 29
    invoke-interface {v0}, LX/CR1;->AGk()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$frameTick$delegate:LX/CR1;

    .line 34
    .line 35
    add-int/lit8 v0, v0, 0x1

    .line 36
    .line 37
    invoke-interface {v1, v0}, LX/CR1;->Ae1(I)V

    .line 38
    .line 39
    .line 40
    if-nez v2, :cond_2

    .line 41
    .line 42
    :goto_0
    iget-object v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 43
    .line 44
    const/4 v0, 0x0

    .line 45
    iput-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->L$0:Ljava/lang/Object;

    .line 46
    .line 47
    iput v3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->label:I

    .line 48
    .line 49
    invoke-virtual {v1, p0}, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;->awaitEmission(LX/2M4;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    if-ne v0, v5, :cond_2

    .line 54
    .line 55
    return-object v5

    .line 56
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_2
    iget-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->$state:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisState;

    .line 60
    .line 61
    sget-object v0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1$hasParticles$1;->INSTANCE:Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1$hasParticles$1;

    .line 62
    .line 63
    iput-object v2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->L$0:Ljava/lang/Object;

    .line 64
    .line 65
    iput v4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratchDebrisKt$InviteCodeScratchDebris$1$1;->label:I

    .line 66
    .line 67
    invoke-static {v0, p0}, LX/39q;->A01(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v5, :cond_0

    .line 72
    .line 73
    return-object v5

    .line 74
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_4
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    throw v0
.end method
