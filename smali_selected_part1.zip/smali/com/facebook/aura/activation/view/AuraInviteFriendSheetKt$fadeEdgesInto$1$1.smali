.class public final Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2RG;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $bottomFade:LX/2hZ;

.field public final synthetic $endFade:LX/2hZ;

.field public final synthetic $fade:F

.field public final synthetic $startFade:LX/2hZ;

.field public final synthetic $topFade:LX/2hZ;


# direct methods
.method public constructor <init>(LX/2hZ;FLX/2hZ;LX/2hZ;LX/2hZ;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$topFade:LX/2hZ;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$fade:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$bottomFade:LX/2hZ;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$startFade:LX/2hZ;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$endFade:LX/2hZ;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2RG;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->invoke(LX/2RG;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2RG;)V
    .locals 26

    .line 0
    move-object/from16 v13, p1

    .line 1
    .line 2
    invoke-static {v13}, LX/2RG;->A01(LX/2RG;)V

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p0

    .line 6
    .line 7
    iget-object v14, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$topFade:LX/2hZ;

    .line 8
    .line 9
    invoke-interface {v13}, LX/2la;->AKf()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    const/16 v12, 0x20

    .line 14
    .line 15
    invoke-static {v0, v1}, LX/002;->A01(J)F

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    iget v2, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$fade:F

    .line 20
    .line 21
    invoke-static {v0}, LX/001;->A0F(F)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    invoke-static {v2}, LX/001;->A0F(F)J

    .line 26
    .line 27
    .line 28
    move-result-wide v21

    .line 29
    shl-long/2addr v0, v12

    .line 30
    const-wide v4, 0xffffffffL

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    and-long v21, v21, v4

    .line 36
    .line 37
    or-long v21, v21, v0

    .line 38
    .line 39
    const/4 v15, 0x0

    .line 40
    const/4 v7, 0x0

    .line 41
    const-wide/16 v19, 0x0

    .line 42
    .line 43
    const/high16 v17, 0x3f800000    # 1.0f

    .line 44
    .line 45
    sget-object v16, LX/2RH;->A00:LX/2RH;

    .line 46
    .line 47
    const/16 v18, 0x3

    .line 48
    .line 49
    const/16 v23, 0x3

    .line 50
    .line 51
    invoke-interface/range {v13 .. v22}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V

    .line 52
    .line 53
    .line 54
    iget-object v9, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$bottomFade:LX/2hZ;

    .line 55
    .line 56
    invoke-interface {v13}, LX/2la;->AKf()J

    .line 57
    .line 58
    .line 59
    move-result-wide v2

    .line 60
    invoke-static {v2, v3, v4, v5}, LX/002;->A02(JJ)F

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    iget v0, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$fade:F

    .line 65
    .line 66
    sub-float/2addr v1, v0

    .line 67
    invoke-static {v7}, LX/001;->A0F(F)J

    .line 68
    .line 69
    .line 70
    move-result-wide v10

    .line 71
    invoke-static {v1}, LX/001;->A0F(F)J

    .line 72
    .line 73
    .line 74
    move-result-wide v7

    .line 75
    shl-long v0, v10, v12

    .line 76
    .line 77
    and-long/2addr v7, v4

    .line 78
    or-long/2addr v0, v7

    .line 79
    invoke-static {v2, v3, v0, v1}, LX/2lb;->A00(JJ)J

    .line 80
    .line 81
    .line 82
    move-result-wide p0

    .line 83
    move-object/from16 v18, v13

    .line 84
    .line 85
    move-object/from16 v19, v9

    .line 86
    .line 87
    move-object/from16 v20, v15

    .line 88
    .line 89
    move-object/from16 v21, v16

    .line 90
    .line 91
    move/from16 v22, v17

    .line 92
    .line 93
    move-wide/from16 v24, v0

    .line 94
    .line 95
    invoke-interface/range {v18 .. v27}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V

    .line 96
    .line 97
    .line 98
    iget-object v3, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$startFade:LX/2hZ;

    .line 99
    .line 100
    iget v2, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$fade:F

    .line 101
    .line 102
    invoke-interface {v13}, LX/2la;->AKf()J

    .line 103
    .line 104
    .line 105
    move-result-wide v0

    .line 106
    invoke-static {v0, v1, v4, v5}, LX/002;->A02(JJ)F

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    invoke-static {v2, v0}, LX/005;->A0I(FF)J

    .line 111
    .line 112
    .line 113
    move-result-wide p0

    .line 114
    const-wide/16 v24, 0x0

    .line 115
    .line 116
    move-object/from16 v19, v3

    .line 117
    .line 118
    invoke-interface/range {v18 .. v27}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V

    .line 119
    .line 120
    .line 121
    iget-object v7, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$endFade:LX/2hZ;

    .line 122
    .line 123
    invoke-interface {v13}, LX/2la;->AKf()J

    .line 124
    .line 125
    .line 126
    move-result-wide v2

    .line 127
    invoke-static {v2, v3}, LX/002;->A01(J)F

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    iget v0, v6, Lcom/facebook/aura/activation/view/AuraInviteFriendSheetKt$fadeEdgesInto$1$1;->$fade:F

    .line 132
    .line 133
    sub-float/2addr v1, v0

    .line 134
    invoke-static {v1}, LX/002;->A0N(F)J

    .line 135
    .line 136
    .line 137
    move-result-wide v0

    .line 138
    and-long/2addr v10, v4

    .line 139
    or-long/2addr v0, v10

    .line 140
    invoke-static {v2, v3, v0, v1}, LX/2lb;->A00(JJ)J

    .line 141
    .line 142
    .line 143
    move-result-wide p0

    .line 144
    move-object/from16 v19, v7

    .line 145
    .line 146
    move-wide/from16 v24, v0

    .line 147
    .line 148
    invoke-interface/range {v18 .. v27}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V

    .line 149
    .line 150
    .line 151
    return-void
.end method
