.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/3CH;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $hapticDistancePx:LX/2aZ;

.field public final synthetic $hapticSpacingPx:F

.field public final synthetic $onScratchTick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $scratch:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "LX/2qg;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $spacingPx:F


# direct methods
.method public constructor <init>(LX/2aZ;FLkotlin/jvm/functions/Function0;FLX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2aZ;",
            "F",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;F",
            "LX/JDM<",
            "-",
            "LX/2qg;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$hapticDistancePx:LX/2aZ;

    .line 1
    .line 2
    iput p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$hapticSpacingPx:F

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput p4, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$spacingPx:F

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$scratch:LX/JDM;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/3CH;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->invoke(LX/3CH;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/3CH;)V
    .locals 9

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$hapticDistancePx:LX/2aZ;

    .line 5
    .line 6
    iget v7, v8, LX/2aZ;->element:F

    .line 7
    .line 8
    iget-wide v0, p1, LX/3CH;->A0A:J

    .line 9
    .line 10
    iget-wide v4, p1, LX/3CH;->A0B:J

    .line 11
    .line 12
    invoke-static {v0, v1, v4, v5}, LX/2qg;->A03(JJ)J

    .line 13
    .line 14
    .line 15
    move-result-wide v2

    .line 16
    invoke-static {v2, v3}, LX/2qg;->A00(J)F

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    add-float/2addr v7, v6

    .line 21
    iput v7, v8, LX/2aZ;->element:F

    .line 22
    .line 23
    iget v1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$hapticSpacingPx:F

    .line 24
    .line 25
    cmpl-float v0, v7, v1

    .line 26
    .line 27
    if-ltz v0, :cond_0

    .line 28
    .line 29
    rem-float/2addr v7, v1

    .line 30
    iput v7, v8, LX/2aZ;->element:F

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$onScratchTick:Lkotlin/jvm/functions/Function0;

    .line 33
    .line 34
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    :cond_0
    iget v0, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$spacingPx:F

    .line 38
    .line 39
    iget-object v8, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$ScratchFoil$3$1$1$1;->$scratch:LX/JDM;

    .line 40
    .line 41
    div-float/2addr v6, v0

    .line 42
    invoke-static {v6}, LX/002;->A03(F)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    const/4 v6, 0x1

    .line 47
    if-ge v7, v6, :cond_1

    .line 48
    .line 49
    const/4 v7, 0x1

    .line 50
    :cond_1
    :goto_0
    int-to-float v1, v6

    .line 51
    int-to-float v0, v7

    .line 52
    div-float/2addr v1, v0

    .line 53
    invoke-static {v2, v3, v1, v4, v5}, LX/2qg;->A02(JFJ)J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    invoke-static {v8, v0, v1}, LX/2qg;->A0A(LX/JDM;J)V

    .line 58
    .line 59
    .line 60
    if-eq v6, v7, :cond_2

    .line 61
    .line 62
    add-int/lit8 v6, v6, 0x1

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_2
    invoke-virtual {p1}, LX/3CH;->A04()V

    .line 66
    .line 67
    .line 68
    return-void
.end method
