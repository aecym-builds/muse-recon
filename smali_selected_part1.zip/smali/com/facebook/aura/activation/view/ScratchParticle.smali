.class public final Lcom/facebook/aura/activation/view/ScratchParticle;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final birthNanos:J

.field public final diameterPx:F

.field public final isBright:Z

.field public final origin:J

.field public final velocity:J


# direct methods
.method public constructor <init>(JJJFZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-wide p1, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->origin:J

    .line 4
    .line 5
    iput-wide p3, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->velocity:J

    .line 6
    .line 7
    iput-wide p5, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->birthNanos:J

    .line 8
    .line 9
    iput p7, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->diameterPx:F

    .line 10
    .line 11
    iput-boolean p8, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->isBright:Z

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(JJJFZLX/04f;)V
    .locals 0

    .line 268435456
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/activation/view/ScratchParticle;-><init>(JJJFZ)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method


# virtual methods
.method public final ageSeconds(J)F
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->birthNanos:J

    .line 1
    .line 2
    sub-long/2addr p1, v0

    .line 3
    long-to-float p0, p1

    .line 4
    const v0, 0x4e6e6b28    # 1.0E9f

    .line 5
    .line 6
    .line 7
    div-float/2addr p0, v0

    .line 8
    return p0
.end method

.method public final getBirthNanos()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->birthNanos:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getDiameterPx()F
    .locals 0

    .line 0
    iget p0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->diameterPx:F

    .line 1
    .line 2
    return p0
.end method

.method public final getOrigin-F1C5BW0()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->origin:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final getVelocity-F1C5BW0()J
    .locals 1

    .line 0
    iget-wide v0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->velocity:J

    .line 1
    .line 2
    return-wide v0
.end method

.method public final isBright()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/view/ScratchParticle;->isBright:Z

    .line 1
    .line 2
    return p0
.end method
