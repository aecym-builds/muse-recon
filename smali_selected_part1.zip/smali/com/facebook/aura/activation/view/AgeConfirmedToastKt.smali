.class public abstract Lcom/facebook/aura/activation/view/AgeConfirmedToastKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ageConfirmedToast(LX/2d4;I)Lkotlin/jvm/functions/Function0;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, 0x7f120096

    .line 1
    .line 2
    .line 3
    invoke-static {p0, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    new-instance v3, LX/1AM;

    .line 8
    .line 9
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    sget-wide v0, LX/JOw;->A07:J

    .line 13
    .line 14
    iput-wide v0, v3, LX/1AM;->element:J

    .line 15
    .line 16
    sget-object v1, Lcom/facebook/aura/vds/compose/toast/AuraToastStyle;->INSTANCE:Lcom/facebook/aura/vds/compose/toast/AuraToastStyle;

    .line 17
    .line 18
    const/4 v0, 0x6

    .line 19
    invoke-virtual {v1, p0, v0}, Lcom/facebook/aura/vds/compose/toast/AuraToastStyle;->isLight(LX/2d4;I)Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    new-instance v1, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$1;

    .line 24
    .line 25
    invoke-direct {v1, v3}, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$1;-><init>(LX/1AM;)V

    .line 26
    .line 27
    .line 28
    const v0, 0xcad8d3a

    .line 29
    .line 30
    .line 31
    invoke-static {p0, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    const/16 v0, 0x180

    .line 36
    .line 37
    invoke-static {p0, v2, v1, v0}, LX/003;->A0s(LX/2d4;Lcom/facebook/aura/vds/compose/theme/root/mode/AuraThemeMode;LX/JDN;I)V

    .line 38
    .line 39
    .line 40
    new-instance v0, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;

    .line 41
    .line 42
    invoke-direct {v0, v4, v3}, Lcom/facebook/aura/activation/view/AgeConfirmedToastKt$ageConfirmedToast$2;-><init>(Ljava/lang/String;LX/1AM;)V

    .line 43
    .line 44
    .line 45
    return-object v0
.end method
