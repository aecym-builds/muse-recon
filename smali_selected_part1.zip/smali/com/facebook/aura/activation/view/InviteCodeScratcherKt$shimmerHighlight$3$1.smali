.class public final Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/2RG;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $brush:LX/2hZ;

.field public final synthetic $progress:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $shimmerWidth:F


# direct methods
.method public constructor <init>(FLkotlin/jvm/functions/Function0;LX/2hZ;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Float;",
            ">;",
            "LX/2hZ;",
            ")V"
        }
    .end annotation

    .line 0
    iput p1, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$shimmerWidth:F

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$progress:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$brush:LX/2hZ;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2RG;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->invoke(LX/2RG;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(LX/2RG;)V
    .locals 16

    .line 0
    move-object/from16 v8, p1

    .line 1
    .line 2
    invoke-static {v8}, LX/2RG;->A01(LX/2RG;)V

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p0

    .line 6
    .line 7
    iget v0, v4, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$shimmerWidth:F

    .line 8
    .line 9
    neg-float v6, v0

    .line 10
    iget-object v0, v4, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$progress:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    invoke-static {v0}, LX/003;->A01(Lkotlin/jvm/functions/Function0;)F

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/high16 v12, 0x3f800000    # 1.0f

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v0, v3, v12}, LX/34j;->A04(FFF)F

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    invoke-interface {v8}, LX/2la;->AKf()J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    invoke-static {v0, v1}, LX/002;->A01(J)F

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    iget v7, v4, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$shimmerWidth:F

    .line 32
    .line 33
    add-float/2addr v0, v7

    .line 34
    mul-float/2addr v2, v0

    .line 35
    add-float/2addr v6, v2

    .line 36
    iget-object v9, v4, Lcom/facebook/aura/activation/view/InviteCodeScratcherKt$shimmerHighlight$3$1;->$brush:LX/2hZ;

    .line 37
    .line 38
    invoke-interface {v8}, LX/2la;->AEy()LX/2lC;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, LX/2kf;

    .line 43
    .line 44
    iget-object v5, v0, LX/2kf;->A01:LX/2lA;

    .line 45
    .line 46
    invoke-interface {v5, v6, v3}, LX/2lA;->Ahp(FF)V

    .line 47
    .line 48
    .line 49
    const/high16 v4, -0x80000000

    .line 50
    .line 51
    :try_start_0
    invoke-interface {v8}, LX/2la;->AKf()J

    .line 52
    .line 53
    .line 54
    move-result-wide v2

    .line 55
    const/4 v10, 0x0

    .line 56
    const-wide v0, 0xffffffffL

    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    invoke-static {v0, v1, v2, v3}, LX/002;->A02(JJ)F

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v7, v0}, LX/005;->A0H(FF)J

    .line 66
    .line 67
    .line 68
    move-result-wide p0

    .line 69
    const/16 v13, 0x9

    .line 70
    .line 71
    const-wide/16 v14, 0x0

    .line 72
    .line 73
    sget-object v11, LX/2RH;->A00:LX/2RH;

    .line 74
    .line 75
    invoke-interface/range {v8 .. v17}, LX/2la;->A9k(LX/2hZ;LX/2hc;LX/2Qt;FIJJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 76
    .line 77
    .line 78
    neg-float v0, v6

    .line 79
    invoke-interface {v5, v0, v4}, LX/2lA;->Ahp(FF)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :catchall_0
    move-exception v1

    .line 84
    neg-float v0, v6

    .line 85
    invoke-interface {v5, v0, v4}, LX/2lA;->Ahp(FF)V

    .line 86
    .line 87
    .line 88
    throw v1
.end method
