.class public final Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $showContextMenu$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 8

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->HEADER:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_WAITLIST:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchComponent;->THREE_DOTS_MENU:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    move-object v6, v5

    .line 12
    move-object v7, v5

    .line 13
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/view/AuraActivationScreenKt$WaitlistOverflowHeader$1$1$1$1;->$showContextMenu$delegate:Landroidx/compose/runtime/MutableState;

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    invoke-static {v0, v1}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
