.class public final Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/0z5;",
        "LX/CdD;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(LX/0z5;)LX/CdD;
    .locals 0

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 1
    .line 2
    sget-object p0, Lcom/facebook/aura/navigation/key/ActivationInfoSheetKey;->INSTANCE:Lcom/facebook/aura/navigation/key/ActivationInfoSheetKey;

    .line 3
    .line 4
    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-interface {p1, p0}, Lcom/facebook/aura/navigation/AuraNavigator;->popAll(Ljava/util/Collection;)V

    .line 9
    .line 10
    .line 11
    new-instance p0, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1$invoke$$inlined$onDispose$1;

    .line 12
    .line 13
    invoke-direct {p0}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1$invoke$$inlined$onDispose$1;-><init>()V

    .line 14
    .line 15
    .line 16
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/0z5;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/view/AuraDisclosureInfoSheetKt$AuraDisclosureInfoSheet$1$1;->invoke(LX/0z5;)LX/CdD;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
