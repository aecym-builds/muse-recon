.class public final Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;->INSTANCE:Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/activation/view/ComposableSingletons$AuraConfirmNameScreenKt$lambda$268752177$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 3

    .line 0
    and-int/lit8 v1, p2, 0x3

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    const/4 p0, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    sget v0, Lcom/facebook/aura/auth/login/ui/NativeLoginUiKitKt;->NATIVE_LOGIN_LOGO_SIZE:F

    .line 17
    .line 18
    invoke-static {v1, v0, p1, p0, v2}, Lcom/facebook/aura/auth/login/ui/NativeLoginUiKitKt;->NativeLoginHeaderLogo-rAjV9yQ(LX/3C1;FLX/2d4;II)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 23
    .line 24
    .line 25
    return-void
.end method
