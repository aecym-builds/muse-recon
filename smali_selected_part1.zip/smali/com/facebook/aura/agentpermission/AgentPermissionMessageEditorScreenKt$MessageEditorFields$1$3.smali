.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $subjectLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;->$subjectLabel:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 16

    .line 0
    move/from16 v1, p2

    .line 1
    .line 2
    invoke-static {v1}, LX/005;->A1D(I)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    move-object/from16 v15, p1

    .line 7
    .line 8
    invoke-static {v0, v15, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-static {v15}, LX/007;->A0j(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v4, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->bodyRegular:LX/2hg;

    .line 19
    .line 20
    sget-object v2, LX/3C1;->A00:LX/3Cb;

    .line 21
    .line 22
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 23
    .line 24
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 25
    .line 26
    const/4 v5, 0x0

    .line 27
    invoke-static {v2, v1, v0}, LX/2pj;->A09(LX/3C1;FF)LX/3C1;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    move-object/from16 v0, p0

    .line 32
    .line 33
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$3;->$subjectLabel:Ljava/lang/String;

    .line 34
    .line 35
    const/4 v8, 0x0

    .line 36
    const/16 p2, 0x3ff4

    .line 37
    .line 38
    const-wide/16 v2, 0x0

    .line 39
    .line 40
    move-object v6, v5

    .line 41
    move-object v7, v5

    .line 42
    move v9, v8

    .line 43
    move v10, v8

    .line 44
    move v11, v8

    .line 45
    move-object v12, v5

    .line 46
    move-object v13, v5

    .line 47
    move-object v14, v5

    .line 48
    move/from16 p0, v8

    .line 49
    .line 50
    move/from16 p1, v8

    .line 51
    .line 52
    invoke-static/range {v0 .. v18}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_0
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 57
    .line 58
    .line 59
    return-void
.end method
