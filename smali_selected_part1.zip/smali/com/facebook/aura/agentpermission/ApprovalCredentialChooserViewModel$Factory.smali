.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;",
        ">;"
    }
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field public final approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final marker:Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->userSession:LX/AHE;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->marker:Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->create()Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;
    .locals 8

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iget-object v4, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->marker:Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;->REQUIRED:Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;

    .line 7
    .line 8
    invoke-static {v1, v0}, LX/003;->A1T(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v5

    .line 12
    iget-object v0, v2, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {}, LX/001;->A11()Ljava/util/ArrayList;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    move-object v0, v1

    .line 33
    check-cast v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 34
    .line 35
    invoke-static {v0}, Lcom/facebook/aura/gateway/ApprovalCredentialSelectionKt;->takesCredential(Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_0

    .line 40
    .line 41
    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    invoke-static {}, LX/001;->A17()Ljava/util/LinkedHashSet;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_2

    .line 58
    .line 59
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    check-cast v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 64
    .line 65
    iget-object v0, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual {v6, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 72
    .line 73
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 74
    .line 75
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_4

    .line 84
    .line 85
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    move-object v0, v7

    .line 90
    check-cast v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 91
    .line 92
    iget-object v1, v0, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;->kind:Ljava/lang/String;

    .line 93
    .line 94
    sget-object v0, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->ALLOW_ONCE:Lcom/facebook/aura/gateway/ApprovalRecordDecision;

    .line 95
    .line 96
    invoke-virtual {v0}, Lcom/facebook/aura/gateway/ApprovalRecordDecision;->getWireValue()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_3

    .line 105
    .line 106
    :goto_2
    check-cast v7, Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 107
    .line 108
    sget-object v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;->Companion:Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;

    .line 109
    .line 110
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;->userSession:LX/AHE;

    .line 111
    .line 112
    invoke-virtual {v1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 117
    .line 118
    invoke-direct/range {v3 .. v8}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;-><init>(Ljava/lang/String;ZLjava/util/Set;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;Lcom/facebook/aura/agentpermission/ApprovalCredentialSelections;)V

    .line 119
    .line 120
    .line 121
    return-object v3

    .line 122
    :cond_4
    const/4 v7, 0x0

    .line 123
    goto :goto_2
.end method
