.class public final Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approvals:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $sessionId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$approvals:Ljava/util/List;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$sessionId:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 10

    .line 0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_BANNER_REVIEW_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$approvals:Ljava/util/List;

    .line 11
    .line 12
    invoke-static {v0}, LX/B89;->A0Y(Ljava/util/List;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 17
    .line 18
    const/4 v9, 0x0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    iget-object v7, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 22
    .line 23
    :goto_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$approvals:Ljava/util/List;

    .line 24
    .line 25
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const-string v0, "approval_count"

    .line 34
    .line 35
    invoke-static {v0, v1}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    invoke-virtual/range {v2 .. v9}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$approvals:Ljava/util/List;

    .line 43
    .line 44
    invoke-static {v0}, LX/B89;->A0Y(Ljava/util/List;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 49
    .line 50
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 51
    .line 52
    if-eqz v0, :cond_0

    .line 53
    .line 54
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 55
    .line 56
    new-instance v2, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;

    .line 57
    .line 58
    invoke-direct {v2, v0}, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;-><init>(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :goto_1
    const/4 v0, 0x0

    .line 62
    invoke-interface {v3, v2, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 63
    .line 64
    .line 65
    return-void

    .line 66
    :cond_0
    sget-object v1, Lcom/facebook/aura/navigation/key/HatchStatusTab;->APPROVALS:Lcom/facebook/aura/navigation/key/HatchStatusTab;

    .line 67
    .line 68
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;->$sessionId:Ljava/lang/String;

    .line 69
    .line 70
    new-instance v2, Lcom/facebook/aura/navigation/key/HatchStatusScreenKey;

    .line 71
    .line 72
    invoke-direct {v2, v1, v0, v9, v9}, Lcom/facebook/aura/navigation/key/HatchStatusScreenKey;-><init>(Lcom/facebook/aura/navigation/key/HatchStatusTab;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_1
    move-object v7, v9

    .line 77
    goto :goto_0
.end method
