.class public abstract Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final ApprovalCardProgressMessage(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 28

    .line 0
    move-object/from16 v6, p1

    .line 1
    .line 2
    const/4 v4, 0x0

    .line 3
    move-object/from16 v14, p0

    .line 4
    .line 5
    invoke-static {v14, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x33deb64e    # -4.228065E7f

    .line 9
    .line 10
    .line 11
    move-object/from16 v3, p2

    .line 12
    .line 13
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v2, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_4

    .line 21
    .line 22
    invoke-static {v3, v14}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    or-int v5, p3, v0

    .line 27
    .line 28
    :goto_0
    move/from16 v8, p4

    .line 29
    .line 30
    and-int/lit8 v9, p4, 0x2

    .line 31
    .line 32
    if-eqz v9, :cond_3

    .line 33
    .line 34
    or-int/lit8 v5, v5, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    and-int/lit8 v7, v5, 0x13

    .line 37
    .line 38
    const/16 v0, 0x12

    .line 39
    .line 40
    const/4 v1, 0x1

    .line 41
    invoke-static {v7, v0}, LX/003;->A1H(II)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0, v3, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_5

    .line 50
    .line 51
    if-eqz v9, :cond_1

    .line 52
    .line 53
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 54
    .line 55
    :cond_1
    invoke-static {v6}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 56
    .line 57
    .line 58
    move-result-object v9

    .line 59
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v7

    .line 63
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 64
    .line 65
    if-ne v7, v0, :cond_2

    .line 66
    .line 67
    sget-object v7, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardProgressMessage$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardProgressMessage$1$1;

    .line 68
    .line 69
    invoke-interface {v3, v7}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    invoke-static {v9, v7, v1}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 73
    .line 74
    .line 75
    move-result-object v10

    .line 76
    sget v7, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 77
    .line 78
    sget-object v0, LX/2Id;->A00:LX/2sS;

    .line 79
    .line 80
    invoke-static {v0, v7}, LX/Dn6;->A01(LX/2sS;F)LX/CP5;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    sget-object v7, LX/2Id;->A04:LX/2rU;

    .line 85
    .line 86
    const/16 v0, 0x30

    .line 87
    .line 88
    invoke-static {v9, v3, v7, v0}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 89
    .line 90
    .line 91
    move-result-object v13

    .line 92
    move-object v0, v3

    .line 93
    check-cast v0, LX/J7I;

    .line 94
    .line 95
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 96
    .line 97
    .line 98
    move-result v12

    .line 99
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 100
    .line 101
    .line 102
    move-result-object v11

    .line 103
    invoke-static {v3, v10}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 104
    .line 105
    .line 106
    move-result-object v10

    .line 107
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 108
    .line 109
    iget-object v7, v0, LX/J7I;->A0V:LX/3DJ;

    .line 110
    .line 111
    if-nez v7, :cond_6

    .line 112
    .line 113
    invoke-static {}, LX/1VY;->A00()V

    .line 114
    .line 115
    .line 116
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    throw v0

    .line 121
    :cond_3
    and-int/lit8 v0, p3, 0x30

    .line 122
    .line 123
    if-nez v0, :cond_0

    .line 124
    .line 125
    invoke-static {v3, v6}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    or-int/2addr v5, v0

    .line 130
    goto :goto_1

    .line 131
    :cond_4
    move v5, v2

    .line 132
    goto :goto_0

    .line 133
    :cond_5
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 134
    .line 135
    .line 136
    goto :goto_2

    .line 137
    :cond_6
    invoke-static {v3, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 138
    .line 139
    .line 140
    invoke-static {v3, v13, v11, v10, v12}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 141
    .line 142
    .line 143
    sget-object v7, LX/CgK;->A00:LX/CgK;

    .line 144
    .line 145
    const/16 v25, 0x7

    .line 146
    .line 147
    const/16 v19, 0x0

    .line 148
    .line 149
    const-wide/16 v21, 0x0

    .line 150
    .line 151
    move-object/from16 v20, v19

    .line 152
    .line 153
    move-object/from16 v23, v3

    .line 154
    .line 155
    move/from16 v24, v4

    .line 156
    .line 157
    invoke-static/range {v19 .. v25}, Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerKt;->AuraSpinner-FNF3uiM(LX/3C1;Lcom/facebook/aura/vds/compose/spinner/AuraSpinnerStyle;JLX/2d4;II)V

    .line 158
    .line 159
    .line 160
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 161
    .line 162
    invoke-static {v3, v9}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 163
    .line 164
    .line 165
    move-result-object v18

    .line 166
    invoke-static {v3, v9}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 167
    .line 168
    .line 169
    move-result-wide v16

    .line 170
    const/4 v10, 0x5

    .line 171
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 172
    .line 173
    invoke-static {v7, v9, v4}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 174
    .line 175
    .line 176
    move-result-object v15

    .line 177
    invoke-static {v10}, LX/2wS;->A01(I)LX/2wS;

    .line 178
    .line 179
    .line 180
    move-result-object v21

    .line 181
    and-int/lit8 p2, v5, 0xe

    .line 182
    .line 183
    const/16 p4, 0x3fb0

    .line 184
    .line 185
    move/from16 v22, v4

    .line 186
    .line 187
    move/from16 v23, v4

    .line 188
    .line 189
    move/from16 v25, v4

    .line 190
    .line 191
    move-object/from16 v26, v19

    .line 192
    .line 193
    move-object/from16 v27, v19

    .line 194
    .line 195
    move-object/from16 p0, v19

    .line 196
    .line 197
    move-object/from16 p1, v3

    .line 198
    .line 199
    move/from16 p3, v4

    .line 200
    .line 201
    invoke-static/range {v14 .. v32}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 202
    .line 203
    .line 204
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 205
    .line 206
    .line 207
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    if-eqz v1, :cond_7

    .line 212
    .line 213
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardProgressMessage$3;

    .line 214
    .line 215
    invoke-direct {v0, v14, v6, v2, v8}, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardProgressMessage$3;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 216
    .line 217
    .line 218
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 219
    .line 220
    :cond_7
    return-void
.end method

.method public static final ApprovalCardStatusMessage-8V94_ZQ(Ljava/lang/String;JLX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/2d4;II)V
    .locals 46
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "LX/3C1;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v15, p3

    .line 1
    .line 2
    move-object/from16 v7, p4

    .line 3
    .line 4
    move-object/from16 v2, p5

    .line 5
    .line 6
    const/4 v4, 0x0

    .line 7
    move-object/from16 p5, p0

    .line 8
    .line 9
    move-object/from16 v0, p5

    .line 10
    .line 11
    invoke-static {v0, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 12
    .line 13
    .line 14
    const v0, 0xec6c951

    .line 15
    .line 16
    .line 17
    move-object/from16 v6, p6

    .line 18
    .line 19
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 20
    .line 21
    .line 22
    move/from16 v5, p7

    .line 23
    .line 24
    and-int/lit8 v0, p7, 0x6

    .line 25
    .line 26
    if-nez v0, :cond_b

    .line 27
    .line 28
    move-object/from16 v0, p5

    .line 29
    .line 30
    invoke-static {v6, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    or-int v3, v3, p7

    .line 35
    .line 36
    :goto_0
    and-int/lit8 v0, p7, 0x30

    .line 37
    .line 38
    move-wide/from16 p3, p1

    .line 39
    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    move-wide/from16 v0, p3

    .line 43
    .line 44
    invoke-static {v6, v0, v1}, LX/008;->A0N(LX/2d4;J)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    or-int/2addr v3, v0

    .line 49
    :cond_0
    move/from16 p2, p8

    .line 50
    .line 51
    and-int/lit8 v1, p8, 0x4

    .line 52
    .line 53
    if-eqz v1, :cond_a

    .line 54
    .line 55
    or-int/lit16 v3, v3, 0x180

    .line 56
    .line 57
    :cond_1
    :goto_1
    and-int/lit8 v9, p8, 0x8

    .line 58
    .line 59
    if-eqz v9, :cond_9

    .line 60
    .line 61
    or-int/lit16 v3, v3, 0xc00

    .line 62
    .line 63
    :cond_2
    :goto_2
    and-int/lit8 v8, p8, 0x10

    .line 64
    .line 65
    if-eqz v8, :cond_8

    .line 66
    .line 67
    or-int/lit16 v3, v3, 0x6000

    .line 68
    .line 69
    :cond_3
    :goto_3
    invoke-static {v3}, LX/009;->A1I(I)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-static {v0, v6, v3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_c

    .line 78
    .line 79
    if-eqz v1, :cond_4

    .line 80
    .line 81
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 82
    .line 83
    :cond_4
    const/4 v1, 0x0

    .line 84
    if-eqz v9, :cond_5

    .line 85
    .line 86
    move-object v7, v1

    .line 87
    :cond_5
    if-eqz v8, :cond_7

    .line 88
    .line 89
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 94
    .line 95
    if-ne v2, v0, :cond_6

    .line 96
    .line 97
    sget-object v2, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$1$1;

    .line 98
    .line 99
    invoke-interface {v6, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_6
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 103
    .line 104
    :cond_7
    invoke-static {v15}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    sget-object v9, LX/2Id;->A00:LX/2sS;

    .line 109
    .line 110
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 111
    .line 112
    invoke-static {v0}, LX/Dn6;->A00(F)LX/CP5;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    const/16 v10, 0x30

    .line 117
    .line 118
    invoke-static {v0, v6, v9, v10}, LX/1hu;->A00(LX/Dps;LX/2d4;LX/2sS;I)LX/3BI;

    .line 119
    .line 120
    .line 121
    move-result-object v14

    .line 122
    move-object v0, v6

    .line 123
    check-cast v0, LX/J7I;

    .line 124
    .line 125
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 126
    .line 127
    .line 128
    move-result v13

    .line 129
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 130
    .line 131
    .line 132
    move-result-object v12

    .line 133
    invoke-static {v6, v8}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 134
    .line 135
    .line 136
    move-result-object v11

    .line 137
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 138
    .line 139
    iget-object v8, v0, LX/J7I;->A0V:LX/3DJ;

    .line 140
    .line 141
    if-nez v8, :cond_d

    .line 142
    .line 143
    invoke-static {}, LX/1VY;->A00()V

    .line 144
    .line 145
    .line 146
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    throw v0

    .line 151
    :cond_8
    and-int/lit16 v0, v5, 0x6000

    .line 152
    .line 153
    if-nez v0, :cond_3

    .line 154
    .line 155
    invoke-static {v6, v2}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    or-int/2addr v3, v0

    .line 160
    goto :goto_3

    .line 161
    :cond_9
    and-int/lit16 v0, v5, 0xc00

    .line 162
    .line 163
    if-nez v0, :cond_2

    .line 164
    .line 165
    invoke-static {v6, v7}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    or-int/2addr v3, v0

    .line 170
    goto :goto_2

    .line 171
    :cond_a
    and-int/lit16 v0, v5, 0x180

    .line 172
    .line 173
    if-nez v0, :cond_1

    .line 174
    .line 175
    invoke-static {v6, v15}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    or-int/2addr v3, v0

    .line 180
    goto :goto_1

    .line 181
    :cond_b
    move v3, v5

    .line 182
    goto/16 :goto_0

    .line 183
    .line 184
    :cond_c
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 185
    .line 186
    .line 187
    goto/16 :goto_5

    .line 188
    .line 189
    :cond_d
    invoke-static {v6, v0, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 190
    .line 191
    .line 192
    invoke-static {v6, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 193
    .line 194
    .line 195
    invoke-static {v6}, LX/007;->A0j(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 196
    .line 197
    .line 198
    move-result-object v8

    .line 199
    iget-object v8, v8, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->footnoteRegular:LX/2hg;

    .line 200
    .line 201
    const/4 v13, 0x3

    .line 202
    sget-object v12, LX/3C1;->A00:LX/3Cb;

    .line 203
    .line 204
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v11

    .line 208
    sget-object v9, LX/2d6;->A00:Ljava/lang/Object;

    .line 209
    .line 210
    if-ne v11, v9, :cond_e

    .line 211
    .line 212
    sget-object v11, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$2$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$2$1$1;

    .line 213
    .line 214
    invoke-interface {v6, v11}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    :cond_e
    invoke-static {v12, v11, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 218
    .line 219
    .line 220
    move-result-object v17

    .line 221
    invoke-static {v13}, LX/2wS;->A01(I)LX/2wS;

    .line 222
    .line 223
    .line 224
    move-result-object v23

    .line 225
    and-int/lit8 v32, v3, 0xe

    .line 226
    .line 227
    shl-int/lit8 v9, v3, 0x3

    .line 228
    .line 229
    and-int/lit16 v9, v9, 0x380

    .line 230
    .line 231
    or-int v32, v32, v9

    .line 232
    .line 233
    const/16 v34, 0x3fb0

    .line 234
    .line 235
    move-object/from16 v16, p5

    .line 236
    .line 237
    move-wide/from16 v18, p3

    .line 238
    .line 239
    move-object/from16 v20, v8

    .line 240
    .line 241
    move-object/from16 v21, v1

    .line 242
    .line 243
    move-object/from16 v22, v1

    .line 244
    .line 245
    move/from16 v24, v4

    .line 246
    .line 247
    move/from16 v25, v4

    .line 248
    .line 249
    move/from16 v26, v4

    .line 250
    .line 251
    move/from16 v27, v4

    .line 252
    .line 253
    move-object/from16 v28, v1

    .line 254
    .line 255
    move-object/from16 v29, v1

    .line 256
    .line 257
    move-object/from16 v30, v1

    .line 258
    .line 259
    move-object/from16 v31, v6

    .line 260
    .line 261
    move/from16 v33, v4

    .line 262
    .line 263
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 264
    .line 265
    .line 266
    if-eqz v7, :cond_10

    .line 267
    .line 268
    const v8, -0x5485a3cd

    .line 269
    .line 270
    .line 271
    invoke-interface {v6, v8}, LX/2d4;->Agj(I)V

    .line 272
    .line 273
    .line 274
    sget-object v9, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 275
    .line 276
    const/4 v8, 0x1

    .line 277
    invoke-virtual {v9, v1, v6, v10, v8}, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->secondary(Lcom/facebook/aura/vds/compose/button/AuraButtonCorner;LX/2d4;II)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 278
    .line 279
    .line 280
    move-result-object v20

    .line 281
    sget-object v21, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 282
    .line 283
    shr-int/lit8 v8, v3, 0x6

    .line 284
    .line 285
    and-int/lit8 v44, v8, 0x70

    .line 286
    .line 287
    const/high16 v8, 0x30000

    .line 288
    .line 289
    or-int v44, v44, v8

    .line 290
    .line 291
    const v8, 0xe000

    .line 292
    .line 293
    .line 294
    and-int/2addr v3, v8

    .line 295
    const p1, 0x7ffbfcd

    .line 296
    .line 297
    .line 298
    move-object/from16 v18, v1

    .line 299
    .line 300
    move-object/from16 v19, v1

    .line 301
    .line 302
    move-object/from16 v30, v2

    .line 303
    .line 304
    move-object/from16 v31, v1

    .line 305
    .line 306
    move-object/from16 v32, v1

    .line 307
    .line 308
    move-object/from16 v33, v1

    .line 309
    .line 310
    move-object/from16 v34, v1

    .line 311
    .line 312
    move-object/from16 v35, v1

    .line 313
    .line 314
    move-object/from16 v36, v1

    .line 315
    .line 316
    move-object/from16 v37, v1

    .line 317
    .line 318
    move-object/from16 v38, v1

    .line 319
    .line 320
    move/from16 v39, v4

    .line 321
    .line 322
    move/from16 v40, v4

    .line 323
    .line 324
    move/from16 v41, v4

    .line 325
    .line 326
    move/from16 v42, v4

    .line 327
    .line 328
    move-object/from16 v43, v6

    .line 329
    .line 330
    move/from16 v45, v3

    .line 331
    .line 332
    move/from16 p0, v4

    .line 333
    .line 334
    move-object/from16 v16, v1

    .line 335
    .line 336
    move-object/from16 v17, v7

    .line 337
    .line 338
    move/from16 v23, v4

    .line 339
    .line 340
    invoke-static/range {v16 .. v47}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 341
    .line 342
    .line 343
    :goto_4
    invoke-static {v0}, LX/003;->A0u(LX/J7I;)V

    .line 344
    .line 345
    .line 346
    :goto_5
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    if-eqz v1, :cond_f

    .line 351
    .line 352
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$3;

    .line 353
    .line 354
    move-object/from16 v40, v0

    .line 355
    .line 356
    move-object/from16 v41, p5

    .line 357
    .line 358
    move-wide/from16 v42, p3

    .line 359
    .line 360
    move-object/from16 v44, v15

    .line 361
    .line 362
    move-object/from16 v45, v7

    .line 363
    .line 364
    move-object/from16 p0, v2

    .line 365
    .line 366
    move/from16 p1, v5

    .line 367
    .line 368
    invoke-direct/range {v40 .. v48}, Lcom/facebook/aura/agentpermission/ApprovalCardStatusKt$ApprovalCardStatusMessage$3;-><init>(Ljava/lang/String;JLX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;II)V

    .line 369
    .line 370
    .line 371
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 372
    .line 373
    :cond_f
    return-void

    .line 374
    :cond_10
    const v1, -0x54830019

    .line 375
    .line 376
    .line 377
    invoke-interface {v6, v1}, LX/2d4;->Agj(I)V

    .line 378
    .line 379
    .line 380
    goto :goto_4
.end method
