.class public final Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Ljava/lang/Integer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $decodedAspectRatio:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;->$decodedAspectRatio:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 268435456
    invoke-static {p1}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v1

    .line 268435460
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, v1, v0}, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;->invoke(II)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(II)V
    .locals 2

    .line 0
    if-lez p1, :cond_0

    .line 1
    .line 2
    if-lez p2, :cond_0

    .line 3
    .line 4
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;->$decodedAspectRatio:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    int-to-float v1, p1

    .line 7
    int-to-float v0, p2

    .line 8
    div-float/2addr v1, v0

    .line 9
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-interface {p0, v0}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method
