.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/JDM<",
        "Ljava/lang/Integer;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $items:Ljava/util/List;

.field public final synthetic $key:LX/JDN;


# direct methods
.method public constructor <init>(LX/JDN;Ljava/util/List;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;->$key:LX/JDN;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;->$items:Ljava/util/List;

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final invoke(I)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;->$key:LX/JDN;

    .line 1
    .line 2
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;->$items:Ljava/util/List;

    .line 7
    .line 8
    invoke-static {v1, v0, v2, p1}, LX/007;->A0x(Ljava/lang/Object;Ljava/util/List;LX/JDN;I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$openApprovalsSection$$inlined$itemsIndexed$1;->invoke(I)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object v0

    .line 268435464
    return-object v0
.end method
