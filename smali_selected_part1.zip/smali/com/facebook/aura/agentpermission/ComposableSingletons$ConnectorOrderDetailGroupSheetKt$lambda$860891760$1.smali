.class public final Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDO;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDO<",
        "LX/3dS;",
        "Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x4

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 268435459
    .line 268435460
    check-cast p3, LX/2d4;

    .line 268435461
    .line 268435462
    invoke-static {p4}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435463
    .line 268435464
    .line 268435465
    move-result v0

    .line 268435466
    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1;->invoke(LX/3dS;Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;LX/2d4;I)V

    .line 268435467
    .line 268435468
    .line 268435469
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435470
    .line 268435471
    return-object v0
.end method

.method public final invoke(LX/3dS;Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;LX/2d4;I)V
    .locals 11

    .line 0
    move-object v6, p1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v8

    .line 6
    and-int/lit8 v0, p4, 0x6

    .line 7
    .line 8
    move-object p2, p3

    .line 9
    if-nez v0, :cond_5

    .line 10
    .line 11
    invoke-static {p3, p1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    or-int v2, p4, v0

    .line 16
    .line 17
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 18
    .line 19
    const/16 v5, 0x20

    .line 20
    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    invoke-static {v3, p3, p4}, LX/005;->A1X(Ljava/lang/Object;LX/2d4;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {v0}, LX/003;->A07(I)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    or-int/2addr v2, v0

    .line 32
    :cond_0
    and-int/lit16 v1, v2, 0x93

    .line 33
    .line 34
    const/16 v0, 0x92

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-static {v0, p3, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_6

    .line 46
    .line 47
    new-instance v1, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;

    .line 48
    .line 49
    invoke-direct {v1, v3}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;-><init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V

    .line 50
    .line 51
    .line 52
    const v0, 0x1e361e5c

    .line 53
    .line 54
    .line 55
    invoke-static {p3, v1, v0}, LX/Ddp;->A00(LX/2d4;Ljava/lang/Object;I)LX/Ddo;

    .line 56
    .line 57
    .line 58
    move-result-object v9

    .line 59
    invoke-static {p3}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iget-wide v10, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->card:J

    .line 64
    .line 65
    and-int/lit8 v0, v2, 0x70

    .line 66
    .line 67
    if-eq v0, v5, :cond_1

    .line 68
    .line 69
    and-int/lit8 v0, v2, 0x40

    .line 70
    .line 71
    if-eqz v0, :cond_2

    .line 72
    .line 73
    invoke-interface {p3, v3}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_2

    .line 78
    .line 79
    :cond_1
    const/4 v4, 0x1

    .line 80
    :cond_2
    invoke-interface {p3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    if-nez v4, :cond_3

    .line 85
    .line 86
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 87
    .line 88
    if-ne p1, v0, :cond_4

    .line 89
    .line 90
    :cond_3
    new-instance p1, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;

    .line 91
    .line 92
    invoke-direct {p1, v3}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;-><init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V

    .line 93
    .line 94
    .line 95
    invoke-interface {p3, p1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_4
    check-cast p1, LX/JDM;

    .line 99
    .line 100
    and-int/lit8 v0, v2, 0xe

    .line 101
    .line 102
    or-int/lit16 p3, v0, 0xc00

    .line 103
    .line 104
    const/4 p4, 0x3

    .line 105
    const/4 v7, 0x0

    .line 106
    invoke-static/range {v6 .. v15}, Lcom/facebook/aura/ui/HatchSectionKt;->HatchSection-FHprtrg(LX/3dS;LX/3C1;ZLX/JDN;JLX/JDM;LX/2d4;II)V

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :cond_5
    move v2, p4

    .line 111
    goto :goto_0

    .line 112
    :cond_6
    invoke-interface {p3}, LX/2d4;->AgJ()V

    .line 113
    .line 114
    .line 115
    return-void
.end method
