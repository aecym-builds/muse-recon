.class public final Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDQ<",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;",
        "LX/2M4<",
        "-",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionPendingCardViewModel$submittingApprovalIds$1"
    f = "AgentPermissionPendingCardViewModel.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public synthetic L$0:Ljava/lang/Object;

.field public synthetic L$1:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0, p1}, LX/DRu;-><init>(ILX/2M4;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/util/Set;

    .line 268435457
    .line 268435458
    check-cast p2, Ljava/util/Set;

    .line 268435459
    .line 268435460
    check-cast p3, LX/2M4;

    .line 268435461
    .line 268435462
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->invoke(Ljava/util/Set;Ljava/util/Set;LX/2M4;)Ljava/lang/Object;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object p0

    .line 268435466
    return-object p0
.end method

.method public final invoke(Ljava/util/Set;Ljava/util/Set;LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    new-instance p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;

    .line 1
    .line 2
    invoke-direct {p0, p3}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->L$0:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->L$1:Ljava/lang/Object;

    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->L$0:Ljava/lang/Object;

    .line 1
    .line 2
    check-cast v2, Ljava/util/Set;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->L$1:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Ljava/lang/Iterable;

    .line 7
    .line 8
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardViewModel$submittingApprovalIds$1;->label:I

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v1, v2}, LX/163;->A00(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0

    .line 20
    :cond_0
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    throw v0
.end method
