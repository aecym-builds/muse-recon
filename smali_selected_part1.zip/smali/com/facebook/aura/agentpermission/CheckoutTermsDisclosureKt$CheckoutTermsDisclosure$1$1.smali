.class public final Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onLinkClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $text:LX/2iK;

.field public final synthetic $uriHandler:LX/18m;


# direct methods
.method public constructor <init>(LX/2iK;Lkotlin/jvm/functions/Function0;LX/18m;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2iK;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/18m;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$text:LX/2iK;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$onLinkClick:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$uriHandler:LX/18m;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    invoke-static {p1}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435457
    .line 268435458
    .line 268435459
    move-result v0

    .line 268435460
    invoke-virtual {p0, v0}, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->invoke(I)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object v0
.end method

.method public final invoke(I)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$text:LX/2iK;

    .line 1
    .line 2
    invoke-virtual {v0, p1, p1}, LX/2iK;->A04(II)Ljava/util/List;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, LX/B89;->A0U(Ljava/util/List;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, LX/2aw;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$onLinkClick:Lkotlin/jvm/functions/Function0;

    .line 15
    .line 16
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/CheckoutTermsDisclosureKt$CheckoutTermsDisclosure$1$1;->$uriHandler:LX/18m;

    .line 17
    .line 18
    iget-object v0, v0, LX/2aw;->A02:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, LX/2D6;

    .line 21
    .line 22
    iget-object v1, v0, LX/2D6;->A00:Ljava/lang/String;

    .line 23
    .line 24
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    :try_start_0
    invoke-interface {p0, v1}, LX/18m;->openUri(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 31
    :catch_0
    move-exception p0

    .line 32
    const-string v0, "Failed to open checkout terms URL: "

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    const-string v0, "CheckoutTermsDisclosure"

    .line 39
    .line 40
    invoke-static {v0, v1, p0}, LX/FnY;->A0A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    return-void
.end method
