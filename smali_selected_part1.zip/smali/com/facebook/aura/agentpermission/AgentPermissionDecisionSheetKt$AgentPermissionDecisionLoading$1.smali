.class public final Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $loadingDescription:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;->$loadingDescription:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 5

    .line 0
    and-int/lit8 v1, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    const/4 v4, 0x0

    .line 5
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_3

    .line 14
    .line 15
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 16
    .line 17
    const/high16 v0, 0x42f00000    # 120.0f

    .line 18
    .line 19
    invoke-static {v1, v0}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;->$loadingDescription:Ljava/lang/String;

    .line 24
    .line 25
    invoke-interface {p2, v0}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1;->$loadingDescription:Ljava/lang/String;

    .line 30
    .line 31
    invoke-interface {p2}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-nez v1, :cond_0

    .line 36
    .line 37
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 38
    .line 39
    if-ne v0, v1, :cond_1

    .line 40
    .line 41
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1$1$1;

    .line 42
    .line 43
    invoke-direct {v0, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionDecisionSheetKt$AgentPermissionDecisionLoading$1$1$1;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-interface {p2, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :cond_1
    invoke-static {v3, v0, v4}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    move-object p0, p2

    .line 58
    check-cast p0, LX/J7I;

    .line 59
    .line 60
    invoke-static {p0}, LX/003;->A0F(LX/J7I;)I

    .line 61
    .line 62
    .line 63
    move-result v4

    .line 64
    invoke-static {p0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    invoke-static {p2, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 73
    .line 74
    iget-object v0, p0, LX/J7I;->A0V:LX/3DJ;

    .line 75
    .line 76
    if-nez v0, :cond_2

    .line 77
    .line 78
    invoke-static {}, LX/1VY;->A00()V

    .line 79
    .line 80
    .line 81
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    throw v0

    .line 86
    :cond_2
    invoke-static {p2, p0, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 87
    .line 88
    .line 89
    invoke-static {p2, p1, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 90
    .line 91
    .line 92
    invoke-static {p2, p0}, LX/009;->A0u(LX/2d4;LX/J7I;)V

    .line 93
    .line 94
    .line 95
    return-void

    .line 96
    :cond_3
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 97
    .line 98
    .line 99
    return-void
.end method
