.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $$default:I

.field public final synthetic $enabled:Z

.field public final synthetic $modifier:LX/3C1;

.field public final synthetic $onEnterLogin:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onReload:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "II)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 1
    .line 2
    iput-boolean p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$enabled:Z

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onSelect:LX/JDM;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onReload:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onEnterLogin:LX/JDM;

    .line 9
    .line 10
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$modifier:LX/3C1;

    .line 11
    .line 12
    iput p7, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$$changed:I

    .line 13
    .line 14
    iput p8, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$$default:I

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 9

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 1
    .line 2
    iget-boolean v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$enabled:Z

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onSelect:LX/JDM;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onReload:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$onEnterLogin:LX/JDM;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$modifier:LX/3C1;

    .line 11
    .line 12
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$$changed:I

    .line 13
    .line 14
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 15
    .line 16
    .line 17
    move-result v8

    .line 18
    iget p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;->$$default:I

    .line 19
    .line 20
    move-object v7, p1

    .line 21
    invoke-static/range {v1 .. v9}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialChooser(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
