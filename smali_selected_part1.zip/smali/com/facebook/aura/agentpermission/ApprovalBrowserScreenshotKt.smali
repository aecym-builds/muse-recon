.class public abstract Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FallbackAspectRatio:F = 1.7777778f

.field public static final PortraitFrameAspectRatio:F = 1.3333334f


# direct methods
.method public static final ApprovalBrowserScreenshot(Ljava/lang/String;Ljava/lang/Float;LX/2bW;LX/3C1;LX/JDQ;LX/2d4;II)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Float;",
            "LX/2bW;",
            "LX/3C1;",
            "LX/JDQ<",
            "-",
            "LX/33K;",
            "-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v8, p3

    .line 1
    .line 2
    move-object/from16 v7, p4

    .line 3
    .line 4
    const/4 v1, 0x2

    .line 5
    move-object/from16 p4, p2

    .line 6
    .line 7
    move-object/from16 v0, p4

    .line 8
    .line 9
    invoke-static {v0, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 10
    .line 11
    .line 12
    const v0, -0x8a15b53

    .line 13
    .line 14
    .line 15
    move-object/from16 v6, p5

    .line 16
    .line 17
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 18
    .line 19
    .line 20
    move/from16 v5, p6

    .line 21
    .line 22
    and-int/lit8 v0, p6, 0x6

    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    move-object/from16 v21, p0

    .line 26
    .line 27
    if-nez v0, :cond_12

    .line 28
    .line 29
    move-object/from16 v0, v21

    .line 30
    .line 31
    invoke-static {v6, v0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    or-int v4, v4, p6

    .line 36
    .line 37
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 38
    .line 39
    move-object/from16 v20, p1

    .line 40
    .line 41
    if-nez v0, :cond_0

    .line 42
    .line 43
    move-object/from16 v0, v20

    .line 44
    .line 45
    invoke-static {v6, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v4, v0

    .line 50
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 51
    .line 52
    if-nez v0, :cond_1

    .line 53
    .line 54
    move-object/from16 v0, p4

    .line 55
    .line 56
    invoke-static {v6, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    or-int/2addr v4, v0

    .line 61
    :cond_1
    move/from16 p3, p7

    .line 62
    .line 63
    and-int/lit8 v10, p7, 0x8

    .line 64
    .line 65
    if-eqz v10, :cond_11

    .line 66
    .line 67
    or-int/lit16 v4, v4, 0xc00

    .line 68
    .line 69
    :cond_2
    :goto_1
    and-int/lit8 v9, p7, 0x10

    .line 70
    .line 71
    if-eqz v9, :cond_10

    .line 72
    .line 73
    or-int/lit16 v4, v4, 0x6000

    .line 74
    .line 75
    :cond_3
    :goto_2
    and-int/lit16 v2, v4, 0x2493

    .line 76
    .line 77
    const/16 v0, 0x2492

    .line 78
    .line 79
    const/4 v3, 0x0

    .line 80
    invoke-static {v2, v0}, LX/003;->A1H(II)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    invoke-static {v0, v6, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_17

    .line 89
    .line 90
    if-eqz v10, :cond_4

    .line 91
    .line 92
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 93
    .line 94
    :cond_4
    if-eqz v9, :cond_5

    .line 95
    .line 96
    sget-object v7, Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt;->lambda$2133090866:LX/JDQ;

    .line 97
    .line 98
    :cond_5
    and-int/lit8 v2, v4, 0xe

    .line 99
    .line 100
    invoke-static {v2, v1}, LX/003;->A1I(II)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v9

    .line 108
    const/16 v19, 0x0

    .line 109
    .line 110
    if-nez v0, :cond_6

    .line 111
    .line 112
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 113
    .line 114
    if-ne v9, v0, :cond_7

    .line 115
    .line 116
    :cond_6
    move-object/from16 v0, v19

    .line 117
    .line 118
    invoke-static {v6, v0}, LX/005;->A0X(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 119
    .line 120
    .line 121
    move-result-object v9

    .line 122
    :cond_7
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .line 123
    .line 124
    invoke-interface {v6, v9}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v10

    .line 132
    if-nez v0, :cond_8

    .line 133
    .line 134
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 135
    .line 136
    if-ne v10, v0, :cond_9

    .line 137
    .line 138
    :cond_8
    new-instance v10, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;

    .line 139
    .line 140
    invoke-direct {v10, v9}, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$onImageSizeDecoded$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 141
    .line 142
    .line 143
    invoke-interface {v6, v10}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_9
    check-cast v10, LX/JDN;

    .line 147
    .line 148
    if-eqz p1, :cond_e

    .line 149
    .line 150
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->floatValue()F

    .line 151
    .line 152
    .line 153
    move-result v13

    .line 154
    :goto_3
    const/high16 v0, 0x3f800000    # 1.0f

    .line 155
    .line 156
    cmpg-float v0, v13, v0

    .line 157
    .line 158
    const/16 v18, 0x1

    .line 159
    .line 160
    if-ltz v0, :cond_a

    .line 161
    .line 162
    :goto_4
    const/16 v18, 0x0

    .line 163
    .line 164
    :cond_a
    invoke-static {v2, v1}, LX/003;->A1I(II)Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v12

    .line 172
    if-nez v0, :cond_b

    .line 173
    .line 174
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 175
    .line 176
    if-ne v12, v0, :cond_c

    .line 177
    .line 178
    :cond_b
    new-instance v12, LX/3Lr;

    .line 179
    .line 180
    invoke-direct {v12, v3}, LX/3Lr;-><init>(I)V

    .line 181
    .line 182
    .line 183
    invoke-interface {v6, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    :cond_c
    check-cast v12, LX/3Lr;

    .line 187
    .line 188
    sget-object v11, LX/2sI;->A02:LX/2wD;

    .line 189
    .line 190
    invoke-interface {v8, v11}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    move v0, v13

    .line 195
    if-eqz v18, :cond_d

    .line 196
    .line 197
    const v0, 0x3faaaaab

    .line 198
    .line 199
    .line 200
    :cond_d
    invoke-static {v1, v0, v6, v3}, Lcom/facebook/aura/ui/BrowserScreenshotSizeKt;->browserScreenshotSize(LX/3C1;FLX/2d4;I)LX/3C1;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    move-object/from16 v0, p4

    .line 205
    .line 206
    invoke-static {v1, v0}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-static {v6, v0}, LX/07H;->A0A(LX/2d4;LX/3C1;)LX/3C1;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    invoke-static {v3}, LX/001;->A0g(Z)LX/3BI;

    .line 215
    .line 216
    .line 217
    move-result-object v17

    .line 218
    move-object v1, v6

    .line 219
    check-cast v1, LX/J7I;

    .line 220
    .line 221
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 222
    .line 223
    .line 224
    move-result v16

    .line 225
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 226
    .line 227
    .line 228
    move-result-object v15

    .line 229
    invoke-static {v6, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 230
    .line 231
    .line 232
    move-result-object v14

    .line 233
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 234
    .line 235
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 236
    .line 237
    if-nez v0, :cond_13

    .line 238
    .line 239
    invoke-static {}, LX/1VY;->A00()V

    .line 240
    .line 241
    .line 242
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    throw v0

    .line 247
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    check-cast v0, Ljava/lang/Number;

    .line 252
    .line 253
    if-eqz v0, :cond_f

    .line 254
    .line 255
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 256
    .line 257
    .line 258
    move-result v13

    .line 259
    goto :goto_3

    .line 260
    :cond_f
    const v13, 0x3fe38e39

    .line 261
    .line 262
    .line 263
    goto :goto_4

    .line 264
    :cond_10
    and-int/lit16 v0, v5, 0x6000

    .line 265
    .line 266
    if-nez v0, :cond_3

    .line 267
    .line 268
    invoke-static {v6, v7}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 269
    .line 270
    .line 271
    move-result v0

    .line 272
    or-int/2addr v4, v0

    .line 273
    goto/16 :goto_2

    .line 274
    .line 275
    :cond_11
    and-int/lit16 v0, v5, 0xc00

    .line 276
    .line 277
    if-nez v0, :cond_2

    .line 278
    .line 279
    invoke-static {v6, v8}, LX/004;->A0c(LX/2d4;Ljava/lang/Object;)I

    .line 280
    .line 281
    .line 282
    move-result v0

    .line 283
    or-int/2addr v4, v0

    .line 284
    goto/16 :goto_1

    .line 285
    .line 286
    :cond_12
    move v4, v5

    .line 287
    goto/16 :goto_0

    .line 288
    .line 289
    :cond_13
    invoke-static {v6, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 290
    .line 291
    .line 292
    move-object/from16 v9, v17

    .line 293
    .line 294
    move/from16 v0, v16

    .line 295
    .line 296
    invoke-static {v6, v9, v15, v14, v0}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 297
    .line 298
    .line 299
    sget-object v0, LX/3Jn;->A00:LX/3Jn;

    .line 300
    .line 301
    if-eqz p0, :cond_16

    .line 302
    .line 303
    const v9, -0x52e8881b

    .line 304
    .line 305
    .line 306
    invoke-interface {v6, v9}, LX/2d4;->Agj(I)V

    .line 307
    .line 308
    .line 309
    if-eqz v18, :cond_15

    .line 310
    .line 311
    const/4 v9, 0x1

    .line 312
    invoke-static {v12, v11, v9}, LX/3J3;->A02(LX/3Lr;LX/3C1;Z)LX/3C1;

    .line 313
    .line 314
    .line 315
    move-result-object v9

    .line 316
    invoke-static {v9, v13, v3}, LX/7b5;->A00(LX/3C1;FZ)LX/3C1;

    .line 317
    .line 318
    .line 319
    move-result-object v22

    .line 320
    :goto_5
    sget-object v23, LX/32Y;->A02:LX/2vq;

    .line 321
    .line 322
    const v9, 0x7f1200bc

    .line 323
    .line 324
    .line 325
    invoke-static {v6, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object v24

    .line 329
    move-object/from16 v36, v19

    .line 330
    .line 331
    if-nez p1, :cond_14

    .line 332
    .line 333
    move-object/from16 v36, v10

    .line 334
    .line 335
    :cond_14
    const v9, 0x6000180

    .line 336
    .line 337
    .line 338
    or-int/2addr v2, v9

    .line 339
    const/16 p2, 0x3ef0

    .line 340
    .line 341
    const-wide/16 v28, 0x0

    .line 342
    .line 343
    const/16 v30, 0x1

    .line 344
    .line 345
    move-object/from16 v25, v19

    .line 346
    .line 347
    move/from16 v26, v3

    .line 348
    .line 349
    move-object/from16 v27, v19

    .line 350
    .line 351
    move/from16 v31, v3

    .line 352
    .line 353
    move/from16 v32, v3

    .line 354
    .line 355
    move-object/from16 v33, v19

    .line 356
    .line 357
    move-object/from16 v34, v19

    .line 358
    .line 359
    move-object/from16 v35, v19

    .line 360
    .line 361
    move-object/from16 v37, v6

    .line 362
    .line 363
    move/from16 p0, v2

    .line 364
    .line 365
    move/from16 p1, v3

    .line 366
    .line 367
    invoke-static/range {v21 .. v40}, Lcom/facebook/aura/vds/compose/image/AuraImageKt;->AuraImage-XRP3Ue8(Ljava/lang/String;LX/3C1;LX/2vq;Ljava/lang/String;Lcom/facebook/common/callercontext/ContextChain;ZLX/1Ot;JZZZLX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDN;LX/2d4;III)V

    .line 368
    .line 369
    .line 370
    :goto_6
    invoke-static {v1, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 371
    .line 372
    .line 373
    shr-int/lit8 v2, v4, 0x9

    .line 374
    .line 375
    and-int/lit8 v2, v2, 0x70

    .line 376
    .line 377
    or-int/lit8 v2, v2, 0x6

    .line 378
    .line 379
    invoke-static {v1, v0, v6, v7, v2}, LX/005;->A0u(LX/J7I;Ljava/lang/Object;Ljava/lang/Object;LX/JDQ;I)V

    .line 380
    .line 381
    .line 382
    goto :goto_7

    .line 383
    :cond_15
    sget-object v9, LX/3C1;->A00:LX/3Cb;

    .line 384
    .line 385
    invoke-virtual {v0, v9}, LX/3Jn;->AQU(LX/3C1;)LX/3C1;

    .line 386
    .line 387
    .line 388
    move-result-object v22

    .line 389
    goto :goto_5

    .line 390
    :cond_16
    const v2, -0x52e03b65

    .line 391
    .line 392
    .line 393
    invoke-interface {v6, v2}, LX/2d4;->Agj(I)V

    .line 394
    .line 395
    .line 396
    goto :goto_6

    .line 397
    :cond_17
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 398
    .line 399
    .line 400
    :goto_7
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 401
    .line 402
    .line 403
    move-result-object v1

    .line 404
    if-eqz v1, :cond_18

    .line 405
    .line 406
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$2;

    .line 407
    .line 408
    move-object/from16 v34, v0

    .line 409
    .line 410
    move-object/from16 v35, v21

    .line 411
    .line 412
    move-object/from16 v36, v20

    .line 413
    .line 414
    move-object/from16 v37, p4

    .line 415
    .line 416
    move-object/from16 p0, v8

    .line 417
    .line 418
    move-object/from16 p1, v7

    .line 419
    .line 420
    move/from16 p2, v5

    .line 421
    .line 422
    invoke-direct/range {v34 .. v41}, Lcom/facebook/aura/agentpermission/ApprovalBrowserScreenshotKt$ApprovalBrowserScreenshot$2;-><init>(Ljava/lang/String;Ljava/lang/Float;LX/2bW;LX/3C1;LX/JDQ;II)V

    .line 423
    .line 424
    .line 425
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 426
    .line 427
    :cond_18
    return-void
.end method
