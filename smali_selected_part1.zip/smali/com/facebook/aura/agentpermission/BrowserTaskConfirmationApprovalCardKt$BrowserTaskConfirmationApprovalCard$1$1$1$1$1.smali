.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "LX/367;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, LX/367;

    .line 1
    .line 2
    invoke-static {p1}, LX/35e;->A04(LX/367;)V

    .line 3
    .line 4
    .line 5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/367;)V
    .locals 0

    .line 268435456
    invoke-static {p1}, LX/35e;->A04(LX/367;)V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method
