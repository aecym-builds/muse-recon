.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 34

    .line 0
    move/from16 v2, p2

    .line 1
    .line 2
    and-int/lit8 v1, p2, 0x3

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v12, 0x0

    .line 6
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    move-object/from16 v4, p1

    .line 11
    .line 12
    invoke-static {v0, v4, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    const v0, 0x7f1200ac

    .line 19
    .line 20
    .line 21
    invoke-static {v4, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    sget-object v0, Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;->INSTANCE:Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;

    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    invoke-static {v4, v0}, LX/006;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/button/AuraButtonStyles;)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 29
    .line 30
    .line 31
    move-result-object v9

    .line 32
    sget-object v10, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->SMALL:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 33
    .line 34
    move-object/from16 v2, p0

    .line 35
    .line 36
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 37
    .line 38
    invoke-interface {v4, v0}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, v2, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 43
    .line 44
    invoke-static {v4, v0, v1}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    iget-object v3, v2, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 49
    .line 50
    iget-object v2, v2, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 51
    .line 52
    invoke-interface {v4}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-nez v1, :cond_0

    .line 57
    .line 58
    sget-object v1, LX/2d6;->A00:Ljava/lang/Object;

    .line 59
    .line 60
    if-ne v0, v1, :cond_1

    .line 61
    .line 62
    :cond_0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;

    .line 63
    .line 64
    invoke-direct {v0, v3, v2}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 65
    .line 66
    .line 67
    invoke-interface {v4, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_1
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 71
    .line 72
    const p2, 0x7ffbfcd

    .line 73
    .line 74
    .line 75
    const/high16 v33, 0x30000

    .line 76
    .line 77
    move-object v7, v5

    .line 78
    move-object v8, v5

    .line 79
    move-object v11, v5

    .line 80
    move v13, v12

    .line 81
    move v14, v12

    .line 82
    move v15, v12

    .line 83
    move/from16 v16, v12

    .line 84
    .line 85
    move-object/from16 v17, v5

    .line 86
    .line 87
    move-object/from16 v18, v5

    .line 88
    .line 89
    move-object/from16 v19, v0

    .line 90
    .line 91
    move-object/from16 v20, v5

    .line 92
    .line 93
    move-object/from16 v21, v5

    .line 94
    .line 95
    move-object/from16 v22, v5

    .line 96
    .line 97
    move-object/from16 v23, v5

    .line 98
    .line 99
    move-object/from16 v24, v5

    .line 100
    .line 101
    move-object/from16 v25, v5

    .line 102
    .line 103
    move-object/from16 v26, v5

    .line 104
    .line 105
    move-object/from16 v27, v5

    .line 106
    .line 107
    move/from16 v28, v12

    .line 108
    .line 109
    move/from16 v29, v12

    .line 110
    .line 111
    move/from16 v30, v12

    .line 112
    .line 113
    move/from16 v31, v12

    .line 114
    .line 115
    move-object/from16 v32, v4

    .line 116
    .line 117
    move/from16 p0, v12

    .line 118
    .line 119
    move/from16 p1, v12

    .line 120
    .line 121
    invoke-static/range {v5 .. v36}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :cond_2
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 126
    .line 127
    .line 128
    return-void
.end method
