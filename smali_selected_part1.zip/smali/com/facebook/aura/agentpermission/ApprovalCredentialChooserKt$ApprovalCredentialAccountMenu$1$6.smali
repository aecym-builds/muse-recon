.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $enterLoginLabel:Ljava/lang/String;

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;->$enterLoginLabel:Ljava/lang/String;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/Ddn;
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation

    .line 0
    const v0, -0x2c28df92

    .line 1
    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 6
    .line 7
    .line 8
    move-object/from16 v0, p0

    .line 9
    .line 10
    iget-object v5, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;->$enterLoginLabel:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 19
    .line 20
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    const/4 v8, 0x0

    .line 25
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_1

    .line 30
    .line 31
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    add-int/lit8 v4, v8, 0x1

    .line 36
    .line 37
    if-gez v8, :cond_0

    .line 38
    .line 39
    invoke-static {}, LX/B8B;->A1A()V

    .line 40
    .line 41
    .line 42
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    throw v0

    .line 47
    :cond_0
    check-cast v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 48
    .line 49
    iget-object v9, v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 50
    .line 51
    iget-boolean v14, v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 52
    .line 53
    iget-boolean v3, v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 54
    .line 55
    const/4 v10, 0x0

    .line 56
    const/4 v15, 0x0

    .line 57
    sget-object v19, LX/3C1;->A00:LX/3Cb;

    .line 58
    .line 59
    const/16 v20, 0x1

    .line 60
    .line 61
    new-instance v7, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 62
    .line 63
    move-object v11, v10

    .line 64
    move-object v12, v10

    .line 65
    move-object v13, v10

    .line 66
    move/from16 v16, v15

    .line 67
    .line 68
    move/from16 v18, v15

    .line 69
    .line 70
    move/from16 v21, v20

    .line 71
    .line 72
    move/from16 v17, v3

    .line 73
    .line 74
    invoke-direct/range {v7 .. v21}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move v8, v4

    .line 81
    goto :goto_0

    .line 82
    :cond_1
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v3, :cond_2

    .line 85
    .line 86
    const/4 v6, 0x0

    .line 87
    const-string v5, ""

    .line 88
    .line 89
    const/4 v4, -0x2

    .line 90
    const/4 v10, 0x0

    .line 91
    const/4 v11, 0x1

    .line 92
    sget-object v15, LX/3C1;->A00:LX/3Cb;

    .line 93
    .line 94
    new-instance v3, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 95
    .line 96
    move-object v7, v6

    .line 97
    move-object v8, v6

    .line 98
    move-object v9, v6

    .line 99
    move v12, v10

    .line 100
    move v13, v11

    .line 101
    move v14, v10

    .line 102
    move/from16 v16, v11

    .line 103
    .line 104
    move/from16 v17, v11

    .line 105
    .line 106
    invoke-direct/range {v3 .. v17}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    const/16 v16, -0x1

    .line 113
    .line 114
    new-instance v3, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 115
    .line 116
    move-object/from16 v17, v1

    .line 117
    .line 118
    move-object/from16 v18, v6

    .line 119
    .line 120
    move-object/from16 v19, v6

    .line 121
    .line 122
    move-object/from16 v20, v6

    .line 123
    .line 124
    move-object/from16 v21, v6

    .line 125
    .line 126
    move/from16 v22, v10

    .line 127
    .line 128
    move/from16 v23, v10

    .line 129
    .line 130
    move/from16 v24, v10

    .line 131
    .line 132
    move/from16 v25, v11

    .line 133
    .line 134
    move/from16 v26, v10

    .line 135
    .line 136
    move-object/from16 p0, v15

    .line 137
    .line 138
    move/from16 p1, v11

    .line 139
    .line 140
    move/from16 p2, v11

    .line 141
    .line 142
    move-object v15, v3

    .line 143
    invoke-direct/range {v15 .. v29}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v0, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    :cond_2
    invoke-static {v0}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-static {v0}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-static {v2}, LX/002;->A1I(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;->invoke(LX/2d4;I)LX/Ddn;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
