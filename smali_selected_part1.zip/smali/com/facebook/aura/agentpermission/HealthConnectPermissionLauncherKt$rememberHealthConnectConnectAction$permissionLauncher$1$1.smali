.class public final Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/util/Set<",
        "+",
        "Ljava/lang/String;",
        ">;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $attemptId$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $startedAtMs$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/1EL;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$coroutineScope:LX/1EL;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$startedAtMs$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/util/Set;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->invoke(Ljava/util/Set;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/util/Set;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 1
    .line 2
    invoke-static {v0}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$startedAtMs$delegate:Landroidx/compose/runtime/MutableState;

    .line 7
    .line 8
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    check-cast v4, Ljava/lang/Long;

    .line 13
    .line 14
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$startedAtMs$delegate:Landroidx/compose/runtime/MutableState;

    .line 21
    .line 22
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$coroutineScope:LX/1EL;

    .line 26
    .line 27
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$context:Landroid/content/Context;

    .line 28
    .line 29
    iget-object v5, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 30
    .line 31
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 32
    .line 33
    new-instance v1, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;

    .line 34
    .line 35
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 36
    .line 37
    .line 38
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method
