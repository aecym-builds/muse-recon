.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1"
    f = "ApprovalCredentialChooser.kt"
    l = {
        0x53
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $currentOnDecisionClick$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field public final synthetic $enabled:Z

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

.field public label:I


# direct methods
.method public constructor <init>(ZLcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;LX/16A;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$enabled:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$currentOnDecisionClick$delegate:LX/16A;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-boolean v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$enabled:Z

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$currentOnDecisionClick$delegate:LX/16A;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;-><init>(ZLcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;LX/16A;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 0
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v3, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v4

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$enabled:Z

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 23
    .line 24
    iget-object v2, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->enteredLoginAllows:LX/2Lw;

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->$currentOnDecisionClick$delegate:LX/16A;

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;

    .line 29
    .line 30
    invoke-direct {v0, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;-><init>(LX/16A;)V

    .line 31
    .line 32
    .line 33
    iput v3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;->label:I

    .line 34
    .line 35
    invoke-interface {v2, v0, p0}, LX/2Lw;->collect(LX/39x;LX/2M4;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-ne v0, v4, :cond_0

    .line 40
    .line 41
    return-object v4

    .line 42
    :cond_2
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    throw v0
.end method
