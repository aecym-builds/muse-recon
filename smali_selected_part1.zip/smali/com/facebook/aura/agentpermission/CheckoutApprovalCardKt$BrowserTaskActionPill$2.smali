.class public final Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $contentColor:J

.field public final synthetic $faviconUri:Ljava/lang/String;

.field public final synthetic $label:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;JLjava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$faviconUri:Ljava/lang/String;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$contentColor:J

    .line 3
    .line 4
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$label:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 22

    .line 0
    move/from16 v2, p2

    .line 1
    .line 2
    and-int/lit8 v0, p2, 0x3

    .line 3
    .line 4
    const/4 v14, 0x0

    .line 5
    const/4 v4, 0x2

    .line 6
    invoke-static {v0, v4}, LX/003;->A1H(II)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    move-object/from16 v0, p1

    .line 11
    .line 12
    invoke-static {v1, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    move-object/from16 v5, p0

    .line 19
    .line 20
    iget-object v3, v5, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$faviconUri:Ljava/lang/String;

    .line 21
    .line 22
    iget-wide v1, v5, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$contentColor:J

    .line 23
    .line 24
    invoke-static {v3, v1, v2, v0, v14}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutReviewOrderFavicon-RPmYEkk(Ljava/lang/String;JLX/2d4;I)V

    .line 25
    .line 26
    .line 27
    sget-object v3, LX/3C1;->A00:LX/3Cb;

    .line 28
    .line 29
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 30
    .line 31
    invoke-static {v0, v3, v1}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 32
    .line 33
    .line 34
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 35
    .line 36
    const/16 p1, 0x6

    .line 37
    .line 38
    invoke-static {v0, v2}, LX/07H;->A0O(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 39
    .line 40
    .line 41
    move-result-object v10

    .line 42
    iget-object v6, v5, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$label:Ljava/lang/String;

    .line 43
    .line 44
    iget-wide v8, v5, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$BrowserTaskActionPill$2;->$contentColor:J

    .line 45
    .line 46
    const/16 p2, 0x39f2

    .line 47
    .line 48
    const/4 v7, 0x0

    .line 49
    const/16 v16, 0x1

    .line 50
    .line 51
    const/high16 p0, 0x30000000

    .line 52
    .line 53
    move-object v11, v7

    .line 54
    move-object v12, v7

    .line 55
    move-object v13, v7

    .line 56
    move v15, v14

    .line 57
    move-object/from16 v18, v7

    .line 58
    .line 59
    move-object/from16 v19, v7

    .line 60
    .line 61
    move-object/from16 v20, v7

    .line 62
    .line 63
    move-object/from16 v21, v0

    .line 64
    .line 65
    move/from16 v17, v4

    .line 66
    .line 67
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 68
    .line 69
    .line 70
    invoke-static {v0, v3, v1}, LX/1Vt;->A06(LX/2d4;LX/3C1;F)V

    .line 71
    .line 72
    .line 73
    const v1, 0x7f080093

    .line 74
    .line 75
    .line 76
    invoke-static {v0, v1, v14}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 77
    .line 78
    .line 79
    move-result-object v6

    .line 80
    const/high16 v1, 0x41400000    # 12.0f

    .line 81
    .line 82
    invoke-static {v3, v1}, LX/2sI;->A07(LX/3C1;F)LX/3C1;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-static {v0, v2}, LX/07H;->A01(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 87
    .line 88
    .line 89
    move-result-wide v1

    .line 90
    invoke-static {v1, v2}, LX/2hb;->A00(J)LX/2hb;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    sget v1, LX/2l9;->$stable:I

    .line 95
    .line 96
    or-int/lit16 v1, v1, 0x1b0

    .line 97
    .line 98
    const/16 v11, 0x38

    .line 99
    .line 100
    const/4 v9, 0x0

    .line 101
    move-object v2, v0

    .line 102
    move-object v3, v7

    .line 103
    move-object v8, v7

    .line 104
    move v10, v1

    .line 105
    invoke-static/range {v2 .. v11}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :cond_0
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 110
    .line 111
    .line 112
    return-void
.end method
