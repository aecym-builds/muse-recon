.class public abstract Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DEFAULT_PERMISSION_MODE_OPTIONS:LX/Dwf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Dwf<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation
.end field

.field public static final RESET_MENU_ITEM_ID:I = -0x2

.field public static final REVOKE_MENU_ITEM_ID:I = -0x1


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    sget-object v2, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->ALLOW:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->ASK:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;->DENY:Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 5
    .line 6
    filled-new-array {v2, v1, v0}, [Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0}, LX/Dwp;->A05([Ljava/lang/Object;)LX/Dwf;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->DEFAULT_PERMISSION_MODE_OPTIONS:LX/Dwf;

    .line 15
    .line 16
    return-void
.end method

.method public static final PermissionModeContextMenu(LX/3C1;ZLX/Ddn;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;LX/2d4;II)V
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3C1;",
            "Z",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v9, p2

    .line 1
    .line 2
    move-object/from16 v7, p3

    .line 3
    .line 4
    move-object/from16 v6, p4

    .line 5
    .line 6
    move-object/from16 v1, p0

    .line 7
    .line 8
    const/4 v0, 0x5

    .line 9
    move-object/from16 v5, p5

    .line 10
    .line 11
    move-object/from16 v4, p6

    .line 12
    .line 13
    invoke-static {v5, v0, v4}, LX/003;->A11(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    const v0, -0x644aca74

    .line 17
    .line 18
    .line 19
    move-object/from16 v3, p7

    .line 20
    .line 21
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 22
    .line 23
    .line 24
    and-int/lit8 v17, p9, 0x1

    .line 25
    .line 26
    move/from16 v2, p8

    .line 27
    .line 28
    if-eqz v17, :cond_12

    .line 29
    .line 30
    or-int/lit8 v8, p8, 0x6

    .line 31
    .line 32
    :goto_0
    and-int/lit8 v0, p8, 0x30

    .line 33
    .line 34
    move/from16 v11, p1

    .line 35
    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    invoke-static {v3, v11}, LX/004;->A0j(LX/2d4;Z)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    or-int/2addr v8, v0

    .line 43
    :cond_0
    and-int/lit8 v16, p9, 0x4

    .line 44
    .line 45
    if-eqz v16, :cond_11

    .line 46
    .line 47
    or-int/lit16 v8, v8, 0x180

    .line 48
    .line 49
    :cond_1
    :goto_1
    and-int/lit8 v15, p9, 0x8

    .line 50
    .line 51
    if-eqz v15, :cond_10

    .line 52
    .line 53
    or-int/lit16 v8, v8, 0xc00

    .line 54
    .line 55
    :cond_2
    :goto_2
    and-int/lit8 v12, p9, 0x10

    .line 56
    .line 57
    if-eqz v12, :cond_f

    .line 58
    .line 59
    or-int/lit16 v8, v8, 0x6000

    .line 60
    .line 61
    :cond_3
    :goto_3
    const/high16 v14, 0x30000

    .line 62
    .line 63
    and-int v0, p8, v14

    .line 64
    .line 65
    if-nez v0, :cond_4

    .line 66
    .line 67
    invoke-static {v3, v5}, LX/004;->A0U(LX/2d4;Ljava/lang/Object;)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    or-int/2addr v8, v0

    .line 72
    :cond_4
    const/high16 v0, 0x180000

    .line 73
    .line 74
    and-int v0, p8, v0

    .line 75
    .line 76
    if-nez v0, :cond_5

    .line 77
    .line 78
    invoke-static {v3, v4}, LX/004;->A0V(LX/2d4;Ljava/lang/Object;)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    or-int/2addr v8, v0

    .line 83
    :cond_5
    const v0, 0x92493

    .line 84
    .line 85
    .line 86
    and-int v10, v8, v0

    .line 87
    .line 88
    const v0, 0x92492

    .line 89
    .line 90
    .line 91
    const/4 v13, 0x0

    .line 92
    invoke-static {v10, v0}, LX/003;->A1H(II)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    invoke-static {v0, v3, v8}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    if-eqz v0, :cond_e

    .line 101
    .line 102
    if-eqz v17, :cond_6

    .line 103
    .line 104
    sget-object v1, LX/3C1;->A00:LX/3Cb;

    .line 105
    .line 106
    :cond_6
    const/4 v0, 0x0

    .line 107
    if-eqz v16, :cond_7

    .line 108
    .line 109
    move-object v9, v0

    .line 110
    :cond_7
    if-eqz v15, :cond_8

    .line 111
    .line 112
    move-object v7, v0

    .line 113
    :cond_8
    if-eqz v12, :cond_9

    .line 114
    .line 115
    move-object v6, v0

    .line 116
    :cond_9
    const v0, 0x7f12018d

    .line 117
    .line 118
    .line 119
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p3

    .line 123
    const v0, 0x7f12018a

    .line 124
    .line 125
    .line 126
    invoke-static {v3, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    const/4 v10, 0x0

    .line 131
    const/high16 v0, 0x41c00000    # 24.0f

    .line 132
    .line 133
    invoke-static {v10, v0}, LX/005;->A0G(FF)J

    .line 134
    .line 135
    .line 136
    move-result-wide v17

    .line 137
    invoke-static {v8}, LX/009;->A1L(I)Z

    .line 138
    .line 139
    .line 140
    move-result v12

    .line 141
    invoke-static {v8}, LX/005;->A1L(I)Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    or-int/2addr v12, v0

    .line 146
    invoke-static {v8}, LX/005;->A1N(I)Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    or-int/2addr v12, v0

    .line 151
    const/high16 v10, 0x380000

    .line 152
    .line 153
    and-int/2addr v10, v8

    .line 154
    const/high16 v0, 0x100000

    .line 155
    .line 156
    if-ne v10, v0, :cond_a

    .line 157
    .line 158
    const/4 v13, 0x1

    .line 159
    :cond_a
    or-int/2addr v13, v12

    .line 160
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    if-nez v13, :cond_b

    .line 165
    .line 166
    sget-object v10, LX/2d6;->A00:Ljava/lang/Object;

    .line 167
    .line 168
    if-ne v0, v10, :cond_c

    .line 169
    .line 170
    :cond_b
    new-instance v0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$1$1;

    .line 171
    .line 172
    invoke-direct {v0, v5, v7, v6, v4}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;)V

    .line 173
    .line 174
    .line 175
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    :cond_c
    check-cast v0, LX/JDM;

    .line 179
    .line 180
    new-instance v21, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;

    .line 181
    .line 182
    move-object/from16 v22, v9

    .line 183
    .line 184
    move-object/from16 p0, v6

    .line 185
    .line 186
    move-object/from16 p2, v7

    .line 187
    .line 188
    invoke-direct/range {v21 .. v26}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;-><init>(LX/Ddn;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    and-int/lit8 p6, v8, 0xe

    .line 192
    .line 193
    or-int p6, p6, v14

    .line 194
    .line 195
    shr-int/lit8 v10, v8, 0x9

    .line 196
    .line 197
    and-int/lit16 v10, v10, 0x380

    .line 198
    .line 199
    or-int p6, p6, v10

    .line 200
    .line 201
    shl-int/lit8 v8, v8, 0x6

    .line 202
    .line 203
    and-int/lit16 v8, v8, 0x1c00

    .line 204
    .line 205
    or-int p6, p6, v8

    .line 206
    .line 207
    const/16 v20, 0x0

    .line 208
    .line 209
    const/16 p8, 0x7ed0

    .line 210
    .line 211
    const/16 v16, 0x0

    .line 212
    .line 213
    move-object/from16 v19, v16

    .line 214
    .line 215
    move/from16 v22, v20

    .line 216
    .line 217
    move/from16 p0, v20

    .line 218
    .line 219
    move-object/from16 p1, v16

    .line 220
    .line 221
    move-object/from16 p2, v16

    .line 222
    .line 223
    move-object/from16 p3, v16

    .line 224
    .line 225
    move/from16 p4, v20

    .line 226
    .line 227
    move-object/from16 p5, v3

    .line 228
    .line 229
    move/from16 p7, v20

    .line 230
    .line 231
    move-object v13, v0

    .line 232
    move-object v14, v5

    .line 233
    move v15, v11

    .line 234
    move-object v12, v1

    .line 235
    invoke-static/range {v12 .. v31}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuKt;->AuraContextMenu-Q3lI2Mc(LX/3C1;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuStyle;JLX/3Lr;ZLX/JDN;ZZLX/Ddn;LX/1Ot;LX/JDM;ZLX/2d4;III)V

    .line 236
    .line 237
    .line 238
    :goto_4
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 239
    .line 240
    .line 241
    move-result-object v3

    .line 242
    if-eqz v3, :cond_d

    .line 243
    .line 244
    new-instance v0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$3;

    .line 245
    .line 246
    move-object/from16 p0, v0

    .line 247
    .line 248
    move-object/from16 p1, v1

    .line 249
    .line 250
    move/from16 p2, v11

    .line 251
    .line 252
    move-object/from16 p3, v9

    .line 253
    .line 254
    move-object/from16 p4, v7

    .line 255
    .line 256
    move-object/from16 p5, v6

    .line 257
    .line 258
    move-object/from16 p6, v5

    .line 259
    .line 260
    move-object/from16 p7, v4

    .line 261
    .line 262
    move/from16 p8, v2

    .line 263
    .line 264
    invoke-direct/range {p0 .. p9}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$3;-><init>(LX/3C1;ZLX/Ddn;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDM;II)V

    .line 265
    .line 266
    .line 267
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 268
    .line 269
    :cond_d
    return-void

    .line 270
    :cond_e
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 271
    .line 272
    .line 273
    goto :goto_4

    .line 274
    :cond_f
    and-int/lit16 v0, v2, 0x6000

    .line 275
    .line 276
    if-nez v0, :cond_3

    .line 277
    .line 278
    invoke-static {v3, v6}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 279
    .line 280
    .line 281
    move-result v0

    .line 282
    or-int/2addr v8, v0

    .line 283
    goto/16 :goto_3

    .line 284
    .line 285
    :cond_10
    and-int/lit16 v0, v2, 0xc00

    .line 286
    .line 287
    if-nez v0, :cond_2

    .line 288
    .line 289
    invoke-static {v3, v7}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 290
    .line 291
    .line 292
    move-result v0

    .line 293
    or-int/2addr v8, v0

    .line 294
    goto/16 :goto_2

    .line 295
    .line 296
    :cond_11
    and-int/lit16 v0, v2, 0x180

    .line 297
    .line 298
    if-nez v0, :cond_1

    .line 299
    .line 300
    invoke-static {v3, v9}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 301
    .line 302
    .line 303
    move-result v0

    .line 304
    or-int/2addr v8, v0

    .line 305
    goto/16 :goto_1

    .line 306
    .line 307
    :cond_12
    and-int/lit8 v0, p8, 0x6

    .line 308
    .line 309
    if-nez v0, :cond_13

    .line 310
    .line 311
    invoke-static {v3, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 312
    .line 313
    .line 314
    move-result v8

    .line 315
    or-int v8, v8, p8

    .line 316
    .line 317
    goto/16 :goto_0

    .line 318
    .line 319
    :cond_13
    move v8, v2

    .line 320
    goto/16 :goto_0
.end method

.method public static final synthetic access$getDEFAULT_PERMISSION_MODE_OPTIONS$p()LX/Dwf;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->DEFAULT_PERMISSION_MODE_OPTIONS:LX/Dwf;

    .line 1
    .line 2
    return-object v0
.end method

.method public static final permissionModeShortLabel(Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)Ljava/lang/String;
    .locals 3

    .line 0
    const/4 v2, -0x1

    .line 1
    invoke-static {p0}, LX/004;->A0s(Ljava/lang/Enum;)I

    .line 2
    .line 3
    .line 4
    move-result v1

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eq v1, v2, :cond_2

    .line 7
    .line 8
    if-eq v1, v0, :cond_1

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eq v1, v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    if-ne v1, v0, :cond_3

    .line 15
    .line 16
    const v0, 0x39c96522

    .line 17
    .line 18
    .line 19
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 20
    .line 21
    .line 22
    const v0, 0x7f120187

    .line 23
    .line 24
    .line 25
    :goto_0
    invoke-static {p1, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {p1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_0
    const v0, 0x39c95661

    .line 34
    .line 35
    .line 36
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 37
    .line 38
    .line 39
    const v0, 0x7f120185

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    const v0, 0x39c94783

    .line 44
    .line 45
    .line 46
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 47
    .line 48
    .line 49
    const v0, 0x7f120184

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_2
    const v0, 0x39c96fbd

    .line 54
    .line 55
    .line 56
    invoke-interface {p1, v0}, LX/2d4;->Agj(I)V

    .line 57
    .line 58
    .line 59
    const v0, 0x7f120188

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    const v0, 0x39c94124

    .line 64
    .line 65
    .line 66
    invoke-static {p1, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    throw v0
.end method
