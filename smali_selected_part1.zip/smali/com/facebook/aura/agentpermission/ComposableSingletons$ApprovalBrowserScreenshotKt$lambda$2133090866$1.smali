.class public final Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/33K;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ComposableSingletons$ApprovalBrowserScreenshotKt$lambda$2133090866$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p2, LX/2d4;

    .line 1
    .line 2
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    invoke-static {p1}, LX/005;->A1F(I)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    invoke-static {p0, p2, p1}, LX/008;->A1V(ZLX/2d4;I)V

    .line 11
    .line 12
    .line 13
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    return-object p0
.end method

.method public final invoke(LX/33K;LX/2d4;I)V
    .locals 0

    .line 268435456
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 268435457
    .line 268435458
    .line 268435459
    move-result p0

    .line 268435460
    invoke-static {p0, p2, p3}, LX/008;->A1V(ZLX/2d4;I)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-void
.end method
