.class public final Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/Ddn<",
        "+",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic $modes:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onResetToDefault:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onRevoke:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $resetLabel:Ljava/lang/String;

.field public final synthetic $revokeLabel:Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/Ddn;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/Ddn<",
            "+",
            "Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$modes:LX/Ddn;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$onResetToDefault:Lkotlin/jvm/functions/Function0;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$resetLabel:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$onRevoke:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$revokeLabel:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/Ddn;
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2d4;",
            "I)",
            "LX/Ddn<",
            "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
            ">;"
        }
    .end annotation

    .line 0
    move-object/from16 v0, p1

    .line 1
    .line 2
    const v1, 0x4a529444    # 3450129.0f

    .line 3
    .line 4
    .line 5
    invoke-interface {v0, v1}, LX/2d4;->Agj(I)V

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p0

    .line 9
    .line 10
    iget-object v5, v1, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$modes:LX/Ddn;

    .line 11
    .line 12
    iget-object v6, v1, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$onResetToDefault:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    iget-object v4, v1, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$resetLabel:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v3, v1, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$onRevoke:Lkotlin/jvm/functions/Function0;

    .line 17
    .line 18
    iget-object v2, v1, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->$revokeLabel:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {}, LX/ImR;->A1D()LX/Imw;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const v7, -0x16285

    .line 25
    .line 26
    .line 27
    invoke-interface {v0, v7}, LX/2d4;->Agj(I)V

    .line 28
    .line 29
    .line 30
    if-nez v5, :cond_0

    .line 31
    .line 32
    sget-object v5, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->DEFAULT_PERMISSION_MODE_OPTIONS:LX/Dwf;

    .line 33
    .line 34
    :cond_0
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 35
    .line 36
    .line 37
    move-result-object v7

    .line 38
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-eqz v5, :cond_1

    .line 43
    .line 44
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    check-cast v5, Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;

    .line 49
    .line 50
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 51
    .line 52
    .line 53
    move-result v9

    .line 54
    const/4 v15, 0x0

    .line 55
    invoke-static {v5, v0, v15}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt;->permissionModeShortLabel(Lcom/facebook/aura/agentpermission/ConnectorPermissionMode;LX/2d4;I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v10

    .line 59
    const/4 v11, 0x0

    .line 60
    const/16 v18, 0x1

    .line 61
    .line 62
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 63
    .line 64
    new-instance v8, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 65
    .line 66
    move-object v12, v11

    .line 67
    move-object v13, v11

    .line 68
    move-object v14, v11

    .line 69
    move/from16 v16, v15

    .line 70
    .line 71
    move/from16 v17, v15

    .line 72
    .line 73
    move/from16 v19, v15

    .line 74
    .line 75
    move/from16 p1, v18

    .line 76
    .line 77
    move/from16 p2, v18

    .line 78
    .line 79
    invoke-direct/range {v8 .. v22}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1, v8}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_1
    check-cast v0, LX/J7I;

    .line 87
    .line 88
    const/4 v5, 0x0

    .line 89
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 90
    .line 91
    .line 92
    if-eqz v6, :cond_2

    .line 93
    .line 94
    const/4 v9, 0x0

    .line 95
    const/4 v7, -0x2

    .line 96
    const/16 v16, 0x1

    .line 97
    .line 98
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 99
    .line 100
    new-instance v6, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 101
    .line 102
    move-object v10, v9

    .line 103
    move-object v11, v9

    .line 104
    move-object v12, v9

    .line 105
    move v14, v5

    .line 106
    move v15, v5

    .line 107
    move/from16 v17, v5

    .line 108
    .line 109
    move/from16 v19, v16

    .line 110
    .line 111
    move/from16 p0, v16

    .line 112
    .line 113
    move-object v8, v4

    .line 114
    move v13, v5

    .line 115
    invoke-direct/range {v6 .. v20}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1, v6}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    :cond_2
    if-eqz v3, :cond_3

    .line 122
    .line 123
    const/4 v9, 0x0

    .line 124
    const/4 v7, -0x1

    .line 125
    const/16 v16, 0x1

    .line 126
    .line 127
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 128
    .line 129
    new-instance v3, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 130
    .line 131
    move-object v6, v3

    .line 132
    move-object v8, v2

    .line 133
    move-object v10, v9

    .line 134
    move-object v11, v9

    .line 135
    move-object v12, v9

    .line 136
    move v13, v5

    .line 137
    move v14, v5

    .line 138
    move v15, v5

    .line 139
    move/from16 v17, v16

    .line 140
    .line 141
    move/from16 v19, v16

    .line 142
    .line 143
    move/from16 p0, v16

    .line 144
    .line 145
    invoke-direct/range {v6 .. v20}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;-><init>(ILjava/lang/String;Ljava/lang/String;LX/2l9;LX/JOw;LX/2l9;ZZZZZLX/3C1;II)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v1, v3}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    :cond_3
    invoke-static {v1}, LX/ImR;->A1E(Ljava/util/List;)LX/Imw;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    invoke-static {v1}, LX/Dwp;->A03(Ljava/lang/Iterable;)LX/Dwf;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-static {v0, v5}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 160
    .line 161
    .line 162
    return-object v1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/PermissionModeContextMenuKt$PermissionModeContextMenu$2;->invoke(LX/2d4;I)LX/Ddn;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
