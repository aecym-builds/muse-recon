.class public abstract Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final ENTER_LOGIN_DIVIDER_ID:I = -0x2

.field public static final ENTER_LOGIN_MENU_ITEM_ID:I = -0x1


# direct methods
.method public static final ApprovalCredentialAccountMenu(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v25, p4

    .line 1
    .line 2
    const v1, -0x7de56714

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p5

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v9, p6

    .line 11
    .line 12
    and-int/lit8 v1, p6, 0x6

    .line 13
    .line 14
    move-object/from16 p6, p0

    .line 15
    .line 16
    if-nez v1, :cond_7

    .line 17
    .line 18
    move-object/from16 v1, p6

    .line 19
    .line 20
    invoke-static {v0, v1}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    or-int/2addr v1, v9

    .line 25
    :goto_0
    and-int/lit8 v2, v9, 0x30

    .line 26
    .line 27
    move/from16 v26, p1

    .line 28
    .line 29
    if-nez v2, :cond_0

    .line 30
    .line 31
    move/from16 v2, v26

    .line 32
    .line 33
    invoke-static {v0, v2}, LX/004;->A0j(LX/2d4;Z)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    or-int/2addr v1, v2

    .line 38
    :cond_0
    and-int/lit16 v2, v9, 0x180

    .line 39
    .line 40
    move-object/from16 p5, p2

    .line 41
    .line 42
    if-nez v2, :cond_1

    .line 43
    .line 44
    move-object/from16 v2, p5

    .line 45
    .line 46
    invoke-static {v0, v2}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    or-int/2addr v1, v2

    .line 51
    :cond_1
    and-int/lit16 v2, v9, 0xc00

    .line 52
    .line 53
    move-object/from16 p4, p3

    .line 54
    .line 55
    if-nez v2, :cond_2

    .line 56
    .line 57
    move-object/from16 v2, p4

    .line 58
    .line 59
    invoke-static {v0, v2}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    or-int/2addr v1, v2

    .line 64
    :cond_2
    move/from16 p3, p7

    .line 65
    .line 66
    and-int/lit8 v4, p7, 0x10

    .line 67
    .line 68
    if-eqz v4, :cond_6

    .line 69
    .line 70
    or-int/lit16 v1, v1, 0x6000

    .line 71
    .line 72
    :cond_3
    :goto_1
    and-int/lit16 v3, v1, 0x2493

    .line 73
    .line 74
    const/16 v2, 0x2492

    .line 75
    .line 76
    const/16 v24, 0x0

    .line 77
    .line 78
    invoke-static {v3, v2}, LX/003;->A1H(II)Z

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    invoke-static {v2, v0, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    if-eqz v2, :cond_11

    .line 87
    .line 88
    if-eqz v4, :cond_4

    .line 89
    .line 90
    sget-object v25, LX/3C1;->A00:LX/3Cb;

    .line 91
    .line 92
    :cond_4
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    sget-object v7, LX/2d6;->A00:Ljava/lang/Object;

    .line 97
    .line 98
    move/from16 v2, v24

    .line 99
    .line 100
    invoke-static {v0, v3, v7, v2}, LX/005;->A0j(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 105
    .line 106
    move-object/from16 v2, p6

    .line 107
    .line 108
    iget-object v6, v2, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 109
    .line 110
    if-nez v6, :cond_5

    .line 111
    .line 112
    const v2, 0x65d835c3

    .line 113
    .line 114
    .line 115
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 116
    .line 117
    .line 118
    const v2, 0x7f1201c0

    .line 119
    .line 120
    .line 121
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    :goto_2
    invoke-static {v0}, LX/001;->A0T(Ljava/lang/Object;)LX/J7I;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    const v2, 0x7f1201c7

    .line 130
    .line 131
    .line 132
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v11

    .line 136
    const v2, 0x7f1201c2

    .line 137
    .line 138
    .line 139
    invoke-static {v0, v2}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v23

    .line 143
    sget-object v8, LX/2sI;->A02:LX/2wD;

    .line 144
    .line 145
    move-object/from16 v2, v25

    .line 146
    .line 147
    invoke-interface {v2, v8}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 148
    .line 149
    .line 150
    move-result-object v14

    .line 151
    invoke-static/range {v24 .. v24}, LX/001;->A0g(Z)LX/3BI;

    .line 152
    .line 153
    .line 154
    move-result-object v12

    .line 155
    iget-wide v2, v5, LX/J7I;->A06:J

    .line 156
    .line 157
    invoke-static {v2, v3}, LX/001;->A0A(J)I

    .line 158
    .line 159
    .line 160
    move-result v13

    .line 161
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 162
    .line 163
    .line 164
    move-result-object v10

    .line 165
    invoke-static {v0, v14}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    sget-object v22, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 170
    .line 171
    iget-object v2, v5, LX/J7I;->A0V:LX/3DJ;

    .line 172
    .line 173
    if-nez v2, :cond_8

    .line 174
    .line 175
    invoke-static {}, LX/1VY;->A00()V

    .line 176
    .line 177
    .line 178
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    throw v0

    .line 183
    :cond_5
    const v2, 0x65d832bc

    .line 184
    .line 185
    .line 186
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 187
    .line 188
    .line 189
    goto :goto_2

    .line 190
    :cond_6
    and-int/lit16 v2, v9, 0x6000

    .line 191
    .line 192
    if-nez v2, :cond_3

    .line 193
    .line 194
    move-object/from16 v2, v25

    .line 195
    .line 196
    invoke-static {v0, v2}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 197
    .line 198
    .line 199
    move-result v2

    .line 200
    or-int/2addr v1, v2

    .line 201
    goto/16 :goto_1

    .line 202
    .line 203
    :cond_7
    move v1, v9

    .line 204
    goto/16 :goto_0

    .line 205
    .line 206
    :cond_8
    move-object/from16 v2, v22

    .line 207
    .line 208
    invoke-static {v0, v5, v2}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 209
    .line 210
    .line 211
    sget-object v21, LX/3Cl;->A04:LX/JDN;

    .line 212
    .line 213
    move-object/from16 v2, v21

    .line 214
    .line 215
    invoke-static {v0, v12, v2}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 216
    .line 217
    .line 218
    move-result-object v15

    .line 219
    invoke-static {v0, v10, v15, v13}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 220
    .line 221
    .line 222
    move-result-object v20

    .line 223
    sget-object v10, LX/3Cl;->A02:LX/JDM;

    .line 224
    .line 225
    invoke-static {v0, v3, v10}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 226
    .line 227
    .line 228
    move-result-object v19

    .line 229
    sget-object v18, LX/3Jn;->A00:LX/3Jn;

    .line 230
    .line 231
    sget-object v17, LX/3C1;->A00:LX/3Cb;

    .line 232
    .line 233
    const/high16 v2, 0x42400000    # 48.0f

    .line 234
    .line 235
    invoke-static {v8, v2}, LX/002;->A0a(LX/3C1;F)LX/3C1;

    .line 236
    .line 237
    .line 238
    move-result-object v13

    .line 239
    sget-object v8, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 240
    .line 241
    const/16 p0, 0x6

    .line 242
    .line 243
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 244
    .line 245
    invoke-static {v2, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v2

    .line 249
    check-cast v2, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 250
    .line 251
    iget-wide v2, v2, Lcom/facebook/aura/vds/compose/theme/AuraColors;->secondaryButtonBackground:J

    .line 252
    .line 253
    sget-object v12, Lcom/facebook/aura/vds/compose/theme/AuraShapesKt;->LocalAuraShapes:LX/Ip3;

    .line 254
    .line 255
    invoke-static {v12, v0}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v12

    .line 259
    check-cast v12, Lcom/facebook/aura/vds/compose/theme/AuraShapes;

    .line 260
    .line 261
    iget-object v12, v12, Lcom/facebook/aura/vds/compose/theme/AuraShapes;->small:LX/2bW;

    .line 262
    .line 263
    invoke-static {v13, v12, v2, v3}, LX/2pC;->A03(LX/3C1;LX/2bW;J)LX/3C1;

    .line 264
    .line 265
    .line 266
    move-result-object v14

    .line 267
    invoke-static/range {v24 .. v24}, LX/1Y9;->A01(I)LX/1Y9;

    .line 268
    .line 269
    .line 270
    move-result-object v13

    .line 271
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object v12

    .line 275
    if-ne v12, v7, :cond_9

    .line 276
    .line 277
    new-instance v12, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$1$1;

    .line 278
    .line 279
    invoke-direct {v12, v4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$1$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 280
    .line 281
    .line 282
    invoke-interface {v0, v12}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    :cond_9
    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 286
    .line 287
    const/16 v16, 0x0

    .line 288
    .line 289
    move-object/from16 v3, v16

    .line 290
    .line 291
    move/from16 v2, v26

    .line 292
    .line 293
    invoke-static {v14, v13, v3, v12, v2}, LX/3GU;->A03(LX/3C1;LX/1Y9;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 294
    .line 295
    .line 296
    move-result-object v3

    .line 297
    invoke-static {v0, v11, v6}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    move-result v12

    .line 301
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v2

    .line 305
    if-nez v12, :cond_a

    .line 306
    .line 307
    if-ne v2, v7, :cond_b

    .line 308
    .line 309
    :cond_a
    new-instance v2, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$2$1;

    .line 310
    .line 311
    invoke-direct {v2, v11, v6}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$2$1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    invoke-interface {v0, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    :cond_b
    check-cast v2, LX/JDM;

    .line 318
    .line 319
    const/4 v14, 0x1

    .line 320
    move/from16 v11, v24

    .line 321
    .line 322
    invoke-static {v3, v2, v11}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 323
    .line 324
    .line 325
    move-result-object v3

    .line 326
    sget v2, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 327
    .line 328
    invoke-static {v3, v2}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 329
    .line 330
    .line 331
    move-result-object v2

    .line 332
    sget-object v12, LX/2Id;->A04:LX/2rU;

    .line 333
    .line 334
    sget v3, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 335
    .line 336
    invoke-static {v3}, LX/Dn6;->A00(F)LX/CP5;

    .line 337
    .line 338
    .line 339
    move-result-object v11

    .line 340
    const/16 v3, 0x30

    .line 341
    .line 342
    invoke-static {v11, v0, v12, v3}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 343
    .line 344
    .line 345
    move-result-object v13

    .line 346
    invoke-static {v5}, LX/002;->A0J(LX/J7I;)I

    .line 347
    .line 348
    .line 349
    move-result v12

    .line 350
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 351
    .line 352
    .line 353
    move-result-object v11

    .line 354
    invoke-static {v0, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    move-object/from16 v2, v22

    .line 359
    .line 360
    invoke-static {v0, v5, v2}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 361
    .line 362
    .line 363
    move-object/from16 v2, v21

    .line 364
    .line 365
    invoke-static {v0, v13, v2}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 366
    .line 367
    .line 368
    invoke-static {v0, v11, v15}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 369
    .line 370
    .line 371
    move-object/from16 v2, v20

    .line 372
    .line 373
    invoke-static {v10, v2, v0, v12}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 374
    .line 375
    .line 376
    move-object/from16 v2, v19

    .line 377
    .line 378
    invoke-static {v0, v3, v2}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 379
    .line 380
    .line 381
    sget-object v3, LX/CgK;->A00:LX/CgK;

    .line 382
    .line 383
    invoke-static {v0, v8}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 384
    .line 385
    .line 386
    move-result-object v31

    .line 387
    invoke-static {v0, v8}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 388
    .line 389
    .line 390
    move-result-wide v29

    .line 391
    const/16 v38, 0x2

    .line 392
    .line 393
    move-object/from16 v2, v17

    .line 394
    .line 395
    invoke-static {v3, v2, v14}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 396
    .line 397
    .line 398
    move-result-object v28

    .line 399
    const/16 p1, 0x39f0

    .line 400
    .line 401
    const/16 v2, 0x100

    .line 402
    .line 403
    const/high16 v43, 0x30000000

    .line 404
    .line 405
    move-object/from16 v27, v6

    .line 406
    .line 407
    move-object/from16 v32, v16

    .line 408
    .line 409
    move-object/from16 v33, v16

    .line 410
    .line 411
    move-object/from16 v34, v16

    .line 412
    .line 413
    move/from16 v35, v24

    .line 414
    .line 415
    move/from16 v36, v24

    .line 416
    .line 417
    move/from16 v37, v14

    .line 418
    .line 419
    move-object/from16 v39, v16

    .line 420
    .line 421
    move-object/from16 v40, v16

    .line 422
    .line 423
    move-object/from16 v41, v16

    .line 424
    .line 425
    move-object/from16 v42, v0

    .line 426
    .line 427
    invoke-static/range {v27 .. v45}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 428
    .line 429
    .line 430
    const v6, 0x7f0800e9

    .line 431
    .line 432
    .line 433
    move/from16 v3, v24

    .line 434
    .line 435
    invoke-static {v0, v6, v3}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 436
    .line 437
    .line 438
    move-result-object v28

    .line 439
    sget-object v29, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 440
    .line 441
    invoke-static {v0, v8}, LX/07H;->A08(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 442
    .line 443
    .line 444
    move-result-wide v31

    .line 445
    invoke-static {}, LX/2l9;->A04()I

    .line 446
    .line 447
    .line 448
    move-result v35

    .line 449
    const/16 v36, 0x21

    .line 450
    .line 451
    move-object/from16 v27, v16

    .line 452
    .line 453
    move-object/from16 v30, v16

    .line 454
    .line 455
    move-object/from16 v34, v0

    .line 456
    .line 457
    invoke-static/range {v27 .. v36}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 458
    .line 459
    .line 460
    invoke-static {v5, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 461
    .line 462
    .line 463
    sget-object v8, LX/2Id;->A08:Landroidx/compose/ui/Alignment;

    .line 464
    .line 465
    move-object/from16 v6, v18

    .line 466
    .line 467
    move-object/from16 v3, v17

    .line 468
    .line 469
    invoke-virtual {v6, v8, v3}, LX/3Jn;->A4D(Landroidx/compose/ui/Alignment;LX/3C1;)LX/3C1;

    .line 470
    .line 471
    .line 472
    move-result-object v27

    .line 473
    invoke-static {v4}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 474
    .line 475
    .line 476
    move-result v3

    .line 477
    if-eqz v3, :cond_c

    .line 478
    .line 479
    const/16 v30, 0x1

    .line 480
    .line 481
    if-nez v26, :cond_d

    .line 482
    .line 483
    :cond_c
    const/16 v30, 0x0

    .line 484
    .line 485
    :cond_d
    invoke-static {v1}, LX/008;->A1X(I)Z

    .line 486
    .line 487
    .line 488
    move-result v6

    .line 489
    invoke-static {v1}, LX/005;->A1L(I)Z

    .line 490
    .line 491
    .line 492
    move-result v3

    .line 493
    or-int/2addr v3, v6

    .line 494
    and-int/lit16 v1, v1, 0x380

    .line 495
    .line 496
    invoke-static {v1, v2}, LX/003;->A1I(II)Z

    .line 497
    .line 498
    .line 499
    move-result v1

    .line 500
    or-int/2addr v3, v1

    .line 501
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 502
    .line 503
    .line 504
    move-result-object v2

    .line 505
    if-nez v3, :cond_e

    .line 506
    .line 507
    if-ne v2, v7, :cond_f

    .line 508
    .line 509
    :cond_e
    new-instance v2, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;

    .line 510
    .line 511
    move-object/from16 v6, p6

    .line 512
    .line 513
    move-object/from16 v3, p4

    .line 514
    .line 515
    move-object/from16 v1, p5

    .line 516
    .line 517
    invoke-direct {v2, v6, v3, v4, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;LX/JDM;Landroidx/compose/runtime/MutableState;LX/JDM;)V

    .line 518
    .line 519
    .line 520
    invoke-interface {v0, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 521
    .line 522
    .line 523
    :cond_f
    check-cast v2, LX/JDM;

    .line 524
    .line 525
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 526
    .line 527
    .line 528
    move-result-object v3

    .line 529
    if-ne v3, v7, :cond_10

    .line 530
    .line 531
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$5$1;

    .line 532
    .line 533
    invoke-direct {v3, v4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$5$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 534
    .line 535
    .line 536
    invoke-interface {v0, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 537
    .line 538
    .line 539
    :cond_10
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 540
    .line 541
    new-instance v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;

    .line 542
    .line 543
    move-object/from16 v4, v23

    .line 544
    .line 545
    move-object/from16 v1, p6

    .line 546
    .line 547
    invoke-direct {v6, v1, v4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$6;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;Ljava/lang/String;)V

    .line 548
    .line 549
    .line 550
    const/16 p2, 0x7ef0

    .line 551
    .line 552
    const-wide/16 v32, 0x0

    .line 553
    .line 554
    const/16 p0, 0x180

    .line 555
    .line 556
    move-object/from16 v31, v16

    .line 557
    .line 558
    move-object/from16 v34, v16

    .line 559
    .line 560
    move/from16 v35, v24

    .line 561
    .line 562
    move-object/from16 v36, v6

    .line 563
    .line 564
    move/from16 v37, v24

    .line 565
    .line 566
    move/from16 v38, v24

    .line 567
    .line 568
    move/from16 v42, v24

    .line 569
    .line 570
    move-object/from16 v43, v0

    .line 571
    .line 572
    move/from16 p1, v24

    .line 573
    .line 574
    move-object/from16 v28, v2

    .line 575
    .line 576
    move-object/from16 v29, v3

    .line 577
    .line 578
    invoke-static/range {v27 .. v46}, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuKt;->AuraContextMenu-Q3lI2Mc(LX/3C1;LX/JDM;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuStyle;JLX/3Lr;ZLX/JDN;ZZLX/Ddn;LX/1Ot;LX/JDM;ZLX/2d4;III)V

    .line 579
    .line 580
    .line 581
    invoke-static {v5, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 582
    .line 583
    .line 584
    goto :goto_3

    .line 585
    :cond_11
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 586
    .line 587
    .line 588
    :goto_3
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 589
    .line 590
    .line 591
    move-result-object v1

    .line 592
    if-eqz v1, :cond_12

    .line 593
    .line 594
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$2;

    .line 595
    .line 596
    move-object/from16 v40, v0

    .line 597
    .line 598
    move-object/from16 v41, p6

    .line 599
    .line 600
    move/from16 v42, v26

    .line 601
    .line 602
    move-object/from16 v43, p5

    .line 603
    .line 604
    move-object/from16 p0, p4

    .line 605
    .line 606
    move-object/from16 p1, v25

    .line 607
    .line 608
    move/from16 p2, v9

    .line 609
    .line 610
    invoke-direct/range {v40 .. v47}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$2;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;II)V

    .line 611
    .line 612
    .line 613
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 614
    .line 615
    :cond_12
    return-void
.end method

.method public static final ApprovalCredentialAccountMenu$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0S(Landroidx/compose/runtime/MutableState;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final ApprovalCredentialAccountMenu$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final ApprovalCredentialAccountPicker(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v6, p4

    .line 1
    .line 2
    const v0, -0x38f55963

    .line 3
    .line 4
    .line 5
    move-object/from16 v4, p5

    .line 6
    .line 7
    invoke-interface {v4, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p6

    .line 11
    .line 12
    and-int/lit8 v0, p6, 0x6

    .line 13
    .line 14
    move-object/from16 v7, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v4, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    or-int v5, v5, p6

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 25
    .line 26
    move/from16 p6, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move/from16 v0, p6

    .line 31
    .line 32
    invoke-static {v4, v0}, LX/004;->A0j(LX/2d4;Z)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v5, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v3, 0x180

    .line 38
    .line 39
    move-object/from16 v15, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v4, v15}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    or-int/2addr v5, v0

    .line 48
    :cond_1
    and-int/lit16 v0, v3, 0xc00

    .line 49
    .line 50
    move-object/from16 v8, p3

    .line 51
    .line 52
    if-nez v0, :cond_2

    .line 53
    .line 54
    invoke-static {v4, v8}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    or-int/2addr v5, v0

    .line 59
    :cond_2
    move/from16 p5, p7

    .line 60
    .line 61
    and-int/lit8 v10, p7, 0x10

    .line 62
    .line 63
    if-eqz v10, :cond_5

    .line 64
    .line 65
    or-int/lit16 v5, v5, 0x6000

    .line 66
    .line 67
    :cond_3
    :goto_1
    and-int/lit16 v9, v5, 0x2493

    .line 68
    .line 69
    const/16 v0, 0x2492

    .line 70
    .line 71
    const/4 v2, 0x1

    .line 72
    const/4 v1, 0x0

    .line 73
    invoke-static {v9, v0}, LX/003;->A1H(II)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-static {v0, v4, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_a

    .line 82
    .line 83
    if-eqz v10, :cond_4

    .line 84
    .line 85
    sget-object v6, LX/3C1;->A00:LX/3Cb;

    .line 86
    .line 87
    :cond_4
    invoke-static {v6}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 88
    .line 89
    .line 90
    move-result-object v9

    .line 91
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 92
    .line 93
    invoke-static {v4, v0, v1}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 94
    .line 95
    .line 96
    move-result-object v14

    .line 97
    move-object v0, v4

    .line 98
    check-cast v0, LX/J7I;

    .line 99
    .line 100
    invoke-static {v0}, LX/003;->A0F(LX/J7I;)I

    .line 101
    .line 102
    .line 103
    move-result v13

    .line 104
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 105
    .line 106
    .line 107
    move-result-object v12

    .line 108
    invoke-static {v4, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 109
    .line 110
    .line 111
    move-result-object v11

    .line 112
    sget-object v10, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 113
    .line 114
    iget-object v9, v0, LX/J7I;->A0V:LX/3DJ;

    .line 115
    .line 116
    if-nez v9, :cond_7

    .line 117
    .line 118
    invoke-static {}, LX/1VY;->A00()V

    .line 119
    .line 120
    .line 121
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    throw v0

    .line 126
    :cond_5
    and-int/lit16 v0, v3, 0x6000

    .line 127
    .line 128
    if-nez v0, :cond_3

    .line 129
    .line 130
    invoke-static {v4, v6}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    or-int/2addr v5, v0

    .line 135
    goto :goto_1

    .line 136
    :cond_6
    move v5, v3

    .line 137
    goto :goto_0

    .line 138
    :cond_7
    invoke-static {v4, v0, v10}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 139
    .line 140
    .line 141
    invoke-static {v4, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 142
    .line 143
    .line 144
    iget-object v10, v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 145
    .line 146
    if-nez v10, :cond_9

    .line 147
    .line 148
    const v9, 0x24a76af2

    .line 149
    .line 150
    .line 151
    invoke-interface {v4, v9}, LX/2d4;->Agj(I)V

    .line 152
    .line 153
    .line 154
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 155
    .line 156
    .line 157
    :cond_8
    const v9, 0x2237003e

    .line 158
    .line 159
    .line 160
    invoke-interface {v4, v9}, LX/2d4;->Agj(I)V

    .line 161
    .line 162
    .line 163
    const v9, 0x7f1201c0

    .line 164
    .line 165
    .line 166
    invoke-static {v4, v9}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v16

    .line 170
    :goto_2
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 171
    .line 172
    .line 173
    sget-object v9, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 174
    .line 175
    const/16 p3, 0x6

    .line 176
    .line 177
    invoke-static {v4, v9}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 178
    .line 179
    .line 180
    move-result-object v20

    .line 181
    invoke-static {v4, v9}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 182
    .line 183
    .line 184
    move-result-wide v18

    .line 185
    const/16 v27, 0x2

    .line 186
    .line 187
    const/16 p4, 0x39f2

    .line 188
    .line 189
    const/16 v17, 0x0

    .line 190
    .line 191
    const/high16 p2, 0x30000000

    .line 192
    .line 193
    move-object/from16 v21, v17

    .line 194
    .line 195
    move-object/from16 v22, v17

    .line 196
    .line 197
    move-object/from16 v23, v17

    .line 198
    .line 199
    move/from16 v25, v1

    .line 200
    .line 201
    move-object/from16 v28, v17

    .line 202
    .line 203
    move-object/from16 v29, v17

    .line 204
    .line 205
    move-object/from16 p0, v17

    .line 206
    .line 207
    move-object/from16 p1, v4

    .line 208
    .line 209
    move/from16 v24, v1

    .line 210
    .line 211
    move/from16 v26, v2

    .line 212
    .line 213
    invoke-static/range {v16 .. v34}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 214
    .line 215
    .line 216
    and-int/lit16 v1, v5, 0x1ffe

    .line 217
    .line 218
    const/16 v20, 0x10

    .line 219
    .line 220
    move-object v13, v7

    .line 221
    move/from16 v14, p6

    .line 222
    .line 223
    move-object/from16 v16, v8

    .line 224
    .line 225
    move-object/from16 v18, v4

    .line 226
    .line 227
    move/from16 v19, v1

    .line 228
    .line 229
    invoke-static/range {v13 .. v20}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialAccountMenu(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 230
    .line 231
    .line 232
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 233
    .line 234
    .line 235
    goto :goto_3

    .line 236
    :cond_9
    const v9, 0x24a76af3

    .line 237
    .line 238
    .line 239
    invoke-interface {v4, v9}, LX/2d4;->Agj(I)V

    .line 240
    .line 241
    .line 242
    const v9, 0x7f1201c1

    .line 243
    .line 244
    .line 245
    invoke-static {v4, v10, v9}, LX/18b;->A08(LX/2d4;Ljava/lang/Object;I)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v16

    .line 249
    invoke-static {v0, v1}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 250
    .line 251
    .line 252
    if-eqz v16, :cond_8

    .line 253
    .line 254
    const v9, 0x2236f13a

    .line 255
    .line 256
    .line 257
    invoke-interface {v4, v9}, LX/2d4;->Agj(I)V

    .line 258
    .line 259
    .line 260
    goto :goto_2

    .line 261
    :cond_a
    invoke-interface {v4}, LX/2d4;->AgJ()V

    .line 262
    .line 263
    .line 264
    :goto_3
    invoke-interface {v4}, LX/2d4;->AAg()LX/J7V;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    if-eqz v1, :cond_b

    .line 269
    .line 270
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountPicker$2;

    .line 271
    .line 272
    move-object/from16 v28, v0

    .line 273
    .line 274
    move-object/from16 v29, v7

    .line 275
    .line 276
    move/from16 p0, p6

    .line 277
    .line 278
    move-object/from16 p1, v15

    .line 279
    .line 280
    move-object/from16 p2, v8

    .line 281
    .line 282
    move-object/from16 p3, v6

    .line 283
    .line 284
    move/from16 p4, v3

    .line 285
    .line 286
    invoke-direct/range {v28 .. v35}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountPicker$2;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;II)V

    .line 287
    .line 288
    .line 289
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 290
    .line 291
    :cond_b
    return-void
.end method

.method public static final ApprovalCredentialChooser(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            "Z",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v13, p5

    .line 1
    .line 2
    const v0, -0x10400b77

    .line 3
    .line 4
    .line 5
    move-object/from16 v2, p6

    .line 6
    .line 7
    invoke-interface {v2, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v14, p7

    .line 11
    .line 12
    and-int/lit8 v0, p7, 0x6

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    move-object v8, p0

    .line 16
    if-nez v0, :cond_c

    .line 17
    .line 18
    invoke-static {v2, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    or-int v4, v4, p7

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p7, 0x30

    .line 25
    .line 26
    move/from16 v9, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-static {v2, v9}, LX/004;->A0j(LX/2d4;Z)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    or-int/2addr v4, v0

    .line 35
    :cond_0
    and-int/lit16 v0, v14, 0x180

    .line 36
    .line 37
    move-object/from16 v10, p2

    .line 38
    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    invoke-static {v2, v10}, LX/004;->A0R(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v4, v0

    .line 46
    :cond_1
    and-int/lit16 v0, v14, 0xc00

    .line 47
    .line 48
    move-object/from16 v11, p3

    .line 49
    .line 50
    if-nez v0, :cond_2

    .line 51
    .line 52
    invoke-static {v2, v11}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    or-int/2addr v4, v0

    .line 57
    :cond_2
    and-int/lit16 v0, v14, 0x6000

    .line 58
    .line 59
    move-object/from16 v12, p4

    .line 60
    .line 61
    if-nez v0, :cond_3

    .line 62
    .line 63
    invoke-static {v2, v12}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    or-int/2addr v4, v0

    .line 68
    :cond_3
    move/from16 p0, p8

    .line 69
    .line 70
    and-int/lit8 v6, p8, 0x20

    .line 71
    .line 72
    const/high16 v0, 0x30000

    .line 73
    .line 74
    if-nez v6, :cond_4

    .line 75
    .line 76
    and-int v0, v0, p7

    .line 77
    .line 78
    if-nez v0, :cond_5

    .line 79
    .line 80
    invoke-static {v2, v13}, LX/004;->A0e(LX/2d4;Ljava/lang/Object;)I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    :cond_4
    or-int/2addr v4, v0

    .line 85
    :cond_5
    const v5, 0x12493

    .line 86
    .line 87
    .line 88
    and-int/2addr v5, v4

    .line 89
    const v0, 0x12492

    .line 90
    .line 91
    .line 92
    const/4 v3, 0x0

    .line 93
    invoke-static {v5, v0}, LX/003;->A1H(II)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    invoke-static {v0, v2, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_b

    .line 102
    .line 103
    if-eqz v6, :cond_6

    .line 104
    .line 105
    sget-object v13, LX/3C1;->A00:LX/3Cb;

    .line 106
    .line 107
    :cond_6
    iget-object v0, v8, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 108
    .line 109
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 110
    .line 111
    .line 112
    move-result v7

    .line 113
    if-eq v7, v3, :cond_a

    .line 114
    .line 115
    const v6, 0xe000

    .line 116
    .line 117
    .line 118
    const/4 v5, 0x3

    .line 119
    const/4 v0, 0x2

    .line 120
    if-eq v7, v1, :cond_8

    .line 121
    .line 122
    if-eq v7, v0, :cond_9

    .line 123
    .line 124
    if-ne v7, v5, :cond_d

    .line 125
    .line 126
    const v0, -0x6a7244

    .line 127
    .line 128
    .line 129
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 130
    .line 131
    .line 132
    and-int/lit16 v1, v4, 0x3fe

    .line 133
    .line 134
    shr-int/2addr v4, v5

    .line 135
    and-int/lit16 v0, v4, 0x1c00

    .line 136
    .line 137
    or-int/2addr v1, v0

    .line 138
    and-int/2addr v4, v6

    .line 139
    or-int/2addr v1, v4

    .line 140
    move-object/from16 p1, v8

    .line 141
    .line 142
    move/from16 p2, v9

    .line 143
    .line 144
    move-object/from16 p3, v10

    .line 145
    .line 146
    move-object/from16 p5, v13

    .line 147
    .line 148
    move/from16 p7, v1

    .line 149
    .line 150
    move/from16 p8, v3

    .line 151
    .line 152
    invoke-static/range {p1 .. p8}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialAccountPicker(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 153
    .line 154
    .line 155
    :goto_1
    invoke-static {v2}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    :goto_2
    invoke-interface {v2}, LX/2d4;->AAg()LX/J7V;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    if-eqz v0, :cond_7

    .line 163
    .line 164
    new-instance v7, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;

    .line 165
    .line 166
    invoke-direct/range {v7 .. v15}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialChooser$1;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;II)V

    .line 167
    .line 168
    .line 169
    iput-object v7, v0, LX/J7V;->A06:LX/JDN;

    .line 170
    .line 171
    :cond_7
    return-void

    .line 172
    :cond_8
    const v0, -0x6ac738

    .line 173
    .line 174
    .line 175
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 176
    .line 177
    .line 178
    const v0, 0x7f1201c3

    .line 179
    .line 180
    .line 181
    invoke-static {v2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    const v0, 0x7f1202bd

    .line 186
    .line 187
    .line 188
    goto :goto_3

    .line 189
    :cond_9
    const v0, -0x6a9c99

    .line 190
    .line 191
    .line 192
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 193
    .line 194
    .line 195
    const v0, 0x7f1201c5

    .line 196
    .line 197
    .line 198
    invoke-static {v2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    const v0, 0x7f1201c6

    .line 203
    .line 204
    .line 205
    :goto_3
    invoke-static {v2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p2

    .line 209
    shl-int/lit8 v0, v4, 0x3

    .line 210
    .line 211
    and-int/lit16 v1, v0, 0x380

    .line 212
    .line 213
    and-int/lit16 v0, v4, 0x1c00

    .line 214
    .line 215
    or-int/2addr v1, v0

    .line 216
    shr-int/2addr v4, v5

    .line 217
    and-int/2addr v4, v6

    .line 218
    or-int/2addr v1, v4

    .line 219
    move/from16 p3, v9

    .line 220
    .line 221
    move-object/from16 p4, v11

    .line 222
    .line 223
    move-object/from16 p5, v13

    .line 224
    .line 225
    move/from16 p7, v1

    .line 226
    .line 227
    move/from16 p8, v3

    .line 228
    .line 229
    invoke-static/range {p1 .. p8}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialReload(Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 230
    .line 231
    .line 232
    goto :goto_1

    .line 233
    :cond_a
    const v0, -0x6ae0c6

    .line 234
    .line 235
    .line 236
    invoke-interface {v2, v0}, LX/2d4;->Agj(I)V

    .line 237
    .line 238
    .line 239
    const v0, 0x7f1201c4

    .line 240
    .line 241
    .line 242
    invoke-static {v2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v1

    .line 246
    shr-int/lit8 v0, v4, 0xc

    .line 247
    .line 248
    and-int/lit8 v0, v0, 0x70

    .line 249
    .line 250
    invoke-static {v1, v13, v2, v0, v3}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialStatus(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 251
    .line 252
    .line 253
    goto :goto_1

    .line 254
    :cond_b
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 255
    .line 256
    .line 257
    goto :goto_2

    .line 258
    :cond_c
    move v4, v14

    .line 259
    goto/16 :goto_0

    .line 260
    .line 261
    :cond_d
    const v0, -0x6ae69f

    .line 262
    .line 263
    .line 264
    invoke-static {v2, v0}, LX/005;->A0q(LX/2d4;I)Lkotlin/NoWhenBranchMatchedException;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    throw v0
.end method

.method public static final ApprovalCredentialDecisions-eHTjO5g(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;ZLX/JDN;FLX/2or;LX/3C1;LX/2d4;II)V
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            "Lcom/facebook/aura/analytics/hatch/HatchScreen;",
            "Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;",
            "Z",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;F",
            "LX/2or;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v19, p7

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    move-object/from16 v10, p0

    .line 4
    .line 5
    move-object/from16 v9, p1

    .line 6
    .line 7
    move-object/from16 v0, p2

    .line 8
    .line 9
    invoke-static {v10, v9, v0}, LX/005;->A0z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    const/4 v13, 0x4

    .line 13
    move-object/from16 v14, p4

    .line 14
    .line 15
    move-object/from16 p0, p6

    .line 16
    .line 17
    move-object/from16 v0, p0

    .line 18
    .line 19
    invoke-static {v14, v13, v0}, LX/003;->A11(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    const v0, 0x3f29922d

    .line 23
    .line 24
    .line 25
    move-object/from16 v11, p8

    .line 26
    .line 27
    invoke-interface {v11, v0}, LX/2d4;->Agl(I)V

    .line 28
    .line 29
    .line 30
    move/from16 v8, p9

    .line 31
    .line 32
    and-int/lit8 v0, p9, 0x6

    .line 33
    .line 34
    if-nez v0, :cond_b

    .line 35
    .line 36
    invoke-static {v10, v11, v8}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-static {v0}, LX/003;->A06(I)I

    .line 41
    .line 42
    .line 43
    move-result v12

    .line 44
    or-int v12, v12, p9

    .line 45
    .line 46
    :goto_0
    and-int/lit8 v0, p9, 0x30

    .line 47
    .line 48
    if-nez v0, :cond_0

    .line 49
    .line 50
    invoke-static {v11, v9}, LX/005;->A0A(LX/2d4;Ljava/lang/Enum;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    or-int/2addr v12, v0

    .line 55
    :cond_0
    and-int/lit16 v0, v8, 0x180

    .line 56
    .line 57
    if-nez v0, :cond_1

    .line 58
    .line 59
    move-object/from16 v0, p2

    .line 60
    .line 61
    invoke-static {v11, v0}, LX/005;->A0B(LX/2d4;Ljava/lang/Enum;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    or-int/2addr v12, v0

    .line 66
    :cond_1
    and-int/lit16 v0, v8, 0xc00

    .line 67
    .line 68
    move/from16 v21, p3

    .line 69
    .line 70
    if-nez v0, :cond_2

    .line 71
    .line 72
    move/from16 v0, v21

    .line 73
    .line 74
    invoke-static {v11, v0}, LX/004;->A0l(LX/2d4;Z)I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    or-int/2addr v12, v0

    .line 79
    :cond_2
    and-int/lit16 v0, v8, 0x6000

    .line 80
    .line 81
    if-nez v0, :cond_3

    .line 82
    .line 83
    invoke-static {v11, v14}, LX/004;->A0T(LX/2d4;Ljava/lang/Object;)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    or-int/2addr v12, v0

    .line 88
    :cond_3
    const/high16 v0, 0x30000

    .line 89
    .line 90
    and-int v0, v0, p9

    .line 91
    .line 92
    move/from16 p1, p5

    .line 93
    .line 94
    if-nez v0, :cond_4

    .line 95
    .line 96
    move/from16 v0, p1

    .line 97
    .line 98
    invoke-static {v11, v0}, LX/004;->A0D(LX/2d4;F)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    or-int/2addr v12, v0

    .line 103
    :cond_4
    const/high16 v0, 0x180000

    .line 104
    .line 105
    and-int v0, v0, p9

    .line 106
    .line 107
    if-nez v0, :cond_5

    .line 108
    .line 109
    move-object/from16 v0, p0

    .line 110
    .line 111
    invoke-static {v11, v0}, LX/004;->A0f(LX/2d4;Ljava/lang/Object;)I

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    or-int/2addr v12, v0

    .line 116
    :cond_5
    move/from16 v30, p10

    .line 117
    .line 118
    move/from16 v0, v30

    .line 119
    .line 120
    and-int/lit16 v2, v0, 0x80

    .line 121
    .line 122
    const/high16 v0, 0xc00000

    .line 123
    .line 124
    if-nez v2, :cond_6

    .line 125
    .line 126
    and-int v0, p9, v0

    .line 127
    .line 128
    if-nez v0, :cond_7

    .line 129
    .line 130
    move-object/from16 v0, v19

    .line 131
    .line 132
    invoke-static {v11, v0}, LX/004;->A0g(LX/2d4;Ljava/lang/Object;)I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    :cond_6
    or-int/2addr v12, v0

    .line 137
    :cond_7
    invoke-static {v12}, LX/009;->A1J(I)Z

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    invoke-static {v0, v11, v12}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-eqz v0, :cond_d

    .line 146
    .line 147
    if-eqz v2, :cond_8

    .line 148
    .line 149
    sget-object v19, LX/3C1;->A00:LX/3Cb;

    .line 150
    .line 151
    :cond_8
    iget-object v2, v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 152
    .line 153
    const-string v0, "approval-credential-"

    .line 154
    .line 155
    invoke-static {v0, v2}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v5

    .line 159
    sget-object v0, Lcom/facebook/aura/session/LocalUserSessionKt;->LocalUserSession:LX/Ip3;

    .line 160
    .line 161
    move-object v7, v11

    .line 162
    check-cast v7, LX/J7I;

    .line 163
    .line 164
    invoke-static {v0, v7}, LX/004;->A16(LX/Iow;LX/J7I;)LX/AHE;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    new-instance v4, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;

    .line 169
    .line 170
    move-object/from16 v0, p2

    .line 171
    .line 172
    invoke-direct {v4, v2, v10, v0}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel$Factory;-><init>(LX/AHE;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v11}, LX/16i;->A00(LX/2d4;)LX/13Z;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    if-eqz v3, :cond_c

    .line 180
    .line 181
    invoke-static {v3}, LX/009;->A0W(Ljava/lang/Object;)LX/13i;

    .line 182
    .line 183
    .line 184
    move-result-object v2

    .line 185
    const-class v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 186
    .line 187
    invoke-static {v4, v3, v2, v0, v5}, LX/15E;->A00(LX/15L;LX/13Z;LX/13i;Ljava/lang/Class;Ljava/lang/String;)LX/1EJ;

    .line 188
    .line 189
    .line 190
    move-result-object v6

    .line 191
    check-cast v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 192
    .line 193
    iget-object v0, v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->uiState:LX/2J3;

    .line 194
    .line 195
    const/16 v18, 0x0

    .line 196
    .line 197
    invoke-static {v11, v0, v1}, LX/1x0;->A02(LX/2d4;LX/2J3;I)LX/16A;

    .line 198
    .line 199
    .line 200
    move-result-object v5

    .line 201
    sget-object v0, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 202
    .line 203
    invoke-static {v0, v7}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 204
    .line 205
    .line 206
    move-result-object v17

    .line 207
    invoke-static {v11, v14}, LX/2TI;->A00(LX/2d4;Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 208
    .line 209
    .line 210
    move-result-object v15

    .line 211
    invoke-static/range {v21 .. v21}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 212
    .line 213
    .line 214
    move-result-object v4

    .line 215
    invoke-static {v12}, LX/005;->A1L(I)Z

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    invoke-static {v11, v6, v15, v0}, LX/004;->A1V(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v3

    .line 227
    if-nez v0, :cond_9

    .line 228
    .line 229
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 230
    .line 231
    if-ne v3, v0, :cond_a

    .line 232
    .line 233
    :cond_9
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;

    .line 234
    .line 235
    move-object/from16 v2, v18

    .line 236
    .line 237
    move/from16 v0, v21

    .line 238
    .line 239
    invoke-direct {v3, v0, v6, v15, v2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1;-><init>(ZLcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;LX/16A;LX/2M4;)V

    .line 240
    .line 241
    .line 242
    invoke-interface {v11, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 243
    .line 244
    .line 245
    :cond_a
    check-cast v3, LX/JDN;

    .line 246
    .line 247
    shr-int/lit8 v0, v12, 0x6

    .line 248
    .line 249
    and-int/lit8 v27, v0, 0x70

    .line 250
    .line 251
    invoke-static {v11, v6, v4, v3}, LX/CdB;->A04(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;LX/JDN;)V

    .line 252
    .line 253
    .line 254
    invoke-static/range {v19 .. v19}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 255
    .line 256
    .line 257
    move-result-object v0

    .line 258
    sget v2, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->SingleApprovalContentSpacing:F

    .line 259
    .line 260
    invoke-static {v11, v2, v1}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 261
    .line 262
    .line 263
    move-result-object v16

    .line 264
    iget-wide v1, v7, LX/J7I;->A06:J

    .line 265
    .line 266
    const/16 v4, 0x20

    .line 267
    .line 268
    invoke-static {v1, v2}, LX/001;->A0A(J)I

    .line 269
    .line 270
    .line 271
    move-result v15

    .line 272
    invoke-static {v7}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 273
    .line 274
    .line 275
    move-result-object v3

    .line 276
    invoke-static {v11, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 281
    .line 282
    iget-object v0, v7, LX/J7I;->A0V:LX/3DJ;

    .line 283
    .line 284
    if-nez v0, :cond_e

    .line 285
    .line 286
    invoke-static {}, LX/1VY;->A00()V

    .line 287
    .line 288
    .line 289
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 290
    .line 291
    .line 292
    move-result-object v0

    .line 293
    throw v0

    .line 294
    :cond_b
    move v12, v8

    .line 295
    goto/16 :goto_0

    .line 296
    .line 297
    :cond_c
    invoke-static {}, LX/002;->A0q()Ljava/lang/IllegalStateException;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    throw v0

    .line 302
    :cond_d
    invoke-interface {v11}, LX/2d4;->AgJ()V

    .line 303
    .line 304
    .line 305
    goto/16 :goto_4

    .line 306
    .line 307
    :cond_e
    invoke-static {v11, v7, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 308
    .line 309
    .line 310
    move-object/from16 v0, v16

    .line 311
    .line 312
    invoke-static {v11, v0, v3, v2, v15}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 313
    .line 314
    .line 315
    invoke-interface {v5}, LX/16A;->getValue()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v20

    .line 319
    check-cast v20, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 320
    .line 321
    and-int/lit8 v3, v12, 0x70

    .line 322
    .line 323
    invoke-static {v3, v4}, LX/003;->A1I(II)Z

    .line 324
    .line 325
    .line 326
    move-result v1

    .line 327
    and-int/lit8 v2, v12, 0xe

    .line 328
    .line 329
    if-eq v2, v13, :cond_f

    .line 330
    .line 331
    and-int/lit8 v0, v12, 0x8

    .line 332
    .line 333
    if-eqz v0, :cond_1f

    .line 334
    .line 335
    invoke-interface {v11, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    move-result v0

    .line 339
    if-eqz v0, :cond_1f

    .line 340
    .line 341
    :cond_f
    const/4 v0, 0x1

    .line 342
    :goto_1
    invoke-static {v11, v6, v1, v0}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 343
    .line 344
    .line 345
    move-result v0

    .line 346
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    if-nez v0, :cond_10

    .line 351
    .line 352
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 353
    .line 354
    if-ne v1, v0, :cond_11

    .line 355
    .line 356
    :cond_10
    new-instance v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;

    .line 357
    .line 358
    invoke-direct {v1, v9, v10, v6}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 359
    .line 360
    .line 361
    invoke-interface {v11, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 362
    .line 363
    .line 364
    :cond_11
    check-cast v1, LX/JDM;

    .line 365
    .line 366
    invoke-static {v3, v4}, LX/003;->A1I(II)Z

    .line 367
    .line 368
    .line 369
    move-result v15

    .line 370
    if-eq v2, v13, :cond_12

    .line 371
    .line 372
    and-int/lit8 v0, v12, 0x8

    .line 373
    .line 374
    if-eqz v0, :cond_1e

    .line 375
    .line 376
    invoke-interface {v11, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 377
    .line 378
    .line 379
    move-result v0

    .line 380
    if-eqz v0, :cond_1e

    .line 381
    .line 382
    :cond_12
    const/4 v0, 0x1

    .line 383
    :goto_2
    invoke-static {v11, v6, v0, v15}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 384
    .line 385
    .line 386
    move-result v15

    .line 387
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    if-nez v15, :cond_13

    .line 392
    .line 393
    sget-object v15, LX/2d6;->A00:Ljava/lang/Object;

    .line 394
    .line 395
    if-ne v0, v15, :cond_14

    .line 396
    .line 397
    :cond_13
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$2$1;

    .line 398
    .line 399
    invoke-direct {v0, v9, v10, v6}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$2$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V

    .line 400
    .line 401
    .line 402
    invoke-interface {v11, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 403
    .line 404
    .line 405
    :cond_14
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 406
    .line 407
    invoke-static {v3, v4}, LX/003;->A1I(II)Z

    .line 408
    .line 409
    .line 410
    move-result v3

    .line 411
    if-eq v2, v13, :cond_15

    .line 412
    .line 413
    and-int/lit8 v2, v12, 0x8

    .line 414
    .line 415
    if-eqz v2, :cond_1d

    .line 416
    .line 417
    invoke-interface {v11, v10}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    if-eqz v2, :cond_1d

    .line 422
    .line 423
    :cond_15
    const/4 v6, 0x1

    .line 424
    :goto_3
    move-object/from16 v2, v17

    .line 425
    .line 426
    invoke-static {v11, v2, v3, v6}, LX/002;->A1W(LX/2d4;Ljava/lang/Object;ZZ)Z

    .line 427
    .line 428
    .line 429
    move-result v2

    .line 430
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 431
    .line 432
    .line 433
    move-result-object v3

    .line 434
    if-nez v2, :cond_16

    .line 435
    .line 436
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 437
    .line 438
    if-ne v3, v2, :cond_17

    .line 439
    .line 440
    :cond_16
    new-instance v3, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$3$1;

    .line 441
    .line 442
    move-object/from16 v2, v17

    .line 443
    .line 444
    invoke-direct {v3, v9, v10, v2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$3$1;-><init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V

    .line 445
    .line 446
    .line 447
    invoke-interface {v11, v3}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 448
    .line 449
    .line 450
    :cond_17
    check-cast v3, LX/JDM;

    .line 451
    .line 452
    move-object/from16 v22, v1

    .line 453
    .line 454
    move-object/from16 v23, v0

    .line 455
    .line 456
    move-object/from16 v24, v3

    .line 457
    .line 458
    move-object/from16 v25, v18

    .line 459
    .line 460
    move-object/from16 v26, v11

    .line 461
    .line 462
    move/from16 v28, v4

    .line 463
    .line 464
    invoke-static/range {v20 .. v28}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialChooser(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 465
    .line 466
    .line 467
    iget-object v3, v10, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->decisionOptions:Ljava/util/List;

    .line 468
    .line 469
    const v4, 0xe000

    .line 470
    .line 471
    .line 472
    and-int v1, v12, v4

    .line 473
    .line 474
    const/16 v0, 0x4000

    .line 475
    .line 476
    invoke-static {v1, v0}, LX/003;->A1I(II)Z

    .line 477
    .line 478
    .line 479
    move-result v0

    .line 480
    invoke-static {v11, v5, v0}, LX/001;->A1U(LX/2d4;Ljava/lang/Object;Z)Z

    .line 481
    .line 482
    .line 483
    move-result v0

    .line 484
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 485
    .line 486
    .line 487
    move-result-object v2

    .line 488
    if-nez v0, :cond_18

    .line 489
    .line 490
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 491
    .line 492
    if-ne v2, v0, :cond_19

    .line 493
    .line 494
    :cond_18
    new-instance v2, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$4$1;

    .line 495
    .line 496
    invoke-direct {v2, v14, v5}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$4$1;-><init>(LX/JDN;LX/16A;)V

    .line 497
    .line 498
    .line 499
    invoke-interface {v11, v2}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 500
    .line 501
    .line 502
    :cond_19
    check-cast v2, LX/JDM;

    .line 503
    .line 504
    invoke-interface {v11, v5}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 505
    .line 506
    .line 507
    move-result v0

    .line 508
    invoke-interface {v11}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object v1

    .line 512
    if-nez v0, :cond_1a

    .line 513
    .line 514
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 515
    .line 516
    if-ne v1, v0, :cond_1b

    .line 517
    .line 518
    :cond_1a
    new-instance v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$5$1;

    .line 519
    .line 520
    invoke-direct {v1, v5}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$5$1;-><init>(LX/16A;)V

    .line 521
    .line 522
    .line 523
    invoke-interface {v11, v1}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 524
    .line 525
    .line 526
    :cond_1b
    check-cast v1, LX/JDM;

    .line 527
    .line 528
    shr-int/lit8 v0, v12, 0x3

    .line 529
    .line 530
    and-int/2addr v4, v0

    .line 531
    or-int v4, v4, v27

    .line 532
    .line 533
    invoke-static {v0, v4}, LX/002;->A06(II)I

    .line 534
    .line 535
    .line 536
    move-result v28

    .line 537
    const/16 v29, 0x8

    .line 538
    .line 539
    move-object/from16 v20, v3

    .line 540
    .line 541
    move-object/from16 v22, v2

    .line 542
    .line 543
    move-object/from16 v23, v18

    .line 544
    .line 545
    move/from16 v24, p1

    .line 546
    .line 547
    move-object/from16 v25, p0

    .line 548
    .line 549
    move-object/from16 v26, v1

    .line 550
    .line 551
    move-object/from16 v27, v11

    .line 552
    .line 553
    invoke-static/range {v20 .. v29}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionDecisionButtons-iHT-50w(Ljava/util/List;ZLX/JDM;LX/3C1;FLX/2or;LX/JDM;LX/2d4;II)V

    .line 554
    .line 555
    .line 556
    const/4 v0, 0x1

    .line 557
    invoke-static {v7, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 558
    .line 559
    .line 560
    :goto_4
    invoke-interface {v11}, LX/2d4;->AAg()LX/J7V;

    .line 561
    .line 562
    .line 563
    move-result-object v0

    .line 564
    if-eqz v0, :cond_1c

    .line 565
    .line 566
    new-instance v6, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$3;

    .line 567
    .line 568
    move-object v11, v14

    .line 569
    move/from16 v12, p1

    .line 570
    .line 571
    move-object/from16 v13, p0

    .line 572
    .line 573
    move-object/from16 v14, v19

    .line 574
    .line 575
    move v15, v8

    .line 576
    move/from16 v16, v30

    .line 577
    .line 578
    move-object v7, v10

    .line 579
    move-object v8, v9

    .line 580
    move-object/from16 v9, p2

    .line 581
    .line 582
    move/from16 v10, v21

    .line 583
    .line 584
    invoke-direct/range {v6 .. v16}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$3;-><init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/ApprovalCredentialSelectionMarker;ZLX/JDN;FLX/2or;LX/3C1;II)V

    .line 585
    .line 586
    .line 587
    iput-object v6, v0, LX/J7V;->A06:LX/JDN;

    .line 588
    .line 589
    :cond_1c
    return-void

    .line 590
    :cond_1d
    const/4 v6, 0x0

    .line 591
    goto/16 :goto_3

    .line 592
    .line 593
    :cond_1e
    const/4 v0, 0x0

    .line 594
    goto/16 :goto_2

    .line 595
    .line 596
    :cond_1f
    const/4 v0, 0x0

    .line 597
    goto/16 :goto_1
.end method

.method public static final ApprovalCredentialDecisions_eHTjO5g$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            ">;)",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final ApprovalCredentialDecisions_eHTjO5g$lambda$1(LX/16A;)LX/JDN;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;)",
            "LX/JDN<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final ApprovalCredentialReload(Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 41
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v7, p4

    .line 1
    .line 2
    const v0, -0x4ae724fd

    .line 3
    .line 4
    .line 5
    move-object/from16 v6, p5

    .line 6
    .line 7
    invoke-interface {v6, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v5, p6

    .line 11
    .line 12
    and-int/lit8 v0, p6, 0x6

    .line 13
    .line 14
    move-object/from16 v8, p0

    .line 15
    .line 16
    if-nez v0, :cond_6

    .line 17
    .line 18
    invoke-static {v6, v8}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v10

    .line 22
    or-int v10, v10, p6

    .line 23
    .line 24
    :goto_0
    and-int/lit8 v0, p6, 0x30

    .line 25
    .line 26
    move-object/from16 v17, p1

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move-object/from16 v0, v17

    .line 31
    .line 32
    invoke-static {v6, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    or-int/2addr v10, v0

    .line 37
    :cond_0
    and-int/lit16 v0, v5, 0x180

    .line 38
    .line 39
    move/from16 v25, p2

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    move/from16 v0, v25

    .line 44
    .line 45
    invoke-static {v6, v0}, LX/004;->A0k(LX/2d4;Z)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    or-int/2addr v10, v0

    .line 50
    :cond_1
    and-int/lit16 v0, v5, 0xc00

    .line 51
    .line 52
    move-object/from16 v15, p3

    .line 53
    .line 54
    if-nez v0, :cond_2

    .line 55
    .line 56
    invoke-static {v6, v15}, LX/004;->A0S(LX/2d4;Ljava/lang/Object;)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    or-int/2addr v10, v0

    .line 61
    :cond_2
    and-int/lit8 v2, p7, 0x10

    .line 62
    .line 63
    if-eqz v2, :cond_5

    .line 64
    .line 65
    or-int/lit16 v10, v10, 0x6000

    .line 66
    .line 67
    :cond_3
    :goto_1
    and-int/lit16 v1, v10, 0x2493

    .line 68
    .line 69
    const/16 v0, 0x2492

    .line 70
    .line 71
    const/4 v4, 0x0

    .line 72
    const/4 v3, 0x1

    .line 73
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-static {v0, v6, v10}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_9

    .line 82
    .line 83
    if-eqz v2, :cond_4

    .line 84
    .line 85
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 86
    .line 87
    :cond_4
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 88
    .line 89
    invoke-interface {v7, v2}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 90
    .line 91
    .line 92
    move-result-object v9

    .line 93
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingXsmall:F

    .line 94
    .line 95
    invoke-static {v6, v0, v4}, LX/008;->A0n(LX/2d4;FI)LX/3BI;

    .line 96
    .line 97
    .line 98
    move-result-object v14

    .line 99
    move-object v1, v6

    .line 100
    check-cast v1, LX/J7I;

    .line 101
    .line 102
    invoke-static {v1}, LX/003;->A0F(LX/J7I;)I

    .line 103
    .line 104
    .line 105
    move-result v13

    .line 106
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 107
    .line 108
    .line 109
    move-result-object v12

    .line 110
    invoke-static {v6, v9}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 111
    .line 112
    .line 113
    move-result-object v11

    .line 114
    sget-object v9, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 115
    .line 116
    iget-object v0, v1, LX/J7I;->A0V:LX/3DJ;

    .line 117
    .line 118
    if-nez v0, :cond_7

    .line 119
    .line 120
    invoke-static {}, LX/1VY;->A00()V

    .line 121
    .line 122
    .line 123
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    throw v0

    .line 128
    :cond_5
    and-int/lit16 v0, v5, 0x6000

    .line 129
    .line 130
    if-nez v0, :cond_3

    .line 131
    .line 132
    invoke-static {v6, v7}, LX/004;->A0d(LX/2d4;Ljava/lang/Object;)I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    or-int/2addr v10, v0

    .line 137
    goto :goto_1

    .line 138
    :cond_6
    move v10, v5

    .line 139
    goto :goto_0

    .line 140
    :cond_7
    invoke-static {v6, v1, v9}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 141
    .line 142
    .line 143
    invoke-static {v6, v14, v12, v11, v13}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 144
    .line 145
    .line 146
    sget-object v11, LX/3C1;->A00:LX/3Cb;

    .line 147
    .line 148
    invoke-interface {v6}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v9

    .line 152
    sget-object v0, LX/2d6;->A00:Ljava/lang/Object;

    .line 153
    .line 154
    if-ne v9, v0, :cond_8

    .line 155
    .line 156
    sget-object v9, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialReload$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialReload$1$1$1;

    .line 157
    .line 158
    invoke-interface {v6, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    :cond_8
    check-cast v9, LX/JDM;

    .line 162
    .line 163
    const/16 v16, 0x0

    .line 164
    .line 165
    invoke-static {v11, v9, v4}, LX/36n;->A01(LX/3C1;LX/JDM;Z)LX/3C1;

    .line 166
    .line 167
    .line 168
    move-result-object v9

    .line 169
    and-int/lit8 v0, v10, 0xe

    .line 170
    .line 171
    invoke-static {v8, v9, v6, v0, v4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialStatus(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 172
    .line 173
    .line 174
    invoke-static {v6}, LX/007;->A0h(LX/2d4;)Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;

    .line 175
    .line 176
    .line 177
    move-result-object v20

    .line 178
    sget-object v21, Lcom/facebook/aura/vds/compose/button/AuraButtonSize;->MEDIUM:Lcom/facebook/aura/vds/compose/button/AuraButtonSize;

    .line 179
    .line 180
    and-int/lit8 v9, v10, 0x70

    .line 181
    .line 182
    const v0, 0x30c00

    .line 183
    .line 184
    .line 185
    or-int/2addr v9, v0

    .line 186
    shl-int/lit8 v0, v10, 0x15

    .line 187
    .line 188
    invoke-static {v0, v9}, LX/002;->A05(II)I

    .line 189
    .line 190
    .line 191
    move-result p3

    .line 192
    shl-int/lit8 p4, v10, 0x3

    .line 193
    .line 194
    const v0, 0xe000

    .line 195
    .line 196
    .line 197
    and-int p4, p4, v0

    .line 198
    .line 199
    const p6, 0x7ffbdc5

    .line 200
    .line 201
    .line 202
    move-object/from16 v18, v16

    .line 203
    .line 204
    move-object/from16 v22, v16

    .line 205
    .line 206
    move/from16 v23, v4

    .line 207
    .line 208
    move/from16 v24, v4

    .line 209
    .line 210
    move/from16 v26, v4

    .line 211
    .line 212
    move/from16 v27, v4

    .line 213
    .line 214
    move-object/from16 v28, v16

    .line 215
    .line 216
    move-object/from16 v29, v16

    .line 217
    .line 218
    move-object/from16 v30, v15

    .line 219
    .line 220
    move-object/from16 v31, v16

    .line 221
    .line 222
    move-object/from16 v32, v16

    .line 223
    .line 224
    move-object/from16 v33, v16

    .line 225
    .line 226
    move-object/from16 v34, v16

    .line 227
    .line 228
    move-object/from16 v35, v16

    .line 229
    .line 230
    move-object/from16 v36, v16

    .line 231
    .line 232
    move-object/from16 v37, v16

    .line 233
    .line 234
    move-object/from16 v38, v16

    .line 235
    .line 236
    move/from16 v39, v4

    .line 237
    .line 238
    move/from16 v40, v4

    .line 239
    .line 240
    move/from16 p0, v4

    .line 241
    .line 242
    move/from16 p1, v4

    .line 243
    .line 244
    move-object/from16 p2, v6

    .line 245
    .line 246
    move/from16 p5, v4

    .line 247
    .line 248
    move-object/from16 v19, v2

    .line 249
    .line 250
    invoke-static/range {v16 .. v47}, Lcom/facebook/aura/vds/compose/button/AuraButtonKt;->AuraButton-nL3aKkM(Ljava/lang/String;Ljava/lang/String;LX/2wS;LX/3C1;Lcom/facebook/aura/vds/compose/button/AuraLabelButtonStyle;Lcom/facebook/aura/vds/compose/button/AuraButtonSize;LX/JDQ;ZZZZZLX/3Gw;LX/346;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;LX/JDN;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/facebook/aura/vds/compose/button/AuraButtonAccessibility;ZIZILX/2d4;IIII)V

    .line 251
    .line 252
    .line 253
    invoke-static {v1, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 254
    .line 255
    .line 256
    goto :goto_2

    .line 257
    :cond_9
    invoke-interface {v6}, LX/2d4;->AgJ()V

    .line 258
    .line 259
    .line 260
    :goto_2
    invoke-interface {v6}, LX/2d4;->AAg()LX/J7V;

    .line 261
    .line 262
    .line 263
    move-result-object v1

    .line 264
    if-eqz v1, :cond_a

    .line 265
    .line 266
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialReload$2;

    .line 267
    .line 268
    move-object/from16 p2, v17

    .line 269
    .line 270
    move/from16 p3, v25

    .line 271
    .line 272
    move-object/from16 p4, v15

    .line 273
    .line 274
    move-object/from16 p5, v7

    .line 275
    .line 276
    move/from16 p6, v5

    .line 277
    .line 278
    move-object/from16 p0, v0

    .line 279
    .line 280
    move-object/from16 p1, v8

    .line 281
    .line 282
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialReload$2;-><init>(Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/3C1;II)V

    .line 283
    .line 284
    .line 285
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 286
    .line 287
    :cond_a
    return-void
.end method

.method public static final ApprovalCredentialStatus(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 20

    .line 0
    move-object/from16 v7, p1

    .line 1
    .line 2
    const v0, 0x4bcdceb5    # 2.6975594E7f

    .line 3
    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    invoke-interface {v3, v0}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v2, p3

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x6

    .line 13
    .line 14
    move-object/from16 v6, p0

    .line 15
    .line 16
    if-nez v0, :cond_5

    .line 17
    .line 18
    invoke-static {v3, v6}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    or-int v4, p3, v0

    .line 23
    .line 24
    :goto_0
    move/from16 v1, p4

    .line 25
    .line 26
    and-int/lit8 v5, p4, 0x2

    .line 27
    .line 28
    if-eqz v5, :cond_4

    .line 29
    .line 30
    or-int/lit8 v4, v4, 0x30

    .line 31
    .line 32
    :cond_0
    :goto_1
    invoke-static {v4}, LX/005;->A1G(I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0, v3, v4}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_3

    .line 41
    .line 42
    if-eqz v5, :cond_1

    .line 43
    .line 44
    sget-object v7, LX/3C1;->A00:LX/3Cb;

    .line 45
    .line 46
    :cond_1
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 47
    .line 48
    const/16 p3, 0x6

    .line 49
    .line 50
    invoke-static {v3, v0}, LX/07H;->A0I(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 51
    .line 52
    .line 53
    move-result-object v10

    .line 54
    invoke-static {v3, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 55
    .line 56
    .line 57
    move-result-wide v8

    .line 58
    const/16 v17, 0x2

    .line 59
    .line 60
    invoke-static {v4}, LX/006;->A06(I)I

    .line 61
    .line 62
    .line 63
    move-result p2

    .line 64
    and-int/lit8 v0, v4, 0x70

    .line 65
    .line 66
    or-int p2, p2, v0

    .line 67
    .line 68
    const/16 p4, 0x39f0

    .line 69
    .line 70
    const/4 v11, 0x0

    .line 71
    const/4 v14, 0x0

    .line 72
    const/16 v16, 0x1

    .line 73
    .line 74
    move-object v12, v11

    .line 75
    move-object v13, v11

    .line 76
    move v15, v14

    .line 77
    move-object/from16 v18, v11

    .line 78
    .line 79
    move-object/from16 v19, v11

    .line 80
    .line 81
    move-object/from16 p0, v11

    .line 82
    .line 83
    move-object/from16 p1, v3

    .line 84
    .line 85
    invoke-static/range {v6 .. v24}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 86
    .line 87
    .line 88
    :goto_2
    invoke-interface {v3}, LX/2d4;->AAg()LX/J7V;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    if-eqz v3, :cond_2

    .line 93
    .line 94
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialStatus$1;

    .line 95
    .line 96
    invoke-direct {v0, v6, v7, v2, v1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialStatus$1;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 97
    .line 98
    .line 99
    iput-object v0, v3, LX/J7V;->A06:LX/JDN;

    .line 100
    .line 101
    :cond_2
    return-void

    .line 102
    :cond_3
    invoke-interface {v3}, LX/2d4;->AgJ()V

    .line 103
    .line 104
    .line 105
    goto :goto_2

    .line 106
    :cond_4
    and-int/lit8 v0, p3, 0x30

    .line 107
    .line 108
    if-nez v0, :cond_0

    .line 109
    .line 110
    invoke-static {v3, v7}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    or-int/2addr v4, v0

    .line 115
    goto :goto_1

    .line 116
    :cond_5
    move v4, v2

    .line 117
    goto :goto_0
.end method

.method public static final synthetic access$ApprovalCredentialAccountMenu(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialAccountMenu(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalCredentialAccountMenu$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0

    .line 0
    invoke-static {p1, p0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalCredentialAccountPicker(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialAccountPicker(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalCredentialChooser(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p8}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialChooser(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;ZLX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalCredentialDecisions_eHTjO5g$lambda$0(LX/16A;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 0

    .line 0
    invoke-interface {p0}, LX/16A;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$ApprovalCredentialDecisions_eHTjO5g$lambda$1(LX/16A;)LX/JDN;
    .locals 0

    .line 0
    invoke-static {p0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$ApprovalCredentialReload(Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialReload(Ljava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function0;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$ApprovalCredentialStatus(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt;->ApprovalCredentialStatus(Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
