.class public final Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $$changed:I

.field public final synthetic $faviconUri:Ljava/lang/String;

.field public final synthetic $tint:J


# direct methods
.method public constructor <init>(Ljava/lang/String;JI)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$faviconUri:Ljava/lang/String;

    .line 1
    .line 2
    iput-wide p2, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$tint:J

    .line 3
    .line 4
    iput p4, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$$changed:I

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 4

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$faviconUri:Ljava/lang/String;

    .line 1
    .line 2
    iget-wide v1, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$tint:J

    .line 3
    .line 4
    iget v0, p0, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt$CheckoutReviewOrderFavicon$1;->$$changed:I

    .line 5
    .line 6
    invoke-static {v0}, LX/0z0;->A00(I)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v3, v1, v2, p1, v0}, Lcom/facebook/aura/agentpermission/CheckoutApprovalCardKt;->CheckoutReviewOrderFavicon-RPmYEkk(Ljava/lang/String;JLX/2d4;I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
