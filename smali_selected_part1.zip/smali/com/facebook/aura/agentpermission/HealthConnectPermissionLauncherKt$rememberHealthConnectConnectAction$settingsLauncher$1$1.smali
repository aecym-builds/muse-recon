.class public final Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Landroidx/activity/result/ActivityResult;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $coroutineScope:LX/1EL;

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/1EL;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$coroutineScope:LX/1EL;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->invoke(Landroidx/activity/result/ActivityResult;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Landroidx/activity/result/ActivityResult;)V
    .locals 5

    .line 0
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$coroutineScope:LX/1EL;

    .line 1
    .line 2
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$context:Landroid/content/Context;

    .line 3
    .line 4
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1$1;

    .line 8
    .line 9
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1$1;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;LX/2M4;)V

    .line 10
    .line 11
    .line 12
    invoke-static {v0, v4}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
