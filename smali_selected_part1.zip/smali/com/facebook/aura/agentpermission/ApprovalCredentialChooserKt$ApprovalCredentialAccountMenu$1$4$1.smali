.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $expanded$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onEnterLogin:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $onSelect:LX/JDM;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDM<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;LX/JDM;Landroidx/compose/runtime/MutableState;LX/JDM;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "LX/JDM<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$onEnterLogin:LX/JDM;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$expanded$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$onSelect:LX/JDM;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->invoke(Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;)V
    .locals 3

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-static {p1, v1}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$expanded$delegate:Landroidx/compose/runtime/MutableState;

    .line 5
    .line 6
    invoke-static {v1, v0}, Landroidx/compose/runtime/MutableState;->A0R(ZLandroidx/compose/runtime/MutableState;)V

    .line 7
    .line 8
    .line 9
    iget v2, p1, Lcom/facebook/aura/vds/compose/contextmenu/AuraContextMenuItem;->id:I

    .line 10
    .line 11
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$uiState:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 12
    .line 13
    const/4 v0, -0x1

    .line 14
    if-ne v2, v0, :cond_1

    .line 15
    .line 16
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$onEnterLogin:LX/JDM;

    .line 21
    .line 22
    :goto_0
    invoke-interface {v1, v0}, LX/JDM;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :cond_1
    iget-object v0, v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 27
    .line 28
    invoke-static {v2, v0}, LX/B89;->A0N(ILjava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialAccountMenu$1$4$1;->$onSelect:LX/JDM;

    .line 37
    .line 38
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 39
    .line 40
    goto :goto_0
.end method
