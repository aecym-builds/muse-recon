.class public final Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1"
    f = "AgentPermissionMessageEditorScreen.kt"
    l = {
        0xd9
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $focusRequester:LX/3Bk;

.field public final synthetic $keyboardController:LX/2M7;

.field public label:I


# direct methods
.method public constructor <init>(LX/3Bk;LX/2M7;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/3Bk;",
            "LX/2M7;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$focusRequester:LX/3Bk;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$keyboardController:LX/2M7;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$focusRequester:LX/3Bk;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$keyboardController:LX/2M7;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;-><init>(LX/3Bk;LX/2M7;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-ne v0, v1, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$focusRequester:LX/3Bk;

    .line 13
    .line 14
    invoke-static {v0}, LX/3Bk;->A00(LX/3Bk;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->$keyboardController:LX/2M7;

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    invoke-interface {v0}, LX/2M7;->Ag7()V

    .line 22
    .line 23
    .line 24
    :cond_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 25
    .line 26
    return-object v2

    .line 27
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    sget-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1$1;

    .line 31
    .line 32
    iput v1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionMessageEditorScreenKt$MessageEditorFields$1$4$1;->label:I

    .line 33
    .line 34
    invoke-static {v0, p0}, LX/39q;->A01(LX/JDM;LX/2M4;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-ne v0, v2, :cond_0

    .line 39
    .line 40
    return-object v2

    .line 41
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    throw v0
.end method
