.class public abstract Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final AgentPermissionBannerCard(Ljava/util/List;Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 40
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;",
            ">;",
            "Ljava/lang/String;",
            "LX/3C1;",
            "LX/2d4;",
            "II)V"
        }
    .end annotation

    .line 0
    move-object/from16 v23, p2

    .line 1
    .line 2
    const/4 v9, 0x0

    .line 3
    move-object/from16 v11, p0

    .line 4
    .line 5
    invoke-static {v11, v9}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x474fd160

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p3

    .line 12
    .line 13
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v10, p4

    .line 17
    .line 18
    and-int/lit8 v0, p4, 0x6

    .line 19
    .line 20
    const/4 v3, 0x4

    .line 21
    if-nez v0, :cond_a

    .line 22
    .line 23
    invoke-static {v11, v1, v10}, LX/005;->A1W(Ljava/lang/Object;LX/2d4;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-static {v0}, LX/003;->A06(I)I

    .line 28
    .line 29
    .line 30
    move-result v7

    .line 31
    or-int v7, v7, p4

    .line 32
    .line 33
    :goto_0
    and-int/lit8 v0, p4, 0x30

    .line 34
    .line 35
    move-object/from16 p4, p1

    .line 36
    .line 37
    if-nez v0, :cond_0

    .line 38
    .line 39
    move-object/from16 v0, p4

    .line 40
    .line 41
    invoke-static {v1, v0}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    or-int/2addr v7, v0

    .line 46
    :cond_0
    move/from16 p3, p5

    .line 47
    .line 48
    and-int/lit8 v2, p5, 0x4

    .line 49
    .line 50
    if-eqz v2, :cond_9

    .line 51
    .line 52
    or-int/lit16 v7, v7, 0x180

    .line 53
    .line 54
    :cond_1
    :goto_1
    invoke-static {v7}, LX/005;->A1I(I)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    invoke-static {v0, v1, v7}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_c

    .line 63
    .line 64
    if-eqz v2, :cond_2

    .line 65
    .line 66
    sget-object v23, LX/3C1;->A00:LX/3Cb;

    .line 67
    .line 68
    :cond_2
    sget-object v2, Lcom/facebook/aura/navigation/AuraNavigatorKt;->LocalNavigator:LX/Ip3;

    .line 69
    .line 70
    move-object v0, v1

    .line 71
    check-cast v0, LX/J7I;

    .line 72
    .line 73
    invoke-static {v2, v0}, LX/004;->A15(LX/Iow;LX/J7I;)Lcom/facebook/aura/navigation/AuraNavigator;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    invoke-static {v2, v1, v9}, Lcom/facebook/aura/microphone/view/SilencedByMicrophoneKt;->rememberSilencedByMicrophone(Ljava/lang/Object;LX/2d4;I)Z

    .line 86
    .line 87
    .line 88
    move-result v12

    .line 89
    and-int/lit8 v2, v7, 0xe

    .line 90
    .line 91
    if-eq v2, v3, :cond_3

    .line 92
    .line 93
    and-int/lit8 v2, v7, 0x8

    .line 94
    .line 95
    if-eqz v2, :cond_8

    .line 96
    .line 97
    invoke-interface {v1, v11}, LX/2d4;->A6B(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v2

    .line 101
    if-eqz v2, :cond_8

    .line 102
    .line 103
    :cond_3
    const/4 v2, 0x1

    .line 104
    :goto_2
    invoke-static {v1, v5, v2}, LX/001;->A1W(LX/2d4;Ljava/lang/Object;Z)Z

    .line 105
    .line 106
    .line 107
    move-result v3

    .line 108
    invoke-static {v7}, LX/004;->A1S(I)Z

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    or-int/2addr v3, v2

    .line 113
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v4

    .line 117
    if-nez v3, :cond_4

    .line 118
    .line 119
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 120
    .line 121
    if-ne v4, v2, :cond_5

    .line 122
    .line 123
    :cond_4
    new-instance v4, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;

    .line 124
    .line 125
    move-object/from16 v2, p4

    .line 126
    .line 127
    invoke-direct {v4, v11, v5, v2}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$onReview$1$1;-><init>(Ljava/util/List;Lcom/facebook/aura/navigation/AuraNavigator;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-interface {v1, v4}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_5
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 134
    .line 135
    const v2, 0x4d5fcbd1    # 2.3466728E8f

    .line 136
    .line 137
    .line 138
    invoke-interface {v1, v2}, LX/2d4;->Agj(I)V

    .line 139
    .line 140
    .line 141
    sget-object v2, LX/2sI;->A02:LX/2wD;

    .line 142
    .line 143
    move-object/from16 v3, v23

    .line 144
    .line 145
    invoke-interface {v3, v2}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 146
    .line 147
    .line 148
    move-result-object v6

    .line 149
    const/high16 v5, 0x41800000    # 16.0f

    .line 150
    .line 151
    const/4 v3, 0x0

    .line 152
    invoke-static {v6, v5, v3}, LX/2pj;->A0A(LX/3C1;FF)LX/3C1;

    .line 153
    .line 154
    .line 155
    move-result-object v6

    .line 156
    const/high16 v5, 0x42800000    # 64.0f

    .line 157
    .line 158
    invoke-static {v6, v5}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 159
    .line 160
    .line 161
    move-result-object v6

    .line 162
    const/high16 v5, 0x41c00000    # 24.0f

    .line 163
    .line 164
    invoke-static {v5, v5, v3, v3}, LX/2bA;->A01(FFFF)LX/2bC;

    .line 165
    .line 166
    .line 167
    move-result-object v5

    .line 168
    invoke-static {v6, v5}, LX/1qF;->A03(LX/3C1;LX/2bW;)LX/3C1;

    .line 169
    .line 170
    .line 171
    move-result-object v8

    .line 172
    sget-object v22, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 173
    .line 174
    const/16 p1, 0x6

    .line 175
    .line 176
    sget-object v5, Lcom/facebook/aura/vds/compose/theme/AuraColorsKt;->LocalAuraColors:LX/Ip3;

    .line 177
    .line 178
    invoke-static {v5, v1}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    check-cast v6, Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 183
    .line 184
    sget v5, Lcom/facebook/aura/vds/compose/theme/AuraColors;->$stable:I

    .line 185
    .line 186
    invoke-static {v6, v1, v5}, Lcom/facebook/aura/vds/compose/theme/AuraAdaptiveColorsKt;->adaptiveSecondaryFill(Lcom/facebook/aura/vds/compose/theme/AuraColors;LX/2d4;I)J

    .line 187
    .line 188
    .line 189
    move-result-wide v5

    .line 190
    const/16 v21, 0x0

    .line 191
    .line 192
    invoke-static {v8, v5, v6}, LX/2pC;->A01(LX/3C1;J)LX/3C1;

    .line 193
    .line 194
    .line 195
    move-result-object v8

    .line 196
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 197
    .line 198
    shl-int/lit8 v5, v7, 0x3

    .line 199
    .line 200
    and-int/lit8 v5, v5, 0x70

    .line 201
    .line 202
    or-int/lit16 v5, v5, 0x180

    .line 203
    .line 204
    invoke-static {v8, v11, v6, v1, v5}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->agentPermissionApprovalImpressions(LX/3C1;Ljava/util/List;Lcom/facebook/aura/analytics/hatch/HatchScreen;LX/2d4;I)LX/3C1;

    .line 205
    .line 206
    .line 207
    move-result-object v7

    .line 208
    if-nez v12, :cond_7

    .line 209
    .line 210
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 211
    .line 212
    invoke-interface {v1}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v6

    .line 216
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 217
    .line 218
    if-ne v6, v5, :cond_6

    .line 219
    .line 220
    sget-object v6, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$1$1$1;

    .line 221
    .line 222
    invoke-interface {v1, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    :cond_6
    invoke-static {v8, v6, v9}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 226
    .line 227
    .line 228
    move-result-object v5

    .line 229
    invoke-interface {v7, v5}, LX/3C1;->then(LX/3C1;)LX/3C1;

    .line 230
    .line 231
    .line 232
    move-result-object v7

    .line 233
    :cond_7
    invoke-static {v0, v9}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 234
    .line 235
    .line 236
    invoke-static {v9}, LX/001;->A0g(Z)LX/3BI;

    .line 237
    .line 238
    .line 239
    move-result-object v6

    .line 240
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 241
    .line 242
    .line 243
    move-result v8

    .line 244
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 245
    .line 246
    .line 247
    move-result-object v5

    .line 248
    invoke-static {v1, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 249
    .line 250
    .line 251
    move-result-object v7

    .line 252
    sget-object v14, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 253
    .line 254
    iget-object v12, v0, LX/J7I;->A0V:LX/3DJ;

    .line 255
    .line 256
    if-nez v12, :cond_b

    .line 257
    .line 258
    invoke-static {}, LX/1VY;->A00()V

    .line 259
    .line 260
    .line 261
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    throw v0

    .line 266
    :cond_8
    const/4 v2, 0x0

    .line 267
    goto/16 :goto_2

    .line 268
    .line 269
    :cond_9
    and-int/lit16 v0, v10, 0x180

    .line 270
    .line 271
    if-nez v0, :cond_1

    .line 272
    .line 273
    move-object/from16 v0, v23

    .line 274
    .line 275
    invoke-static {v1, v0}, LX/004;->A0b(LX/2d4;Ljava/lang/Object;)I

    .line 276
    .line 277
    .line 278
    move-result v0

    .line 279
    or-int/2addr v7, v0

    .line 280
    goto/16 :goto_1

    .line 281
    .line 282
    :cond_a
    move v7, v10

    .line 283
    goto/16 :goto_0

    .line 284
    .line 285
    :cond_b
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 286
    .line 287
    .line 288
    sget-object v12, LX/3Cl;->A04:LX/JDN;

    .line 289
    .line 290
    invoke-static {v1, v6, v12}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 291
    .line 292
    .line 293
    move-result-object v6

    .line 294
    invoke-static {v1, v5, v6, v8}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 295
    .line 296
    .line 297
    move-result-object v20

    .line 298
    sget-object v5, LX/3Cl;->A02:LX/JDM;

    .line 299
    .line 300
    invoke-static {v1, v7, v5}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 301
    .line 302
    .line 303
    move-result-object v19

    .line 304
    sget-object v18, LX/3C1;->A00:LX/3Cb;

    .line 305
    .line 306
    const/high16 v15, 0x42200000    # 40.0f

    .line 307
    .line 308
    invoke-static {v2, v15}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 309
    .line 310
    .line 311
    move-result-object v7

    .line 312
    const/high16 v17, 0x41700000    # 15.0f

    .line 313
    .line 314
    move/from16 v2, v17

    .line 315
    .line 316
    invoke-static {v7, v2, v3, v3, v3}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 317
    .line 318
    .line 319
    move-result-object v2

    .line 320
    invoke-static {v1}, LX/008;->A0j(LX/2d4;)LX/3BI;

    .line 321
    .line 322
    .line 323
    move-result-object v13

    .line 324
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 325
    .line 326
    .line 327
    move-result v8

    .line 328
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 329
    .line 330
    .line 331
    move-result-object v7

    .line 332
    invoke-static {v1, v2}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 333
    .line 334
    .line 335
    move-result-object v2

    .line 336
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 337
    .line 338
    .line 339
    invoke-static {v1, v13, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 340
    .line 341
    .line 342
    invoke-static {v1, v7, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 343
    .line 344
    .line 345
    move-object/from16 v7, v20

    .line 346
    .line 347
    invoke-static {v5, v7, v1, v8}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 348
    .line 349
    .line 350
    move-object/from16 v7, v19

    .line 351
    .line 352
    invoke-static {v1, v2, v7}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 353
    .line 354
    .line 355
    sget-object v16, LX/CgK;->A00:LX/CgK;

    .line 356
    .line 357
    const v13, 0x7f100002

    .line 358
    .line 359
    .line 360
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 361
    .line 362
    .line 363
    move-result v8

    .line 364
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 365
    .line 366
    .line 367
    move-result v2

    .line 368
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 369
    .line 370
    .line 371
    move-result-object v7

    .line 372
    const/4 v2, 0x1

    .line 373
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    move-result-object v7

    .line 377
    invoke-static {v13, v7, v1, v8}, LX/18b;->A03(I[Ljava/lang/Object;LX/2d4;I)Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v24

    .line 381
    move-object/from16 v7, v22

    .line 382
    .line 383
    invoke-static {v1, v7}, LX/07H;->A0K(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 384
    .line 385
    .line 386
    move-result-object v28

    .line 387
    invoke-static {v1, v7}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 388
    .line 389
    .line 390
    move-result-wide v26

    .line 391
    const/16 v35, 0x2

    .line 392
    .line 393
    move-object/from16 v8, v16

    .line 394
    .line 395
    move-object/from16 v7, v18

    .line 396
    .line 397
    invoke-static {v8, v7, v2}, LX/006;->A0X(LX/CgK;LX/3C1;Z)LX/3C1;

    .line 398
    .line 399
    .line 400
    move-result-object v25

    .line 401
    const/16 p2, 0x39f0

    .line 402
    .line 403
    const/high16 p0, 0x30000000

    .line 404
    .line 405
    move-object/from16 v29, v21

    .line 406
    .line 407
    move-object/from16 v30, v21

    .line 408
    .line 409
    move-object/from16 v31, v21

    .line 410
    .line 411
    move/from16 v32, v9

    .line 412
    .line 413
    move/from16 v33, v9

    .line 414
    .line 415
    move/from16 v34, v2

    .line 416
    .line 417
    move-object/from16 v36, v21

    .line 418
    .line 419
    move-object/from16 v37, v21

    .line 420
    .line 421
    move-object/from16 v38, v21

    .line 422
    .line 423
    move-object/from16 v39, v1

    .line 424
    .line 425
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 426
    .line 427
    .line 428
    const/high16 v8, 0x42400000    # 48.0f

    .line 429
    .line 430
    invoke-static {v7, v8, v15}, LX/2sI;->A09(LX/3C1;FF)LX/3C1;

    .line 431
    .line 432
    .line 433
    move-result-object v8

    .line 434
    move-object/from16 v7, v21

    .line 435
    .line 436
    invoke-static {v8, v7, v4, v2}, LX/1Y9;->A00(LX/3C1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Z)LX/3C1;

    .line 437
    .line 438
    .line 439
    move-result-object v8

    .line 440
    const/high16 v7, 0x41400000    # 12.0f

    .line 441
    .line 442
    move/from16 v4, v17

    .line 443
    .line 444
    invoke-static {v8, v7, v3, v4, v3}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 445
    .line 446
    .line 447
    move-result-object v3

    .line 448
    invoke-static {}, LX/001;->A0e()LX/3BI;

    .line 449
    .line 450
    .line 451
    move-result-object v8

    .line 452
    invoke-static {v0}, LX/002;->A0J(LX/J7I;)I

    .line 453
    .line 454
    .line 455
    move-result v7

    .line 456
    invoke-static {v0}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 457
    .line 458
    .line 459
    move-result-object v4

    .line 460
    invoke-static {v1, v3}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 461
    .line 462
    .line 463
    move-result-object v3

    .line 464
    invoke-static {v1, v0, v14}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 465
    .line 466
    .line 467
    invoke-static {v1, v8, v12}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 468
    .line 469
    .line 470
    invoke-static {v1, v4, v6}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 471
    .line 472
    .line 473
    move-object/from16 v4, v20

    .line 474
    .line 475
    invoke-static {v5, v4, v1, v7}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 476
    .line 477
    .line 478
    move-object/from16 v4, v19

    .line 479
    .line 480
    invoke-static {v1, v3, v4}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 481
    .line 482
    .line 483
    const v3, 0x7f1200ac

    .line 484
    .line 485
    .line 486
    invoke-static {v1, v3}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 487
    .line 488
    .line 489
    move-result-object v24

    .line 490
    sget-object v3, Lcom/facebook/aura/vds/compose/theme/AuraTypographyKt;->LocalAuraTypography:LX/Ip3;

    .line 491
    .line 492
    invoke-static {v3, v1}, LX/003;->A0g(LX/Iow;Ljava/lang/Object;)Ljava/lang/Object;

    .line 493
    .line 494
    .line 495
    move-result-object v3

    .line 496
    check-cast v3, Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 497
    .line 498
    iget-object v4, v3, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->caption1Emphasized:LX/2hg;

    .line 499
    .line 500
    move-object/from16 v3, v22

    .line 501
    .line 502
    invoke-static {v1, v3}, LX/07H;->A07(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 503
    .line 504
    .line 505
    move-result-wide v26

    .line 506
    const/16 p2, 0x39f2

    .line 507
    .line 508
    move-object/from16 v25, v21

    .line 509
    .line 510
    move-object/from16 v28, v4

    .line 511
    .line 512
    invoke-static/range {v24 .. v42}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 513
    .line 514
    .line 515
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 516
    .line 517
    .line 518
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 519
    .line 520
    .line 521
    invoke-static {v0, v2}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 522
    .line 523
    .line 524
    goto :goto_3

    .line 525
    :cond_c
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 526
    .line 527
    .line 528
    :goto_3
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 529
    .line 530
    .line 531
    move-result-object v1

    .line 532
    if-eqz v1, :cond_d

    .line 533
    .line 534
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$3;

    .line 535
    .line 536
    move-object/from16 v38, v0

    .line 537
    .line 538
    move-object/from16 v39, v11

    .line 539
    .line 540
    move-object/from16 p0, p4

    .line 541
    .line 542
    move-object/from16 p1, v23

    .line 543
    .line 544
    move/from16 p2, v10

    .line 545
    .line 546
    invoke-direct/range {v38 .. v43}, Lcom/facebook/aura/agentpermission/AgentPermissionBannerCardKt$AgentPermissionBannerCard$3;-><init>(Ljava/util/List;Ljava/lang/String;LX/3C1;II)V

    .line 547
    .line 548
    .line 549
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 550
    .line 551
    :cond_d
    return-void
.end method
