.class public final Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Lcom/facebook/aura/ui/HatchSectionScope;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/ui/HatchSectionScope;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;->invoke(Lcom/facebook/aura/ui/HatchSectionScope;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/ui/HatchSectionScope;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 5
    .line 6
    new-instance p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;

    .line 7
    .line 8
    invoke-direct {p0, v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;-><init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V

    .line 9
    .line 10
    .line 11
    const v0, 0x2b1d98e9

    .line 12
    .line 13
    .line 14
    invoke-static {p1, p0, v0}, LX/007;->A1F(Lcom/facebook/aura/ui/HatchSectionScope;Ljava/lang/Object;I)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
