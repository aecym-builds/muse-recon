.class public final Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionNotificationRepository$start$1$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1
    .line 2
    return-object p0
.end method

.method public final emit(Lkotlin/Unit;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/Unit;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 268435456
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435457
    .line 268435458
    return-object p0
.end method
