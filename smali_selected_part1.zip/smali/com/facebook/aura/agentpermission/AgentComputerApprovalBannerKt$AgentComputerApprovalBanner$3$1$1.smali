.class public final Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->invoke()V

    .line 268435457
    .line 268435458
    .line 268435459
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435460
    .line 268435461
    return-object p0
.end method

.method public final invoke()V
    .locals 9

    .line 0
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchSurface;->CHAT:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->AGENT_PERMISSION:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 5
    .line 6
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchScreen;->AGENT_PERMISSION_BANNER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchComponent;->AGENT_PERMISSION_BANNER_REVIEW_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 11
    .line 12
    iget-object v6, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 13
    .line 14
    const/4 v7, 0x0

    .line 15
    move-object v8, v7

    .line 16
    invoke-virtual/range {v1 .. v8}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/AgentComputerApprovalBannerKt$AgentComputerApprovalBanner$3$1$1;->$currentApproval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 22
    .line 23
    iget-object v0, v0, Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;->approvalId:Ljava/lang/String;

    .line 24
    .line 25
    new-instance v1, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;

    .line 26
    .line 27
    invoke-direct {v1, v0}, Lcom/facebook/aura/navigation/key/AgentPermissionDecisionSheetKey;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    invoke-interface {v2, v1, v0}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
