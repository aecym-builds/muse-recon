.class public abstract Lcom/facebook/aura/agentpermission/DeliveryDetailTextKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final DeliveryDetailText(Ljava/lang/String;LX/3C1;LX/2d4;II)V
    .locals 21

    .line 0
    move-object/from16 v4, p1

    .line 1
    .line 2
    const/4 v15, 0x0

    .line 3
    move-object/from16 v7, p0

    .line 4
    .line 5
    invoke-static {v7, v15}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    const v0, -0x75f208f4

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p2

    .line 12
    .line 13
    invoke-interface {v1, v0}, LX/2d4;->Agl(I)V

    .line 14
    .line 15
    .line 16
    move/from16 v3, p3

    .line 17
    .line 18
    and-int/lit8 v0, p3, 0x6

    .line 19
    .line 20
    if-nez v0, :cond_5

    .line 21
    .line 22
    invoke-static {v1, v7}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    or-int v5, p3, v0

    .line 27
    .line 28
    :goto_0
    move/from16 v2, p4

    .line 29
    .line 30
    and-int/lit8 v6, p4, 0x2

    .line 31
    .line 32
    if-eqz v6, :cond_4

    .line 33
    .line 34
    or-int/lit8 v5, v5, 0x30

    .line 35
    .line 36
    :cond_0
    :goto_1
    invoke-static {v5}, LX/005;->A1G(I)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-static {v0, v1, v5}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    if-eqz v6, :cond_1

    .line 47
    .line 48
    sget-object v4, LX/3C1;->A00:LX/3Cb;

    .line 49
    .line 50
    :cond_1
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 51
    .line 52
    invoke-static {v1, v0}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 53
    .line 54
    .line 55
    move-result-object v11

    .line 56
    invoke-static {v1, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 57
    .line 58
    .line 59
    move-result-wide v9

    .line 60
    const/4 v12, 0x0

    .line 61
    invoke-static {v4}, LX/001;->A0W(LX/3C1;)LX/3C1;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {v0}, LX/2pj;->A03(LX/3C1;)LX/3C1;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    and-int/lit8 p2, v5, 0xe

    .line 70
    .line 71
    const/16 p4, 0x3ff0

    .line 72
    .line 73
    move-object v13, v12

    .line 74
    move-object v14, v12

    .line 75
    move/from16 v16, v15

    .line 76
    .line 77
    move/from16 v17, v15

    .line 78
    .line 79
    move/from16 v18, v15

    .line 80
    .line 81
    move-object/from16 v19, v12

    .line 82
    .line 83
    move-object/from16 v20, v12

    .line 84
    .line 85
    move-object/from16 p0, v12

    .line 86
    .line 87
    move-object/from16 p1, v1

    .line 88
    .line 89
    move/from16 p3, v15

    .line 90
    .line 91
    invoke-static/range {v7 .. v25}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 92
    .line 93
    .line 94
    :goto_2
    invoke-interface {v1}, LX/2d4;->AAg()LX/J7V;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    if-eqz v1, :cond_2

    .line 99
    .line 100
    new-instance v0, Lcom/facebook/aura/agentpermission/DeliveryDetailTextKt$DeliveryDetailText$1;

    .line 101
    .line 102
    invoke-direct {v0, v7, v4, v3, v2}, Lcom/facebook/aura/agentpermission/DeliveryDetailTextKt$DeliveryDetailText$1;-><init>(Ljava/lang/String;LX/3C1;II)V

    .line 103
    .line 104
    .line 105
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 106
    .line 107
    :cond_2
    return-void

    .line 108
    :cond_3
    invoke-interface {v1}, LX/2d4;->AgJ()V

    .line 109
    .line 110
    .line 111
    goto :goto_2

    .line 112
    :cond_4
    and-int/lit8 v0, p3, 0x30

    .line 113
    .line 114
    if-nez v0, :cond_0

    .line 115
    .line 116
    invoke-static {v1, v4}, LX/004;->A0a(LX/2d4;Ljava/lang/Object;)I

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    or-int/2addr v5, v0

    .line 121
    goto :goto_1

    .line 122
    :cond_5
    move v5, v3

    .line 123
    goto :goto_0
.end method
