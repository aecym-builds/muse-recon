.class public final Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;->INSTANCE:Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/1Xg;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/pastapprovals/ComposableSingletons$ActivePermissionsScreenKt$lambda$54296397$1;->invoke(LX/1Xg;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 1

    .line 0
    and-int/lit8 p0, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    invoke-static {p0, v0}, LX/003;->A1H(II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object p0, LX/2sI;->A02:LX/2wD;

    .line 16
    .line 17
    const/high16 v0, 0x43700000    # 240.0f

    .line 18
    .line 19
    invoke-static {p0, v0}, LX/2sI;->A04(LX/3C1;F)LX/3C1;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    const/4 v0, 0x6

    .line 24
    invoke-static {p0, p2, v0, p1}, Lcom/facebook/aura/ui/HatchScreenLoadingStateKt;->HatchScreenLoadingState(LX/3C1;LX/2d4;II)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 29
    .line 30
    .line 31
    return-void
.end method
