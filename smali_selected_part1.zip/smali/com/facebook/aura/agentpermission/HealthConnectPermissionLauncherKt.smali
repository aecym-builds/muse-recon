.class public abstract Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final synthetic access$rememberHealthConnectConnectAction$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$rememberHealthConnectConnectAction$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$rememberHealthConnectConnectAction$lambda$4(Landroidx/compose/runtime/MutableState;)Ljava/lang/Long;
    .locals 0

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/lang/Long;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final synthetic access$rememberHealthConnectConnectAction$lambda$5(Landroidx/compose/runtime/MutableState;Ljava/lang/Long;)V
    .locals 0

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberHealthConnectConnectAction(Lkotlin/jvm/functions/Function0;LX/2d4;I)Lkotlin/jvm/functions/Function0;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "LX/2d4;",
            "I)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v12, p0

    .line 2
    .line 3
    invoke-static {v12, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v3, p1

    .line 7
    .line 8
    invoke-static {v3}, LX/005;->A0Q(Ljava/lang/Object;)Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v10

    .line 12
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sget-object v2, LX/2d6;->A00:Ljava/lang/Object;

    .line 17
    .line 18
    invoke-static {v3, v0, v2}, LX/004;->A1B(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    check-cast v5, LX/1EL;

    .line 23
    .line 24
    new-array v1, v4, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-ne v0, v2, :cond_0

    .line 31
    .line 32
    sget-object v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$attemptId$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$attemptId$2$1;

    .line 33
    .line 34
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-static {v3, v0, v1}, LX/39E;->A02(LX/2d4;Ljava/lang/Object;[Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 38
    .line 39
    .line 40
    move-result-object v14

    .line 41
    new-array v1, v4, [Ljava/lang/Object;

    .line 42
    .line 43
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    if-ne v0, v2, :cond_1

    .line 48
    .line 49
    sget-object v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$startedAtMs$2$1;->INSTANCE:Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$startedAtMs$2$1;

    .line 50
    .line 51
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    invoke-static {v3, v0, v1}, LX/39E;->A01(LX/2d4;Ljava/lang/Object;[Ljava/lang/Object;)Landroidx/compose/runtime/MutableState;

    .line 55
    .line 56
    .line 57
    move-result-object v15

    .line 58
    new-instance v4, LX/13u;

    .line 59
    .line 60
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 61
    .line 62
    .line 63
    invoke-static {v3, v5, v10}, LX/003;->A1O(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v9

    .line 67
    and-int/lit8 v0, p2, 0xe

    .line 68
    .line 69
    xor-int/lit8 v7, v0, 0x6

    .line 70
    .line 71
    const/4 v8, 0x1

    .line 72
    const/4 v6, 0x4

    .line 73
    if-le v7, v6, :cond_2

    .line 74
    .line 75
    invoke-interface {v3, v12}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-nez v0, :cond_3

    .line 80
    .line 81
    :cond_2
    and-int/lit8 v1, p2, 0x6

    .line 82
    .line 83
    const/4 v0, 0x0

    .line 84
    if-ne v1, v6, :cond_4

    .line 85
    .line 86
    :cond_3
    const/4 v0, 0x1

    .line 87
    :cond_4
    or-int/2addr v9, v0

    .line 88
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-nez v9, :cond_5

    .line 93
    .line 94
    if-ne v0, v2, :cond_6

    .line 95
    .line 96
    :cond_5
    new-instance v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;

    .line 97
    .line 98
    invoke-direct {v0, v5, v10, v12}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$settingsLauncher$1$1;-><init>(LX/1EL;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 99
    .line 100
    .line 101
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    :cond_6
    check-cast v0, LX/JDM;

    .line 105
    .line 106
    invoke-static {v4, v3, v0}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 107
    .line 108
    .line 109
    move-result-object v11

    .line 110
    const-string v0, "com.google.android.apps.healthdata"

    .line 111
    .line 112
    new-instance v4, LX/14N;

    .line 113
    .line 114
    invoke-direct {v4, v0}, LX/14N;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    invoke-static {v3, v14, v15}, LX/003;->A1N(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    invoke-static {v3, v5, v10, v0}, LX/004;->A1Y(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Z)Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    if-le v7, v6, :cond_7

    .line 126
    .line 127
    invoke-interface {v3, v12}, LX/2d4;->A69(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    if-nez v0, :cond_8

    .line 132
    .line 133
    :cond_7
    and-int/lit8 v0, p2, 0x6

    .line 134
    .line 135
    if-eq v0, v6, :cond_8

    .line 136
    .line 137
    const/4 v8, 0x0

    .line 138
    :cond_8
    or-int/2addr v1, v8

    .line 139
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    if-nez v1, :cond_9

    .line 144
    .line 145
    if-ne v0, v2, :cond_a

    .line 146
    .line 147
    :cond_9
    new-instance v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;

    .line 148
    .line 149
    move-object/from16 v18, v14

    .line 150
    .line 151
    move-object/from16 p0, v15

    .line 152
    .line 153
    move-object/from16 p1, v10

    .line 154
    .line 155
    move-object/from16 p2, v12

    .line 156
    .line 157
    move-object/from16 v17, v5

    .line 158
    .line 159
    move-object/from16 v16, v0

    .line 160
    .line 161
    invoke-direct/range {v16 .. v21}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1;-><init>(LX/1EL;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v3, v0}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    :cond_a
    check-cast v0, LX/JDM;

    .line 168
    .line 169
    invoke-static {v4, v3, v0}, LX/16g;->A00(LX/14D;LX/2d4;LX/JDM;)LX/166;

    .line 170
    .line 171
    .line 172
    move-result-object v13

    .line 173
    invoke-static {v3, v10, v11, v13}, LX/005;->A1R(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    invoke-interface {v3}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v9

    .line 181
    if-nez v0, :cond_b

    .line 182
    .line 183
    if-ne v9, v2, :cond_c

    .line 184
    .line 185
    :cond_b
    new-instance v9, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$1$1;

    .line 186
    .line 187
    invoke-direct/range {v9 .. v15}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$1$1;-><init>(Landroid/content/Context;LX/166;Lkotlin/jvm/functions/Function0;LX/166;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 188
    .line 189
    .line 190
    invoke-interface {v3, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_c
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 194
    .line 195
    return-object v9
.end method

.method public static final rememberHealthConnectConnectAction$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 0
    invoke-static {p0}, Landroidx/compose/runtime/MutableState;->A0I(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final rememberHealthConnectConnectAction$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final rememberHealthConnectConnectAction$lambda$4(Landroidx/compose/runtime/MutableState;)Ljava/lang/Long;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/Long;"
        }
    .end annotation

    .line 0
    invoke-interface {p0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    check-cast p0, Ljava/lang/Long;

    .line 5
    .line 6
    return-object p0
.end method

.method public static final rememberHealthConnectConnectAction$lambda$5(Landroidx/compose/runtime/MutableState;Ljava/lang/Long;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;",
            "Ljava/lang/Long;",
            ")V"
        }
    .end annotation

    .line 0
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->Afc(Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method
