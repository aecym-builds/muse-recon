.class public final Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $attentionLabel:Ljava/lang/String;

.field public final synthetic $headline:LX/2iK;

.field public final synthetic $narrative:Ljava/lang/String;

.field public final synthetic $reviewText:Ljava/lang/String;

.field public final synthetic $treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;LX/2iK;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$narrative:Ljava/lang/String;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$attentionLabel:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$reviewText:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$headline:LX/2iK;

    .line 9
    .line 10
    const/4 v0, 0x3

    .line 11
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 37

    .line 0
    const/4 v3, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v2, p3

    .line 4
    .line 5
    invoke-static {v0, v3, v2}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    move-object/from16 v0, p2

    .line 10
    .line 11
    invoke-static {v1, v0, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_3

    .line 16
    .line 17
    sget v9, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingMedium:F

    .line 18
    .line 19
    invoke-static {v9}, LX/Dn6;->A00(F)LX/CP5;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    move-object/from16 v4, p0

    .line 24
    .line 25
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$narrative:Ljava/lang/String;

    .line 26
    .line 27
    move-object/from16 v16, v1

    .line 28
    .line 29
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$attentionLabel:Ljava/lang/String;

    .line 30
    .line 31
    move-object/from16 p3, v1

    .line 32
    .line 33
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$reviewText:Ljava/lang/String;

    .line 34
    .line 35
    move-object/from16 p2, v1

    .line 36
    .line 37
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$treatment:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;

    .line 38
    .line 39
    move-object/from16 v18, v1

    .line 40
    .line 41
    iget-object v1, v4, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1;->$headline:LX/2iK;

    .line 42
    .line 43
    move-object/from16 v17, v1

    .line 44
    .line 45
    sget-object v5, LX/3C1;->A00:LX/3Cb;

    .line 46
    .line 47
    invoke-static {v2, v0, v3}, LX/001;->A0f(LX/Dps;LX/2d4;I)LX/3BI;

    .line 48
    .line 49
    .line 50
    move-result-object v8

    .line 51
    move-object v1, v0

    .line 52
    check-cast v1, LX/J7I;

    .line 53
    .line 54
    iget-wide v6, v1, LX/J7I;->A06:J

    .line 55
    .line 56
    invoke-static {v6, v7}, LX/001;->A0A(J)I

    .line 57
    .line 58
    .line 59
    move-result v7

    .line 60
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    invoke-static {v0, v5}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    sget-object v15, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 69
    .line 70
    iget-object v2, v1, LX/J7I;->A0V:LX/3DJ;

    .line 71
    .line 72
    if-nez v2, :cond_0

    .line 73
    .line 74
    invoke-static {}, LX/1VY;->A00()V

    .line 75
    .line 76
    .line 77
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    throw v0

    .line 82
    :cond_0
    invoke-static {v0, v1, v15}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    sget-object v14, LX/3Cl;->A04:LX/JDN;

    .line 86
    .line 87
    invoke-static {v0, v8, v14}, LX/2d5;->A02(LX/2d4;Ljava/lang/Object;LX/JDN;)LX/JDN;

    .line 88
    .line 89
    .line 90
    move-result-object v13

    .line 91
    invoke-static {v0, v6, v13, v7}, LX/2d5;->A03(LX/2d4;Ljava/lang/Object;LX/JDN;I)LX/JDN;

    .line 92
    .line 93
    .line 94
    move-result-object v12

    .line 95
    sget-object v11, LX/3Cl;->A02:LX/JDM;

    .line 96
    .line 97
    invoke-static {v0, v4, v11}, LX/2d5;->A01(LX/2d4;Ljava/lang/Object;LX/JDM;)LX/JDN;

    .line 98
    .line 99
    .line 100
    move-result-object v10

    .line 101
    sget-object v7, LX/2sI;->A02:LX/2wD;

    .line 102
    .line 103
    invoke-static {v9}, LX/Dn6;->A00(F)LX/CP5;

    .line 104
    .line 105
    .line 106
    move-result-object v4

    .line 107
    sget-object v2, LX/2Id;->A05:LX/2rU;

    .line 108
    .line 109
    const/16 v8, 0x30

    .line 110
    .line 111
    invoke-static {v4, v0, v2, v8}, LX/1gq;->A00(LX/Cl0;LX/2d4;LX/2rU;I)LX/3BI;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    invoke-static {v1}, LX/002;->A0J(LX/J7I;)I

    .line 116
    .line 117
    .line 118
    move-result v6

    .line 119
    invoke-static {v1}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 120
    .line 121
    .line 122
    move-result-object v4

    .line 123
    invoke-static {v0, v7}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    invoke-static {v0, v1, v15}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 128
    .line 129
    .line 130
    invoke-static {v0, v9, v14}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v0, v4, v13}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v11, v12, v0, v6}, LX/2d5;->A0D(LX/JDM;LX/JDN;LX/2d4;I)V

    .line 137
    .line 138
    .line 139
    invoke-static {v0, v2, v10}, LX/2d5;->A0B(LX/2d4;Ljava/lang/Object;LX/JDN;)V

    .line 140
    .line 141
    .line 142
    sget-object v6, LX/CgK;->A00:LX/CgK;

    .line 143
    .line 144
    invoke-virtual/range {v18 .. v18}, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationTreatment;->getIconRes()I

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    invoke-static {v0, v2, v3}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 149
    .line 150
    .line 151
    move-result-object v20

    .line 152
    sget-object v2, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 153
    .line 154
    const/16 p1, 0x6

    .line 155
    .line 156
    invoke-static {v0, v2}, LX/07H;->A02(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 157
    .line 158
    .line 159
    move-result-wide v23

    .line 160
    sget-object v21, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->MEDIUM:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 161
    .line 162
    invoke-static {}, LX/2l9;->A04()I

    .line 163
    .line 164
    .line 165
    move-result v27

    .line 166
    const/16 v28, 0x21

    .line 167
    .line 168
    const/16 v22, 0x0

    .line 169
    .line 170
    move-object/from16 v19, v22

    .line 171
    .line 172
    move-object/from16 v25, v22

    .line 173
    .line 174
    move-object/from16 v26, v0

    .line 175
    .line 176
    invoke-static/range {v19 .. v28}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 177
    .line 178
    .line 179
    invoke-static {v0, v2}, LX/07H;->A0L(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 180
    .line 181
    .line 182
    move-result-object v21

    .line 183
    invoke-static {v0, v2}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 184
    .line 185
    .line 186
    move-result-wide v19

    .line 187
    const/high16 v9, 0x3f800000    # 1.0f

    .line 188
    .line 189
    const/4 v4, 0x1

    .line 190
    invoke-virtual {v6, v5, v9, v4}, LX/CgK;->Aiw(LX/3C1;FZ)LX/3C1;

    .line 191
    .line 192
    .line 193
    move-result-object v9

    .line 194
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v6

    .line 198
    sget-object v5, LX/2d6;->A00:Ljava/lang/Object;

    .line 199
    .line 200
    if-ne v6, v5, :cond_1

    .line 201
    .line 202
    sget-object v6, Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;->INSTANCE:Lcom/facebook/aura/agentpermission/BrowserTaskConfirmationApprovalCardKt$BrowserTaskConfirmationApprovalCard$1$1$1$1$1;

    .line 203
    .line 204
    invoke-interface {v0, v6}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_1
    invoke-static {v9, v6, v3}, LX/001;->A0a(LX/3C1;Ljava/lang/Object;Z)LX/3C1;

    .line 208
    .line 209
    .line 210
    move-result-object v18

    .line 211
    const/16 p0, 0x7ff0

    .line 212
    .line 213
    const-wide/16 v25, 0x0

    .line 214
    .line 215
    move-object/from16 v23, v22

    .line 216
    .line 217
    move-object/from16 v24, v22

    .line 218
    .line 219
    move/from16 v27, v3

    .line 220
    .line 221
    move/from16 v28, v3

    .line 222
    .line 223
    move/from16 v29, v3

    .line 224
    .line 225
    move/from16 v30, v3

    .line 226
    .line 227
    move-object/from16 v31, v22

    .line 228
    .line 229
    move-object/from16 v32, v22

    .line 230
    .line 231
    move-object/from16 v33, v22

    .line 232
    .line 233
    move-object/from16 v34, v0

    .line 234
    .line 235
    move/from16 v35, v3

    .line 236
    .line 237
    move/from16 v36, v3

    .line 238
    .line 239
    invoke-static/range {v17 .. v37}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-VmYn7U0(LX/2iK;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;JZIIILX/JDM;LX/2Qv;LX/0Xl;LX/2d4;III)V

    .line 240
    .line 241
    .line 242
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 243
    .line 244
    .line 245
    if-nez v16, :cond_2

    .line 246
    .line 247
    const v2, 0x30562989

    .line 248
    .line 249
    .line 250
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 251
    .line 252
    .line 253
    invoke-static {v1, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 254
    .line 255
    .line 256
    :goto_0
    const/4 v14, 0x4

    .line 257
    move-object/from16 v9, p3

    .line 258
    .line 259
    move-object/from16 v10, v22

    .line 260
    .line 261
    move-object v11, v10

    .line 262
    move-object v12, v0

    .line 263
    move v13, v8

    .line 264
    invoke-static/range {v9 .. v14}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionAttentionBanner(Ljava/lang/String;Ljava/lang/String;LX/3C1;LX/2d4;II)V

    .line 265
    .line 266
    .line 267
    move-object/from16 v33, p2

    .line 268
    .line 269
    move-object/from16 v34, v10

    .line 270
    .line 271
    move-object/from16 v36, v0

    .line 272
    .line 273
    move/from16 p0, v3

    .line 274
    .line 275
    invoke-static/range {v33 .. v38}, Lcom/facebook/aura/agentpermission/AgentPermissionPendingCardKt;->AgentPermissionReviewText(Ljava/lang/String;LX/3C1;ZLX/2d4;II)V

    .line 276
    .line 277
    .line 278
    invoke-static {v1, v4}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 279
    .line 280
    .line 281
    return-void

    .line 282
    :cond_2
    const v5, 0x3056298a

    .line 283
    .line 284
    .line 285
    invoke-static {v0, v2, v5}, LX/002;->A0h(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;I)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 286
    .line 287
    .line 288
    move-result-object v5

    .line 289
    iget-object v5, v5, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->footnoteRegular:LX/2hg;

    .line 290
    .line 291
    invoke-static {v0, v2}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 292
    .line 293
    .line 294
    move-result-wide v11

    .line 295
    const/16 v27, 0x3ff0

    .line 296
    .line 297
    move-object/from16 v9, v16

    .line 298
    .line 299
    move-object v10, v7

    .line 300
    move-object v13, v5

    .line 301
    move-object/from16 v14, v22

    .line 302
    .line 303
    move-object v15, v14

    .line 304
    move-object/from16 v16, v14

    .line 305
    .line 306
    move/from16 v17, v3

    .line 307
    .line 308
    move/from16 v18, v3

    .line 309
    .line 310
    move/from16 v19, v3

    .line 311
    .line 312
    move/from16 v20, v3

    .line 313
    .line 314
    move-object/from16 v21, v14

    .line 315
    .line 316
    move-object/from16 v24, v0

    .line 317
    .line 318
    move/from16 v25, v8

    .line 319
    .line 320
    move/from16 v26, v3

    .line 321
    .line 322
    invoke-static/range {v9 .. v27}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 323
    .line 324
    .line 325
    invoke-static {v1, v3}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 326
    .line 327
    .line 328
    goto :goto_0

    .line 329
    :cond_3
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 330
    .line 331
    .line 332
    return-void
.end method
