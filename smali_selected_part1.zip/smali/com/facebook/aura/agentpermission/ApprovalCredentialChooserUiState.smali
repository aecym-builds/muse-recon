.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final blockedKinds:LX/1c6;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/1c6<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final credentialIds:LX/0Xl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final enterLoginPageUrl:Ljava/lang/String;

.field public final origin:Ljava/lang/String;

.field public final rows:LX/Ddn;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;",
            ">;"
        }
    .end annotation
.end field

.field public final selectedLabel:Ljava/lang/String;

.field public final status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;


# direct methods
.method public constructor <init>()V
    .locals 7

    .line 0
    const/4 v2, 0x0

    .line 1
    sget-object v1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 2
    .line 3
    sget-object v3, LX/Dwg;->A01:LX/Dwg;

    .line 4
    .line 5
    sget-object v5, LX/InZ;->A03:LX/InZ;

    .line 6
    .line 7
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 8
    .line 9
    .line 10
    move-result-object v6

    .line 11
    move-object v0, p0

    .line 12
    move-object v4, v2

    .line 13
    move-object p0, v2

    .line 14
    invoke-direct/range {v0 .. v7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;",
            ">;",
            "Ljava/lang/String;",
            "LX/1c6<",
            "Ljava/lang/String;",
            ">;",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 268435456
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435457
    .line 268435458
    .line 268435459
    invoke-static {p5, p6}, LX/004;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435460
    .line 268435461
    .line 268435462
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435463
    .line 268435464
    .line 268435465
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 268435466
    .line 268435467
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 268435468
    .line 268435469
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 268435470
    .line 268435471
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 268435472
    .line 268435473
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 268435474
    .line 268435475
    iput-object p6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 268435476
    .line 268435477
    iput-object p7, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 268435478
    .line 268435479
    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p8, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    sget-object p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;->LOADING:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 536870917
    .line 536870918
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 536870919
    .line 536870920
    const/4 v1, 0x0

    .line 536870921
    if-eqz v0, :cond_1

    .line 536870922
    .line 536870923
    move-object p2, v1

    .line 536870924
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    sget-object p3, LX/Dwg;->A01:LX/Dwg;

    .line 536870929
    .line 536870930
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 536870931
    .line 536870932
    if-eqz v0, :cond_3

    .line 536870933
    .line 536870934
    move-object p4, v1

    .line 536870935
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 536870936
    .line 536870937
    if-eqz v0, :cond_4

    .line 536870938
    .line 536870939
    sget-object p5, LX/InZ;->A03:LX/InZ;

    .line 536870940
    .line 536870941
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 536870942
    .line 536870943
    if-eqz v0, :cond_5

    .line 536870944
    .line 536870945
    invoke-static {}, LX/InY;->A00()LX/InY;

    .line 536870946
    .line 536870947
    .line 536870948
    move-result-object p6

    .line 536870949
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 536870950
    .line 536870951
    if-eqz v0, :cond_6

    .line 536870952
    .line 536870953
    move-object p7, v1

    .line 536870954
    :cond_6
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)V

    .line 536870955
    .line 536870956
    .line 536870957
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 1

    .line 0
    and-int/lit8 v0, p8, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p8, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p8, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p8, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p8, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p8, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p8, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 41
    .line 42
    :cond_6
    invoke-virtual/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->copy(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()LX/1c6;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/1c6<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;",
            "Ljava/lang/String;",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;",
            ">;",
            "Ljava/lang/String;",
            "LX/1c6<",
            "Ljava/lang/String;",
            ">;",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;"
        }
    .end annotation

    .line 0
    invoke-static {p1, p3}, LX/008;->A1L(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p5, p6}, LX/004;->A1K(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    new-instance p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 7
    .line 8
    invoke-direct/range {p0 .. p7}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;-><init>(Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;Ljava/lang/String;LX/Ddn;Ljava/lang/String;LX/1c6;LX/0Xl;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 49
    .line 50
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 57
    .line 58
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 59
    .line 60
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 67
    .line 68
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_1

    .line 75
    .line 76
    :cond_0
    return v2

    .line 77
    :cond_1
    return v3
.end method

.method public final getBlockedKinds()LX/1c6;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/1c6<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCredentialIds()LX/0Xl;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/0Xl<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEnterLoginPageUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrigin()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRows()LX/Ddn;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/Ddn<",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSelectedLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStatus()Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->status:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserStatus;

    .line 1
    .line 2
    invoke-static {v0}, LX/001;->A0C(Ljava/lang/Object;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->origin:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    add-int/2addr v1, v0

    .line 13
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->rows:LX/Ddn;

    .line 16
    .line 17
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->selectedLabel:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v1, v0

    .line 28
    mul-int/lit8 v1, v1, 0x1f

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->blockedKinds:LX/1c6;

    .line 31
    .line 32
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->credentialIds:LX/0Xl;

    .line 37
    .line 38
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserUiState;->enterLoginPageUrl:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v0}, LX/006;->A0K(Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
