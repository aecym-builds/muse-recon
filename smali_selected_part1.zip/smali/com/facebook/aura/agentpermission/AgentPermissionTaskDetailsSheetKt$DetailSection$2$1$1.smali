.class public final Lcom/facebook/aura/agentpermission/AgentPermissionTaskDetailsSheetKt$DetailSection$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $body:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionTaskDetailsSheetKt$DetailSection$2$1$1;->$body:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionTaskDetailsSheetKt$DetailSection$2$1$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 16

    .line 0
    const/4 v8, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v1, p3

    .line 4
    .line 5
    invoke-static {v0, v8, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object/from16 v15, p2

    .line 10
    .line 11
    invoke-static {v0, v15, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 18
    .line 19
    invoke-static {v15, v0}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-static {v15, v0}, LX/07H;->A06(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 24
    .line 25
    .line 26
    move-result-wide v2

    .line 27
    const/4 v5, 0x0

    .line 28
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 29
    .line 30
    const/high16 v0, 0x41800000    # 16.0f

    .line 31
    .line 32
    invoke-static {v1, v0}, LX/2pj;->A07(LX/3C1;F)LX/3C1;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    move-object/from16 v0, p0

    .line 37
    .line 38
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/AgentPermissionTaskDetailsSheetKt$DetailSection$2$1$1;->$body:Ljava/lang/String;

    .line 39
    .line 40
    const/16 p2, 0x3ff0

    .line 41
    .line 42
    const/16 p0, 0x30

    .line 43
    .line 44
    move-object v6, v5

    .line 45
    move-object v7, v5

    .line 46
    move v9, v8

    .line 47
    move v10, v8

    .line 48
    move v11, v8

    .line 49
    move-object v12, v5

    .line 50
    move-object v13, v5

    .line 51
    move-object v14, v5

    .line 52
    move/from16 p1, v8

    .line 53
    .line 54
    invoke-static/range {v0 .. v18}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_0
    invoke-interface {v15}, LX/2d4;->AgJ()V

    .line 59
    .line 60
    .line 61
    return-void
.end method
