.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/1Xg;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $onRetry:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;->$onRetry:Lkotlin/jvm/functions/Function0;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/1Xg;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;->invoke(LX/1Xg;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/1Xg;LX/2d4;I)V
    .locals 9

    .line 0
    invoke-static {p3}, LX/005;->A1F(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    move-object p1, p2

    .line 5
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const v0, 0x7f1200aa

    .line 12
    .line 13
    .line 14
    invoke-static {p2, v0}, LX/18b;->A05(LX/2d4;I)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$approvalsStatusItem$1;->$onRetry:Lkotlin/jvm/functions/Function0;

    .line 19
    .line 20
    const/4 p0, 0x0

    .line 21
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 22
    .line 23
    const/high16 v0, 0x41800000    # 16.0f

    .line 24
    .line 25
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const/high16 v0, 0x43480000    # 200.0f

    .line 30
    .line 31
    invoke-static {v1, v0}, LX/006;->A0Z(LX/3C1;F)LX/3C1;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchSurface;->STATUS:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 36
    .line 37
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->BOT_SHEET_CONTENT:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 38
    .line 39
    sget-object v7, Lcom/facebook/aura/analytics/hatch/HatchScreen;->BOT_SHEET:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 40
    .line 41
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->TAB_APPROVALS:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 42
    .line 43
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchComponent;->getValue()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v8

    .line 47
    const p2, 0x36d80

    .line 48
    .line 49
    .line 50
    const/16 p3, 0x80

    .line 51
    .line 52
    invoke-static/range {v2 .. v12}, Lcom/facebook/aura/ui/HatchScreenErrorStateKt;->HatchScreenErrorState(Ljava/lang/String;Lkotlin/jvm/functions/Function0;LX/3C1;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Ljava/lang/String;Ljava/util/Map;LX/2d4;II)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_0
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 57
    .line 58
    .line 59
    return-void
.end method
