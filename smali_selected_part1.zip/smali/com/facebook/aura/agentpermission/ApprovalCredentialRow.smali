.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;
.super LX/07H;
.source ""


# static fields
.field public static final $stable:I


# instance fields
.field public final credentialId:Ljava/lang/String;

.field public final isSelectable:Z

.field public final isSelected:Z

.field public final label:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZZ)V
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 9
    .line 10
    iput-boolean p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 11
    .line 12
    iput-boolean p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 13
    .line 14
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;Ljava/lang/String;Ljava/lang/String;ZZILjava/lang/Object;)Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-boolean p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-boolean p4, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 23
    .line 24
    :cond_3
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 28
    .line 29
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V

    .line 30
    .line 31
    .line 32
    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component4()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 1
    .line 2
    return p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;ZZ)Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;
    .locals 0

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 31
    .line 32
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 33
    .line 34
    if-ne v1, v0, :cond_0

    .line 35
    .line 36
    iget-boolean v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 37
    .line 38
    iget-boolean v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 39
    .line 40
    if-eq v1, v0, :cond_1

    .line 41
    .line 42
    :cond_0
    return v2

    .line 43
    :cond_1
    return v3
.end method

.method public final getCredentialId()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->credentialId:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/006;->A0J(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->label:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/07F;->A00(IZ)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    return v0
.end method

.method public final isSelectable()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelectable:Z

    .line 1
    .line 2
    return p0
.end method

.method public final isSelected()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialRow;->isSelected:Z

    .line 1
    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
