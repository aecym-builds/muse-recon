.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/39x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "LX/39x;"
    }
.end annotation


# instance fields
.field public final synthetic $currentOnDecisionClick$delegate:LX/16A;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/16A<",
            "LX/JDN<",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/16A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/16A<",
            "+",
            "LX/JDN<",
            "-",
            "Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;>;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;->$currentOnDecisionClick$delegate:LX/16A;

    .line 1
    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final emit(Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;LX/2M4;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;->$currentOnDecisionClick$delegate:LX/16A;

    .line 1
    .line 2
    invoke-static {v0}, LX/16A;->A08(LX/16A;)LX/JDN;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    iget-object v1, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;->option:Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;->credentialId:Ljava/lang/String;

    .line 9
    .line 10
    invoke-interface {p0, v1, v0}, LX/JDN;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v0
.end method

.method public bridge synthetic emit(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$1$1$1;->emit(Lcom/facebook/aura/agentpermission/ApprovalCredentialDecision;LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method
