.class public final Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;->invoke(LX/2d4;I)V

    .line 268435463
    .line 268435464
    .line 268435465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435466
    .line 268435467
    return-object v0
.end method

.method public final invoke(LX/2d4;I)V
    .locals 1

    .line 0
    invoke-static {p2}, LX/005;->A1D(I)Z

    .line 1
    .line 2
    .line 3
    move-result v0

    .line 4
    invoke-static {v0, p1, p2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;->title:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {p1, v0}, LX/008;->A1K(LX/2d4;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 19
    .line 20
    .line 21
    return-void
.end method
