.class public final Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "Lcom/facebook/aura/analytics/hatch/HatchComponent;",
        "Lcom/facebook/aura/navigation/AuraNavKey;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/navigation/AuraNavigator;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 268435457
    .line 268435458
    check-cast p2, Lcom/facebook/aura/navigation/AuraNavKey;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->invoke(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/navigation/AuraNavKey;)V

    .line 268435461
    .line 268435462
    .line 268435463
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435464
    .line 268435465
    return-object p0
.end method

.method public final invoke(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/navigation/AuraNavKey;)V
    .locals 9

    .line 0
    const/4 v1, 0x0

    .line 1
    move-object v2, p1

    .line 2
    invoke-static {p1, p2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result v7

    .line 6
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    sget-object v8, LX/0Xj;->A00:LX/0Xj;

    .line 12
    .line 13
    move-object v6, v5

    .line 14
    invoke-static/range {v2 .. v8}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/RichApprovalCardKt$rememberRichApprovalTap$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 18
    .line 19
    invoke-interface {v0, p2, v1}, Lcom/facebook/aura/navigation/AuraNavigator;->navigate(Lcom/facebook/aura/navigation/AuraNavKey;Z)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
