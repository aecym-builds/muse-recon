.class public final Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 1
    .line 2
    const/4 v0, 0x3

    .line 3
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 18

    .line 0
    const/4 v11, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v1, p3

    .line 4
    .line 5
    invoke-static {v0, v11, v1}, LX/005;->A1V(Ljava/lang/Object;II)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object/from16 v2, p2

    .line 10
    .line 11
    invoke-static {v0, v2, v1}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    move-object/from16 v0, p0

    .line 18
    .line 19
    iget-object v0, v0, Lcom/facebook/aura/agentpermission/ComposableSingletons$ConnectorOrderDetailGroupSheetKt$lambda$860891760$1$2$1$1;->$info:Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;

    .line 20
    .line 21
    iget-object v3, v0, Lcom/facebook/aura/gateway/ConnectorCheckoutPriceLine$Info;->body:Ljava/lang/String;

    .line 22
    .line 23
    sget-object v0, Lcom/facebook/aura/vds/compose/theme/AuraTheme;->INSTANCE:Lcom/facebook/aura/vds/compose/theme/AuraTheme;

    .line 24
    .line 25
    invoke-static {v2, v0}, LX/07H;->A0J(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)LX/2hg;

    .line 26
    .line 27
    .line 28
    move-result-object v7

    .line 29
    invoke-static {v2, v0}, LX/07H;->A05(LX/2d4;Lcom/facebook/aura/vds/compose/theme/AuraTheme;)J

    .line 30
    .line 31
    .line 32
    move-result-wide v5

    .line 33
    sget-object v0, LX/3C1;->A00:LX/3Cb;

    .line 34
    .line 35
    invoke-static {v0}, LX/2pj;->A03(LX/3C1;)LX/3C1;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    const/16 p3, 0x3ff0

    .line 40
    .line 41
    const/4 v8, 0x0

    .line 42
    move-object v9, v8

    .line 43
    move-object v10, v8

    .line 44
    move v12, v11

    .line 45
    move v13, v11

    .line 46
    move v14, v11

    .line 47
    move-object v15, v8

    .line 48
    move-object/from16 v16, v8

    .line 49
    .line 50
    move-object/from16 v17, v8

    .line 51
    .line 52
    move-object/from16 p0, v2

    .line 53
    .line 54
    move/from16 p1, v11

    .line 55
    .line 56
    move/from16 p2, v11

    .line 57
    .line 58
    invoke-static/range {v3 .. v21}, Lcom/facebook/aura/vds/compose/text/AuraTextKt;->AuraText-UY9GdpU(Ljava/lang/String;LX/3C1;JLX/2hg;LX/2i5;LX/2W8;LX/2wS;ZIIILX/JDM;LX/2Qv;LX/1Sf;LX/2d4;III)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_0
    invoke-interface {v2}, LX/2d4;->AgJ()V

    .line 63
    .line 64
    .line 65
    return-void
.end method
