.class public final Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final $stable:I = 0x0

.field public static final CONFIG_ID:I = 0x22112

.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;

.field public static final __CONFIG__:I = 0x234

.field public static final is_nodes_media_enabled:LX/0d8;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;->INSTANCE:Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;

    .line 6
    .line 7
    const-wide v0, 0x8102340000014dL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    invoke-static {v0, v1}, LX/0d8;->A00(J)LX/0d8;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lcom/facebook/aura/agentpermission/MC$hatch_media_sync;->is_nodes_media_enabled:LX/0d8;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method
