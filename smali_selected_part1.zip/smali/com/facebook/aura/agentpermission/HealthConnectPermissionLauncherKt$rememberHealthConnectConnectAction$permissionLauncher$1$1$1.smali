.class public final Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1"
    f = "HealthConnectPermissionLauncher.kt"
    l = {
        0x32
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $attempt:Ljava/lang/String;

.field public final synthetic $attemptId$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $startedAt:Ljava/lang/Long;

.field public label:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attempt:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$startedAt:Ljava/lang/Long;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attempt:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$startedAt:Ljava/lang/Long;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-ne v0, v4, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    invoke-static {p1}, LX/001;->A1Y(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    sget-object v0, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->INSTANCE:Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/facebook/aura/permissions/changes/PermissionChangeNotifier;->notifyChanged()V

    .line 19
    .line 20
    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attemptId$delegate:Landroidx/compose/runtime/MutableState;

    .line 24
    .line 25
    invoke-interface {v0}, Landroidx/compose/runtime/MutableState;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    if-nez v0, :cond_1

    .line 30
    .line 31
    sget-object v0, Lcom/facebook/aura/agentpermission/LocalConnectorConsentHandshake;->onAccept:Lkotlin/jvm/functions/Function0;

    .line 32
    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    sget-object v1, Lcom/facebook/aura/health/HealthConnectPermissionUtils;->INSTANCE:Lcom/facebook/aura/health/HealthConnectPermissionUtils;

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$context:Landroid/content/Context;

    .line 38
    .line 39
    invoke-virtual {v1, v0}, Lcom/facebook/aura/health/HealthConnectPermissionUtils;->openPermissionSettings(Landroid/content/Context;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$onPermissionFlowFinished:Lkotlin/jvm/functions/Function0;

    .line 43
    .line 44
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 48
    .line 49
    return-object v0

    .line 50
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    sget-object v3, Lcom/facebook/aura/health/HealthConnectPermissionUtils;->INSTANCE:Lcom/facebook/aura/health/HealthConnectPermissionUtils;

    .line 54
    .line 55
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$context:Landroid/content/Context;

    .line 56
    .line 57
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$attempt:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->$startedAt:Ljava/lang/Long;

    .line 60
    .line 61
    iput v4, p0, Lcom/facebook/aura/agentpermission/HealthConnectPermissionLauncherKt$rememberHealthConnectConnectAction$permissionLauncher$1$1$1;->label:I

    .line 62
    .line 63
    invoke-virtual {v3, v2, v1, v0, p0}, Lcom/facebook/aura/health/HealthConnectPermissionUtils;->completeConsentAttempt(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Long;LX/2M4;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    if-ne p1, v5, :cond_0

    .line 68
    .line 69
    return-object v5

    .line 70
    :cond_3
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    throw v0
.end method
