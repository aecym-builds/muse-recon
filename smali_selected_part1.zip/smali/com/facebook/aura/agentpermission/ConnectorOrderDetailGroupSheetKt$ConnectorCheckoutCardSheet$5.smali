.class public final Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDQ;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDQ<",
        "LX/3dS;",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $content:LX/JDO;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/JDO<",
            "LX/3dS;",
            "TT;",
            "LX/2d4;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $selected:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LX/JDO;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/JDO<",
            "-",
            "LX/3dS;",
            "-TT;-",
            "LX/2d4;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;TT;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;->$content:LX/JDO;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;->$selected:Ljava/lang/Object;

    .line 3
    .line 4
    const/4 v0, 0x3

    .line 5
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/3dS;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2d4;

    .line 268435459
    .line 268435460
    invoke-static {p3}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435461
    .line 268435462
    .line 268435463
    move-result v0

    .line 268435464
    invoke-virtual {p0, p1, p2, v0}, Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;->invoke(LX/3dS;LX/2d4;I)V

    .line 268435465
    .line 268435466
    .line 268435467
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435468
    .line 268435469
    return-object v0
.end method

.method public final invoke(LX/3dS;LX/2d4;I)V
    .locals 7

    .line 0
    and-int/lit8 v1, p3, 0x11

    .line 1
    .line 2
    const/16 v0, 0x10

    .line 3
    .line 4
    invoke-static {v1, v0}, LX/003;->A1H(II)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-static {v0, p2, p3}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    sget-object v1, LX/2sI;->A02:LX/2wD;

    .line 15
    .line 16
    sget v0, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingLarge:F

    .line 17
    .line 18
    invoke-static {v1, v0}, LX/2pj;->A06(LX/3C1;F)LX/3C1;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-object p1, p0, Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;->$content:LX/JDO;

    .line 23
    .line 24
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/ConnectorOrderDetailGroupSheetKt$ConnectorCheckoutCardSheet$5;->$selected:Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p2}, LX/003;->A0X(LX/2d4;)LX/3BI;

    .line 27
    .line 28
    .line 29
    move-result-object v6

    .line 30
    move-object v5, p2

    .line 31
    check-cast v5, LX/J7I;

    .line 32
    .line 33
    invoke-static {v5}, LX/003;->A0F(LX/J7I;)I

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    invoke-static {v5}, LX/J7I;->A04(LX/J7I;)LX/IoC;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    invoke-static {p2, v0}, LX/3FK;->A01(LX/2d4;LX/3C1;)LX/3C1;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    sget-object v1, LX/3Cl;->A00:Lkotlin/jvm/functions/Function0;

    .line 46
    .line 47
    iget-object v0, v5, LX/J7I;->A0V:LX/3DJ;

    .line 48
    .line 49
    if-nez v0, :cond_0

    .line 50
    .line 51
    invoke-static {}, LX/1VY;->A00()V

    .line 52
    .line 53
    .line 54
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    throw v0

    .line 59
    :cond_0
    invoke-static {p2, v5, v1}, LX/005;->A0t(LX/2d4;LX/J7I;Lkotlin/jvm/functions/Function0;)V

    .line 60
    .line 61
    .line 62
    invoke-static {p2, v6, v3, v2, v4}, LX/2d5;->A08(LX/2d4;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 63
    .line 64
    .line 65
    sget-object v1, LX/CgJ;->A00:LX/CgJ;

    .line 66
    .line 67
    const/4 v0, 0x6

    .line 68
    invoke-static {v1, p0, p2, p1, v0}, LX/002;->A1J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;LX/JDO;I)V

    .line 69
    .line 70
    .line 71
    const/4 v0, 0x1

    .line 72
    invoke-static {v5, v0}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :cond_1
    invoke-interface {p2}, LX/2d4;->AgJ()V

    .line 77
    .line 78
    .line 79
    return-void
.end method
