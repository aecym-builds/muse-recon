.class public final Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDM<",
        "Ljava/lang/String;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic $approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

.field public final synthetic $screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

.field public final synthetic $viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;)V
    .locals 1

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, Ljava/lang/String;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->invoke(Ljava/lang/String;)V

    .line 268435459
    .line 268435460
    .line 268435461
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 268435462
    .line 268435463
    return-object p0
.end method

.method public final invoke(Ljava/lang/String;)V
    .locals 7

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->SECURE_STORAGE_CREDENTIAL_ROW:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$screen:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 7
    .line 8
    iget-object v2, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$approval:Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v5, 0x1

    .line 12
    sget-object v6, LX/0Xj;->A00:LX/0Xj;

    .line 13
    .line 14
    move-object v4, v3

    .line 15
    invoke-static/range {v0 .. v6}, Lcom/facebook/aura/agentpermission/AgentPermissionTelemetryKt;->logAgentPermissionCardClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/gateway/HatchAgentPermissionsRepository$AgentPermissionApproval;Ljava/util/List;Lcom/facebook/aura/gateway/AgentPermissionDecisionOption;ILjava/util/Map;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserKt$ApprovalCredentialDecisions$2$1$1;->$viewModel:Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, Lcom/facebook/aura/agentpermission/ApprovalCredentialChooserViewModel;->select(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method
