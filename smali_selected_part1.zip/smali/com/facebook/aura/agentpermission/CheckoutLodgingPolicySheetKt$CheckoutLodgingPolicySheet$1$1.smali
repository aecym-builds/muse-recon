.class public final Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.agentpermission.CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1"
    f = "CheckoutLodgingPolicySheet.kt"
    l = {}
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $available:Z

.field public final synthetic $navigator:Lcom/facebook/aura/navigation/AuraNavigator;

.field public label:I


# direct methods
.method public constructor <init>(ZLcom/facebook/aura/navigation/AuraNavigator;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lcom/facebook/aura/navigation/AuraNavigator;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$available:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-boolean p1, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$available:Z

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;-><init>(ZLcom/facebook/aura/navigation/AuraNavigator;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget v0, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->label:I

    .line 1
    .line 2
    if-nez v0, :cond_1

    .line 3
    .line 4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-boolean v0, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$available:Z

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/agentpermission/CheckoutLodgingPolicySheetKt$CheckoutLodgingPolicySheet$1$1;->$navigator:Lcom/facebook/aura/navigation/AuraNavigator;

    .line 12
    .line 13
    invoke-interface {v0}, Lcom/facebook/aura/navigation/AuraNavigator;->back()Z

    .line 14
    .line 15
    .line 16
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_1
    invoke-static {}, LX/001;->A0q()Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    throw v0
.end method
