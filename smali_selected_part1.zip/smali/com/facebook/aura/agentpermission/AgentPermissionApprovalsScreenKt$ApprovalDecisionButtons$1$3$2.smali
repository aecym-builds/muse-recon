.class public final Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;
.super LX/DRv;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "LX/JDN<",
        "LX/2d4;",
        "Ljava/lang/Integer;",
        "LX/2hg;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;->INSTANCE:Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x2

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke(LX/2d4;I)LX/2hg;
    .locals 21

    .line 0
    const v0, 0x42bf2a88

    .line 1
    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, LX/2d4;->Agj(I)V

    .line 6
    .line 7
    .line 8
    invoke-static {v1}, LX/007;->A0j(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraTypography;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v3, v0, Lcom/facebook/aura/vds/compose/theme/AuraTypography;->subheadlineMedium:LX/2hg;

    .line 13
    .line 14
    const/16 v0, 0x14

    .line 15
    .line 16
    invoke-static {v0}, LX/2S9;->A02(I)J

    .line 17
    .line 18
    .line 19
    move-result-wide p1

    .line 20
    const v15, 0xfdffff

    .line 21
    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    const-wide/16 v16, 0x0

    .line 25
    .line 26
    const/4 v12, 0x0

    .line 27
    move-object v4, v2

    .line 28
    move-object v5, v2

    .line 29
    move-object v6, v2

    .line 30
    move-object v7, v2

    .line 31
    move-object v8, v2

    .line 32
    move-object v9, v2

    .line 33
    move-object v10, v2

    .line 34
    move-object v11, v2

    .line 35
    move v13, v12

    .line 36
    move v14, v12

    .line 37
    move-wide/from16 v18, v16

    .line 38
    .line 39
    move-wide/from16 v20, v16

    .line 40
    .line 41
    invoke-static/range {v2 .. v23}, LX/2hg;->A00(LX/2SR;LX/2hg;LX/IzA;LX/2i5;LX/2W8;LX/2iI;LX/2RW;LX/2Qv;LX/2hr;Ljava/lang/String;IIIIJJJJ)LX/2hg;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-static {v1}, LX/001;->A1M(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 268435456
    check-cast p1, LX/2d4;

    .line 268435457
    .line 268435458
    invoke-static {p2}, LX/001;->A0D(Ljava/lang/Object;)I

    .line 268435459
    .line 268435460
    .line 268435461
    move-result v0

    .line 268435462
    invoke-virtual {p0, p1, v0}, Lcom/facebook/aura/agentpermission/AgentPermissionApprovalsScreenKt$ApprovalDecisionButtons$1$3$2;->invoke(LX/2d4;I)LX/2hg;

    .line 268435463
    .line 268435464
    .line 268435465
    move-result-object v0

    .line 268435466
    return-object v0
.end method
