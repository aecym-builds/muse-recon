.class public abstract Lcom/facebook/aura/agentpermission/CheckoutRowChevronKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final CheckoutRowChevron(LX/3C1;LX/2d4;II)V
    .locals 11

    .line 0
    const v0, -0x71b30b69

    .line 1
    .line 2
    .line 3
    move-object v8, p1

    .line 4
    invoke-interface {p1, v0}, LX/2d4;->Agl(I)V

    .line 5
    .line 6
    .line 7
    and-int/lit8 v4, p3, 0x1

    .line 8
    .line 9
    const/4 v3, 0x2

    .line 10
    if-eqz v4, :cond_3

    .line 11
    .line 12
    or-int/lit8 v2, p2, 0x6

    .line 13
    .line 14
    :goto_0
    and-int/lit8 v0, v2, 0x3

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-static {v0, v3}, LX/003;->A1H(II)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0, p1, v2}, LX/001;->A1a(ZLX/2d4;I)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    if-eqz v4, :cond_0

    .line 28
    .line 29
    sget-object p0, LX/3C1;->A00:LX/3Cb;

    .line 30
    .line 31
    :cond_0
    const v0, 0x7f0800e8

    .line 32
    .line 33
    .line 34
    invoke-static {p1, v0, v1}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {p1}, LX/003;->A0b(LX/2d4;)Lcom/facebook/aura/vds/compose/theme/AuraColors;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    iget-wide v5, v0, Lcom/facebook/aura/vds/compose/theme/AuraColors;->tertiaryText:J

    .line 43
    .line 44
    sget-object v3, Lcom/facebook/aura/vds/compose/icons/AuraIconSize;->X_SMALL:Lcom/facebook/aura/vds/compose/icons/AuraIconSize;

    .line 45
    .line 46
    sget v1, Lcom/facebook/aura/vds/compose/base/AuraDimensKt;->SpacingSmall:F

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-static {p0, v1, v0, v0, v0}, LX/2pj;->A0B(LX/3C1;FFFF)LX/3C1;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-static {}, LX/2l9;->A04()I

    .line 55
    .line 56
    .line 57
    move-result v9

    .line 58
    const/16 v10, 0x20

    .line 59
    .line 60
    move-object v7, v4

    .line 61
    invoke-static/range {v1 .. v10}, Lcom/facebook/aura/vds/compose/icons/AuraIconKt;->AuraIcon-FHprtrg(LX/3C1;LX/2l9;Lcom/facebook/aura/vds/compose/icons/AuraIconSize;Ljava/lang/String;JLX/2vq;LX/2d4;II)V

    .line 62
    .line 63
    .line 64
    :goto_1
    invoke-interface {p1}, LX/2d4;->AAg()LX/J7V;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    if-eqz v1, :cond_1

    .line 69
    .line 70
    new-instance v0, Lcom/facebook/aura/agentpermission/CheckoutRowChevronKt$CheckoutRowChevron$1;

    .line 71
    .line 72
    invoke-direct {v0, p0, p2, p3}, Lcom/facebook/aura/agentpermission/CheckoutRowChevronKt$CheckoutRowChevron$1;-><init>(LX/3C1;II)V

    .line 73
    .line 74
    .line 75
    iput-object v0, v1, LX/J7V;->A06:LX/JDN;

    .line 76
    .line 77
    :cond_1
    return-void

    .line 78
    :cond_2
    invoke-interface {p1}, LX/2d4;->AgJ()V

    .line 79
    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_3
    and-int/lit8 v0, p2, 0x6

    .line 83
    .line 84
    if-nez v0, :cond_4

    .line 85
    .line 86
    invoke-static {p1, p0}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    or-int/2addr v2, p2

    .line 91
    goto :goto_0

    .line 92
    :cond_4
    move v2, p2

    .line 93
    goto :goto_0
.end method
