.class public final Lcom/facebook/aura/appid/AuraClientToken;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appid/AuraClientToken;

.field public static final loggedOutARAccessToken:Ljava/lang/String;

.field public static final loggedOutFRLAccessToken:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v0, Lcom/facebook/aura/appid/AuraClientToken;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appid/AuraClientToken;->INSTANCE:Lcom/facebook/aura/appid/AuraClientToken;

    .line 6
    .line 7
    const-string v2, "1237225311881278"

    .line 8
    .line 9
    const-string v1, "6f0e5d739d0a9ba664848be8d1d3c01e"

    .line 10
    .line 11
    const-string v0, "AR|"

    .line 12
    .line 13
    const-string v3, "|"

    .line 14
    .line 15
    invoke-static {v0, v2, v3, v1}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Lcom/facebook/aura/appid/AuraClientToken;->loggedOutARAccessToken:Ljava/lang/String;

    .line 20
    .line 21
    const-string v2, "4387961628157459"

    .line 22
    .line 23
    const-string v1, "94a311186817e40ff116fbc11d7e2a72"

    .line 24
    .line 25
    const-string v0, "FRL|"

    .line 26
    .line 27
    invoke-static {v0, v2, v3, v1}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, Lcom/facebook/aura/appid/AuraClientToken;->loggedOutFRLAccessToken:Ljava/lang/String;

    .line 32
    .line 33
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getLoggedOutARAccessToken()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appid/AuraClientToken;->loggedOutARAccessToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLoggedOutFRLAccessToken()Ljava/lang/String;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/appid/AuraClientToken;->loggedOutFRLAccessToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
