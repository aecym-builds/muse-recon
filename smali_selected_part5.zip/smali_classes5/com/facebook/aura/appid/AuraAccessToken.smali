.class public final Lcom/facebook/aura/appid/AuraAccessToken;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appid/AuraAccessToken;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appid/AuraAccessToken;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appid/AuraAccessToken;->INSTANCE:Lcom/facebook/aura/appid/AuraAccessToken;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getARAccessToken()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "6f0e5d739d0a9ba664848be8d1d3c01e"

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFRLAccessToken()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "94a311186817e40ff116fbc11d7e2a72"

    .line 1
    .line 2
    return-object p0
.end method
