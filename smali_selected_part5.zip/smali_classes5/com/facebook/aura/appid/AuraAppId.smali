.class public final Lcom/facebook/aura/appid/AuraAppId;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/appid/AuraAppId;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/appid/AuraAppId;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/appid/AuraAppId;->INSTANCE:Lcom/facebook/aura/appid/AuraAppId;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getAbraAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p0}, LX/EYs;->A00(I)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getAppClientToken()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "330bd45681a06ad240322862d206c0be"

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "4331325740476680"

    .line 1
    .line 2
    return-object p0
.end method

.method public final getAppName()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x3

    .line 1
    invoke-static {p0}, LX/601;->A00(I)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getArAppId()Ljava/lang/String;
    .locals 0
    .annotation runtime Lkotlin/Deprecated;
        message = "Legacy \u2014 only used by AuthLite/CrudoNet. Use getAbraAppId() for new code."
        replaceWith = .subannotation Lkotlin/ReplaceWith;
            expression = "getAbraAppId()"
            imports = {}
        .end subannotation
    .end annotation

    .line 0
    const-string p0, "1237225311881278"

    .line 1
    .line 2
    return-object p0
.end method

.method public final getFrlAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const-string p0, "4387961628157459"

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPushAppId()Ljava/lang/String;
    .locals 0

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p0}, LX/EYs;->A00(I)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
