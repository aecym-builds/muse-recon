.class public final Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraInviteFriendViewModel$renderStoryCard$1"
    f = "AuraInviteFriendViewModel.kt"
    l = {
        0x81
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $accessCodeMessage:Ljava/lang/String;

.field public final synthetic $content:LX/IBK;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic $context:Landroid/content/Context;

.field public final synthetic $message:Ljava/lang/String;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/IBK;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;",
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$message:Ljava/lang/String;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$accessCodeMessage:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 7
    .line 8
    iput-object p5, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$content:LX/IBK;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p0, v0, p6}, LX/DRu;-><init>(ILX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$context:Landroid/content/Context;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$message:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$accessCodeMessage:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v4, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 7
    .line 8
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$content:LX/IBK;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;

    .line 11
    .line 12
    move-object p1, p2

    .line 13
    invoke-direct/range {v0 .. v6}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/IBK;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 3
    .line 4
    move-object/from16 v6, p0

    .line 5
    .line 6
    iget v0, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->label:I

    .line 7
    .line 8
    const/4 v4, 0x1

    .line 9
    if-eqz v0, :cond_4

    .line 10
    .line 11
    if-ne v0, v4, :cond_5

    .line 12
    .line 13
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast v3, Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 19
    .line 20
    iget-object v1, v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 21
    .line 22
    iget-object v0, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$content:LX/IBK;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    iget-object v1, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 31
    .line 32
    if-nez v3, :cond_2

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    iput-object v0, v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 36
    .line 37
    :cond_1
    :goto_0
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 38
    .line 39
    return-object v5

    .line 40
    :cond_2
    iget-object v2, v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 41
    .line 42
    :cond_3
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    move-object v4, v1

    .line 47
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 48
    .line 49
    const/16 p0, 0x1fff

    .line 50
    .line 51
    const/4 v5, 0x0

    .line 52
    const/4 v12, 0x0

    .line 53
    move-object v6, v5

    .line 54
    move-object v7, v5

    .line 55
    move-object v8, v5

    .line 56
    move-object v9, v5

    .line 57
    move-object v10, v5

    .line 58
    move-object v11, v5

    .line 59
    move-object v13, v5

    .line 60
    move-object v14, v5

    .line 61
    move v15, v12

    .line 62
    move/from16 v16, v12

    .line 63
    .line 64
    move/from16 v17, v12

    .line 65
    .line 66
    move-object/from16 v18, v3

    .line 67
    .line 68
    move-object/from16 p1, v5

    .line 69
    .line 70
    invoke-static/range {v4 .. v20}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->copy$default(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_3

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_4
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    sget-object v3, Lcom/facebook/aura/sharesheet/HatchInviteStoryImageRenderer;->INSTANCE:Lcom/facebook/aura/sharesheet/HatchInviteStoryImageRenderer;

    .line 85
    .line 86
    iget-object v2, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$context:Landroid/content/Context;

    .line 87
    .line 88
    iget-object v1, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$message:Ljava/lang/String;

    .line 89
    .line 90
    iget-object v0, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->$accessCodeMessage:Ljava/lang/String;

    .line 91
    .line 92
    iput v4, v6, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;->label:I

    .line 93
    .line 94
    invoke-virtual {v3, v2, v1, v0, v6}, Lcom/facebook/aura/sharesheet/HatchInviteStoryImageRenderer;->render(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    if-ne v3, v5, :cond_0

    .line 99
    .line 100
    return-object v5

    .line 101
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 102
    .line 103
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 104
    .line 105
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    throw v0
.end method
