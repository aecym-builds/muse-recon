.class public final Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;
.super LX/1EJ;
.source ""


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Companion;

.field public static final TAG:Ljava/lang/String; = "AuraActivationPlanFinishViewModel"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field public final _isFinishing:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final _page:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;",
            ">;"
        }
    .end annotation
.end field

.field public final _viewEffects:LX/EYl;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/EYl<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;",
            ">;"
        }
    .end annotation
.end field

.field public final activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

.field public final confidentialVmRepository:Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;

.field public final isFinishing:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public final page:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;",
            ">;"
        }
    .end annotation
.end field

.field public final setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

.field public final subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

.field public final viewEffects:LX/2Lw;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;",
            ">;"
        }
    .end annotation
.end field

.field public final viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->Companion:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;Lcom/facebook/aura/user/provider/AuraViewerDataProvider;)V
    .locals 4

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p2, p3, p4, p5, v0}, LX/005;->A13(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 6
    .line 7
    .line 8
    invoke-direct {p0}, LX/1EJ;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 12
    .line 13
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->confidentialVmRepository:Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;

    .line 14
    .line 15
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 16
    .line 17
    iput-object p4, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 18
    .line 19
    iput-object p5, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v1, -0x2

    .line 23
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-static {v0, v1}, LX/EMd;->A00(Ljava/lang/Integer;I)LX/Dbx;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_viewEffects:LX/EYl;

    .line 30
    .line 31
    invoke-static {v0}, LX/ESM;->A01(LX/DpP;)LX/5ND;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->viewEffects:LX/2Lw;

    .line 36
    .line 37
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    new-instance v1, LX/Ddv;

    .line 42
    .line 43
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_isFinishing:LX/2J2;

    .line 47
    .line 48
    new-instance v0, LX/ERk;

    .line 49
    .line 50
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 51
    .line 52
    .line 53
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->isFinishing:LX/2J3;

    .line 54
    .line 55
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->LOADING:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 56
    .line 57
    new-instance v1, LX/Ddv;

    .line 58
    .line 59
    invoke-direct {v1, v0}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iput-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_page:LX/2J2;

    .line 63
    .line 64
    new-instance v0, LX/ERk;

    .line 65
    .line 66
    invoke-direct {v0, v2, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 67
    .line 68
    .line 69
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->page:LX/2J3;

    .line 70
    .line 71
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->loadPage()V

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method private final acceptTerms(Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 1
    .line 2
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->io()LX/BqD;

    .line 3
    .line 4
    .line 5
    move-result-object v2

    .line 6
    const/4 v1, 0x0

    .line 7
    new-instance v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1, p2, v1}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V

    .line 10
    .line 11
    .line 12
    invoke-static {p3, v2, v0}, LX/DRD;->A00(LX/2M4;LX/BqD;LX/JDN;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method

.method public static final synthetic access$acceptTerms(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->acceptTerms(Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getActivationRepository$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSetupGate$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getSubscriptionRepository$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getViewerDataProvider$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_page$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_page:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_viewEffects$p(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;)LX/EYl;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_viewEffects:LX/EYl;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$logConfidentialVmOfferError(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->logConfidentialVmOfferError(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;)V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static final synthetic access$resolveConfidentialVmEffect(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->resolveConfidentialVmEffect(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final logConfidentialVmOfferError(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;)V
    .locals 9

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_page:LX/2J2;

    .line 1
    .line 2
    invoke-interface {v0}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->CONFIDENTIAL_VM_OFFER:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 7
    .line 8
    if-ne v1, v0, :cond_1

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$TermsFailed;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$TermsFailed;

    .line 11
    .line 12
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$ReturnToActivation;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$ReturnToActivation;

    .line 19
    .line 20
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$EnterExistingPin;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$EnterExistingPin;

    .line 27
    .line 28
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$CreatePin;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$CreatePin;

    .line 35
    .line 36
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_1

    .line 41
    .line 42
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$Finished;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$Finished;

    .line 43
    .line 44
    invoke-static {p1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 51
    .line 52
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 53
    .line 54
    .line 55
    throw v0

    .line 56
    :cond_0
    sget-object v2, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;

    .line 57
    .line 58
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchOrigin;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchOrigin;

    .line 59
    .line 60
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 61
    .line 62
    sget-object v5, Lcom/facebook/aura/analytics/hatch/HatchSubsurface;->ONBOARDING_POST_AUTH:Lcom/facebook/aura/analytics/hatch/HatchSubsurface;

    .line 63
    .line 64
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_CVM_OFFER:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 65
    .line 66
    sget-object v7, Lcom/facebook/aura/analytics/hatch/HatchComponent;->CVM_ERROR_STATE:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 67
    .line 68
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->ENTRY_POINT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 69
    .line 70
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    sget-object v0, Lcom/facebook/aura/navigation/key/SubscriptionPaywallEntryPoint;->ACTIVATION:Lcom/facebook/aura/navigation/key/SubscriptionPaywallEntryPoint;

    .line 75
    .line 76
    invoke-virtual {v0}, Lcom/facebook/aura/navigation/key/SubscriptionPaywallEntryPoint;->getValue()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-static {v1, v0}, LX/1H9;->A03(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    const/4 v8, 0x0

    .line 85
    move-object p1, v8

    .line 86
    invoke-virtual/range {v2 .. v10}, Lcom/facebook/aura/analytics/hatch/HatchImpressionLogger;->logImpression(Lcom/facebook/aura/analytics/hatch/HatchOrigin;Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Integer;)V

    .line 87
    .line 88
    .line 89
    :cond_1
    return-void
.end method

.method private final resolveConfidentialVmEffect(LX/2M4;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    move-object v5, p1

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v0, v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x1

    .line 25
    const/4 v3, 0x0

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v4, :cond_1

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_0
    new-instance v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;

    .line 32
    .line 33
    invoke-direct {v5, p0, p1}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 38
    .line 39
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 40
    .line 41
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v1

    .line 45
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->confidentialVmRepository:Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;

    .line 49
    .line 50
    iput v4, v5, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$resolveConfidentialVmEffect$1;->label:I

    .line 51
    .line 52
    invoke-interface {v0, v5}, Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;->resolveEnrollmentStep(LX/2M4;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    if-ne v2, v1, :cond_3

    .line 57
    .line 58
    return-object v1

    .line 59
    :goto_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    :cond_3
    check-cast v2, Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmEnrollmentStep;

    .line 63
    .line 64
    goto :goto_2
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    :catch_0
    move-exception v2

    .line 66
    const-string v1, "Failed to resolve confidential VM enrollment after purchase"

    .line 67
    .line 68
    const-string v0, "AuraActivationPlanFinishViewModel"

    .line 69
    .line 70
    invoke-static {v0, v1, v2}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    sget-object v2, Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmEnrollmentStep;->UNAVAILABLE:Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmEnrollmentStep;

    .line 74
    .line 75
    :goto_2
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    if-eq v1, v3, :cond_6

    .line 80
    .line 81
    if-eq v1, v4, :cond_5

    .line 82
    .line 83
    const/4 v0, 0x2

    .line 84
    if-ne v1, v0, :cond_4

    .line 85
    .line 86
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$ReturnToActivation;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$ReturnToActivation;

    .line 87
    .line 88
    return-object v0

    .line 89
    :cond_4
    new-instance v1, Lkotlin/NoWhenBranchMatchedException;

    .line 90
    .line 91
    invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V

    .line 92
    .line 93
    .line 94
    throw v1

    .line 95
    :cond_5
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$CreatePin;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$CreatePin;

    .line 96
    .line 97
    return-object v0

    .line 98
    :cond_6
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$EnterExistingPin;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$EnterExistingPin;

    .line 99
    .line 100
    return-object v0

    .line 101
    :catch_1
    move-exception v0

    .line 102
    throw v0
.end method


# virtual methods
.method public final getPage()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->page:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getViewEffects()LX/2Lw;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2Lw<",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->viewEffects:LX/2Lw;

    .line 1
    .line 2
    return-object p0
.end method

.method public final isFinishing()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->isFinishing:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final loadPage()V
    .locals 3

    .line 0
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_page:LX/2J2;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->LOADING:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 3
    .line 4
    check-cast v1, LX/Ddv;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    invoke-static {v2, v0, v1}, LX/Ddv;->A00(Ljava/lang/Object;Ljava/lang/Object;LX/Ddv;)Z

    .line 8
    .line 9
    .line 10
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    new-instance v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;

    .line 15
    .line 16
    invoke-direct {v0, p0, v2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final onPurchaseConfirmed(ZLcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;)V
    .locals 6

    .line 0
    const/4 v0, 0x2

    .line 1
    move-object v5, p3

    .line 2
    invoke-static {p3, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 3
    .line 4
    .line 5
    move-object v3, p0

    .line 6
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_isFinishing:LX/2J2;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v0, 0x1

    .line 14
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v2, LX/Ddv;

    .line 19
    .line 20
    invoke-static {v1, v0, v2}, LX/Ddv;->A00(Ljava/lang/Object;Ljava/lang/Object;LX/Ddv;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const/4 p0, 0x0

    .line 31
    new-instance v1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;

    .line 32
    .line 33
    move v2, p1

    .line 34
    move-object v4, p2

    .line 35
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;-><init>(ZLcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V

    .line 36
    .line 37
    .line 38
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    return-void
.end method
