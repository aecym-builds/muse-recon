.class public final Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDM;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDM<",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraInviteFriendViewModel$refresh$1$1"
    f = "AuraInviteFriendViewModel.kt"
    l = {
        0x3d
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 1
    .line 2
    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 1
    .line 2
    new-instance v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;

    .line 3
    .line 4
    invoke-direct {v0, p0, p1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final invoke(LX/2M4;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;

    .line 3
    .line 4
    invoke-direct {p0, v0, p1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/2M4;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->invoke(LX/2M4;)Ljava/lang/Object;

    .line 268435459
    .line 268435460
    .line 268435461
    move-result-object p0

    .line 268435462
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->label:I

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v1, :cond_2

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    .line 14
    return-object v2

    .line 15
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->this$0:Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 19
    .line 20
    iput v1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1$1;->label:I

    .line 21
    .line 22
    invoke-static {v0, p0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->access$load(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    if-ne v0, v2, :cond_0

    .line 27
    .line 28
    return-object v2

    .line 29
    :cond_2
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 30
    .line 31
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v0
.end method
