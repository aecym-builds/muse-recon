.class public final Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraActivationPlanFinishViewModel$acceptTerms$2"
    f = "AuraActivationPlanFinishViewModel.kt"
    l = {
        0x99,
        0x9a
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

.field public final synthetic $fallbackDisclosureText:Ljava/lang/String;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$fallbackDisclosureText:Ljava/lang/String;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-direct {p0, v0, p4}, LX/DRu;-><init>(ILX/2M4;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 3
    .line 4
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$fallbackDisclosureText:Ljava/lang/String;

    .line 5
    .line 6
    new-instance v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;

    .line 7
    .line 8
    invoke-direct {v0, v3, v2, v1, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->label:I

    .line 3
    .line 4
    const/4 v4, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    if-eq v0, v3, :cond_3

    .line 9
    .line 10
    if-ne v0, v4, :cond_6

    .line 11
    .line 12
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    check-cast p1, Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    :cond_1
    :goto_0
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0

    .line 29
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 33
    .line 34
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 35
    .line 36
    iput v3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->label:I

    .line 37
    .line 38
    invoke-virtual {v0, p0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->fetchTosMetadata(LX/2M4;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-ne p1, v5, :cond_4

    .line 43
    .line 44
    return-object v5

    .line 45
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_4
    check-cast p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 49
    .line 50
    if-eqz p1, :cond_5

    .line 51
    .line 52
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchTosMetadata;->hasAcceptedTos:Z

    .line 53
    .line 54
    if-ne v0, v3, :cond_5

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_5
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 58
    .line 59
    iget-object v2, v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 60
    .line 61
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 62
    .line 63
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->$fallbackDisclosureText:Ljava/lang/String;

    .line 64
    .line 65
    iput v4, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$acceptTerms$2;->label:I

    .line 66
    .line 67
    invoke-static {v2, v1, v0, p0}, Lcom/facebook/aura/activation/model/TosConsentKt;->submitTosConsent(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v5, :cond_0

    .line 72
    .line 73
    return-object v5

    .line 74
    :cond_6
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 75
    .line 76
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 77
    .line 78
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v0
.end method
