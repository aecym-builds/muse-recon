.class public final Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;",
        ">;"
    }
.end annotation


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->create()Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;
    .locals 6

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    sget-object v1, Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;->Companion:Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets$Companion;

    .line 9
    .line 10
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 11
    .line 12
    invoke-virtual {v1, v0}, Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    sget-object v1, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;->Companion:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate$Companion;

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 19
    .line 20
    invoke-virtual {v1, v0}, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    sget-object v1, Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;->Companion:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository$Companion;

    .line 25
    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    sget-object v1, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->Companion:Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;

    .line 33
    .line 34
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Factory;->userSession:LX/AHE;

    .line 35
    .line 36
    invoke-virtual {v1, v0}, Lcom/facebook/aura/user/provider/AuraViewerDataProvider$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    new-instance v1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 41
    .line 42
    invoke-direct/range {v1 .. v6}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;Lcom/facebook/aura/confidentialvm/api/secret/ConfidentialVmSecrets;Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;Lcom/facebook/aura/user/provider/AuraViewerDataProvider;)V

    .line 43
    .line 44
    .line 45
    return-object v1
.end method
