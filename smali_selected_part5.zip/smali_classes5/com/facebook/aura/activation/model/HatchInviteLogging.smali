.class public final Lcom/facebook/aura/activation/model/HatchInviteLogging;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final EVENT_INVITE_CODE_GENERATE:Ljava/lang/String; = "invite_code_generate"

.field public static final EVENT_INVITE_PAGE_LOAD:Ljava/lang/String; = "invite_page_load"

.field public static final EVENT_TYPE_STATUS_CHECK:Ljava/lang/String; = "status_check"

.field public static final INSTANCE:Lcom/facebook/aura/activation/model/HatchInviteLogging;

.field public static final KEY_HAS_CODE:Ljava/lang/String; = "has_code"

.field public static final KEY_HAS_INVITE_LINK:Ljava/lang/String; = "has_invite_link"

.field public static final KEY_HAS_SHARE_TEXT:Ljava/lang/String; = "has_share_text"

.field public static final KEY_INVITE_STATE:Ljava/lang/String; = "invite_state"

.field public static final RESULT_ERROR:Ljava/lang/String; = "error"

.field public static final RESULT_SUCCESS:Ljava/lang/String; = "success"

.field public static final SUBSURFACE_INVITE_FRIENDS:Ljava/lang/String; = "invite_friends"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/model/HatchInviteLogging;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/model/HatchInviteLogging;->INSTANCE:Lcom/facebook/aura/activation/model/HatchInviteLogging;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final bool(Z)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final logSheetClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V
    .locals 6

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;

    .line 1
    .line 2
    sget-object v1, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    sget-object v3, Lcom/facebook/aura/analytics/hatch/HatchScreen;->ONBOARDING_INVITE_FRIENDS:Lcom/facebook/aura/analytics/hatch/HatchScreen;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v4, p1

    .line 8
    move-object v5, v2

    .line 9
    move-object p0, v2

    .line 10
    move-object p1, v2

    .line 11
    invoke-virtual/range {v0 .. v7}, Lcom/facebook/aura/analytics/hatch/HatchInteractionLogger;->logClick(Lcom/facebook/aura/analytics/hatch/HatchSurface;Lcom/facebook/aura/analytics/hatch/HatchSubsurface;Lcom/facebook/aura/analytics/hatch/HatchScreen;Lcom/facebook/aura/analytics/hatch/HatchComponent;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method private final result(Z)Ljava/lang/String;
    .locals 0

    .line 0
    if-eqz p1, :cond_0

    .line 1
    .line 2
    const-string p0, "success"

    .line 3
    .line 4
    return-object p0

    .line 5
    :cond_0
    const-string p0, "error"

    .line 6
    .line 7
    return-object p0
.end method


# virtual methods
.method public final logCopyCodeClick()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->COPY_CODE_BUTTON:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/model/HatchInviteLogging;->logSheetClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final logInviteCodeGenerate(Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;)V
    .locals 12

    .line 0
    sget-object v6, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchSurface;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v8

    .line 8
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const/4 v2, 0x0

    .line 15
    if-eqz p1, :cond_6

    .line 16
    .line 17
    const-string v0, "success"

    .line 18
    .line 19
    :goto_0
    new-instance v5, LX/IBK;

    .line 20
    .line 21
    invoke-direct {v5, v1, v0}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    if-eqz p1, :cond_0

    .line 25
    .line 26
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->code:Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    const/4 v0, 0x0

    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    :cond_0
    const/4 v0, 0x1

    .line 38
    :cond_1
    xor-int/lit8 v0, v0, 0x1

    .line 39
    .line 40
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const-string v0, "has_code"

    .line 45
    .line 46
    new-instance v4, LX/IBK;

    .line 47
    .line 48
    invoke-direct {v4, v0, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    if-eqz p1, :cond_2

    .line 52
    .line 53
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->inviteLink:Ljava/lang/String;

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    const/4 v0, 0x0

    .line 62
    if-eqz v1, :cond_3

    .line 63
    .line 64
    :cond_2
    const/4 v0, 0x1

    .line 65
    :cond_3
    xor-int/lit8 v0, v0, 0x1

    .line 66
    .line 67
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const-string v0, "has_invite_link"

    .line 72
    .line 73
    new-instance v3, LX/IBK;

    .line 74
    .line 75
    invoke-direct {v3, v0, v1}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->shareText:Ljava/lang/String;

    .line 81
    .line 82
    if-eqz v0, :cond_4

    .line 83
    .line 84
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_5

    .line 89
    .line 90
    :cond_4
    const/4 v2, 0x1

    .line 91
    :cond_5
    xor-int/lit8 v0, v2, 0x1

    .line 92
    .line 93
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    const-string v1, "has_share_text"

    .line 98
    .line 99
    new-instance v0, LX/IBK;

    .line 100
    .line 101
    invoke-direct {v0, v1, v2}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    filled-new-array {v5, v4, v3, v0}, [LX/IBK;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-static {v0}, LX/1HA;->A0G([LX/IBK;)Ljava/util/Map;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    const/4 p1, 0x0

    .line 113
    const-string v7, "invite_code_generate"

    .line 114
    .line 115
    const-string v9, "invite_friends"

    .line 116
    .line 117
    const-string v10, "status_check"

    .line 118
    .line 119
    move-object v11, v7

    .line 120
    invoke-virtual/range {v6 .. v13}, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->logEvent(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/analytics/hatch/HatchAppEventLoggingContext;)V

    .line 121
    .line 122
    .line 123
    return-void

    .line 124
    :cond_6
    const-string v0, "error"

    .line 125
    .line 126
    goto :goto_0
.end method

.method public final logInvitePageLoad(Lcom/facebook/aura/activation/data/HatchInvitePage;)V
    .locals 10

    .line 0
    sget-object v4, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->INSTANCE:Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;

    .line 1
    .line 2
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchSurface;->ONBOARDING:Lcom/facebook/aura/analytics/hatch/HatchSurface;

    .line 3
    .line 4
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchSurface;->getValue()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v6

    .line 8
    new-instance v2, LX/Imj;

    .line 9
    .line 10
    invoke-direct {v2}, LX/Imj;-><init>()V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->RESULT:Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/facebook/aura/analytics/hatch/HatchMetadataKey;->getValue()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const/4 v3, 0x0

    .line 20
    if-eqz p1, :cond_7

    .line 21
    .line 22
    const-string v0, "success"

    .line 23
    .line 24
    :goto_0
    invoke-virtual {v2, v1, v0}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 38
    .line 39
    invoke-static {v0}, LX/I1c;->A0c(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const-string v0, "invite_state"

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 52
    .line 53
    if-eqz v0, :cond_1

    .line 54
    .line 55
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    const/4 v0, 0x0

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    :cond_1
    const/4 v0, 0x1

    .line 63
    :cond_2
    xor-int/lit8 v0, v0, 0x1

    .line 64
    .line 65
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const-string v0, "has_code"

    .line 70
    .line 71
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    if-eqz p1, :cond_3

    .line 75
    .line 76
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 77
    .line 78
    if-eqz v0, :cond_3

    .line 79
    .line 80
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    const/4 v0, 0x0

    .line 85
    if-eqz v1, :cond_4

    .line 86
    .line 87
    :cond_3
    const/4 v0, 0x1

    .line 88
    :cond_4
    xor-int/lit8 v0, v0, 0x1

    .line 89
    .line 90
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    const-string v0, "has_invite_link"

    .line 95
    .line 96
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    if-eqz p1, :cond_5

    .line 100
    .line 101
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 102
    .line 103
    if-eqz v0, :cond_5

    .line 104
    .line 105
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_6

    .line 110
    .line 111
    :cond_5
    const/4 v3, 0x1

    .line 112
    :cond_6
    xor-int/lit8 v0, v3, 0x1

    .line 113
    .line 114
    invoke-static {v0}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    const-string v0, "has_share_text"

    .line 119
    .line 120
    invoke-virtual {v2, v0, v1}, LX/Imj;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    invoke-static {v2}, LX/IZe;->A0N(Ljava/util/Map;)LX/Imj;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    const/4 p1, 0x0

    .line 128
    const-string v5, "invite_page_load"

    .line 129
    .line 130
    const-string v7, "invite_friends"

    .line 131
    .line 132
    const-string v8, "status_check"

    .line 133
    .line 134
    move-object v9, v5

    .line 135
    invoke-virtual/range {v4 .. v11}, Lcom/facebook/aura/analytics/hatch/HatchAppEventLogger;->logEvent(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/facebook/aura/analytics/hatch/HatchAppEventLoggingContext;)V

    .line 136
    .line 137
    .line 138
    return-void

    .line 139
    :cond_7
    const-string v0, "error"

    .line 140
    .line 141
    goto :goto_0
.end method

.method public final logTicketCardReveal()V
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/analytics/hatch/HatchComponent;->INVITE_TICKET_CARD:Lcom/facebook/aura/analytics/hatch/HatchComponent;

    .line 1
    .line 2
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/model/HatchInviteLogging;->logSheetClick(Lcom/facebook/aura/analytics/hatch/HatchComponent;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method
