.class public final Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;
.super LX/1EJ;
.source ""


# instance fields
.field public final _uiState:LX/2J2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J2<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

.field public final loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

.field public renderedStoryCardContent:LX/IBK;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/IBK<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final uiState:LX/2J3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation
.end field

.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/AHE;)V
    .locals 16

    .line 0
    const/4 v15, 0x0

    .line 1
    move-object/from16 v2, p2

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    invoke-static {v0, v2}, LX/003;->A1U(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v12

    .line 9
    move-object/from16 v3, p0

    .line 10
    .line 11
    invoke-direct {v3}, LX/1EJ;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 15
    .line 16
    iput-object v2, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->userSession:LX/AHE;

    .line 17
    .line 18
    const/4 v5, 0x0

    .line 19
    new-instance v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 20
    .line 21
    move-object v6, v5

    .line 22
    move-object v7, v5

    .line 23
    move-object v8, v5

    .line 24
    move-object v9, v5

    .line 25
    move-object v10, v5

    .line 26
    move-object v11, v5

    .line 27
    move-object v13, v5

    .line 28
    move-object v14, v5

    .line 29
    move/from16 p0, v12

    .line 30
    .line 31
    move/from16 p1, v15

    .line 32
    .line 33
    move-object/from16 p2, v5

    .line 34
    .line 35
    invoke-direct/range {v4 .. v18}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    new-instance v1, LX/Ddv;

    .line 39
    .line 40
    invoke-direct {v1, v4}, LX/Ddv;-><init>(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iput-object v1, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 44
    .line 45
    new-instance v0, LX/ERk;

    .line 46
    .line 47
    invoke-direct {v0, v5, v1}, LX/ERk;-><init>(LX/Cbu;LX/2J3;)V

    .line 48
    .line 49
    .line 50
    iput-object v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->uiState:LX/2J3;

    .line 51
    .line 52
    sget-object v0, Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;->INSTANCE:Lcom/facebook/aura/common/coroutines/OnDuplicateCall$Join;

    .line 53
    .line 54
    invoke-static {v2, v0, v15}, Lcom/facebook/aura/common/coroutines/SingleFlightKt;->SingleFlight(LX/AHE;Lcom/facebook/aura/common/coroutines/OnDuplicateCall;Z)Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    iput-object v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 59
    .line 60
    return-void
.end method

.method public static final synthetic access$generateInviteCode(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->generateInviteCode(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$getLoadSingleFlight$p(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;)Lcom/facebook/aura/common/coroutines/SingleFlight;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->loadSingleFlight:Lcom/facebook/aura/common/coroutines/SingleFlight;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$getRenderedStoryCardContent$p(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;)LX/IBK;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$get_uiState$p(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;)LX/2J2;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 1
    .line 2
    return-object p0
.end method

.method public static final synthetic access$load(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->load(LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$setRenderedStoryCardContent$p(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/IBK;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 1
    .line 2
    return-void
.end method

.method private final generateInviteCode(LX/2M4;)Ljava/lang/Object;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;

    .line 3
    .line 4
    move-object/from16 v5, p0

    .line 5
    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    move-object v4, v3

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;

    .line 10
    .line 11
    iget v2, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_a

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v3, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;->label:I

    .line 27
    .line 28
    const/4 v1, 0x1

    .line 29
    if-eqz v0, :cond_9

    .line 30
    .line 31
    if-ne v0, v1, :cond_b

    .line 32
    .line 33
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    check-cast v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;

    .line 37
    .line 38
    const/4 v2, 0x0

    .line 39
    const/4 v7, 0x0

    .line 40
    if-eqz v3, :cond_1

    .line 41
    .line 42
    const/4 v7, 0x1

    .line 43
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->code:Ljava/lang/String;

    .line 44
    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    const/4 v0, 0x0

    .line 52
    if-eqz v1, :cond_2

    .line 53
    .line 54
    :cond_1
    const/4 v0, 0x1

    .line 55
    :cond_2
    xor-int/lit8 v6, v0, 0x1

    .line 56
    .line 57
    if-eqz v3, :cond_3

    .line 58
    .line 59
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->inviteLink:Ljava/lang/String;

    .line 60
    .line 61
    if-eqz v0, :cond_3

    .line 62
    .line 63
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    const/4 v0, 0x0

    .line 68
    if-eqz v1, :cond_4

    .line 69
    .line 70
    :cond_3
    const/4 v0, 0x1

    .line 71
    :cond_4
    xor-int/lit8 v4, v0, 0x1

    .line 72
    .line 73
    if-eqz v3, :cond_5

    .line 74
    .line 75
    iget-object v0, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->shareText:Ljava/lang/String;

    .line 76
    .line 77
    if-eqz v0, :cond_5

    .line 78
    .line 79
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_6

    .line 84
    .line 85
    :cond_5
    const/4 v2, 0x1

    .line 86
    :cond_6
    xor-int/lit8 v2, v2, 0x1

    .line 87
    .line 88
    const-string v0, "POST /hatch/invite_code/generate completed resultAvailable="

    .line 89
    .line 90
    new-instance v1, Ljava/lang/StringBuilder;

    .line 91
    .line 92
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    const-string v0, " codeAvailable="

    .line 99
    .line 100
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    const-string v0, " inviteLinkAvailable="

    .line 107
    .line 108
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    const-string v0, " shareTextAvailable="

    .line 115
    .line 116
    invoke-static {v0, v1, v2}, LX/602;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;Z)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    const-string v0, "HatchInviteShare"

    .line 121
    .line 122
    invoke-static {v0, v1}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sget-object v0, Lcom/facebook/aura/activation/model/HatchInviteLogging;->INSTANCE:Lcom/facebook/aura/activation/model/HatchInviteLogging;

    .line 126
    .line 127
    invoke-virtual {v0, v3}, Lcom/facebook/aura/activation/model/HatchInviteLogging;->logInviteCodeGenerate(Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;)V

    .line 128
    .line 129
    .line 130
    if-eqz v3, :cond_8

    .line 131
    .line 132
    iget-object v2, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 133
    .line 134
    :cond_7
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    move-object v4, v1

    .line 139
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 140
    .line 141
    iget-object v8, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->code:Ljava/lang/String;

    .line 142
    .line 143
    iget-object v9, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->inviteLink:Ljava/lang/String;

    .line 144
    .line 145
    iget-object v10, v3, Lcom/facebook/aura/activation/repo/AuraActivationRepository$GenerateInviteCodeResult;->shareText:Ljava/lang/String;

    .line 146
    .line 147
    const/16 p0, 0x3fc7

    .line 148
    .line 149
    const/4 v5, 0x0

    .line 150
    const/4 v12, 0x0

    .line 151
    move-object v6, v5

    .line 152
    move-object v7, v5

    .line 153
    move-object v11, v5

    .line 154
    move-object v13, v5

    .line 155
    move-object v14, v5

    .line 156
    move v15, v12

    .line 157
    move/from16 v16, v12

    .line 158
    .line 159
    move/from16 v17, v12

    .line 160
    .line 161
    move-object/from16 v18, v5

    .line 162
    .line 163
    move-object/from16 p1, v5

    .line 164
    .line 165
    invoke-static/range {v4 .. v20}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->copy$default(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    if-eqz v0, :cond_7

    .line 174
    .line 175
    :cond_8
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 176
    .line 177
    return-object v2

    .line 178
    :cond_9
    invoke-static {v3}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    iget-object v0, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 182
    .line 183
    iput v1, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;->label:I

    .line 184
    .line 185
    invoke-virtual {v0, v4}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->generateInviteCode(LX/2M4;)Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v3

    .line 189
    if-ne v3, v2, :cond_0

    .line 190
    .line 191
    return-object v2

    .line 192
    :cond_a
    new-instance v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;

    .line 193
    .line 194
    invoke-direct {v4, v5, v3}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$generateInviteCode$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V

    .line 195
    .line 196
    .line 197
    goto/16 :goto_0

    .line 198
    .line 199
    :cond_b
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 200
    .line 201
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 202
    .line 203
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    throw v0
.end method

.method private final load(LX/2M4;)Ljava/lang/Object;
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    instance-of v0, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;

    .line 3
    .line 4
    move-object/from16 v3, p0

    .line 5
    .line 6
    if-eqz v0, :cond_10

    .line 7
    .line 8
    move-object v4, v5

    .line 9
    check-cast v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;

    .line 10
    .line 11
    iget v2, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->label:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    and-int v0, v2, v1

    .line 16
    .line 17
    if-eqz v0, :cond_10

    .line 18
    .line 19
    sub-int/2addr v2, v1

    .line 20
    iput v2, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v7, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v0, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->label:I

    .line 27
    .line 28
    const/4 v1, 0x2

    .line 29
    const/4 v8, 0x1

    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    if-eq v0, v8, :cond_4

    .line 33
    .line 34
    if-ne v0, v1, :cond_11

    .line 35
    .line 36
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    iget-object v2, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 40
    .line 41
    :cond_1
    invoke-interface {v2}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    move-object v3, v1

    .line 46
    check-cast v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 47
    .line 48
    iget v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->completedLoads:I

    .line 49
    .line 50
    add-int/lit8 v16, v0, 0x1

    .line 51
    .line 52
    const/16 v18, 0x27ff

    .line 53
    .line 54
    const/4 v4, 0x0

    .line 55
    const/4 v11, 0x0

    .line 56
    move-object v5, v4

    .line 57
    move-object v6, v4

    .line 58
    move-object v7, v4

    .line 59
    move-object v8, v4

    .line 60
    move-object v9, v4

    .line 61
    move-object v10, v4

    .line 62
    move-object v12, v4

    .line 63
    move-object v13, v4

    .line 64
    move v14, v11

    .line 65
    move v15, v11

    .line 66
    move-object/from16 v17, v4

    .line 67
    .line 68
    move-object/from16 v19, v4

    .line 69
    .line 70
    invoke-static/range {v3 .. v19}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->copy$default(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-interface {v2, v1, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_1

    .line 79
    .line 80
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 81
    .line 82
    return-object v2

    .line 83
    :cond_2
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    iget-object v6, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 87
    .line 88
    :cond_3
    invoke-interface {v6}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    move-object v9, v5

    .line 93
    check-cast v9, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 94
    .line 95
    const/16 v24, 0x33ff

    .line 96
    .line 97
    const/4 v10, 0x0

    .line 98
    const/16 v17, 0x0

    .line 99
    .line 100
    move-object v11, v10

    .line 101
    move-object v12, v10

    .line 102
    move-object v13, v10

    .line 103
    move-object v14, v10

    .line 104
    move-object v15, v10

    .line 105
    move-object/from16 v16, v10

    .line 106
    .line 107
    move-object/from16 v18, v10

    .line 108
    .line 109
    move-object/from16 v19, v10

    .line 110
    .line 111
    move/from16 v20, v17

    .line 112
    .line 113
    move/from16 v21, v8

    .line 114
    .line 115
    move/from16 v22, v17

    .line 116
    .line 117
    move-object/from16 v23, v10

    .line 118
    .line 119
    move-object/from16 v25, v10

    .line 120
    .line 121
    invoke-static/range {v9 .. v25}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->copy$default(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-interface {v6, v5, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_3

    .line 130
    .line 131
    iget-object v0, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->activationRepository:Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 132
    .line 133
    iput v8, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->label:I

    .line 134
    .line 135
    invoke-virtual {v0, v4}, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->fetchInvitePage(LX/2M4;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    if-ne v7, v2, :cond_5

    .line 140
    .line 141
    return-object v2

    .line 142
    :cond_4
    invoke-static {v7}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    :cond_5
    check-cast v7, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 146
    .line 147
    const/4 v8, 0x0

    .line 148
    invoke-static {v7}, LX/003;->A1Q(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v12

    .line 152
    const/4 v6, 0x0

    .line 153
    if-eqz v7, :cond_f

    .line 154
    .line 155
    iget-object v11, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 156
    .line 157
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 158
    .line 159
    if-eqz v0, :cond_6

    .line 160
    .line 161
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 162
    .line 163
    .line 164
    move-result v5

    .line 165
    const/4 v0, 0x0

    .line 166
    if-eqz v5, :cond_7

    .line 167
    .line 168
    :cond_6
    :goto_1
    const/4 v0, 0x1

    .line 169
    :cond_7
    xor-int/lit8 v10, v0, 0x1

    .line 170
    .line 171
    if-eqz v7, :cond_8

    .line 172
    .line 173
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 174
    .line 175
    if-eqz v0, :cond_8

    .line 176
    .line 177
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 178
    .line 179
    .line 180
    move-result v5

    .line 181
    const/4 v0, 0x0

    .line 182
    if-eqz v5, :cond_9

    .line 183
    .line 184
    :cond_8
    const/4 v0, 0x1

    .line 185
    :cond_9
    xor-int/lit8 v9, v0, 0x1

    .line 186
    .line 187
    if-eqz v7, :cond_a

    .line 188
    .line 189
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 190
    .line 191
    if-eqz v0, :cond_a

    .line 192
    .line 193
    invoke-static {v0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    if-eqz v0, :cond_b

    .line 198
    .line 199
    :cond_a
    const/4 v8, 0x1

    .line 200
    :cond_b
    xor-int/lit8 v8, v8, 0x1

    .line 201
    .line 202
    const-string v0, "GET /hatch/invite completed resultAvailable="

    .line 203
    .line 204
    new-instance v5, Ljava/lang/StringBuilder;

    .line 205
    .line 206
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    const-string v0, " state="

    .line 213
    .line 214
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    const-string v0, " codeAvailable="

    .line 221
    .line 222
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 223
    .line 224
    .line 225
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 226
    .line 227
    .line 228
    const-string v0, " inviteLinkAvailable="

    .line 229
    .line 230
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 231
    .line 232
    .line 233
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    const-string v0, " shareTextAvailable="

    .line 237
    .line 238
    invoke-static {v0, v5, v8}, LX/602;->A0j(Ljava/lang/String;Ljava/lang/StringBuilder;Z)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v5

    .line 242
    const-string v0, "HatchInviteShare"

    .line 243
    .line 244
    invoke-static {v0, v5}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    sget-object v0, Lcom/facebook/aura/activation/model/HatchInviteLogging;->INSTANCE:Lcom/facebook/aura/activation/model/HatchInviteLogging;

    .line 248
    .line 249
    invoke-virtual {v0, v7}, Lcom/facebook/aura/activation/model/HatchInviteLogging;->logInvitePageLoad(Lcom/facebook/aura/activation/data/HatchInvitePage;)V

    .line 250
    .line 251
    .line 252
    if-eqz v7, :cond_d

    .line 253
    .line 254
    iget-object v8, v3, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->_uiState:LX/2J2;

    .line 255
    .line 256
    :cond_c
    invoke-interface {v8}, LX/2J2;->getValue()Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v9

    .line 260
    move-object v5, v9

    .line 261
    check-cast v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 262
    .line 263
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 264
    .line 265
    move-object/from16 p1, v0

    .line 266
    .line 267
    iget-object v10, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 268
    .line 269
    if-eqz v10, :cond_e

    .line 270
    .line 271
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 272
    .line 273
    if-eqz v0, :cond_e

    .line 274
    .line 275
    :goto_2
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 276
    .line 277
    move-object/from16 p0, v0

    .line 278
    .line 279
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 280
    .line 281
    move-object/from16 v27, v0

    .line 282
    .line 283
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 284
    .line 285
    move-object/from16 v26, v0

    .line 286
    .line 287
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 288
    .line 289
    move-object/from16 v25, v0

    .line 290
    .line 291
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 292
    .line 293
    move-object/from16 v17, v0

    .line 294
    .line 295
    iget-boolean v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 296
    .line 297
    move/from16 v16, v0

    .line 298
    .line 299
    iget-object v15, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 300
    .line 301
    iget-object v14, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 302
    .line 303
    iget-boolean v13, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 304
    .line 305
    iget-boolean v12, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->isLoading:Z

    .line 306
    .line 307
    iget v11, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->completedLoads:I

    .line 308
    .line 309
    iget-object v5, v5, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;->storyCardUri:Ljava/lang/String;

    .line 310
    .line 311
    new-instance v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;

    .line 312
    .line 313
    move/from16 v18, v16

    .line 314
    .line 315
    move-object/from16 v19, v15

    .line 316
    .line 317
    move-object/from16 v20, v14

    .line 318
    .line 319
    move/from16 v21, v13

    .line 320
    .line 321
    move/from16 v22, v12

    .line 322
    .line 323
    move/from16 v23, v11

    .line 324
    .line 325
    move-object/from16 v24, v5

    .line 326
    .line 327
    move-object/from16 v11, p1

    .line 328
    .line 329
    move-object v12, v10

    .line 330
    move-object/from16 v13, p0

    .line 331
    .line 332
    move-object/from16 v14, v27

    .line 333
    .line 334
    move-object/from16 v15, v26

    .line 335
    .line 336
    move-object/from16 v16, v25

    .line 337
    .line 338
    move-object v10, v0

    .line 339
    invoke-direct/range {v10 .. v24}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;ZZILjava/lang/String;)V

    .line 340
    .line 341
    .line 342
    invoke-interface {v8, v9, v0}, LX/2J2;->A6i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 343
    .line 344
    .line 345
    move-result v0

    .line 346
    if-eqz v0, :cond_c

    .line 347
    .line 348
    iget-object v0, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 349
    .line 350
    if-nez v0, :cond_0

    .line 351
    .line 352
    iget-object v5, v7, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 353
    .line 354
    sget-object v0, Lcom/facebook/aura/activation/data/HatchInviteState;->ELIGIBLE:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 355
    .line 356
    if-ne v5, v0, :cond_0

    .line 357
    .line 358
    :cond_d
    iput-object v6, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->L$0:Ljava/lang/Object;

    .line 359
    .line 360
    iput v1, v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;->label:I

    .line 361
    .line 362
    invoke-direct {v3, v4}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->generateInviteCode(LX/2M4;)Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object v0

    .line 366
    if-ne v0, v2, :cond_0

    .line 367
    .line 368
    return-object v2

    .line 369
    :cond_e
    move-object v10, v6

    .line 370
    goto :goto_2

    .line 371
    :cond_f
    move-object v11, v6

    .line 372
    goto/16 :goto_1

    .line 373
    .line 374
    :cond_10
    new-instance v4, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;

    .line 375
    .line 376
    invoke-direct {v4, v3, v5}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$load$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V

    .line 377
    .line 378
    .line 379
    goto/16 :goto_0

    .line 380
    .line 381
    :cond_11
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 382
    .line 383
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 384
    .line 385
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 386
    .line 387
    .line 388
    throw v0
.end method


# virtual methods
.method public final getUiState()LX/2J3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/2J3<",
            "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$UiState;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->uiState:LX/2J3;

    .line 1
    .line 2
    return-object p0
.end method

.method public final refresh()V
    .locals 4

    .line 0
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 1
    .line 2
    .line 3
    move-result-object v3

    .line 4
    sget-object v0, Lcom/facebook/aura/executors/AuraDispatchers;->INSTANCE:Lcom/facebook/aura/executors/AuraDispatchers;

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/aura/executors/AuraDispatchers;->io()LX/BqD;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    const/4 v0, 0x0

    .line 11
    new-instance v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1;

    .line 12
    .line 13
    invoke-direct {v1, p0, v0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$refresh$1;-><init>(Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/2M4;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, LX/FkO;->A00:Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-static {v0, v2, v1, v3}, LX/DRD;->A02(Ljava/lang/Integer;LX/BqD;LX/JDN;LX/1EL;)LX/ESp;

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final renderStoryCard(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 0
    move-object v2, p1

    .line 1
    move-object v3, p2

    .line 2
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    new-instance p1, LX/IBK;

    .line 6
    .line 7
    move-object v4, p3

    .line 8
    invoke-direct {p1, p2, p3}, LX/IBK;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 12
    .line 13
    invoke-static {v0, p1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;->renderedStoryCardContent:LX/IBK;

    .line 20
    .line 21
    invoke-static {p0}, LX/2N7;->A00(LX/1EJ;)LX/ERX;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const/4 p2, 0x0

    .line 26
    new-instance v1, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;

    .line 27
    .line 28
    invoke-direct/range {v1 .. v7}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$renderStoryCard$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;LX/IBK;LX/2M4;)V

    .line 29
    .line 30
    .line 31
    invoke-static {v1, v0}, LX/002;->A1Q(LX/JDN;LX/1EL;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void
.end method
