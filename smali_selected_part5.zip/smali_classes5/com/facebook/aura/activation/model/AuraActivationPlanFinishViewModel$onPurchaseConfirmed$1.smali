.class public final Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1"
    f = "AuraActivationPlanFinishViewModel.kt"
    l = {
        0x72,
        0x73,
        0x77
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

.field public final synthetic $fallbackDisclosureText:Ljava/lang/String;

.field public final synthetic $usesConfidentialVm:Z

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;


# direct methods
.method public constructor <init>(ZLcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;",
            "Lcom/facebook/aura/activation/data/HatchTosMetadata;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-boolean p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$usesConfidentialVm:Z

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 3
    .line 4
    iput-object p3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p5}, LX/DRu;-><init>(ILX/2M4;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-boolean v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$usesConfidentialVm:Z

    .line 1
    .line 2
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 3
    .line 4
    iget-object v3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 5
    .line 6
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 7
    .line 8
    new-instance v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;

    .line 9
    .line 10
    move-object p1, p2

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;-><init>(ZLcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->label:I

    .line 3
    .line 4
    const/4 v4, 0x3

    .line 5
    const/4 v6, 0x2

    .line 6
    const/4 v5, 0x1

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-eq v0, v5, :cond_4

    .line 10
    .line 11
    if-eq v0, v6, :cond_1

    .line 12
    .line 13
    if-ne v0, v4, :cond_9

    .line 14
    .line 15
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    return-object v3

    .line 21
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_2
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$usesConfidentialVm:Z

    .line 29
    .line 30
    if-nez v0, :cond_3

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 33
    .line 34
    iget-object v1, v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->setupGate:Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;

    .line 35
    .line 36
    sget-object v0, Lcom/facebook/aura/gateway/HatchlingVmType;->HATCH_VM:Lcom/facebook/aura/gateway/HatchlingVmType;

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Lcom/facebook/aura/confidentialvm/api/access/ConfidentialVmSetupGate;->markSelected(Lcom/facebook/aura/gateway/HatchlingVmType;)Z

    .line 39
    .line 40
    .line 41
    :cond_3
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 42
    .line 43
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$displayedTosMetadata:Lcom/facebook/aura/activation/data/HatchTosMetadata;

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$fallbackDisclosureText:Ljava/lang/String;

    .line 46
    .line 47
    iput v5, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->label:I

    .line 48
    .line 49
    invoke-static {v2, v1, v0, p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->access$acceptTerms(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/data/HatchTosMetadata;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-ne p1, v3, :cond_5

    .line 54
    .line 55
    return-object v3

    .line 56
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_5
    check-cast p1, Ljava/lang/Boolean;

    .line 60
    .line 61
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-nez v0, :cond_7

    .line 66
    .line 67
    sget-object p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$TermsFailed;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$TermsFailed;

    .line 68
    .line 69
    :cond_6
    :goto_0
    check-cast p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 72
    .line 73
    invoke-static {v0, p1}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->access$logConfidentialVmOfferError(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;)V

    .line 74
    .line 75
    .line 76
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 77
    .line 78
    iget-object v1, v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_viewEffects:LX/EYl;

    .line 79
    .line 80
    const/4 v0, 0x0

    .line 81
    iput-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->L$0:Ljava/lang/Object;

    .line 82
    .line 83
    iput v4, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->label:I

    .line 84
    .line 85
    invoke-interface {v1, p1, p0}, LX/Dn5;->Acx(Ljava/lang/Object;LX/2M4;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    if-ne v0, v3, :cond_0

    .line 90
    .line 91
    return-object v3

    .line 92
    :cond_7
    iget-boolean v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->$usesConfidentialVm:Z

    .line 93
    .line 94
    if-eqz v0, :cond_8

    .line 95
    .line 96
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 97
    .line 98
    iput v6, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$onPurchaseConfirmed$1;->label:I

    .line 99
    .line 100
    invoke-static {v0, p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->access$resolveConfidentialVmEffect(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    if-ne p1, v3, :cond_6

    .line 105
    .line 106
    return-object v3

    .line 107
    :cond_8
    sget-object p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$Finished;->INSTANCE:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect$Finished;

    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_9
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 111
    .line 112
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 113
    .line 114
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw v0
.end method
