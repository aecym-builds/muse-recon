.class public final Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.model.AuraActivationPlanFinishViewModel$loadPage$1"
    f = "AuraActivationPlanFinishViewModel.kt"
    l = {
        0x57
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 1
    .line 2
    const/4 v0, 0x2

    .line 3
    invoke-direct {p0, v0, p2}, LX/DRu;-><init>(ILX/2M4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 1
    .line 2
    new-instance p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;

    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    return-object p0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 1
    .line 2
    new-instance p1, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;

    .line 3
    .line 4
    invoke-direct {p1, p0, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;-><init>(Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;LX/2M4;)V

    .line 5
    .line 6
    .line 7
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->label:I

    .line 3
    .line 4
    const/4 v3, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    if-ne v0, v3, :cond_5

    .line 8
    .line 9
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    instance-of v0, p1, Lcom/facebook/aura/subscription/repo/SubscriptionDetailsState$Success;

    .line 13
    .line 14
    if-eqz v0, :cond_3

    .line 15
    .line 16
    check-cast p1, Lcom/facebook/aura/subscription/repo/SubscriptionDetailsState$Success;

    .line 17
    .line 18
    :goto_0
    iget-object v2, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 19
    .line 20
    iget-object v1, v2, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->_page:LX/2J2;

    .line 21
    .line 22
    if-nez p1, :cond_1

    .line 23
    .line 24
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->LOAD_FAILED:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 25
    .line 26
    :goto_1
    invoke-static {v1, v0}, LX/003;->A18(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_1
    iget-object v0, p1, Lcom/facebook/aura/subscription/repo/SubscriptionDetailsState$Success;->details:Lcom/facebook/aura/subscription/repo/SubscriptionDetails;

    .line 33
    .line 34
    iget-boolean v0, v0, Lcom/facebook/aura/subscription/repo/SubscriptionDetails;->isPaidTier:Z

    .line 35
    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    iget-object v0, v2, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->viewerDataProvider:Lcom/facebook/aura/user/provider/AuraViewerDataProvider;

    .line 39
    .line 40
    iget-object v0, v0, Lcom/facebook/aura/user/provider/AuraViewerDataProvider;->userData:LX/2J3;

    .line 41
    .line 42
    invoke-interface {v0}, LX/2J3;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Lcom/facebook/aura/user/provider/AuraUserData;

    .line 47
    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    iget-object v0, v0, Lcom/facebook/aura/user/provider/AuraUserData;->isVmTypeSelectionRequired:Ljava/lang/Boolean;

    .line 51
    .line 52
    invoke-static {v0, v3}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->CONFIDENTIAL_VM_OFFER:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;->PLANS:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$Page;

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_3
    const/4 p1, 0x0

    .line 65
    goto :goto_0

    .line 66
    :cond_4
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->this$0:Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;

    .line 70
    .line 71
    iget-object v0, v0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel;->subscriptionRepository:Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;

    .line 72
    .line 73
    iput v3, p0, Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$loadPage$1;->label:I

    .line 74
    .line 75
    invoke-virtual {v0, p0}, Lcom/facebook/aura/subscription/repo/AuraSubscriptionRepository;->fetchSubscriptionDetailsState(LX/2M4;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    if-ne p1, v1, :cond_0

    .line 80
    .line 81
    return-object v1

    .line 82
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 83
    .line 84
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 85
    .line 86
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    throw v0
.end method
