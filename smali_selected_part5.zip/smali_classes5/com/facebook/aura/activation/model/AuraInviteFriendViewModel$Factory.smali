.class public final Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;
.super Lcom/facebook/aura/common/mvvm/AuraViewModelFactory;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/aura/common/mvvm/AuraViewModelFactory<",
        "Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;",
        ">;"
    }
.end annotation


# instance fields
.field public final userSession:LX/AHE;


# direct methods
.method public constructor <init>(LX/AHE;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;->userSession:LX/AHE;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public bridge synthetic create()LX/1EJ;
    .locals 0

    .line 268435456
    invoke-virtual {p0}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;->create()Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public create()Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;
    .locals 3

    .line 0
    sget-object v1, Lcom/facebook/aura/activation/repo/AuraActivationRepository;->Companion:Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;

    .line 1
    .line 2
    iget-object v0, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;->userSession:LX/AHE;

    .line 3
    .line 4
    invoke-virtual {v1, v0}, Lcom/facebook/aura/activation/repo/AuraActivationRepository$Companion;->getInstance(LX/AHE;)Lcom/facebook/aura/activation/repo/AuraActivationRepository;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    iget-object v1, p0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel$Factory;->userSession:LX/AHE;

    .line 9
    .line 10
    new-instance v0, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;

    .line 11
    .line 12
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/model/AuraInviteFriendViewModel;-><init>(Lcom/facebook/aura/activation/repo/AuraActivationRepository;LX/AHE;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method
