.class public abstract Lcom/facebook/aura/activation/model/AuraInviteFriendViewModelKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INVITE_SHARE_TAG:Ljava/lang/String; = "HatchInviteShare"
