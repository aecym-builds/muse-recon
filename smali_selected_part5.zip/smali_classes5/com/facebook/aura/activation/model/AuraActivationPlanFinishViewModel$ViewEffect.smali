.class public interface abstract Lcom/facebook/aura/activation/model/AuraActivationPlanFinishViewModel$ViewEffect;
.super Ljava/lang/Object;
.source ""
