.class public final Lcom/facebook/aura/activation/data/HatchInvitePage;
.super LX/07H;
.source ""


# instance fields
.field public final code:Ljava/lang/String;

.field public final giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

.field public final hasRedeemedInviteCode:Z

.field public final inviteLink:Ljava/lang/String;

.field public final redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

.field public final redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

.field public final reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

.field public final shareText:Ljava/lang/String;

.field public final showRedeemButton:Z

.field public final showsGift:Z

.field public final state:Lcom/facebook/aura/activation/data/HatchInviteState;

.field public final storyShareText:Ljava/lang/String;

.field public final subtitle:Ljava/lang/String;

.field public final subtitleLinkText:Ljava/lang/String;

.field public final subtitleLinkUrl:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p4, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 10
    .line 11
    iput-boolean p5, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 12
    .line 13
    iput-boolean p6, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 14
    .line 15
    iput-object p7, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 16
    .line 17
    iput-object p8, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p9, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p10, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 22
    .line 23
    iput-boolean p11, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 24
    .line 25
    iput-object p12, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 26
    .line 27
    iput-object p13, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 28
    .line 29
    iput-object p14, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 30
    .line 31
    iput-object p15, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 32
    .line 33
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/data/HatchInvitePage;Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;ILjava/lang/Object;)Lcom/facebook/aura/activation/data/HatchInvitePage;
    .locals 30

    .line 0
    move-object/from16 v16, p2

    .line 1
    .line 2
    move-object/from16 v14, p3

    .line 3
    .line 4
    move-object/from16 v13, p4

    .line 5
    .line 6
    move/from16 v12, p5

    .line 7
    .line 8
    move/from16 v11, p6

    .line 9
    .line 10
    move-object/from16 v10, p7

    .line 11
    .line 12
    move-object/from16 v9, p8

    .line 13
    .line 14
    move-object/from16 v8, p9

    .line 15
    .line 16
    move-object/from16 v7, p10

    .line 17
    .line 18
    move/from16 v6, p11

    .line 19
    .line 20
    move-object/from16 v5, p12

    .line 21
    .line 22
    move-object/from16 v4, p13

    .line 23
    .line 24
    move-object/from16 v3, p14

    .line 25
    .line 26
    move/from16 v2, p16

    .line 27
    .line 28
    move-object/from16 v1, p15

    .line 29
    .line 30
    and-int/lit8 v0, p16, 0x1

    .line 31
    .line 32
    move-object/from16 v15, p0

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v0, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 37
    .line 38
    move-object/from16 p1, v0

    .line 39
    .line 40
    :cond_0
    and-int/lit8 v0, p16, 0x2

    .line 41
    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    iget-object v0, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 45
    .line 46
    move-object/from16 v16, v0

    .line 47
    .line 48
    :cond_1
    and-int/lit8 v0, p16, 0x4

    .line 49
    .line 50
    if-eqz v0, :cond_2

    .line 51
    .line 52
    iget-object v14, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 53
    .line 54
    :cond_2
    and-int/lit8 v0, p16, 0x8

    .line 55
    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    iget-object v13, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 59
    .line 60
    :cond_3
    and-int/lit8 v0, p16, 0x10

    .line 61
    .line 62
    if-eqz v0, :cond_4

    .line 63
    .line 64
    iget-boolean v12, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 65
    .line 66
    :cond_4
    and-int/lit8 v0, p16, 0x20

    .line 67
    .line 68
    if-eqz v0, :cond_5

    .line 69
    .line 70
    iget-boolean v11, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 71
    .line 72
    :cond_5
    and-int/lit8 v0, p16, 0x40

    .line 73
    .line 74
    if-eqz v0, :cond_6

    .line 75
    .line 76
    iget-object v10, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 77
    .line 78
    :cond_6
    and-int/lit16 v0, v2, 0x80

    .line 79
    .line 80
    if-eqz v0, :cond_7

    .line 81
    .line 82
    iget-object v9, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 83
    .line 84
    :cond_7
    and-int/lit16 v0, v2, 0x100

    .line 85
    .line 86
    if-eqz v0, :cond_8

    .line 87
    .line 88
    iget-object v8, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 89
    .line 90
    :cond_8
    and-int/lit16 v0, v2, 0x200

    .line 91
    .line 92
    if-eqz v0, :cond_9

    .line 93
    .line 94
    iget-object v7, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 95
    .line 96
    :cond_9
    and-int/lit16 v0, v2, 0x400

    .line 97
    .line 98
    if-eqz v0, :cond_a

    .line 99
    .line 100
    iget-boolean v6, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 101
    .line 102
    :cond_a
    and-int/lit16 v0, v2, 0x800

    .line 103
    .line 104
    if-eqz v0, :cond_b

    .line 105
    .line 106
    iget-object v5, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 107
    .line 108
    :cond_b
    and-int/lit16 v0, v2, 0x1000

    .line 109
    .line 110
    if-eqz v0, :cond_c

    .line 111
    .line 112
    iget-object v4, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 113
    .line 114
    :cond_c
    and-int/lit16 v0, v2, 0x2000

    .line 115
    .line 116
    if-eqz v0, :cond_d

    .line 117
    .line 118
    iget-object v3, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 119
    .line 120
    :cond_d
    and-int/lit16 v0, v2, 0x4000

    .line 121
    .line 122
    if-eqz v0, :cond_e

    .line 123
    .line 124
    iget-object v1, v15, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 125
    .line 126
    :cond_e
    new-instance v15, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 127
    .line 128
    move-object/from16 v29, v3

    .line 129
    .line 130
    move-object/from16 p0, v1

    .line 131
    .line 132
    move/from16 v26, v6

    .line 133
    .line 134
    move-object/from16 v27, v5

    .line 135
    .line 136
    move-object/from16 v28, v4

    .line 137
    .line 138
    move-object/from16 v23, v9

    .line 139
    .line 140
    move-object/from16 v24, v8

    .line 141
    .line 142
    move-object/from16 v25, v7

    .line 143
    .line 144
    move/from16 v20, v12

    .line 145
    .line 146
    move/from16 v21, v11

    .line 147
    .line 148
    move-object/from16 v22, v10

    .line 149
    .line 150
    move-object/from16 v17, v16

    .line 151
    .line 152
    move-object/from16 v18, v14

    .line 153
    .line 154
    move-object/from16 v19, v13

    .line 155
    .line 156
    move-object/from16 v16, p1

    .line 157
    .line 158
    invoke-direct/range {v15 .. v30}, Lcom/facebook/aura/activation/data/HatchInvitePage;-><init>(Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 159
    .line 160
    .line 161
    return-object v15
.end method


# virtual methods
.method public final component1()Lcom/facebook/aura/activation/data/HatchInviteState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component12()Lcom/facebook/aura/activation/data/HatchInviteReward;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component13()Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component14()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component15()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component6()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 1
    .line 2
    return p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)Lcom/facebook/aura/activation/data/HatchInvitePage;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 1
    .line 2
    invoke-direct/range {p0 .. p15}, Lcom/facebook/aura/activation/data/HatchInvitePage;-><init>(Lcom/facebook/aura/activation/data/HatchInviteState;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/facebook/aura/activation/data/HatchInviteReward;Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/data/HatchInvitePage;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    iget-boolean v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 47
    .line 48
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 49
    .line 50
    if-ne v1, v0, :cond_0

    .line 51
    .line 52
    iget-boolean v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 53
    .line 54
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 55
    .line 56
    if-ne v1, v0, :cond_0

    .line 57
    .line 58
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 59
    .line 60
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_0

    .line 67
    .line 68
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 69
    .line 70
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 71
    .line 72
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_0

    .line 77
    .line 78
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 79
    .line 80
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 81
    .line 82
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_0

    .line 87
    .line 88
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 89
    .line 90
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_0

    .line 97
    .line 98
    iget-boolean v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 99
    .line 100
    iget-boolean v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 101
    .line 102
    if-ne v1, v0, :cond_0

    .line 103
    .line 104
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 105
    .line 106
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 107
    .line 108
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    if-eqz v0, :cond_0

    .line 113
    .line 114
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 115
    .line 116
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 117
    .line 118
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_0

    .line 123
    .line 124
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 125
    .line 126
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 127
    .line 128
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-eqz v0, :cond_0

    .line 133
    .line 134
    iget-object v1, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 135
    .line 136
    iget-object v0, p1, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 137
    .line 138
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    if-nez v0, :cond_1

    .line 143
    .line 144
    :cond_0
    return v2

    .line 145
    :cond_1
    return v3
.end method

.method public final getCode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getGiftVideo()Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getHasRedeemedInviteCode()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getInviteLink()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRedeemScreen()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getRedeemSuccessScreen()Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReward()Lcom/facebook/aura/activation/data/HatchInviteReward;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShareText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getShowRedeemButton()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getShowsGift()Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 1
    .line 2
    return p0
.end method

.method public final getState()Lcom/facebook/aura/activation/data/HatchInviteState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getStoryShareText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitleLinkText()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitleLinkUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->state:Lcom/facebook/aura/activation/data/HatchInviteState;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitle:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkText:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->subtitleLinkUrl:Ljava/lang/String;

    .line 28
    .line 29
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-boolean v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->hasRedeemedInviteCode:Z

    .line 37
    .line 38
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-boolean v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showRedeemButton:Z

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->code:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    add-int/2addr v1, v0

    .line 55
    mul-int/lit8 v1, v1, 0x1f

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->inviteLink:Ljava/lang/String;

    .line 58
    .line 59
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    add-int/2addr v1, v0

    .line 64
    mul-int/lit8 v1, v1, 0x1f

    .line 65
    .line 66
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->shareText:Ljava/lang/String;

    .line 67
    .line 68
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    add-int/2addr v1, v0

    .line 73
    mul-int/lit8 v1, v1, 0x1f

    .line 74
    .line 75
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->storyShareText:Ljava/lang/String;

    .line 76
    .line 77
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    add-int/2addr v1, v0

    .line 82
    mul-int/lit8 v1, v1, 0x1f

    .line 83
    .line 84
    iget-boolean v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->showsGift:Z

    .line 85
    .line 86
    invoke-static {v1, v0}, LX/07F;->A01(IZ)I

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->reward:Lcom/facebook/aura/activation/data/HatchInviteReward;

    .line 91
    .line 92
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    add-int/2addr v1, v0

    .line 97
    mul-int/lit8 v1, v1, 0x1f

    .line 98
    .line 99
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->giftVideo:Lcom/facebook/aura/activation/data/HatchInviteGiftVideo;

    .line 100
    .line 101
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    add-int/2addr v1, v0

    .line 106
    mul-int/lit8 v1, v1, 0x1f

    .line 107
    .line 108
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeCopy;

    .line 109
    .line 110
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    add-int/2addr v1, v0

    .line 115
    mul-int/lit8 v1, v1, 0x1f

    .line 116
    .line 117
    iget-object v0, p0, Lcom/facebook/aura/activation/data/HatchInvitePage;->redeemSuccessScreen:Lcom/facebook/aura/activation/data/HatchRedeemInviteCodeSuccessCopy;

    .line 118
    .line 119
    if-eqz v0, :cond_0

    .line 120
    .line 121
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    :cond_0
    add-int/2addr v1, v2

    .line 126
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
