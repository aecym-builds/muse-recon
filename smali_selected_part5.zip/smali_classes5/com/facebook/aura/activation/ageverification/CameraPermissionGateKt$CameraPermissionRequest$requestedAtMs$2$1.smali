.class public final Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;
.super LX/DRv;
.source ""

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRv;",
        "Lkotlin/jvm/functions/Function0<",
        "LX/2kB;",
        ">;"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;

    .line 1
    .line 2
    invoke-direct {v0}, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/CameraPermissionGateKt$CameraPermissionRequest$requestedAtMs$2$1;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, LX/DRv;-><init>(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final invoke()LX/2kB;
    .locals 2

    .line 0
    const-wide/16 v1, 0x0

    .line 1
    .line 2
    new-instance v0, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 3
    .line 4
    invoke-direct {v0, v1, p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;-><init>(J)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 2

    .line 268435456
    const-wide/16 v1, 0x0

    .line 268435457
    .line 268435458
    new-instance v0, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 268435459
    .line 268435460
    invoke-direct {v0, v1, p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;-><init>(J)V

    .line 268435461
    .line 268435462
    .line 268435463
    return-object v0
.end method
