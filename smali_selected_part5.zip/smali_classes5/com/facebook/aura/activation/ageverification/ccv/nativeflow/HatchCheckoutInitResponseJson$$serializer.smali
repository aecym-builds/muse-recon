.class public final synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutInitResponseJson"

    .line 10
    .line 11
    new-instance v2, LX/DZp;

    .line 12
    .line 13
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "order_id"

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "ecp_checkout_session_id"

    .line 23
    .line 24
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "payment_container_mode"

    .line 28
    .line 29
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "components"

    .line 33
    .line 34
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "ccv_screen_content"

    .line 38
    .line 39
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "checkout_button_label"

    .line 43
    .line 44
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    const-string v0, "currency_amount"

    .line 48
    .line 49
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    const-string v0, "verification_purpose"

    .line 53
    .line 54
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->descriptor:LX/Da5;

    .line 58
    .line 59
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 3
    .line 4
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    invoke-static {v0}, LX/3Rq;->A1N([Lkotlin/Lazy;)LX/DZ7;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;

    .line 21
    .line 22
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v6

    .line 26
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 27
    .line 28
    .line 29
    move-result-object v7

    .line 30
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;

    .line 31
    .line 32
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 33
    .line 34
    .line 35
    move-result-object v8

    .line 36
    invoke-static {v1}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    filled-new-array/range {v2 .. v9}, [LX/DZ7;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;
    .locals 18

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v5}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    sget-object v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 13
    .line 14
    const/4 v8, 0x7

    .line 15
    const/4 v3, 0x6

    .line 16
    const/4 v2, 0x5

    .line 17
    const/4 v11, 0x0

    .line 18
    move-object/from16 v17, v11

    .line 19
    .line 20
    move-object/from16 p0, v11

    .line 21
    .line 22
    move-object/from16 v16, v11

    .line 23
    .line 24
    move-object v15, v11

    .line 25
    move-object v12, v11

    .line 26
    move-object v13, v11

    .line 27
    move-object v14, v11

    .line 28
    const/4 v10, 0x0

    .line 29
    const/4 v1, 0x3

    .line 30
    :goto_0
    invoke-interface {v4, v5}, LX/Da7;->A8S(LX/Da5;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 38
    .line 39
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 40
    .line 41
    .line 42
    throw v1

    .line 43
    :pswitch_0
    invoke-static {v5, v4, v8}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    or-int/lit16 v10, v10, 0x80

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :pswitch_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;

    .line 51
    .line 52
    invoke-interface {v4, v0, v5, v3}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v17

    .line 56
    check-cast v17, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 57
    .line 58
    or-int/lit8 v10, v10, 0x40

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :pswitch_2
    invoke-static {v5, v4, v2}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v16

    .line 65
    or-int/lit8 v10, v10, 0x20

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :pswitch_3
    sget-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;

    .line 69
    .line 70
    const/4 v0, 0x4

    .line 71
    invoke-interface {v4, v7, v5, v0}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v15

    .line 75
    check-cast v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 76
    .line 77
    or-int/lit8 v10, v10, 0x10

    .line 78
    .line 79
    goto :goto_0

    .line 80
    :pswitch_4
    invoke-static {v5, v4, v9, v1}, LX/3Rs;->A0j(LX/Da5;LX/Da7;[Lkotlin/Lazy;I)Ljava/util/List;

    .line 81
    .line 82
    .line 83
    move-result-object v14

    .line 84
    or-int/lit8 v10, v10, 0x8

    .line 85
    .line 86
    goto :goto_0

    .line 87
    :pswitch_5
    invoke-static {v5, v4}, LX/3Rs;->A0U(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v13

    .line 91
    or-int/lit8 v10, v10, 0x4

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :pswitch_6
    invoke-static {v5, v4}, LX/3Rs;->A0T(LX/Da5;LX/Da7;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v12

    .line 98
    or-int/lit8 v10, v10, 0x2

    .line 99
    .line 100
    goto :goto_0

    .line 101
    :pswitch_7
    invoke-static {v5, v4, v6}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v11

    .line 105
    or-int/lit8 v10, v10, 0x1

    .line 106
    .line 107
    goto :goto_0

    .line 108
    :pswitch_8
    invoke-interface {v4, v5}, LX/Da7;->AAi(LX/Da5;)V

    .line 109
    .line 110
    .line 111
    const/16 p1, 0x0

    .line 112
    .line 113
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 114
    .line 115
    invoke-direct/range {v9 .. v19}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;LX/5Xm;)V

    .line 116
    .line 117
    .line 118
    return-object v9

    .line 119
    nop

    .line 120
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
