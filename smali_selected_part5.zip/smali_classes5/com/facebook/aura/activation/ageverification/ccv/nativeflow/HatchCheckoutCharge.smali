.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final amount:Ljava/lang/String;

.field public final billingCountry:Ljava/lang/String;

.field public final credentialId:Ljava/lang/String;

.field public final currency:Ljava/lang/String;

.field public final platformTrustToken:Ljava/lang/String;

.field public final session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    const/4 v0, 0x5

    .line 4
    invoke-static {p6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 11
    .line 12
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->credentialId:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->platformTrustToken:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->amount:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->currency:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->billingCountry:Ljava/lang/String;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final getAmount$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getBillingCountry$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->billingCountry:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCredentialId$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->credentialId:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->currency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlatformTrustToken$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->platformTrustToken:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSession$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 1
    .line 2
    return-object p0
.end method
