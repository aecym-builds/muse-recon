.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion;


# instance fields
.field public final ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

.field public final checkout_button_label:Ljava/lang/String;

.field public final components:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;"
        }
    .end annotation
.end field

.field public final currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

.field public final ecp_checkout_session_id:Ljava/lang/String;

.field public final order_id:Ljava/lang/String;

.field public final payment_container_mode:Ljava/lang/String;

.field public final verification_purpose:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v5

    .line 16
    move-object v3, v2

    .line 17
    move-object v4, v2

    .line 18
    move-object v6, v2

    .line 19
    move-object v7, v2

    .line 20
    move-object v8, v2

    .line 21
    move-object v9, v2

    .line 22
    filled-new-array/range {v2 .. v9}, [Lkotlin/Lazy;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 27
    .line 28
    return-void
.end method

.method public constructor <init>()V
    .locals 8

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v4, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    move-object v0, p0

    .line 805306372
    move-object v2, v1

    .line 805306373
    move-object v3, v1

    .line 805306374
    move-object v5, v1

    .line 805306375
    move-object v6, v1

    .line 805306376
    move-object v7, v1

    .line 805306377
    move-object p0, v1

    .line 805306378
    invoke-direct/range {v0 .. v8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)V

    .line 805306379
    .line 805306380
    .line 805306381
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    const/4 v1, 0x0

    .line 536870918
    if-nez v0, :cond_6

    .line 536870919
    .line 536870920
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 536870921
    .line 536870922
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 536870923
    .line 536870924
    if-nez v0, :cond_5

    .line 536870925
    .line 536870926
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 536870927
    .line 536870928
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 536870929
    .line 536870930
    if-nez v0, :cond_4

    .line 536870931
    .line 536870932
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 536870933
    .line 536870934
    :goto_2
    and-int/lit8 v0, p1, 0x8

    .line 536870935
    .line 536870936
    if-nez v0, :cond_3

    .line 536870937
    .line 536870938
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 536870939
    .line 536870940
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 536870941
    .line 536870942
    :goto_3
    and-int/lit8 v0, p1, 0x10

    .line 536870943
    .line 536870944
    if-nez v0, :cond_2

    .line 536870945
    .line 536870946
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 536870947
    .line 536870948
    :goto_4
    and-int/lit8 v0, p1, 0x20

    .line 536870949
    .line 536870950
    if-nez v0, :cond_1

    .line 536870951
    .line 536870952
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 536870953
    .line 536870954
    :goto_5
    and-int/lit8 v0, p1, 0x40

    .line 536870955
    .line 536870956
    if-nez v0, :cond_0

    .line 536870957
    .line 536870958
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 536870959
    .line 536870960
    :goto_6
    and-int/lit16 v0, p1, 0x80

    .line 536870961
    .line 536870962
    if-nez v0, :cond_7

    .line 536870963
    .line 536870964
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 536870965
    .line 536870966
    return-void

    .line 536870967
    :cond_0
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 536870968
    .line 536870969
    goto :goto_6

    .line 536870970
    :cond_1
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 536870971
    .line 536870972
    goto :goto_5

    .line 536870973
    :cond_2
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 536870974
    .line 536870975
    goto :goto_4

    .line 536870976
    :cond_3
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 536870977
    .line 536870978
    goto :goto_3

    .line 536870979
    :cond_4
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 536870980
    .line 536870981
    goto :goto_2

    .line 536870982
    :cond_5
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 536870983
    .line 536870984
    goto :goto_1

    .line 536870985
    :cond_6
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 536870986
    .line 536870987
    goto :goto_0

    .line 536870988
    :cond_7
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 536870989
    .line 536870990
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x3

    .line 1
    invoke-static {p4, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 14
    .line 15
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 16
    .line 17
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 20
    .line 21
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 22
    .line 23
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p9, 0x1

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p1, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p2, v1

    .line 268435467
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p3, v1

    .line 268435472
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 268435473
    .line 268435474
    if-eqz v0, :cond_3

    .line 268435475
    .line 268435476
    sget-object p4, LX/0wV;->A00:LX/0wV;

    .line 268435477
    .line 268435478
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 268435479
    .line 268435480
    if-eqz v0, :cond_4

    .line 268435481
    .line 268435482
    move-object p5, v1

    .line 268435483
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 268435484
    .line 268435485
    if-eqz v0, :cond_5

    .line 268435486
    .line 268435487
    move-object p6, v1

    .line 268435488
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 268435489
    .line 268435490
    if-eqz v0, :cond_6

    .line 268435491
    .line 268435492
    move-object p7, v1

    .line 268435493
    :cond_6
    and-int/lit16 v0, p9, 0x80

    .line 268435494
    .line 268435495
    if-eqz v0, :cond_7

    .line 268435496
    .line 268435497
    move-object p8, v1

    .line 268435498
    :cond_7
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)V

    .line 268435499
    .line 268435500
    .line 268435501
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p9, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p9, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 47
    .line 48
    :cond_7
    invoke-virtual/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    if-nez v4, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 18
    .line 19
    .line 20
    :cond_1
    const/4 v2, 0x1

    .line 21
    if-nez v4, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 24
    .line 25
    if-eqz v0, :cond_3

    .line 26
    .line 27
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 28
    .line 29
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 30
    .line 31
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 32
    .line 33
    .line 34
    :cond_3
    const/4 v2, 0x2

    .line 35
    if-nez v4, :cond_4

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 38
    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 42
    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 44
    .line 45
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 46
    .line 47
    .line 48
    :cond_5
    const/4 v2, 0x3

    .line 49
    if-nez v4, :cond_6

    .line 50
    .line 51
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 52
    .line 53
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 54
    .line 55
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_7

    .line 60
    .line 61
    :cond_6
    invoke-static {v3, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 66
    .line 67
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 68
    .line 69
    .line 70
    :cond_7
    const/4 v2, 0x4

    .line 71
    if-nez v4, :cond_8

    .line 72
    .line 73
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 74
    .line 75
    if-eqz v0, :cond_9

    .line 76
    .line 77
    :cond_8
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson$$serializer;

    .line 78
    .line 79
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 80
    .line 81
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 82
    .line 83
    .line 84
    :cond_9
    const/4 v2, 0x5

    .line 85
    if-nez v4, :cond_a

    .line 86
    .line 87
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 88
    .line 89
    if-eqz v0, :cond_b

    .line 90
    .line 91
    :cond_a
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 92
    .line 93
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 94
    .line 95
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 96
    .line 97
    .line 98
    :cond_b
    const/4 v2, 0x6

    .line 99
    if-nez v4, :cond_c

    .line 100
    .line 101
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 102
    .line 103
    if-eqz v0, :cond_d

    .line 104
    .line 105
    :cond_c
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson$$serializer;

    .line 106
    .line 107
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 108
    .line 109
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 110
    .line 111
    .line 112
    :cond_d
    const/4 v2, 0x7

    .line 113
    if-nez v4, :cond_e

    .line 114
    .line 115
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 116
    .line 117
    if-eqz v0, :cond_f

    .line 118
    .line 119
    :cond_e
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 120
    .line 121
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 122
    .line 123
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 124
    .line 125
    .line 126
    :cond_f
    return-void
.end method


# virtual methods
.method public final checkoutButtonLabel()Ljava/lang/String;
    .locals 2

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    return-object v1
.end method

.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;",
            "Ljava/lang/String;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x3

    .line 1
    invoke-static {p4, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 5
    .line 6
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_1

    .line 89
    .line 90
    :cond_0
    return v2

    .line 91
    :cond_1
    return v3
.end method

.method public final getCcv_screen_content()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCheckout_button_label()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getComponents()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency_amount()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getEcp_checkout_session_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrder_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_container_mode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVerification_purpose()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ecp_checkout_session_id:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 28
    .line 29
    invoke-static {v0, v1}, LX/007;->A0Q(Ljava/lang/Object;I)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 34
    .line 35
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    add-int/2addr v1, v0

    .line 40
    mul-int/lit8 v1, v1, 0x1f

    .line 41
    .line 42
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkout_button_label:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    add-int/2addr v1, v0

    .line 49
    mul-int/lit8 v1, v1, 0x1f

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 52
    .line 53
    invoke-static {v0}, LX/008;->A0V(Ljava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    add-int/2addr v1, v0

    .line 58
    mul-int/lit8 v1, v1, 0x1f

    .line 59
    .line 60
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 61
    .line 62
    if-eqz v0, :cond_0

    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    :cond_0
    add-int/2addr v1, v2

    .line 69
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
