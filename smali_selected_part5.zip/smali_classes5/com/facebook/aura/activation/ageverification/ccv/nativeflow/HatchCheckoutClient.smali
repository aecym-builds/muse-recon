.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final context:Landroid/content/Context;

.field public final countsUnconfirmedFinalizeAsDone:Z

.field public final verificationPurpose:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->context:Landroid/content/Context;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->verificationPurpose:Ljava/lang/String;

    .line 10
    .line 11
    iput-boolean p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->countsUnconfirmedFinalizeAsDone:Z

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;ZILX/04f;)V
    .locals 1

    .line 268435456
    and-int/lit8 v0, p4, 0x4

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    const/4 p3, 0x0

    .line 268435461
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 268435462
    .line 268435463
    .line 268435464
    return-void
.end method

.method public static final synthetic access$awaitCardSaveConfirmation(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->awaitCardSaveConfirmation(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$fetchCardActionState(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->fetchCardActionState(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$finalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->finalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method private final awaitCardSaveConfirmation(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;

    .line 1
    .line 2
    if-eqz v0, :cond_4

    .line 3
    .line 4
    move-object v6, p2

    .line 5
    check-cast v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;

    .line 6
    .line 7
    iget v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_4

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->label:I

    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    const/4 v3, 0x2

    .line 26
    const/4 v0, 0x1

    .line 27
    if-eqz v1, :cond_1

    .line 28
    .line 29
    if-eq v1, v0, :cond_2

    .line 30
    .line 31
    if-ne v1, v3, :cond_5

    .line 32
    .line 33
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    return-object v2

    .line 37
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;

    .line 41
    .line 42
    invoke-direct {v2, p0, p1, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)V

    .line 43
    .line 44
    .line 45
    iput-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->L$0:Ljava/lang/Object;

    .line 46
    .line 47
    iput v0, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->label:I

    .line 48
    .line 49
    const-wide/16 v0, 0x61a8

    .line 50
    .line 51
    invoke-static {v6, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    if-ne v2, v5, :cond_3

    .line 56
    .line 57
    return-object v5

    .line 58
    :cond_2
    iget-object p1, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 61
    .line 62
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_3
    if-nez v2, :cond_0

    .line 66
    .line 67
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$3;

    .line 68
    .line 69
    invoke-direct {v2, p0, p1, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$3;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)V

    .line 70
    .line 71
    .line 72
    iput-object v4, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->L$0:Ljava/lang/Object;

    .line 73
    .line 74
    iput v3, v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;->label:I

    .line 75
    .line 76
    const-wide/16 v0, 0x1388

    .line 77
    .line 78
    invoke-static {v6, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-ne v2, v5, :cond_0

    .line 83
    .line 84
    return-object v5

    .line 85
    :cond_4
    new-instance v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;

    .line 86
    .line 87
    invoke-direct {v6, p0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 88
    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 92
    .line 93
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 94
    .line 95
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    throw v0
.end method

.method private final fetchCardActionState(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;

    .line 3
    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    move-object v3, v4

    .line 7
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;

    .line 8
    .line 9
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v1, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v2, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->label:I

    .line 25
    .line 26
    const/4 v12, 0x1

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    if-ne v0, v12, :cond_5

    .line 30
    .line 31
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v1, LX/2PJ;

    .line 35
    .line 36
    iget-object v1, v1, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    if-nez v0, :cond_3

    .line 43
    .line 44
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCardProcessingInfoResponseJson;

    .line 45
    .line 46
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCardProcessingInfoResponseJson;->card_action_state:Ljava/lang/String;

    .line 47
    .line 48
    return-object v0

    .line 49
    :cond_1
    invoke-static {v1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 53
    .line 54
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutCardProcessingInfo;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutCardProcessingInfo;

    .line 55
    .line 56
    move-object/from16 v0, p1

    .line 57
    .line 58
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->credentialId:Ljava/lang/String;

    .line 59
    .line 60
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 61
    .line 62
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 63
    .line 64
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCardProcessingInfoRequestJson;

    .line 65
    .line 66
    invoke-direct {v9, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCardProcessingInfoRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    sget-object v10, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 70
    .line 71
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 72
    .line 73
    .line 74
    move-result-object v11

    .line 75
    sget-object p0, LX/0wX;->A00:LX/0wX;

    .line 76
    .line 77
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 78
    .line 79
    sget-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 80
    .line 81
    const/4 v7, 0x0

    .line 82
    const/4 v13, 0x0

    .line 83
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$0:Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$1:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$2:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$3:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$4:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$5:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->L$6:Ljava/lang/Object;

    .line 96
    .line 97
    iput v12, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->I$0:I

    .line 98
    .line 99
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->I$1:I

    .line 100
    .line 101
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->I$2:I

    .line 102
    .line 103
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->I$3:I

    .line 104
    .line 105
    iput v12, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;->label:I

    .line 106
    .line 107
    move v14, v7

    .line 108
    move-object v15, v13

    .line 109
    move-object/from16 v16, v13

    .line 110
    .line 111
    move/from16 v17, v7

    .line 112
    .line 113
    move/from16 p1, v7

    .line 114
    .line 115
    move-object/from16 p2, v3

    .line 116
    .line 117
    invoke-virtual/range {v4 .. v20}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    if-ne v1, v2, :cond_0

    .line 122
    .line 123
    return-object v2

    .line 124
    :cond_2
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;

    .line 125
    .line 126
    move-object/from16 v0, p0

    .line 127
    .line 128
    invoke-direct {v3, v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$fetchCardActionState$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_3
    invoke-static {v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->isFinalClientError(Ljava/lang/Throwable;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_4

    .line 137
    .line 138
    const-string v0, "FAILURE"

    .line 139
    .line 140
    return-object v0

    .line 141
    :cond_4
    const/4 v0, 0x0

    .line 142
    return-object v0

    .line 143
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 144
    .line 145
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 146
    .line 147
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    throw v0
.end method

.method private final finalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p2

    .line 1
    .line 2
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;

    .line 3
    .line 4
    move-object/from16 v2, p0

    .line 5
    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    move-object v0, v5

    .line 9
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;

    .line 10
    .line 11
    iget v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->label:I

    .line 12
    .line 13
    const/high16 v3, -0x80000000

    .line 14
    .line 15
    and-int v1, v4, v3

    .line 16
    .line 17
    if-eqz v1, :cond_3

    .line 18
    .line 19
    sub-int/2addr v4, v3

    .line 20
    iput v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->label:I

    .line 27
    .line 28
    const/4 v3, 0x1

    .line 29
    if-eqz v1, :cond_2

    .line 30
    .line 31
    if-ne v1, v3, :cond_a

    .line 32
    .line 33
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$1:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 36
    .line 37
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    check-cast v5, LX/2PJ;

    .line 41
    .line 42
    iget-object v5, v5, LX/2PJ;->value:Ljava/lang/Object;

    .line 43
    .line 44
    :cond_0
    invoke-static {v5}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    const-string v6, "HatchCheckoutClient"

    .line 49
    .line 50
    if-nez v3, :cond_8

    .line 51
    .line 52
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;

    .line 53
    .line 54
    iget-object v3, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->order_id:Ljava/lang/String;

    .line 55
    .line 56
    if-nez v3, :cond_1

    .line 57
    .line 58
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 59
    .line 60
    :cond_1
    iget-object v4, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->checkout_status:Ljava/lang/String;

    .line 61
    .line 62
    const-string v1, "checkout/finalize status="

    .line 63
    .line 64
    const-string v0, " order="

    .line 65
    .line 66
    invoke-static {v1, v4, v0, v3}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-static {v6, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->checkout_status:Ljava/lang/String;

    .line 74
    .line 75
    const-string v0, "SUCCESS"

    .line 76
    .line 77
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_4

    .line 82
    .line 83
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Success;

    .line 84
    .line 85
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Success;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    return-object v0

    .line 89
    :cond_2
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    move-object/from16 v5, p1

    .line 93
    .line 94
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 95
    .line 96
    sget-object v13, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 97
    .line 98
    sget-object v17, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutFinalize;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutFinalize;

    .line 99
    .line 100
    iget-object v12, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v11, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 103
    .line 104
    iget-object v10, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->credentialId:Ljava/lang/String;

    .line 105
    .line 106
    iget-object v9, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->platformTrustToken:Ljava/lang/String;

    .line 107
    .line 108
    iget-object v8, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->amount:Ljava/lang/String;

    .line 109
    .line 110
    iget-object v7, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->currency:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v6, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->billingCountry:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {}, LX/Ffc;->A00()Ljava/util/UUID;

    .line 115
    .line 116
    .line 117
    move-result-object v5

    .line 118
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v30

    .line 122
    invoke-static {}, LX/Ffc;->A00()Ljava/util/UUID;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    iget-object v5, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 131
    .line 132
    const-string p2, "card"

    .line 133
    .line 134
    const-string v22, "CREDIT_CARD"

    .line 135
    .line 136
    const-string v24, "766358168544755"

    .line 137
    .line 138
    const-string v25, "352501280694489"

    .line 139
    .line 140
    const-string v29, "LIVE"

    .line 141
    .line 142
    new-instance v18, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;

    .line 143
    .line 144
    move-object/from16 v26, v8

    .line 145
    .line 146
    move-object/from16 v27, v7

    .line 147
    .line 148
    move-object/from16 v28, v6

    .line 149
    .line 150
    move-object/from16 p1, v5

    .line 151
    .line 152
    move-object/from16 v20, v11

    .line 153
    .line 154
    move-object/from16 v21, v10

    .line 155
    .line 156
    move-object/from16 v23, v9

    .line 157
    .line 158
    move-object/from16 v19, v12

    .line 159
    .line 160
    invoke-direct/range {v18 .. v33}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    sget-object v19, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 164
    .line 165
    iget-boolean v7, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->countsUnconfirmedFinalizeAsDone:Z

    .line 166
    .line 167
    xor-int/lit8 v8, v7, 0x1

    .line 168
    .line 169
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 170
    .line 171
    .line 172
    move-result-object v20

    .line 173
    sget-object v27, LX/0wX;->A00:LX/0wX;

    .line 174
    .line 175
    sget-object v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 176
    .line 177
    sget-object v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 178
    .line 179
    const/4 v6, 0x0

    .line 180
    const/4 v5, 0x0

    .line 181
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$0:Ljava/lang/Object;

    .line 182
    .line 183
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$1:Ljava/lang/Object;

    .line 184
    .line 185
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$2:Ljava/lang/Object;

    .line 186
    .line 187
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$3:Ljava/lang/Object;

    .line 188
    .line 189
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$4:Ljava/lang/Object;

    .line 190
    .line 191
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$5:Ljava/lang/Object;

    .line 192
    .line 193
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$6:Ljava/lang/Object;

    .line 194
    .line 195
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->L$7:Ljava/lang/Object;

    .line 196
    .line 197
    iput v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->I$0:I

    .line 198
    .line 199
    iput v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->I$1:I

    .line 200
    .line 201
    iput v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->I$2:I

    .line 202
    .line 203
    iput-boolean v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->Z$0:Z

    .line 204
    .line 205
    iput v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;->label:I

    .line 206
    .line 207
    move/from16 v23, v6

    .line 208
    .line 209
    move-object/from16 v24, v5

    .line 210
    .line 211
    move-object/from16 v25, v5

    .line 212
    .line 213
    move/from16 v26, v6

    .line 214
    .line 215
    move/from16 v28, v7

    .line 216
    .line 217
    move-object/from16 v29, v0

    .line 218
    .line 219
    move/from16 v21, v8

    .line 220
    .line 221
    move-object/from16 v22, v5

    .line 222
    .line 223
    move/from16 v16, v6

    .line 224
    .line 225
    invoke-virtual/range {v13 .. v29}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v5

    .line 229
    if-ne v5, v4, :cond_0

    .line 230
    .line 231
    return-object v4

    .line 232
    :cond_3
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;

    .line 233
    .line 234
    invoke-direct {v0, v2, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalize$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 235
    .line 236
    .line 237
    goto/16 :goto_0

    .line 238
    .line 239
    :cond_4
    const-string v0, "PENDING"

    .line 240
    .line 241
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 242
    .line 243
    .line 244
    move-result v1

    .line 245
    const/4 v0, 0x0

    .line 246
    if-eqz v1, :cond_6

    .line 247
    .line 248
    iget-object v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->next_action:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;

    .line 249
    .line 250
    invoke-static {v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutWireTypesJsonKt;->toThreeDSRedirect(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect;

    .line 251
    .line 252
    .line 253
    move-result-object v4

    .line 254
    iget-boolean v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->countsUnconfirmedFinalizeAsDone:Z

    .line 255
    .line 256
    if-eqz v1, :cond_5

    .line 257
    .line 258
    instance-of v1, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;

    .line 259
    .line 260
    if-eqz v1, :cond_5

    .line 261
    .line 262
    check-cast v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;

    .line 263
    .line 264
    iget-object v3, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;->url:Ljava/lang/String;

    .line 265
    .line 266
    iget-object v2, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;->method:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 267
    .line 268
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 269
    .line 270
    invoke-direct {v1, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;)V

    .line 271
    .line 272
    .line 273
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 274
    .line 275
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;)V

    .line 276
    .line 277
    .line 278
    return-object v2

    .line 279
    :cond_5
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Pending;

    .line 280
    .line 281
    invoke-direct {v0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Pending;-><init>(Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    return-object v0

    .line 285
    :cond_6
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->FINALIZE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 286
    .line 287
    iget-object v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;

    .line 288
    .line 289
    if-eqz v2, :cond_7

    .line 290
    .line 291
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;->title:Ljava/lang/String;

    .line 292
    .line 293
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;->description:Ljava/lang/String;

    .line 294
    .line 295
    :goto_1
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 296
    .line 297
    invoke-direct {v2, v3, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 298
    .line 299
    .line 300
    return-object v2

    .line 301
    :cond_7
    move-object v1, v0

    .line 302
    goto :goto_1

    .line 303
    :cond_8
    const-string v0, "checkout/finalize failed"

    .line 304
    .line 305
    invoke-static {v6, v0, v3}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 306
    .line 307
    .line 308
    invoke-static {v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->isFinalClientError(Ljava/lang/Throwable;)Z

    .line 309
    .line 310
    .line 311
    move-result v0

    .line 312
    if-nez v0, :cond_9

    .line 313
    .line 314
    invoke-virtual {v3}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    instance-of v0, v0, Lcom/facebook/aura/network/state/NoNetworkException;

    .line 319
    .line 320
    if-nez v0, :cond_9

    .line 321
    .line 322
    invoke-direct {v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->unconfirmedFinalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;

    .line 323
    .line 324
    .line 325
    move-result-object v0

    .line 326
    return-object v0

    .line 327
    :cond_9
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->FINALIZE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 328
    .line 329
    const/4 v0, 0x0

    .line 330
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 331
    .line 332
    invoke-direct {v2, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    return-object v2

    .line 336
    :cond_a
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 337
    .line 338
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 339
    .line 340
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    throw v0
.end method

.method private final serves(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;Ljava/lang/String;)Z
    .locals 0

    .line 0
    iget-object p0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->verification_purpose:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {p0, p2}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    iget-object p0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 9
    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;->title:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    if-nez p0, :cond_0

    .line 21
    .line 22
    iget-object p0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 23
    .line 24
    if-eqz p0, :cond_0

    .line 25
    .line 26
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;->subtitle:Ljava/lang/String;

    .line 27
    .line 28
    if-eqz p0, :cond_0

    .line 29
    .line 30
    invoke-static {p0}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    const/4 p1, 0x1

    .line 35
    if-eqz p0, :cond_1

    .line 36
    .line 37
    :cond_0
    const/4 p1, 0x0

    .line 38
    :cond_1
    return p1
.end method

.method private final unconfirmedFinalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;
    .locals 1

    .line 0
    iget-boolean v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->countsUnconfirmedFinalizeAsDone:Z

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 5
    .line 6
    new-instance p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Pending;

    .line 7
    .line 8
    invoke-direct {p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Pending;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->FINALIZE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    new-instance p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 16
    .line 17
    invoke-direct {p1, p0, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-object p1
.end method


# virtual methods
.method public final finalizeAfterChallenge(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;

    .line 1
    .line 2
    if-eqz v0, :cond_5

    .line 3
    .line 4
    move-object v5, p2

    .line 5
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;

    .line 6
    .line 7
    iget v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->label:I

    .line 8
    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    and-int v0, v2, v1

    .line 12
    .line 13
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v2, v1

    .line 16
    iput v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->label:I

    .line 17
    .line 18
    :goto_0
    iget-object v2, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->result:Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v6, LX/2PB;->A02:LX/2PB;

    .line 21
    .line 22
    iget v1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->label:I

    .line 23
    .line 24
    const-string v3, "HatchCheckoutClient"

    .line 25
    .line 26
    const/4 v4, 0x2

    .line 27
    const/4 v0, 0x1

    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    if-eq v1, v0, :cond_2

    .line 31
    .line 32
    if-ne v1, v4, :cond_6

    .line 33
    .line 34
    iget-object p1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->L$0:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 37
    .line 38
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    if-nez v2, :cond_8

    .line 42
    .line 43
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;->session:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 44
    .line 45
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->unconfirmedFinalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    const-string v0, "checkout/finalize after 3DS timed out on the client"

    .line 50
    .line 51
    invoke-static {v3, v0}, LX/FnY;->A06(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object v1

    .line 55
    :cond_1
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iput-object p1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->L$0:Ljava/lang/Object;

    .line 59
    .line 60
    iput v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->label:I

    .line 61
    .line 62
    invoke-direct {p0, p1, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->awaitCardSaveConfirmation(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    if-ne v2, v6, :cond_3

    .line 67
    .line 68
    return-object v6

    .line 69
    :cond_2
    iget-object p1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->L$0:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 72
    .line 73
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_3
    check-cast v2, Ljava/lang/String;

    .line 77
    .line 78
    if-nez v2, :cond_4

    .line 79
    .line 80
    const-string v1, "timed out"

    .line 81
    .line 82
    :goto_1
    const-string v0, "card-save confirmation after 3DS: "

    .line 83
    .line 84
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-static {v3, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    const-string v0, "SUCCESS"

    .line 92
    .line 93
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_7

    .line 98
    .line 99
    const/4 v0, 0x0

    .line 100
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$2;

    .line 101
    .line 102
    invoke-direct {v2, p0, p1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)V

    .line 103
    .line 104
    .line 105
    iput-object p1, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->L$0:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->L$1:Ljava/lang/Object;

    .line 108
    .line 109
    iput v4, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;->label:I

    .line 110
    .line 111
    const-wide/16 v0, 0x4e20

    .line 112
    .line 113
    invoke-static {v5, v2, v0, v1}, LX/DRJ;->A01(LX/2M4;LX/JDN;J)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    if-ne v2, v6, :cond_0

    .line 118
    .line 119
    return-object v6

    .line 120
    :cond_4
    move-object v1, v2

    .line 121
    goto :goto_1

    .line 122
    :cond_5
    new-instance v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;

    .line 123
    .line 124
    invoke-direct {v5, p0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$finalizeAfterChallenge$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 125
    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_6
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 129
    .line 130
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 131
    .line 132
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v0

    .line 136
    :cond_7
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->THREE_DS_STEP_UP:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 137
    .line 138
    const/4 v0, 0x0

    .line 139
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 140
    .line 141
    invoke-direct {v2, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    :cond_8
    return-object v2
.end method

.method public final startCheckout(LX/2M4;)Ljava/lang/Object;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v5, p1

    .line 1
    .line 2
    instance-of v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;

    .line 3
    .line 4
    move-object/from16 v2, p0

    .line 5
    .line 6
    if-eqz v0, :cond_5

    .line 7
    .line 8
    move-object v1, v5

    .line 9
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;

    .line 10
    .line 11
    iget v4, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->label:I

    .line 12
    .line 13
    const/high16 v3, -0x80000000

    .line 14
    .line 15
    and-int v0, v4, v3

    .line 16
    .line 17
    if-eqz v0, :cond_5

    .line 18
    .line 19
    sub-int/2addr v4, v3

    .line 20
    iput v4, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->label:I

    .line 21
    .line 22
    :goto_0
    iget-object v5, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->result:Ljava/lang/Object;

    .line 23
    .line 24
    sget-object v0, LX/2PB;->A02:LX/2PB;

    .line 25
    .line 26
    iget v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->label:I

    .line 27
    .line 28
    const/4 v14, 0x1

    .line 29
    if-eqz v3, :cond_4

    .line 30
    .line 31
    if-ne v3, v14, :cond_11

    .line 32
    .line 33
    iget-object v4, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$1:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v4, Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$0:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v3, Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    check-cast v5, LX/2PJ;

    .line 45
    .line 46
    iget-object v1, v5, LX/2PJ;->value:Ljava/lang/Object;

    .line 47
    .line 48
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    const-string v7, "HatchCheckoutClient"

    .line 53
    .line 54
    if-nez v5, :cond_2

    .line 55
    .line 56
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;

    .line 57
    .line 58
    iget-object v6, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->order_id:Ljava/lang/String;

    .line 59
    .line 60
    if-eqz v6, :cond_1

    .line 61
    .line 62
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->verificationPurpose:Ljava/lang/String;

    .line 63
    .line 64
    if-eqz v0, :cond_6

    .line 65
    .line 66
    invoke-direct {v2, v1, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->serves(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;Ljava/lang/String;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_6

    .line 71
    .line 72
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->verificationPurpose:Ljava/lang/String;

    .line 73
    .line 74
    const-string v0, "checkout/init did not serve verification purpose "

    .line 75
    .line 76
    invoke-static {v0, v1}, LX/Gi8;->A0e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-static {v7, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    :cond_1
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;->SERVER_ERROR:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 84
    .line 85
    :goto_1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Failed;

    .line 86
    .line 87
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;)V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :cond_2
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->verificationPurpose:Ljava/lang/String;

    .line 92
    .line 93
    if-eqz v0, :cond_3

    .line 94
    .line 95
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->isCardAlreadyVerified(Ljava/lang/Throwable;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_3

    .line 100
    .line 101
    const-string v0, "checkout/init: card already verified"

    .line 102
    .line 103
    invoke-static {v7, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$AlreadyVerified;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$AlreadyVerified;

    .line 107
    .line 108
    return-object v0

    .line 109
    :cond_3
    const-string v0, "checkout/init failed"

    .line 110
    .line 111
    invoke-static {v7, v0, v5}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->toUnavailableReason(Ljava/lang/Throwable;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    goto :goto_1

    .line 119
    :cond_4
    invoke-static {v5}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {}, LX/GsK;->A00()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    invoke-static {}, LX/Ffc;->A00()Ljava/util/UUID;

    .line 127
    .line 128
    .line 129
    move-result-object v4

    .line 130
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v4

    .line 134
    sget-object v6, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 135
    .line 136
    sget-object v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutInit;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutInit;

    .line 137
    .line 138
    iget-object v5, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->verificationPurpose:Ljava/lang/String;

    .line 139
    .line 140
    const/4 v15, 0x0

    .line 141
    const-string v18, "766358168544755"

    .line 142
    .line 143
    const-string v19, "352501280694489"

    .line 144
    .line 145
    const-string p0, "card"

    .line 146
    .line 147
    new-instance v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 148
    .line 149
    move-object/from16 v16, v11

    .line 150
    .line 151
    move-object/from16 v17, v3

    .line 152
    .line 153
    move-object/from16 v20, v15

    .line 154
    .line 155
    move-object/from16 v21, v15

    .line 156
    .line 157
    move-object/from16 v22, v4

    .line 158
    .line 159
    move-object/from16 p1, v5

    .line 160
    .line 161
    invoke-direct/range {v16 .. v24}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    sget-object v12, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 165
    .line 166
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 167
    .line 168
    .line 169
    move-result-object v13

    .line 170
    sget-object v20, LX/0wX;->A00:LX/0wX;

    .line 171
    .line 172
    sget-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 173
    .line 174
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 175
    .line 176
    const/4 v9, 0x0

    .line 177
    iput-object v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$0:Ljava/lang/Object;

    .line 178
    .line 179
    iput-object v4, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$1:Ljava/lang/Object;

    .line 180
    .line 181
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$2:Ljava/lang/Object;

    .line 182
    .line 183
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$3:Ljava/lang/Object;

    .line 184
    .line 185
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$4:Ljava/lang/Object;

    .line 186
    .line 187
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$5:Ljava/lang/Object;

    .line 188
    .line 189
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$6:Ljava/lang/Object;

    .line 190
    .line 191
    iput-object v15, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->L$7:Ljava/lang/Object;

    .line 192
    .line 193
    iput v14, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->I$0:I

    .line 194
    .line 195
    iput v9, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->I$1:I

    .line 196
    .line 197
    iput v9, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->I$2:I

    .line 198
    .line 199
    iput v9, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->I$3:I

    .line 200
    .line 201
    iput v14, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;->label:I

    .line 202
    .line 203
    move/from16 v16, v9

    .line 204
    .line 205
    move-object/from16 v17, v15

    .line 206
    .line 207
    move-object/from16 v18, v15

    .line 208
    .line 209
    move/from16 v19, v9

    .line 210
    .line 211
    move/from16 v21, v9

    .line 212
    .line 213
    move-object/from16 v22, v1

    .line 214
    .line 215
    invoke-virtual/range {v6 .. v22}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    if-ne v1, v0, :cond_0

    .line 220
    .line 221
    return-object v0

    .line 222
    :cond_5
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;

    .line 223
    .line 224
    invoke-direct {v1, v2, v5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$startCheckout$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 225
    .line 226
    .line 227
    goto/16 :goto_0

    .line 228
    .line 229
    :cond_6
    iget-object v5, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->payment_container_mode:Ljava/lang/String;

    .line 230
    .line 231
    const-string v2, "checkout/init ok, order="

    .line 232
    .line 233
    const-string v0, " container_mode="

    .line 234
    .line 235
    invoke-static {v2, v6, v0, v5}, LX/Gi8;->A0u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    invoke-static {v7, v0}, LX/FnY;->A05(Ljava/lang/String;Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    invoke-static {v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->acceptedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)Ljava/util/List;

    .line 243
    .line 244
    .line 245
    move-result-object v9

    .line 246
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;

    .line 247
    .line 248
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 249
    .line 250
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 251
    .line 252
    .line 253
    move-result-object v7

    .line 254
    :cond_7
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 255
    .line 256
    .line 257
    move-result v0

    .line 258
    const/4 v12, 0x0

    .line 259
    if-eqz v0, :cond_10

    .line 260
    .line 261
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v5

    .line 265
    move-object v0, v5

    .line 266
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 267
    .line 268
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 269
    .line 270
    const-string v0, "PAYMENT_METHOD"

    .line 271
    .line 272
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-result v0

    .line 276
    if-eqz v0, :cond_7

    .line 277
    .line 278
    :goto_2
    check-cast v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 279
    .line 280
    if-eqz v5, :cond_f

    .line 281
    .line 282
    iget-object v0, v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->address_form_fields_config:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;

    .line 283
    .line 284
    :goto_3
    invoke-virtual {v8, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptionsSource;->countryOptions(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAddressFormFieldsConfigJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;

    .line 285
    .line 286
    .line 287
    move-result-object v10

    .line 288
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 289
    .line 290
    if-eqz v0, :cond_8

    .line 291
    .line 292
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;->title:Ljava/lang/String;

    .line 293
    .line 294
    if-eqz v7, :cond_8

    .line 295
    .line 296
    invoke-static {v7}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 297
    .line 298
    .line 299
    move-result v0

    .line 300
    if-eqz v0, :cond_9

    .line 301
    .line 302
    :cond_8
    move-object v7, v12

    .line 303
    :cond_9
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->ccv_screen_content:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;

    .line 304
    .line 305
    if-eqz v0, :cond_a

    .line 306
    .line 307
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvScreenContentJson;->subtitle:Ljava/lang/String;

    .line 308
    .line 309
    if-eqz v5, :cond_a

    .line 310
    .line 311
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 312
    .line 313
    .line 314
    move-result v0

    .line 315
    if-eqz v0, :cond_b

    .line 316
    .line 317
    :cond_a
    move-object v5, v12

    .line 318
    :cond_b
    invoke-virtual {v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->checkoutButtonLabel()Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v15

    .line 322
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 323
    .line 324
    if-eqz v0, :cond_c

    .line 325
    .line 326
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;->amount:Ljava/lang/String;

    .line 327
    .line 328
    if-eqz v2, :cond_c

    .line 329
    .line 330
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    if-eqz v0, :cond_d

    .line 335
    .line 336
    :cond_c
    move-object v2, v12

    .line 337
    :cond_d
    iget-object v0, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->currency_amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;

    .line 338
    .line 339
    if-eqz v0, :cond_e

    .line 340
    .line 341
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCurrencyAmountJson;->currency:Ljava/lang/String;

    .line 342
    .line 343
    if-eqz v1, :cond_e

    .line 344
    .line 345
    invoke-static {v1}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 346
    .line 347
    .line 348
    move-result v0

    .line 349
    if-nez v0, :cond_e

    .line 350
    .line 351
    move-object v12, v1

    .line 352
    :cond_e
    new-instance v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 353
    .line 354
    move-object v13, v7

    .line 355
    move-object v14, v5

    .line 356
    move-object v5, v1

    .line 357
    move-object v7, v3

    .line 358
    move-object v8, v4

    .line 359
    move-object v11, v2

    .line 360
    invoke-direct/range {v5 .. v15}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvCountryOptions;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Opened;

    .line 364
    .line 365
    invoke-direct {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutStartResult$Opened;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;)V

    .line 366
    .line 367
    .line 368
    return-object v0

    .line 369
    :cond_f
    move-object v0, v12

    .line 370
    goto :goto_3

    .line 371
    :cond_10
    move-object v5, v12

    .line 372
    goto :goto_2

    .line 373
    :cond_11
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 374
    .line 375
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 376
    .line 377
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    throw v0
.end method

.method public final submitCard(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v11, p10

    .line 1
    .line 2
    move-object/from16 v6, p9

    .line 3
    .line 4
    move-object/from16 v5, p8

    .line 5
    .line 6
    move-object/from16 v4, p7

    .line 7
    .line 8
    move-object/from16 v9, p6

    .line 9
    .line 10
    move-object/from16 v8, p5

    .line 11
    .line 12
    move-object/from16 v7, p4

    .line 13
    .line 14
    move-object/from16 v12, p3

    .line 15
    .line 16
    move-object/from16 v2, p1

    .line 17
    .line 18
    instance-of v0, v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;

    .line 19
    .line 20
    move-object/from16 p10, p0

    .line 21
    .line 22
    if-eqz v0, :cond_12

    .line 23
    .line 24
    move-object v0, v11

    .line 25
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;

    .line 26
    .line 27
    iget v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 28
    .line 29
    const/high16 v3, -0x80000000

    .line 30
    .line 31
    and-int v1, v10, v3

    .line 32
    .line 33
    if-eqz v1, :cond_12

    .line 34
    .line 35
    sub-int/2addr v10, v3

    .line 36
    iput v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 37
    .line 38
    :goto_0
    iget-object v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->result:Ljava/lang/Object;

    .line 39
    .line 40
    sget-object v11, LX/2PB;->A02:LX/2PB;

    .line 41
    .line 42
    iget v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 43
    .line 44
    const/16 v18, 0x3

    .line 45
    .line 46
    const/16 v16, 0x2

    .line 47
    .line 48
    const/16 v17, 0x4

    .line 49
    .line 50
    const-string v15, "HatchCheckoutClient"

    .line 51
    .line 52
    const/4 v14, 0x1

    .line 53
    if-eqz v3, :cond_1

    .line 54
    .line 55
    if-eq v3, v14, :cond_4

    .line 56
    .line 57
    move/from16 v1, v16

    .line 58
    .line 59
    if-eq v3, v1, :cond_8

    .line 60
    .line 61
    move/from16 v1, v18

    .line 62
    .line 63
    if-eq v3, v1, :cond_b

    .line 64
    .line 65
    move/from16 v0, v17

    .line 66
    .line 67
    if-ne v3, v0, :cond_13

    .line 68
    .line 69
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_0
    return-object v10

    .line 73
    :cond_1
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    invoke-static/range {p2 .. p2}, Lcom/facebook/aura/payments/cardvalidation/HatchCardNetworkKt;->digitsOnly(Ljava/lang/String;)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->supportedCardTypes:Ljava/util/List;

    .line 81
    .line 82
    invoke-static {v1, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardValidationKt;->validatePan(Ljava/lang/String;Ljava/util/List;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCardFieldError;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    if-eqz v3, :cond_3

    .line 87
    .line 88
    const-string v0, "submitCard called with a PAN that does not validate"

    .line 89
    .line 90
    invoke-static {v15, v0}, LX/FnY;->A04(Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    :cond_2
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->CARD_SAVE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 94
    .line 95
    :goto_1
    const/4 v0, 0x0

    .line 96
    new-instance v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 97
    .line 98
    invoke-direct {v10, v1, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    return-object v10

    .line 102
    :cond_3
    sget-object v3, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->INSTANCE:Lcom/facebook/aura/auth/deviceid/AuraDeviceId;

    .line 103
    .line 104
    invoke-virtual {v3}, Lcom/facebook/aura/auth/deviceid/AuraDeviceId;->get()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v25

    .line 108
    sget-object v19, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 109
    .line 110
    sget-object v23, Lcom/facebook/aura/network/api/StefiHatchPath$PttEncryptionKey;->INSTANCE:Lcom/facebook/aura/network/api/StefiHatchPath$PttEncryptionKey;

    .line 111
    .line 112
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 113
    .line 114
    move-object/from16 v20, v3

    .line 115
    .line 116
    iget-object v10, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 117
    .line 118
    const-string v3, "card"

    .line 119
    .line 120
    new-instance v13, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 121
    .line 122
    invoke-direct {v13, v10, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    const-string v26, "ECP"

    .line 126
    .line 127
    const-string v28, "766358168544755"

    .line 128
    .line 129
    new-instance v24, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;

    .line 130
    .line 131
    move-object/from16 v27, v20

    .line 132
    .line 133
    move-object/from16 v29, v13

    .line 134
    .line 135
    invoke-direct/range {v24 .. v29}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;)V

    .line 136
    .line 137
    .line 138
    sget-object v25, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 139
    .line 140
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 141
    .line 142
    .line 143
    move-result-object v26

    .line 144
    sget-object v33, LX/0wX;->A00:LX/0wX;

    .line 145
    .line 146
    sget-object v20, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 147
    .line 148
    sget-object v21, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 149
    .line 150
    const/4 v10, 0x0

    .line 151
    iput-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 152
    .line 153
    const/4 v3, 0x0

    .line 154
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$1:Ljava/lang/Object;

    .line 155
    .line 156
    iput-object v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$2:Ljava/lang/Object;

    .line 157
    .line 158
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 159
    .line 160
    iput-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 161
    .line 162
    iput-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 163
    .line 164
    iput-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 165
    .line 166
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 167
    .line 168
    iput-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 169
    .line 170
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 171
    .line 172
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$10:Ljava/lang/Object;

    .line 173
    .line 174
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$11:Ljava/lang/Object;

    .line 175
    .line 176
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$12:Ljava/lang/Object;

    .line 177
    .line 178
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$13:Ljava/lang/Object;

    .line 179
    .line 180
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$14:Ljava/lang/Object;

    .line 181
    .line 182
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$15:Ljava/lang/Object;

    .line 183
    .line 184
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$16:Ljava/lang/Object;

    .line 185
    .line 186
    iput v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$0:I

    .line 187
    .line 188
    iput v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$1:I

    .line 189
    .line 190
    iput v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$2:I

    .line 191
    .line 192
    iput v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$3:I

    .line 193
    .line 194
    iput v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 195
    .line 196
    move-object/from16 v28, v3

    .line 197
    .line 198
    move/from16 v29, v10

    .line 199
    .line 200
    move-object/from16 v30, v3

    .line 201
    .line 202
    move-object/from16 v31, v3

    .line 203
    .line 204
    move/from16 v32, v10

    .line 205
    .line 206
    move/from16 v34, v10

    .line 207
    .line 208
    move-object/from16 v35, v0

    .line 209
    .line 210
    move/from16 v22, v10

    .line 211
    .line 212
    move/from16 v27, v14

    .line 213
    .line 214
    invoke-virtual/range {v19 .. v35}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v10

    .line 218
    if-ne v10, v11, :cond_5

    .line 219
    .line 220
    return-object v11

    .line 221
    :cond_4
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 222
    .line 223
    check-cast v1, Ljava/lang/String;

    .line 224
    .line 225
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v6, Ljava/lang/String;

    .line 228
    .line 229
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 230
    .line 231
    check-cast v5, Ljava/lang/String;

    .line 232
    .line 233
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 234
    .line 235
    check-cast v4, Ljava/lang/String;

    .line 236
    .line 237
    iget-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 238
    .line 239
    check-cast v9, Ljava/lang/String;

    .line 240
    .line 241
    iget-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v8, Ljava/lang/String;

    .line 244
    .line 245
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v7, Ljava/lang/String;

    .line 248
    .line 249
    iget-object v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$2:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v12, Ljava/lang/String;

    .line 252
    .line 253
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 256
    .line 257
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    check-cast v10, LX/2PJ;

    .line 261
    .line 262
    iget-object v10, v10, LX/2PJ;->value:Ljava/lang/Object;

    .line 263
    .line 264
    :cond_5
    invoke-static {v10}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 265
    .line 266
    .line 267
    move-result-object v3

    .line 268
    if-nez v3, :cond_11

    .line 269
    .line 270
    check-cast v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;

    .line 271
    .line 272
    iget-object v3, v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 273
    .line 274
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 275
    .line 276
    .line 277
    move-result v3

    .line 278
    if-eqz v3, :cond_6

    .line 279
    .line 280
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->ENCRYPTION_KEY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 281
    .line 282
    goto/16 :goto_1

    .line 283
    .line 284
    :cond_6
    sget-object v19, Lcom/facebook/aura/payments/ptt/HatchAddCardPttGenerator;->INSTANCE:Lcom/facebook/aura/payments/ptt/HatchAddCardPttGenerator;

    .line 285
    .line 286
    move-object/from16 v3, p10

    .line 287
    .line 288
    iget-object v3, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->context:Landroid/content/Context;

    .line 289
    .line 290
    move-object/from16 v20, v3

    .line 291
    .line 292
    iget-object v3, v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->trust_chain:Ljava/util/List;

    .line 293
    .line 294
    move-object/from16 v21, v3

    .line 295
    .line 296
    iget-object v10, v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyResponseJson;->id:Ljava/lang/String;

    .line 297
    .line 298
    if-nez v10, :cond_7

    .line 299
    .line 300
    const-string v10, ""

    .line 301
    .line 302
    :cond_7
    iget-object v3, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 303
    .line 304
    move-object/from16 v23, v3

    .line 305
    .line 306
    iput-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 307
    .line 308
    const/4 v3, 0x0

    .line 309
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$1:Ljava/lang/Object;

    .line 310
    .line 311
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$2:Ljava/lang/Object;

    .line 312
    .line 313
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 314
    .line 315
    iput-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 316
    .line 317
    iput-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 318
    .line 319
    iput-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 320
    .line 321
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 322
    .line 323
    iput-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 324
    .line 325
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 326
    .line 327
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$10:Ljava/lang/Object;

    .line 328
    .line 329
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$11:Ljava/lang/Object;

    .line 330
    .line 331
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$12:Ljava/lang/Object;

    .line 332
    .line 333
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$13:Ljava/lang/Object;

    .line 334
    .line 335
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$14:Ljava/lang/Object;

    .line 336
    .line 337
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$15:Ljava/lang/Object;

    .line 338
    .line 339
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$16:Ljava/lang/Object;

    .line 340
    .line 341
    move/from16 v13, v16

    .line 342
    .line 343
    iput v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 344
    .line 345
    const-string v24, "ECP"

    .line 346
    .line 347
    move-object/from16 v22, v10

    .line 348
    .line 349
    move-object/from16 v25, v1

    .line 350
    .line 351
    move-object/from16 v26, v12

    .line 352
    .line 353
    move-object/from16 v27, v7

    .line 354
    .line 355
    move-object/from16 v28, v8

    .line 356
    .line 357
    move-object/from16 v29, v3

    .line 358
    .line 359
    move-object/from16 v30, v0

    .line 360
    .line 361
    invoke-virtual/range {v19 .. v30}, Lcom/facebook/aura/payments/ptt/HatchAddCardPttGenerator;->generate-5p_uFSQ(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;LX/2M4;)Ljava/lang/Object;

    .line 362
    .line 363
    .line 364
    move-result-object v3

    .line 365
    if-ne v3, v11, :cond_9

    .line 366
    .line 367
    return-object v11

    .line 368
    :cond_8
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 369
    .line 370
    check-cast v1, Ljava/lang/String;

    .line 371
    .line 372
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 373
    .line 374
    check-cast v6, Ljava/lang/String;

    .line 375
    .line 376
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 377
    .line 378
    check-cast v5, Ljava/lang/String;

    .line 379
    .line 380
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 381
    .line 382
    check-cast v4, Ljava/lang/String;

    .line 383
    .line 384
    iget-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 385
    .line 386
    check-cast v9, Ljava/lang/String;

    .line 387
    .line 388
    iget-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 389
    .line 390
    check-cast v8, Ljava/lang/String;

    .line 391
    .line 392
    iget-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 393
    .line 394
    check-cast v7, Ljava/lang/String;

    .line 395
    .line 396
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 397
    .line 398
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 399
    .line 400
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 401
    .line 402
    .line 403
    check-cast v10, LX/2PJ;

    .line 404
    .line 405
    iget-object v3, v10, LX/2PJ;->value:Ljava/lang/Object;

    .line 406
    .line 407
    :cond_9
    invoke-static {v3}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 408
    .line 409
    .line 410
    move-result-object v10

    .line 411
    if-nez v10, :cond_10

    .line 412
    .line 413
    check-cast v3, Ljava/lang/String;

    .line 414
    .line 415
    sget-object v36, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 416
    .line 417
    sget-object v40, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutCredential;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$CheckoutCredential;

    .line 418
    .line 419
    iget-object v10, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->uplSessionId:Ljava/lang/String;

    .line 420
    .line 421
    move-object/from16 v20, v10

    .line 422
    .line 423
    iget-object v10, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->orderId:Ljava/lang/String;

    .line 424
    .line 425
    move-object/from16 v23, v10

    .line 426
    .line 427
    const/4 v10, 0x6

    .line 428
    invoke-static {v1, v10}, LX/Bf6;->A11(Ljava/lang/String;I)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v28

    .line 432
    const/16 v16, 0x4

    .line 433
    .line 434
    const/4 v13, 0x0

    .line 435
    invoke-static {v1, v13}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 436
    .line 437
    .line 438
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 439
    .line 440
    .line 441
    move-result v12

    .line 442
    move/from16 v10, v17

    .line 443
    .line 444
    if-le v10, v12, :cond_a

    .line 445
    .line 446
    move/from16 v16, v12

    .line 447
    .line 448
    :cond_a
    sub-int v12, v12, v16

    .line 449
    .line 450
    invoke-virtual {v1, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 451
    .line 452
    .line 453
    move-result-object v29

    .line 454
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;->otcSessionId:Ljava/lang/String;

    .line 455
    .line 456
    const-string v35, "card"

    .line 457
    .line 458
    const-string v21, "CREATE"

    .line 459
    .line 460
    const-string v26, "766358168544755"

    .line 461
    .line 462
    const-string v27, "352501280694489"

    .line 463
    .line 464
    new-instance v19, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 465
    .line 466
    move-object/from16 v22, v3

    .line 467
    .line 468
    move-object/from16 v24, v5

    .line 469
    .line 470
    move-object/from16 v25, v6

    .line 471
    .line 472
    move-object/from16 v30, v7

    .line 473
    .line 474
    move-object/from16 v31, v8

    .line 475
    .line 476
    move-object/from16 v32, v9

    .line 477
    .line 478
    move-object/from16 v33, v4

    .line 479
    .line 480
    move-object/from16 v34, v1

    .line 481
    .line 482
    invoke-direct/range {v19 .. v35}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 483
    .line 484
    .line 485
    sget-object v42, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 486
    .line 487
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 488
    .line 489
    .line 490
    move-result-object p0

    .line 491
    sget-object p7, LX/0wX;->A00:LX/0wX;

    .line 492
    .line 493
    sget-object v37, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$3;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$3;

    .line 494
    .line 495
    sget-object v38, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$4;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$$inlined$executeStefiRequest-1iavgos$default$4;

    .line 496
    .line 497
    iput-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 498
    .line 499
    const/4 v7, 0x0

    .line 500
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$1:Ljava/lang/Object;

    .line 501
    .line 502
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$2:Ljava/lang/Object;

    .line 503
    .line 504
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 505
    .line 506
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 507
    .line 508
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 509
    .line 510
    iput-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 511
    .line 512
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 513
    .line 514
    iput-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 515
    .line 516
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 517
    .line 518
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$10:Ljava/lang/Object;

    .line 519
    .line 520
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$11:Ljava/lang/Object;

    .line 521
    .line 522
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$12:Ljava/lang/Object;

    .line 523
    .line 524
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$13:Ljava/lang/Object;

    .line 525
    .line 526
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$14:Ljava/lang/Object;

    .line 527
    .line 528
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$15:Ljava/lang/Object;

    .line 529
    .line 530
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$16:Ljava/lang/Object;

    .line 531
    .line 532
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$17:Ljava/lang/Object;

    .line 533
    .line 534
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$18:Ljava/lang/Object;

    .line 535
    .line 536
    iput v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$0:I

    .line 537
    .line 538
    iput v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$1:I

    .line 539
    .line 540
    iput v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$2:I

    .line 541
    .line 542
    iput v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->I$3:I

    .line 543
    .line 544
    move/from16 v1, v18

    .line 545
    .line 546
    iput v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 547
    .line 548
    move/from16 v39, v13

    .line 549
    .line 550
    move-object/from16 v41, v19

    .line 551
    .line 552
    move/from16 p1, v14

    .line 553
    .line 554
    move-object/from16 p2, v7

    .line 555
    .line 556
    move/from16 p3, v13

    .line 557
    .line 558
    move-object/from16 p4, v7

    .line 559
    .line 560
    move-object/from16 p5, v7

    .line 561
    .line 562
    move/from16 p6, v13

    .line 563
    .line 564
    move/from16 p8, v13

    .line 565
    .line 566
    move-object/from16 p9, v0

    .line 567
    .line 568
    invoke-virtual/range {v36 .. v52}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v7

    .line 572
    if-ne v7, v11, :cond_c

    .line 573
    .line 574
    return-object v11

    .line 575
    :cond_b
    iget-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$12:Ljava/lang/Object;

    .line 576
    .line 577
    check-cast v3, Ljava/lang/String;

    .line 578
    .line 579
    iget-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 580
    .line 581
    check-cast v6, Ljava/lang/String;

    .line 582
    .line 583
    iget-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 584
    .line 585
    check-cast v5, Ljava/lang/String;

    .line 586
    .line 587
    iget-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 588
    .line 589
    check-cast v4, Ljava/lang/String;

    .line 590
    .line 591
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 592
    .line 593
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;

    .line 594
    .line 595
    invoke-static {v10}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 596
    .line 597
    .line 598
    check-cast v10, LX/2PJ;

    .line 599
    .line 600
    iget-object v7, v10, LX/2PJ;->value:Ljava/lang/Object;

    .line 601
    .line 602
    :cond_c
    invoke-static {v7}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 603
    .line 604
    .line 605
    move-result-object v1

    .line 606
    if-nez v1, :cond_f

    .line 607
    .line 608
    check-cast v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialResponseJson;

    .line 609
    .line 610
    iget-object v8, v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialResponseJson;->mutation:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCredentialMutationJson;

    .line 611
    .line 612
    if-eqz v8, :cond_2

    .line 613
    .line 614
    iget-boolean v1, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCredentialMutationJson;->success:Z

    .line 615
    .line 616
    if-nez v1, :cond_e

    .line 617
    .line 618
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->CARD_SAVE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 619
    .line 620
    iget-object v0, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCredentialMutationJson;->error:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;

    .line 621
    .line 622
    if-eqz v0, :cond_d

    .line 623
    .line 624
    iget-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;->title:Ljava/lang/String;

    .line 625
    .line 626
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;->description:Ljava/lang/String;

    .line 627
    .line 628
    :goto_2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;

    .line 629
    .line 630
    invoke-direct {v0, v3, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$Failed;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;Ljava/lang/String;Ljava/lang/String;)V

    .line 631
    .line 632
    .line 633
    return-object v0

    .line 634
    :cond_d
    const/4 v2, 0x0

    .line 635
    const/4 v1, 0x0

    .line 636
    goto :goto_2

    .line 637
    :cond_e
    iget-object v1, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCredentialMutationJson;->credential_id:Ljava/lang/String;

    .line 638
    .line 639
    if-eqz v1, :cond_2

    .line 640
    .line 641
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 642
    .line 643
    move-object/from16 v18, v7

    .line 644
    .line 645
    move-object/from16 v19, v2

    .line 646
    .line 647
    move-object/from16 v20, v1

    .line 648
    .line 649
    move-object/from16 v21, v3

    .line 650
    .line 651
    move-object/from16 v22, v5

    .line 652
    .line 653
    move-object/from16 v23, v6

    .line 654
    .line 655
    move-object/from16 v24, v4

    .line 656
    .line 657
    invoke-direct/range {v18 .. v24}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 658
    .line 659
    .line 660
    iget-object v1, v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCredentialMutationJson;->next_action:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;

    .line 661
    .line 662
    invoke-static {v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutWireTypesJsonKt;->toThreeDSRedirect(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect;

    .line 663
    .line 664
    .line 665
    move-result-object v3

    .line 666
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$None;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$None;

    .line 667
    .line 668
    invoke-static {v3, v1}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 669
    .line 670
    .line 671
    move-result v1

    .line 672
    if-eqz v1, :cond_14

    .line 673
    .line 674
    const/4 v1, 0x0

    .line 675
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$0:Ljava/lang/Object;

    .line 676
    .line 677
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$1:Ljava/lang/Object;

    .line 678
    .line 679
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$2:Ljava/lang/Object;

    .line 680
    .line 681
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$3:Ljava/lang/Object;

    .line 682
    .line 683
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$4:Ljava/lang/Object;

    .line 684
    .line 685
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$5:Ljava/lang/Object;

    .line 686
    .line 687
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$6:Ljava/lang/Object;

    .line 688
    .line 689
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$7:Ljava/lang/Object;

    .line 690
    .line 691
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$8:Ljava/lang/Object;

    .line 692
    .line 693
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$9:Ljava/lang/Object;

    .line 694
    .line 695
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$10:Ljava/lang/Object;

    .line 696
    .line 697
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$11:Ljava/lang/Object;

    .line 698
    .line 699
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$12:Ljava/lang/Object;

    .line 700
    .line 701
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$13:Ljava/lang/Object;

    .line 702
    .line 703
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$14:Ljava/lang/Object;

    .line 704
    .line 705
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$15:Ljava/lang/Object;

    .line 706
    .line 707
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$16:Ljava/lang/Object;

    .line 708
    .line 709
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$17:Ljava/lang/Object;

    .line 710
    .line 711
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->L$18:Ljava/lang/Object;

    .line 712
    .line 713
    move/from16 v1, v17

    .line 714
    .line 715
    iput v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 716
    .line 717
    move-object/from16 v1, p10

    .line 718
    .line 719
    invoke-direct {v1, v7, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->finalize(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 720
    .line 721
    .line 722
    move-result-object v10

    .line 723
    if-ne v10, v11, :cond_0

    .line 724
    .line 725
    return-object v11

    .line 726
    :cond_f
    const-string v0, "checkout/credential failed"

    .line 727
    .line 728
    invoke-static {v15, v0, v1}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 729
    .line 730
    .line 731
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->CARD_SAVE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 732
    .line 733
    goto/16 :goto_1

    .line 734
    .line 735
    :cond_10
    const-string v0, "PTT generation failed"

    .line 736
    .line 737
    invoke-static {v15, v0, v10}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 738
    .line 739
    .line 740
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->PTT_GENERATION:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 741
    .line 742
    goto/16 :goto_1

    .line 743
    .line 744
    :cond_11
    const-string v0, "ptt/encryption-key failed"

    .line 745
    .line 746
    invoke-static {v15, v0, v3}, LX/FnY;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 747
    .line 748
    .line 749
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;->ENCRYPTION_KEY:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvError;

    .line 750
    .line 751
    goto/16 :goto_1

    .line 752
    .line 753
    :cond_12
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;

    .line 754
    .line 755
    move-object/from16 v1, p10

    .line 756
    .line 757
    invoke-direct {v0, v1, v11}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V

    .line 758
    .line 759
    .line 760
    goto/16 :goto_0

    .line 761
    .line 762
    :cond_13
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 763
    .line 764
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 765
    .line 766
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 767
    .line 768
    .line 769
    throw v0

    .line 770
    :cond_14
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Invalid;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Invalid;

    .line 771
    .line 772
    invoke-static {v3, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 773
    .line 774
    .line 775
    move-result v0

    .line 776
    if-eqz v0, :cond_15

    .line 777
    .line 778
    sget-object v10, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$InvalidThreeDSStepUp;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$InvalidThreeDSStepUp;

    .line 779
    .line 780
    return-object v10

    .line 781
    :cond_15
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;

    .line 782
    .line 783
    if-eqz v0, :cond_16

    .line 784
    .line 785
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;

    .line 786
    .line 787
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;->url:Ljava/lang/String;

    .line 788
    .line 789
    iget-object v1, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;->method:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 790
    .line 791
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;

    .line 792
    .line 793
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;)V

    .line 794
    .line 795
    .line 796
    new-instance v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;

    .line 797
    .line 798
    invoke-direct {v11, v0, v7}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvResult$ThreeDSStepUpRequired;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSStepUp;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;)V

    .line 799
    .line 800
    .line 801
    return-object v11

    .line 802
    :cond_16
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 803
    .line 804
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 805
    .line 806
    .line 807
    throw v0
.end method
