.class public final synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x4

    .line 8
    const-string v0, "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutFinalizeResponseJson"

    .line 9
    .line 10
    new-instance v2, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "checkout_status"

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v0, "order_id"

    .line 22
    .line 23
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "error"

    .line 27
    .line 28
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    const-string v0, "next_action"

    .line 32
    .line 33
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 34
    .line 35
    .line 36
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->descriptor:LX/Da5;

    .line 37
    .line 38
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson$$serializer;

    .line 11
    .line 12
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson$$serializer;

    .line 17
    .line 18
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    filled-new-array {p0, v2, v1, v0}, [LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;
    .locals 12

    .line 0
    const/4 v7, 0x0

    .line 1
    invoke-static {p1, v7}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    sget-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->descriptor:LX/Da5;

    .line 5
    .line 6
    invoke-interface {p1, v6}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 7
    .line 8
    .line 9
    move-result-object v5

    .line 10
    const/4 v4, 0x3

    .line 11
    const/4 v3, 0x2

    .line 12
    const/4 v2, 0x1

    .line 13
    const/4 v9, 0x0

    .line 14
    move-object v10, v9

    .line 15
    move-object v11, v9

    .line 16
    move-object p0, v9

    .line 17
    const/4 v8, 0x0

    .line 18
    :goto_0
    invoke-interface {v5, v6}, LX/Da7;->A8S(LX/Da5;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/4 v0, -0x1

    .line 23
    if-eq v1, v0, :cond_4

    .line 24
    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    if-eq v1, v2, :cond_1

    .line 28
    .line 29
    if-eq v1, v3, :cond_0

    .line 30
    .line 31
    if-ne v1, v4, :cond_3

    .line 32
    .line 33
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson$$serializer;

    .line 34
    .line 35
    invoke-interface {v5, v0, v6, v4}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    check-cast p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;

    .line 40
    .line 41
    or-int/lit8 v8, v8, 0x8

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson$$serializer;

    .line 45
    .line 46
    invoke-interface {v5, v0, v6, v3}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v11

    .line 50
    check-cast v11, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;

    .line 51
    .line 52
    or-int/lit8 v8, v8, 0x4

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_1
    invoke-static {v6, v5, v2}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v10

    .line 59
    or-int/lit8 v8, v8, 0x2

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    invoke-static {v6, v5, v7}, LX/3Rr;->A0p(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v9

    .line 66
    or-int/lit8 v8, v8, 0x1

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_3
    new-instance v0, Lkotlinx/serialization/UnknownFieldException;

    .line 70
    .line 71
    invoke-direct {v0, v1}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 72
    .line 73
    .line 74
    throw v0

    .line 75
    :cond_4
    invoke-interface {v5, v6}, LX/Da7;->AAi(LX/Da5;)V

    .line 76
    .line 77
    .line 78
    const/4 p1, 0x0

    .line 79
    new-instance v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;

    .line 80
    .line 81
    invoke-direct/range {v7 .. v13}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;-><init>(ILjava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutErrorJson;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;LX/5Xm;)V

    .line 82
    .line 83
    .line 84
    return-object v7
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeResponseJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
