.class public interface abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/facebook/aura/network/api/StefiHatchPath$Extension;
