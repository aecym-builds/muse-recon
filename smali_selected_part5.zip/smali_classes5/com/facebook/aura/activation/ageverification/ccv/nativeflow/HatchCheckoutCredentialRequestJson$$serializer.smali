.class public final synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x10

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutCredentialRequestJson"

    .line 10
    .line 11
    new-instance v2, LX/DZp;

    .line 12
    .line 13
    invoke-direct {v2, v0, v3, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "session_id"

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "mutation_type"

    .line 23
    .line 24
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "platform_trust_token"

    .line 28
    .line 29
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "order_id"

    .line 33
    .line 34
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "amount"

    .line 38
    .line 39
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "currency_code"

    .line 43
    .line 44
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    const-string v0, "product_id"

    .line 48
    .line 49
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    const-string v0, "receiver_id"

    .line 53
    .line 54
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    const-string v0, "card_first_6"

    .line 58
    .line 59
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 60
    .line 61
    .line 62
    const-string v0, "card_last_4"

    .line 63
    .line 64
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 65
    .line 66
    .line 67
    const-string v0, "expiry_month"

    .line 68
    .line 69
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 70
    .line 71
    .line 72
    const-string v0, "expiry_year"

    .line 73
    .line 74
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 75
    .line 76
    .line 77
    const-string v0, "zip"

    .line 78
    .line 79
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 80
    .line 81
    .line 82
    const-string v0, "country_code"

    .line 83
    .line 84
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 85
    .line 86
    .line 87
    const-string v0, "otc_session_id"

    .line 88
    .line 89
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 90
    .line 91
    .line 92
    const-string v0, "otc_type"

    .line 93
    .line 94
    invoke-virtual {v2, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 95
    .line 96
    .line 97
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->descriptor:LX/Da5;

    .line 98
    .line 99
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    move-object v1, v0

    .line 3
    move-object v2, v0

    .line 4
    move-object v3, v0

    .line 5
    move-object v4, v0

    .line 6
    move-object v5, v0

    .line 7
    move-object v6, v0

    .line 8
    move-object v7, v0

    .line 9
    move-object v8, v0

    .line 10
    move-object v9, v0

    .line 11
    move-object v10, v0

    .line 12
    move-object v11, v0

    .line 13
    move-object v12, v0

    .line 14
    move-object v13, v0

    .line 15
    move-object v14, v0

    .line 16
    move-object p0, v0

    .line 17
    filled-new-array/range {v0 .. v15}, [LX/DZ7;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;
    .locals 32

    .line 0
    const/4 v4, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v4}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v2}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    const/16 v16, 0xc

    .line 13
    .line 14
    const/16 v15, 0xb

    .line 15
    .line 16
    const/16 v14, 0xa

    .line 17
    .line 18
    const/16 v13, 0x9

    .line 19
    .line 20
    const/4 v12, 0x7

    .line 21
    const/4 v11, 0x6

    .line 22
    const/4 v10, 0x5

    .line 23
    const/4 v9, 0x3

    .line 24
    const/16 v8, 0x8

    .line 25
    .line 26
    const/4 v7, 0x4

    .line 27
    const/4 v6, 0x2

    .line 28
    const/4 v1, 0x0

    .line 29
    const/16 v5, 0xf

    .line 30
    .line 31
    const/16 v17, 0x0

    .line 32
    .line 33
    move-object/from16 v31, v17

    .line 34
    .line 35
    move-object/from16 v19, v17

    .line 36
    .line 37
    move-object/from16 v18, v17

    .line 38
    .line 39
    move-object/from16 v20, v17

    .line 40
    .line 41
    move-object/from16 p0, v17

    .line 42
    .line 43
    move-object/from16 v29, v17

    .line 44
    .line 45
    move-object/from16 v28, v17

    .line 46
    .line 47
    move-object/from16 v27, v17

    .line 48
    .line 49
    move-object/from16 v26, v17

    .line 50
    .line 51
    move-object/from16 v24, v17

    .line 52
    .line 53
    move-object/from16 v23, v17

    .line 54
    .line 55
    move-object/from16 v22, v17

    .line 56
    .line 57
    move-object/from16 v21, v17

    .line 58
    .line 59
    move-object/from16 v25, v17

    .line 60
    .line 61
    move-object/from16 v30, v17

    .line 62
    .line 63
    :goto_0
    invoke-interface {v3, v2}, LX/Da7;->A8S(LX/Da5;)I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    packed-switch v0, :pswitch_data_0

    .line 68
    .line 69
    .line 70
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 71
    .line 72
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 73
    .line 74
    .line 75
    throw v1

    .line 76
    :pswitch_0
    invoke-interface {v3, v2, v4}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v17

    .line 80
    or-int/lit8 v1, v1, 0x1

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :pswitch_1
    const/4 v0, 0x1

    .line 84
    invoke-interface {v3, v2, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v18

    .line 88
    or-int/lit8 v1, v1, 0x2

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :pswitch_2
    invoke-interface {v3, v2, v6}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v19

    .line 95
    or-int/lit8 v1, v1, 0x4

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :pswitch_3
    invoke-interface {v3, v2, v9}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v20

    .line 102
    or-int/lit8 v1, v1, 0x8

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :pswitch_4
    invoke-interface {v3, v2, v7}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v21

    .line 109
    or-int/lit8 v1, v1, 0x10

    .line 110
    .line 111
    goto :goto_0

    .line 112
    :pswitch_5
    invoke-interface {v3, v2, v10}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v22

    .line 116
    or-int/lit8 v1, v1, 0x20

    .line 117
    .line 118
    goto :goto_0

    .line 119
    :pswitch_6
    invoke-interface {v3, v2, v11}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v23

    .line 123
    or-int/lit8 v1, v1, 0x40

    .line 124
    .line 125
    goto :goto_0

    .line 126
    :pswitch_7
    invoke-interface {v3, v2, v12}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v24

    .line 130
    or-int/lit16 v1, v1, 0x80

    .line 131
    .line 132
    goto :goto_0

    .line 133
    :pswitch_8
    invoke-interface {v3, v2, v8}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v25

    .line 137
    or-int/lit16 v1, v1, 0x100

    .line 138
    .line 139
    goto :goto_0

    .line 140
    :pswitch_9
    invoke-interface {v3, v2, v13}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v26

    .line 144
    or-int/lit16 v1, v1, 0x200

    .line 145
    .line 146
    goto :goto_0

    .line 147
    :pswitch_a
    invoke-interface {v3, v2, v14}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v27

    .line 151
    or-int/lit16 v1, v1, 0x400

    .line 152
    .line 153
    goto :goto_0

    .line 154
    :pswitch_b
    invoke-interface {v3, v2, v15}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v28

    .line 158
    or-int/lit16 v1, v1, 0x800

    .line 159
    .line 160
    goto :goto_0

    .line 161
    :pswitch_c
    move/from16 v0, v16

    .line 162
    .line 163
    invoke-interface {v3, v2, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v29

    .line 167
    or-int/lit16 v1, v1, 0x1000

    .line 168
    .line 169
    goto :goto_0

    .line 170
    :pswitch_d
    const/16 v0, 0xd

    .line 171
    .line 172
    invoke-interface {v3, v2, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v30

    .line 176
    or-int/lit16 v1, v1, 0x2000

    .line 177
    .line 178
    goto :goto_0

    .line 179
    :pswitch_e
    const/16 v0, 0xe

    .line 180
    .line 181
    invoke-interface {v3, v2, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v31

    .line 185
    or-int/lit16 v1, v1, 0x4000

    .line 186
    .line 187
    goto :goto_0

    .line 188
    :pswitch_f
    invoke-interface {v3, v2, v5}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object p0

    .line 192
    const v0, 0x8000

    .line 193
    .line 194
    .line 195
    or-int/2addr v1, v0

    .line 196
    goto/16 :goto_0

    .line 197
    .line 198
    :pswitch_10
    invoke-interface {v3, v2}, LX/Da7;->AAi(LX/Da5;)V

    .line 199
    .line 200
    .line 201
    const/16 p1, 0x0

    .line 202
    .line 203
    new-instance v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 204
    .line 205
    move/from16 v16, v1

    .line 206
    .line 207
    invoke-direct/range {v15 .. v33}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 208
    .line 209
    .line 210
    return-object v15

    .line 211
    nop

    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_10
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
