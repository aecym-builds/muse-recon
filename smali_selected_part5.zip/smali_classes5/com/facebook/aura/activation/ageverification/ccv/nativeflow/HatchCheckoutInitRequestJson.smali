.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$Companion;


# instance fields
.field public final amount:Ljava/lang/String;

.field public final currency:Ljava/lang/String;

.field public final otc_session_id:Ljava/lang/String;

.field public final otc_type:Ljava/lang/String;

.field public final product_id:Ljava/lang/String;

.field public final receiver_id:Ljava/lang/String;

.field public final session_id:Ljava/lang/String;

.field public final verification_purpose:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p1, 0x67

    .line 536870913
    .line 536870914
    const/16 v1, 0x67

    .line 536870915
    .line 536870916
    if-eq v1, v0, :cond_0

    .line 536870917
    .line 536870918
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 536870919
    .line 536870920
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 536870921
    .line 536870922
    .line 536870923
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 536870924
    .line 536870925
    .line 536870926
    move-result-object v0

    .line 536870927
    throw v0

    .line 536870928
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870929
    .line 536870930
    .line 536870931
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 536870932
    .line 536870933
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 536870934
    .line 536870935
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 536870936
    .line 536870937
    and-int/lit8 v0, p1, 0x8

    .line 536870938
    .line 536870939
    const/4 v1, 0x0

    .line 536870940
    if-nez v0, :cond_2

    .line 536870941
    .line 536870942
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 536870943
    .line 536870944
    :goto_0
    and-int/lit8 v0, p1, 0x10

    .line 536870945
    .line 536870946
    if-nez v0, :cond_1

    .line 536870947
    .line 536870948
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 536870949
    .line 536870950
    :goto_1
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 536870951
    .line 536870952
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 536870953
    .line 536870954
    and-int/lit16 v0, p1, 0x80

    .line 536870955
    .line 536870956
    if-nez v0, :cond_3

    .line 536870957
    .line 536870958
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 536870959
    .line 536870960
    return-void

    .line 536870961
    :cond_1
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 536870962
    .line 536870963
    goto :goto_1

    .line 536870964
    :cond_2
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 536870965
    .line 536870966
    goto :goto_0

    .line 536870967
    :cond_3
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 536870968
    .line 536870969
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 14
    .line 15
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 16
    .line 17
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 18
    .line 19
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 22
    .line 23
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 24
    .line 25
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p9, 0x8

    .line 268435457
    .line 268435458
    const/4 v1, 0x0

    .line 268435459
    if-eqz v0, :cond_0

    .line 268435460
    .line 268435461
    move-object p4, v1

    .line 268435462
    :cond_0
    and-int/lit8 v0, p9, 0x10

    .line 268435463
    .line 268435464
    if-eqz v0, :cond_1

    .line 268435465
    .line 268435466
    move-object p5, v1

    .line 268435467
    :cond_1
    and-int/lit16 v0, p9, 0x80

    .line 268435468
    .line 268435469
    if-eqz v0, :cond_2

    .line 268435470
    .line 268435471
    move-object p8, v1

    .line 268435472
    :cond_2
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 268435473
    .line 268435474
    .line 268435475
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p9, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p9, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p9, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p9, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p9, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 29
    .line 30
    :cond_4
    and-int/lit8 v0, p9, 0x20

    .line 31
    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    iget-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 35
    .line 36
    :cond_5
    and-int/lit8 v0, p9, 0x40

    .line 37
    .line 38
    if-eqz v0, :cond_6

    .line 39
    .line 40
    iget-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 41
    .line 42
    :cond_6
    and-int/lit16 v0, p9, 0x80

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iget-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 47
    .line 48
    :cond_7
    invoke-virtual/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    const/4 v2, 0x3

    .line 19
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-nez v3, :cond_0

    .line 24
    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    :cond_1
    const/4 v2, 0x4

    .line 37
    if-nez v3, :cond_2

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 40
    .line 41
    if-eqz v0, :cond_3

    .line 42
    .line 43
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 46
    .line 47
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 48
    .line 49
    .line 50
    :cond_3
    const/4 v1, 0x5

    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 52
    .line 53
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 54
    .line 55
    .line 56
    const/4 v1, 0x6

    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 60
    .line 61
    .line 62
    const/4 v2, 0x7

    .line 63
    if-nez v3, :cond_4

    .line 64
    .line 65
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 66
    .line 67
    if-eqz v0, :cond_5

    .line 68
    .line 69
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 72
    .line 73
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 74
    .line 75
    .line 76
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3}, LX/005;->A0y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 7
    .line 8
    invoke-direct/range {p0 .. p8}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_1

    .line 89
    .line 90
    :cond_0
    return v2

    .line 91
    :cond_1
    return v3
.end method

.method public final getAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_session_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getProduct_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReceiver_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSession_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getVerification_purpose()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->product_id:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->receiver_id:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->amount:Ljava/lang/String;

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v1, v0

    .line 28
    mul-int/lit8 v1, v1, 0x1f

    .line 29
    .line 30
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->currency:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_session_id:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->otc_type:Ljava/lang/String;

    .line 46
    .line 47
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->verification_purpose:Ljava/lang/String;

    .line 52
    .line 53
    if-eqz v0, :cond_0

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    :cond_0
    add-int/2addr v1, v2

    .line 60
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
