.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson$Companion;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    return-void
.end method

.method public synthetic constructor <init>(LX/04f;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final serializer()LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LX/DZ7<",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;",
            ">;"
        }
    .end annotation

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson$$serializer;

    .line 1
    .line 2
    return-object p0
.end method
