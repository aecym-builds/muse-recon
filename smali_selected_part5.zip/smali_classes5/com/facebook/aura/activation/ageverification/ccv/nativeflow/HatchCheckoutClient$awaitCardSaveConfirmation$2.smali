.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;
.super LX/DRu;
.source ""

# interfaces
.implements LX/JDN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LX/DRu;",
        "LX/JDN<",
        "LX/1EL;",
        "LX/2M4<",
        "-",
        "Ljava/lang/String;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutClient$awaitCardSaveConfirmation$2"
    f = "HatchCheckoutClient.kt"
    l = {
        0x1a5,
        0x1a7,
        0x1a8
    }
    m = "invokeSuspend"
    v = 0x2
.end annotation


# instance fields
.field public final synthetic $charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

.field public L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 1
    .line 2
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    invoke-direct {p0, v0, p3}, LX/DRu;-><init>(ILX/2M4;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;LX/2M4;)LX/2M4;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "LX/2M4<",
            "*>;)",
            "LX/2M4<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 3
    .line 4
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p0, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "LX/2M4<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    invoke-virtual {p0, p1, p2}, LX/DrA;->create(Ljava/lang/Object;LX/2M4;)LX/2M4;

    .line 1
    .line 2
    .line 3
    move-result-object p1

    .line 4
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;

    .line 5
    .line 6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    check-cast p1, LX/1EL;

    .line 268435457
    .line 268435458
    check-cast p2, LX/2M4;

    .line 268435459
    .line 268435460
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->invoke(LX/1EL;LX/2M4;)Ljava/lang/Object;

    .line 268435461
    .line 268435462
    .line 268435463
    move-result-object p0

    .line 268435464
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    sget-object v5, LX/2PB;->A02:LX/2PB;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->label:I

    .line 3
    .line 4
    const/4 v4, 0x3

    .line 5
    const/4 v3, 0x2

    .line 6
    const/4 v0, 0x1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    if-eq v1, v0, :cond_1

    .line 10
    .line 11
    if-eq v1, v3, :cond_3

    .line 12
    .line 13
    if-eq v1, v4, :cond_1

    .line 14
    .line 15
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 16
    .line 17
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 18
    .line 19
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw v0

    .line 23
    :cond_0
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 27
    .line 28
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 29
    .line 30
    iput v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->label:I

    .line 31
    .line 32
    :goto_0
    invoke-static {v2, v1, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->access$fetchCardActionState(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;LX/2M4;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    if-ne p1, v5, :cond_2

    .line 37
    .line 38
    return-object v5

    .line 39
    :cond_1
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_2
    const-string v0, "SUCCESS"

    .line 43
    .line 44
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_5

    .line 49
    .line 50
    const-string v0, "FAILURE"

    .line 51
    .line 52
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_5

    .line 57
    .line 58
    const/4 v0, 0x0

    .line 59
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->L$0:Ljava/lang/Object;

    .line 60
    .line 61
    iput v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->label:I

    .line 62
    .line 63
    const-wide/16 v0, 0x3e8

    .line 64
    .line 65
    invoke-static {v0, v1, p0}, LX/DSi;->A01(JLX/2M4;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-ne v0, v5, :cond_4

    .line 70
    .line 71
    return-object v5

    .line 72
    :cond_3
    invoke-static {p1}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_4
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 76
    .line 77
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->$charge:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCharge;

    .line 78
    .line 79
    const/4 v0, 0x0

    .line 80
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->L$0:Ljava/lang/Object;

    .line 81
    .line 82
    iput v4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$awaitCardSaveConfirmation$2;->label:I

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_5
    return-object p1
.end method
