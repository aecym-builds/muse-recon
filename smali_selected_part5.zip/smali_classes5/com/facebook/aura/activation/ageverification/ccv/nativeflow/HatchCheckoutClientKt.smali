.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final CARD_ACTION_STATE_FAILURE:Ljava/lang/String; = "FAILURE"

.field public static final CARD_ACTION_STATE_SUCCESS:Ljava/lang/String; = "SUCCESS"

.field public static final CARD_SAVE_CONFIRMATION_POLL_INTERVAL_MS:J = 0x3e8L

.field public static final CARD_SAVE_CONFIRMATION_TIMEOUT_MS:J = 0x61a8L

.field public static final CARD_SAVE_FINAL_CHECK_TIMEOUT_MS:J = 0x1388L

.field public static final CHECKOUT_STATUS_PENDING:Ljava/lang/String; = "PENDING"

.field public static final CHECKOUT_STATUS_SUCCESS:Ljava/lang/String; = "SUCCESS"

.field public static final COMPONENT_PAYMENT_METHOD:Ljava/lang/String; = "PAYMENT_METHOD"

.field public static final CONTAINER_MODE_LIVE:Ljava/lang/String; = "LIVE"

.field public static final CREDENTIAL_TYPE_CARD:Ljava/lang/String; = "CREDIT_CARD"

.field public static final FINALIZE_AFTER_CHALLENGE_TIMEOUT_MS:J = 0x4e20L

.field public static final HTTP_CONFLICT:I = 0x199

.field public static final HTTP_REQUEST_TIMEOUT:I = 0x198

.field public static final HTTP_TOO_MANY_REQUESTS:I = 0x1ad

.field public static final MUTATION_TYPE_CREATE:Ljava/lang/String; = "CREATE"

.field public static final OTC_TYPE_CARD:Ljava/lang/String; = "card"

.field public static final PAYMENT_PRODUCT_ID:Ljava/lang/String; = "766358168544755"

.field public static final PAYMENT_TYPE_ECP:Ljava/lang/String; = "ECP"

.field public static final RECEIVER_ID:Ljava/lang/String; = "352501280694489"

.field public static final TAG:Ljava/lang/String; = "HatchCheckoutClient"

.field public static final UFAC_CARD_ALREADY_VERIFIED_PROBLEM:Ljava/lang/String; = "urn:meta:hatch:checkout:ufac-card-already-verified"


# direct methods
.method public static final acceptedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;->components:Ljava/util/List;

    .line 1
    .line 2
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    move-object v0, v2

    .line 18
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 19
    .line 20
    iget-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->type:Ljava/lang/String;

    .line 21
    .line 22
    const-string v0, "PAYMENT_METHOD"

    .line 23
    .line 24
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    :cond_1
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;

    .line 31
    .line 32
    if-eqz v2, :cond_2

    .line 33
    .line 34
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutComponentJson;->supported_cc_types:Ljava/util/List;

    .line 35
    .line 36
    if-nez v0, :cond_3

    .line 37
    .line 38
    :cond_2
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 39
    .line 40
    :cond_3
    return-object v0
.end method

.method public static final synthetic access$acceptedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)Ljava/util/List;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->acceptedCardTypes(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitResponseJson;)Ljava/util/List;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final synthetic access$isCardAlreadyVerified(Ljava/lang/Throwable;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->isCardAlreadyVerified(Ljava/lang/Throwable;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$isFinalClientError(Ljava/lang/Throwable;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->isFinalClientError(Ljava/lang/Throwable;)Z

    .line 1
    .line 2
    .line 3
    move-result p0

    .line 4
    return p0
.end method

.method public static final synthetic access$toUnavailableReason(Ljava/lang/Throwable;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClientKt;->toUnavailableReason(Ljava/lang/Throwable;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method

.method public static final isCardAlreadyVerified(Ljava/lang/Throwable;)Z
    .locals 3

    .line 0
    instance-of v0, p0, Lcom/facebook/aura/json/NetworkException;

    .line 1
    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    move-object v0, p0

    .line 6
    check-cast v0, Lcom/facebook/aura/json/NetworkException;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget v2, v0, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 11
    .line 12
    const/16 v0, 0x199

    .line 13
    .line 14
    if-ne v2, v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, Lcom/facebook/aura/json/HatchProblemJsonKt;->hatchProblemOf(Ljava/lang/String;)Lcom/facebook/aura/json/HatchProblemJson;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v1, v0, Lcom/facebook/aura/json/HatchProblemJson;->type:Ljava/lang/String;

    .line 27
    .line 28
    :cond_0
    const-string v0, "urn:meta:hatch:checkout:ufac-card-already-verified"

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    const/4 v0, 0x1

    .line 35
    if-nez v1, :cond_2

    .line 36
    .line 37
    :cond_1
    const/4 v0, 0x0

    .line 38
    :cond_2
    return v0
.end method

.method public static final isFinalClientError(Ljava/lang/Throwable;)Z
    .locals 3

    .line 0
    instance-of v0, p0, Lcom/facebook/aura/json/NetworkException;

    .line 1
    .line 2
    if-eqz v0, :cond_1

    .line 3
    .line 4
    check-cast p0, Lcom/facebook/aura/json/NetworkException;

    .line 5
    .line 6
    :goto_0
    const/4 v2, 0x0

    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    iget v1, p0, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 10
    .line 11
    const/16 v0, 0x190

    .line 12
    .line 13
    if-gt v0, v1, :cond_0

    .line 14
    .line 15
    const/16 v0, 0x1f4

    .line 16
    .line 17
    if-ge v1, v0, :cond_0

    .line 18
    .line 19
    const/16 v0, 0x198

    .line 20
    .line 21
    if-eq v1, v0, :cond_0

    .line 22
    .line 23
    const/16 v0, 0x1ad

    .line 24
    .line 25
    if-eq v1, v0, :cond_0

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    :cond_0
    return v2

    .line 29
    :cond_1
    const/4 p0, 0x0

    .line 30
    goto :goto_0
.end method

.method public static final toUnavailableReason(Ljava/lang/Throwable;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;
    .locals 1

    .line 0
    instance-of v0, p0, Lcom/facebook/aura/json/NetworkException;

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    check-cast p0, Lcom/facebook/aura/json/NetworkException;

    .line 5
    .line 6
    if-eqz p0, :cond_0

    .line 7
    .line 8
    iget p0, p0, Lcom/facebook/aura/json/NetworkException;->httpResponseCode:I

    .line 9
    .line 10
    const/4 v0, -0x1

    .line 11
    if-ne p0, v0, :cond_0

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;->TIMEOUT:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;->SERVER_ERROR:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutUnavailableReason;

    .line 17
    .line 18
    return-object v0
.end method
