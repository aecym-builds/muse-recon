.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$Companion;


# instance fields
.field public final amount:Ljava/lang/String;

.field public final card_first_6:Ljava/lang/String;

.field public final card_last_4:Ljava/lang/String;

.field public final country_code:Ljava/lang/String;

.field public final currency_code:Ljava/lang/String;

.field public final expiry_month:Ljava/lang/String;

.field public final expiry_year:Ljava/lang/String;

.field public final mutation_type:Ljava/lang/String;

.field public final order_id:Ljava/lang/String;

.field public final otc_session_id:Ljava/lang/String;

.field public final otc_type:Ljava/lang/String;

.field public final platform_trust_token:Ljava/lang/String;

.field public final product_id:Ljava/lang/String;

.field public final receiver_id:Ljava/lang/String;

.field public final session_id:Ljava/lang/String;

.field public final zip:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 0
    const v1, 0xffff

    .line 1
    .line 2
    .line 3
    and-int v0, p1, v1

    .line 4
    .line 5
    if-eq v1, v0, :cond_0

    .line 6
    .line 7
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson$$serializer;->descriptor:LX/Da5;

    .line 8
    .line 9
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 10
    .line 11
    .line 12
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    throw v0

    .line 17
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 23
    .line 24
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 25
    .line 26
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 27
    .line 28
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 29
    .line 30
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 31
    .line 32
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 33
    .line 34
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 35
    .line 36
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 37
    .line 38
    iput-object p11, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 39
    .line 40
    iput-object p12, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 41
    .line 42
    iput-object p13, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 43
    .line 44
    move-object/from16 v0, p14

    .line 45
    .line 46
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 47
    .line 48
    move-object/from16 v0, p15

    .line 49
    .line 50
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 51
    .line 52
    move-object/from16 v0, p16

    .line 53
    .line 54
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 55
    .line 56
    move-object/from16 v0, p17

    .line 57
    .line 58
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 59
    .line 60
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 18

    .line 268435456
    move-object/from16 v12, p5

    .line 268435457
    .line 268435458
    move-object/from16 v14, p3

    .line 268435459
    .line 268435460
    move-object/from16 v13, p4

    .line 268435461
    .line 268435462
    move-object/from16 v17, p1

    .line 268435463
    .line 268435464
    move-object/from16 v16, p2

    .line 268435465
    .line 268435466
    move-object/from16 v1, v17

    .line 268435467
    .line 268435468
    move-object/from16 v0, v16

    .line 268435469
    .line 268435470
    invoke-static {v1, v0, v14, v13, v12}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435471
    .line 268435472
    .line 268435473
    move-object/from16 v10, p7

    .line 268435474
    .line 268435475
    move-object/from16 v11, p6

    .line 268435476
    .line 268435477
    invoke-static {v11, v10}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 268435478
    .line 268435479
    .line 268435480
    const/4 v0, 0x7

    .line 268435481
    move-object/from16 v9, p8

    .line 268435482
    .line 268435483
    invoke-static {v9, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435484
    .line 268435485
    .line 268435486
    const/16 v0, 0x8

    .line 268435487
    .line 268435488
    move-object/from16 v6, p11

    .line 268435489
    .line 268435490
    move-object/from16 v5, p12

    .line 268435491
    .line 268435492
    move-object/from16 v8, p9

    .line 268435493
    .line 268435494
    move-object/from16 v7, p10

    .line 268435495
    .line 268435496
    invoke-static {v8, v7, v6, v5, v0}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435497
    .line 268435498
    .line 268435499
    const/16 v0, 0xc

    .line 268435500
    .line 268435501
    move-object/from16 v2, p15

    .line 268435502
    .line 268435503
    move-object/from16 v4, p13

    .line 268435504
    .line 268435505
    move-object/from16 v3, p14

    .line 268435506
    .line 268435507
    invoke-static {v4, v3, v2, v0}, LX/Bi9;->A0I(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 268435508
    .line 268435509
    .line 268435510
    const/16 v0, 0xf

    .line 268435511
    .line 268435512
    move-object/from16 v1, p16

    .line 268435513
    .line 268435514
    invoke-static {v1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 268435515
    .line 268435516
    .line 268435517
    move-object/from16 v15, p0

    .line 268435518
    .line 268435519
    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    .line 268435520
    .line 268435521
    .line 268435522
    move-object/from16 v0, v17

    .line 268435523
    .line 268435524
    iput-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 268435525
    .line 268435526
    move-object/from16 v0, v16

    .line 268435527
    .line 268435528
    iput-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 268435529
    .line 268435530
    iput-object v14, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 268435531
    .line 268435532
    iput-object v13, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 268435533
    .line 268435534
    iput-object v12, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 268435535
    .line 268435536
    iput-object v11, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 268435537
    .line 268435538
    iput-object v10, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 268435539
    .line 268435540
    iput-object v9, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 268435541
    .line 268435542
    iput-object v8, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 268435543
    .line 268435544
    iput-object v7, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 268435545
    .line 268435546
    iput-object v6, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 268435547
    .line 268435548
    iput-object v5, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 268435549
    .line 268435550
    iput-object v4, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 268435551
    .line 268435552
    iput-object v3, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 268435553
    .line 268435554
    iput-object v2, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 268435555
    .line 268435556
    iput-object v1, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 268435557
    .line 268435558
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;
    .locals 32

    .line 1348701
    move-object/from16 v31, p1

    move-object/from16 v30, p2

    move-object/from16 v16, p3

    move-object/from16 v14, p4

    move-object/from16 v13, p5

    move-object/from16 v12, p6

    move-object/from16 v11, p7

    move-object/from16 v10, p8

    move-object/from16 v9, p9

    move-object/from16 v8, p10

    move-object/from16 v7, p11

    move-object/from16 v6, p12

    move-object/from16 v5, p13

    move-object/from16 v4, p14

    move-object/from16 v3, p15

    move/from16 v2, p17

    move-object/from16 v1, p16

    and-int/lit8 v0, p17, 0x1

    move-object/from16 v15, p0

    if-eqz v0, :cond_0

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    move-object/from16 v31, v0

    :cond_0
    and-int/lit8 v0, p17, 0x2

    if-eqz v0, :cond_1

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    move-object/from16 v30, v0

    :cond_1
    and-int/lit8 v0, p17, 0x4

    if-eqz v0, :cond_2

    iget-object v0, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    move-object/from16 v16, v0

    :cond_2
    and-int/lit8 v0, p17, 0x8

    if-eqz v0, :cond_3

    iget-object v14, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    :cond_3
    and-int/lit8 v0, p17, 0x10

    if-eqz v0, :cond_4

    iget-object v13, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    :cond_4
    and-int/lit8 v0, p17, 0x20

    if-eqz v0, :cond_5

    iget-object v12, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    :cond_5
    and-int/lit8 v0, p17, 0x40

    if-eqz v0, :cond_6

    iget-object v11, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    :cond_6
    and-int/lit16 v0, v2, 0x80

    if-eqz v0, :cond_7

    iget-object v10, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    :cond_7
    and-int/lit16 v0, v2, 0x100

    if-eqz v0, :cond_8

    iget-object v9, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    :cond_8
    and-int/lit16 v0, v2, 0x200

    if-eqz v0, :cond_9

    iget-object v8, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    :cond_9
    and-int/lit16 v0, v2, 0x400

    if-eqz v0, :cond_a

    iget-object v7, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    :cond_a
    and-int/lit16 v0, v2, 0x800

    if-eqz v0, :cond_b

    iget-object v6, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    :cond_b
    and-int/lit16 v0, v2, 0x1000

    if-eqz v0, :cond_c

    iget-object v5, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    :cond_c
    and-int/lit16 v0, v2, 0x2000

    if-eqz v0, :cond_d

    iget-object v4, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    :cond_d
    and-int/lit16 v0, v2, 0x4000

    if-eqz v0, :cond_e

    iget-object v3, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    :cond_e
    const v0, 0x8000

    and-int v2, p17, v0

    if-eqz v2, :cond_f

    iget-object v1, v15, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    :cond_f
    move-object/from16 v28, v3

    move-object/from16 v29, v1

    move-object/from16 v25, v6

    move-object/from16 v26, v5

    move-object/from16 v27, v4

    move-object/from16 v22, v9

    move-object/from16 v23, v8

    move-object/from16 v24, v7

    move-object/from16 v19, v12

    move-object/from16 v20, v11

    move-object/from16 v21, v10

    move-object/from16 v17, v14

    move-object/from16 v18, v13

    move-object v13, v15

    move-object/from16 v14, v31

    move-object/from16 v15, v30

    invoke-virtual/range {v13 .. v29}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;LX/Da8;LX/Da5;)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x3

    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 26
    .line 27
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 28
    .line 29
    .line 30
    const/4 v1, 0x5

    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    const/4 v1, 0x6

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 38
    .line 39
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 40
    .line 41
    .line 42
    const/4 v1, 0x7

    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 44
    .line 45
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 46
    .line 47
    .line 48
    const/16 v1, 0x8

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 51
    .line 52
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 53
    .line 54
    .line 55
    const/16 v1, 0x9

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 60
    .line 61
    .line 62
    const/16 v1, 0xa

    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 65
    .line 66
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 67
    .line 68
    .line 69
    const/16 v1, 0xb

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 72
    .line 73
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 74
    .line 75
    .line 76
    const/16 v1, 0xc

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 79
    .line 80
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 81
    .line 82
    .line 83
    const/16 v1, 0xd

    .line 84
    .line 85
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 86
    .line 87
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 88
    .line 89
    .line 90
    const/16 v1, 0xe

    .line 91
    .line 92
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 93
    .line 94
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 95
    .line 96
    .line 97
    const/16 v1, 0xf

    .line 98
    .line 99
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 100
    .line 101
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 102
    .line 103
    .line 104
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component12()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component13()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component14()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component15()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component16()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;
    .locals 15

    .line 0
    move-object/from16 v11, p4

    .line 1
    .line 2
    move-object/from16 v10, p5

    .line 3
    .line 4
    move-object/from16 v13, p2

    .line 5
    .line 6
    move-object/from16 v12, p3

    .line 7
    .line 8
    move-object/from16 v0, p1

    .line 9
    .line 10
    invoke-static {v0, v13, v12, v11, v10}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    move-object/from16 v14, p6

    .line 14
    .line 15
    move-object/from16 v9, p7

    .line 16
    .line 17
    invoke-static {v14, v9}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x7

    .line 21
    move-object/from16 v8, p8

    .line 22
    .line 23
    invoke-static {v8, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 24
    .line 25
    .line 26
    const/16 v0, 0x8

    .line 27
    .line 28
    move-object/from16 v4, p12

    .line 29
    .line 30
    move-object/from16 v6, p10

    .line 31
    .line 32
    move-object/from16 v5, p11

    .line 33
    .line 34
    move-object/from16 v7, p9

    .line 35
    .line 36
    invoke-static {v7, v6, v5, v4, v0}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 37
    .line 38
    .line 39
    const/16 v0, 0xc

    .line 40
    .line 41
    move-object/from16 v2, p14

    .line 42
    .line 43
    move-object/from16 v1, p15

    .line 44
    .line 45
    move-object/from16 v3, p13

    .line 46
    .line 47
    invoke-static {v3, v2, v1, v0}, LX/Bi9;->A0I(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 48
    .line 49
    .line 50
    const/16 p0, 0xf

    .line 51
    .line 52
    move-object/from16 v0, p16

    .line 53
    .line 54
    invoke-static {v0, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 55
    .line 56
    .line 57
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 58
    .line 59
    invoke-direct/range {p0 .. p16}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 91
    .line 92
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 93
    .line 94
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_0

    .line 109
    .line 110
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    if-eqz v0, :cond_0

    .line 119
    .line 120
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 121
    .line 122
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 123
    .line 124
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_0

    .line 129
    .line 130
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 131
    .line 132
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 133
    .line 134
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_0

    .line 139
    .line 140
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 141
    .line 142
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 143
    .line 144
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_0

    .line 149
    .line 150
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 151
    .line 152
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 153
    .line 154
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-eqz v0, :cond_0

    .line 159
    .line 160
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 161
    .line 162
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 163
    .line 164
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    if-nez v0, :cond_1

    .line 169
    .line 170
    :cond_0
    return v2

    .line 171
    :cond_1
    return v3
.end method

.method public final getAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCard_first_6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCard_last_4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCountry_code()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency_code()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExpiry_month()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExpiry_year()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getMutation_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrder_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_session_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlatform_trust_token()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getProduct_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReceiver_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSession_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getZip()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->mutation_type:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->order_id:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->amount:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->currency_code:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->product_id:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->receiver_id:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_first_6:Ljava/lang/String;

    .line 51
    .line 52
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->card_last_4:Ljava/lang/String;

    .line 57
    .line 58
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_month:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->expiry_year:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->zip:Ljava/lang/String;

    .line 75
    .line 76
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->country_code:Ljava/lang/String;

    .line 81
    .line 82
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_session_id:Ljava/lang/String;

    .line 87
    .line 88
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutCredentialRequestJson;->otc_type:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    add-int/2addr v1, v0

    .line 99
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
