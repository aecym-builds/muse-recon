.class public final synthetic Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;

    .line 6
    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    const-string v0, "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutInitRequestJson"

    .line 10
    .line 11
    new-instance v3, LX/DZp;

    .line 12
    .line 13
    invoke-direct {v3, v0, v2, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "session_id"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "product_id"

    .line 23
    .line 24
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "receiver_id"

    .line 28
    .line 29
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "amount"

    .line 33
    .line 34
    const/4 v1, 0x1

    .line 35
    invoke-virtual {v3, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    const-string v0, "currency"

    .line 39
    .line 40
    invoke-virtual {v3, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "otc_session_id"

    .line 44
    .line 45
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    const-string v0, "otc_type"

    .line 49
    .line 50
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    const-string v0, "verification_purpose"

    .line 54
    .line 55
    invoke-virtual {v3, v0, v1}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 56
    .line 57
    .line 58
    sput-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 59
    .line 60
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v0, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    move-object v1, v0

    .line 15
    move-object v2, v0

    .line 16
    move-object v5, v0

    .line 17
    move-object v6, v0

    .line 18
    filled-new-array/range {v0 .. v7}, [LX/DZ7;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;
    .locals 18

    .line 0
    const/4 v6, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v6}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v5}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    const/4 v9, 0x7

    .line 13
    const/4 v8, 0x6

    .line 14
    const/4 v7, 0x5

    .line 15
    const/4 v3, 0x3

    .line 16
    const/4 v2, 0x4

    .line 17
    const/4 v1, 0x2

    .line 18
    const/4 v11, 0x0

    .line 19
    move-object/from16 p0, v11

    .line 20
    .line 21
    move-object v12, v11

    .line 22
    move-object v13, v11

    .line 23
    move-object v14, v11

    .line 24
    move-object v15, v11

    .line 25
    move-object/from16 v16, v11

    .line 26
    .line 27
    move-object/from16 v17, v11

    .line 28
    .line 29
    const/4 v10, 0x0

    .line 30
    :goto_0
    invoke-interface {v4, v5}, LX/Da7;->A8S(LX/Da5;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 38
    .line 39
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 40
    .line 41
    .line 42
    throw v1

    .line 43
    :pswitch_0
    invoke-interface {v4, v5, v6}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v11

    .line 47
    or-int/lit8 v10, v10, 0x1

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :pswitch_1
    const/4 v0, 0x1

    .line 51
    invoke-interface {v4, v5, v0}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v12

    .line 55
    or-int/lit8 v10, v10, 0x2

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :pswitch_2
    invoke-interface {v4, v5, v1}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v13

    .line 62
    or-int/lit8 v10, v10, 0x4

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :pswitch_3
    invoke-static {v5, v4, v3}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v14

    .line 69
    or-int/lit8 v10, v10, 0x8

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :pswitch_4
    invoke-static {v5, v4, v2}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v15

    .line 76
    or-int/lit8 v10, v10, 0x10

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :pswitch_5
    invoke-interface {v4, v5, v7}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v16

    .line 83
    or-int/lit8 v10, v10, 0x20

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :pswitch_6
    invoke-interface {v4, v5, v8}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v17

    .line 90
    or-int/lit8 v10, v10, 0x40

    .line 91
    .line 92
    goto :goto_0

    .line 93
    :pswitch_7
    invoke-static {v5, v4, v9}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    or-int/lit16 v10, v10, 0x80

    .line 98
    .line 99
    goto :goto_0

    .line 100
    :pswitch_8
    invoke-interface {v4, v5}, LX/Da7;->AAi(LX/Da5;)V

    .line 101
    .line 102
    .line 103
    const/16 p1, 0x0

    .line 104
    .line 105
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 106
    .line 107
    invoke-direct/range {v9 .. v19}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V

    .line 108
    .line 109
    .line 110
    return-object v9

    .line 111
    nop

    .line 112
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_8
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutInitRequestJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
