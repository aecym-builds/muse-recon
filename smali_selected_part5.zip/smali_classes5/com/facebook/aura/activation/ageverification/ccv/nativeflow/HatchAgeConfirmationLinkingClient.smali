.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method private final formatMinorAmount(ILjava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 0
    :try_start_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 1
    .line 2
    invoke-virtual {p2, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-static {v0}, Ljava/util/Currency;->getInstance(Ljava/lang/String;)Ljava/util/Currency;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0}, Ljava/util/Currency;->getDefaultFractionDigits()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    goto :goto_0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    :catchall_0
    move-exception v0

    .line 20
    new-instance v2, LX/2PH;

    .line 21
    .line 22
    invoke-direct {v2, v0}, LX/2PH;-><init>(Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    instance-of v0, v2, LX/2PH;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    move-object v2, v1

    .line 31
    :cond_0
    check-cast v2, Ljava/lang/Number;

    .line 32
    .line 33
    if-eqz v2, :cond_2

    .line 34
    .line 35
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-gez v0, :cond_1

    .line 40
    .line 41
    move-object v2, v1

    .line 42
    :cond_1
    if-eqz v2, :cond_2

    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    if-nez p0, :cond_3

    .line 49
    .line 50
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    :cond_2
    return-object v1

    .line 55
    :cond_3
    const/4 v1, 0x1

    .line 56
    const/4 v0, 0x0

    .line 57
    :goto_1
    if-ge v0, p0, :cond_4

    .line 58
    .line 59
    mul-int/lit8 v1, v1, 0xa

    .line 60
    .line 61
    add-int/lit8 v0, v0, 0x1

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_4
    div-int v2, p1, v1

    .line 65
    .line 66
    rem-int/2addr p1, v1

    .line 67
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-static {v0, p0}, LX/AdT;->A0T(Ljava/lang/String;I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    const-string v0, "."

    .line 76
    .line 77
    invoke-static {v2, v0, v1}, LX/Gi8;->A0K(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    return-object v1
.end method

.method private final toChargeParts(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;)LX/IAg;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;",
            ")",
            "LX/IAg<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    const/4 v4, 0x0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object v3, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;->currency:Ljava/lang/String;

    .line 4
    .line 5
    if-eqz v3, :cond_0

    .line 6
    .line 7
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget v1, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;->minor_value:I

    .line 14
    .line 15
    if-ltz v1, :cond_0

    .line 16
    .line 17
    iget-object v2, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;->display_amount:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    invoke-direct {p0, v1, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->formatMinorAmount(ILjava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    new-instance v0, LX/IAg;

    .line 34
    .line 35
    invoke-direct {v0, v1, v3, v2}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    return-object v0

    .line 39
    :cond_0
    new-instance v0, LX/IAg;

    .line 40
    .line 41
    invoke-direct {v0, v4, v4, v4}, LX/IAg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return-object v0
.end method

.method private final toDomain(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptionsResponseJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;
    .locals 8

    .line 0
    iget-object v2, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptionsResponseJson;->age_confirmation_screen:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;

    .line 1
    .line 2
    if-eqz v2, :cond_0

    .line 3
    .line 4
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    :cond_0
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptionsResponseJson;->linkable_account_types:Ljava/util/List;

    .line 9
    .line 10
    :cond_1
    sget-object v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType$Companion;

    .line 11
    .line 12
    new-instance v4, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 15
    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_3

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v3, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_3
    const/4 v1, 0x0

    .line 44
    if-eqz v2, :cond_8

    .line 45
    .line 46
    iget-object v0, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 47
    .line 48
    if-eqz v0, :cond_8

    .line 49
    .line 50
    iget-object v0, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;->amount:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;

    .line 51
    .line 52
    :goto_1
    invoke-direct {p0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->toChargeParts(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvAmountJson;)LX/IAg;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iget-object v7, v0, LX/IAg;->first:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v7, Ljava/lang/String;

    .line 59
    .line 60
    iget-object p0, v0, LX/IAg;->second:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast p0, Ljava/lang/String;

    .line 63
    .line 64
    iget-object p1, v0, LX/IAg;->third:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast p1, Ljava/lang/String;

    .line 67
    .line 68
    if-eqz v2, :cond_4

    .line 69
    .line 70
    iget-object v5, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 71
    .line 72
    if-eqz v5, :cond_4

    .line 73
    .line 74
    invoke-static {v5}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_5

    .line 79
    .line 80
    :cond_4
    move-object v5, v1

    .line 81
    if-eqz v2, :cond_6

    .line 82
    .line 83
    :cond_5
    iget-object v6, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 84
    .line 85
    if-eqz v6, :cond_6

    .line 86
    .line 87
    invoke-static {v6}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_7

    .line 92
    .line 93
    :cond_6
    move-object v6, v1

    .line 94
    :cond_7
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 95
    .line 96
    invoke-direct/range {v3 .. v9}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    return-object v3

    .line 100
    :cond_8
    move-object v0, v1

    .line 101
    goto :goto_1
.end method


# virtual methods
.method public final completeWebAuth(Ljava/lang/String;LX/2M4;)Ljava/lang/Object;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v4, p2

    .line 1
    .line 2
    instance-of v0, v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;

    .line 3
    .line 4
    if-eqz v0, :cond_3

    .line 5
    .line 6
    move-object v3, v4

    .line 7
    check-cast v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;

    .line 8
    .line 9
    iget v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_3

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v2, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v1, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->label:I

    .line 25
    .line 26
    const/4 v12, 0x1

    .line 27
    if-eqz v0, :cond_2

    .line 28
    .line 29
    if-ne v0, v12, :cond_5

    .line 30
    .line 31
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v2, LX/2PJ;

    .line 35
    .line 36
    iget-object v2, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    instance-of v1, v2, LX/2PH;

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    move-object v2, v0

    .line 44
    :cond_1
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthCompletionResponseJson;

    .line 45
    .line 46
    if-eqz v2, :cond_4

    .line 47
    .line 48
    iget-object v1, v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthCompletionResponseJson;->next_action:Ljava/lang/String;

    .line 49
    .line 50
    if-eqz v1, :cond_4

    .line 51
    .line 52
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction$Companion;

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction$Companion;->fromWire(Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingNextAction;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    return-object v1

    .line 59
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 63
    .line 64
    sget-object v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingWebAuthCompletion;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingWebAuthCompletion;

    .line 65
    .line 66
    new-instance v9, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthCompletionRequestJson;

    .line 67
    .line 68
    move-object/from16 v0, p1

    .line 69
    .line 70
    invoke-direct {v9, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthCompletionRequestJson;-><init>(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    sget-object v10, Lcom/facebook/aura/network/http/RequestType;->POST:Lcom/facebook/aura/network/http/RequestType;

    .line 74
    .line 75
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 76
    .line 77
    .line 78
    move-result-object v11

    .line 79
    sget-object p0, LX/0wX;->A00:LX/0wX;

    .line 80
    .line 81
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$$inlined$executeStefiRequest-1iavgos$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$$inlined$executeStefiRequest-1iavgos$default$1;

    .line 82
    .line 83
    sget-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$$inlined$executeStefiRequest-1iavgos$default$2;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$$inlined$executeStefiRequest-1iavgos$default$2;

    .line 84
    .line 85
    const/4 v7, 0x0

    .line 86
    const/4 v13, 0x0

    .line 87
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$0:Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$1:Ljava/lang/Object;

    .line 90
    .line 91
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$2:Ljava/lang/Object;

    .line 92
    .line 93
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$3:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$4:Ljava/lang/Object;

    .line 96
    .line 97
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$5:Ljava/lang/Object;

    .line 98
    .line 99
    iput-object v13, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->L$6:Ljava/lang/Object;

    .line 100
    .line 101
    iput v12, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->I$0:I

    .line 102
    .line 103
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->I$1:I

    .line 104
    .line 105
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->I$2:I

    .line 106
    .line 107
    iput v7, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->I$3:I

    .line 108
    .line 109
    iput v12, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;->label:I

    .line 110
    .line 111
    move v14, v7

    .line 112
    move-object v15, v13

    .line 113
    move-object/from16 v16, v13

    .line 114
    .line 115
    move/from16 v17, v7

    .line 116
    .line 117
    move/from16 p1, v7

    .line 118
    .line 119
    move-object/from16 p2, v3

    .line 120
    .line 121
    invoke-virtual/range {v4 .. v20}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeStefiRequestWith-Y5yfBNE(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Ljava/lang/Object;Lcom/facebook/aura/network/http/RequestType;Ljava/util/Map;ZLcom/facebook/aura/network/transport/HatchHttpRequestAttemptObserverFactory;ZLjava/lang/Long;LX/AHE;ZLjava/util/Set;ZLX/2M4;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    if-ne v2, v1, :cond_0

    .line 126
    .line 127
    return-object v1

    .line 128
    :cond_3
    new-instance v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;

    .line 129
    .line 130
    move-object/from16 v0, p0

    .line 131
    .line 132
    invoke-direct {v3, v0, v4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$completeWebAuth$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;LX/2M4;)V

    .line 133
    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_4
    return-object v0

    .line 137
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 138
    .line 139
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 140
    .line 141
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    throw v0
.end method

.method public final fetchLinkingOptions(LX/2M4;)Ljava/lang/Object;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object/from16 v3, p1

    .line 1
    .line 2
    instance-of v0, v3, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;

    .line 3
    .line 4
    if-eqz v0, :cond_4

    .line 5
    .line 6
    move-object v14, v3

    .line 7
    check-cast v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;

    .line 8
    .line 9
    iget v2, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->label:I

    .line 10
    .line 11
    const/high16 v1, -0x80000000

    .line 12
    .line 13
    and-int v0, v2, v1

    .line 14
    .line 15
    if-eqz v0, :cond_4

    .line 16
    .line 17
    sub-int/2addr v2, v1

    .line 18
    iput v2, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->label:I

    .line 19
    .line 20
    :goto_0
    iget-object v2, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->result:Ljava/lang/Object;

    .line 21
    .line 22
    sget-object v3, LX/2PB;->A02:LX/2PB;

    .line 23
    .line 24
    iget v1, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->label:I

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    if-eqz v1, :cond_3

    .line 28
    .line 29
    if-ne v1, v0, :cond_5

    .line 30
    .line 31
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    check-cast v2, LX/2PJ;

    .line 35
    .line 36
    iget-object v2, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_0
    instance-of v1, v2, LX/2PH;

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    move-object v2, v0

    .line 44
    :cond_1
    check-cast v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptionsResponseJson;

    .line 45
    .line 46
    if-eqz v2, :cond_2

    .line 47
    .line 48
    invoke-direct {p0, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;->toDomain(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptionsResponseJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingOptions;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :cond_2
    return-object v0

    .line 53
    :cond_3
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object v4, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 57
    .line 58
    sget-object v7, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingOptions;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingOptions;

    .line 59
    .line 60
    sget-object v8, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 61
    .line 62
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 63
    .line 64
    .line 65
    move-result-object v11

    .line 66
    sget-object v5, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 67
    .line 68
    const/4 v6, 0x0

    .line 69
    const/4 v9, 0x0

    .line 70
    iput-object v9, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->L$0:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object v9, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->L$1:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v9, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->L$2:Ljava/lang/Object;

    .line 75
    .line 76
    iput-object v9, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->L$3:Ljava/lang/Object;

    .line 77
    .line 78
    iput-object v9, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->L$4:Ljava/lang/Object;

    .line 79
    .line 80
    iput v0, v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;->label:I

    .line 81
    .line 82
    move-object v10, v9

    .line 83
    move-object v12, v11

    .line 84
    move-object v13, v9

    .line 85
    invoke-virtual/range {v4 .. v14}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    if-ne v2, v3, :cond_0

    .line 90
    .line 91
    return-object v3

    .line 92
    :cond_4
    new-instance v14, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;

    .line 93
    .line 94
    invoke-direct {v14, p0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchLinkingOptions$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;LX/2M4;)V

    .line 95
    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_5
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 99
    .line 100
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 101
    .line 102
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    throw v0
.end method

.method public final fetchWebAuthUrl(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;LX/2M4;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 0
    move-object v3, p2

    .line 1
    instance-of v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    move-object p2, v3

    .line 6
    check-cast p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;

    .line 7
    .line 8
    iget v2, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->label:I

    .line 9
    .line 10
    const/high16 v1, -0x80000000

    .line 11
    .line 12
    and-int v0, v2, v1

    .line 13
    .line 14
    if-eqz v0, :cond_3

    .line 15
    .line 16
    sub-int/2addr v2, v1

    .line 17
    iput v2, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->label:I

    .line 18
    .line 19
    :goto_0
    iget-object v2, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->result:Ljava/lang/Object;

    .line 20
    .line 21
    sget-object v4, LX/2PB;->A02:LX/2PB;

    .line 22
    .line 23
    iget v0, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->label:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    if-ne v0, v1, :cond_6

    .line 29
    .line 30
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    check-cast v2, LX/2PJ;

    .line 34
    .line 35
    iget-object v1, v2, LX/2PJ;->value:Ljava/lang/Object;

    .line 36
    .line 37
    :cond_0
    invoke-static {v1}, LX/2PJ;->A00(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-nez v0, :cond_5

    .line 42
    .line 43
    check-cast v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;

    .line 44
    .line 45
    iget-object v3, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v3, :cond_4

    .line 48
    .line 49
    invoke-static {v3}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_4

    .line 54
    .line 55
    iget-object v2, v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 56
    .line 57
    const/4 v1, 0x0

    .line 58
    if-eqz v2, :cond_1

    .line 59
    .line 60
    invoke-static {v2}, LX/AdT;->A0l(Ljava/lang/CharSequence;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-nez v0, :cond_1

    .line 65
    .line 66
    :goto_1
    new-instance v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;

    .line 67
    .line 68
    invoke-direct {v4, v3, v2}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Available;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    return-object v4

    .line 72
    :cond_1
    move-object v2, v1

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    invoke-static {v2}, LX/2PI;->A04(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    sget-object v5, Lcom/facebook/aura/network/http/HatchHttpApi;->INSTANCE:Lcom/facebook/aura/network/http/HatchHttpApi;

    .line 78
    .line 79
    invoke-virtual {p1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkableAccountType;->getWireValue()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    new-instance v8, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingWebAuth;

    .line 84
    .line 85
    invoke-direct {v8, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/CcvStefiPath$AgeConfirmationLinkingWebAuth;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    sget-object v9, Lcom/facebook/aura/network/http/RequestType;->GET:Lcom/facebook/aura/network/http/RequestType;

    .line 89
    .line 90
    invoke-static {}, LX/1HA;->A0H()LX/0Xj;

    .line 91
    .line 92
    .line 93
    move-result-object v12

    .line 94
    sget-object v6, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$$inlined$executeStefiRequest-eH_QyT8$default$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$$inlined$executeStefiRequest-eH_QyT8$default$1;

    .line 95
    .line 96
    const/4 v7, 0x0

    .line 97
    const/4 v10, 0x0

    .line 98
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$0:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$1:Ljava/lang/Object;

    .line 101
    .line 102
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$2:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$3:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$4:Ljava/lang/Object;

    .line 107
    .line 108
    iput-object v10, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->L$5:Ljava/lang/Object;

    .line 109
    .line 110
    iput v1, p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;->label:I

    .line 111
    .line 112
    move-object v11, v10

    .line 113
    move-object p0, v12

    .line 114
    move-object p1, v10

    .line 115
    invoke-virtual/range {v5 .. v15}, Lcom/facebook/aura/network/http/HatchHttpApi;->executeBodylessStefiRequestWith-LiYkppA(Lkotlin/jvm/functions/Function0;ZLcom/facebook/aura/network/api/StefiPath;Lcom/facebook/aura/network/http/RequestType;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;Ljava/util/Map;LX/AHE;LX/2M4;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    if-ne v1, v4, :cond_0

    .line 120
    .line 121
    return-object v4

    .line 122
    :cond_3
    new-instance p2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;

    .line 123
    .line 124
    invoke-direct {p2, p0, v3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient$fetchWebAuthUrl$1;-><init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationLinkingClient;LX/2M4;)V

    .line 125
    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_4
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$NotOffered;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$NotOffered;

    .line 129
    .line 130
    return-object v0

    .line 131
    :cond_5
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Failed;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResult$Failed;

    .line 132
    .line 133
    return-object v0

    .line 134
    :cond_6
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 135
    .line 136
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 137
    .line 138
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    throw v0
.end method
