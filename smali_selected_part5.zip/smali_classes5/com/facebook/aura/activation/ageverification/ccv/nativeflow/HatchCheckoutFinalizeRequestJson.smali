.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson$Companion;


# instance fields
.field public final amount:Ljava/lang/String;

.field public final country_code:Ljava/lang/String;

.field public final credential_id:Ljava/lang/String;

.field public final credential_type:Ljava/lang/String;

.field public final currency_code:Ljava/lang/String;

.field public final order_id:Ljava/lang/String;

.field public final otc_session_id:Ljava/lang/String;

.field public final otc_type:Ljava/lang/String;

.field public final pay_button_click_id:Ljava/lang/String;

.field public final payment_container_mode:Ljava/lang/String;

.field public final payment_product_id:Ljava/lang/String;

.field public final payment_request_id:Ljava/lang/String;

.field public final platform_trust_token:Ljava/lang/String;

.field public final receiver_id:Ljava/lang/String;

.field public final upl_session_id:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 0
    and-int/lit16 v0, p1, 0x7fff

    .line 1
    .line 2
    const/16 v1, 0x7fff

    .line 3
    .line 4
    if-eq v1, v0, :cond_0

    .line 5
    .line 6
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 9
    .line 10
    .line 11
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    throw v0

    .line 16
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 22
    .line 23
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 24
    .line 25
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 26
    .line 27
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 28
    .line 29
    iput-object p7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 30
    .line 31
    iput-object p8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 32
    .line 33
    iput-object p9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 34
    .line 35
    iput-object p10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 36
    .line 37
    iput-object p11, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 38
    .line 39
    iput-object p12, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 40
    .line 41
    iput-object p13, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 42
    .line 43
    move-object/from16 v0, p14

    .line 44
    .line 45
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 46
    .line 47
    move-object/from16 v0, p15

    .line 48
    .line 49
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 50
    .line 51
    move-object/from16 v0, p16

    .line 52
    .line 53
    iput-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 54
    .line 55
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16

    .line 269784093
    move-object/from16 v9, p5

    move-object/from16 v10, p4

    move-object/from16 v11, p3

    move-object/from16 v12, p2

    move-object/from16 v13, p1

    invoke-static {v13, v12, v11, v10, v9}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 269784094
    move-object/from16 v7, p7

    move-object/from16 v8, p6

    invoke-static {v8, v7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 269784095
    const/4 v0, 0x7

    move-object/from16 v6, p8

    invoke-static {v6, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    const/16 v0, 0x8

    .line 269784096
    move-object/from16 v3, p12

    move-object/from16 v4, p11

    move-object/from16 v5, p10

    move-object/from16 v14, p9

    invoke-static {v14, v5, v4, v3, v0}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 269784097
    const/16 v0, 0xc

    .line 269784098
    move-object/from16 v1, p15

    move-object/from16 v2, p14

    move-object/from16 v15, p13

    invoke-static {v15, v2, v1, v0}, LX/Bi9;->A0I(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 269784099
    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 269784100
    iput-object v13, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 269784101
    iput-object v12, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 269784102
    iput-object v11, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 269784103
    iput-object v10, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 269784104
    iput-object v9, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 269784105
    iput-object v8, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 269784106
    iput-object v7, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 269784107
    iput-object v6, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 269784108
    iput-object v14, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 269784109
    iput-object v5, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 269784110
    iput-object v4, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 269784111
    iput-object v3, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 269784112
    iput-object v15, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 269784113
    iput-object v2, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 269784114
    iput-object v1, v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;
    .locals 15

    .line 0
    move-object/from16 v14, p3

    .line 1
    .line 2
    move-object/from16 v13, p4

    .line 3
    .line 4
    move-object/from16 v12, p5

    .line 5
    .line 6
    move-object/from16 v11, p6

    .line 7
    .line 8
    move-object/from16 v10, p7

    .line 9
    .line 10
    move-object/from16 v9, p8

    .line 11
    .line 12
    move-object/from16 v8, p9

    .line 13
    .line 14
    move-object/from16 v7, p10

    .line 15
    .line 16
    move-object/from16 v6, p11

    .line 17
    .line 18
    move-object/from16 v5, p12

    .line 19
    .line 20
    move-object/from16 v4, p13

    .line 21
    .line 22
    move-object/from16 v3, p14

    .line 23
    .line 24
    move/from16 v2, p16

    .line 25
    .line 26
    move-object/from16 v1, p15

    .line 27
    .line 28
    and-int/lit8 v0, p16, 0x1

    .line 29
    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 33
    .line 34
    move-object/from16 p1, v0

    .line 35
    .line 36
    :cond_0
    and-int/lit8 v0, p16, 0x2

    .line 37
    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 41
    .line 42
    move-object/from16 p2, v0

    .line 43
    .line 44
    :cond_1
    and-int/lit8 v0, p16, 0x4

    .line 45
    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    iget-object v14, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 49
    .line 50
    :cond_2
    and-int/lit8 v0, p16, 0x8

    .line 51
    .line 52
    if-eqz v0, :cond_3

    .line 53
    .line 54
    iget-object v13, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 55
    .line 56
    :cond_3
    and-int/lit8 v0, p16, 0x10

    .line 57
    .line 58
    if-eqz v0, :cond_4

    .line 59
    .line 60
    iget-object v12, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 61
    .line 62
    :cond_4
    and-int/lit8 v0, p16, 0x20

    .line 63
    .line 64
    if-eqz v0, :cond_5

    .line 65
    .line 66
    iget-object v11, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 67
    .line 68
    :cond_5
    and-int/lit8 v0, p16, 0x40

    .line 69
    .line 70
    if-eqz v0, :cond_6

    .line 71
    .line 72
    iget-object v10, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 73
    .line 74
    :cond_6
    and-int/lit16 v0, v2, 0x80

    .line 75
    .line 76
    if-eqz v0, :cond_7

    .line 77
    .line 78
    iget-object v9, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 79
    .line 80
    :cond_7
    and-int/lit16 v0, v2, 0x100

    .line 81
    .line 82
    if-eqz v0, :cond_8

    .line 83
    .line 84
    iget-object v8, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 85
    .line 86
    :cond_8
    and-int/lit16 v0, v2, 0x200

    .line 87
    .line 88
    if-eqz v0, :cond_9

    .line 89
    .line 90
    iget-object v7, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 91
    .line 92
    :cond_9
    and-int/lit16 v0, v2, 0x400

    .line 93
    .line 94
    if-eqz v0, :cond_a

    .line 95
    .line 96
    iget-object v6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 97
    .line 98
    :cond_a
    and-int/lit16 v0, v2, 0x800

    .line 99
    .line 100
    if-eqz v0, :cond_b

    .line 101
    .line 102
    iget-object v5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 103
    .line 104
    :cond_b
    and-int/lit16 v0, v2, 0x1000

    .line 105
    .line 106
    if-eqz v0, :cond_c

    .line 107
    .line 108
    iget-object v4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 109
    .line 110
    :cond_c
    and-int/lit16 v0, v2, 0x2000

    .line 111
    .line 112
    if-eqz v0, :cond_d

    .line 113
    .line 114
    iget-object v3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 115
    .line 116
    :cond_d
    and-int/lit16 v0, v2, 0x4000

    .line 117
    .line 118
    if-eqz v0, :cond_e

    .line 119
    .line 120
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 121
    .line 122
    :cond_e
    move-object/from16 p15, v1

    .line 123
    .line 124
    move-object/from16 p13, v4

    .line 125
    .line 126
    move-object/from16 p14, v3

    .line 127
    .line 128
    move-object/from16 p11, v6

    .line 129
    .line 130
    move-object/from16 p12, v5

    .line 131
    .line 132
    move-object/from16 p9, v8

    .line 133
    .line 134
    move-object/from16 p10, v7

    .line 135
    .line 136
    move-object/from16 p7, v10

    .line 137
    .line 138
    move-object/from16 p8, v9

    .line 139
    .line 140
    move-object/from16 p5, v12

    .line 141
    .line 142
    move-object/from16 p6, v11

    .line 143
    .line 144
    move-object/from16 p3, v14

    .line 145
    .line 146
    move-object/from16 p4, v13

    .line 147
    .line 148
    invoke-virtual/range {p0 .. p15}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;LX/Da8;LX/Da5;)V
    .locals 2

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x3

    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 26
    .line 27
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 28
    .line 29
    .line 30
    const/4 v1, 0x5

    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    const/4 v1, 0x6

    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 38
    .line 39
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 40
    .line 41
    .line 42
    const/4 v1, 0x7

    .line 43
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 44
    .line 45
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 46
    .line 47
    .line 48
    const/16 v1, 0x8

    .line 49
    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 51
    .line 52
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 53
    .line 54
    .line 55
    const/16 v1, 0x9

    .line 56
    .line 57
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 60
    .line 61
    .line 62
    const/16 v1, 0xa

    .line 63
    .line 64
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 65
    .line 66
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 67
    .line 68
    .line 69
    const/16 v1, 0xb

    .line 70
    .line 71
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 72
    .line 73
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 74
    .line 75
    .line 76
    const/16 v1, 0xc

    .line 77
    .line 78
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 79
    .line 80
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 81
    .line 82
    .line 83
    const/16 v1, 0xd

    .line 84
    .line 85
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 86
    .line 87
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 88
    .line 89
    .line 90
    const/16 v1, 0xe

    .line 91
    .line 92
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 93
    .line 94
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 95
    .line 96
    .line 97
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component10()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component11()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component12()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component13()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component14()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component15()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component7()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component8()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component9()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-static {p6, p7}, LX/3Rq;->A1R(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x7

    .line 7
    invoke-static {p8, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 8
    .line 9
    .line 10
    const/16 p0, 0x8

    .line 11
    .line 12
    invoke-static {p9, p10, p11, p12, p0}, LX/005;->A15(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 13
    .line 14
    .line 15
    const/16 p0, 0xc

    .line 16
    .line 17
    invoke-static {p13, p14, p15, p0}, LX/Bi9;->A0I(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;

    .line 21
    .line 22
    invoke-direct/range {p0 .. p15}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_0

    .line 59
    .line 60
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_0

    .line 69
    .line 70
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_0

    .line 79
    .line 80
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 81
    .line 82
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 91
    .line 92
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 93
    .line 94
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_0

    .line 99
    .line 100
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 101
    .line 102
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 103
    .line 104
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eqz v0, :cond_0

    .line 109
    .line 110
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    if-eqz v0, :cond_0

    .line 119
    .line 120
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 121
    .line 122
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 123
    .line 124
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_0

    .line 129
    .line 130
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 131
    .line 132
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 133
    .line 134
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_0

    .line 139
    .line 140
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 141
    .line 142
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 143
    .line 144
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_0

    .line 149
    .line 150
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 151
    .line 152
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 153
    .line 154
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-nez v0, :cond_1

    .line 159
    .line 160
    :cond_0
    return v2

    .line 161
    :cond_1
    return v3
.end method

.method public final getAmount()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCountry_code()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCredential_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCredential_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCurrency_code()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOrder_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_session_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOtc_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPay_button_click_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_container_mode()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_product_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_request_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPlatform_trust_token()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getReceiver_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUpl_session_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->order_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->upl_session_id:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_id:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->credential_type:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->platform_trust_token:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_product_id:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->receiver_id:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->amount:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->currency_code:Ljava/lang/String;

    .line 51
    .line 52
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->country_code:Ljava/lang/String;

    .line 57
    .line 58
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_container_mode:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->pay_button_click_id:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->payment_request_id:Ljava/lang/String;

    .line 75
    .line 76
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_session_id:Ljava/lang/String;

    .line 81
    .line 82
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutFinalizeRequestJson;->otc_type:Ljava/lang/String;

    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    add-int/2addr v1, v0

    .line 93
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
