.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson$Companion;


# instance fields
.field public final attempt_id:Ljava/lang/String;

.field public final expires_at:Ljava/lang/Long;

.field public final url:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 805306368
    const/4 v0, 0x0

    .line 805306369
    invoke-direct {p0, v0, v0, v0}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 805306370
    .line 805306371
    .line 805306372
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Long;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    const/4 v1, 0x0

    .line 268435462
    if-nez v0, :cond_1

    .line 268435463
    .line 268435464
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 268435465
    .line 268435466
    :goto_0
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    if-nez v0, :cond_0

    .line 268435469
    .line 268435470
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 268435471
    .line 268435472
    :goto_1
    and-int/lit8 v0, p1, 0x4

    .line 268435473
    .line 268435474
    if-nez v0, :cond_2

    .line 268435475
    .line 268435476
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 268435477
    .line 268435478
    return-void

    .line 268435479
    :cond_0
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 268435480
    .line 268435481
    goto :goto_1

    .line 268435482
    :cond_1
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 268435483
    .line 268435484
    goto :goto_0

    .line 268435485
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 268435486
    .line 268435487
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p4, 0x1

    .line 536870913
    .line 536870914
    const/4 v1, 0x0

    .line 536870915
    if-eqz v0, :cond_0

    .line 536870916
    .line 536870917
    move-object p1, v1

    .line 536870918
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 536870919
    .line 536870920
    if-eqz v0, :cond_1

    .line 536870921
    .line 536870922
    move-object p2, v1

    .line 536870923
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 536870924
    .line 536870925
    if-eqz v0, :cond_2

    .line 536870926
    .line 536870927
    move-object p3, v1

    .line 536870928
    :cond_2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 536870929
    .line 536870930
    .line 536870931
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 17
    .line 18
    :cond_2
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;

    .line 19
    .line 20
    invoke-direct {v0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 21
    .line 22
    .line 23
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v2, 0x1

    .line 19
    if-nez v3, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 22
    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    :cond_3
    const/4 v2, 0x2

    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 36
    .line 37
    if-eqz v0, :cond_5

    .line 38
    .line 39
    :cond_4
    sget-object v1, LX/DZ1;->A00:LX/DZ1;

    .line 40
    .line 41
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 42
    .line 43
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 44
    .line 45
    .line 46
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;
    .locals 0

    .line 0
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;

    .line 1
    .line 2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getAttempt_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getExpires_at()Ljava/lang/Long;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getUrl()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->url:Ljava/lang/String;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v1, v0, 0x1f

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->attempt_id:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchLinkingWebAuthResponseJson;->expires_at:Ljava/lang/Long;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    :cond_0
    add-int/2addr v1, v2

    .line 27
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
