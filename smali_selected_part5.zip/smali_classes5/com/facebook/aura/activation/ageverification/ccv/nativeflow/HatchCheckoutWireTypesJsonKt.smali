.class public abstract Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutWireTypesJsonKt;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final HTTPS_SCHEME:Ljava/lang/String; = "https"

.field public static final HTTP_METHOD_POST:Ljava/lang/String; = "POST"


# direct methods
.method public static final toThreeDSRedirect(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect;
    .locals 3

    .line 0
    if-eqz p0, :cond_1

    .line 1
    .line 2
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutNextActionJson;->redirect_url:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutRedirectUrlJson;

    .line 3
    .line 4
    if-eqz p0, :cond_1

    .line 5
    .line 6
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutRedirectUrlJson;->is_for_three_ds:Ljava/lang/Boolean;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-static {v1, v0}, LX/003;->A1Z(Ljava/lang/Object;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-object v2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutRedirectUrlJson;->url:Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v2, :cond_2

    .line 18
    .line 19
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v0, "https"

    .line 28
    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2

    .line 34
    .line 35
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutRedirectUrlJson;->http_method:Ljava/lang/String;

    .line 36
    .line 37
    const-string v0, "POST"

    .line 38
    .line 39
    if-eqz v1, :cond_0

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_0

    .line 46
    .line 47
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;->POST:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 48
    .line 49
    :goto_0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;

    .line 50
    .line 51
    invoke-direct {v0, v2, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Valid;-><init>(Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;)V

    .line 52
    .line 53
    .line 54
    return-object v0

    .line 55
    :cond_0
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;->GET:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSHttpMethod;

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$None;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$None;

    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_2
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Invalid;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect$Invalid;

    .line 62
    .line 63
    :goto_1
    check-cast v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchThreeDSRedirect;

    .line 64
    .line 65
    return-object v0
.end method
