.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final $childSerializers:[Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlin/Lazy<",
            "LX/DZ7<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson$Companion;


# instance fields
.field public final age_confirmation_title:Ljava/lang/String;

.field public final ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

.field public final ccv_subtitle:Ljava/lang/String;

.field public final linkable_account_types:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 0
    const/4 v2, 0x0

    .line 1
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson$Companion;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson$Companion;

    .line 7
    .line 8
    sget-object v1, LX/FkO;->A01:Ljava/lang/Integer;

    .line 9
    .line 10
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson$Companion$$childSerializers$1;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson$Companion$$childSerializers$1;

    .line 11
    .line 12
    invoke-static {v1, v0}, LX/E2q;->A01(Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v0, v2, v2, v2}, [Lkotlin/Lazy;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->$childSerializers:[Lkotlin/Lazy;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 805306370
    .line 805306371
    invoke-direct {p0, v0, v1, v1, v1}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;LX/5Xm;)V
    .locals 2

    .line 536870912
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536870913
    .line 536870914
    .line 536870915
    and-int/lit8 v0, p1, 0x1

    .line 536870916
    .line 536870917
    if-nez v0, :cond_0

    .line 536870918
    .line 536870919
    sget-object p2, LX/0wV;->A00:LX/0wV;

    .line 536870920
    .line 536870921
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 536870922
    .line 536870923
    and-int/lit8 v0, p1, 0x2

    .line 536870924
    .line 536870925
    const/4 v1, 0x0

    .line 536870926
    if-nez v0, :cond_2

    .line 536870927
    .line 536870928
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 536870929
    .line 536870930
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 536870931
    .line 536870932
    if-nez v0, :cond_1

    .line 536870933
    .line 536870934
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 536870935
    .line 536870936
    :goto_1
    and-int/lit8 v0, p1, 0x8

    .line 536870937
    .line 536870938
    if-nez v0, :cond_3

    .line 536870939
    .line 536870940
    iput-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 536870941
    .line 536870942
    return-void

    .line 536870943
    :cond_1
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 536870944
    .line 536870945
    goto :goto_1

    .line 536870946
    :cond_2
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 536870947
    .line 536870948
    goto :goto_0

    .line 536870949
    :cond_3
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 536870950
    .line 536870951
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;",
            ")V"
        }
    .end annotation

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;ILX/04f;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p5, 0x1

    .line 268435457
    .line 268435458
    if-eqz v0, :cond_0

    .line 268435459
    .line 268435460
    sget-object p1, LX/0wV;->A00:LX/0wV;

    .line 268435461
    .line 268435462
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 268435463
    .line 268435464
    const/4 v1, 0x0

    .line 268435465
    if-eqz v0, :cond_1

    .line 268435466
    .line 268435467
    move-object p2, v1

    .line 268435468
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 268435469
    .line 268435470
    if-eqz v0, :cond_2

    .line 268435471
    .line 268435472
    move-object p3, v1

    .line 268435473
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 268435474
    .line 268435475
    if-eqz v0, :cond_3

    .line 268435476
    .line 268435477
    move-object p4, v1

    .line 268435478
    :cond_3
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)V

    .line 268435479
    .line 268435480
    .line 268435481
    return-void
.end method

.method public static final synthetic access$get$childSerializers$cp()[Lkotlin/Lazy;
    .locals 1

    .line 0
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p5, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p5, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p5, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p5, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 23
    .line 24
    :cond_3
    const/4 v0, 0x0

    .line 25
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;

    .line 29
    .line 30
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)V

    .line 31
    .line 32
    .line 33
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;LX/Da8;LX/Da5;)V
    .locals 5

    .line 0
    sget-object v4, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->$childSerializers:[Lkotlin/Lazy;

    .line 1
    .line 2
    const/4 v2, 0x0

    .line 3
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 4
    .line 5
    .line 6
    move-result v3

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 10
    .line 11
    sget-object v0, LX/0wV;->A00:LX/0wV;

    .line 12
    .line 13
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    :cond_0
    invoke-static {v4, v2}, LX/3Rp;->A1B([Lkotlin/Lazy;I)LX/DZE;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 24
    .line 25
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 26
    .line 27
    .line 28
    :cond_1
    const/4 v2, 0x1

    .line 29
    if-nez v3, :cond_2

    .line 30
    .line 31
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 32
    .line 33
    if-eqz v0, :cond_3

    .line 34
    .line 35
    :cond_2
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 36
    .line 37
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 38
    .line 39
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 40
    .line 41
    .line 42
    :cond_3
    const/4 v2, 0x2

    .line 43
    if-nez v3, :cond_4

    .line 44
    .line 45
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v0, :cond_5

    .line 48
    .line 49
    :cond_4
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 50
    .line 51
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 52
    .line 53
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 54
    .line 55
    .line 56
    :cond_5
    const/4 v2, 0x3

    .line 57
    if-nez v3, :cond_6

    .line 58
    .line 59
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 60
    .line 61
    if-eqz v0, :cond_7

    .line 62
    .line 63
    :cond_6
    sget-object v1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson$$serializer;

    .line 64
    .line 65
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 66
    .line 67
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 68
    .line 69
    .line 70
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;",
            ")",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;"
        }
    .end annotation

    .line 0
    const/4 p0, 0x0

    .line 1
    invoke-static {p1, p0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;

    .line 5
    .line 6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;)V

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    :cond_0
    return v2

    .line 51
    :cond_1
    return v3
.end method

.method public final getAge_confirmation_title()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCcv_params()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getCcv_subtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getLinkable_account_types()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->linkable_account_types:Ljava/util/List;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->age_confirmation_title:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_subtitle:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v1, v0

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchAgeConfirmationScreenJson;->ccv_params:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCcvParamsJson;

    .line 28
    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    :cond_0
    add-int/2addr v1, v2

    .line 36
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
