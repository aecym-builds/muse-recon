.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson$Companion;


# instance fields
.field public final device_id:Ljava/lang/String;

.field public final one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

.field public final payment_product_id:Ljava/lang/String;

.field public final payment_type:Ljava/lang/String;

.field public final session_id:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->Companion:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;LX/5Xm;)V
    .locals 2

    .line 268435456
    and-int/lit8 v0, p1, 0x1f

    .line 268435457
    .line 268435458
    const/16 v1, 0x1f

    .line 268435459
    .line 268435460
    if-eq v1, v0, :cond_0

    .line 268435461
    .line 268435462
    sget-object v0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson$$serializer;->descriptor:LX/Da5;

    .line 268435463
    .line 268435464
    invoke-static {v0, p1, v1}, LX/EPk;->A00(LX/Da5;II)V

    .line 268435465
    .line 268435466
    .line 268435467
    invoke-static {}, LX/01i;->createAndThrow()LX/01i;

    .line 268435468
    .line 268435469
    .line 268435470
    move-result-object v0

    .line 268435471
    throw v0

    .line 268435472
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435473
    .line 268435474
    .line 268435475
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 268435476
    .line 268435477
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 268435478
    .line 268435479
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 268435480
    .line 268435481
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 268435482
    .line 268435483
    iput-object p6, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 268435484
    .line 268435485
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;)V
    .locals 0

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 15
    .line 16
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;ILjava/lang/Object;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p6, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p6, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p6, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    and-int/lit8 v0, p6, 0x8

    .line 19
    .line 20
    if-eqz v0, :cond_3

    .line 21
    .line 22
    iget-object p4, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 23
    .line 24
    :cond_3
    and-int/lit8 v0, p6, 0x10

    .line 25
    .line 26
    if-eqz v0, :cond_4

    .line 27
    .line 28
    iget-object p5, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 29
    .line 30
    :cond_4
    invoke-virtual/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_ccv_nativeflow_nativeflow(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;LX/Da8;LX/Da5;)V
    .locals 3

    .line 0
    const/4 v1, 0x0

    .line 1
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 2
    .line 3
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 8
    .line 9
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x3

    .line 19
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 20
    .line 21
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 22
    .line 23
    .line 24
    sget-object v2, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson$$serializer;

    .line 25
    .line 26
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 27
    .line 28
    const/4 v0, 0x4

    .line 29
    invoke-interface {p1, v1, v2, p2, v0}, LX/Da8;->AAU(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component5()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;)Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;
    .locals 0

    .line 0
    invoke-static {p1, p2, p3, p4, p5}, LX/Bi9;->A0J(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;

    .line 4
    .line 5
    invoke-direct/range {p0 .. p5}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    iget-object v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 53
    .line 54
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-nez v0, :cond_1

    .line 59
    .line 60
    :cond_0
    return v2

    .line 61
    :cond_1
    return v3
.end method

.method public final getDevice_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getOne_time_checkout_input()Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_product_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getPayment_type()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSession_id()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->device_id:Ljava/lang/String;

    .line 1
    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_type:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->session_id:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->payment_product_id:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchPttEncryptionKeyRequestJson;->one_time_checkout_input:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchOneTimeCheckoutInputJson;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v1, v0

    .line 33
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
