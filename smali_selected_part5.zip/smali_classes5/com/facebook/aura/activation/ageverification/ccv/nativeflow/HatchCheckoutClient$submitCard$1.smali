.class public final Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;
.super LX/Btl;
.source ""


# annotations
.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.facebook.aura.activation.ageverification.ccv.nativeflow.HatchCheckoutClient"
    f = "HatchCheckoutClient.kt"
    l = {
        0x232,
        0x146,
        0x251,
        0x18c
    }
    m = "submitCard"
    v = 0x2
.end annotation


# instance fields
.field public I$0:I

.field public I$1:I

.field public I$2:I

.field public I$3:I

.field public L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$10:Ljava/lang/Object;

.field public L$11:Ljava/lang/Object;

.field public L$12:Ljava/lang/Object;

.field public L$13:Ljava/lang/Object;

.field public L$14:Ljava/lang/Object;

.field public L$15:Ljava/lang/Object;

.field public L$16:Ljava/lang/Object;

.field public L$17:Ljava/lang/Object;

.field public L$18:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public L$4:Ljava/lang/Object;

.field public L$5:Ljava/lang/Object;

.field public L$6:Ljava/lang/Object;

.field public L$7:Ljava/lang/Object;

.field public L$8:Ljava/lang/Object;

.field public L$9:Ljava/lang/Object;

.field public label:I

.field public synthetic result:Ljava/lang/Object;

.field public final synthetic this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;


# direct methods
.method public constructor <init>(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;LX/2M4;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;",
            ">;)V"
        }
    .end annotation

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 1
    .line 2
    invoke-direct {p0, p2}, LX/Btl;-><init>(LX/2M4;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->result:Ljava/lang/Object;

    .line 1
    .line 2
    iget v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    or-int/2addr v1, v0

    .line 7
    iput v1, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->label:I

    .line 8
    .line 9
    iget-object v0, p0, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient$submitCard$1;->this$0:Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    move-object v2, v1

    .line 13
    move-object v3, v1

    .line 14
    move-object v4, v1

    .line 15
    move-object v5, v1

    .line 16
    move-object v6, v1

    .line 17
    move-object v7, v1

    .line 18
    move-object v8, v1

    .line 19
    move-object v9, v1

    .line 20
    invoke-virtual/range {v0 .. v10}, Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutClient;->submitCard(Lcom/facebook/aura/activation/ageverification/ccv/nativeflow/HatchCheckoutSession;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/2M4;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0
.end method
