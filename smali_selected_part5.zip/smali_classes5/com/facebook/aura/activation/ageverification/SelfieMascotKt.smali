.class public abstract Lcom/facebook/aura/activation/ageverification/SelfieMascotKt;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final SelfieMascot(LX/3C1;LX/2d4;II)V
    .locals 36

    .line 0
    move-object/from16 v8, p0

    .line 1
    .line 2
    const v1, -0x41f51131

    .line 3
    .line 4
    .line 5
    move-object/from16 v0, p1

    .line 6
    .line 7
    invoke-interface {v0, v1}, LX/2d4;->Agl(I)V

    .line 8
    .line 9
    .line 10
    move/from16 v3, p3

    .line 11
    .line 12
    and-int/lit8 v7, p3, 0x1

    .line 13
    .line 14
    const/4 v5, 0x2

    .line 15
    move/from16 v1, p2

    .line 16
    .line 17
    if-eqz v7, :cond_5

    .line 18
    .line 19
    or-int/lit8 v6, p2, 0x6

    .line 20
    .line 21
    :goto_0
    and-int/lit8 v4, v6, 0x3

    .line 22
    .line 23
    const/4 v14, 0x0

    .line 24
    const/4 v2, 0x1

    .line 25
    invoke-static {v4, v5}, LX/003;->A1H(II)Z

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    and-int/lit8 v4, v6, 0x1

    .line 30
    .line 31
    invoke-interface {v0, v4, v5}, LX/2d4;->Afw(IZ)Z

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_4

    .line 36
    .line 37
    if-eqz v7, :cond_0

    .line 38
    .line 39
    sget-object v8, LX/3C1;->A00:LX/3Cb;

    .line 40
    .line 41
    :cond_0
    const/4 v5, 0x6

    .line 42
    invoke-static {v2, v0, v5, v14}, Lcom/facebook/aura/vds/compose/accessibility/ReducedMotionKt;->rememberAnimatorDurationScale(ZLX/2d4;II)F

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    const/16 v21, 0x0

    .line 47
    .line 48
    cmpl-float v4, v4, v21

    .line 49
    .line 50
    if-lez v4, :cond_3

    .line 51
    .line 52
    const v4, 0x7a467004

    .line 53
    .line 54
    .line 55
    invoke-interface {v0, v4}, LX/2d4;->Agj(I)V

    .line 56
    .line 57
    .line 58
    invoke-interface {v0}, LX/2d4;->Aat()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v9

    .line 62
    sget-object v4, LX/2d6;->A00:Ljava/lang/Object;

    .line 63
    .line 64
    if-ne v9, v4, :cond_1

    .line 65
    .line 66
    sget-object v4, Lcom/facebook/aura/ageverification/remote/RemoteFiles;->AGE_VERIFICATION_SELFIE_MASCOT:LX/32e;

    .line 67
    .line 68
    invoke-static {v4}, LX/9j8;->A00(LX/32e;)Landroid/net/Uri;

    .line 69
    .line 70
    .line 71
    move-result-object v9

    .line 72
    invoke-interface {v0, v9}, LX/2d4;->AiV(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_1
    check-cast v9, Landroid/net/Uri;

    .line 76
    .line 77
    sget-object v12, Lcom/facebook/aura/common/video/HatchVideoPlayer$RepeatMode;->ALL:Lcom/facebook/aura/common/video/HatchVideoPlayer$RepeatMode;

    .line 78
    .line 79
    move v13, v14

    .line 80
    move/from16 v17, v5

    .line 81
    .line 82
    move-object v15, v0

    .line 83
    move/from16 v16, v5

    .line 84
    .line 85
    invoke-static/range {v12 .. v17}, Lcom/facebook/aura/common/video/RememberHatchVideoPlayerKt;->rememberHatchVideoPlayer(Lcom/facebook/aura/common/video/HatchVideoPlayer$RepeatMode;ZZLX/2d4;II)Lcom/facebook/aura/common/video/HatchVideoPlayer;

    .line 86
    .line 87
    .line 88
    move-result-object v10

    .line 89
    const v4, 0x7f080079

    .line 90
    .line 91
    .line 92
    new-instance v12, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;

    .line 93
    .line 94
    invoke-direct {v12, v4}, Lcom/facebook/aura/vds/compose/common/AuraDrawableSourceResource;-><init>(I)V

    .line 95
    .line 96
    .line 97
    sget-object v20, Lcom/facebook/aura/common/video/HatchVideoPlayer$ResizeMode;->ZOOM:Lcom/facebook/aura/common/video/HatchVideoPlayer$ResizeMode;

    .line 98
    .line 99
    and-int/lit8 p0, v6, 0xe

    .line 100
    .line 101
    const p3, 0x7faabe8

    .line 102
    .line 103
    .line 104
    const/4 v11, 0x0

    .line 105
    const-string v22, "age_verification_selfie_mascot"

    .line 106
    .line 107
    const p1, 0x6186186

    .line 108
    .line 109
    .line 110
    move-object v13, v11

    .line 111
    move v15, v14

    .line 112
    move/from16 v16, v14

    .line 113
    .line 114
    move/from16 v17, v14

    .line 115
    .line 116
    move/from16 v18, v14

    .line 117
    .line 118
    move/from16 v19, v14

    .line 119
    .line 120
    move-object/from16 v23, v11

    .line 121
    .line 122
    move/from16 v24, v14

    .line 123
    .line 124
    move/from16 v25, v14

    .line 125
    .line 126
    move/from16 v26, v2

    .line 127
    .line 128
    move-object/from16 v27, v11

    .line 129
    .line 130
    move/from16 v28, v14

    .line 131
    .line 132
    move-object/from16 v29, v11

    .line 133
    .line 134
    move-object/from16 v30, v11

    .line 135
    .line 136
    move-object/from16 v31, v11

    .line 137
    .line 138
    move-object/from16 v32, v11

    .line 139
    .line 140
    move-object/from16 v33, v11

    .line 141
    .line 142
    move-object/from16 v34, v11

    .line 143
    .line 144
    move-object/from16 v35, v0

    .line 145
    .line 146
    move/from16 p2, v14

    .line 147
    .line 148
    invoke-static/range {v8 .. v39}, Lcom/facebook/aura/common/video/HatchVideoPlayerComposableKt;->HatchVideoPlayerComposable(LX/3C1;Landroid/net/Uri;Lcom/facebook/aura/common/video/HatchVideoPlayer;Ljava/lang/String;Lcom/facebook/aura/vds/compose/common/AuraDrawableSource;LX/HVa;ZZZZZZLcom/facebook/aura/common/video/HatchVideoPlayer$ResizeMode;FLjava/lang/String;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/Integer;ZLX/JDM;LX/JDN;LX/JDM;Lkotlin/jvm/functions/Function0;LX/JDM;LX/JDM;LX/2d4;IIII)V

    .line 149
    .line 150
    .line 151
    :goto_1
    move-object v2, v0

    .line 152
    check-cast v2, LX/J7I;

    .line 153
    .line 154
    invoke-static {v2, v14}, LX/J7I;->A0R(LX/J7I;Z)V

    .line 155
    .line 156
    .line 157
    :goto_2
    invoke-interface {v0}, LX/2d4;->AAg()LX/J7V;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    if-eqz v2, :cond_2

    .line 162
    .line 163
    new-instance v0, Lcom/facebook/aura/activation/ageverification/SelfieMascotKt$SelfieMascot$1;

    .line 164
    .line 165
    invoke-direct {v0, v8, v1, v3}, Lcom/facebook/aura/activation/ageverification/SelfieMascotKt$SelfieMascot$1;-><init>(LX/3C1;II)V

    .line 166
    .line 167
    .line 168
    iput-object v0, v2, LX/J7V;->A06:LX/JDN;

    .line 169
    .line 170
    :cond_2
    return-void

    .line 171
    :cond_3
    const v2, 0x7a4f614b

    .line 172
    .line 173
    .line 174
    invoke-interface {v0, v2}, LX/2d4;->Agj(I)V

    .line 175
    .line 176
    .line 177
    const v2, 0x7f080079

    .line 178
    .line 179
    .line 180
    invoke-static {v0, v2, v14}, LX/18Y;->A00(LX/2d4;II)LX/2l9;

    .line 181
    .line 182
    .line 183
    move-result-object v26

    .line 184
    sget-object v27, LX/32Y;->A00:LX/2vq;

    .line 185
    .line 186
    sget v2, LX/2l9;->$stable:I

    .line 187
    .line 188
    or-int/lit16 v4, v2, 0x6030

    .line 189
    .line 190
    shl-int/lit8 v2, v6, 0x6

    .line 191
    .line 192
    and-int/lit16 v2, v2, 0x380

    .line 193
    .line 194
    or-int/2addr v4, v2

    .line 195
    const/16 v31, 0x68

    .line 196
    .line 197
    const/16 v23, 0x0

    .line 198
    .line 199
    move-object/from16 v22, v0

    .line 200
    .line 201
    move-object/from16 v24, v8

    .line 202
    .line 203
    move-object/from16 v25, v23

    .line 204
    .line 205
    move-object/from16 v28, v23

    .line 206
    .line 207
    move/from16 v29, v21

    .line 208
    .line 209
    move/from16 v30, v4

    .line 210
    .line 211
    invoke-static/range {v22 .. v31}, LX/1oV;->A00(LX/2d4;Landroidx/compose/ui/Alignment;LX/3C1;LX/2hc;LX/2l9;LX/2vq;Ljava/lang/String;FII)V

    .line 212
    .line 213
    .line 214
    goto :goto_1

    .line 215
    :cond_4
    invoke-interface {v0}, LX/2d4;->AgJ()V

    .line 216
    .line 217
    .line 218
    goto :goto_2

    .line 219
    :cond_5
    and-int/lit8 v2, p2, 0x6

    .line 220
    .line 221
    if-nez v2, :cond_6

    .line 222
    .line 223
    invoke-static {v0, v8}, LX/004;->A0Z(LX/2d4;Ljava/lang/Object;)I

    .line 224
    .line 225
    .line 226
    move-result v6

    .line 227
    or-int v6, v6, p2

    .line 228
    .line 229
    goto/16 :goto_0

    .line 230
    .line 231
    :cond_6
    move v6, v1

    .line 232
    goto/16 :goto_0
.end method
