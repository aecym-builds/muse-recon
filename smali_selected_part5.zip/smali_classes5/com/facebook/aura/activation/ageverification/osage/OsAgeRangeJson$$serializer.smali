.class public final synthetic Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements LX/D8a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LX/D8a<",
        "Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Deprecated;
    level = .enum LX/1EM;->A03:LX/1EM;
    message = "This synthesized declaration should not be used directly"
.end annotation


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;

.field public static final descriptor:LX/Da5;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 0
    new-instance v2, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;

    .line 1
    .line 2
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v2, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;

    .line 6
    .line 7
    const/4 v1, 0x6

    .line 8
    const-string v0, "com.facebook.aura.activation.ageverification.osage.OsAgeRangeJson"

    .line 9
    .line 10
    new-instance v3, LX/DZp;

    .line 11
    .line 12
    invoke-direct {v3, v0, v2, v1}, LX/DZp;-><init>(Ljava/lang/String;LX/D8a;I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "source"

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    const-string v1, "age_range_type"

    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    invoke-virtual {v3, v1, v0}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "age_lower"

    .line 28
    .line 29
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "age_upper"

    .line 33
    .line 34
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "most_recent_approval_date"

    .line 38
    .line 39
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "significant_change_status"

    .line 43
    .line 44
    invoke-virtual {v3, v0, v2}, LX/DZp;->A01(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sput-object v3, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->descriptor:LX/Da5;

    .line 48
    .line 49
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final childSerializers()[LX/DZ7;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object v2, LX/DYp;->A01:LX/DYp;

    .line 1
    .line 2
    invoke-static {v2}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    sget-object v0, LX/DYo;->A00:LX/DYo;

    .line 7
    .line 8
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    sget-object v0, LX/DZ1;->A00:LX/DZ1;

    .line 17
    .line 18
    invoke-static {v0}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    invoke-static {v2}, LX/DZ8;->A00(LX/DZ7;)LX/DZ7;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    filled-new-array/range {v1 .. v6}, [LX/DZ7;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0
.end method

.method public final deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;
    .locals 15

    .line 0
    const/4 v8, 0x0

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0, v8}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 4
    .line 5
    .line 6
    sget-object v7, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->descriptor:LX/Da5;

    .line 7
    .line 8
    invoke-interface {v0, v7}, LX/DYy;->A58(LX/Da5;)LX/Da7;

    .line 9
    .line 10
    .line 11
    move-result-object v6

    .line 12
    const/4 v5, 0x5

    .line 13
    const/4 v4, 0x3

    .line 14
    const/4 v3, 0x4

    .line 15
    const/4 v2, 0x2

    .line 16
    const/4 v1, 0x1

    .line 17
    const/4 v10, 0x0

    .line 18
    move-object v11, v10

    .line 19
    move-object v12, v10

    .line 20
    move-object v13, v10

    .line 21
    move-object v14, v10

    .line 22
    move-object p0, v10

    .line 23
    const/4 v9, 0x0

    .line 24
    :goto_0
    invoke-interface {v6, v7}, LX/Da7;->A8S(LX/Da5;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    packed-switch v0, :pswitch_data_0

    .line 29
    .line 30
    .line 31
    new-instance v1, Lkotlinx/serialization/UnknownFieldException;

    .line 32
    .line 33
    invoke-direct {v1, v0}, Lkotlinx/serialization/UnknownFieldException;-><init>(I)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :pswitch_0
    invoke-static {v7, v6, v8}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v10

    .line 41
    or-int/lit8 v9, v9, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :pswitch_1
    invoke-interface {v6, v7, v1}, LX/Da7;->A8k(LX/Da5;I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v11

    .line 48
    or-int/lit8 v9, v9, 0x2

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :pswitch_2
    sget-object v0, LX/DYo;->A00:LX/DYo;

    .line 52
    .line 53
    invoke-interface {v6, v0, v7, v2}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v12

    .line 57
    check-cast v12, Ljava/lang/Integer;

    .line 58
    .line 59
    or-int/lit8 v9, v9, 0x4

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :pswitch_3
    sget-object v0, LX/DYo;->A00:LX/DYo;

    .line 63
    .line 64
    invoke-interface {v6, v0, v7, v4}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v13

    .line 68
    check-cast v13, Ljava/lang/Integer;

    .line 69
    .line 70
    or-int/lit8 v9, v9, 0x8

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :pswitch_4
    sget-object v0, LX/DZ1;->A00:LX/DZ1;

    .line 74
    .line 75
    invoke-interface {v6, v0, v7, v3}, LX/Da7;->A8e(LX/Dci;LX/Da5;I)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v14

    .line 79
    check-cast v14, Ljava/lang/Long;

    .line 80
    .line 81
    or-int/lit8 v9, v9, 0x10

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :pswitch_5
    invoke-static {v7, v6, v5}, LX/3Rr;->A0q(LX/Da5;LX/Da7;I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p0

    .line 88
    or-int/lit8 v9, v9, 0x20

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :pswitch_6
    invoke-interface {v6, v7}, LX/Da7;->AAi(LX/Da5;)V

    .line 92
    .line 93
    .line 94
    const/16 p1, 0x0

    .line 95
    .line 96
    new-instance v8, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;

    .line 97
    .line 98
    invoke-direct/range {v8 .. v16}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/String;LX/5Xm;)V

    .line 99
    .line 100
    .line 101
    return-object v8

    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_6
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method

.method public bridge synthetic deserialize(LX/DYy;)Ljava/lang/Object;
    .locals 0

    .line 268435456
    invoke-virtual {p0, p1}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->deserialize(LX/DYy;)Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;

    .line 268435457
    .line 268435458
    .line 268435459
    move-result-object p0

    .line 268435460
    return-object p0
.end method

.method public final getDescriptor()LX/Da5;
    .locals 0

    .line 0
    sget-object p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->descriptor:LX/Da5;

    .line 1
    .line 2
    return-object p0
.end method

.method public final serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;)V
    .locals 1

    .line 0
    invoke-static {p1, p2}, LX/004;->A1I(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    sget-object p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->descriptor:LX/Da5;

    .line 4
    .line 5
    invoke-interface {p1, p0}, LX/DZ5;->A59(LX/Da5;)LX/Da8;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {p2, v0, p0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;->write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_ageverification_osage_impl_impl(Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;LX/Da8;LX/Da5;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {v0, p0}, LX/Da8;->AAi(LX/Da5;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public bridge synthetic serialize(LX/DZ5;Ljava/lang/Object;)V
    .locals 0

    .line 268435456
    check-cast p2, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;

    .line 268435457
    .line 268435458
    invoke-virtual {p0, p1, p2}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson$$serializer;->serialize(LX/DZ5;Lcom/facebook/aura/activation/ageverification/osage/OsAgeRangeJson;)V

    .line 268435459
    .line 268435460
    .line 268435461
    return-void
.end method

.method public bridge typeParametersSerializers()[LX/DZ7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "LX/DZ7<",
            "*>;"
        }
    .end annotation

    .line 0
    sget-object p0, LX/5w5;->A00:[LX/DZ7;

    .line 1
    .line 2
    return-object p0
.end method
