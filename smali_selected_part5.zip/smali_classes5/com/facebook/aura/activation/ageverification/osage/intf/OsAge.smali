.class public final Lcom/facebook/aura/activation/ageverification/osage/intf/OsAge;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/intf/OsAge;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAge;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAge;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/intf/OsAge;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final getIntegration()Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;
    .locals 1

    .line 0
    const/4 p0, 0x0

    .line 1
    filled-new-array {p0}, [I

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    aget p0, v0, p0

    .line 6
    .line 7
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-nez p0, :cond_0

    .line 12
    .line 13
    sget-object v0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;->integration()Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0

    .line 20
    :cond_0
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    const/16 v0, 0x2c

    .line 25
    .line 26
    invoke-static {v0}, LX/000;->A00(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v0, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 35
    .line 36
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw v0
.end method
