.class public final Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final rangeJson:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    iput-object p1, p0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;->rangeJson:Ljava/lang/String;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final getRangeJson()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;->rangeJson:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method
