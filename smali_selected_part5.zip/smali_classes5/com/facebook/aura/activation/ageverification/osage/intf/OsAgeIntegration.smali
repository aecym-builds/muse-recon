.class public interface abstract Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract collect(LX/1EL;Lkotlin/jvm/functions/Function0;LX/2M4;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LX/1EL;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroid/app/Activity;",
            ">;",
            "LX/2M4<",
            "-",
            "Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeAnswer;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
