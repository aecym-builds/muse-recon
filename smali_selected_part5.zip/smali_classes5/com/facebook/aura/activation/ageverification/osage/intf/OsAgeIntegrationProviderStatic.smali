.class public Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegrationProviderStatic;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    .line 2
    .line 3
    return-void
.end method

.method public static getKeys()[I
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    filled-new-array {v0}, [I

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static integration(I)Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;
    .locals 0

    .line 0
    if-nez p0, :cond_0

    .line 1
    .line 2
    sget-object p0, Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;->INSTANCE:Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;

    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/facebook/aura/activation/ageverification/osage/OsAgeIntegrationProviderImpl;->integration()Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0

    .line 9
    :cond_0
    invoke-static {p0}, LX/009;->A0Z(I)Ljava/lang/IllegalArgumentException;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    throw p0
.end method
