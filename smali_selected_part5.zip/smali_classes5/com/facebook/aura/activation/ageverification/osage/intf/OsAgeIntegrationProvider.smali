.class public interface abstract Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegrationProvider;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract integration()Lcom/facebook/aura/activation/ageverification/osage/intf/OsAgeIntegration;
.end method
