.class public final Lcom/facebook/aura/activation/repo/AuraDebugSetHatchWaitlistStatusMutationResponse$XabDebugSetHatchWaitlistStatus;
.super LX/IUd;
.source ""


# direct methods
.method public constructor <init>(LX/IUc;)V
    .locals 1

    .line 0
    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, LX/I1c;->A0f(Ljava/lang/Object;I)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, LX/IUd;-><init>(LX/IUc;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getStatus$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()LX/7Kq;
    .locals 2

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    sget-object v1, LX/7Kq;->A05:LX/7Kq;

    .line 3
    .line 4
    const v0, -0x3532300e    # -6744057.0f

    .line 5
    .line 6
    .line 7
    invoke-interface {p0, v1, v0}, LX/JmF;->AIO(Ljava/lang/Enum;I)Ljava/lang/Enum;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, LX/7Kq;

    .line 12
    .line 13
    return-object v0
.end method

.method public final getSuccess$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()Z
    .locals 1

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, -0x6f4abffd

    .line 3
    .line 4
    .line 5
    invoke-interface {p0, v0}, LX/JmF;->ADt(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public final hasSuccess$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo()Z
    .locals 1

    .line 0
    iget-object p0, p0, LX/IUd;->innerData:LX/IUc;

    .line 1
    .line 2
    const v0, -0x6f4abffd

    .line 3
    .line 4
    .line 5
    invoke-interface {p0, v0}, LX/JmF;->ANF(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method
