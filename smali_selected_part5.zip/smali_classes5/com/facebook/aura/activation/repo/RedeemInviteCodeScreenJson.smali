.class public final Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
.super LX/07H;
.source ""


# annotations
.annotation runtime Lkotlinx/serialization/Serializable;
.end annotation


# static fields
.field public static final Companion:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$Companion;


# instance fields
.field public final disclaimer:Ljava/lang/String;

.field public final subtitle:Ljava/lang/String;

.field public final title:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$Companion;

    .line 1
    .line 2
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 3
    .line 4
    .line 5
    sput-object v0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->Companion:Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson$Companion;

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 805306368
    const/4 v1, 0x0

    .line 805306369
    const-string v0, ""

    .line 805306370
    .line 805306371
    invoke-direct {p0, v1, v0, v0}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 805306372
    .line 805306373
    .line 805306374
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;LX/5Xm;)V
    .locals 2

    .line 268435456
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268435457
    .line 268435458
    .line 268435459
    and-int/lit8 v0, p1, 0x1

    .line 268435460
    .line 268435461
    if-nez v0, :cond_0

    .line 268435462
    .line 268435463
    const/4 p2, 0x0

    .line 268435464
    :cond_0
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 268435465
    .line 268435466
    and-int/lit8 v0, p1, 0x2

    .line 268435467
    .line 268435468
    const-string v1, ""

    .line 268435469
    .line 268435470
    if-nez v0, :cond_1

    .line 268435471
    .line 268435472
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 268435473
    .line 268435474
    :goto_0
    and-int/lit8 v0, p1, 0x4

    .line 268435475
    .line 268435476
    if-nez v0, :cond_2

    .line 268435477
    .line 268435478
    iput-object v1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 268435479
    .line 268435480
    return-void

    .line 268435481
    :cond_1
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 268435482
    .line 268435483
    goto :goto_0

    .line 268435484
    :cond_2
    iput-object p4, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 268435485
    .line 268435486
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p2, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p3, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILX/04f;)V
    .locals 2

    .line 536870912
    and-int/lit8 v0, p4, 0x1

    .line 536870913
    .line 536870914
    if-eqz v0, :cond_0

    .line 536870915
    .line 536870916
    const/4 p1, 0x0

    .line 536870917
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 536870918
    .line 536870919
    const-string v1, ""

    .line 536870920
    .line 536870921
    if-eqz v0, :cond_1

    .line 536870922
    .line 536870923
    move-object p2, v1

    .line 536870924
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 536870925
    .line 536870926
    if-eqz v0, :cond_2

    .line 536870927
    .line 536870928
    move-object p3, v1

    .line 536870929
    :cond_2
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 536870930
    .line 536870931
    .line 536870932
    return-void
.end method

.method public static synthetic copy$default(Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
    .locals 1

    .line 0
    and-int/lit8 v0, p4, 0x1

    .line 1
    .line 2
    if-eqz v0, :cond_0

    .line 3
    .line 4
    iget-object p1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 5
    .line 6
    :cond_0
    and-int/lit8 v0, p4, 0x2

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object p2, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 11
    .line 12
    :cond_1
    and-int/lit8 v0, p4, 0x4

    .line 13
    .line 14
    if-eqz v0, :cond_2

    .line 15
    .line 16
    iget-object p3, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 17
    .line 18
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method

.method public static final synthetic write$Self$fbandroid_express_aura_java_com_facebook_aura_activation_repo_repo(Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;LX/Da8;LX/Da5;)V
    .locals 4

    .line 0
    const/4 v2, 0x0

    .line 1
    invoke-interface {p1}, LX/Da8;->Afv()Z

    .line 2
    .line 3
    .line 4
    move-result v3

    .line 5
    if-nez v3, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    :cond_0
    sget-object v1, LX/DYp;->A01:LX/DYp;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 14
    .line 15
    invoke-interface {p1, v0, v1, p2, v2}, LX/Da8;->AAT(Ljava/lang/Object;LX/DZE;LX/Da5;I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    const/4 v1, 0x1

    .line 19
    const-string v2, ""

    .line 20
    .line 21
    if-nez v3, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    :cond_2
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 34
    .line 35
    .line 36
    :cond_3
    const/4 v1, 0x2

    .line 37
    if-nez v3, :cond_4

    .line 38
    .line 39
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_5

    .line 46
    .line 47
    :cond_4
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 48
    .line 49
    invoke-interface {p1, v0, p2, v1}, LX/Da8;->AAZ(Ljava/lang/String;LX/Da5;I)V

    .line 50
    .line 51
    .line 52
    :cond_5
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;
    .locals 0

    .line 0
    invoke-static {p2, p3}, LX/004;->A1J(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    .line 2
    .line 3
    new-instance p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 4
    .line 5
    invoke-direct {p0, p1, p2, p3}, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 0
    const/4 v3, 0x1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    check-cast p1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;

    .line 9
    .line 10
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 13
    .line 14
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    iget-object v1, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v1, v0}, LX/I1c;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    :cond_0
    return v2

    .line 41
    :cond_1
    return v3
.end method

.method public final getDisclaimer()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getSubtitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    return-object p0
.end method

.method public hashCode()I
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->title:Ljava/lang/String;

    .line 1
    .line 2
    invoke-static {v0}, LX/008;->A0Y(Ljava/lang/String;)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v1, v0, 0x1f

    .line 7
    .line 8
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->subtitle:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {v0, v1}, LX/007;->A0S(Ljava/lang/String;I)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    iget-object v0, p0, Lcom/facebook/aura/activation/repo/RedeemInviteCodeScreenJson;->disclaimer:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    add-int/2addr v1, v0

    .line 21
    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    .line 0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1
    .line 2
    .line 3
    move-result-object p0

    .line 4
    return-object p0
.end method
